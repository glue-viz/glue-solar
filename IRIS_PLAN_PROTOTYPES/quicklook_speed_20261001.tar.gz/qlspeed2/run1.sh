#!/bin/sh
# run1.sh TREE MODE AXES OUT
Q=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/qlspeed2
H=$(mktemp -d "$Q/home.XXXXXX"); mkdir -p "$H/cache" "$H/config" "$H/sunpy"
cd "$Q" && env HOME="$H" MPLCONFIGDIR="$Q/mplcfg" XDG_CACHE_HOME="$H/cache" XDG_CONFIG_HOME="$H/config" SUNPY_CONFIGDIR="$H/sunpy" \
  QT_QPA_PLATFORM=offscreen MPLBACKEND=agg PYTHONDONTWRITEBYTECODE=1 \
  ~/mamba/envs/iris-plan/bin/python -B "$Q/qlprobe.py" "$@"
rc=$?
rm -rf "$H"
exit $rc
