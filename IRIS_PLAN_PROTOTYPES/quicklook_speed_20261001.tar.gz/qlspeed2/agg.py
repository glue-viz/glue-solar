"""Aggregate out/r*_<tree>_<mode>_<axes>.json: pooled medians, per-round median spread, per-commit deltas."""
import glob
import json
import os
import statistics as st
import sys
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
TREES = ["3e1e767", "00f222e", "dd3c453", "a06a251", "20f6a9d", "0998867", "75a2bbd", "784ff92", "ce3d36a", "280be13"]
LABEL = {"3e1e767": "main", "00f222e": "S9", "dd3c453": "S7", "a06a251": "S8", "20f6a9d": "S3", "0998867": "S2",
         "75a2bbd": "S1", "784ff92": "HideAx", "ce3d36a": "R1", "280be13": "memo"}
# (row label, mode, scenario, metric); metric 'draws' sums Agg draws
ROWS = [
    ("quicklook() s", "ql", "quicklook_s", None),
    ("open to idle s", "ql", "open_idle_s", None),
    ("image step (stock viewer) to drawn", "image", "image_step", "images"),
    ("  its set phase (sync)", "image", "image_step", "sync"),
    ("image step (QL map wavelength) to drawn [S8]", "ql", "map_wl_step", "images"),
    ("  its idle (coordinator timer too)", "ql", "map_wl_step", "idle"),
    ("λ–t slit step, image panels drawn", "ql", "lt_slit_step", "images"),
    ("  its set phase (sync) [S1, R1]", "ql", "lt_slit_step", "sync"),
    ("  its idle (spectrum too)", "ql", "lt_slit_step", "idle"),
    ("SJI step to drawn", "ql", "sji_step", "images"),
    ("  its set phase (sync) [R1]", "ql", "sji_step", "sync"),
    ("  its idle", "ql", "sji_step", "idle"),
    ("synced step @1, image panels drawn", "ql", "synced_step_1", "images"),
    ("synced step @800, image panels drawn", "ql", "synced_step_800", "images"),
    ("synced step @1599, image panels drawn", "ql", "synced_step_1599", "images"),
    ("synced step @800 idle (spectrum too)", "ql", "synced_step_800", "idle"),
    ("click to drawn spectrum", "ql", "click", "spectrum"),
    ("click, image panels drawn [S2, S3]", "ql", "click", "images"),
    ("click idle", "ql", "click", "idle"),
    ("click, Agg draws (all panels)", "ql", "click", "draws"),
    ("click, SJI draws", "ql", "click", "draws_sji"),
    ("click, tick updates", "ql", "click", "ticks"),
    ("SJI step tick updates", "ql", "sji_step", "ticks"),
    ("λ–t slit step tick updates (set phase)", "ql", "lt_slit_step", "ticks_sync"),
    ("map contrast to drawn [S7]", "ql", "contrast_map", "images"),
    ("redraw map", "ql", "redraw_map", "sync"),
    ("redraw spectrogram", "ql", "redraw_spectrogram", "sync"),
    ("redraw λ–t", "ql", "redraw_wavelength", "sync"),
    ("redraw SJI", "ql", "redraw_sji", "sync"),
    ("stock viewer unchanged redraw", "image", "image_redraw", "sync"),
    ("peak RSS MB", "ql", "maxrss_mb", None),
]


def value(sample, metric):
    if metric == "draws":
        return sum(sample["draws"].values())
    if metric == "draws_sji":
        return sample["draws"].get("sji", 0)
    v = sample[metric]
    return None if v is None else v


def load(clock="slow"):
    from classify import labels

    lab = labels()
    data = defaultdict(list)  # (tree, mode, axes) -> results
    for path in sorted(glob.glob(os.path.join(HERE, "out", "r*_*.json"))):
        if clock != "all" and lab[path] != clock:
            continue
        r, tree, mode, axes = os.path.basename(path)[:-5].split("_")
        data[tree, mode, axes].append(json.load(open(path)))
    return data


def stat(results, scenario, metric):
    """(pooled median, min and max of per-round medians, rounds); seconds become ms, counts stay."""
    if metric is None:
        vals = [r[scenario] for r in results if r.get(scenario) is not None]
        if not vals:
            return None
        return st.median(vals), min(vals), max(vals), len(vals)
    pooled, rounds = [], []
    for r in results:
        vs = [value(s, metric) for s in r["samples"].get(scenario, [])]
        vs = [v for v in vs if v is not None]
        if vs:
            pooled += vs
            rounds.append(st.median(vs))
    if not pooled:
        return None
    scale = 1 if metric.startswith(("draws", "ticks")) else 1e3
    return st.median(pooled) * scale, min(rounds) * scale, max(rounds) * scale, len(rounds)


def fmt(s, spread=True):
    if s is None:
        return "–"
    m, lo, hi, n = s
    if spread:
        return f"{m:.0f} ({lo:.0f}–{hi:.0f})" if m >= 10 else f"{m:.2f} ({lo:.2f}–{hi:.2f})"
    return f"{m:.0f}" if m >= 10 else f"{m:.2f}"


def main():
    axes = sys.argv[1] if len(sys.argv) > 1 else "on"
    data = load(sys.argv[2] if len(sys.argv) > 2 else "slow")
    trees = [t for t in TREES if (t, "ql", axes) in data or (t, "image", axes) in data]
    print("rounds:", {f"{LABEL[t]}/{m}/{a}": len(v) for (t, m, a), v in sorted(data.items())})
    print("| scenario | " + " | ".join(f"{LABEL[t]} {t}" for t in trees) + " |")
    print("|---|" + "---|" * len(trees))
    for label, mode, scenario, metric in ROWS:
        cells = [fmt(stat(data.get((t, mode, axes), []), scenario, metric)) for t in trees]
        print(f"| {label} | " + " | ".join(cells) + " |")


if __name__ == "__main__":
    main()
