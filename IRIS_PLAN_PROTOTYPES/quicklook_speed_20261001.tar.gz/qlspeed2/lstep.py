exec(open("ident.py").read().split("for name, (data, x, y, steps) in cases.items():")[0])
for name in ("lambda_step", "sji_roll60"):
    data, x, y, steps = cases[name]
    for patched in (False, True):
        v = make(data, x, y, patched)
        v.figure.canvas.draw()
        print(name, "patched" if patched else "glue", v.state.x_axislabel, "|", v.state.y_axislabel)
        for i, coord in enumerate(v.axes.coords):
            print("   coord", i, coord.coord_type, "ticklabels", coord.get_ticklabel_position(), {k: list(t)[:4] for k, t in coord._ticklabels.text.items() if t},
                  "| axislabel", repr(coord.get_axislabel()), coord.get_axislabel_position())
