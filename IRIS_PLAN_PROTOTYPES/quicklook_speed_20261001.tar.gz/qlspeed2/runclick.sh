#!/bin/sh
# Interleave every tree run by run: round r goes through the configurations forward, round r+1 backward.
Q=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/qlspeed2
ROUNDS=${ROUNDS:-4}
TREES="3e1e767 00f222e dd3c453 a06a251 20f6a9d 0998867 75a2bbd 784ff92 ce3d36a 280be13"
OFF="784ff92 ce3d36a 280be13"
CONFIGS=""
for t in $TREES; do
  CONFIGS="$CONFIGS $t:click:on"
  case " $OFF " in *" $t "*) CONFIGS="$CONFIGS $t:click:off";; esac
done
REV=$(for c in $CONFIGS; do echo $c; done | tail -r | tr '\n' ' ')
r=${START:-0}
while [ $r -lt $ROUNDS ]; do
  if [ $((r % 2)) -eq 0 ]; then LIST=$CONFIGS; else LIST=$REV; fi
  for c in $LIST; do
    t=${c%%:*}; rest=${c#*:}; m=${rest%%:*}; a=${rest#*:}
    out="$Q/outclick/r${r}_${t}_${m}_${a}.json"
    [ -f "$out" ] && continue
    echo "$(date +%T) round $r $t $m $a load $(sysctl -n vm.loadavg)"
    "$Q/run1.sh" "$Q/trees/$t" "$m" "$a" "$out" 2>&1 | grep -E "ok,|Error|error|Traceback|assert" | head -5
  done
  r=$((r + 1))
done
echo "$(date +%T) done"
