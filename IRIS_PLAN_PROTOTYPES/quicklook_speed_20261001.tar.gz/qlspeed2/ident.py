import os, sys, tempfile
sys.path.insert(0, "/Users/nabil/Git/glue-solar-wp10-m0-quicklook-speed")
import numpy as np
import glue_solar
print(glue_solar.__file__)
from glue_solar import glue_patches as gp
from glue_solar.conftest import _header, startobs, find_irispy_test_file
import glue_solar.conftest as cf
from glue_solar.sources.loaders.iris import image_data, raster_data
from glue.core import Data
from glue_qt.app.application import GlueApplication
from glue_qt.viewers.image import ImageViewer
from glue_qt.utils import get_qapp
from irispy.data.test import get_test_data_filenames
from astropy.wcs import WCS

glue_solar.setup()
qapp = get_qapp()
files = get_test_data_filenames()
SNS = "iris_l2_20210905_001833_3620258102_{}.fits"
sns_sji = image_data(find_irispy_test_file(files, SNS.format("SJI_1400_t000")))
[sns_raster] = raster_data([find_irispy_test_file(files, SNS.format("raster_t000_r00000"))], ["Si IV 1403"])
[scan] = raster_data([find_irispy_test_file(files, "iris_l2_20140329_140938_3860258481_raster_t000_r00000.fits")], ["C II 1336"])

tmp = tempfile.mkdtemp()
def rolled(angle):
    src = cf._write_image.__code__
    path = os.path.join(tmp, f"iris_l2_20250328_225628_3400109360_SJI_1400_t000_{angle}.fits")
    h = _header("SJI", "3400109360", startobs("20250328", "225628"), TDESC1="SJI_1400", TWAVE1=1400.0, NWIN=1)
    # conftest's writer with another roll
    orig = np.deg2rad
    cf.np.deg2rad = lambda x: orig(angle)
    try:
        cf._write_image(path, h)
    finally:
        cf.np.deg2rad = orig
    return image_data(path)

w = WCS(naxis=2); w.wcs.ctype = ["HPLN-TAN", "HPLT-TAN"]; w.wcs.cunit = ["arcsec", "arcsec"]; w.wcs.cdelt = [0.6, 0.6]; w.wcs.crpix = [25, 30]; w.wcs.crval = [100, -200]
plain_map = Data(label="map", flux=np.random.default_rng(0).random((60, 50)), coords=w)
no_wcs = Data(label="nowcs", flux=np.random.default_rng(1).random((8, 40, 50)))

cases = {
    "sji": (sns_sji, 2, 1, [("slices", (5, 0, 0)), ("swap",), ("slices", (6, 0, 0))]),
    "sji_roll30": (rolled(30), 2, 1, [("slices", (1, 0, 0)), ("swap",), ("slices", (2, 0, 0))]),
    "sji_roll60": (rolled(60), 2, 1, [("slices", (1, 0, 0)), ("swap",), ("slices", (2, 0, 0))]),
    "raster_map": (scan, 0, 1, [("slices", (0, 0, 8)), ("swap",), ("slices", (0, 0, 9))]),
    "spectrogram": (scan, 2, 1, [("slices", (3, 0, 0)), ("swap",), ("slices", (4, 0, 0))]),
    "lambda_step": (scan, 2, 0, [("slices", (0, 50, 0)), ("swap",), ("slices", (0, 51, 0))]),
    "sns_map": (sns_raster, 0, 1, [("slices", (0, 0, 5)), ("swap",), ("slices", (0, 0, 6))]),
    "lambda_time": (sns_raster, 2, 0, [("slices", (0, 20, 0)), ("swap",), ("slices", (0, 21, 0))]),
    "plain_map": (plain_map, 1, 0, [("swap",)]),
    "no_wcs": (no_wcs, 2, 1, [("slices", (3, 0, 0)), ("swap",), ("slices", (4, 0, 0))]),
}

print({k: v[0].shape for k, v in cases.items()})
app = GlueApplication()
datasets = []
for d, *_ in cases.values():
    if d not in datasets:
        datasets.append(d)
app.data_collection.extend(datasets)

def record(viewer):
    canvas = viewer.figure.canvas
    canvas.draw()
    rgba = bytes(canvas.buffer_rgba())
    renderer = canvas.get_renderer()
    labels = []
    for coords in viewer.axes._all_coords:
        for coord in coords:
            al = coord._axislabels
            labels.append((coord.get_axislabel(), tuple(coord.get_axislabel_position()), al.get_visible(),
                           tuple(np.round(al.get_position(), 6)), tuple(np.round(al.get_window_extent(renderer).bounds, 6))))
    return rgba, labels

def make(data, x, y, patched):
    ImageViewer.update_x_axislabel, ImageViewer.update_y_axislabel = (
        (gp.update_x_axislabel, gp.update_y_axislabel) if patched else gp._original_update_axislabels)
    v = app.new_data_viewer(ImageViewer, data=data)
    v.state.x_att, v.state.y_att = data.pixel_component_ids[x], data.pixel_component_ids[y]
    return v

def step(v, s):
    if s[0] == "slices":
        v.state.slices = s[1]
    else:
        v.state.x_att, v.state.y_att = v.state.y_att, v.state.x_att

for name, (data, x, y, steps) in cases.items():
    a, b = make(data, x, y, False), make(data, x, y, True)
    results = []
    for i, s in enumerate([None] + steps):
        if s:
            step(a, s); step(b, s)
        try:
            ra = record(a)
        except Exception as e:
            ra = (repr(e), [])
        try:
            rb = record(b)
        except Exception as e:
            rb = (repr(e), [])
        if isinstance(ra[0], str) or isinstance(rb[0], str):
            print("   ", name, s, "errors", ra[0] if isinstance(ra[0], str) else "-", rb[0] if isinstance(rb[0], str) else "-")
        same_rgba = ra[0] == rb[0]
        visible_a = [l for l in ra[1] if l[2] and l[1] and l[1] != ('',)]
        visible_b = [l for l in rb[1] if l[2] and l[1] and l[1] != ('',)]
        diffs = [(la, lb) for la, lb in zip(ra[1], rb[1]) if la != lb]
        results.append((s, same_rgba, len(diffs)))
        if not same_rgba or diffs:
            for la, lb in zip(ra[1], rb[1]):
                if la != lb:
                    print("   ", name, s, "\n      orig", la, "\n      patc", lb)
    print(name, results, flush=True)
    a.close(warn=False); b.close(warn=False)
