import sys, time
sys.path.insert(0, "/Users/nabil/Git/glue-solar-wp10-m0-quicklook-speed")
import glue_solar
from glue_solar import glue_patches as gp
for name in ("needs_inverse_workaround", "needs_pv_slice_workaround", "needs_pixel_point_workaround", "needs_crosshair_workaround", "needs_axis_label_workaround"):
    f = getattr(gp, name)
    f()
    t = time.perf_counter()
    for _ in range(20):
        f()
    print(name, round((time.perf_counter() - t) / 20 * 1000, 2), "ms")
