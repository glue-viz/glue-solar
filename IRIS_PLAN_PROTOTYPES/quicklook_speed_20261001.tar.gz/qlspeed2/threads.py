import os, sys, threading, time, traceback
sys.path.insert(0, "/Users/nabil/Git/glue-solar-wp10-m0-quicklook-speed")
import numpy as np
from glue_solar.conftest import find_irispy_test_file
from glue_solar.sources.loaders import iris
from irispy.data.test import get_test_data_filenames
path = find_irispy_test_file(get_test_data_filenames(), "iris_l2_20210905_001833_3620258102_raster_t000_r00000.fits")
wcs = iris.raster_data([path], ["Si IV 1403"])[0].coords
pixels = [np.arange(1000.0) % n for n in wcs.pixel_shape]
mode = sys.argv[1]
N = int(sys.argv[2])
def pixels_of(i):
    return [p + i % 300 * 1e-3 for p in pixels] if mode == "vary" else pixels
done = threading.Event()
counts = [0]
def convert():
    i = 0
    while not done.is_set():
        wcs.pixel_to_world_values(*pixels_of(i))
        wcs.axis_correlation_matrix
        i += 1
    counts[0] = i
t0 = time.perf_counter()
th = threading.Thread(target=convert); th.start()
for i in range(N):
    wcs.pixel_to_world_values(*pixels_of(i))
done.set(); th.join()
print(mode, N, "main", round(time.perf_counter() - t0, 2), "s; thread iterations", counts[0])
t0 = time.perf_counter()
for i in range(N):
    wcs.pixel_to_world_values(*pixels_of(i))
print(mode, "single-thread", round(time.perf_counter() - t0, 2), "s")
