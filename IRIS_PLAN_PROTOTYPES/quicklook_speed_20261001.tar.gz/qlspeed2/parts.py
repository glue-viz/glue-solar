import sys, time
sys.path.insert(0, "/Users/nabil/Git/glue-solar-wp10-m0-quicklook-speed")
import glue_solar
from matplotlib.figure import Figure
from astropy.visualization.wcsaxes import WCSAxes
from astropy.wcs import WCS
def t(f, n=50):
    f(); s = time.perf_counter()
    for _ in range(n): f()
    return round((time.perf_counter() - s) / n * 1000, 3)
print("WCS", t(lambda: WCS(naxis=2)))
print("Figure", t(lambda: Figure()))
w = WCS(naxis=2)
print("WCSAxes", t(lambda: WCSAxes(Figure(), [0, 0, 1, 1], wcs=w)))
ax = WCSAxes(Figure(), [0, 0, 1, 1], wcs=w)
print("set_xlabel", t(lambda: ax.set_xlabel("x")))
from unittest.mock import MagicMock
print("MagicMock", t(lambda: MagicMock()))
