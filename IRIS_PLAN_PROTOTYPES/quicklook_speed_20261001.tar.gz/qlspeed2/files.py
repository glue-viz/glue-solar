import sys
sys.path.insert(0, "/Users/nabil/Git/glue-solar-wp10-m0-quicklook-speed")
import glue_solar; print(glue_solar.__file__)
from irispy.data.test import get_test_data_filenames
from astropy.io import fits
for f in sorted(get_test_data_filenames()):
    try:
        h = fits.getheader(f)
        print(f.name, h.get("SAT_ROT"), h.get("OBS_DESC"), h.get("NAXIS"))
    except Exception as e:
        print(f.name, e)
