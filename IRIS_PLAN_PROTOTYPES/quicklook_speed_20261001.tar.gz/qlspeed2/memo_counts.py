import sys
sys.path.insert(0, "/Users/nabil/Git/glue-solar-wp10-m0-quicklook-speed")
import numpy as np
import glue_solar
print(glue_solar.__file__)
from glue_solar.conftest import find_irispy_test_file
from glue_solar.sources.loaders import iris
from glue_solar.sources.loaders.iris import WCS_LOCK, image_data, raster_data
from glue_solar.quicklook import quicklook
from glue_solar.tests.helpers import select_point
from glue_qt.app.application import GlueApplication
from glue_qt.utils import get_qapp
from irispy.data.test import get_test_data_filenames

memo = iris._GlueWCS.pixel_to_world_values
def original(self, *pixel_arrays):
    with WCS_LOCK:
        values = list(self._wcs.pixel_to_world_values(*pixel_arrays))
    for i, to_arcsec, _, full_circle in self._helioprojective:
        values[i] = np.asarray(values[i])
        if full_circle is not None:
            values[i] = (values[i] + full_circle / 2) % full_circle - full_circle / 2
        values[i] = values[i] * to_arcsec
    return tuple(values)

glue_solar.setup()
qapp = get_qapp()
files = get_test_data_filenames()
SNS = "iris_l2_20210905_001833_3620258102_{}.fits"
for name, method in (("without memo", original), ("with memo", memo)):
    iris._GlueWCS.pixel_to_world_values = method
    sji = image_data(find_irispy_test_file(files, SNS.format("SJI_1400_t000")))
    [raster] = raster_data([find_irispy_test_file(files, SNS.format("raster_t000_r00000"))], ["Si IV 1403"])
    n = {"calls": 0}
    for d in (sji, raster):
        inner = d.coords._wcs
        conv = inner.pixel_to_world_values
        inner.pixel_to_world_values = lambda *p, _c=conv: (n.__setitem__("calls", n["calls"] + 1), _c(*p))[1]
    app = GlueApplication()
    viewers = quicklook(app, [raster, sji])
    [s] = viewers["sji"]
    qapp.processEvents()
    out = []
    n["calls"] = 0; s.state.slices = (20, 0, 0); qapp.processEvents(); out.append(("SJI frame step (state change + its draw)", n["calls"]))
    n["calls"] = 0; s.figure.canvas.draw(); out.append(("SJI unchanged redraw", n["calls"]))
    panels = [viewers[r] for r in ("map", "spectrogram", "wavelength")]
    n["calls"] = 0
    for v in panels: v.figure.canvas.draw()
    out.append(("three raster panels, unchanged redraw", n["calls"]))
    n["calls"] = 0; select_point(viewers["map"], 100, 20); qapp.processEvents(); out.append(("map click (point move), all panels", n["calls"]))
    print(name, out)
    app.close()
