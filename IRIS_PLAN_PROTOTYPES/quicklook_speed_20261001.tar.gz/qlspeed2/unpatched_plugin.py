# pytest plugin: keep glue-qt's own label updates, as without the workaround
import glue_solar.glue_patches as gp
from glue_qt.viewers.image import ImageViewer
ImageViewer.update_x_axislabel, ImageViewer.update_y_axislabel = gp._original_update_axislabels
