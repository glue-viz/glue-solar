#!/bin/sh
# Interleave old HEAD 280be13 and the fixed HEAD 4f2f0dc, quicklook mode, axes on.
Q=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/qlspeed2
O=$Q/fixmut/remeasure; mkdir -p $O
r=0
while [ $r -lt ${ROUNDS:-4} ]; do
  if [ $((r % 2)) -eq 0 ]; then L="280be13 4f2f0dc"; else L="4f2f0dc 280be13"; fi
  for t in $L; do
    echo "$(date +%T) r$r $t load $(sysctl -n vm.loadavg)"
    "$Q/run1.sh" "$Q/trees/$t" ql on "$O/r${r}_${t}_ql_on.json" 2>&1 | grep -E "ok,|Error|Traceback|assert" | head -3
  done
  r=$((r + 1))
done
