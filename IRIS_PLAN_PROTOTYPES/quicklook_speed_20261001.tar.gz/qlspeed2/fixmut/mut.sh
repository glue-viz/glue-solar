#!/bin/sh
# mut.sh NAME FILE OLD NEW TESTFILE [pytest args]: copy the worktree, replace OLD by NEW once in FILE, run the tests
Q=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/qlspeed2
W=/Users/nabil/Git/glue-solar-wp10-m0-quicklook-speed
N=$1; F=$2; OLD=$3; NEW=$4; T=$5; shift 5
D=$Q/fixmut/$N
rm -rf "$D"; mkdir -p "$D"; cp -R "$W/glue_solar" "$D/"
~/mamba/envs/iris-plan/bin/python -c "
import sys; p, old, new = sys.argv[1:]
s = open(p).read(); assert s.count(old) == 1, ('matches', s.count(old)); open(p, 'w').write(s.replace(old, new))
" "$D/$F" "$OLD" "$NEW" || exit 1
cd "$Q" && env HOME="$(mktemp -d)" ~/mamba/envs/iris-plan/bin/python /Users/nabil/Git/glue-solar/IRIS_PLAN_PROTOTYPES/run_checks.py "$D" "$D/glue_solar/tests/$T" "$@" 2>&1 | grep -v "Warning\|^  warnings" | grep -E "^E |passed|failed|error" | head -12
