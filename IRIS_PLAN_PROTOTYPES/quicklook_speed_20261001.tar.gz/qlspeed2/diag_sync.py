"""Time inside the coordinator (outermost calls, with the glue work they trigger) per synced spectrogram step (TREE)."""
import os, statistics, sys, time
TREE = sys.argv[1]
sys.path.insert(0, TREE)
import glue_solar
assert glue_solar.__file__.startswith(TREE)
from glue_qt.app import GlueApplication
from glue_qt.utils import get_qapp
from qtpy import QtWidgets
import glue_solar.quicklook as ql
from glue_solar.sources.loaders.iris import image_data, raster_data
perf = time.perf_counter
INSIDE = [0.0, 0]
for name in ("_update", "_move_point", "_subset_changed", "_apply_point"):
    orig = getattr(ql.Coordinator, name)
    def f(self, *a, _o=orig, **k):
        if INSIDE[1]:
            return _o(self, *a, **k)
        INSIDE[1] = 1
        t = perf()
        try:
            return _o(self, *a, **k)
        finally:
            INSIDE[0] += perf() - t
            INSIDE[1] = 0
    setattr(ql.Coordinator, name, f)
D = "/Users/nabil/DATA/IRIS/"
[raster] = raster_data([D + "2dd2d12db374b3466aa27a65bec235d3-iris_l2_20130902_163935_4000255147_raster/iris_l2_20130902_163935_4000255147_raster_t000_r00000.fits"], ["Si IV 1403"])
sji = image_data(D + "534d789bb0a2821fb2b78eb36d1d6753-iris_l2_20130902_163935_4000255147_SJI_1400_t000.fits.gz")
qapp = get_qapp(); app = GlueApplication(); app.resize(1600, 1000); app.show()
v = ql.quicklook(app, [raster, sji])
def pump(sec):
    end = perf() + sec
    while perf() < end:
        qapp.processEvents(); time.sleep(0.002)
pump(2)
qs = v["spectrogram"].options_widget().slice_helper._sliders[0].findChild(QtWidgets.QSlider, "value_slice_center")
res = []
for base in (1, 800, 1599):
    qs.setValue(base); pump(0.6)
    for k in range(4):
        INSIDE[0] = 0.0
        qs.triggerAction(QtWidgets.QAbstractSlider.SliderSingleStepAdd if base != 1599 else QtWidgets.QAbstractSlider.SliderSingleStepSub)
        pump(0.5)
        if k:
            res.append(INSIDE[0])
print(f"coordinator per synced step: median {statistics.median(res)*1e3:.1f} ms (min {min(res)*1e3:.1f}, max {max(res)*1e3:.1f}), n={len(res)}")
sys.stdout.flush()
os._exit(0)
