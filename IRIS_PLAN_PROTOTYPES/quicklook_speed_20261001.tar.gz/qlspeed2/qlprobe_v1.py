"""
Wall-clock probe for wp10-m0-quicklook-speed on full 4000255147 (Si IV 1403 + SJI 1400), offscreen.

    python qlprobe.py TREE MODE AXES OUT.json

MODE ql: the quicklook in a 1600x1000 app (quicklook() time, unchanged redraws, map contrast, map
wavelength step, lambda-time slit step, SJI frame step, synced spectrogram exposure steps at exposures
1, 800 and 1599, Pixel clicks on the map). MODE image: one stock Image viewer of the Si IV window at
glue's default size, stepping its exposure slider (wp10_slider_probe's 'image step').
AXES on/off sets glue_solar's SOLAR_SHOW_AXES before any viewer opens (off needs the Hide axes commit).

Each action is a real Qt slider step or mouse click; after it the probe processes events until nothing
is pending for 0.1 s (image canvases, the coordinator's timer, the spectrum's worker) and reports, from
the canvases' own draw timestamps: sync (the action call), images (the last image-panel draw ends),
spectrum (the last spectrum draw ends), idle (all quiet), Agg draws per canvas and WCSAxes tick updates.
Steps move monotonically to fresh indices so no memo is favoured by revisiting a slice.
"""

import json
import os
import resource
import sys
import time

TREE, MODE, AXES, OUT = sys.argv[1:5]
sys.path.insert(0, TREE)

import glue_solar  # noqa: E402

assert glue_solar.__file__.startswith(TREE), glue_solar.__file__

from astropy.visualization.wcsaxes.coordinate_helpers import CoordinateHelper  # noqa: E402
from glue.config import settings  # noqa: E402
from glue_qt.app import GlueApplication  # noqa: E402
from glue_qt.utils import get_qapp  # noqa: E402
from glue_qt.viewers.image import ImageViewer  # noqa: E402
from qtpy import QtCore, QtWidgets  # noqa: E402
from qtpy.QtTest import QTest  # noqa: E402

from glue_solar.sources.loaders.iris import image_data, raster_data  # noqa: E402

D = "/Users/nabil/DATA/IRIS/"
RASTER = (D + "2dd2d12db374b3466aa27a65bec235d3-iris_l2_20130902_163935_4000255147_raster/"
          "iris_l2_20130902_163935_4000255147_raster_t000_r00000.fits")
SJI = D + "534d789bb0a2821fb2b78eb36d1d6753-iris_l2_20130902_163935_4000255147_SJI_1400_t000.fits.gz"
perf = time.perf_counter
qapp = get_qapp()
result = {"tree": TREE, "mode": MODE, "axes": AXES, "glue_solar": glue_solar.__file__, "samples": {}, "counts": {}}

# instrumentation: Agg draw spans per canvas, tick updates
DRAWS = []  # (canvas id, start, end)
TICKS = [0]
_update_ticks = CoordinateHelper._update_ticks


def counted(self):
    TICKS[0] += 1
    return _update_ticks(self)


CoordinateHelper._update_ticks = counted


def instrument(canvas):
    cls = type(canvas)
    if getattr(cls, "_probe", False):
        return
    draw = cls.draw

    def timed(self, *args, **kwargs):
        start = perf()
        try:
            return draw(self, *args, **kwargs)
        finally:
            DRAWS.append((id(self), start, perf()))

    cls.draw, cls._probe = timed, True


t0 = perf()
[raster] = raster_data([RASTER], ["Si IV 1403"])
sji = image_data(SJI) if MODE == "ql" else None
result["load_s"] = perf() - t0

app = GlueApplication()  # loads the plugins, so glue_solar.setup() runs once
if AXES == "off":
    assert hasattr(settings, "SOLAR_SHOW_AXES"), "this tree has no Hide axes"
    settings.SOLAR_SHOW_AXES = False
bad = [m.__file__ for n, m in list(sys.modules.items())
       if n.startswith("glue_solar") and getattr(m, "__file__", None) and not m.__file__.startswith(TREE)]
assert not bad, bad
from glue.config import colormaps  # noqa: E402

result["colormaps"] = len(colormaps.members)


def busy(images, spectrum=None, layers=()):
    for canvas in images + ([spectrum] if spectrum is not None else []):
        if getattr(canvas, "_draw_pending", False):
            return True
    for layer in layers:
        if getattr(layer, "is_computing", False):
            return True
        worker = getattr(layer, "_worker", None)
        if worker is not None and not worker.work_queue.empty():
            return True
    coord = getattr(app.data_collection, "_solar_coordinator", None)
    return coord is not None and coord._timer.isActive()


def settle(timeout=30.0):
    start, quiet = perf(), None
    while perf() - start < timeout:
        qapp.processEvents()
        if busy(*BUSY):
            quiet = None
        else:
            quiet = quiet or perf()
            if perf() - quiet > 0.1:
                return quiet
        time.sleep(0.001)
    raise RuntimeError("not idle after 30 s")


def measure(name, act, record=True):
    """Run ``act`` and settle; append its timings to the samples of ``name``."""
    DRAWS.clear()
    TICKS[0] = 0
    start = perf()
    act()
    sync = perf()
    ticks_sync = TICKS[0]
    idle = settle()
    draws = {}
    last = {}
    for cid, _s, end in DRAWS:
        role = NAMES.get(cid, "other")
        draws[role] = draws.get(role, 0) + 1
        last[role] = max(last.get(role, 0), end)
    images = max([sync] + [last[r] for r in last if r not in ("spectrum", "other")])
    sample = {
        "sync": sync - start,
        "images": images - start,
        "spectrum": (last["spectrum"] - start) if "spectrum" in last else None,
        "idle": idle - start,
        "draws": draws,
        "ticks": TICKS[0],
        "ticks_sync": ticks_sync,
    }
    if record:
        result["samples"].setdefault(name, []).append(sample)
    return sample


def slider(viewer, axis):
    helper = viewer.options_widget().slice_helper
    return helper._sliders[axis].findChild(QtWidgets.QSlider, "value_slice_center")


def stepper(viewer, axis, add=True):
    qs = slider(viewer, axis)
    action = QtWidgets.QAbstractSlider.SliderSingleStepAdd if add else QtWidgets.QAbstractSlider.SliderSingleStepSub
    return lambda: qs.triggerAction(action)


def run(name, act, warm=2, n=9):
    for _ in range(warm):
        measure(name, act, record=False)
    for _ in range(n):
        measure(name, act)


def redraw(canvas):
    return lambda: canvas.draw()


NAMES = {}
if MODE == "image":
    app.data_collection.append(raster)
    viewer = app.new_data_viewer(ImageViewer, data=raster)
    app.show()
    for _ in range(5):
        qapp.processEvents()
        time.sleep(0.1)
    canvas = viewer.figure.canvas
    instrument(canvas)
    NAMES[id(canvas)] = "image"
    BUSY = ([canvas],)
    settle()
    result["canvas"] = [canvas.width(), canvas.height()]
    result["axison"] = {"image": viewer.axes.axison}
    shown = {viewer.state.x_att.axis, viewer.state.y_att.axis}
    axis = next(i for i in range(raster.ndim) if i not in shown)
    qs = slider(viewer, axis)
    qs.setValue(raster.shape[axis] // 2)
    settle()
    result["image_axis"] = axis
    run("image_step", stepper(viewer, axis), warm=3, n=15)
    run("image_redraw", redraw(canvas), warm=2, n=9)
else:
    from glue_solar.quicklook import quicklook

    app.resize(1600, 1000)
    app.show()
    for _ in range(5):
        qapp.processEvents()
        time.sleep(0.05)
    t0 = perf()
    viewers = quicklook(app, [raster, sji])
    t1 = perf()
    panels = {"map": viewers["map"], "spectrogram": viewers["spectrogram"], "wavelength": viewers["wavelength"],
              "sji": viewers["sji"][0], "spectrum": viewers["spectrum"]}
    for role, v in panels.items():
        instrument(v.figure.canvas)
        NAMES[id(v.figure.canvas)] = role
    images = [panels[r].figure.canvas for r in ("map", "spectrogram", "wavelength", "sji")]
    spectrum_layers = viewers["spectrum"].layers
    BUSY = (images, panels["spectrum"].figure.canvas, spectrum_layers)
    t2 = settle(60)
    result["quicklook_s"] = t1 - t0
    result["open_idle_s"] = t2 - t0
    end = perf() + 1.5  # the canvases' resize timers
    while perf() < end:
        qapp.processEvents()
        time.sleep(0.005)
    settle()
    result["canvas"] = {r: [v.figure.canvas.width(), v.figure.canvas.height()] for r, v in panels.items()}
    result["axison"] = {r: panels[r].axes.axison for r in ("map", "spectrogram", "wavelength", "sji")}

    for role in ("map", "spectrogram", "wavelength", "sji"):
        run(f"redraw_{role}", redraw(panels[role].figure.canvas))

    layer = panels["map"].state.layers[0]
    flip = [0]

    def contrast():
        flip[0] += 1
        layer.v_max *= 1.01 if flip[0] % 2 else 1 / 1.01

    run("contrast_map", contrast)
    run("map_wl_step", stepper(panels["map"], 2))  # the map shows exposure x slit; its slider is wavelength
    run("lt_slit_step", stepper(panels["wavelength"], 1))  # lambda-time shows wavelength x exposure
    run("sji_step", stepper(panels["sji"], 0))
    spectrogram = panels["spectrogram"]
    qs = slider(spectrogram, 0)
    last = raster.shape[0] - 1
    for base in (1, 800, last):
        qs.setValue(base)
        settle()
        run(f"synced_step_{base}", stepper(spectrogram, 0, add=base != last), warm=1, n=3)

    # Pixel clicks on the map at fresh exposures and slits
    canvas = panels["map"].figure.canvas
    clicks = iter([(300 + 97 * k, 60 + 29 * k) for k in range(12)])
    missed = []

    def click():
        x, y = next(clicks)
        xs, ys = panels["map"].axes.transData.transform((x, y))
        dpr = canvas.device_pixel_ratio
        pos = QtCore.QPoint(int(round(xs / dpr)), int(round(canvas.height() - ys / dpr)))
        QTest.mousePress(canvas, QtCore.Qt.LeftButton, QtCore.Qt.NoModifier, pos)
        QTest.mouseRelease(canvas, QtCore.Qt.LeftButton, QtCore.Qt.NoModifier, pos)
        click.target = (x, y)

    for k in range(11):
        measure("click", click, record=k >= 2)
        exposure = spectrogram.state.slices[0]
        if abs(exposure - click.target[0]) > 4:
            missed.append((click.target, exposure))
    result["click_missed"] = missed

result["maxrss_mb"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1e6
with open(OUT, "w") as f:
    json.dump(result, f)
print(f"{os.path.basename(TREE)} {MODE} {AXES}: ok, maxrss {result['maxrss_mb']:.0f} MB", flush=True)
os._exit(0)  # no teardown: glue would write QSettings on close
