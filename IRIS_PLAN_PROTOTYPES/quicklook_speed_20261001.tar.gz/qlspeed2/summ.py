import json, sys, statistics as st
for p in sys.argv[1:]:
    r = json.load(open(p))
    print(p, {k: r.get(k) for k in ("load_s", "quicklook_s", "open_idle_s", "maxrss_mb", "colormaps", "canvas", "axison", "click_missed")})
    for name, ss in r["samples"].items():
        f = lambda k: st.median([s[k] for s in ss if s[k] is not None]) * 1e3 if any(s[k] is not None for s in ss) else float("nan")
        dr = {}
        for s in ss:
            for k, v in s["draws"].items():
                dr.setdefault(k, []).append(v)
        print(f"  {name:18s} n={len(ss):2d} sync {f('sync'):7.1f} images {f('images'):7.1f} spectrum {f('spectrum'):7.1f} idle {f('idle'):7.1f} ms; "
              f"ticks {st.median([s['ticks'] for s in ss]):.0f} (sync {st.median([s['ticks_sync'] for s in ss]):.0f}); draws {{{', '.join(f'{k}: {st.median(v):g}' for k, v in dr.items())}}}")
