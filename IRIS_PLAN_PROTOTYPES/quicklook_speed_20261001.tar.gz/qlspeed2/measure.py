import sys
sys.path.insert(0, "/Users/nabil/Git/glue-solar-wp10-m0-quicklook-speed")
from collections import Counter
import glue_solar
print(glue_solar.__file__)
from glue_solar import glue_patches as gp
from glue_solar.conftest import find_irispy_test_file
from glue_solar.sources.loaders.iris import image_data, raster_data
from glue_solar.quicklook import quicklook
from glue_qt.app.application import GlueApplication
from glue_qt.viewers.image import ImageViewer
from glue_qt.utils import get_qapp
from irispy.data.test import get_test_data_filenames
from astropy.visualization.wcsaxes import WCSAxes
from astropy.visualization.wcsaxes.coordinate_helpers import CoordinateHelper

glue_solar.setup()
qapp = get_qapp()
files = get_test_data_filenames()
SNS = "iris_l2_20210905_001833_3620258102_{}.fits"
calls = Counter()
for name in ("set_xlabel", "set_ylabel"):
    orig = getattr(WCSAxes, name)
    setattr(WCSAxes, name, lambda self, *a, _o=orig, _n=name, **k: (calls.update([_n]), _o(self, *a, **k))[1])
ut = CoordinateHelper._update_ticks
CoordinateHelper._update_ticks = lambda self: (calls.update(["_update_ticks"]), ut(self))[1]
sal = CoordinateHelper.set_axislabel
CoordinateHelper.set_axislabel = lambda self, *a, **k: (calls.update(["set_axislabel"]), sal(self, *a, **k))[1]

def run(patched, validator):
    ImageViewer.update_x_axislabel, ImageViewer.update_y_axislabel = (
        (gp.update_x_axislabel, gp.update_y_axislabel) if patched else gp._original_update_axislabels)
    sji = image_data(find_irispy_test_file(files, SNS.format("SJI_1400_t000")))
    [raster] = raster_data([find_irispy_test_file(files, SNS.format("raster_t000_r00000"))], ["Si IV 1403"])
    app = GlueApplication()
    viewers = quicklook(app, [raster, sji])
    if not validator:
        for v in app.viewers[-1]:
            tool = getattr(v, "toolbar", None) and v.toolbar.tools.get("solar:frame_time")
            if tool and hasattr(tool, "_keep_labels"):
                for prop, keep in tool._keep_labels.items():
                    v.state.remove_callback(prop, keep)
    [s] = viewers["sji"]
    w = viewers["wavelength"]
    out = {}
    for label, viewer, change in (
        ("SJI frame step", s, lambda i: setattr(s.state, "slices", (10 + i, 0, 0))),
        ("lambda-time slit step", w, lambda i: setattr(w.state, "slices", (w.state.slices[0], 10 + i, w.state.slices[2]))),
    ):
        for v in app.viewers[-1]:
            if hasattr(v, "axes"):
                v.figure.canvas.draw()
        qapp.processEvents()
        rows = []
        for i in range(3):
            calls.clear()
            change(i)
            setphase = dict(calls)
            calls.clear()
            qapp.processEvents()
            rows.append((setphase, dict(calls)))
        out[label] = rows[-1]
    app.close()
    return out

for patched in (False, True):
    for validator in (False,):
        r = run(patched, validator)
        print(f"patch={patched} validator={validator}")
        for k, (setp, draw) in r.items():
            print(f"   {k}: state change {setp} | the draws it starts {draw}")
