import sys
sys.path.insert(0, "/Users/nabil/Git/glue-solar-wp10-m0-quicklook-speed")
from collections import Counter
import numpy as np
import glue_solar
print(glue_solar.__file__)
from glue_solar.conftest import find_irispy_test_file
from glue_solar.sources.loaders.iris import image_data, raster_data
from glue_solar.quicklook import quicklook
from glue_qt.app.application import GlueApplication
from glue_qt.utils import get_qapp
from irispy.data.test import get_test_data_filenames

glue_solar.setup()
qapp = get_qapp()
files = get_test_data_filenames()
SNS = "iris_l2_20210905_001833_3620258102_{}.fits"
sji = image_data(find_irispy_test_file(files, SNS.format("SJI_1400_t000")))
[raster] = raster_data([find_irispy_test_file(files, SNS.format("raster_t000_r00000"))], ["Si IV 1403"])
log = []
for d in (sji, raster):
    inner = d.coords._wcs
    orig = inner.pixel_to_world_values
    def rec(*p, _o=orig, _d=d.label):
        arrs = [np.asarray(a) for a in p]
        log.append((_d, tuple(a.shape for a in arrs), tuple(a.dtype.str for a in arrs), hash(tuple(a.tobytes() for a in arrs))))
        return _o(*p)
    try:
        inner.pixel_to_world_values = rec
    except AttributeError:
        print("cannot set on", type(inner))
app = GlueApplication()
viewers = quicklook(app, [raster, sji])
qapp.processEvents()
for role in ("map", "spectrogram", "wavelength"):
    v = viewers[role]
    for n in range(2):
        log.clear(); v.figure.canvas.draw()
        keys = Counter(l[1:] for l in log)
        sizes = sorted({int(np.prod(l[1][0])) for l in log})
        print(role, "draw", n, "calls", len(log), "distinct", len(keys), "sizes", sizes, "dtypes", {l[2] for l in log})
[s] = viewers["sji"]
for n in range(2):
    log.clear(); s.figure.canvas.draw()
    keys = Counter(l[1:] for l in log)
    print("sji draw", n, "calls", len(log), "distinct", len(keys), "sizes", sorted({int(np.prod(l[1][0])) for l in log}))
log.clear(); s.state.slices = (11, 0, 0); qapp.processEvents(); s.figure.canvas.draw()
print("sji step+draw calls", len(log), "distinct", len(Counter(l[1:] for l in log)))
# whole-cube world coordinates through glue
log.clear(); w = raster[raster.world_component_ids[0]]
print("world component calls", len(log), "sizes", sorted({int(np.prod(l[1][0])) for l in log}))
