import os, sys, threading, time
sys.path.insert(0, "/Users/nabil/Git/glue-solar-wp10-m0-quicklook-speed")
import numpy as np
from glue_solar.conftest import find_irispy_test_file
from glue_solar.sources.loaders import iris
from glue_solar.sources.loaders.iris import WCS_LOCK, _copies, _MEMO_SAMPLES, _MEMO_ENTRIES
from irispy.data.test import get_test_data_filenames

def original(self, *pixel_arrays):
    with WCS_LOCK:
        values = list(self._wcs.pixel_to_world_values(*pixel_arrays))
    for i, to_arcsec, _, full_circle in self._helioprojective:
        values[i] = np.asarray(values[i])
        if full_circle is not None:
            values[i] = (values[i] + full_circle / 2) % full_circle - full_circle / 2
        values[i] = values[i] * to_arcsec
    return tuple(values)

MEMO_LOCK = threading.Lock()
def split(self, *pixel_arrays):
    arrays = [np.asarray(pixel) for pixel in pixel_arrays]
    key = None
    if all(array.dtype.kind in "biuf" and array.size <= _MEMO_SAMPLES for array in arrays):
        key = tuple((type(p), a.dtype.str, a.shape, a.tobytes()) for p, a in zip(pixel_arrays, arrays))
        with MEMO_LOCK:
            cached = self._memo.get(key)
            if cached is not None:
                self._memo.move_to_end(key)
        if cached is not None:
            return _copies(cached)
    values = original(self, *pixel_arrays)
    if key is not None:
        kept = _copies(values)
        with MEMO_LOCK:
            self._memo[key] = kept
            if len(self._memo) > _MEMO_ENTRIES:
                self._memo.popitem(last=False)
    return values

variant = sys.argv[1]
if variant != "current":
    iris._GlueWCS.pixel_to_world_values = {"original": original, "split": split}[variant]
path = find_irispy_test_file(get_test_data_filenames(), "iris_l2_20210905_001833_3620258102_raster_t000_r00000.fits")
wcs = iris.raster_data([path], ["Si IV 1403"])[0].coords
pixels = [np.arange(1000.0) % n for n in wcs.pixel_shape]
mode, N = sys.argv[2], int(sys.argv[3])
def pixels_of(i):
    return [p + i % 300 * 1e-3 for p in pixels] if mode == "vary" else pixels
done = threading.Event(); counts = [0]
def convert():
    i = 0
    while not done.is_set():
        wcs.pixel_to_world_values(*pixels_of(i)); wcs.axis_correlation_matrix; i += 1
    counts[0] = i
t0 = time.perf_counter()
th = threading.Thread(target=convert); th.start()
for i in range(N):
    wcs.pixel_to_world_values(*pixels_of(i))
done.set(); th.join()
print(variant, mode, N, "main", round(time.perf_counter() - t0, 2), "s; thread iterations", counts[0])
