import os, sys, tempfile
sys.path.insert(0, "/Users/nabil/Git/glue-solar-wp10-m0-quicklook-speed")
from glue import config
d = tempfile.mkdtemp(); config.CFG_DIR = d
open(os.path.join(d, "settings.cfg"), "w").write("[main]\nsolar_show_axes = false\n")
import glue_solar; print(glue_solar.__file__)
from glue._settings_helpers import load_settings
load_settings()
print(config.settings.SOLAR_SHOW_AXES)
