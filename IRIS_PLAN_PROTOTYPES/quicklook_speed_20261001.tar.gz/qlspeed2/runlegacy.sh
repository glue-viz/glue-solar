#!/bin/sh
# The plan's own probes (copies) on main and the branch head, interleaved ABAB.
Q=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/qlspeed2
SIIV=/Users/nabil/DATA/IRIS/2dd2d12db374b3466aa27a65bec235d3-iris_l2_20130902_163935_4000255147_raster/iris_l2_20130902_163935_4000255147_raster_t000_r00000.fits
mkdir -p "$Q/legacy"
r=0
while [ $r -lt ${ROUNDS:-4} ]; do
  if [ $((r % 2)) -eq 0 ]; then LIST="3e1e767 280be13"; else LIST="280be13 3e1e767"; fi
  for t in $LIST; do
    T="$Q/trees/$t"
    for probe in ql sync slider; do
      out="$Q/legacy/r${r}_${t}_${probe}.log"
      [ -s "$out" ] && continue
      H=$(mktemp -d "$Q/home.XXXXXX"); mkdir -p "$H/cache" "$H/config" "$H/sunpy"
      echo "$(date +%T) round $r $t $probe load $(sysctl -n vm.loadavg)"
      case $probe in
        ql) set -- "$Q/wp4_quicklook_probe.py" "$T" 4000255147-siiv;;
        sync) set -- "$Q/wp4_time_sync_probe.py" "$T";;
        slider) set -- "$Q/wp10_slider_probe.py" "$SIIV" --window "Si IV 1403" --steps 40;;
      esac
      (cd "$Q" && env HOME="$H" MPLCONFIGDIR="$Q/mplcfg" XDG_CACHE_HOME="$H/cache" XDG_CONFIG_HOME="$H/config" \
        SUNPY_CONFIGDIR="$H/sunpy" QT_QPA_PLATFORM=offscreen MPLBACKEND=agg PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$T" \
        ~/mamba/envs/iris-plan/bin/python -B "$@") > "$out" 2>&1
      rm -rf "$H"
    done
  done
  r=$((r + 1))
done
echo "$(date +%T) done"
