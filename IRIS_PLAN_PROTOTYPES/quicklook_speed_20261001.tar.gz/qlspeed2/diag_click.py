"""Timeline of Pixel clicks on the map: when the spectrum's profile is requested, computed and drawn (TREE first)."""
import statistics
import sys
import threading
import time

TREE = sys.argv[1]
sys.path.insert(0, TREE)
import glue_solar  # noqa: E402

assert glue_solar.__file__.startswith(TREE)
from glue_qt.app import GlueApplication  # noqa: E402
from glue_qt.utils import get_qapp  # noqa: E402
from glue_qt.viewers.profile.layer_artist import QThreadedProfileLayerArtist as A  # noqa: E402
from qtpy import QtCore  # noqa: E402
from qtpy.QtTest import QTest  # noqa: E402

import glue_solar.quicklook as ql  # noqa: E402
from glue_solar.sources.loaders.iris import image_data, raster_data  # noqa: E402

perf = time.perf_counter
EV = []
MAIN = threading.get_ident()


def wrap(cls, name, label):
    orig = getattr(cls, name)

    def f(self, *a, **k):
        EV.append((perf(), label + ("" if threading.get_ident() == MAIN else "@worker") + " start"))
        try:
            return orig(self, *a, **k)
        finally:
            EV.append((perf(), label + ("" if threading.get_ident() == MAIN else "@worker") + " end"))

    setattr(cls, name, f)


wrap(A, "_calculate_profile", "request")
wrap(A, "_calculate_profile_thread", "compute")
wrap(A, "_calculate_profile_postthread", "postthread")
wrap(ql.Coordinator, "_update", "coordinator._update")

D = "/Users/nabil/DATA/IRIS/"
[raster] = raster_data([D + "2dd2d12db374b3466aa27a65bec235d3-iris_l2_20130902_163935_4000255147_raster/"
                        "iris_l2_20130902_163935_4000255147_raster_t000_r00000.fits"], ["Si IV 1403"])
sji = image_data(D + "534d789bb0a2821fb2b78eb36d1d6753-iris_l2_20130902_163935_4000255147_SJI_1400_t000.fits.gz")
qapp = get_qapp()
app = GlueApplication()
app.resize(1600, 1000)
app.show()
v = ql.quicklook(app, [raster, sji])
names = {id(v[r].figure.canvas): r for r in ("map", "spectrogram", "wavelength", "spectrum")}
names[id(v["sji"][0].figure.canvas)] = "sji"
cls = type(v["map"].figure.canvas)
draw = cls.draw


def timed(self, *a, **k):
    EV.append((perf(), f"draw {names.get(id(self), '?')} start"))
    try:
        return draw(self, *a, **k)
    finally:
        EV.append((perf(), f"draw {names.get(id(self), '?')} end"))


cls.draw = timed
end = perf() + 3
while perf() < end:
    qapp.processEvents()
    time.sleep(0.005)
canvas = v["map"].figure.canvas
firsts = {}
for k in range(8):
    x, y = 300 + 97 * k, 60 + 29 * k
    xs, ys = v["map"].axes.transData.transform((x, y))
    pos = QtCore.QPoint(int(round(xs / canvas.device_pixel_ratio)), int(round(canvas.height() - ys / canvas.device_pixel_ratio)))
    EV.clear()
    t0 = perf()
    QTest.mousePress(canvas, QtCore.Qt.LeftButton, QtCore.Qt.NoModifier, pos)
    QTest.mouseRelease(canvas, QtCore.Qt.LeftButton, QtCore.Qt.NoModifier, pos)
    EV.append((perf(), "click returned"))
    end = perf() + 0.8
    while perf() < end:
        qapp.processEvents()
        time.sleep(0.001)
    seen = {}
    for t, e in EV:
        seen.setdefault(e, (t - t0) * 1e3)
        if e == "draw spectrum end":
            seen["last spectrum draw end"] = (t - t0) * 1e3
    if k >= 2:
        for e, t in seen.items():
            firsts.setdefault(e, []).append(t)
    if k == 7:
        print(f"timeline of click {k} (ms):")
        for t, e in EV:
            print(f"  {(t - t0) * 1e3:7.1f}  {e}")
print("medians of first occurrence (ms):")
for e, ts in sorted(firsts.items(), key=lambda kv: statistics.median(kv[1])):
    print(f"  {statistics.median(ts):7.1f}  {e}")
import os  # noqa: E402

sys.stdout.flush()
os._exit(0)
