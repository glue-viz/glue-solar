"""Profile the synchronous set phase of SJI frame steps with the axes on or off (TREE AXES)."""
import cProfile, io, os, pstats, sys, time
TREE, AXES = sys.argv[1:3]
sys.path.insert(0, TREE)
import glue_solar
assert glue_solar.__file__.startswith(TREE)
from glue.config import settings
from glue_qt.app import GlueApplication
from glue_qt.utils import get_qapp
from qtpy import QtWidgets
from glue_solar.quicklook import quicklook
from glue_solar.sources.loaders.iris import image_data, raster_data
D = "/Users/nabil/DATA/IRIS/"
[raster] = raster_data([D + "2dd2d12db374b3466aa27a65bec235d3-iris_l2_20130902_163935_4000255147_raster/iris_l2_20130902_163935_4000255147_raster_t000_r00000.fits"], ["Si IV 1403"])
sji = image_data(D + "534d789bb0a2821fb2b78eb36d1d6753-iris_l2_20130902_163935_4000255147_SJI_1400_t000.fits.gz")
qapp = get_qapp(); app = GlueApplication()
settings.SOLAR_SHOW_AXES = AXES == "on"
app.resize(1600, 1000); app.show()
v = quicklook(app, [raster, sji])
end = time.perf_counter() + 2
while time.perf_counter() < end:
    qapp.processEvents(); time.sleep(0.005)
viewer = v["sji"][0]
print("axison", viewer.axes.axison)
qs = viewer.options_widget().slice_helper._sliders[0].findChild(QtWidgets.QSlider, "value_slice_center")
prof = cProfile.Profile()
ts = []
for k in range(25):
    t = time.perf_counter()
    if k >= 5:
        prof.enable()
    qs.triggerAction(QtWidgets.QAbstractSlider.SliderSingleStepAdd)
    if k >= 5:
        prof.disable()
        ts.append(time.perf_counter() - t)
    end = time.perf_counter() + 0.3
    while time.perf_counter() < end:
        qapp.processEvents(); time.sleep(0.002)
ts.sort()
print(f"set phase median {ts[len(ts)//2]*1e3:.1f} ms (profiled)")
s = io.StringIO()
pstats.Stats(prof, stream=s).sort_stats("cumulative").print_stats(30)
print(s.getvalue())
sys.stdout.flush()
os._exit(0)
