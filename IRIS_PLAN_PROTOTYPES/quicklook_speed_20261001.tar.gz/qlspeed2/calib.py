import time, statistics
def f():
    s = 0
    for i in range(300000):
        s += i * i % 7
    return s
ts = []
for _ in range(15):
    t = time.perf_counter(); f(); ts.append((time.perf_counter() - t) * 1e3)
print(" ".join(f"{t:.0f}" for t in ts), "median", f"{statistics.median(ts):.1f} ms")
