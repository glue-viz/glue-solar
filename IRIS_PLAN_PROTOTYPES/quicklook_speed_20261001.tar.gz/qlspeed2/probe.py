import sys, time
sys.path.insert(0, "/Users/nabil/Git/glue-solar-wp10-m0-quicklook-speed")
import glue_solar
from glue_solar import glue_patches as gp
print(glue_solar.__file__)
from glue_qt.viewers.image import ImageViewer
print("installed", ImageViewer.update_x_axislabel is gp.update_x_axislabel)
print("original needs", gp.needs_axis_label_workaround())
print("patched needs", gp.needs_axis_label_workaround((gp.update_x_axislabel, gp.update_y_axislabel)))
t = time.perf_counter()
for _ in range(20):
    gp.needs_axis_label_workaround()
print("ms per probe", (time.perf_counter() - t) / 20 * 1000)
