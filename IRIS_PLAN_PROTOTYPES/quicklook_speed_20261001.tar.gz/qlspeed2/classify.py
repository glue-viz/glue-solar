"""Label each process slow (idle-machine clocks) or fast (cluster clock held high), per configuration."""
import glob, json, os, statistics as st
from collections import defaultdict
HERE = os.path.dirname(os.path.abspath(__file__))


def marker(d):
    key = "redraw_map" if d["mode"] == "ql" else "image_redraw"
    return st.median(s["sync"] for s in d["samples"][key])


def labels():
    by = defaultdict(list)
    for p in glob.glob(os.path.join(HERE, "out", "r*_*.json")):
        r, t, m, a = os.path.basename(p)[:-5].split("_")
        by[t, m, a].append((p, marker(json.load(open(p)))))
    out = {}
    for cfg, items in by.items():
        top = max(v for _, v in items)
        for p, v in items:
            out[p] = "slow" if v >= 0.75 * top else "fast"
    return out


if __name__ == "__main__":
    lab = labels()
    count = defaultdict(lambda: [0, 0])
    for p, l in lab.items():
        r, t, m, a = os.path.basename(p)[:-5].split("_")
        count[t, m, a][l == "fast"] += 1
    for k, (s, f) in sorted(count.items()):
        print(k, "slow", s, "fast", f)
