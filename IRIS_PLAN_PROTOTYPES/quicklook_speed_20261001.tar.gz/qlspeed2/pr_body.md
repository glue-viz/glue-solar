Plan item `wp10-m0-quicklook-speed`: glue-solar's own costs from the 2026-10-01 profiling survey (`GLUE_SPEED.md` on the `plan` branch, items S1-S3, S7-S9, S14 and R1), one commit each:

- Add a quicklook's new datasets in one `extend` (one link update instead of one per dataset).
- Work out `_GlueWCS`'s arcsec scales and longitude wrap once per wrapper (bit-identical results).
- Sync time only when the time master's time slider moves, and place the raster point on the SJI once per frame.
- Remove a quicklook's Point layer where it must not show instead of hiding it (glue still redraws hidden layers).
- Apply a clicked point before glue draws it; drags keep the coalescing timer.
- Keep the sit-and-stare exposure label through glue's axis reset without the extra label round trip.
- Add a Hide axes button to every Image viewer, connecting glue's own `show_axes` state, with a `SOLAR_SHOW_AXES` glue setting for new viewers. The mouse-over readout keeps world coordinates.
- Label Image viewer axes on their WCSAxes coordinates instead of `set_xlabel`/`set_ylabel`, which place every tick eagerly (a probe-gated patch in `glue_patches`, retired when glue no longer does this).
- Reuse `_GlueWCS` conversions of identical pixels (a bounded, locked LRU; outputs bit-identical).

Measured on full 4000255147 (Si IV 1403 + SJI 1400), offscreen, warm cache, interleaved against main:

| | main | this branch | M0 budget |
|---|---|---|---|
| λ–t slit step (image panels) | 218 ms | 106 ms (63 with axes hidden) | ≤ 0.15 s |
| Click to spectrum (plan's probe) | 0.39-0.41 s | 0.17-0.18 s | ≤ 0.35 s |
| Synced step (plan's probe) | 0.30-0.32 s | 0.14-0.15 s | ≤ 0.25 s |
| SJI frame step (plan's probe) | 0.10 s | 0.025-0.027 s | ≤ 0.15 s |
| `quicklook()` | 2.26 s | 1.43 s | ≤ 3 s |

Main failed the first three budgets; all six hold on this branch. Every fix has a test that fails without it; the full suite passes locally (130 passed, 10 skipped).

One behaviour change to note: on SJIs rolled past 45° and on a scanning raster's λ–step panel, WCSAxes puts each coordinate's ticks on the other spine than glue assumes. glue labelled the latitude ticks 'Helioprojective Longitude' there; with this branch each axis label sits with its own coordinate's ticks. The user guide says so.

https://claude.ai/code/session_016GzY8z27NRe3KLiFYRzsHk
