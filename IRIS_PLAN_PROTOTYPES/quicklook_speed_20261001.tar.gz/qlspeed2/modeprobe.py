"""Does the slow/fast mode flip within a process, and does pure Python flip with the redraw? (TREE first)"""
import sys, time, statistics, os
TREE = sys.argv[1]
sys.path.insert(0, TREE)
import glue_solar
assert glue_solar.__file__.startswith(TREE)
from glue_qt.app import GlueApplication
from glue_qt.utils import get_qapp
from glue_solar.quicklook import quicklook
from glue_solar.sources.loaders.iris import image_data, raster_data
D = "/Users/nabil/DATA/IRIS/"
[raster] = raster_data([D + "2dd2d12db374b3466aa27a65bec235d3-iris_l2_20130902_163935_4000255147_raster/iris_l2_20130902_163935_4000255147_raster_t000_r00000.fits"], ["Si IV 1403"])
sji = image_data(D + "534d789bb0a2821fb2b78eb36d1d6753-iris_l2_20130902_163935_4000255147_SJI_1400_t000.fits.gz")
qapp = get_qapp(); app = GlueApplication(); app.resize(1600, 1000); app.show()
v = quicklook(app, [raster, sji])
for _ in range(100):
    qapp.processEvents(); time.sleep(0.01)
canvas = v["map"].figure.canvas
def calib():
    s = 0
    for i in range(300000):
        s += i * i % 7
start = time.perf_counter()
while time.perf_counter() - start < float(sys.argv[2]):
    rd, cb = [], []
    for _ in range(5):
        t = time.perf_counter(); canvas.draw(); rd.append(time.perf_counter() - t)
        t = time.perf_counter(); calib(); cb.append(time.perf_counter() - t)
        qapp.processEvents(); time.sleep(0.02)
    print(f"{time.perf_counter() - start:6.1f} s  redraw_map {statistics.median(rd)*1e3:5.1f} ms  calib {statistics.median(cb)*1e3:5.1f} ms", flush=True)
os._exit(0)
