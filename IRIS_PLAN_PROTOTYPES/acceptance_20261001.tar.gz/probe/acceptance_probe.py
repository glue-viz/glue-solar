"""
Manual probe for wp10-m0-acceptance: #90's qlprobe.py generalised to every observation and budget.

    python acceptance_probe.py TREE MODE OBSID [N]     (run it through acceptance.sh)
    python acceptance_probe.py summary FILE.jsonl ...

MODE ql: qlprobe's MODE ql on OBSID's scan 0 window (the table's, or $WINDOW) and SJI, in a 1600x1000 app:
quicklook() time, unchanged redraws, map contrast, map wavelength step, λ–t (λ–step) slit step, SJI frame
step, synced spectrogram step/exposure steps at 1, n/2 and n-1, Pixel clicks on the map.
MODE image: qlprobe's MODE image, a stock Image viewer of the window at glue's default size stepping its
slider over the axis it does not show.
MODE memory: scan 0's file with all windows as the launch reads it, or with the table's stack flag the
browser's stack of all scans, window by window (load_entry, stack=True), then the quicklook; no SJI. Bytes per
raster element by tracemalloc, #59's measure (kept and peak of the load, then with the quicklook: the
4000005156 budget), and by RSS from the running app (after the load, its peak, after the quicklook, the peak
overall: the stack's budget).
MODE crash: open the quicklook, click 3 times, step, and close its tab, N times in one process (acceptance.sh
runs one cycle per process, so a segfault ends one run only); one JSON line per cycle, which counts as crashed
on any exception, traceback on stderr, Qt critical/fatal message or Profile compute error, then a total.
A segfault, Qt fatal message or hang (HANG_S) ends the process; acceptance.sh reports its exit.

Timings are qlprobe's: each action is a real Qt slider step or mouse click; after it the probe processes
events until nothing is pending for 0.1 s and reports, from the canvases' own draw timestamps: sync (the
action call), images (the last image-panel draw ends), spectrum (the last spectrum draw ends), idle (all
quiet). Every run prints one JSON line. 'summary' pools the runs against the M0 budgets, per observation and
window, with one line per synced-step base (each must hold), and counts runs with errors or a bad exit.
"""

import faulthandler
import gc
import glob
import json
import os
import resource
import statistics
import sys
import threading
import time
import tracemalloc
import traceback

D = "/Users/nabil/DATA/IRIS/"
OBS = {  # OBSID: (raster files, SJI file, the time modes' window, memory stacks all scans)
    "4000255147": ("*_4000255147_raster/*.fits", "*_4000255147_SJI_1400_t000.fits.gz", "Si IV 1403", False),  # #90's
    "4000005156": ("*_4000005156_raster/*.fits", "*_4000005156_SJI_2796_t000_deconvolved.fits.gz", "Mg II k 2796", False),
    "3824262996": ("*_3824262996_raster/*.fits", None, "Mg II k 2796", False),
    "3400109360": ("*_3400109360_raster/*.fits", None, "Mg II k 2796", False),
    "3602506433": ("*_3602506433_raster/*.fits", None, None, True),  # memory only
}
BUDGETS = {  # budget: (mode, sample name prefix or result key, metric, seconds)
    "quicklook()": ("ql", "quicklook_s", None, 3.0),
    "image step": ("image", "image_step", "images", 0.10),
    "λ–t slit step": ("ql", "lt_slit_step", "images", 0.15),
    "click to spectrum": ("ql", "click", "spectrum", 0.35),
    "SJI step": ("ql", "sji_step", "images", 0.15),
    "synced step": ("ql", "synced_step_", "images", 0.25),
}

if sys.argv[1] == "summary":
    runs = [r for path in sys.argv[2:] for line in open(path) if line.startswith("{")
            for r in [json.loads(line)] if "mode" in r and "cycle" not in r]
    timed = [r for r in runs if "samples" in r and r["mode"] in ("ql", "image")]
    for obs, window in sorted({(r["obs"], r["window"]) for r in timed}):
        done = [r for r in timed if (r["obs"], r["window"]) == (obs, window)]
        for name, (mode, key, metric, budget) in BUDGETS.items():
            mine = [r for r in done if r["mode"] == mode]
            if metric is None:
                groups = {key: [r[key] for r in mine]}
            else:
                groups = {}
                for r in mine:
                    for k, ss in r["samples"].items():
                        if k.startswith(key):  # synced_step_ keeps one row per base
                            groups.setdefault(k, []).extend(s[metric] for s in ss if s[metric] is not None)
            for k, values in groups.items():
                if values:
                    median = statistics.median(values)
                    print(json.dumps({"obs": obs, "window": window, "budget": name, "samples": k, "runs": len(mine),
                                      "n": len(values), "median": round(median, 4), "max": round(max(values), 4),
                                      "limit": budget, "ok": median <= budget}, ensure_ascii=False))
    for r in runs:
        if r["mode"] == "memory" and "gb" in r:
            bpe, gb = r["bytes_per_element"], r["gb"]
            ok = (gb["peak"] < 12 if OBS[r["obs"]][3] else
                  max(bpe["kept"], bpe["kept_with_quicklook"]) <= 6 and bpe["peak_with_quicklook"] <= 10)
            print(json.dumps({"obs": r["obs"], "memory": "stack peak RSS < 12 GB" if OBS[r["obs"]][3] else
                              "tracemalloc kept <= 6, peak <= 10 B/element, quicklook included", "B/element": bpe,
                              "RSS B/element": r["rss_bytes_per_element"], "GB": gb, "ok": ok}))
    for obs, mode in sorted({(r["obs"], r["mode"].removesuffix("_total")) for r in runs}):
        mine = [r for r in runs if (r["obs"], r["mode"].removesuffix("_total")) == (obs, mode)]
        bad = sum(bool(r.get("errors")) or "exit" in r for r in mine)
        print(json.dumps({"obs": obs, "mode": mode, "runs": len(mine), "with_errors_or_exit": bad}
                         | ({"ok": bad == 0 and len(mine) >= 20} if mode == "crash" else {})))
    sys.exit()

TREE, MODE, OBSID = sys.argv[1:4]
N = int(sys.argv[4]) if len(sys.argv) > 4 else 1
RASTER_GLOB, SJI_GLOB, WINDOW, STACK = OBS[OBSID]
WINDOW = os.environ.get("WINDOW", WINDOW)
RASTERS = sorted(glob.glob(D + RASTER_GLOB))
SJI = glob.glob(D + SJI_GLOB)[0] if SJI_GLOB else None
assert RASTERS and (MODE == "memory" or WINDOW), (OBSID, MODE)
os.environ["GLUE_TESTING"] = "True"  # a glue error raises (and is counted) instead of opening a modal box
faulthandler.enable()  # a segfault prints every thread's Python stack to stderr (out/*.err)
# a hang, such as a modal box offscreen, ends the run with the stacks and exit 1 instead of blocking the runner
faulthandler.dump_traceback_later(float(os.environ.get("HANG_S", 1800 if MODE == "memory" else 600)), exit=True)
sys.path.insert(0, TREE)

import glue_solar  # noqa: E402

assert glue_solar.__file__.startswith(TREE), glue_solar.__file__

import psutil  # noqa: E402
from astropy.visualization.wcsaxes.coordinate_helpers import CoordinateHelper  # noqa: E402
from glue_qt.app import GlueApplication  # noqa: E402
from glue_qt.utils import get_qapp  # noqa: E402
from glue_qt.viewers.image import ImageViewer  # noqa: E402
from qtpy import QtCore, QtWidgets  # noqa: E402
from qtpy.QtTest import QTest  # noqa: E402

from glue_solar.sources.loaders.iris import image_data, iris_data, load_entry, raster_data  # noqa: E402
from glue_solar.sources.loaders.scan import scan_directory  # noqa: E402

perf = time.perf_counter
qapp = get_qapp()
result = {"tree": TREE, "mode": MODE, "obs": OBSID, "glue_solar": glue_solar.__file__,
          "ram_gb": os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") / 1e9, "loadavg": os.getloadavg(),
          "samples": {}}

# error capture: Python exceptions (Qt slots, threads), tracebacks printed to stderr (matplotlib's callbacks),
# Qt critical and fatal messages
ERRORS = []


def excepthook(kind, value, tb):
    ERRORS.append("".join(traceback.format_exception_only(kind, value)).strip())
    traceback.print_exception(kind, value, tb, file=sys.__stderr__)


sys.excepthook = excepthook
threading.excepthook = lambda a: excepthook(a.exc_type, a.exc_value, a.exc_traceback)


def qt_message(kind, _context, message):
    if kind in (QtCore.QtCriticalMsg, QtCore.QtFatalMsg):
        ERRORS.append(f"Qt: {message}")
    sys.__stderr__.write(f"{message}\n")


QtCore.qInstallMessageHandler(qt_message)


def capture_stderr():
    """Count tracebacks written to sys.stderr, which glue's logger replaces when the app starts."""
    stream = sys.stderr
    write = stream.write

    def tee(message):
        if "Traceback (most recent call last)" in message:
            ERRORS.append("traceback on stderr")
        return write(message)

    stream.write = tee


# glue hides a Profile layer whose computation raised (on its worker thread or not) and prints nothing; it
# disables the layer with a message for IncompatibleAttribute, which is not counted
from glue.core.exceptions import IncompatibleAttribute  # noqa: E402
from glue.viewers.profile.layer_artist import ProfileLayerArtist  # noqa: E402

_profile_error = ProfileLayerArtist._calculate_profile_error


def profile_error(self, exc):
    if not issubclass(exc[0], IncompatibleAttribute):
        ERRORS.append("Profile: " + "".join(traceback.format_exception_only(*exc[:2])).strip())
        traceback.print_exception(*exc, file=sys.__stderr__)
    return _profile_error(self, exc)


ProfileLayerArtist._calculate_profile_error = profile_error

# instrumentation: Agg draw spans per canvas, tick updates
DRAWS = []  # (canvas id, start, end)
TICKS = [0]
POSTS = []  # ends of the spectrum's profile results reaching the main thread
from glue_qt.viewers.profile.layer_artist import QThreadedProfileLayerArtist  # noqa: E402

_postthread = QThreadedProfileLayerArtist._calculate_profile_postthread


def posted(self, *args, **kwargs):
    try:
        return _postthread(self, *args, **kwargs)
    finally:
        POSTS.append(perf())


QThreadedProfileLayerArtist._calculate_profile_postthread = posted
_update_ticks = CoordinateHelper._update_ticks


def counted(self):
    TICKS[0] += 1
    return _update_ticks(self)


CoordinateHelper._update_ticks = counted


def instrument(canvas):
    cls = type(canvas)
    if getattr(cls, "_probe", False):
        return
    draw = cls.draw

    def timed(self, *args, **kwargs):
        start = perf()
        try:
            return draw(self, *args, **kwargs)
        finally:
            DRAWS.append((id(self), start, perf()))

    cls.draw, cls._probe = timed, True


def rss():
    return psutil.Process().memory_info().rss


def maxrss():
    """Peak RSS in bytes: ru_maxrss is bytes on macOS, KiB on Linux."""
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * (1024 if sys.platform.startswith("linux") else 1)


if MODE == "memory":  # the app first, so that the baseline holds it
    app = GlueApplication()
    capture_stderr()
    app.resize(1600, 1000)
    app.show()
    for _ in range(5):
        qapp.processEvents()
        time.sleep(0.05)
    result["rss_start"] = rss()
    tracemalloc.start()  # numpy reports its buffers to it; memory-mapped stack pages are not traced
    t0 = perf()
    if STACK:  # the browser with the observation ticked: every window, stacked
        [observation] = scan_directory(os.path.dirname(RASTERS[0]), recursive=False)
        datasets = [d for w in observation.windows for d in load_entry(observation, "raster", w, stack=True)]
    else:  # glue --startup=iris_quicklook on scan 0's file: every window
        datasets = iris_data(RASTERS[0])
    result["load_s"] = perf() - t0
    gc.collect()  # kept, not garbage: irispy's discarded cubes sit in reference cycles (about 1 B/element)
    result["traced_load"] = tracemalloc.get_traced_memory()  # (kept, peak) of the load
    result["rss_load"], result["rss_peak_load"] = rss(), maxrss()
else:
    t0 = perf()
    [raster] = raster_data(RASTERS[:1], [WINDOW])  # scan 0
    sji = image_data(SJI) if SJI and MODE != "image" else None
    result.update(load_s=perf() - t0, window=WINDOW, sji=SJI if sji is not None else None)
    app = GlueApplication()  # loads the plugins, so glue_solar.setup() runs once
    capture_stderr()
bad = [m.__file__ for n, m in list(sys.modules.items())
       if n.startswith("glue_solar") and getattr(m, "__file__", None) and not m.__file__.startswith(TREE)]
assert not bad, bad


def busy(images, spectrum=None, layers=()):
    for canvas in images + ([spectrum] if spectrum is not None else []):
        if getattr(canvas, "_draw_pending", False):
            return True
    for layer in layers:
        if getattr(layer, "is_computing", False):
            return True
        worker = getattr(layer, "_worker", None)
        if worker is not None and not worker.work_queue.empty():
            return True
    coord = getattr(app.data_collection, "_solar_coordinator", None)
    return coord is not None and coord._timer.isActive()


def settle(timeout=30.0):
    start, quiet = perf(), None
    while perf() - start < timeout:
        qapp.processEvents()
        if busy(*BUSY):
            quiet = None
        else:
            quiet = quiet or perf()
            if perf() - quiet > 0.1:
                return quiet
        time.sleep(0.001)
    raise RuntimeError(f"not idle after {timeout} s")


def measure(name, act, record=True):
    """Run ``act`` and settle; append its timings to the samples of ``name``."""
    DRAWS.clear()
    POSTS.clear()
    TICKS[0] = 0
    start = perf()
    act()
    sync = perf()
    ticks_sync = TICKS[0]
    idle = settle()
    draws = {}
    last = {}
    for cid, _s, end in DRAWS:
        role = NAMES.get(cid, "other")
        draws[role] = draws.get(role, 0) + 1
        last[role] = max(last.get(role, 0), end)
    images = max([sync] + [last[r] for r in last if r not in ("spectrum", "other")])
    sample = {
        "sync": sync - start,
        "images": images - start,
        "spectrum": (last["spectrum"] - start) if "spectrum" in last else None,
        # the first spectrum draw after the first profile result: the new spectrum first shown
        "spectrum_first": next((end - start for cid, s0, end in DRAWS
                                if NAMES.get(cid) == "spectrum" and POSTS and s0 >= POSTS[0]), None),
        "idle": idle - start,
        "draws": draws,
        "ticks": TICKS[0],
        "ticks_sync": ticks_sync,
    }
    if record:
        result["samples"].setdefault(name, []).append(sample)
    return sample


def slider(viewer, axis):
    helper = viewer.options_widget().slice_helper
    return helper._sliders[axis].findChild(QtWidgets.QSlider, "value_slice_center")


def stepper(viewer, axis, add=True):
    qs = slider(viewer, axis)
    action = QtWidgets.QAbstractSlider.SliderSingleStepAdd if add else QtWidgets.QAbstractSlider.SliderSingleStepSub
    return lambda: qs.triggerAction(action)


def run(name, act, warm=2, n=9):
    for _ in range(warm):
        measure(name, act, record=False)
    for _ in range(n):
        measure(name, act)


def redraw(canvas):
    return lambda: canvas.draw()


def clicker(viewer, shape):
    """Pixel clicks on the map at fresh steps or exposures and slits: qlprobe's on 4000255147's 1600 x 417 map."""
    canvas = viewer.figure.canvas
    clicks = iter([(round((300 + 97 * k) * shape[0] / 1600), round((60 + 29 * k) * shape[1] / 417)) for k in range(12)])

    def click():
        x, y = next(clicks)
        xs, ys = viewer.axes.transData.transform((x, y))
        dpr = canvas.device_pixel_ratio
        pos = QtCore.QPoint(int(round(xs / dpr)), int(round(canvas.height() - ys / dpr)))
        QTest.mousePress(canvas, QtCore.Qt.LeftButton, QtCore.Qt.NoModifier, pos)
        QTest.mouseRelease(canvas, QtCore.Qt.LeftButton, QtCore.Qt.NoModifier, pos)
        click.target = (x, y)

    return click


def open_quicklook(datasets):
    """quicklook() with its panels instrumented and BUSY set: (viewers, panels, its time, time to idle)."""
    global BUSY
    from glue_solar.quicklook import quicklook

    t0 = perf()
    viewers = quicklook(app, datasets)
    t1 = perf()
    panels = {role: viewers[role] for role in ("map", "spectrogram", "wavelength", "spectrum")}
    panels.update({"sji": viewers["sji"][0]} if viewers["sji"] else {})
    for role, v in panels.items():
        instrument(v.figure.canvas)
        NAMES[id(v.figure.canvas)] = role
    images = [v.figure.canvas for role, v in panels.items() if role != "spectrum"]
    BUSY = (images, panels["spectrum"].figure.canvas, viewers["spectrum"].layers)
    return viewers, panels, t1 - t0, settle(60) - t0


NAMES = {}
BUSY = ([],)
if MODE == "image":
    app.data_collection.append(raster)
    viewer = app.new_data_viewer(ImageViewer, data=raster)
    app.show()
    for _ in range(5):
        qapp.processEvents()
        time.sleep(0.1)
    canvas = viewer.figure.canvas
    instrument(canvas)
    NAMES[id(canvas)] = "image"
    BUSY = ([canvas],)
    settle()
    result["canvas"] = [canvas.width(), canvas.height()]
    shown = {viewer.state.x_att.axis, viewer.state.y_att.axis}
    axis = next(i for i in range(raster.ndim) if i not in shown)
    qs = slider(viewer, axis)
    qs.setValue(raster.shape[axis] // 2)
    settle()
    result["image_axis"] = axis
    run("image_step", stepper(viewer, axis), warm=3, n=15)
    run("image_redraw", redraw(canvas), warm=2, n=9)
elif MODE == "memory":
    # slowed by tracemalloc: the time budgets are the ql runs'
    viewers, panels, result["traced_quicklook_s"], result["traced_open_idle_s"] = open_quicklook(datasets)
    gc.collect()
    result["traced_quicklook"] = tracemalloc.get_traced_memory()  # (kept, peak) of the load and the quicklook
    result["rss_quicklook"], result["rss_peak"] = rss(), maxrss()
    result["shapes"] = {d.label: d.shape for d in datasets}
    result["elements"] = n = int(sum(d.size for d in datasets))
    (kept, peak), (kept_ql, peak_ql) = result["traced_load"], result["traced_quicklook"]
    result["bytes_per_element"] = {"kept": kept / n, "peak": peak / n, "kept_with_quicklook": kept_ql / n,
                                   "peak_with_quicklook": peak_ql / n}
    base = result["rss_start"]
    result["rss_bytes_per_element"] = {k: (result[f"rss_{k}"] - base) / n for k in ("load", "peak_load", "quicklook", "peak")}
    result["gb"] = {k: result[f"rss_{k}"] / 1e9 for k in ("start", "load", "peak_load", "quicklook", "peak")}
elif MODE == "ql":
    app.resize(1600, 1000)
    app.show()
    for _ in range(5):
        qapp.processEvents()
        time.sleep(0.05)
    viewers, panels, result["quicklook_s"], result["open_idle_s"] = open_quicklook([raster] + ([sji] if sji is not None else []))
    end = perf() + 1.5  # the canvases' resize timers
    while perf() < end:
        qapp.processEvents()
        time.sleep(0.005)
    settle()
    roles = [r for r in ("map", "spectrogram", "wavelength", "sji") if r in panels]
    result["canvas"] = {r: [v.figure.canvas.width(), v.figure.canvas.height()] for r, v in panels.items()}
    result["axison"] = {r: panels[r].axes.axison for r in roles}
    for role in roles:
        run(f"redraw_{role}", redraw(panels[role].figure.canvas))

    layer = panels["map"].state.layers[0]
    flip = [0]

    def contrast():
        flip[0] += 1
        layer.v_max *= 1.01 if flip[0] % 2 else 1 / 1.01

    run("contrast_map", contrast)
    spectrogram = panels["spectrogram"]
    run("map_wl_step", stepper(panels["map"], 2))  # the map shows step/exposure x slit; its slider is wavelength
    run("lt_slit_step", stepper(panels["wavelength"], 1))  # λ–t/λ–step shows wavelength x step/exposure
    if "sji" in panels:
        run("sji_step", stepper(panels["sji"], 0))
    qs = slider(spectrogram, 0)
    last = raster.shape[0] - 1
    for base in (1, raster.shape[0] // 2, last):
        qs.setValue(base)
        settle()
        run(f"synced_step_{base}", stepper(spectrogram, 0, add=base != last), warm=1, n=3)

    click = clicker(panels["map"], raster.shape)
    missed = []
    for k in range(11):
        measure("click", click, record=k >= 2)
        exposure = spectrogram.state.slices[0]
        if abs(exposure - click.target[0]) > max(1, raster.shape[0] / 400):
            missed.append((click.target, exposure))
    result["click_missed"] = missed
elif MODE == "crash":
    app.resize(1600, 1000)
    app.show()
    crashed = 0
    for cycle in range(N):
        before, t0 = len(ERRORS), perf()
        try:
            viewers, panels, _, _ = open_quicklook([raster] + ([sji] if sji is not None else []))
            click = clicker(panels["map"], raster.shape)
            acts = [click, click, click, stepper(panels["wavelength"], 1), stepper(panels["spectrogram"], 0)]
            acts += [stepper(panels["sji"], 0)] if "sji" in panels else []
            for act in acts:
                act()
                settle()
            app.close_tab(app.tab_count - 1, warn=False)
            BUSY = ([],)
            settle()
        except Exception as error:  # noqa: BLE001 - a crashed cycle, counted
            ERRORS.append(repr(error))
            traceback.print_exc(file=sys.__stderr__)
        crashed += len(ERRORS) > before
        print(json.dumps({"mode": "crash", "obs": OBSID, "cycle": cycle, "s": perf() - t0, "errors": ERRORS[before:],
                          "tabs": app.tab_count, "rss_gb": rss() / 1e9}), flush=True)
    result = {"mode": "crash_total", "obs": OBSID, "cycles": N, "crashed": crashed, "tree": TREE, "window": WINDOW, "loadavg": os.getloadavg()}

result["errors"] = ERRORS
result["maxrss_mb"] = maxrss() / 1e6
print(json.dumps(result), flush=True)
os._exit(0)  # no teardown: glue would write QSettings on close
