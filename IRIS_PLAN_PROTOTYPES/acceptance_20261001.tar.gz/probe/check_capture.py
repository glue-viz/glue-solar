"""
Check that acceptance_probe.py's crash mode counts what it should: run 2 cycles on 3400109360 with a Qt
critical message, an exception in a Qt slot, one in a matplotlib callback and one in the Profile worker's
computation injected into cycle 0. Expected: cycle 0 lists all four, cycle 1 none, crashed 1. Run it as
acceptance.sh runs the probe:

    env HOME=$(mktemp -d) QT_QPA_PLATFORM=offscreen MPLBACKEND=agg python -B check_capture.py TREE
"""

import os
import runpy
import sys
import threading

TREE = sys.argv[1]
sys.path.insert(0, TREE)
from qtpy import QtCore  # noqa: E402

from glue_solar.quicklook import Coordinator  # noqa: E402

done = set()


def once(name):
    fresh = name not in done
    done.add(name)
    return fresh


_register = Coordinator.register


def slot():
    raise RuntimeError("injected in a Qt slot")


def register(self, viewer):
    def boom(_event):
        if once("mpl"):
            raise RuntimeError("injected in a matplotlib callback")

    viewer.figure.canvas.mpl_connect("button_press_event", boom)
    if once("qt"):
        QtCore.qCritical("injected Qt critical message")
        QtCore.QTimer.singleShot(0, slot)
    return _register(self, viewer)


Coordinator.register = register

from glue.viewers.profile.state import ProfileLayerState  # noqa: E402

_update_profile = ProfileLayerState.update_profile


def update_profile(self, *args, **kwargs):
    if threading.current_thread() is not threading.main_thread() and once("profile"):
        raise RuntimeError("injected in a Profile computation")
    return _update_profile(self, *args, **kwargs)


ProfileLayerState.update_profile = update_profile
sys.argv = ["acceptance_probe.py", TREE, "crash", "3400109360", "2"]
runpy.run_path(os.path.join(os.path.dirname(os.path.abspath(__file__)), "acceptance_probe.py"), run_name="__main__")
