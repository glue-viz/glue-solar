The stress survey ran on all 7 SST cubes and 6 IRIS observations. The biggest result: glue crashes when an IRIS quicklook is open beside an SST cube. All 4 unprotected runs crashed (SST1). `numbers.json` is written. `report.md` was not: the harness refuses report files from a subagent, so the report text follows here. Nothing was edited, committed or pushed. The worktree, session files, scratch HOMEs and the 3630104144 extraction are all removed. Free disk space stayed between 20 and 23 GB.

Paths below are relative to `/private/tmp/claude-501/-Users-nabil-Git-glue-solar/07d33ef8-b8df-4ddb-b55c-24b6271a724b/scratchpad/sst-stress/`. Raw data is in `numbers.json`, and every phase of every run is in `out/<run>.json` and `out/<run>.log`. Scripts are in `scripts/`: `sst.py`, `iris.py`, `restore.py`, `common.py`, `run*.sh`, `batch*.sh`, `summarize.py`.

# SST and IRIS stress survey (wp10-l-sst-stress, D62), 2026-10-10

## Method

- **Software:**
  - glue-core 1.27.0, glue-qt 0.4.2, astropy 8.0.1, irispy main 8c220d4, matplotlib 3.11.2, numpy 2.5.3, PyQt6 on Qt 6.11.0 (as qtpy reports it), Python 3.13.16, env `iris-plan-qt6`.
  - glue-solar is a detached worktree of origin/main 4c57625, first on `sys.path`; every run checks that `glue_solar` was imported from it. origin/main has since moved to 75b7a73 (#225); the numbers are for 4c57625.
- **Machine and app:**
  - macOS (Darwin 27.0.0), 24 GB, 12 CPUs; offscreen Qt with Agg; app 1600x1000 at device pixel ratio 1. The SST Image viewer canvas was 588x303.
  - Each run is a fresh process with a fresh `HOME`, one big cube per process, run with `python -I`.
- **Paths measured:**
  - SST: glue's own File > Open path: `load_data(path, factory=auto_data)` as the data wizard's 'Auto' calls it, then `app.add_datasets` with glue-qt's autolinker.
  - IRIS: the browser path without its dialog: `scan_directory`, the browser's `_load` of every raster window and SJI (stacked for multi-scan sets), `extend` + `keep_hpc_linked`, then `quicklook`.
  - Session restore runs in its own fresh process.
- **Counters:**
  - Wall time is `perf_counter`. Each step or move runs until no draw, profile worker or coordinator timer is pending. The harness's 30 ms quiet window is not counted.
  - Memory and I/O come from macOS `proc_pid_rusage`:
    - resident size (RSS) and footprint (anonymous memory);
    - bytes read from disk (`diskio_bytesread`) and page-ins.
  - A 20 ms sampler records peaks and would have stopped any run over 20 GB RSS. None got there: the maximum was 13.7 GB.
  - Page-cache state comes from `mincore` on a fresh map of the file. I checked the probe by reading 50 MB cold: it counted 50 MB read and 12.4% cached.
  - RSS includes clean memory-mapped file pages, which macOS can drop. The footprint is what a cube really costs.
- **Cold and warm:**
  - I cannot drop the page cache.
  - Every SST cube was 0% cached when its first run started, so the open, viewer and Profile numbers are cold. The 8542 cube was evicted again before its re-run, which was cold too.
  - Step times are given as first visit (mostly cold pages) / warm revisit.
  - IRIS sets were cold except 4000255147 and 3630104144; the tables say which.
- **Timing correction:**
  - Runs before 07:37 (the first SST batch, `s498L`, `s498LI`) included the 30 ms quiet window in each step or move.
  - `numbers.json` and the tables subtract it. The fixed harness confirms the correction: warm steps of 16-20 ms and drags of 194-198 ms.
- **Profiling:**
  - Timers at the 2026-10-01 survey's code boundaries (draw, buffer, statistic, mask, profile, `_reset_y_limits`, astropy WCS transforms), with the main thread and worker threads kept apart.
  - cProfile double-counted under Qt re-entrancy, so I set it aside. Restores are timed without it.
- **Dialogs:**
  - Message boxes were answered OK, as a user clicks through.
  - Other modal dialogs were cancelled.
  - glue-solar's wavelength band prompt was answered with the widest band (15 pixels).
- **WCS lock:** the "with IRIS beside" numbers needed `--wcs-lock`. This is a harness-only stand-in for SST1's candidate fix. It puts every astropy WCS transform and FITS-WCS API property under glue-solar's `WCS_LOCK`.

## What File > Open does with an SST cube

- **Loader:**
  - glue picks `fits_reader` ('FITS file', priority 100); identification takes 2-4 ms.
  - glue-solar's 'IRIS Level 2 FITS' factory (priority 200) reads the primary header and declines.
- **The 33 HDUs become 33 datasets:**
  - the 5-D cube, `>f4`, memory-mapped with no copy and 0 bytes read, with a WCS built from the HDUList (-TAB axes plus a CWDIS3 distortion lookup);
  - `WCSDVARR`, a 5-D image with its own WCS (124 MB on 8542);
  - `WCS-TAB`, which becomes an empty 0-D dataset;
  - 30 `VAR-EXT` tables as 1-D datasets, with about 30 'Dropping column … not 1-dimensional' warnings.
- **Cost:** 0.33-0.61 s. The autolinker suggests nothing, and the collection ends with 20 links.

## SST cubes

Shapes are numpy order (t, Stokes, λ, y, x). Step times are the same for the time, Stokes and λ sliders. Visiting every slice once adds 0.10-0.27 GB of RSS, all file pages; the footprint stays at about 0.3 GB.

| Cube | Shape | GB | Open s | Viewer s (GB read), cold | Steps ms, first / warm | Profile s (main-thread s) | Profile GB read | RSS after Profile, steady / peak | Footprint peak | Drag ms/move | Rectangle apply + settle s | Path Enter + settle s | Save | Restore |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| obs492 8542 | 6×4×21×2274×2281 | 9.86 | 0.61 | 2.56 (0.45); re-run 1.82 (0.74) | 34-39 / 20 | 32.5-32.8 (21.1-21.3) | 9.2-9.4 | 10.3 / 13.6-13.7 | 4.4 | 183-194 | 0.27 + 0.61 | 0.19 + 5.3 | 8 ms, 119 KB | fails, 0.012 s |
| obs492 6173 | 6×4×14×2274×2280 | 6.61 | 0.52 | 2.58 (0.45) | 34-39 / 20 | 21.5 (14.1) | 6.15 | 7.2 / 9.7 | 3.0 | 193 | 0.27 + 0.40 | 0.18 + 7.0 | 8 ms, 119 KB | fails, 0.010 s |
| obs492 6302 | 6×4×11×2275×2280 | 5.22 | 0.48 | 2.58 (0.44) | 35-38 / 20 | 17.0 (11.1) | 4.79 | 5.8 / 7.7 | 2.4 | 207 | 0.28 + 0.30 | 0.17 + 2.7 | 8 ms, 119 KB | same path |
| obs495 3950 | 6×1×55×1848×1402 | 3.30 | 0.42 | 2.45 (0.43) | 28 / 17.5 | 9.8 (6.0) | 2.43 | 4.0 / 5.1 | 1.7 | 184 | 0.28 + 0.42 | 0.18 + 3.5 | 8 ms, 110 KB | fails, 0.010 s |
| obs498 4846 | 6×1×17×1846×1403 | 1.04 | 0.35 | 1.56 (0.50) | 25 / 17 | 3.3 (1.9) | 0.67 | 1.8 / 2.0 | 0.7 | 196-198 (30 without the Profile viewer) | 0.27 + 0.17 | 0.18 + 0.5 | 8 ms, 110 KB | same path |
| obs167 6173 (2020) | 6×4×12×1324×1328 | 1.93 | 0.38 | **refused (SPECSYS)**; with SPECSYS set in memory 1.90 (0.31) | 28-30 / 21 | 6.2 (3.7) | 1.47 | 2.6 / 3.2 | 1.0 | 186 | 0.26 + 0.15 | 0.18 + 1.1 | 3 ms, 61 KB | same path |
| obs171 6563 (2020) | 5×1×11×1323×1326 | 0.39 | 0.33 | **refused**; with SPECSYS set 1.29 (0.28) | 25 / 21 | 1.2 (0.5), cached | 0.06 | 1.0 / 1.2 | 0.6 | 189 | 0.25 + 0.12 | 0.18 + 0.2 | 8 ms, 107 KB | fails, 0.011 s |

- **Playback:**
  - glue-qt's slider at its 100 ms timer plays 9.8-10 frames/s on every cube.
  - At 25 ms it plays 40 frames/s on 8542 warm.
  - glue-solar's Loop… with bounce plays 9.7 frames/s.
- **Steps with subsets shown:** 22-28 ms with the Pixel point, 31-39 ms with the rectangle as well.
- **glue-solar tools on SST cubes** (step costs on 8542, warm):

  | Status | Tools |
  |---|---|
  | Offered and working | Measure; Path diagram (5-D cube → 4-D diagram, a step on it 40 ms); Follow/lock; Hide axes (22 ms per step); Per-frame limits (42 ms); Wavelength band (15 pixels: 101 ms per step on 21-λ cubes); Physical aspect, Zoom 1:1 and Colour bar (30-37 ms); Cursor readout; Loop…; Clear point; Blink |
  | Hidden: they refuse non-IRIS data | Time master, Go to UTC, Raster overlays, both light-curve entries, Row and Column at the point |
  | Disabled | Frame time; Path crosshair and Slope until a diagram exists |

- **Dialogs a user meets on the Profile button:** 'Creating a profile viewer', then 'Add large data set?' for every cube of 1e8 values or more (all but obs171).

## IRIS sets (browser path, lazy reads, quicklook)

Step times are warm, which equals first visit. "Point curves" is 'Light curves of every window and SJI…'.

| Observation, windows ticked | GB, cache state | Open s (load / quicklook) | GB read | RSS GB | Map λ step ms | Spectrogram exposure/step/scan ms | λ-panel ms | SJI frame ms | Click / move ms | Rectangle settle s (SJI step with it, ms) | Path Enter s | Light curve / point curves / row / column s | Save | Restore s (data part) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 4000255147, Si IV 1403 + SJI 1400 | 2.0, 93% | 4.35 (2.74/1.45) | 0.13 | 1.10 | 84 | 207 | 206 | 41 | 248 / 235 | 0.50 (75) | 0.25 | 0.30 / 1.06 / 0.45 / 0.46 | 10 ms, 143 KB | 5.8 (1.1) |
| 4000255147, 9 windows + SJI 1400 | 2.0, warm | 13.6 (5.6/7.1) | 0 | 2.90 | 88 | 865-874 | 916-920 | 42 | 760 / 985 | 2.55 (73) | 0.52 | 1.03 / 4.23 / 2.10 / 2.02 | 31 ms, 542 KB | 19.3 (1.8) |
| 3660259102 sit-and-stare, 9 windows | 1.43, cold | 12.4 (5.1/6.5) | 1.43 (whole file) | 2.17 | 83 | 845 | 909 | — | 711 / 958 | 1.98 | 0.47 | 0.98 / 3.55 / 1.91 / 2.01 | 157 ms, 408 KB | 16.4 (0.8) |
| 3824262996 dense 400-step raster, 8 windows | 1.48, cold | 5.6 (2.2/3.2) | 0.44 | 1.02 | 66 | 361 | 358 | — | 378 / 417 | 2.16 | 0.36 | n/a / **refuses** (SST11) / 0.62 / 0.73 | 12 ms, 139 KB | 6.9 (0.6) |
| 3602506433 99-scan stack, 7 windows | 1.89, cold | 16.7 (11.2/4.8) | 1.55 | 2.24 | 64 | scan 599-606, step 711 | 681-714 | — | 608 / 742 | 1.94 | 0.49 | 0.78 / 2.43 / 1.29 / 1.43 | 23 ms, 279 KB | **49.3 (38.1, 693 file reads)** |
| 3630104144 120-scan stack, 8 windows | 1.99, warm | 18.8 (12.4/5.5) | 0 | 2.75 | 65 | scan 693-695, step 845 | 813-851 | — | 702 / 886 | 3.48 | 0.47 | 0.86 / 2.89 / 1.60 / 1.62 | 26 ms, 319 KB | **70.7 (56.5, 960 file reads)** |
| 4000005156 2-scan stack, 9 windows + SJI 2796 deconvolved | 0.47, cold | 10.1 (2.7/6.6) | 0.47 (whole file) | 1.32 | 71 | scan 772, step 835 | 776-837 | 51 | 685 / 856 | 1.14 (319) | 0.62 | 1.12 / 3.38 / 1.87 / 2.13 | 31 ms, 330 KB | 15.7 (1.5) |

**SST against IRIS:**
- SST warm steps (17-21 ms) are cheaper than IRIS SJI steps (41-51 ms) and map steps (64-88 ms).
- An SST drag (183-207 ms) costs about the same as a single-window IRIS move (235 ms).

## SST cube with an IRIS quicklook in another tab

The quicklook is 4000255147 with all 9 windows and SJI 1400. It was opened after the SST cube had an Image viewer, a Profile viewer, a Pixel point and a rectangle.

| Run | Crash | Quicklook open s | Exposure / λ-panel / SJI / map step ms | IRIS click / move ms | Same without the SST rectangle | SST step / Pixel move ms with IRIS open | RSS / footprint GB |
|---|---|---|---|---|---|---|---|
| 4846 as shipped (2 runs) | **SIGSEGV**, during the quicklook open | — | — | — | — | — | — |
| 8542, transforms-only lock | **SIGABRT**, during the quicklook open | — | — | — | — | — | — |
| 4846, no rectangle, as shipped | **SIGSEGV** on the first SST Pixel drag after the quicklook | 14.5 (alone 13.6) | 909 / 975 / 51 / 91 | 822 / 1047 | — | — | 4.4 / 0.75 |
| 4846, full lock | no | **328-329** | **3687-3705** / 1000 / **2828-2842** / 91 | **3612-3671** / 1068 | 887 / 985 / 40 / 90; 1310 / 722 | 35 / **571-705** (alone 17 / 196) | 7.9 / 3.8 |
| 8542, full lock | no | **410** | **4356** / 999 / **3478** / 92 | **4293** / 1078 | 892 / 999 / 39 / 91; 1360 / 757 | 40 / **735** (alone 20 / 194) | 12.3 (peak 13.7) / 4.0 |

## Findings, ranked by the time or memory a user loses

The "Proposed" lines are for you to accept. The plan and GLUE_SPEED.md were not edited.

### SST1. glue crashes with an IRIS quicklook beside an SST cube: wcslib is called on the SST cube's WCS from several threads, outside WCS_LOCK

- **Owner:** glue-solar (fix); astropy is the root cause (astropy#19174); glue-qt's worker threads are involved.
- **Cost:**
  - 4 of 4 unprotected runs crashed and lost the session: two SIGSEGVs during the quicklook open, one SIGABRT with only the transforms locked, and one SIGSEGV on the first SST Pixel drag with no rectangle at all.
  - With every WCS entry point locked, 3 of 3 runs completed.
- **Cause:**
  - The SST cube's WCS is a plain astropy WCS from glue's FITS reader (-TAB axes plus a distortion lookup).
  - `keep_hpc_linked`/`link_hpc` link it to IRIS when the quicklook opens (`glue_solar/sources/loaders/iris.py:735-829` at 4c57625).
  - glue-qt's profile `ComputeWorker` threads then call into it by two paths:
    - `glue/viewers/image/pixel_selection_subset_state.py:24-36` → `glue/core/link_manager.py:435 pixel_cid_to_pixel_cid_matrix` → `glue_solar/glue_patches.py:108-134 world2pixel_single_axis` → `WCS.all_world2pix`;
    - `glue/core/coordinate_helpers.py:47 pixel2world_single_axis` → `fitswcs.axis_correlation_matrix`.
  - Meanwhile the main thread draws linked masks through the same underlying WCS object.
  - `WCS_LOCK` (`iris.py:84`) only covers `_GlueWCS`, which is IRIS data only.
- **Candidate fix:**
  - glue-solar: wrap the WCS of every non-IRIS dataset that `link_hpc` links in a locked wrapper, as `_GlueWCS` does, and take the lock in `world2pixel_single_axis`.
  - Locking only the transforms is not enough: the SIGABRT was in a property.
- **Existing coverage:** no GLUE_SPEED item. The plan's `wp0-astropy-19174` and `WCS_LOCK` (#60) cover the class; this is the first non-IRIS reproducer.
- **Evidence:** `scripts/sst.py CUBE NAME --iris sit` (with and without `--wcs-lock`); `out/s498noroi.log`, `out/s8542.log`, `out/s498L.json`, `out/s8542W.json`.
- **Proposed:** a glue-solar item `wp13-sst-wcs-lock`, and add this reproducer to `wp0-astropy-19174`.

### SST2. The 2020 SSTRED exports cannot be shown at all: 'Failed to add data — SPECSYS= not yet supported'

- **Owner:** glue-solar (the wp13 loader); astropy as an alternative.
- **Cost:** obs167 and obs171 open, but no Image viewer takes them.
- **Cause:**
  - Their headers have OBSGEO but no SPECSYS.
  - astropy's `fitswcs._get_components_and_classes` (`astropy/wcs/wcsapi/fitswcs.py:504-519`) raises for an empty SPECSYS when there is an observer location.
  - WCSAxes builds every axis's classes just to get the celestial frame (`astropy/visualization/wcsaxes/wcsapi.py:323`).
  - The 2023 exports carry `SPECSYS='TOPOCENT'` and work.
- **Candidate fix:**
  - The SOLARNET loader sets `SPECSYS='TOPOCENT'` on ground-based files that lack it. Setting it in memory makes both cubes work in every phase.
  - Alternatively, astropy treats an empty SPECSYS as "no spectral observer" instead of raising.
- **Existing coverage:** wp13 notes that SPECSYS is missing, but not that the viewer refuses the file.
- **Evidence:** `scripts/sst.py` with and without `--fix-specsys`; `out/s167.json` (the dialog and its traceback).
- **Proposed:** fold into `wp13-solarnet-tab-wcs`, with "obs167 and obs171 show in an Image viewer" added to Done-when.

### SST3. An SST region shown on an IRIS quicklook costs minutes per action (once SST1 is locked)

- **Owner:** glue-core (R2's fix) and glue-solar (which datasets get linked).
- **Cost:**
  - Quicklook open: 328 / 410 s (4846 / 8542) against 13.6 s for the quicklook alone.
  - Exposure step 3.7-4.4 s against 0.87 s; SJI frame 2.8-3.5 s against 0.042 s; Pixel click 3.6-4.3 s against 0.76 s.
  - RSS 7.9-12.3 GB.
  - SST Pixel moves cost 571-735 ms with IRIS open, against 194-198 ms alone. The hidden IRIS tab redraws on each move (R4, R9).
- **Cause:**
  - glue's subset group puts the SST rectangle on all 10 IRIS datasets. `RoiSubsetState.to_mask` (`glue/core/subset.py:557-564`) evaluates IRIS pixel → world → the SST WCS's world-to-pixel inversion. That inversion is iterative because of the distortion lookup.
  - Main thread: every screen pixel of every panel, 117-144 s in 42 masks, 107-134 ms per call.
  - Profile workers: every value of every window, 91 calls of 3.2-4.0 s.
- **Candidate fix:**
  - R2's fix: one inversion per mask, culled to the region's footprint.
  - glue-solar: link non-IRIS data only on request ('IRIS: link helioprojective coordinates'), or keep foreign subsets off the spectrum panels.
  - Not a faster inversion (R8 decision).
- **Existing coverage:** R2 (extended here to SST → IRIS and to whole-window masks in Profile workers), R4, R9.
- **Evidence:** `scripts/sst.py … --iris sit --wcs-lock --instrument`; `out/s498LI.json`, `out/s8542W.json`.
- **Proposed:** a glue-solar item `wp13-sst-link-scope`.

### SST4. The Profile button on an SST cube reads the whole file, freezes the main thread for about 2/3 of the wait, and adds the whole file to RSS

- **Owner:** glue-core (R14, R21) and glue-qt; a glue-solar workaround is possible.
- **Cost (cold, about 3.3 s per GB):**

  | Cube | Total s | Main-thread freeze s | Other |
  |---|---|---|---|
  | 8542 | 32.5-32.8 | 21.1-21.3 | 9.2-9.4 GB read; RSS 10.3 GB steady, 13.7 GB peak; footprint peak 4.4 GB |
  | 6173 | 21.5 | 14.1 | |
  | 6302 | 17.0 | 11.1 | |
  | 3950 | 9.8 | 6.0 | |
  | 4846 | 2.0-3.3 | 0.7-1.9 | |

- **Cause:**
  - `ProfileViewerState._reset_y_limits` (`glue/viewers/profile/state.py:212`) computes the whole-cube 'maximum' on the main thread: 3 calls, 21.2 s.
  - The worker threads then compute it again (22.6 s across threads).
  - `compute_statistic` copies each 4e7-value chunk to float64 (`glue/core/data.py:1679-1720`, `glue/utils/array.py:483`).
- **Candidate fix:**
  - Upstream: R14 and R21.
  - glue-qt: add the data layer hidden for data of `large_data_size` (1e8) or more, so only subsets compute.
  - glue-solar can apply the hidden-layer default now for non-IRIS cubes, like S13 did for the quicklook.
- **Existing coverage:** R14, R21. The SST-scale I/O and RSS are new.
- **Evidence:** `out/s8542W.json`, phase `profile_viewer`.
- **Proposed:** a glue-solar item `wp10-sst-profile-hidden-data`.

### SST5. SST sessions save but never restore ('HDUList is required'), including glue-solar's autosaved last session

- **Owner:** glue-solar (wp13).
- **Cost:**
  - Save: 8-9 ms, 107-119 KB.
  - Restore fails within 10-12 ms, at 0.35 GB RSS, before any data is read. Confirmed on 8542, 6173, 3950 and obs171.
  - The #206 autosave keeps such a session, so 'IRIS: restore last session' fails as well.
- **Cause:** glue saves the WCS as a header string and reloads it with `WCS(Header)` (`glue/core/state.py:656-663`), without the HDUList. The coordinates are restored before any data, so nothing comes before the error.
- **Candidate fix:** a saver or session patch that rebuilds the WCS from the logged file, passing the file.
- **Existing coverage:** wp13 (known); this confirms it at 10 GB.
- **Evidence:** `scripts/restore.py`; `out/rs8542.json`.
- **Proposed:** add the autosave and 'Restore last session' to wp13's Done-when.

### SST6. Restoring a multi-window stack re-reads every raster file once per window

- **Owner:** glue-solar.
- **Cost:**
  - 3602506433 (7 windows): 49.3 s, of which 38.1 s is data loading with 693 `read_files` calls. The browser loaded the same data in 11.2 s.
  - 3630104144 (8 windows): 70.7 s, of which 56.5 s is data loading with 960 reads, against 12.4 s.
- **Cause:** each window has its own load log (`iris.py:704`). Restoring it calls `raster_files_data` → `_raster_windows_data(files, [window])` (`iris.py:668-707`), which opens every file for that one window.
- **Candidate fix:** read each file once for all logged windows during one restore, either with a session patch that groups the raster logs or with a per-restore cache keyed by (files, stack). Expected about 49 → 12 s.
- **Existing coverage:** none. R20 is about session save size.
- **Evidence:** `scripts/restore.py SESSION NAME --no-profile`; `out/ri3602b.json`, `out/ri3630.json`.
- **Proposed:** a glue-solar item `wp3-restore-one-read`.

### SST7. Each ticked window adds quicklook panels that every step and move redraws: about 4× per step with 9 windows

- **Owner:** glue-solar; glue-core and astropy for the cost of each draw (R1, R5, R18).
- **Cost:**
  - 4000255147 with 1 window: exposure step 207 ms, click 248 ms, move 235 ms, open 4.35 s. With 9 windows: 865-874 ms, 760 ms, 985 ms and 13.6 s.
  - The other multi-window sets show the same pattern: 599-849 ms steps and 742-958 ms moves.
  - Opening the point light curves, row and column on a 9-window quicklook raises a move to 1668 ms.
- **Cause:**
  - `quicklook()` (`glue_solar/quicklook.py:1336`) gives each extra window a spectrum panel and, on sit-and-stare or stacks, a λ-time panel. A step redraws all of them.
  - Measured: 2008 canvas draws over 84 steps with 9 windows against 381 with 1 window (5.3×), at about 17 ms each.
- **Candidate fix:**
  - glue-solar: draw the moving time and point markers as blitted artists, refresh images only when their slice changes, or redraw only the visible rows.
  - Upstream: R1, R5 and R18 shrink each draw.
- **Existing coverage:** R1, R5, R18 cover the per-draw cost; the multiplication by windows is new.
- **Evidence:** `scripts/iris.py … [--windows 'Si IV 1403'] --instrument`; `out/i255147I.json`, `out/i255147one.json`.
- **Proposed:** a glue-solar item `wp4-l-window-rows-redraw`.

### SST8. An SST Pixel drag costs about 194 ms per move, of which about 168 ms is waiting on the Profile worker

- **Owner:** glue-qt and glue-core (R3).
- **Cost:** 194-198 ms per move with the Profile viewer open, 30 ms without it. The worker's own compute is 0.2-0.5 ms per move. The cube-sized boolean mask stays virtual: RSS grows by only 0.02 GB (R7, `glue/core/subset.py:1382`).
- **Candidate fix:** R3.
- **Existing coverage:** R3, R7.
- **Evidence:** `out/s498np.json`, phases `pixel_drag` and `pixel_drag_no_profile`.
- **Proposed:** add these numbers to R3's re-verification.

### SST9. A Path diagram, or any link change, recomputes the region's whole-cube profile

- **Owner:** glue-core (R11).
- **Cost:** Enter takes 0.17-0.19 s, then the settle takes another 5.3 s on 8542, 7.0 s on 6173 and 3.5 s on 3950. On 8542 the worker spends 11.8 s in `compute_statistic`.
- **Cause:** the diagram's links change, so glue drops every linked subset mask (R11) and the rectangle's profile is recomputed over the whole cube.
- **Candidate fix:** R11.
- **Existing coverage:** R11.
- **Evidence:** `out/s8542W.json`, phase `path_diagram`.
- **Proposed:** add to R11.

### SST10. A new Image viewer on a cold SST cube reads 0.3-0.74 GB at random for its Min/Max limits

- **Owner:** glue-core.
- **Cost:** 1.3-2.6 s cold against 0.5-0.6 s warm, with about 10,000 page-ins. On 8542, `compute_statistic` takes 1.21 s.
- **Cause:** `StateAttributeLimitsHelper` (`glue/core/state_objects.py:405-422`) uses 10,000 uniform random indices over all 5 axes (`glue/core/data.py:1849-1851`, `glue/utils/array.py:756`). Each index hits a different page of the memory-mapped file.
- **Candidate fix:** sample whole planes or rows, as glue-solar's `RawComponent._sample` does, or sort the indices by page.
- **Existing coverage:** none.
- **Proposed:** upstream for M4 (`wp0-perf-core`), on your direction.

### SST11. 'Light curves of every window and SJI…' is offered on a single-scan raster with no SJI, then refuses

- **Owner:** glue-solar.
- **Cost:** an error box on 3824262996: '… has no exposures or scans, and its observation no slit-jaw image loaded'.
- **Cause:** `_PointCurvesEntry.offered` (`tools.py:1900` at 4c57625) only checks that the dataset has an IRIS role; `_point_curves` needs exposures, scans or an SJI.
- **Candidate fix:** make `offered` run the same check as `_point_curves`.
- **Evidence:** `out/i3824.json`, dialogs.
- **Proposed:** a small glue-solar fix.

### SST12. File > Open makes 33 datasets per SST cube

- **Owner:** glue-solar (wp13).
- **Cost:** no measurable time. The `WCSDVARR` image looks like data, and about 30 warnings appear.
- **Cause:** `glue/core/data_factories/fits.py:123-168` reads every HDU.
- **Existing coverage:** wp13.
- **Proposed:** decision only: it stays in wp13.

### SST13. A cold sit-and-stare quicklook reads the whole raster file

- **Owner:** none.
- **Cost:** 1.43 of 1.43 GB read for 3660259102. On this SSD a cold open is no slower than a warm one.
- **Cause:** each λ-time panel reads one row of every exposure plane, and readahead pulls in whole planes.
- **Proposed:** decision: no action; only matters on slow or network disks.

### Measured and fine

- SST open: memory-mapped, 0 bytes read.
- SST steps: 17-21 ms warm, 25-39 ms on first visit.
- Playback keeps up with glue-qt's timer.
- Rectangle on an SST cube alone: 0.25-0.28 s.
- Session saves: 8-157 ms.
- No run approached the 20 GB RSS stop: the maximum was 13.7 GB RSS and 4.4 GB footprint.