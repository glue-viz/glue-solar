"""Shared helpers for the SST/IRIS stress survey (measure only; nothing on disk is patched)."""

import ctypes
import json
import os
import statistics
import sys
import threading
import time

ROOT = "/private/tmp/claude-501/-Users-nabil-Git-glue-solar/07d33ef8-b8df-4ddb-b55c-24b6271a724b/scratchpad/sst-stress"
GS = f"{ROOT}/gs"
sys.path.insert(0, GS)  # python -I ignores PYTHONPATH: the detached origin/main worktree goes first by hand
OUT = f"{ROOT}/out"
RSS_LIMIT = 20 * 2**30

# --- macOS proc_pid_rusage (RUSAGE_INFO_V2) -------------------------------------------------------------------------
_libc = ctypes.CDLL("/usr/lib/libSystem.B.dylib")


class _RU(ctypes.Structure):
    _fields_ = [("uuid", ctypes.c_uint8 * 16)] + [(n, ctypes.c_uint64) for n in (
        "user_time", "system_time", "pkg_idle_wkups", "interrupt_wkups", "pageins", "wired_size", "resident_size",
        "phys_footprint", "proc_start_abstime", "proc_exit_abstime", "child_user_time", "child_system_time",
        "child_pkg_idle_wkups", "child_interrupt_wkups", "child_pageins", "child_elapsed_abstime",
        "diskio_bytesread", "diskio_byteswritten")]


def rusage():
    ru = _RU()
    if _libc.proc_pid_rusage(os.getpid(), 2, ctypes.byref(ru)) != 0:
        raise OSError("proc_pid_rusage failed")
    return {"rss": ru.resident_size, "footprint": ru.phys_footprint, "read": ru.diskio_bytesread,
            "written": ru.diskio_byteswritten, "pageins": ru.pageins}


GB = 2**30


class Sampler(threading.Thread):
    """Samples RSS and footprint every 20 ms; peak since the last mark(); kills the run past RSS_LIMIT."""

    def __init__(self, log):
        super().__init__(daemon=True)
        self.log = log
        self.peak_rss = self.peak_fp = 0
        self.lock = threading.Lock()

    def mark(self):
        with self.lock:
            r = rusage()
            self.peak_rss, self.peak_fp = r["rss"], r["footprint"]

    def run(self):
        while True:
            r = rusage()
            with self.lock:
                self.peak_rss = max(self.peak_rss, r["rss"])
                self.peak_fp = max(self.peak_fp, r["footprint"])
            if r["rss"] > RSS_LIMIT:
                self.log.add("ABORT", {"reason": f"RSS {r['rss'] / GB:.2f} GB > 20 GB", "phase": self.log.phase,
                                       "footprint_gb": r["footprint"] / GB})
                self.log.flush()
                os._exit(3)
            time.sleep(0.02)


class Log:
    def __init__(self, name):
        self.name = name
        self.path = f"{OUT}/{name}.json"
        self.rows = {}
        self.phase = "start"
        self.sampler = Sampler(self)
        self.sampler.start()

    def add(self, key, value):
        self.rows[key] = value
        print(f"[{self.name}] {key}: {json.dumps(value, default=str)[:600]}", flush=True)
        self.flush()

    def flush(self):
        with open(self.path, "w") as f:
            json.dump(self.rows, f, indent=1, default=str)

    def begin(self, phase):
        self.phase = phase
        self.sampler.mark()
        self._r0 = rusage()
        self._t0 = time.perf_counter()

    def end(self, extra=None):
        t = time.perf_counter() - self._t0
        r = rusage()
        row = {"s": round(t, 4), "peak_rss_gb": round(self.sampler.peak_rss / GB, 3),
               "peak_footprint_gb": round(self.sampler.peak_fp / GB, 3), "rss_gb": round(r["rss"] / GB, 3),
               "footprint_gb": round(r["footprint"] / GB, 3), "read_gb": round((r["read"] - self._r0["read"]) / GB, 3),
               "pageins": r["pageins"] - self._r0["pageins"],
               "rss_growth_gb": round((r["rss"] - self._r0["rss"]) / GB, 3)}
        if extra:
            row.update(extra)
        self.add(self.phase, row)
        return row


def cached_fraction(path):
    """Fraction of ``path``'s pages in the page cache now (libc mmap + mincore; reads nothing)."""
    size = os.path.getsize(path)
    page = os.sysconf("SC_PAGE_SIZE")
    n = (size + page - 1) // page
    _libc.mmap.restype = ctypes.c_void_p
    _libc.mmap.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_long]
    _libc.mincore.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p]
    _libc.munmap.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
    fd = os.open(path, os.O_RDONLY)
    try:
        addr = _libc.mmap(None, size, 1, 1, fd, 0)  # PROT_READ, MAP_SHARED
        vec = (ctypes.c_ubyte * n)()
        rc = _libc.mincore(addr, size, vec)
        _libc.munmap(addr, size)
    finally:
        os.close(fd)
    import numpy as np

    return float((np.frombuffer(vec, dtype=np.uint8) & 1).mean()) if rc == 0 else None


# --- Qt idle ---------------------------------------------------------------------------------------------------------
def busy(app):
    for tab in app.viewers:
        for viewer in tab:
            if getattr(viewer.figure.canvas, "_draw_pending", False):
                return True
            for layer in viewer.layers:
                if getattr(layer, "is_computing", False):
                    return True
                worker = getattr(layer, "_worker", None)
                if worker is not None and not worker.work_queue.empty():
                    return True
    coord = getattr(app.data_collection, "_solar_coordinator", None)
    return coord is not None and coord._timer.isActive()


def to_idle(app, t, quiet_s=0.03):
    """Seconds from ``t`` until the app went idle (the quiet window that confirms it is not counted)."""
    t1 = time.perf_counter()
    return (t1 - t) + settle(app, quiet_s=quiet_s)


def settle(app, timeout=600.0, quiet_s=0.05):
    """Process events until quiet_s of quiet; returns seconds until the quiet began."""
    from glue_qt.utils import get_qapp

    q = get_qapp()
    t0 = time.perf_counter()
    quiet = None
    while time.perf_counter() - t0 < timeout:
        q.processEvents()
        if busy(app):
            quiet = None
        else:
            quiet = quiet or time.perf_counter()
            if time.perf_counter() - quiet > quiet_s:
                return quiet - t0
        time.sleep(0.001)
    return time.perf_counter() - t0


def med_ms(xs):
    return round(statistics.median(xs) * 1e3, 1) if xs else None


def versions():
    from importlib.metadata import version

    import glue_solar
    import matplotlib
    import numpy
    from qtpy import QT_VERSION, API_NAME

    return {p: version(p) for p in ("glue-core", "glue-qt", "astropy", "irispy-lmsal", "matplotlib", "numpy")} | {
        "qt": QT_VERSION, "qt_api": API_NAME, "glue_solar_file": glue_solar.__file__, "python": sys.version.split()[0]}


DIALOGS = []


def make_app():
    from glue_qt.app import GlueApplication
    from glue_qt.dialogs.autolinker import autolinker as al

    # glue-qt's autolinker dialog is modal; the user's 'Apply' is what we take (counted in the open phase)
    al.AutoLinkPreview.exec = lambda self: (self.accept(), 1)[1]
    al.AutoLinkPreview.exec_ = al.AutoLinkPreview.exec
    from qtpy import QtWidgets

    # every message box answered OK (as a user clicking through), and recorded with its text
    def _exec(self):
        import traceback as tb

        exc = sys.exc_info()[1]
        where = tb.format_exc()[-1500:] if exc is not None else "".join(tb.format_stack(limit=8))[-1500:]
        DIALOGS.append(f"{self.text()} | {self.informativeText()[:200]} | {where}")
        print("DIALOG:", DIALOGS[-1], flush=True)
        return QtWidgets.QMessageBox.StandardButton.Ok

    QtWidgets.QMessageBox.exec = QtWidgets.QMessageBox.exec_ = _exec

    def _dexec(self):  # any other modal dialog (Loop range, Go to UTC, ...): recorded, then cancelled
        DIALOGS.append(f"QDialog {type(self).__name__} {self.windowTitle()} (cancelled)")
        print("DIALOG:", DIALOGS[-1], flush=True)
        return 0

    QtWidgets.QDialog.exec = QtWidgets.QDialog.exec_ = _dexec
    def _item(*a, **k):  # the band width: the widest offered
        items = a[3] if len(a) > 3 else k.get("items")
        DIALOGS.append(f"QInputDialog.getItem {a[1] if len(a) > 1 else ''} -> {items[-1]}")
        return items[-1], True

    QtWidgets.QInputDialog.getItem = staticmethod(_item)
    for name in ("getText", "getInt", "getDouble"):
        setattr(QtWidgets.QInputDialog, name, staticmethod(lambda *a, _n=name, **k: (DIALOGS.append(f"QInputDialog.{_n}"), (None, False))[1]))
    import faulthandler

    faulthandler.enable(all_threads=True)  # a crash shows where, every thread
    faulthandler.dump_traceback_later(900, repeat=True)  # a hung run shows where
    app = GlueApplication()
    app.resize(1600, 1000)
    app.show()
    settle(app)
    import glue_solar
    from glue_qt.viewers.image import ImageViewer

    assert "solar:modes" in ImageViewer.tools, "glue-solar plugin not set up"
    assert glue_solar.__file__.startswith(GS), glue_solar.__file__
    return app


class MouseDriver:
    """Matplotlib mouse events at data positions of a viewer's axes, with the transform taken once per gesture."""

    def __init__(self, viewer):
        self.viewer = viewer

    def _ev(self, name, x, y, button=1):
        from matplotlib.backend_bases import MouseEvent

        canvas = self.viewer.figure.canvas
        px, py = self.viewer.axes.transData.transform((x, y))
        canvas.callbacks.process(name, MouseEvent(name, canvas, px, py, button=button))

    def press(self, x, y):
        self._ev("button_press_event", x, y)

    def move(self, x, y):
        self._ev("motion_notify_event", x, y)

    def release(self, x, y):
        self._ev("button_release_event", x, y)


def key(viewer, k):
    from matplotlib.backend_bases import KeyEvent

    canvas = viewer.figure.canvas
    canvas.callbacks.process("key_press_event", KeyEvent("key_press_event", canvas, k))


def tools_report(viewer):
    """The viewer's toolbar tools and menu entries: offered/enabled/visible as glue-qt shows them now."""
    tb = viewer.toolbar
    out = {}
    for tid, tool in tb.tools.items():
        act = tb.actions.get(tid)
        row = {"enabled": getattr(tool, "enabled", None), "visible": act.isVisible() if act is not None else None}
        offered = getattr(tool, "offered", None)
        if callable(offered):
            try:
                row["offered"] = bool(offered())
            except Exception as e:  # noqa: BLE001
                row["offered"] = f"raises {type(e).__name__}: {e}"
        out[tid] = row
    return out


# --- IRIS: the observation browser's path, without its dialog -------------------------------------------------------
def open_iris(app, root, pattern, stack=False, S=None, windows=None, sjis=True):
    """scan_directory, the browser's _load of the picks, extend + keep_hpc_linked, then the quicklook (browse_iris)."""
    import threading
    from functools import partial

    from glue_solar.sources import iris as si
    from glue_solar.sources.loaders import iris as li
    from glue_solar.sources.loaders.scan import scan_directory

    out = {}
    t = time.perf_counter()
    obs = scan_directory(root, pattern=pattern)
    out["scan_s"] = round(time.perf_counter() - t, 3)
    assert len(obs) == 1, [o.obsid for o in obs]
    o = obs[0]
    picks = [(0, "raster", w) for w in o.windows if windows is None or w in windows]
    if sjis:
        picks += [(0, "sji", k) for k in sorted(o.sji)]
    out["picks"] = [p[2] for p in picks]
    out["n_raster_files"] = len(o.rasters)
    t = time.perf_counter()
    _, loaded, err = li._load(0, obs, picks, stack, partial(si._shown, quicklooks=True), threading.Event(),
                              lambda *a: None)
    out["load_s"] = round(time.perf_counter() - t, 3)
    if err:
        raise RuntimeError(err)
    datasets = [d for *_, ds in loaded for d in ds]
    out["datasets"] = len(datasets)
    out["shapes"] = sorted({(d.label.split("-")[-1][:20], tuple(d.shape)) for d in datasets})[:12]
    out["values_gvalues"] = round(sum(d.size for d in datasets) / 1e9, 3)
    t = time.perf_counter()
    app.data_collection.extend(datasets)
    li.keep_hpc_linked(app.data_collection)
    out["extend_link_s"] = round(time.perf_counter() - t, 3)
    t = time.perf_counter()
    qls = [si.quicklook(app, ds, window=w) for ds, w in si._quicklooks(loaded)]
    out["quicklook_call_s"] = round(time.perf_counter() - t, 3)
    out["quicklook_settle_s"] = round(settle(app, quiet_s=0.1), 3)
    out["links"] = len(app.data_collection.links)
    if S is not None:
        S["ql"] = qls[0]
        S["iris_datasets"] = datasets
    ql = qls[0]
    out["panels"] = {k: (v.state.reference_data.label, list(v.state.reference_data.shape)) for k, v in ql.items()
                     if hasattr(v, "state")}
    return out


def _step(app, viewer, axis, values, quiet=0.03):
    times = []
    for v in values:
        s = list(viewer.state.slices)
        s[axis] = int(v)
        t = time.perf_counter()
        viewer.state.slices = tuple(s)
        times.append(to_idle(app, t, quiet))
    return times


def iris_steps(app, ql, n=10):
    """Median ms per slider step of each quicklook panel: a first pass over n spread positions, then a repeat."""
    import numpy as np

    out = {}
    panels = [(k, ql[k]) for k in ("map", "spectrogram", "wavelength") if k in ql]
    panels += [(f"sji{i}", v) for i, v in enumerate(ql.get("sji", []))]
    for name, v in panels:
        d = v.state.reference_data
        for axis in [a for a in range(d.ndim) if a not in (v.state.x_att.axis, v.state.y_att.axis)]:
            size = d.shape[axis]
            if size < 2:
                continue
            start = v.state.slices[axis]
            vals = [int(i) for i in np.linspace(0, size - 1, min(n, size))]
            first = _step(app, v, axis, vals)
            again = _step(app, v, axis, vals)
            out[f"{name}[{axis}]"] = {"n": size, "first_ms": med_ms(first[1:]), "warm_ms": med_ms(again[1:]),
                                      "max_ms": round(max(first) * 1e3, 1)}
            _step(app, v, axis, [start])
    out["rss_gb"] = round(rusage()["rss"] / GB, 3)
    return out


def iris_drag(app, ql, moves=10):
    """Pixel click and drag on the quicklook map: ms per click and per move to idle."""
    v = ql["map"]
    v.toolbar.active_tool = "image:point_selection"
    v.figure.canvas.draw()
    m = MouseDriver(v)
    d = v.state.reference_data
    ny, nx = d.shape[v.state.y_att.axis], d.shape[v.state.x_att.axis]
    x, y = nx // 3, ny // 3
    t = time.perf_counter()
    m.press(x, y)
    m.release(x, y)
    click = to_idle(app, t)
    m.press(x, y)
    settle(app)
    ts = []
    for i in range(1, moves + 1):
        t = time.perf_counter()
        m.move(x + (i % max(1, nx - x - 1)), y + i)
        ts.append(to_idle(app, t))
    m.release(x, y)
    settle(app)
    return {"click_ms": round(click * 1e3, 1), "move_ms": med_ms(ts[1:]), "max_ms": round(max(ts) * 1e3, 1),
            "rss_gb": round(rusage()["rss"] / GB, 3)}


def lock_fits_wcs():
    """
    Harness emulation of a candidate fix: every astropy WCS transform and every FITS-WCS API property (each reads
    the Wcsprm) under glue-solar's re-entrant WCS_LOCK, as glue-solar's _GlueWCS holds it for IRIS data.
    """
    from astropy.wcs import WCS
    from glue_solar.sources.loaders.iris import WCS_LOCK

    for name in ("all_pix2world", "all_world2pix", "wcs_pix2world", "wcs_world2pix", "pixel_to_world_values",
                 "world_to_pixel_values", "sub", "deepcopy"):
        f = getattr(WCS, name)

        def w(self, *a, _f=f, **k):
            with WCS_LOCK:
                return _f(self, *a, **k)

        setattr(WCS, name, w)
    for name in ("axis_correlation_matrix", "world_axis_physical_types", "world_axis_units", "world_axis_names",
                 "world_axis_object_components", "world_axis_object_classes", "pixel_n_dim", "world_n_dim",
                 "array_shape", "pixel_shape", "pixel_bounds", "has_distortion"):
        prop = getattr(WCS, name)

        def get(self, _g=prop.fget):
            with WCS_LOCK:
                return _g(self)

        setattr(WCS, name, property(get, prop.fset))


class Instr:
    """Cumulative wall time and calls of wrapped functions, main thread and worker threads apart."""

    def __init__(self):
        from collections import defaultdict

        self.t = defaultdict(float)
        self.n = defaultdict(int)
        self.main = threading.get_ident()

    def wrap(self, owner, attr, key=None):
        import functools

        orig = getattr(owner, attr)
        key = key or f"{getattr(owner, '__name__', owner)}.{attr}"
        me = self

        @functools.wraps(orig)
        def w(*a, **k):
            name = key if threading.get_ident() == me.main else "worker " + key
            t = time.perf_counter()
            try:
                return orig(*a, **k)
            finally:
                me.t[name] += time.perf_counter() - t
                me.n[name] += 1

        setattr(owner, attr, w)

    def reset(self):
        self.t.clear()
        self.n.clear()

    def report(self, per=1):
        return {k: [round(self.t[k] * 1e3 / per, 1), round(self.n[k] / per, 2)] for k in sorted(self.t, key=lambda k: -self.t[k])}


def standard_instr():
    """The survey's code boundaries: draws, buffers, statistics, masks, profiles, WCS calls, glue-solar's hooks."""
    from astropy.wcs import WCS
    from glue.core.data import Data
    from glue.core import subset as gsub
    from glue.viewers.profile.state import ProfileLayerState, ProfileViewerState
    from glue_qt.viewers.matplotlib.widget import MplCanvas

    I = Instr()
    I.wrap(MplCanvas, "draw", "MplCanvas.draw")
    I.wrap(Data, "compute_fixed_resolution_buffer")
    I.wrap(Data, "compute_statistic")
    I.wrap(gsub.SliceSubsetState, "to_mask")
    I.wrap(gsub.RoiSubsetState, "to_mask")
    I.wrap(ProfileLayerState, "update_profile")
    I.wrap(ProfileViewerState, "_reset_y_limits")
    for name in ("all_pix2world", "all_world2pix", "wcs_pix2world", "wcs_world2pix"):
        I.wrap(WCS, name, f"WCS.{name}")
    try:
        from glue.viewers.image.viewer import MatplotlibImageMixin

        I.wrap(MatplotlibImageMixin, "_set_wcs", "_set_wcs")
    except Exception:  # noqa: BLE001
        pass
    return I
