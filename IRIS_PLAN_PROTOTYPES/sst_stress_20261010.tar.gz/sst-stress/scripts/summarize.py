"""Collect out/*.json into numbers.json (step and move times of runs before the harness fix lose the 30 ms quiet window)."""
import json
import os

OUT = "/private/tmp/claude-501/-Users-nabil-Git-glue-solar/07d33ef8-b8df-4ddb-b55c-24b6271a724b/scratchpad/sst-stress/out"
ROOT = os.path.dirname(OUT)
OLD = {"s495", "s6302", "s6173", "s8542", "s167", "s167F", "s171F", "s498L", "s498LI", "s498"}  # +30 ms per step


def load(name):
    p = f"{OUT}/{name}.json"
    return json.load(open(p)) if os.path.exists(p) else None


def ms(name, v):
    return None if v is None else round(v - 30.0, 1) if name in OLD else v


def sst(name, cube, restore=None):
    d = load(name)
    if d is None:
        return None
    g = lambda k: d.get(k) or {}  # noqa: E731
    o1, o2, iv, pv, st = g("open_load_data"), g("open_add_datasets"), g("image_viewer"), g("profile_viewer"), g("slider_steps")
    main = (o1.get("datasets") or [{}])[0]
    row = {
        "run": name, "cube": cube, "file": g("cache_before").get("cube"), "size_gb": g("cache_before").get("size_gb"),
        "cached_fraction_before": g("cache_before").get("cached_fraction"),
        "shape_numpy": main.get("shape"), "dtype": main.get("dtype"), "memmap": main.get("memmap"),
        "factory": (o1.get("find_factory") or {}).get("factory"), "n_datasets": o1.get("n_datasets"),
        "open_s": round((o1.get("s") or 0) + (o2.get("s") or 0), 3), "open_read_gb": o1.get("read_gb"),
        "open_rss_gb": o2.get("rss_gb"), "viewer": None if "error" in iv else {
            "s": iv.get("s"), "read_gb": iv.get("read_gb"), "pageins": iv.get("pageins"), "rss_gb": iv.get("rss_gb"),
            "peak_rss_gb": iv.get("peak_rss_gb")},
        "viewer_error": iv.get("error"),
        "steps_ms": {k: {"first": ms(name, v.get("first_ms")), "warm": ms(name, v.get("warm_ms")), "n": v.get("n")}
                     for k, v in st.items() if isinstance(v, dict) and "n" in v and v.get("first_ms") is not None},
        "steps_read_gb": st.get("read_gb"), "steps_rss_growth_gb": st.get("rss_growth_gb"),
        "playback": {k: g("playback").get(k) for k in ("timer_ms", "fps", "fast_timer_ms", "fast_fps", "solar_loop_bounce_fps")},
        "profile": None if not pv or "error" in pv else {
            "s": pv.get("s"), "main_thread_s": pv.get("activate_s"), "read_gb": pv.get("read_gb"), "rss_gb": pv.get("rss_gb"),
            "peak_rss_gb": pv.get("peak_rss_gb"), "peak_footprint_gb": pv.get("peak_footprint_gb")},
        "pixel_click_s": g("pixel_click").get("s"), "drag_ms": ms(name, g("pixel_drag").get("move_ms")),
        "steps_with_pixel_ms": {k: ms(name, v) for k, v in g("slider_with_pixel").items() if k in ("time", "stokes", "wavelength")},
        "roi": {k: g("roi").get(k) for k in ("apply_s", "settle_s", "move_settle_s")} | {"step_with_roi_ms": ms(name, g("roi").get("step_with_roi_ms"))},
        "path": {k: g("path_diagram").get(k) for k in ("enter_s", "settle_s", "diagrams")} | {"diagram_step_ms": ms(name, g("path_diagram").get("diagram_step_ms"))},
        "tools": {"coordinate_entries_offered": g("solar_tools").get("coordinate_entries"),
                  "view": {k: {**v, "step_ms": ms(name, v.get("step_ms"))} for k, v in (g("solar_tools").get("view") or {}).items()}},
        "session_save": {k: g("session_save").get(k) for k in ("save_s", "size_kb")},
        "final_rss_gb": g("done").get("rss_gb"), "max_rss_gb": g("done").get("max_rss_gb"),
    }
    if restore and load(restore):
        r = load(restore)["restore"]
        row["restore"] = {"s": r["s"], "error": r["error"], "peak_rss_gb": r["peak_rss_gb"]}
    return row


def iris(name, label, restore=None):
    d = load(name)
    if d is None:
        return None
    op = d["open"]
    row = {"run": name, "observation": label, "files": d["cache_before"]["files"], "size_gb": d["cache_before"]["size_gb"],
           "cached_fraction_before": d["cache_before"]["cached_fraction"],
           "open": {k: op.get(k) for k in ("s", "scan_s", "load_s", "quicklook_call_s", "quicklook_settle_s", "read_gb",
                                            "rss_gb", "peak_rss_gb", "footprint_gb", "datasets", "values_gvalues", "picks")},
           "steps_ms": {k: v for k, v in d.get("steps", {}).items() if isinstance(v, dict)},
           "pixel": {k: d.get("pixel", {}).get(k) for k in ("click_ms", "move_ms")},
           "roi": {k: d.get("roi", {}).get(k) for k in ("apply_s", "settle_s", "sji0_step_ms", "map_step_ms")} if "roi" in d else None,
           "tools_ran": d.get("solar_tools", {}).get("ran"), "pixel_after_curves": d.get("solar_tools", {}).get("pixel_after"),
           "path": {k: {kk: vv for kk, vv in v.items() if kk in ("enter_s", "settle_s")} for k, v in d.get("path", {}).items()
                    if isinstance(v, dict) and "enter_s" in v},
           "session_save": {k: d.get("session_save", {}).get(k) for k in ("save_s", "size_kb")},
           "final_rss_gb": d.get("done", {}).get("rss_gb")}
    if restore and load(restore):
        r = load(restore)["restore"]
        row["restore"] = {"s": r["s"], "error": r["error"], "peak_rss_gb": r["peak_rss_gb"],
                          "instr_ms_calls": r.get("instr_ms_calls")}
    return row


numbers = {
    "harness": {"scripts": f"{ROOT}/scripts", "raw": OUT,
                "note": "runs in OLD had each step/move time include the harness's 30 ms quiet window; it is subtracted here "
                        "(checked: s498noroi, after the fix, gives 16 ms warm steps and 196 ms drags against 47-30 and 226-30)",
                "old_runs": sorted(OLD)},
    "versions": (load("s8542") or {}).get("startup", {}).get("versions"),
    "sst": {
        "8542 (obs492 CRISP Ca II 8542 Stokes)": sst("s8542", "nb_8542", "rs8542"),
        "6173 (obs492 CRISP Fe I 6173 Stokes)": sst("s6173", "nb_6173", "rs6173"),
        "6302 (obs492 CRISP Fe I 6302 Stokes)": sst("s6302", "nb_6302"),
        "3950 (obs495 CHROMIS Ca II K)": sst("s495", "nb_3950", "rs495"),
        "4846 (obs498 CHROMIS H-beta)": sst("s498L", "nb_4846"),
        "6173 2020 (obs167, as opened)": sst("s167", "nb_6173_2020"),
        "6173 2020 (obs167, SPECSYS set in memory)": sst("s167F", "nb_6173_2020"),
        "6563 2020 (obs171, SPECSYS set in memory)": sst("s171F", "nb_6563_2020", "restore171"),
        "8542 warm re-run (new harness, instrumented)": sst("s8542W", "nb_8542"),
        "4846 warm re-run (new harness, beside, no ROI, no lock)": sst("s498noroi", "nb_4846"),
        "4846 warm, drag with and without the Profile viewer": sst("s498np", "nb_4846"),
    },
    "iris": {
        "4000255147 sit-and-stare, 9 windows + SJI 1400": iris("i255147", "4000255147", "ri255147b"),
        "4000255147 instrumented": iris("i255147I", "4000255147"),
        "4000255147 Si IV 1403 + SJI 1400, drag with point curves open": iris("i255147c", "4000255147"),
        "4000255147 Si IV 1403 + SJI 1400 only": iris("i255147one", "4000255147", "ri255147oneb"),
        "3660259102 sit-and-stare, 9 windows": iris("i3660", "3660259102", "ri3660b"),
        "3824262996 dense 400-step raster, 8 windows": iris("i3824", "3824262996", "ri3824b"),
        "3602506433 99-scan stack, 7 windows": iris("i3602", "3602506433", "ri3602b"),
        "3630104144 120-scan stack, 8 windows (extracted, deleted after)": iris("i3630", "3630104144", "ri3630"),
        "4000005156 2-scan stack, 9 windows + SJI 2796 deconvolved": iris("i5156", "4000005156", "ri5156b"),
    },
    "beside": {},
}
for name in ("s498", "s8542", "s498noroi", "s498L", "s498LI", "s8542W"):
    d = load(name)
    if d is None:
        continue
    log = open(f"{OUT}/{name}.log").read()
    row = {"exit": log.strip().splitlines()[-1], "crash": "Fatal Python error" in log,
           "lock": d.get("startup", {}).get("wcs_lock")}
    for k in ("iris_open", "iris_steps", "iris_pixel_drag", "iris_without_sst_roi", "sst_with_iris"):
        if k in d:
            row[k] = {kk: vv for kk, vv in d[k].items() if kk not in ("shapes", "panels", "picks", "instr_ms_calls", "traceback")}
            if name in OLD and k in ("iris_steps", "iris_pixel_drag", "iris_without_sst_roi"):
                def fix(v):
                    if isinstance(v, dict):
                        return {a: (round(b - 30.0, 1) if a in ("first_ms", "warm_ms", "max_ms", "click_ms", "move_ms")
                                    and isinstance(b, (int, float)) else fix(b)) for a, b in v.items()}
                    return v
                row[k] = fix(row[k])
            if name in OLD and k == "sst_with_iris":
                row[k] = {kk: (ms(name, vv) if kk in ("time", "stokes", "wavelength", "sst_pixel_move_ms") else vv)
                          for kk, vv in row[k].items()}
    numbers["beside"][name] = row
np_ = load("s498np")
if np_:
    numbers["checks"] = {"drag_with_profile_ms": np_["pixel_drag"]["move_ms"],
                         "drag_without_profile_ms": np_["pixel_drag_no_profile"]["move_ms"],
                         "instr_with": np_["pixel_drag"].get("instr_ms_calls"),
                         "instr_without": np_["pixel_drag_no_profile"].get("instr_ms_calls")}
for name in ("s8542W", "s498LI", "i255147I", "i255147one"):
    d = load(name)
    if d:
        numbers.setdefault("instrumented", {})[name] = {k: v.get("instr_ms_calls") for k, v in d.items()
                                                         if isinstance(v, dict) and v.get("instr_ms_calls")}
numbers["crashes"] = {n: numbers["beside"].get(n, {}).get("exit") for n in ("s498", "s8542", "s498noroi")}
json.dump(numbers, open(f"{ROOT}/numbers.json", "w"), indent=1, default=str)
print("ok", os.path.getsize(f"{ROOT}/numbers.json"))
