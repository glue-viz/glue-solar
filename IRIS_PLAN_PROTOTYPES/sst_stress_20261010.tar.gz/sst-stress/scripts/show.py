import json, sys
d = json.load(open(sys.argv[1]))
for k, v in d.items():
    if isinstance(v, dict):
        v = {a: b for a, b in v.items() if a not in ('tools', 'datasets', 'traceback', 'versions', 'toolbar', 'profile_top')}
    print(k, json.dumps(v)[:int(sys.argv[2]) if len(sys.argv) > 2 else 900])
