import sys, glob
from astropy.io import fits
for p in sys.argv[1:]:
    with fits.open(p) as h:
        h0 = h[0].header
        print('==', p.split('/')[-1][:40], 'nhdu', len(h))
        print('  NAXIS', [h0.get(f'NAXIS{i}') for i in range(1, h0['NAXIS']+1)], 'BITPIX', h0['BITPIX'], 'CTYPE', [h0.get(f'CTYPE{i}') for i in range(1, h0['NAXIS']+1)])
        print('  BLANK', h0.get('BLANK'), 'BSCALE', h0.get('BSCALE'), 'BUNIT', h0.get('BUNIT'), 'PS', [k for k in h0 if k.startswith('PS')][:12])
        for i, e in enumerate(h[1:], 1):
            print('   ', i, type(e).__name__, e.name, e.header.get('NAXIS'), [e.header.get(f'NAXIS{j}') for j in range(1, (e.header.get('NAXIS') or 0)+1)], e.header.get('BITPIX'))
