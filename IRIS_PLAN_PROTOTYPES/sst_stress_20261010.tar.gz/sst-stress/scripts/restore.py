"""Restore a saved glue session in a fresh process: time, RSS and what happens (measure only)."""
import cProfile, os, sys, time, traceback, warnings, pstats, io
warnings.simplefilter("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common as C

session, name = sys.argv[1], sys.argv[2]
PROFILE = "--no-profile" not in sys.argv
log = C.Log(name)
log.begin("startup")
from glue_qt.app import GlueApplication
from glue_qt.dialogs.autolinker import autolinker as al
al.AutoLinkPreview.exec = lambda self: (self.accept(), 1)[1]
C.make_app  # noqa: B018 (dialog patches are applied inside make_app; restore makes its own app)
app0 = C.make_app()
log.end()
import irispy.io
I = C.Instr()
I.wrap(irispy.io, "read_files", "irispy.io.read_files")
from glue.core.data_factories import helpers as dfh
I.wrap(dfh, "load_data", "glue load_data (LoadLog)")
from glue.core import state as gstate
I.wrap(gstate, "_load_data_collection_4", "_load_data_collection_4")
log.begin("restore")
prof = cProfile.Profile()
err = None
if PROFILE:
    prof.enable()
try:
    app = GlueApplication.restore_session(session)
    app.resize(1600, 1000)
    app.show()
    C.settle(app)
except Exception as e:  # noqa: BLE001
    err = f"{type(e).__name__}: {e}"
    tb = traceback.format_exc()
prof.disable()
s = io.StringIO()
if PROFILE:
    pstats.Stats(prof, stream=s).sort_stats("cumulative").print_stats(18)
row = {"instr_ms_calls": I.report(), "error": err, "traceback": tb[-2500:] if err else None, "profile_top": s.getvalue()[-6000:],
       "dialogs": C.DIALOGS}
if not err:
    row["n_data"] = len(app.data_collection)
    row["viewers"] = [type(v).__name__ for tab in app.viewers for v in tab]
log.end(row)
sys.stdout.flush()
os._exit(0)
