#!/bin/bash
R=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/07d33ef8-b8df-4ddb-b55c-24b6271a724b/scratchpad/sst-stress
I=/Users/nabil/DATA/IRIS
cd $R/scripts
log() { echo "$1 $(date +%T) $(df -g /Users/nabil/DATA | tail -1 | awk '{print $4 " GB free"}')" >> $R/out/batch2.txt; }
for s in s8542 s6173 s495; do log "restore $s"; ./runr.sh r$s $R/home/$s.glu; done
log "i255147"; ./runi.sh i255147 $I "*4000255147*"
log "i3824"; ./runi.sh i3824 $I "*3824262996*"
log "i3660"; ./runi.sh i3660 $I "*3660259102*"
log "i5156"; ./runi.sh i5156 $I "*4000005156*" --stack
log "i3602"; ./runi.sh i3602 $I "*3602506433*" --stack
for s in i255147 i3824 i5156 i3602; do log "restore $s"; ./runr.sh r$s $R/home/$s.glu; done
log "batch2 done"
