"""
Stress one SST SOLARNET cube through glue's own File > Open path and an Image viewer (measure only).

usage: python -I sst.py CUBE NAME [--iris] [--skip PHASES] [--profile PHASE]
Writes out/NAME.json; one big cube per process.
"""

import argparse
import cProfile
import glob
import os
import shutil
import sys
import time
import traceback
import warnings

warnings.filterwarnings('ignore', message='Dropping column')

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common as C  # noqa: E402  (puts the worktree first on sys.path)

ap = argparse.ArgumentParser()
ap.add_argument("cube")
ap.add_argument("name")
ap.add_argument("--iris", default="", help="add an IRIS quicklook beside: sit (4000255147) or stack (4000005156)")
ap.add_argument("--skip", default="")
ap.add_argument("--profile", default="", help="cProfile these phases (comma list) into out/NAME-PHASE.prof")
ap.add_argument("--drag", type=int, default=12)
ap.add_argument("--wcs-lock", action="store_true", help="harness emulation: astropy WCS calls under WCS_LOCK")
ap.add_argument("--instrument", action="store_true", help="per-phase timers at the survey's code boundaries")
ap.add_argument("--fix-specsys", action="store_true", help="harness workaround: SPECSYS=TOPOCENT in memory")
args = ap.parse_args()
SKIP = set(args.skip.split(","))
PROFILE = set(args.profile.split(","))
log = C.Log(args.name)
log.add("cache_before", {"cube": args.cube, "cached_fraction": C.cached_fraction(args.cube),
                         "size_gb": os.path.getsize(args.cube) / C.GB})


def phase(name):
    """Decorator-ish runner: begin/end, errors recorded, optional cProfile."""
    def run(fn):
        if name in SKIP:
            return None
        log.begin(name)
        if INSTR is not None:
            INSTR.reset()
        prof = cProfile.Profile() if name in PROFILE else None
        try:
            if prof:
                prof.enable()
            extra = fn() or {}
        except Exception as e:  # noqa: BLE001
            extra = {"error": f"{type(e).__name__}: {e}", "traceback": traceback.format_exc()[-3000:]}
        finally:
            if prof:
                prof.disable()
                prof.dump_stats(f"{C.OUT}/{args.name}-{name}.prof")
        if INSTR is not None:
            extra["instr_ms_calls"] = INSTR.report()
        return log.end(extra)
    return run


INSTR = None
import numpy as np  # noqa: E402
from glue.core.data_factories import helpers as dfh  # noqa: E402
from glue.core.data_factories.helpers import auto_data, load_data  # noqa: E402
from glue.core.roi import RectangularROI  # noqa: E402
from glue_qt.utils import get_qapp  # noqa: E402
from glue_qt.viewers.image import ImageViewer  # noqa: E402

log.begin("startup")
app = C.make_app()
if args.wcs_lock:
    C.lock_fits_wcs()
if args.instrument:
    INSTR = C.standard_instr()
log.end({"versions": C.versions(), "wcs_lock": args.wcs_lock})
qapp = get_qapp()
S = {}  # shared state between phases

# which factory glue picks, and how long identification takes (the data wizard's 'Auto' calls find_factory)
_find = dfh.find_factory


def find_factory(*a, **k):
    t = time.perf_counter()
    f = _find(*a, **k)
    S["find_factory"] = {"s": round(time.perf_counter() - t, 4), "factory": getattr(f, "__name__", str(f))}
    return f


dfh.find_factory = find_factory


def is_memmap(arr):
    while arr is not None:
        if isinstance(arr, np.memmap) or type(arr).__name__ == "mmap":
            return True
        arr = getattr(arr, "base", None)
    return False


@phase("open_load_data")
def _():
    datasets = load_data(args.cube, factory=auto_data)  # the data wizard with 'Auto' selected
    datasets = datasets if isinstance(datasets, list) else [datasets]
    S["datasets"] = datasets
    rows = []
    for d in datasets:
        c = d.get_component(d.main_components[0]) if d.main_components else None
        arr = getattr(c, "_data", None)
        rows.append({"label": d.label.split("[")[-1], "shape": list(d.shape), "ndim": d.ndim,
                     "n_main": len(d.main_components), "coords": type(d.coords).__name__,
                     "dtype": str(getattr(arr, "dtype", None)), "memmap": is_memmap(arr)})
    return {"find_factory": S.get("find_factory"), "n_datasets": len(datasets), "datasets": rows,
            "cached_fraction_after": C.cached_fraction(args.cube)}


@phase("open_add_datasets")
def _():
    from glue_qt.dialogs.autolinker import autolinker as al

    found = {}
    _fpl = al.find_possible_links

    def fpl(dc):
        t = time.perf_counter()
        r = _fpl(dc)
        found.update({"s": round(time.perf_counter() - t, 3), "suggested": {k: len(v) for k, v in r.items()}})
        return r

    al.find_possible_links = fpl
    app.add_datasets(S["datasets"])  # File > Open: extend, then glue-qt's autolinker (its dialog answered Apply)
    t_settle = C.settle(app)
    al.find_possible_links = _fpl
    S["cube"] = max(S["datasets"], key=lambda d: d.size)
    return {"autolink": found, "links": len(app.data_collection.links), "settle_s": round(t_settle, 3)}


cube = S.get("cube")
if cube is None:
    log.add("FATAL", "no cube")
    os._exit(1)
log.add("cache_after_open", {"cached_fraction": C.cached_fraction(args.cube)})
if args.fix_specsys:
    for d in S["datasets"]:
        if getattr(d.coords, "wcs", None) is not None and not d.coords.wcs.specsys:
            d.coords.wcs.specsys = "TOPOCENT"
    log.add("workaround", "SPECSYS set to TOPOCENT in memory on every dataset's WCS (not a glue path)")


@phase("image_viewer")
def _():
    t = time.perf_counter()
    viewer = app.new_data_viewer(ImageViewer, data=cube)
    t_new = time.perf_counter() - t
    t_settle = C.settle(app)
    S["iv"] = viewer
    st = viewer.state
    lay = viewer.layers[0].state
    return {"new_s": round(t_new, 3), "settle_s": round(t_settle, 3), "slices": list(st.slices),
            "x_att": str(st.x_att), "y_att": str(st.y_att), "v_min": float(lay.v_min), "v_max": float(lay.v_max),
            "percentile": lay.percentile, "canvas": [viewer.figure.canvas.width(), viewer.figure.canvas.height()],
            "tools": C.tools_report(viewer)}


iv = S.get("iv")
log.add("cache_after_viewer", {"cached_fraction": C.cached_fraction(args.cube)})


def step_axis(viewer, axis, values):
    times = []
    for v in values:
        s = list(viewer.state.slices)
        s[axis] = int(v)
        t = time.perf_counter()
        viewer.state.slices = tuple(s)
        times.append(C.to_idle(app, t))
    return times


SLIDER_AXES = [a for a in range(cube.ndim) if a not in (iv.state.x_att.axis, iv.state.y_att.axis)] if iv else []
NAMES = {0: "time", 1: "stokes", 2: "wavelength"} if cube.ndim == 5 else {}


@phase("slider_steps")
def _():
    out = {}
    for axis in SLIDER_AXES:
        n = cube.shape[axis]
        if n < 2:
            out[NAMES.get(axis, axis)] = {"n": n}
            continue
        start = list(iv.state.slices)[axis]
        first = step_axis(iv, axis, [i for i in range(n) if i != start])  # first visits of each slice
        again = step_axis(iv, axis, list(range(n)) * max(1, 12 // n))  # revisits, page cache warm
        out[NAMES.get(axis, axis)] = {"n": n, "first_ms": C.med_ms(first), "first_max_ms": round(max(first) * 1e3, 1),
                                      "warm_ms": C.med_ms(again[2:]), "rss_gb": round(C.rusage()["rss"] / C.GB, 3)}
        step_axis(iv, axis, [start])
    return out


@phase("playback")
def _():
    # glue-qt's slider playback: forward x5 = 100 ms timer, on the time slider (axis 0), for 6 s
    from glue_qt.viewers.common.data_slice_widget import SliceWidget

    axis = SLIDER_AXES[0]
    w = iv.options_widget().slice_helper._sliders[0]  # the time slider (axis 0), glue-solar's _first_slider
    draws = []
    cid = iv.figure.canvas.mpl_connect("draw_event", lambda e: draws.append(time.perf_counter()))
    seen = []
    iv.state.add_callback("slices", lambda s: seen.append(s[axis]))
    for _ in range(5):
        w._adjust_play("forw")
    t0 = time.perf_counter()
    while time.perf_counter() - t0 < 6:
        qapp.processEvents()
        time.sleep(0.001)
    w._adjust_play("stop")
    C.settle(app)
    n100 = len(draws)
    for _ in range(20):  # 500/25 = 20 ms timer
        w._adjust_play("forw")
    fast_ms = w._play_timer.interval()
    t1 = time.perf_counter()
    while time.perf_counter() - t1 < 4:
        qapp.processEvents()
        time.sleep(0.001)
    w._adjust_play("stop")
    C.settle(app)
    fast_fps = round((len(draws) - n100) / 4, 2)
    # glue-solar's Coordinate > Loop... as the user's OK would set it: every index, bounce, at the 100 ms timer
    from glue_solar import tools as T

    T._loop(w, 0, cube.shape[axis] - 1, 1, True)
    n_fast = len(draws)
    for _ in range(5):
        w._adjust_play("forw")
    t2 = time.perf_counter()
    while time.perf_counter() - t2 < 3:
        qapp.processEvents()
        time.sleep(0.001)
    w._adjust_play("stop")
    C.settle(app)
    loop_fps = round((len(draws) - n_fast) / 3, 2)
    draws = draws[:n100]
    iv.figure.canvas.mpl_disconnect(cid)
    d = np.diff(draws)
    return {"widget": w.label if hasattr(w, "label") else None, "timer_ms": w._play_timer.interval(),
            "slice_changes": len(seen), "draws": len(draws), "fps": round(len(draws) / 6, 2),
            "draw_interval_med_ms": C.med_ms(list(d)) if len(d) else None, "fast_timer_ms": fast_ms, "fast_fps": fast_fps,
            "solar_loop_bounce_fps": loop_fps, "slider_label": getattr(w, "_label", None) and w._label.text()}


@phase("profile_viewer")
def _():
    # glue-qt's Profile viewer button, as the user clicks it (its info dialog answered OK)
    from glue_qt.viewers.profile import ProfileViewer

    changes = []
    tool = iv.toolbar.tools["profile-viewer"]
    t = time.perf_counter()
    tool.activate()
    t_act = time.perf_counter() - t
    t_settle = C.settle(app)
    pv = [v for tab in app.viewers for v in tab if isinstance(v, ProfileViewer)][-1]
    S["pv"] = pv
    return {"activate_s": round(t_act, 3), "settle_s": round(t_settle, 3), "x_att": str(pv.state.x_att),
            "function": pv.state.function, "x_changes": changes}


pv = S.get("pv")


@phase("pixel_click")
def _():
    iv.toolbar.active_tool = "image:point_selection"
    m = C.MouseDriver(iv)
    iv.figure.canvas.draw()
    ny, nx = cube.shape[iv.state.y_att.axis], cube.shape[iv.state.x_att.axis]
    S["xy"] = (nx // 2, ny // 2)
    t = time.perf_counter()
    m.press(*S["xy"])
    t_press = time.perf_counter() - t
    t_settle = C.settle(app)
    m.release(*S["xy"])
    C.settle(app)
    return {"press_s": round(t_press, 3), "settle_s": round(t_settle, 3), "subsets": len(app.data_collection.subset_groups)}


@phase("pixel_drag")
def _():
    m = C.MouseDriver(iv)
    x, y = S["xy"]
    m.press(x, y)
    C.settle(app)
    times = []
    for i in range(1, args.drag + 1):
        t = time.perf_counter()
        m.move(x + 3 * i, y + 2 * i)
        times.append(C.to_idle(app, t))
    m.release(x + 3 * args.drag, y + 2 * args.drag)
    C.settle(app)
    return {"move_ms": C.med_ms(times[2:]), "first_ms": round(times[0] * 1e3, 1), "max_ms": round(max(times) * 1e3, 1)}


@phase("slider_with_pixel")
def _():
    out = {}
    for axis in SLIDER_AXES:
        n = cube.shape[axis]
        if n < 2:
            continue
        ts = step_axis(iv, axis, list(range(n)) * max(1, 8 // n))
        out[NAMES.get(axis, axis)] = C.med_ms(ts[1:])
        step_axis(iv, axis, [0])
    return out


@phase("roi")
def _():
    iv.toolbar.active_tool = None
    x, y = S["xy"]
    app.session.edit_subset_mode.edit_subset = []  # a new subset, as a fresh rectangle drag makes
    t = time.perf_counter()
    iv.apply_roi(RectangularROI(x - 100, x + 100, y - 100, y + 100))
    t_apply = time.perf_counter() - t
    t_settle = C.settle(app)
    sub = app.data_collection.subset_groups[-1]
    S["roi_group"] = sub
    # move the same subset (edit it), as a drag of the ROI would
    t2 = time.perf_counter()
    app.session.edit_subset_mode.edit_subset = [sub]
    iv.apply_roi(RectangularROI(x - 80, x + 120, y - 90, y + 110))
    t_move_apply = time.perf_counter() - t2
    t_move = C.settle(app)
    steps = step_axis(iv, SLIDER_AXES[-1], [1, 2, 3, 4, 1, 2]) if SLIDER_AXES else []
    return {"apply_s": round(t_apply, 3), "settle_s": round(t_settle, 3), "move_apply_s": round(t_move_apply, 3),
            "move_settle_s": round(t_move, 3), "step_with_roi_ms": C.med_ms(steps[1:]),
            "n_groups": len(app.data_collection.subset_groups)}


@phase("solar_tools")
def _():
    from glue_solar import tools as T

    out = {"toolbar": C.tools_report(iv)}
    coord = iv.toolbar.tools.get("solar:coordinate")
    if coord is not None:
        out["coordinate_entries"] = {e.tool_id: bool(e.offered()) for e in coord.subtools}
    # each View display tool: toggle on, one wavelength step, toggle off
    view = {}
    for tid in ["solar:frame_time", "solar:hide_axes", "solar:per_frame_limits", "solar:band",
                "solar:physical_aspect", "solar:zoom_1_1", "solar:colour_bar"]:
        tool = iv.toolbar.tools.get(tid)
        if tool is None:
            continue
        row = {"enabled": getattr(tool, "enabled", None)}
        if row["enabled"] is False:
            view[tid] = row
            continue
        try:
            act = iv.toolbar.actions[tid]
            t = time.perf_counter()
            act.trigger()
            row["on_s"] = round(time.perf_counter() - t + C.settle(app), 3)
            if SLIDER_AXES:
                row["step_ms"] = C.med_ms(step_axis(iv, SLIDER_AXES[-1], [2, 3, 4, 5])[1:])
            if act.isCheckable() and act.isChecked():
                act.trigger()
                C.settle(app)
            if tid == "solar:band":  # not checkable: back to one wavelength pixel
                tool.width = 1
                C.settle(app)
            step_axis(iv, SLIDER_AXES[-1], [0])
        except Exception as e:  # noqa: BLE001
            row["error"] = f"{type(e).__name__}: {e}"
        view[tid] = row
    out["view"] = view
    # Point-submenu entries the menu offers: run them
    ran = {}
    if coord is not None:
        for e in coord.subtools:
            if e.tool_id in ("solar:light_curve", "solar:row", "solar:column", "solar:point_curves") and e.offered():
                t = time.perf_counter()
                try:
                    e.run(coord.coordinator)
                    ran[e.tool_id] = {"s": round(time.perf_counter() - t + C.settle(app), 3)}
                except Exception as err:  # noqa: BLE001
                    ran[e.tool_id] = {"error": f"{type(err).__name__}: {err}"}
    out["ran"] = ran
    return out


@phase("path_diagram")
def _():
    from glue_solar import tools as T

    tool = iv.toolbar.tools.get("solar:path")
    if tool is None:
        return {"offered": False}
    out = {"enabled": tool.enabled}
    if not tool.enabled:
        return out
    iv.toolbar.active_tool = "solar:path"
    m = C.MouseDriver(iv)
    iv.figure.canvas.draw()
    st = iv.state  # vertices inside the current view (Zoom 1:1 may have zoomed in)
    w, h = st.x_max - st.x_min, st.y_max - st.y_min
    for vx, vy in ((st.x_min + 0.2 * w, st.y_min + 0.2 * h), (st.x_min + 0.5 * w, st.y_min + 0.7 * h),
                   (st.x_min + 0.8 * w, st.y_min + 0.4 * h)):
        iv.figure.canvas.draw()  # as the tests' mouse helper: the ROI tool takes its background from a draw
        m.press(vx, vy)
        m.release(vx, vy)
    n0 = len(app.data_collection)
    t = time.perf_counter()
    C.key(iv, "enter")
    t_enter = time.perf_counter() - t
    t_settle = C.settle(app)
    new = app.data_collection[n0:]
    out.update({"enter_s": round(t_enter, 3), "settle_s": round(t_settle, 3),
                "diagrams": [(d.label, list(d.shape), type(d.coords).__name__) for d in new]})
    iv.toolbar.active_tool = None
    # a step on the diagram viewer, if one opened
    dv = [v for tab in app.viewers for v in tab if v is not iv and isinstance(v, ImageViewer)
          and isinstance(v.state.reference_data, T.PathData)]
    if dv:
        d = dv[-1]
        ax = [a for a in range(d.state.reference_data.ndim) if a not in (d.state.x_att.axis, d.state.y_att.axis)]
        if ax and d.state.reference_data.shape[ax[0]] > 2:
            out["diagram_step_ms"] = C.med_ms(step_axis(d, ax[0], [1, 2, 1, 2])[1:])
    return out


SESSION = f"{C.ROOT}/home/{args.name}.glu"


@phase("session_save")
def _():
    usage = shutil.disk_usage(C.ROOT)
    if usage.free < 11 * C.GB:
        return {"skipped": f"free {usage.free / C.GB:.1f} GB"}
    t = time.perf_counter()
    app.save_session(SESSION, include_data=False, absolute_paths=True)
    return {"save_s": round(time.perf_counter() - t, 3), "size_kb": round(os.path.getsize(SESSION) / 1024, 1),
            "path": SESSION}


if args.iris:
    IRIS = "/Users/nabil/DATA/IRIS"
    pattern = {"sit": "*4000255147*", "stack": "*4000005156*"}[args.iris]

    @phase("iris_open")
    def _():
        out = C.open_iris(app, IRIS, pattern, stack=args.iris == "stack", S=S)
        return out

    @phase("iris_steps")
    def _():
        return C.iris_steps(app, S["ql"])

    @phase("iris_pixel_drag")
    def _():
        return C.iris_drag(app, S["ql"])

    @phase("iris_without_sst_roi")
    def _():
        # the SST rectangle removed: what the IRIS panels cost with only the SST Pixel subset left
        grp = S.get("roi_group")
        t = time.perf_counter()
        if grp is not None and grp in app.data_collection.subset_groups:
            app.data_collection.remove_subset_group(grp)
        remove_s = time.perf_counter() - t + C.settle(app)
        out = {"remove_s": round(remove_s, 3), "steps": C.iris_steps(app, S["ql"], n=6), "drag": C.iris_drag(app, S["ql"], moves=6)}
        return out

    @phase("sst_with_iris")
    def _():
        # back on the SST tab, as the user would switch
        app.tab_widget.setCurrentIndex(0)
        C.settle(app)
        out = {}
        for axis in SLIDER_AXES:
            n = cube.shape[axis]
            if n > 1:
                out[NAMES.get(axis, axis)] = C.med_ms(step_axis(iv, axis, list(range(n)) * max(1, 8 // n))[1:])
                step_axis(iv, axis, [0])
        iv.toolbar.active_tool = "image:point_selection"
        m = C.MouseDriver(iv)
        iv.figure.canvas.draw()
        x, y = S["xy"]
        m.press(x, y)
        C.settle(app)
        ts = []
        for i in range(1, 9):
            t = time.perf_counter()
            m.move(x - 2 * i, y + 3 * i)
            ts.append(C.to_idle(app, t))
        m.release(x, y)
        C.settle(app)
        out["sst_pixel_move_ms"] = C.med_ms(ts[1:])
        out["links"] = len(app.data_collection.links)
        return out

@phase("pixel_drag_no_profile")
def _():
    # the same drag with the Profile viewer closed: what the profile costs each move (R3)
    app.tab_widget.setCurrentIndex(0)
    pv.close(warn=False)
    C.settle(app)
    iv.toolbar.active_tool = "image:point_selection"
    m = C.MouseDriver(iv)
    x, y = S["xy"]
    m.press(x, y)
    C.settle(app)
    times = []
    for i in range(1, args.drag + 1):
        t = time.perf_counter()
        m.move(x + 3 * i, y - 2 * i)
        times.append(C.to_idle(app, t))
    m.release(x, y)
    C.settle(app)
    return {"move_ms": C.med_ms(times[2:]), "max_ms": round(max(times) * 1e3, 1)}


log.add("cache_end", {"cached_fraction": C.cached_fraction(args.cube)})
log.add("dialogs", C.DIALOGS)
log.add("done", {"rss_gb": C.rusage()["rss"] / C.GB, "max_rss_gb": __import__("resource").getrusage(0).ru_maxrss / C.GB})
os._exit(0)  # skip glue-solar's last-session autosave on close
