"""
Stress one IRIS observation through glue-solar's browser path (scan, lazy load, quicklook) (measure only).

usage: python -I iris.py ROOT PATTERN NAME [--stack] [--windows A,B] [--no-sji] [--profile PHASES]
"""

import argparse
import cProfile
import glob
import os
import shutil
import sys
import time
import traceback
import warnings

warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common as C  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("root")
ap.add_argument("pattern")
ap.add_argument("name")
ap.add_argument("--stack", action="store_true")
ap.add_argument("--windows", default="")
ap.add_argument("--no-sji", action="store_true")
ap.add_argument("--skip", default="")
ap.add_argument("--profile", default="")
ap.add_argument("--instrument", action="store_true")
args = ap.parse_args()
SKIP, PROFILE = set(args.skip.split(",")), set(args.profile.split(","))
log = C.Log(args.name)
files = [p for p in glob.glob(f"{args.root}/**/{args.pattern}", recursive=True) if p.endswith((".fits", ".fits.gz"))]
size = sum(os.path.getsize(p) for p in files)
cached = sum(C.cached_fraction(p) * os.path.getsize(p) for p in files) / max(size, 1)
log.add("cache_before", {"files": len(files), "size_gb": round(size / C.GB, 3), "cached_fraction": round(cached, 3)})


def phase(name):
    def run(fn):
        if name in SKIP:
            return None
        log.begin(name)
        if INSTR is not None:
            INSTR.reset()
        prof = cProfile.Profile() if name in PROFILE else None
        try:
            if prof:
                prof.enable()
            extra = fn() or {}
        except Exception as e:  # noqa: BLE001
            extra = {"error": f"{type(e).__name__}: {e}", "traceback": traceback.format_exc()[-3000:]}
        finally:
            if prof:
                prof.disable()
                prof.dump_stats(f"{C.OUT}/{args.name}-{name}.prof")
        if INSTR is not None:
            extra["instr_ms_calls"] = INSTR.report()
        return log.end(extra)
    return run


from glue.core.roi import RectangularROI  # noqa: E402

INSTR = None

log.begin("startup")
app = C.make_app()
INSTR = C.standard_instr() if args.instrument else None
log.end({"versions": C.versions()})
S = {}


@phase("open")
def _():
    return C.open_iris(app, args.root, args.pattern, stack=args.stack, S=S,
                       windows=args.windows.split(",") if args.windows else None, sjis=not args.no_sji)


ql = S["ql"]
log.add("panels_tools", {k: C.tools_report(v) for k, v in ql.items() if k == "map"})


@phase("steps")
def _():
    return C.iris_steps(app, ql)


@phase("pixel")
def _():
    return C.iris_drag(app, ql)


@phase("roi")
def _():
    v = ql["map"]
    v.toolbar.active_tool = None
    d = v.state.reference_data
    nx, ny = d.shape[v.state.x_att.axis], d.shape[v.state.y_att.axis]
    group0 = app.session.edit_subset_mode.edit_subset
    app.session.edit_subset_mode.edit_subset = []
    t = time.perf_counter()
    v.apply_roi(RectangularROI(nx * 0.3, nx * 0.6, ny * 0.3, ny * 0.6))
    apply_s = time.perf_counter() - t
    settle_s = C.settle(app)
    out = {"apply_s": round(apply_s, 3), "settle_s": round(settle_s, 3)}
    # one step of each SJI with the ROI shown on it (glue's linked ROI mask, R2) and of the map
    for i, sv in enumerate(ql.get("sji", [])):
        n = sv.state.reference_data.shape[0]
        out[f"sji{i}_step_ms"] = C.med_ms(C._step(app, sv, 0, [n // 3, n // 3 + 1, n // 3 + 2])[1:])
    ax = [a for a in range(d.ndim) if a not in (v.state.x_att.axis, v.state.y_att.axis)]
    out["map_step_ms"] = C.med_ms(C._step(app, v, ax[-1], [1, 2, 3, 4])[1:])
    grp = app.data_collection.subset_groups[-1]
    t = time.perf_counter()
    app.data_collection.remove_subset_group(grp)
    out["remove_s"] = round(time.perf_counter() - t + C.settle(app), 3)
    app.session.edit_subset_mode.edit_subset = group0
    return out


@phase("solar_tools")
def _():
    v = ql["map"]
    coord = v.toolbar.tools["solar:coordinate"]
    out = {"offered": {e.tool_id: bool(e.offered()) for e in coord.subtools}}
    ran = {}
    for e in coord.subtools:
        if e.tool_id in ("solar:light_curve", "solar:row", "solar:column", "solar:point_curves") and e.offered():
            n0 = len(app.data_collection)
            t = time.perf_counter()
            try:
                e.run(coord.coordinator)
                ran[e.tool_id] = {"s": round(time.perf_counter() - t + C.settle(app), 3),
                                  "new_data": len(app.data_collection) - n0}
            except Exception as err:  # noqa: BLE001
                ran[e.tool_id] = {"error": f"{type(err).__name__}: {err}"}
    out["ran"] = ran
    # with them open: a Pixel move on the map
    out["pixel_after"] = C.iris_drag(app, ql, moves=6)
    return out


@phase("pixel_after_curves")
def _():
    # a drag with the light curves open (instrumented on its own), and which timers glue-solar runs meanwhile
    from qtpy import QtCore

    fired = {}
    timers = [t for t in app.findChildren(QtCore.QTimer) if t.isSingleShot()]
    out = C.iris_drag(app, ql, moves=8)
    out["single_shot_timers"] = sorted({t.interval() for t in timers})
    return out


@phase("path")
def _():
    out = {}
    for name in ("map", "sji0"):
        v = ql["map"] if name == "map" else (ql.get("sji") or [None])[0]
        if v is None:
            continue
        tool = v.toolbar.tools.get("solar:path")
        if tool is None or not tool.enabled:
            out[name] = {"enabled": False}
            continue
        v.toolbar.active_tool = "solar:path"
        m = C.MouseDriver(v)
        d = v.state.reference_data
        nx, ny = d.shape[v.state.x_att.axis], d.shape[v.state.y_att.axis]
        for fx, fy in ((0.2, 0.2), (0.5, 0.7), (0.8, 0.4)):
            v.figure.canvas.draw()
            m.press(nx * fx, ny * fy)
            m.release(nx * fx, ny * fy)
        n0 = len(app.data_collection)
        t = time.perf_counter()
        C.key(v, "enter")
        enter = time.perf_counter() - t
        out[name] = {"enter_s": round(enter, 3), "settle_s": round(C.settle(app), 3),
                     "diagrams": [(x.label[-40:], list(x.shape)) for x in app.data_collection[n0:]]}
        v.toolbar.active_tool = "image:point_selection" if name == "map" else None
    return out


SESSION = f"{C.ROOT}/home/{args.name}.glu"


@phase("session_save")
def _():
    if shutil.disk_usage(C.ROOT).free < 11 * C.GB:
        return {"skipped": "disk"}
    t = time.perf_counter()
    app.save_session(SESSION, include_data=False, absolute_paths=True)
    return {"save_s": round(time.perf_counter() - t, 3), "size_kb": round(os.path.getsize(SESSION) / 1024, 1),
            "path": SESSION}


log.add("cache_end", {"cached_fraction": round(sum(C.cached_fraction(p) * os.path.getsize(p) for p in files) / max(size, 1), 3)})
log.add("dialogs", C.DIALOGS)
log.add("done", {"rss_gb": C.rusage()["rss"] / C.GB, "max_rss_gb": __import__("resource").getrusage(0).ru_maxrss / C.GB})
sys.stdout.flush()
os._exit(0)
