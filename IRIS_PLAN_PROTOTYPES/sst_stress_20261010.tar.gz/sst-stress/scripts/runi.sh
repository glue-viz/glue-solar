#!/bin/bash
# runi.sh NAME ROOT PATTERN [args...]
NAME=$1; shift
R=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/07d33ef8-b8df-4ddb-b55c-24b6271a724b/scratchpad/sst-stress
H=$R/home/$NAME; rm -rf "$H"; mkdir -p "$H"
cd $R/scripts
env HOME="$H" QT_QPA_PLATFORM=offscreen MPLBACKEND=agg /Users/nabil/mamba/envs/iris-plan-qt6/bin/python -I iris.py "$@" "$NAME" > $R/out/$NAME.log 2>&1
echo "exit $?" >> $R/out/$NAME.log
