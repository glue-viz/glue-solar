import sys, os, warnings, glob, time
warnings.simplefilter("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common as C
from glue.core.data_factories import load_data
from glue_qt.viewers.image import ImageViewer
p = glob.glob("/Users/nabil/DATA/SST/SST-archive_obs171*/*.fits")[0]
app = C.make_app()
ds = load_data(p)
app.add_datasets(ds)
cube = ds[0]
cube.coords.wcs.specsys = "TOPOCENT"
iv = app.new_data_viewer(ImageViewer, data=cube)
C.settle(app)
iv.toolbar.active_tool = "solar:path"
tool = iv.toolbar.tools["solar:path"]
print("active", iv.toolbar.active_tool, tool.enabled)
m = C.MouseDriver(iv)
for vx, vy in ((300, 400), (600, 700), (900, 500)):
    iv.figure.canvas.draw()
    m.press(vx, vy); m.release(vx, vy)
print("roi vertices", getattr(tool._roi_tool, "_roi", None), tool._roi_tool.roi() if hasattr(tool._roi_tool, "roi") else None)
C.key(iv, "enter")
C.settle(app)
print("traces", tool._traces, [d.label for d in app.data_collection][-3:])
print(C.DIALOGS)
sys.stdout.flush(); os._exit(0)
