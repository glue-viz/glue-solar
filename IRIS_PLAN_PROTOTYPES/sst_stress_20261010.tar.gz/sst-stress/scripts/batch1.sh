#!/bin/bash
S=/Users/nabil/DATA/SST
R=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/07d33ef8-b8df-4ddb-b55c-24b6271a724b/scratchpad/sst-stress
cd $R/scripts
run() { df -g /Users/nabil/DATA | tail -1 >> $R/out/batch1.txt; echo "start $1 $(date +%T)" >> $R/out/batch1.txt; ./run.sh "$@"; echo "end $1 $(date +%T) $(tail -1 $R/out/$1.log)" >> $R/out/batch1.txt; rm -f $R/home/*.glu.tmp; }
run s495 "$(ls $S/SST-archive_obs495*/*.fits)"
run s6302 "$(ls $S/SST-archive_obs492*/nb_6302*.fits)"
run s6173 "$(ls $S/SST-archive_obs492*/nb_6173*.fits)"
run s8542 "$(ls $S/SST-archive_obs492*/nb_8542*.fits)" --iris sit --wcs-lock
run s167 "$(ls $S/SST-archive_obs167*/*.fits)"
run s167F "$(ls $S/SST-archive_obs167*/*.fits)" --fix-specsys
run s171F "$(ls $S/SST-archive_obs171*/*.fits)" --fix-specsys
run s498L "$(ls $S/SST-archive_obs498*/*.fits)" --iris sit --wcs-lock
echo "batch done $(date +%T)" >> $R/out/batch1.txt
