#!/bin/bash
# runr.sh NAME SESSION
R=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/07d33ef8-b8df-4ddb-b55c-24b6271a724b/scratchpad/sst-stress
H=$R/home/$1; rm -rf "$H"; mkdir -p "$H"
cd $R/scripts
env HOME="$H" QT_QPA_PLATFORM=offscreen MPLBACKEND=agg /Users/nabil/mamba/envs/iris-plan-qt6/bin/python -I restore.py "$2" "$1" > $R/out/$1.log 2>&1
echo "exit $?" >> $R/out/$1.log
