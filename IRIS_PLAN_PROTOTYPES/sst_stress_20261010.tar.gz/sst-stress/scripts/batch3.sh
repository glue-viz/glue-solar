#!/bin/bash
R=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/07d33ef8-b8df-4ddb-b55c-24b6271a724b/scratchpad/sst-stress
I=/Users/nabil/DATA/IRIS
S=/Users/nabil/DATA/SST
cd $R/scripts
log() { echo "$1 $(date +%T) $(df -g /Users/nabil/DATA | tail -1 | awk '{print $4 " GB free"}')" >> $R/out/batch3.txt; }
log "extract 3630"
mkdir -p $R/extract/x3630 && tar xzf $I/iris_l2_20150917_073915_3630104144_raster.tar.gz -C $R/extract/x3630
log "extracted $(du -sh $R/extract/x3630 | cut -f1)"
./runi.sh i3630 $R/extract/x3630 "*3630104144*" --stack
log "restore i3630"; ./runr.sh ri3630 $R/home/i3630.glu --no-profile
rm -rf $R/extract/x3630; log "extraction deleted"
log "i255147I"; ./runi.sh i255147I $I "*4000255147*" --instrument --skip roi,solar_tools,path,session_save
log "s498noroi"; ./run.sh s498noroi "$(ls $S/SST-archive_obs498*/*.fits)" --iris sit --skip roi,solar_tools,path_diagram,session_save,playback
log "s8542W"; ./run.sh s8542W "$(ls $S/SST-archive_obs492*/nb_8542*.fits)" --iris sit --wcs-lock --instrument
log "batch3 done"
