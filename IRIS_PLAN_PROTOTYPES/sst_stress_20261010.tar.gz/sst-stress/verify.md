# Verification of the SST and IRIS stress survey (wp10-l-sst-stress, D62, D63), 2026-10-10

Paths are relative to `/private/tmp/claude-501/-Users-nabil-Git-glue-solar/07d33ef8-b8df-4ddb-b55c-24b6271a724b/scratchpad/sst-stress/`. My scripts are in `verify/` (`h.py`, `cube.py`, `beside.py`, `iris.py`, `restore.py`, `spec.py`, `autosave.py`, `wcsbench.py`, `oneread.py`, `ident.py`, `run.sh`, `batch*.sh`). Every run's output is in `verify/out/<run>.json` and `.log`. Nothing was edited, committed or pushed. Session files and scratch HOMEs are deleted, and the detached worktree is removed. The data disk kept 22-23 GB free throughout. The highest RSS was 13.96 GB (the 8542 Profile button).

## Method, and how it differs from the survey's

- **glue-solar version:** origin/main 75b7a73 (#225), first on `sys.path`, checked on import. The survey used 4c57625. #225 left the quicklook's default main window unchanged (Mg II k when it is ticked), so the IRIS numbers compare.
- **Environment:** the same as the survey's. Env `iris-plan-qt6`, offscreen Agg, app 1600x1000, Image canvas 588x303. Each run had a fresh HOME and `python -I -X faulthandler`, with one big cube per process.
- **Idle detection:**
  - Events are pumped until nothing has been pending for 30-60 ms. Pending means a canvas draw, a profile worker running or queued, or the coordinator's timer.
  - A `processEvents` call longer than 2 ms counts as busy.
  - Main-thread CPU comes from `time.thread_time`.
- **Timers:**
  - Wrapped: `compute_statistic`, `_reset_y_limits`, `_calculate_profile_thread` (also by layer), `RoiSubsetState.to_mask` (by dataset and thread) and `WCS.all_world2pix`.
  - A nested call is counted once. This matters: glue's chunked `compute_statistic` calls itself, and counting each level doubles the thread totals (see SST4 and SST9).
- **SST1 cause:** faulthandler dumps every thread's stack on SIGSEGV or SIGABRT.
- **SST3 without a lock:**
  - The survey added a harness WCS lock to get past SST1. I used an independent stand-in instead: glue-qt's threaded profile layers compute on the main thread (`beside.py --sync`), so no worker threads exist.
  - This gives an upper bound, because queued profile requests are not coalesced.
- **Cache state:**
  - Cache state comes from `mincore`. The numbers marked cold had 0% of the cube cached.
  - My first 3950 run was made warm by my own harness, which looped over every factory identifier. `astropy_tabular_data`'s identifier reads the whole file, with a 2.3 GB transient footprint on the 1 GB 4846 cube (`out/ident4846.log`). glue's 'Auto' path never calls it: `find_factory` takes 2-4 ms and picks `fits_reader`.
  - I removed that loop and re-ran 3950 cold (`v3950c`).

## Verdicts

| Finding | Verdict | Key number: survey → verification |
|---|---|---|
| SST1 crash beside a quicklook | **CONFIRMED** (cause detail extended) | 4 of 4 unprotected runs crashed; same here: 4 of 4 (3 SIGSEGV, 2 SIGABRT dumps) |
| SST2 2020 cubes refused | **CONFIRMED** | both refused 'SPECSYS= not yet supported'; both show with SPECSYS='TOPOCENT' set first |
| SST3 SST region on a locked quicklook | **CONFIRMED** costs, **CORRECTED** cause | per action matches; open 328 s (harness lock) → 798 s (no workers); the cost is wcslib's -TAB inverse, not a distortion iteration |
| SST4 Profile button reads the file | **CONFIRMED**, numbers **CORRECTED** | 8542 32.5 s (21.2 s freeze) → 27.4 s (21.2 s freeze); worker re-run 22.6 s → 5.9 s |
| SST5 SST sessions never restore | **CONFIRMED** | fails in 5-9 ms; the autosave is written (65 KB) and 'IRIS: restore last session' fails |
| SST6 restore re-reads per window | **CONFIRMED** mechanism, **CORRECTED** cost | 49.3 s (38.1 s data) → 19.8 s (13.8 s data); the survey's restores ran under cProfile |
| SST7 windows multiply redraws | **CONFIRMED** | exposure step 207 → 865 ms becomes 194 → 875 ms (7 → 47 draws) |
| SST8 SST drag waits on the worker | **CONFIRMED** cost, **CORRECTED** split | 194 ms with 168 ms waiting → 170-201 ms with about 105 ms waiting and about 50 ms of extra main-thread drawing |
| SST9 Path Enter recomputes | **CONFIRMED** cost, **CORRECTED** cause | the data layer's whole-cube profile recomputes, not the rectangle's |
| SST10 random limits reads | **CONFIRMED** | cold viewer 1.3-2.6 s, 0.3-0.74 GB → 1.75-1.82 s, 0.68-0.74 GB, about 10,000 page-ins |
| SST11 point curves offered then refused | **CONFIRMED** (on 75b7a73) | refusal box on 3824262996 |
| SST12 33 datasets | **CORRECTED** | not 30 1-D tables: 31 empty 0-D datasets plus 2 5-D ones |
| SST13 cold sit-and-stare reads the file | **CONFIRMED** read, **CORRECTED** cause | 1.43 of 1.43 GB, read by the browser's colour-limit sample, not by the λ-time panels |

## Per finding

### SST1. CONFIRMED: an IRIS quicklook beside an SST cube crashes glue

**Runs.** I used the 4846 cube with the 4000255147 quicklook (9 windows and SJI 1400), all as shipped (`verify/out/b1.log` to `b4.log`):

| Run | Setup | Result | Thread that died |
|---|---|---|---|
| b1 | Image + Profile + Pixel + rectangle | SIGSEGV during the quicklook open | a glue-qt `ComputeWorker`: `update_profile` → glue-solar `lazy.py:217 compute_statistic` → `subset.py:564 to_mask` (SST rectangle on an IRIS window) → `component_link.py:395` → `glue_patches.py:131 world2pixel_single_axis` → `fitswcs.py:365` → `WCS.all_world2pix` → `wcs_world2pix` |
| b2 | same as b1 | SIGSEGV during the open | the main thread: `image/state.py:463 get_sliced_data` → `fixed_resolution_buffer.py:298` → `data.py:1438 get_mask` → `subset.py:564` → the same SST `all_world2pix`, while a worker was also in `wcs.py` |
| b3 | no rectangle | SIGABRT after the open, on the SST step or drag | see below |
| b4 | no SST Profile viewer | SIGSEGV and SIGABRT during the open | the quicklook's spectrum-panel workers, on the same path as b1 |

- **b3 in detail:**
  - A worker ran `pixel_selection_subset_state.py:24 to_array` → glue-solar `glue_patches.py:319 _to_linked_pixel_coords` → `link_manager.py:435 pixel_cid_to_pixel_cid_matrix` → `glue_patches.py:131` → the SST `wcs_world2pix`, unlocked.
  - The abort surfaced in another worker, inside an IRIS `_GlueWCS.axis_correlation_matrix` (`iris.py:131`, holding `WCS_LOCK`).
  - Heap corruption appears in whichever thread allocates next, so the frame that aborts is not the culprit. In all four dumps, the only unlocked wcslib calls are on the SST cube's plain `astropy.wcs.WCS`.
- **New detail:**
  - No SST Profile viewer is needed (b4). The quicklook's own spectrum panels compute the SST rectangle's and the SST Pixel point's profiles over IRIS windows on worker threads.
  - glue-solar's own patches are on every crashing stack: `glue_patches.world2pixel_single_axis` and the `_to_linked_pixel_coords` patch.
  - The survey's second path (`coordinate_helpers.py:47` → `axis_correlation_matrix`) went through IRIS's locked `_GlueWCS` in my dumps, not through the SST WCS.
  - `keep_hpc_linked` took the collection from 20 to 122 links, so the SST cube and its `WCSDVARR` were linked.
- **Not re-tested:** the survey's "transforms-only lock → SIGABRT". sunpy maps loaded through 'sunpy Map' carry a plain astropy WCS that `link_hpc` links with `LinkSameWithUnits`, so they are the same class. Untested.
- **Outcome: `wp13-l-sst-wcs-lock` (D63), with these changes:**
  - The lock covers every non-`_GlueWCS` dataset `link_hpc` links, sunpy maps too.
  - Also take it in `glue_patches._to_linked_pixel_coords`.
  - Done-when also passes `beside.py` with `--no-profile` and `--no-roi` (each crashed here).
  - Note in the item: once locked, the main thread waits behind worker inversions that take several seconds (SST3), so `wp13-l-sst-link-scope` must ship with it or right after. Add `beside.py` as the reproducer to `wp0-astropy-19174`.

### SST2. CONFIRMED: the 2020 SSTRED exports are refused by the Image viewer

- **What happens:**
  - Both 2020 headers have OBSGEO-X/Y/Z and no SPECSYS (`out/spec_obs171.log`, `spec_obs167.log`).
  - `coords.world_axis_object_classes` raises `NotImplementedError: SPECSYS= not yet supported` (`astropy/wcs/wcsapi/fitswcs.py:516-519`).
  - Opening an Image viewer gives 'Failed to add data / SPECSYS= not yet supported'.
- **With SPECSYS set in memory before the first viewer:** with `wcs.specsys='TOPOCENT'`, both cubes show and draw: obs171 in 1.35 s (`spec171fix`), obs167 in 0.64 s.
- **Extra detail:**
  - A second viewer in the same session after the failure fails differently on obs171: 'wrapped C/C++ object of type LayerArtistView has been deleted'. The loader must therefore fix SPECSYS before the data reaches glue.
  - wp13's text ("glue's own FITS reader already loads it … and links it to IRIS") is stale at astropy 8.0.1.
- **Outcome:** `wp13-solarnet-tab-wcs` done-when (D63), with the stale sentence corrected.

### SST3. CONFIRMED costs, CORRECTED cause: an SST region on an IRIS quicklook costs minutes per action

These numbers are from `out/b5.json` (4846 + 4000255147, all profiles on the main thread).

| Action | Survey (harness lock) | Verification (no worker threads) |
|---|---|---|
| Quicklook open | 328 s | 798 s (13.3 min) |
| Exposure step | 3.7-4.4 s | 3.6-3.7 s |
| SJI frame step | 2.8-3.5 s | 2.85-2.97 s |
| Map λ step | 91 ms | 98 ms |
| Click | 3.6-4.3 s | 3.5 s |
| SST step with the quicklook open | 35-40 ms | 31 ms |
| SST Pixel move with the quicklook open | 571-735 ms | 500 ms |

- **Where the open's time goes:**
  - `RoiSubsetState.to_mask` on IRIS data took 120 calls and 788 s. Inside them, the SST WCS's `all_world2pix` took 537 calls and 774 s, which is 98% of the open.
  - A whole-window mask costs 7.6-8.7 s. The SJI screen mask costs 2.8 s, and it is all the cost of an exposure step or SJI frame.
- **Cause correction:**
  - The survey said "the inversion is iterative because of the distortion lookup". It is not.
  - The WCS glue's FITS reader builds has `has_distortion=False`: `cpdis1/2`, `det2im1/2` and `sip` are all None, so CWDIS3 is not loaded, as wp13 says.
  - So `all_world2pix` returns right after one `wcs_world2pix`: wcslib's -TAB inverse.
- **Benchmark of that inverse** (`out/wcsbench.log`, glue's 4846 WCS, 20,000 points):
  - Forward transform: 0.09 µs per point.
  - Inverse inside the cube's footprint: **975 µs per point**.
  - Inverse outside it: 7.9 µs per point, giving NaN.
- **What the survey missed:** its pair (2013 IRIS against a 2023 SST field) never overlaps, so it measured the cheap case. For co-pointed data, such as obs171 with IRIS 3660258923 (the real use case), each covered pixel costs about 100× more. A half-covered SJI frame (about 60,000 of 120,000 screen pixels) would take about a minute. R2's footprint cull does not help where the region overlaps. The R8/D54 decision stands: no faster inversion.
- **Outcome: `wp13-l-sst-link-scope` (D63), with these changes:**
  - Correct the cause text: the cost is the -TAB inverse.
  - Give the open as "328-798 s depending on how SST1 is fixed".
  - Add to the item that co-pointed data will be about 100× worse per covered pixel. That favours linking non-IRIS data only on request over relying on R2.
  - Done-when should include an overlapping case (a synthetic SST-like WCS over the IRIS field) as well as the survey's beside run.

### SST4. CONFIRMED, numbers CORRECTED: the Profile button reads the whole file and freezes the main thread

These are cold runs, with 0% of the cube cached, and `_reset_y_limits` timed on the main thread:

| Cube | Total s | Freeze s | Freeze share | GB read in the phase | RSS steady / peak GB | Footprint peak GB | Survey total (freeze) |
|---|---|---|---|---|---|---|---|
| 8542 | 27.4 | 21.2 | 77% | 9.22 | 10.25 / 13.96 | 4.39 | 32.5-32.8 (21.1-21.3) |
| 6173 | 18.7 | 14.9 | 79% | 6.07 | 7.23 / 9.70 | 3.01 | 21.5 (14.1) |
| 6302 | 13.7 | 10.5 | 77% | 4.30 | 5.85 / 7.74 | 2.42 | 17.0 (11.1) |
| 3950 | 8.2 | 6.1 | 74% | 2.19 | 3.93 / 5.05 | 1.66 | 9.8 (6.0) |

- **Overall:**
  - The whole file is read once the viewer and slider phases are included.
  - The cost is about 2.6-2.8 s per GB, not 3.3, and the freeze is about 3/4 of the wait, not 2/3.
  - The freeze, the bytes read, the RSS and the footprint match the survey. The totals are 15-20% lower.
- **Corrections:**
  - The worker's second pass runs on a warm cache and takes **5.9 s** on 8542, one run on the Data layer. The survey's "22.6 s across threads" (and SST9's "11.8 s") count chunked `compute_statistic` twice. My first harness did the same, showing 2.14 s against a real 1.07 s on 4846.
  - Chunks are not 4e7 values. glue chunks only along the profile axis, at least one index at a time, so each chunk is one λ plane: 6×4×2274×2281 = 1.24e8 values. Its float64 copy is about 1 GB, which is why the footprint reaches 4.4 GB (R21).
- **Dialogs:** 'Creating a profile viewer', then 'Add large data set?' (`large_data_size` 1e8). Both confirmed.
- **Outcome: `wp10-l-sst-profile-hidden-data` (D63), with these changes:**
  - Numbers: 27.4 s cold, a 21.2 s freeze and 9.2 GB read.
  - Add to done-when that a Path Enter on 8542 no longer recomputes the cube (SST9): a hidden layer's `update_profile` returns early.
  - Add the chunk-size note to R21 in `wp0-perf-core-stats-io`.

### SST5. CONFIRMED: SST sessions save but never restore

- **Restore:** it fails in 5-9 ms on 3950, 6302, 6173 and 8542 with `ValueError: HDUList is required to retrieve -TAB coordinates and/or indices.` The cause is `glue/core/state.py` `_save_wcs`/`_load_wcs` (`to_header_string` then `WCS(Header)`).
- **Save:** 16-19 ms, 141-159 KB.
- **Autosave** (`out/autosave.log`):
  - Closing the app with 4846 open writes a 65 KB `glue-solar-last-session.glu`. The 1 MB guard does not stop it, because glue's FITS components carry load logs.
  - 'IRIS: restore last session' then shows 'Failed to restore session / HDUList is required…'.
- **Outcome:** `wp13-solarnet-tab-wcs` done-when (D63), with the autosave case included.

### SST6. CONFIRMED mechanism, CORRECTED cost: restoring a stack reads each file once per window

- **Mechanism:**
  - The 3602506433 stack had 7 windows and 99 files.
  - The browser load took 10.9 s cold, with 99 `read_files` calls.
  - The restore took **19.8 s** (+0.7 s settle) with **693** `read_files` calls (99 × 7). Of that, 13.8 s went to the 7 load-log loads (`out/i3602.json`, `ri3602.json`).
- **The survey's timing error:**
  - Every survey restore record carries cProfile output (`profile_top` in `out/ri*.json`), although its method says restores were timed without it.
  - So 49.3 s (38.1 s data) and 70.7 s for 3630104144 are inflated about 2.5-3×.
  - The whole IRIS 'Restore' column is affected. For example, 4000255147 with 9 windows restores in **6.7 s**, not 19.3 s (`out/ri255.json`; 9 `read_files` calls for its one file).
- **Direct test of the fix** (`out/oneread.json`, warm): one `_raster_windows_data` call for all 7 windows takes 5.6-6.3 s, against 13.5 s for one call per window. The fix should bring the restore to about 12 s, saving about 7.5 s, not 37 s.
- **Outcome:** `wp3-l-restore-one-read` (D63), with its numbers corrected: "19.8 s with 693 reads, about 12 s with one read per file". Also mark GLUE_SPEED's IRIS Restore column as cProfile-inflated.

### SST7. CONFIRMED: each ticked window multiplies the quicklook's redraws

These are 4000255147 runs, warm (`out/i255one.json`, `i255all.json`):

| Windows | Exposure step | Draws per step | Click | Move | Open |
|---|---|---|---|---|---|
| Si IV 1403 + SJI 1400 | 194 ms | 7 | 264 ms | 240 ms | 3.4 s |
| 9 windows + SJI 1400 | 875 ms | 47 | 887 ms | 991 ms | 13.4 s |

- The map λ step is 95 ms and the SJI frame step 48 ms in both, so they are untouched by the window count.
- 3824262996 with 8 windows: raster step 374 ms (27 draws), click 385 ms, move 424 ms. The survey had 361, 378 and 417.
- **Outcome:** `wp4-l-window-rows-redraw` (D63) as written. Add "draws per exposure step 7 → 47" to it.

### SST8. CONFIRMED cost, CORRECTED split: an SST Pixel drag with a Profile viewer

- **Cost:** 170-201 ms per move with the Profile viewer, in 6 runs on 5 cubes; 31-34 ms before it opens (1 draw).
- **What happens per move with it open:**
  - 4 draws.
  - 2 worker runs, each computing for only 0.4-0.5 ms.
  - Main-thread CPU of 75-91 ms.
- **Split:** about 95-110 ms is waiting (R3's 25 Hz polling, twice), and about 44-57 ms is the Profile viewer's extra draws on the main thread. It is not "168 of 194 ms waiting".
- **Without the Profile viewer, after the Path diagram exists:** 65-73 ms, because the diagram viewer also redraws (2 draws).
- **Outcome:** R3's re-verification (D63), with this split. R3 (a) cuts the wait, and (b) (v_min/v_max no longer trigger a recompute) cuts the extra draws.

### SST9. CONFIRMED cost, CORRECTED cause: a Path Enter recomputes the cube's profile

- **Cost:**

  | Cube | Enter | Settle | Survey settle |
  |---|---|---|---|
  | 8542 | 0.17-0.18 s | 5.3 s | 5.3 s |
  | 6302 | 0.17-0.18 s | 5.7 s | 2.7 s |
  | 6173 | 0.17-0.18 s | 3.5 s | 7.0 s |
  | 3950 (cold) | 0.17-0.18 s | 3.6 s | 3.5 s |

- **What recomputes:**
  - The **Data layer's whole-cube 'maximum'**: 5.35 s on 8542, and twice (1.86 + 1.80 s) on 3950.
  - The rectangle subset takes only 0.36-0.42 s.
- **Cause chain:**
  1. The Path adds 3 links (20 → 23).
  2. `Data._update_externally_derivable_components` broadcasts (`glue/core/data.py:640-660`).
  3. `Viewer._update_data` follows (`glue/viewers/common/viewer.py:288-307`).
  4. `ProfileLayerArtist.update` resets the cache and forces a recompute.
- **Outcome:** `wp10-l-sst-profile-hidden-data` removes it. Upstream, record it under R11 as the Profile data-layer case of the same broadcast (R11 today covers image subset masks).

### SST10. CONFIRMED: a new Image viewer on a cold cube reads at random

- **Cost, cold:**
  - 8542, 6173, 6302 and 3950: 1.75-1.82 s, 0.68-0.74 GB read and 9,967-10,186 page-ins, with `compute_statistic` taking 1.17-1.25 s.
  - Warm: 0.53-0.55 s.
- **Cause, checked in code:**
  - `glue/core/state_objects.py:405-422` calls `random_subset`.
  - `glue/core/data.py:1849-1851` caches the indices.
  - `glue/utils/array.py:756` uses one `np.random.randint` per axis.
- **Outcome:** `wp0-perf-core-stats-io` (D63), as R32 when it moves into the ranked list. The survey's `wp0-perf-core` key does not exist.

### SST11. CONFIRMED: 'Light curves of every window and SJI…' is offered, then refuses

- **On 3824262996** (8 windows, no SJI), after a map click: the entry is offered. Running it gives 'Could not add the light curves / … has no exposures or scans, and its observation no slit-jaw image loaded'.
- 'Light curve of this window' is hidden. Row and Column work, in 0.68 and 0.74 s.
- **Cause:** `tools.py:1911-1913` on 75b7a73 checks only `_role`, against `quicklook.py:1800`.
- **Outcome:** `wp11-l-point-curves-offered` (D63).

### SST12. CORRECTED: what File > Open makes of an SST cube

- **The 33 datasets:**
  - The cube (5-D, `WCS`, memory-mapped).
  - `WCSDVARR` (5-D, for example 6×1×1×1846×1403, with its own `WCS`).
  - **31 empty 0-D datasets with no components:** `WCS-TAB` and all 30 `VAR-EXT-*` tables. Their columns are multi-dimensional, so glue drops every one. They are not 1-D datasets.
- **Open:**
  - 0.24-0.25 s: `load_data` 0.07-0.09 s, then `add_datasets` with the autolinker 0.16 s. The survey's 0.33-0.61 s included quiet windows.
  - 0 bytes read. 20 links.
  - `fits_reader` (priority 100) is chosen. glue-solar's `read_iris_file` (priority 200) declines in 1.3 ms.
- **Outcome:** `wp13-solarnet-tab-wcs` done-when (D63), with the dataset description corrected.

### SST13. CONFIRMED read, CORRECTED cause: a cold sit-and-stare reads the whole raster file

- **Measurement** (3660259102 cold, `out/i3660cold2.json`): 1.427 of 1.432 GB is read during the browser's `_load`, before the quicklook. The quicklook phase read 5 MB.
- **Cause:** `_load` samples the colour limits of every shown dataset with `RawComponent._sample`, up to `SAMPLE_BYTES` = 512 MiB of whole planes each (`lazy.py:20, 113-123`). With 9 windows, those samples cover the file. The λ-time panels do not read it.
- **Cold against warm:** the load takes 3.5-4.6 s cold against 2.8 s warm. The quicklook takes 4.5-7.4 s either way.
- **Outcome:** the decision stands (no action). The read happens on the browser's worker thread behind its progress bar.

## Three per-cube rows re-measured (drawn at random: 6173, 6302, 3950)

Each cell gives the survey's value, then mine.

| Cube | Open s | Viewer s (GB read), cold | Steps ms, first / warm | Profile s (freeze) | Profile GB read | RSS steady / peak | Footprint peak | Drag ms | Rectangle apply + settle s | Path Enter + settle s | Save | Restore |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 6173 | 0.52 → 0.25 | 2.58 (0.45) → 1.82 (0.72) | 34-39 / 20 → 37-39 / 19 | 21.5 (14.1) → 18.7 (14.9) | 6.15 → 6.07 | 7.2 / 9.7 → 7.23 / 9.70 | 3.0 → 3.01 | 193 → 195 | 0.27 + 0.40 → 0.28 + 0.39 | 0.18 + 7.0 → 0.17 + 3.5 | 8 ms, 119 KB → 17 ms, 159 KB | fails → fails in 5 ms |
| 6302 | 0.48 → 0.24 | 2.58 (0.44) → 1.80 (0.71) | 35-38 / 20 → 37-39 / 19 | 17.0 (11.1) → 13.7 (10.5) | 4.79 → 4.30 | 5.8 / 7.7 → 5.85 / 7.74 | 2.4 → 2.42 | 207 → 201 | 0.28 + 0.30 → 0.28 + 0.30 | 0.17 + 2.7 → 0.18 + 5.7 | → 17 ms, 159 KB | not run → fails in 6 ms |
| 3950 (cold re-run) | 0.42 → 0.24 | 2.45 (0.43) → 1.75 (0.68) | 28 / 17.5 → 27 / 17 | 9.8 (6.0) → 8.2 (6.1) | 2.43 → 2.19 | 4.0 / 5.1 → 3.93 / 5.05 | 1.7 → 1.66 | 184 → 182 | 0.28 + 0.42 → 0.28 + 0.42 | 0.18 + 3.5 → 0.18 + 3.6 | 8 ms, 110 KB → 16 ms, 141 KB | fails → fails in 6 ms |

- **What agrees:** all three rows hold within noise for memory, footprint, bytes, steps, drags, rectangles and the freeze.
- **What runs lower here:** cold viewer times (with more GB read) and Profile totals.
- **Path settle varies:** 2.7-7.0 s in the survey and 3.5-5.7 s here. It depends on how many data-layer recomputes the link change triggers (SST9).
- **Sessions:** my sessions held a Path diagram, so they are larger.
- **Other cubes:** 8542 (cold) and 4846 (warm) were also re-run, and agree as shown under SST4 and SST8.
- **Not re-measured:** playback, steps with subsets shown, and the glue-solar View tools.

## What the survey missed that the item asks for

1. **"With an IRIS observation beside it" only measured the non-overlapping case.** SST world-to-pixel costs 975 µs per point inside the cube's footprint and 8 µs outside, so co-pointed SST and IRIS data will be about 100× slower per covered pixel than SST3's numbers (see SST3). The reverse direction, an IRIS region shown on the SST Image viewer, was not measured either. That inverts irispy's -TAB raster WCS per SST screen pixel (R8: about 6 ms per point inside a sit-and-stare's footprint).
2. **Session restore timings ran under cProfile.** Every IRIS 'Restore' number in the survey's table, and in GLUE_SPEED's copy, is inflated about 2.5-3×.
3. **An SST light curve was never measured.** glue-solar's light-curve entries are IRIS-only and hidden. On an SST cube a light curve means a Profile viewer with x = time, which recomputes the whole-cube data layer again (R14).
4. **sunpy maps beside a quicklook** carry a plain astropy WCS that `link_hpc` links, the same class as SST1. Not run.

## Proposed outcomes

All items keep the D63 keys:

- **`wp13-l-sst-wcs-lock`** (glue-solar, first):
  - The lock covers every non-`_GlueWCS` dataset `link_hpc` links, including sunpy maps, with properties too.
  - Take the lock in `glue_patches.world2pixel_single_axis` and `_to_linked_pixel_coords`.
  - Done when `verify/beside.py` on 4846 completes 3 of 3 as shipped, with `--no-profile` and with `--no-roi`, plus the survey's runs and a threaded test with a synthetic non-IRIS WCS.
  - Ship it with `wp13-l-sst-link-scope`, since locking turns the crash into multi-second freezes.
  - Add `beside.py` to `wp0-astropy-19174`.
- **`wp13-l-sst-link-scope`** (glue-solar, the user chooses the design):
  - Correct the cause to wcslib's -TAB inverse, with no distortion iteration.
  - Open: 328-798 s depending on the lock.
  - Add the overlapping case (about 1 ms per covered pixel) to done-when.
  - The evidence favours linking non-IRIS data only on request ('IRIS: link helioprojective coordinates').
- **`wp10-l-sst-profile-hidden-data`** (glue-solar):
  - Numbers: 27.4 s cold, a 21.2 s freeze and 9.2 GB read on 8542.
  - Done-when also covers a Path Enter on 8542 that settles without recomputing the cube (SST9).
- **`wp3-l-restore-one-read`** (glue-solar): numbers become 19.8 s (13.8 s data, 693 reads) → about 12 s. Done when 3602506433 restores with 99 `read_files` calls.
- **`wp4-l-window-rows-redraw`** (glue-solar): confirmed. Add draws per step, 7 → 47.
- **`wp11-l-point-curves-offered`** (glue-solar): confirmed as written.
- **`wp13-solarnet-tab-wcs`** done-when:
  - SST2: both 2020 cubes show in an Image viewer, with SPECSYS set by the loader before glue sees the WCS.
  - SST5: restore, including 'IRIS: restore last session'.
  - SST12: the description becomes 2 5-D datasets plus 31 empty 0-D ones.
  - Correct the stale "already loads and links" sentence.
- **Upstream additions:**
  - **R3:** SST8's split, about 105 ms waiting plus about 50 ms of extra draws per move.
  - **R11:** SST9's Profile data-layer recompute path (`data.py:640-660` → `viewer.py:288-307` → `ProfileLayerArtist.update`).
  - **`wp0-perf-core-stats-io`:** SST10 as R32, and R21's plane-sized chunks (1.24e8 values, about 1 GB float64 copies).
- **Decisions:**
  - SST13: no action. The read is the colour-limit sample on the browser's worker thread, 1-2 s cold on this SSD.
  - R8/D54 still rules out a faster -TAB inverse.
- **GLUE_SPEED corrections:**
  - Tick "Re-verified" (2026-10-10, this run) on SST1, 2, 5, 7, 10 and 11.
  - Correct the numbers or causes of SST3, 4, 6, 8, 9, 12 and 13 as above.
  - Mark the IRIS Restore column as cProfile-inflated: 4000255147 with 9 windows 6.7 s, 3602506433 20.5 s.