"""Verifier: SST cube (Image + Profile + Pixel + rectangle), then an IRIS quicklook in another tab.

usage: beside.py CUBE NAME [--sync] [--no-roi] [--no-profile] [--windows all|one] [--light]
--sync: glue-qt profile layers compute on the main thread (no worker threads): tests the thread cause of SST1.
"""

import argparse
import faulthandler
import os
import statistics
import sys
import threading
import time
import warnings
from functools import partial

warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import h  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("cube")
ap.add_argument("name")
ap.add_argument("--sync", action="store_true")
ap.add_argument("--no-roi", action="store_true")
ap.add_argument("--no-profile", action="store_true")
ap.add_argument("--windows", default="all")
ap.add_argument("--light", action="store_true", help="stop after the quicklook open and one step of each kind")
a = ap.parse_args()
log = h.Log(a.name)
faulthandler.enable(all_threads=True)
peak = h.Peak(log)
peak.start()

from astropy.wcs import WCS  # noqa: E402
from glue.core import subset as gsub  # noqa: E402
from glue.core.data import Data  # noqa: E402
from glue.core.data_factories.helpers import auto_data, load_data  # noqa: E402
from glue.core.roi import RectangularROI  # noqa: E402
from glue.viewers.profile.layer_artist import ProfileLayerArtist  # noqa: E402
from glue_qt.viewers.image import ImageViewer  # noqa: E402

app = h.app_setup()
if a.sync:
    from glue_qt.viewers.profile.layer_artist import QThreadedProfileLayerArtist as Q

    def _sync(self, reset=False):
        ProfileLayerArtist._calculate_profile(self, reset=reset)

    Q._calculate_profile = _sync
T = h.Timer()
T.wrap(gsub.RoiSubsetState, "to_mask", "RoiSubsetState.to_mask")
T.wrap(WCS, "all_world2pix", "WCS.all_world2pix")
T.wrap(WCS, "world_to_pixel_values", "WCS.world_to_pixel_values")
T.wrap(Data, "compute_statistic")
T.wrap(ProfileLayerArtist, "_calculate_profile_thread")
mask_by = {}
_tm = gsub.RoiSubsetState.to_mask


def tm(self, data, view=None):
    t = time.perf_counter()
    try:
        return _tm(self, data, view)
    finally:
        key = (data.label[-40:], threading.current_thread() is threading.main_thread())
        r = mask_by.setdefault(key, [0, 0.0])
        r[0] += 1
        r[1] += time.perf_counter() - t


gsub.RoiSubsetState.to_mask = tm


def ms(xs):
    return round(statistics.median(xs) * 1e3, 1) if xs else None


def put(name, out):
    out.update({k: round(v, 2) for k, v in h.ru().items() if k in ("rss", "fp")})
    out["peak_rss"], out["peak_fp"] = round(peak.rss, 2), round(peak.fp, 2)
    out["timers"] = T.report()
    out["masks"] = {f"{k[0]}|{'main' if k[1] else 'thr'}": (v[0], round(v[1], 2)) for k, v in sorted(mask_by.items())}
    log.put(name, out)
    T.reset()
    mask_by.clear()


def step(v, axis, values, quiet=0.03):
    out = []
    for val in values:
        s = list(v.state.slices)
        s[axis] = int(val)
        t = time.perf_counter()
        v.state.slices = tuple(s)
        out.append(h.idle(app, t, quiet=quiet))
    return out


# --- SST side
t = time.perf_counter()
ds = load_data(a.cube, factory=auto_data)
app.add_datasets(ds)
cube = max(ds, key=lambda d: d.size)
iv = app.new_data_viewer(ImageViewer, data=cube)
h.idle(app)
if not a.no_profile:
    iv.toolbar.tools["profile-viewer"].activate()
    h.idle(app, quiet=0.2)
xy = (cube.shape[iv.state.x_att.axis] // 2, cube.shape[iv.state.y_att.axis] // 2)
iv.toolbar.active_tool = "image:point_selection"
iv.figure.canvas.draw()
h.mouse(iv, "press", *xy)
h.mouse(iv, "release", *xy)
h.idle(app)
iv.toolbar.active_tool = None
if not a.no_roi:
    app.session.edit_subset_mode.edit_subset = []
    iv.apply_roi(RectangularROI(xy[0] - 100, xy[0] + 100, xy[1] - 100, xy[1] + 100))
    h.idle(app, quiet=0.2)
put("sst_setup", {"s": round(time.perf_counter() - t, 2), "groups": len(app.data_collection.subset_groups),
                  "sync": a.sync, "threads": [th.name for th in threading.enumerate()]})

# --- IRIS beside, as browse_iris does it
from glue_solar.sources import iris as si  # noqa: E402
from glue_solar.sources.loaders import iris as li  # noqa: E402
from glue_solar.sources.loaders.scan import scan_directory  # noqa: E402

t = time.perf_counter()
obs = scan_directory("/Users/nabil/DATA/IRIS", pattern="*4000255147*")
o = obs[0]
wins = o.windows if a.windows == "all" else [w for w in o.windows if "1403" in w]
picks = [(0, "raster", w) for w in wins] + [(0, "sji", k) for k in sorted(o.sji)]
_, loaded, err = li._load(0, obs, picks, False, partial(si._shown, quicklooks=True), threading.Event(), lambda *x: None)
assert not err, err
datasets = [d for *_, dd in loaded for d in dd]
t_load = time.perf_counter() - t
links0 = len(app.data_collection.links)
app.data_collection.extend(datasets)
li.keep_hpc_linked(app.data_collection)
t_link = time.perf_counter() - t - t_load
put("iris_load", {"load_s": round(t_load, 2), "extend_link_s": round(t_link, 2), "picks": [p[2] for p in picks],
                  "links_before_after": (links0, len(app.data_collection.links))})
t = time.perf_counter()
qls = [si.quicklook(app, dd, window=w) for dd, w in si._quicklooks(loaded)]
t_call = time.perf_counter() - t
t_open = h.idle(app, t, quiet=0.2)
ql = qls[0]
put("quicklook_open", {"call_s": round(t_call, 2), "to_idle_s": round(t_open, 2),
                       "panels": {k: v.state.reference_data.label[-30:] for k, v in ql.items() if hasattr(v, "state")}})

# IRIS steps: spectrogram exposure, map wavelength, SJI frame
n = 2 if a.light else 5
sp = ql["spectrogram"]
d = sp.state.reference_data
ax = [x for x in range(d.ndim) if x not in (sp.state.x_att.axis, sp.state.y_att.axis)][0]
s0 = sp.state.slices[ax]
r = step(sp, ax, [s0 + 10 * i for i in range(1, n + 1)])
put("iris_exposure_step", {"ms": [round(x * 1e3) for x in r]})
mp = ql["map"]
d = mp.state.reference_data
ax = [x for x in range(d.ndim) if x not in (mp.state.x_att.axis, mp.state.y_att.axis)][0]
r = step(mp, ax, [mp.state.slices[ax] + 5 * i for i in range(1, n + 1)])
put("iris_map_step", {"ms": [round(x * 1e3) for x in r]})
sji = ql.get("sji", [])
if sji:
    v = sji[0]
    r = step(v, 0, [v.state.slices[0] + 3 * i for i in range(1, n + 1)])
    put("iris_sji_step", {"ms": [round(x * 1e3) for x in r]})
mp.toolbar.active_tool = "image:point_selection"
mp.figure.canvas.draw()
d = mp.state.reference_data
px, py = d.shape[mp.state.x_att.axis] // 3, d.shape[mp.state.y_att.axis] // 3
t = time.perf_counter()
h.mouse(mp, "press", px, py)
h.mouse(mp, "release", px, py)
put("iris_click", {"ms": round(h.idle(app, t) * 1e3)})
mp.toolbar.active_tool = None
if not a.light:
    # back on the SST tab: a slider step and a Pixel drag with the quicklook open
    app.tab_widget.setCurrentIndex(0)
    h.idle(app)
    r = step(iv, 2, [1, 2, 3, 4, 5])
    iv.toolbar.active_tool = "image:point_selection"
    iv.figure.canvas.draw()
    h.mouse(iv, "press", *xy)
    h.idle(app)
    mv = []
    for i in range(1, 7):
        t = time.perf_counter()
        h.mouse(iv, "move", xy[0] + 2 * i, xy[1] + 3 * i)
        mv.append(h.idle(app, t, quiet=0.03))
    h.mouse(iv, "release", xy[0] + 12, xy[1] + 18)
    h.idle(app)
    put("sst_with_iris", {"step_ms": ms(r[1:]), "move_ms": ms(mv[1:]), "moves": [round(x * 1e3) for x in mv]})
log.put("done", {"ok": True, "dialogs": h.DIALOGS})
os._exit(0)
