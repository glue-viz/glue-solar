"""Verifier: one SST cube through File > Open, Image viewer, steps, Profile button, Pixel drag, rectangle, Path, save.

usage: python -I cube.py CUBE NAME [--only open,viewer,...]
"""

import argparse
import os
import statistics
import sys
import threading
import time
import warnings

warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import h  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("cube")
ap.add_argument("name")
ap.add_argument("--skip", default="")
ap.add_argument("--drag", type=int, default=12)
a = ap.parse_args()
SKIP = set(a.skip.split(","))
log = h.Log(a.name)
log.put("cache_before", h.cached(a.cube))
peak = h.Peak(log)
peak.start()

import numpy as np  # noqa: E402
from glue.core.data import Data  # noqa: E402
from glue.core.data_factories.helpers import auto_data, load_data, find_factory  # noqa: E402
from glue.core.roi import RectangularROI  # noqa: E402
from glue.viewers.profile.state import ProfileViewerState  # noqa: E402
from glue.viewers.profile.layer_artist import ProfileLayerArtist  # noqa: E402
from glue_qt.viewers.image import ImageViewer  # noqa: E402

app = h.app_setup()
T = h.Timer()
T.wrap(Data, "compute_statistic")
T.wrap(ProfileViewerState, "_reset_y_limits")
T.wrap(ProfileLayerArtist, "_calculate_profile_thread")
RUNS = []
_cpt = ProfileLayerArtist._calculate_profile_thread


def _cpt_w(self, *x, **k):
    t = time.perf_counter()
    try:
        return _cpt(self, *x, **k)
    finally:
        RUNS.append((getattr(self.layer, "label", "?")[:30], type(self.layer).__name__, round(time.perf_counter() - t, 3)))


ProfileLayerArtist._calculate_profile_thread = _cpt_w


def ms(xs):
    return round(statistics.median(xs) * 1e3, 1) if xs else None


def delta(r0):
    r1 = h.ru()
    return {"read_gb": round(r1["read"] - r0["read"], 3), "pageins": r1["pageins"] - r0["pageins"],
            "rss_gb": round(r1["rss"], 2), "fp_gb": round(r1["fp"], 2)}


def phase(name, fn):
    if name in SKIP:
        return
    T.reset()
    peak.reset()
    r0 = h.ru()
    t0 = time.perf_counter()
    try:
        out = fn() or {}
    except Exception as e:  # noqa: BLE001
        import traceback

        out = {"error": f"{type(e).__name__}: {e}", "tb": traceback.format_exc()[-1500:]}
    out["wall_s"] = round(time.perf_counter() - t0, 3)
    out.update(delta(r0))
    out["peak_rss_gb"], out["peak_fp_gb"] = round(peak.rss, 2), round(peak.fp, 2)
    out["timers"] = T.report()
    out["profile_runs"] = [r for r in RUNS if r[2] > 0.01]
    RUNS.clear()
    log.put(name, out)


S = {}


def p_open():
    t = time.perf_counter()
    f = find_factory(a.cube)
    t_find = time.perf_counter() - t
    from glue.config import data_factory

    claims = "see ident.py (an identifier loop reads the whole file through astropy_tabular_data)"
    peak.reset()
    t = time.perf_counter()
    ds = load_data(a.cube, factory=auto_data)
    t_load = time.perf_counter() - t
    time.sleep(0.05)
    pk_load = (round(peak.rss, 2), round(peak.fp, 2), round(h.ru()["fp"], 2))
    ds = ds if isinstance(ds, list) else [ds]
    peak.reset()
    t = time.perf_counter()
    app.add_datasets(ds)
    t_add = time.perf_counter() - t + h.idle(app)
    time.sleep(0.05)
    pk_add = (round(peak.rss, 2), round(peak.fp, 2), round(h.ru()["fp"], 2))
    S["pk"] = {"load_peak_rss_fp_now": pk_load, "add_peak_rss_fp_now": pk_add}
    cube = max(ds, key=lambda d: d.size)
    S["cube"] = cube
    return {"factory": f.__name__, "find_s": round(t_find, 4), "claims": claims, "load_s": round(t_load, 3),
            "add_s": round(t_add, 3), "n_datasets": len(ds), "links": len(app.data_collection.links),
            "shape": cube.shape, "kinds": sorted({(d.ndim, type(d.coords).__name__) for d in ds}, key=str),
            "dialogs": list(h.DIALOGS), **S["pk"]}


def _safe(ident, path):
    try:
        return bool(ident(path))
    except Exception:  # noqa: BLE001
        return False


def p_viewer():
    t = time.perf_counter()
    iv = app.new_data_viewer(ImageViewer, data=S["cube"])
    t_new = time.perf_counter() - t
    t_idle = h.idle(app, t)
    S["iv"] = iv
    lay = iv.layers[0].state
    return {"new_s": round(t_new, 3), "to_idle_s": round(t_idle, 3), "x": str(iv.state.x_att), "y": str(iv.state.y_att),
            "slices": iv.state.slices, "vmin": float(lay.v_min), "vmax": float(lay.v_max),
            "canvas": [iv.figure.canvas.width(), iv.figure.canvas.height()], "cache_after": h.cached(a.cube)}


def step(iv, axis, values):
    out = []
    for v in values:
        s = list(iv.state.slices)
        s[axis] = int(v)
        t = time.perf_counter()
        iv.state.slices = tuple(s)
        out.append(h.idle(app, t, quiet=0.03))
    return out


def axes():
    iv = S["iv"]
    return [ax for ax in range(S["cube"].ndim) if ax not in (iv.state.x_att.axis, iv.state.y_att.axis)]


def p_steps():
    iv, out = S["iv"], {}
    for ax in axes():
        n = S["cube"].shape[ax]
        if n < 2:
            continue
        first = step(iv, ax, range(1, n))
        warm = step(iv, ax, list(range(n)) * max(1, 12 // n))
        out[ax] = {"n": n, "first_ms": ms(first), "warm_ms": ms(warm[2:])}
        step(iv, ax, [0])
    return out


def p_profile():
    iv = S["iv"]
    tool = iv.toolbar.tools["profile-viewer"]
    n0 = len(h.DIALOGS)
    t = time.perf_counter()
    main0 = time.thread_time()
    tool.activate()
    t_act = time.perf_counter() - t
    main_cpu_act = time.thread_time() - main0
    t_idle = h.idle(app, t, quiet=0.2)
    from glue_qt.viewers.profile import ProfileViewer

    pv = [v for tab in app.viewers for v in tab if isinstance(v, ProfileViewer)][-1]
    S["pv"] = pv
    return {"activate_s": round(t_act, 3), "main_cpu_activate_s": round(main_cpu_act, 3), "to_idle_s": round(t_idle, 3),
            "x_att": str(pv.state.x_att), "function": pv.state.function, "dialogs": h.DIALOGS[n0:],
            "cache_after": h.cached(a.cube)}


def drag(iv, moves, dx, dy):
    x, y = S["xy"]
    iv.toolbar.active_tool = "image:point_selection"
    iv.figure.canvas.draw()
    h.mouse(iv, "press", x, y)
    h.idle(app)
    draws = []
    cids = [v.figure.canvas.mpl_connect("draw_event", lambda e: draws.append(1)) for tab in app.viewers for v in tab]
    times, cpu, thr = [], [], []
    for i in range(1, moves + 1):
        n_thr = T.t.get("ProfileLayerArtist._calculate_profile_thread", [0, 0, 0, 0.0])[2:]
        c0 = time.thread_time()
        t = time.perf_counter()
        h.mouse(iv, "move", x + dx * i, y + dy * i)
        times.append(h.idle(app, t, quiet=0.03))
        cpu.append(time.thread_time() - c0)
        n_thr2 = T.t.get("ProfileLayerArtist._calculate_profile_thread", [0, 0, 0, 0.0])[2:]
        thr.append((n_thr2[0] - n_thr[0], n_thr2[1] - n_thr[1]))
    h.mouse(iv, "release", x + dx * moves, y + dy * moves)
    h.idle(app)
    iv.toolbar.active_tool = None
    return {"move_ms": ms(times[2:]), "max_ms": round(max(times) * 1e3, 1), "main_cpu_ms": ms(cpu[2:]),
            "worker_runs_per_move": statistics.median([n for n, _ in thr[2:]]),
            "worker_ms_per_move": ms([s for _, s in thr[2:]]), "draws_per_move": round(len(draws) / moves, 2)}


def p_pixel():
    iv = S["iv"]
    c = S["cube"]
    S["xy"] = (c.shape[iv.state.x_att.axis] // 2, c.shape[iv.state.y_att.axis] // 2)
    return drag(iv, a.drag, 3, 2)


def p_roi():
    iv = S["iv"]
    x, y = S["xy"]
    app.session.edit_subset_mode.edit_subset = []
    t = time.perf_counter()
    iv.apply_roi(RectangularROI(x - 100, x + 100, y - 100, y + 100))
    t_apply = time.perf_counter() - t
    t_settle = h.idle(app, quiet=0.1)
    return {"apply_s": round(t_apply, 3), "settle_s": round(t_settle, 3), "groups": len(app.data_collection.subset_groups)}


def p_path():
    from matplotlib.backend_bases import KeyEvent

    iv = S["iv"]
    tool = iv.toolbar.tools.get("solar:path")
    if tool is None or not tool.enabled:
        return {"offered": tool is not None, "enabled": getattr(tool, "enabled", None)}
    iv.toolbar.active_tool = "solar:path"
    st = iv.state
    w, hh = st.x_max - st.x_min, st.y_max - st.y_min
    for fx, fy in ((0.25, 0.25), (0.5, 0.65), (0.75, 0.4)):
        iv.figure.canvas.draw()
        h.mouse(iv, "press", st.x_min + fx * w, st.y_min + fy * hh)
        h.mouse(iv, "release", st.x_min + fx * w, st.y_min + fy * hh)
    n0 = len(app.data_collection)
    nl0 = len(app.data_collection.links)
    T.reset()
    c = iv.figure.canvas
    t = time.perf_counter()
    c.callbacks.process("key_press_event", KeyEvent("key_press_event", c, "enter"))
    t_enter = time.perf_counter() - t
    t_settle = h.idle(app, quiet=0.2)
    iv.toolbar.active_tool = None
    new = app.data_collection[n0:]
    return {"enter_s": round(t_enter, 3), "settle_s": round(t_settle, 3), "new": [(d.label, d.shape) for d in new],
            "links_before_after": (nl0, len(app.data_collection.links))}


def p_save():
    import shutil

    if shutil.disk_usage(h.ROOT).free < 11 * h.GB:
        return {"skipped": "disk"}
    path = f"{h.ROOT}/verify/sessions/{a.name}.glu"
    os.makedirs(os.path.dirname(path), exist_ok=True)
    t = time.perf_counter()
    app.save_session(path, include_data=False, absolute_paths=True)
    return {"save_s": round(time.perf_counter() - t, 4), "kb": round(os.path.getsize(path) / 1024, 1), "path": path}


def p_drag_nopv():
    S["pv"].close(warn=False)
    h.idle(app)
    return drag(S["iv"], a.drag, -3, 2)


def p_drag0():
    iv = S["iv"]
    c = S["cube"]
    S["xy"] = (c.shape[iv.state.x_att.axis] // 2, c.shape[iv.state.y_att.axis] // 2)
    return drag(iv, a.drag, -2, -3)


for name, fn in [("open", p_open), ("viewer", p_viewer), ("steps", p_steps), ("drag_before_profile", p_drag0),
                 ("profile", p_profile),
                 ("pixel_drag", p_pixel), ("roi", p_roi), ("path", p_path), ("save", p_save),
                 ("drag_no_profile", p_drag_nopv)]:
    if name in ("open",) or "cube" in S:
        phase(name, fn)
log.put("dialogs", h.DIALOGS)
log.put("done", h.ru())
os._exit(0)
