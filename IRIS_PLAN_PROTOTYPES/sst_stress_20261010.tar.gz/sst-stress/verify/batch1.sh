#!/bin/bash
V=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/07d33ef8-b8df-4ddb-b55c-24b6271a724b/scratchpad/sst-stress/verify
D=/Users/nabil/DATA/SST
for pair in "v6302:$D/SST-archive_obs492_20230919_CRISP_stokes/nb_6302_*_im.fits" "v6173:$D/SST-archive_obs492_20230919_CRISP_stokes/nb_6173_*_im.fits"; do
  name=${pair%%:*}; f=$(ls ${pair#*:})
  echo "$name start $(date +%T) free $(df -g /Users/nabil/DATA | tail -1 | awk '{print $4}')" >> $V/out/batch1.txt
  $V/run.sh $name cube.py "$f" $name
  $V/run.sh r$name restore.py $V/sessions/$name.glu r$name
  echo "$name end $(date +%T)" >> $V/out/batch1.txt
done
