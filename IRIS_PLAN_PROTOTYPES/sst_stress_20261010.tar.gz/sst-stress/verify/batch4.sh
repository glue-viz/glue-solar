#!/bin/bash
V=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/07d33ef8-b8df-4ddb-b55c-24b6271a724b/scratchpad/sst-stress/verify
run() { n=$1; shift; echo "$n start $(date +%T) free $(df -g /Users/nabil/DATA | tail -1 | awk '{print $4}')" >> $V/out/batch4.txt; $V/run.sh $n "$@"; echo "$n end $(date +%T) $(tail -1 $V/out/$n.log)" >> $V/out/batch4.txt; }
run v3950c cube.py "$(ls /Users/nabil/DATA/SST/SST-archive_obs495_20230919_CHROMIS_3950/nb_3950_*_im.fits)" v3950c
run rv3950c restore.py $V/sessions/v3950c.glu rv3950c
run spec171fix spec.py "$(ls /Users/nabil/DATA/SST/SST-archive_obs171_20201016_CRISP_6563/nb_6563_*_im.fits)" spec171fix --fix-first
run i3660cold iris.py '*3660259102*' i3660cold --no-steps
run i3660warm iris.py '*3660259102*' i3660warm --no-steps
run autosave autosave.py "$(ls /Users/nabil/DATA/SST/SST-archive_obs498_20230919_CHROMIS_4846/nb_4846_*_im.fits)" autosave
run i255one iris.py '*4000255147*' i255one --windows 1403
run i255all iris.py '*4000255147*' i255all
run i3824 iris.py '*3824262996*' i3824 --point-curves
run i3602 iris.py '*3602506433*' i3602 --stack --save --no-steps
run ri3602 restore.py $V/sessions/i3602.glu ri3602
echo "batch4 done $(date +%T)" >> $V/out/batch4.txt
