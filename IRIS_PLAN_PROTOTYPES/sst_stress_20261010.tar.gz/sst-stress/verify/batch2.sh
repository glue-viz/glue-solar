#!/bin/bash
V=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/07d33ef8-b8df-4ddb-b55c-24b6271a724b/scratchpad/sst-stress/verify
D=/Users/nabil/DATA/SST
f8542=$(ls $D/SST-archive_obs492_20230919_CRISP_stokes/nb_8542_*_im.fits)
echo "v8542 start $(date +%T) free $(df -g /Users/nabil/DATA | tail -1 | awk '{print $4}')" >> $V/out/batch2.txt
$V/run.sh v8542 cube.py "$f8542" v8542
$V/run.sh rv8542 restore.py $V/sessions/v8542.glu rv8542
for c in obs171_20201016_CRISP_6563/nb_6563 obs167_20201016_CRISP_6173_stokes/nb_6173; do
  f=$(ls $D/SST-archive_${c}_*_im.fits); n=spec_$(basename $(dirname $f) | cut -c13-18)
  echo "$n $(date +%T)" >> $V/out/batch2.txt
  $V/run.sh $n spec.py "$f" $n
done
echo "batch2 done $(date +%T) free $(df -g /Users/nabil/DATA | tail -1 | awk '{print $4}')" >> $V/out/batch2.txt
