#!/bin/bash
# usage: run.sh NAME script.py args...  (fresh HOME, offscreen, python -I, cwd = scratch home)
V=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/07d33ef8-b8df-4ddb-b55c-24b6271a724b/scratchpad/sst-stress/verify
NAME=$1; shift
HOMED=$(mktemp -d /private/tmp/claude-501/-Users-nabil-Git-glue-solar/07d33ef8-b8df-4ddb-b55c-24b6271a724b/scratchpad/sst-stress/home/v.XXXX)
echo "free: $(df -g /Users/nabil/DATA | tail -1 | awk '{print $4}') GB" > $V/out/$NAME.log
cd $HOMED
env HOME=$HOMED QT_QPA_PLATFORM=offscreen MPLBACKEND=agg PYTHONFAULTHANDLER=1 \
  /Users/nabil/mamba/envs/iris-plan-qt6/bin/python -I -X faulthandler $V/"$@" >> $V/out/$NAME.log 2>&1
echo "exit $?" >> $V/out/$NAME.log
cd /
rm -rf $HOMED
