"""Verifier: an IRIS observation through the browser path (no dialog), quicklook, steps, click/drag, save.

usage: iris.py PATTERN NAME [--windows all|SUBSTR] [--stack] [--no-sji] [--save] [--no-steps] [--point-curves]
"""

import argparse
import os
import statistics
import sys
import threading
import time
import warnings
from functools import partial

warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import h  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("pattern")
ap.add_argument("name")
ap.add_argument("--windows", default="all")
ap.add_argument("--stack", action="store_true")
ap.add_argument("--no-sji", action="store_true")
ap.add_argument("--save", action="store_true")
ap.add_argument("--no-steps", action="store_true")
ap.add_argument("--point-curves", action="store_true")
a = ap.parse_args()
log = h.Log(a.name)
peak = h.Peak(log)
peak.start()
app = h.app_setup()
from glue_solar.sources import iris as si  # noqa: E402
from glue_solar.sources.loaders import iris as li  # noqa: E402
from glue_solar.sources.loaders.scan import scan_directory  # noqa: E402
import irispy.io  # noqa: E402

calls = [0]
_rf = irispy.io.read_files


def rf(*x, **k):
    calls[0] += 1
    return _rf(*x, **k)


irispy.io.read_files = rf


def ms(xs):
    return round(statistics.median(xs) * 1e3, 1) if xs else None


r0 = h.ru()
t = time.perf_counter()
obs = scan_directory("/Users/nabil/DATA/IRIS", pattern=a.pattern)
obs = [o for o in obs if o.rasters]
o = obs[0]
wins = o.windows if a.windows == "all" else [w for w in o.windows if a.windows in w]
picks = [(0, "raster", w) for w in wins] + ([] if a.no_sji else [(0, "sji", k) for k in sorted(o.sji)])
caches = {str(p): h.cached(p) for p in o.rasters[:1]}
t_scan = time.perf_counter() - t
t = time.perf_counter()
_, loaded, err = li._load(0, obs, picks, a.stack, partial(si._shown, quicklooks=True), threading.Event(), lambda *x: None)
assert not err, err
t_load = time.perf_counter() - t
r_load = h.ru()
datasets = [d for *_, dd in loaded for d in dd]
t = time.perf_counter()
app.data_collection.extend(datasets)
li.keep_hpc_linked(app.data_collection)
t_link = time.perf_counter() - t
t = time.perf_counter()
qls = [si.quicklook(app, dd, window=w) for dd, w in si._quicklooks(loaded)]
t_ql = h.idle(app, t, quiet=0.2)
r1 = h.ru()
ql = qls[0]
log.put("open", {"obs": o.obsid, "n_rasters": len(o.rasters), "picks": [p[2] for p in picks], "cache_first_raster": caches,
                 "scan_s": round(t_scan, 2), "load_s": round(t_load, 2), "link_s": round(t_link, 2),
                 "quicklook_s": round(t_ql, 2), "read_files": calls[0], "datasets": len(datasets),
                 "read_gb": round(r1["read"] - r0["read"], 3), "read_load_gb": round(r_load["read"] - r0["read"], 3), "rss": round(r1["rss"], 2), "peak_rss": round(peak.rss, 2),
                 "panels": sorted(k for k in ql if hasattr(ql[k], "state")) + [f"sji x{len(ql.get('sji', []))}"],
                 "viewers": sum(len(tab) for tab in app.viewers)})

draws = []
for tab in app.viewers:
    for v in tab:
        v.figure.canvas.mpl_connect("draw_event", lambda e: draws.append(1))


def step(v, axis, values):
    out, nd = [], []
    for val in values:
        s = list(v.state.slices)
        s[axis] = int(val)
        n0 = len(draws)
        t = time.perf_counter()
        v.state.slices = tuple(s)
        out.append(h.idle(app, t, quiet=0.03))
        nd.append(len(draws) - n0)
    return out, nd


if not a.no_steps:
    res = {}
    sp = ql["spectrogram"]
    d = sp.state.reference_data
    ax = [x for x in range(d.ndim) if x not in (sp.state.x_att.axis, sp.state.y_att.axis)][0]
    vals = [int(x) for x in __import__("numpy").linspace(1, d.shape[ax] - 1, 8)]
    step(sp, ax, vals[:2])
    tt, nd = step(sp, ax, vals)
    res["spectrogram_step"] = {"axis": ax, "n": d.shape[ax], "ms": ms(tt), "draws": statistics.median(nd)}
    mp = ql["map"]
    d = mp.state.reference_data
    ax = [x for x in range(d.ndim) if x not in (mp.state.x_att.axis, mp.state.y_att.axis)][0]
    vals = [int(x) for x in __import__("numpy").linspace(1, d.shape[ax] - 1, 8)]
    tt, nd = step(mp, ax, vals)
    res["map_step"] = {"axis": ax, "ms": ms(tt), "draws": statistics.median(nd)}
    for i, v in enumerate(ql.get("sji", [])):
        nf = v.state.reference_data.shape[0]
        tt, nd = step(v, 0, [(v.state.slices[0] + 2 * j) % nf for j in range(1, 7)])
        res[f"sji{i}_step"] = {"ms": ms(tt), "draws": statistics.median(nd)}
    # click and drag on the map
    mp.toolbar.active_tool = "image:point_selection"
    mp.figure.canvas.draw()
    px, py = d.shape[mp.state.x_att.axis] // 3, d.shape[mp.state.y_att.axis] // 3
    n0 = len(draws)
    t = time.perf_counter()
    h.mouse(mp, "press", px, py)
    h.mouse(mp, "release", px, py)
    res["click"] = {"ms": round(h.idle(app, t) * 1e3), "draws": len(draws) - n0}
    h.mouse(mp, "press", px, py)
    h.idle(app)
    mv, nd = [], []
    for i in range(1, 9):
        n0 = len(draws)
        t = time.perf_counter()
        h.mouse(mp, "move", px + i, py + i)
        mv.append(h.idle(app, t, quiet=0.03))
        nd.append(len(draws) - n0)
    h.mouse(mp, "release", px + 8, py + 8)
    h.idle(app)
    mp.toolbar.active_tool = None
    res["move"] = {"ms": ms(mv[1:]), "draws": statistics.median(nd[1:])}
    res["rss"] = round(h.ru()["rss"], 2)
    log.put("steps", res)

if a.point_curves:
    mp = ql["map"]
    coord = mp.toolbar.tools.get("solar:coordinate")
    out = {}

    def walk(tools):
        for x in tools:
            yield x
            yield from walk(getattr(x, "subtools", None) or [])

    for e in walk(coord.subtools):
        if e.tool_id in ("solar:point_curves", "solar:light_curve", "solar:row", "solar:column"):
            off = bool(e.offered())
            out[e.tool_id] = {"offered": off}
            if off:
                n0 = len(h.DIALOGS)
                t = time.perf_counter()
                try:
                    e.run(e.menu.coordinator)
                except Exception as err:  # noqa: BLE001
                    out[e.tool_id]["raised"] = repr(err)[:200]
                out[e.tool_id]["s"] = round(time.perf_counter() - t + h.idle(app), 2)
                out[e.tool_id]["dialogs"] = h.DIALOGS[n0:]
    log.put("point_entries", out)

if a.save:
    path = f"{h.ROOT}/verify/sessions/{a.name}.glu"
    os.makedirs(os.path.dirname(path), exist_ok=True)
    t = time.perf_counter()
    app.save_session(path, include_data=False, absolute_paths=True)
    log.put("save", {"s": round(time.perf_counter() - t, 3), "kb": round(os.path.getsize(path) / 1024, 1)})
log.put("done", {"dialogs": h.DIALOGS})
os._exit(0)
