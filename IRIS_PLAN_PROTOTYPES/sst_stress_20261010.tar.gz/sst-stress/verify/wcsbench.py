"""Verifier: where an SST cube's world-to-pixel time goes: wcslib's -TAB inverse or the distortion iteration.
usage: wcsbench.py CUBE NAME"""

import os
import sys
import time
import warnings

warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import h  # noqa: E402
import numpy as np  # noqa: E402
from astropy.io import fits  # noqa: E402
from astropy.wcs import WCS  # noqa: E402

path, name = sys.argv[1], sys.argv[2]
log = h.Log(name)
from glue.core.data_factories.helpers import auto_data, load_data  # noqa: E402

ds = load_data(path, factory=auto_data)
w = max(ds, key=lambda d: d.size).coords  # the WCS glue's FITS reader built
log.put("glue_coords", {"type": type(w).__name__, "has_distortion": w.has_distortion, "cpdis": [str(w.cpdis1), str(w.cpdis2)],
                        "det2im": [str(w.det2im1), str(w.det2im2)], "sip": str(w.sip)})
log.put("wcs", {"has_distortion": w.has_distortion, "naxis": w.naxis, "ctype": list(w.wcs.ctype),
                "array_shape": w.array_shape})
rng = np.random.default_rng(1)
n = 20000
shape = w.pixel_shape  # (x, y, wave, stokes, time)
pix = np.column_stack([rng.uniform(0, s - 1, n) for s in shape])
pix[:, 1:] = np.round(pix[:, 1:])  # integral non-spatial pixels as glue passes them
pix[:, 1] = rng.uniform(0, shape[1] - 1, n)
t = time.perf_counter()
world = w.all_pix2world(pix, 0)
t_fwd = time.perf_counter() - t
out = {"forward_us_per_pt": round(t_fwd / n * 1e6, 2)}
for label, wd in (("inside", world), ("outside_+600arcsec", world + np.array([600 / 3600, 0, 0, 0, 0]) * 0)):
    if label.startswith("outside"):
        wd = world.copy()
        lon_unit = w.wcs.cunit[0]
        wd[:, 0] += (600 * __import__("astropy.units", fromlist=["u"]).arcsec).to_value(lon_unit)
    t = time.perf_counter()
    p0 = w.wcs_world2pix(wd, 0)
    t_tab = time.perf_counter() - t
    t = time.perf_counter()
    p1 = w.all_world2pix(wd, 0, quiet=True)
    t_all = time.perf_counter() - t
    t_foc = 0.0
    err = np.nanmax(np.abs(p1[:, :2] - pix[:, :2])) if label == "inside" else None
    out[label] = {"wcs_world2pix_us": round(t_tab / n * 1e6, 2), "all_world2pix_us": round(t_all / n * 1e6, 2),
                  "pix2foc_us": round(t_foc / n * 1e6, 3), "max_px_err": err,
                  "nan_frac": float(np.isnan(p1[:, 0]).mean())}
log.put("bench", out)
