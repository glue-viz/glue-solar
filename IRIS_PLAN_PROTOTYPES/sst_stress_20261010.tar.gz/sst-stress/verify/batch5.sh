#!/bin/bash
V=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/07d33ef8-b8df-4ddb-b55c-24b6271a724b/scratchpad/sst-stress/verify
run() { n=$1; shift; echo "$n start $(date +%T) free $(df -g /Users/nabil/DATA | tail -1 | awk '{print $4}')" >> $V/out/batch5.txt; $V/run.sh $n "$@"; echo "$n end $(date +%T) $(tail -1 $V/out/$n.log)" >> $V/out/batch5.txt; }
run autosave autosave.py "$(ls /Users/nabil/DATA/SST/SST-archive_obs498_20230919_CHROMIS_4846/nb_4846_*_im.fits)" autosave
run wcsbench wcsbench.py "$(ls /Users/nabil/DATA/SST/SST-archive_obs498_20230919_CHROMIS_4846/nb_4846_*_im.fits)" wcsbench
run i255one iris.py '*4000255147*' i255one --windows 1403
run i255all iris.py '*4000255147*' i255all
echo "batch5 done $(date +%T)" >> $V/out/batch5.txt
