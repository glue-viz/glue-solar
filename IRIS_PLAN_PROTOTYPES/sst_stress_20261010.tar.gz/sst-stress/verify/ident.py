import sys, os, time, warnings; warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import h
log = h.Log("ident_" + sys.argv[2]); pk = h.Peak(log); pk.start()
app = h.app_setup()
from glue.config import data_factory
from glue.core.data_factories.helpers import find_factory, load_data, auto_data
p = sys.argv[1]
for x in sorted(data_factory.members, key=lambda m: -m.priority):
    if x.identifier is None: continue
    pk.reset(); time.sleep(0.05); t = time.perf_counter()
    try: r = bool(x.identifier(p))
    except Exception as e: r = repr(e)[:80]
    dt = time.perf_counter() - t; time.sleep(0.05)
    log.put(x.function.__name__, {"prio": x.priority, "claims": r, "s": round(dt, 4), "peak_rss": round(pk.rss, 2), "peak_fp": round(pk.fp, 2)})
pk.reset(); t = time.perf_counter(); f = find_factory(p); dt = time.perf_counter() - t; time.sleep(0.05)
log.put("find_factory", {"f": f.__name__, "s": round(dt, 3), "peak_rss": round(pk.rss, 2), "peak_fp": round(pk.fp, 2)})
os._exit(0)
