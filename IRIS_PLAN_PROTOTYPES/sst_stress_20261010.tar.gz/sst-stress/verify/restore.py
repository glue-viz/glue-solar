"""Verifier: restore a saved session in a fresh process. usage: restore.py SESSION NAME"""

import os
import sys
import time
import traceback
import warnings

warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import h  # noqa: E402

path, name = sys.argv[1], sys.argv[2]
log = h.Log(name)
peak = h.Peak(log)
peak.start()
app0 = h.app_setup()  # loads plugins (glue-solar) as the app does
from glue.core.data_factories import helpers  # noqa: E402
from glue_qt.app import GlueApplication  # noqa: E402
import irispy.io  # noqa: E402

T = h.Timer()
T.wrap(helpers, "load_data")
calls = {"read_files": 0}
_rf = irispy.io.read_files


def rf(*a, **k):
    calls["read_files"] += 1
    return _rf(*a, **k)


irispy.io.read_files = rf
r0 = h.ru()
t = time.perf_counter()
try:
    app = GlueApplication.restore_session(path)
    err = None
except Exception as e:  # noqa: BLE001
    app, err = None, f"{type(e).__name__}: {e}"
    log.put("traceback", traceback.format_exc()[-2500:])
t_restore = time.perf_counter() - t
t_idle = h.idle(app, quiet=0.2) if app is not None else 0
r1 = h.ru()
log.put("restore", {"restore_s": round(t_restore, 3), "idle_s": round(t_idle, 3), "error": err,
                    "load_data": T.report(), "read_files_calls": calls["read_files"],
                    "datasets": len(app.data_collection) if app else None,
                    "viewers": sum(len(t) for t in app.viewers) if app else None,
                    "read_gb": round(r1["read"] - r0["read"], 3), "rss_gb": round(r1["rss"], 2),
                    "peak_rss_gb": round(peak.rss, 2), "peak_fp_gb": round(peak.fp, 2), "dialogs": h.DIALOGS})
os._exit(0)
