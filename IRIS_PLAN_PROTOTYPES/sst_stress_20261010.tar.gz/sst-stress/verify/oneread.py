"""Verifier: SST6's candidate gain: one _raster_windows_data call for all windows against one per window (warm).
usage: oneread.py PATTERN NAME"""

import glob
import os
import sys
import time
import warnings

warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import h  # noqa: E402

pattern, name = sys.argv[1], sys.argv[2]
log = h.Log(name)
from glue_solar.sources.loaders import iris as li  # noqa: E402
from glue_solar.sources.loaders.scan import scan_directory  # noqa: E402

o = [o for o in scan_directory("/Users/nabil/DATA/IRIS", pattern=pattern) if o.rasters][0]
files = [str(p) for p in o.rasters]
out = {"files": len(files), "windows": o.windows,
       "cache": round(sum(h.cached(f) for f in files) / len(files), 3)}
for rep in range(2):
    t = time.perf_counter()
    li._raster_windows_data(files, o.windows, stack=True)
    out[f"one_call_all_windows_s_{rep}"] = round(time.perf_counter() - t, 2)
    t = time.perf_counter()
    for w in o.windows:
        li._raster_windows_data(files, [w], stack=True)
    out[f"one_call_per_window_s_{rep}"] = round(time.perf_counter() - t, 2)
log.put("oneread", out)
os._exit(0)
