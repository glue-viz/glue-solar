#!/bin/bash
V=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/07d33ef8-b8df-4ddb-b55c-24b6271a724b/scratchpad/sst-stress/verify
run() { n=$1; shift; echo "$n start $(date +%T) free $(df -g /Users/nabil/DATA | tail -1 | awk '{print $4}')" >> $V/out/batch6.txt; $V/run.sh $n "$@"; echo "$n end $(date +%T) $(tail -1 $V/out/$n.log)" >> $V/out/batch6.txt; }
run wcsbench wcsbench.py "$(ls /Users/nabil/DATA/SST/SST-archive_obs498_20230919_CHROMIS_4846/nb_4846_*_im.fits)" wcsbench
run oneread oneread.py '*3602506433*' oneread
echo "batch6 done $(date +%T)" >> $V/out/batch6.txt
