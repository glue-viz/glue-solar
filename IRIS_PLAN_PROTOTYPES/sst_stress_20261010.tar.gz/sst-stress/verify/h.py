"""Verifier harness helpers (independent of the survey's common.py)."""

import ctypes
import json
import os
import sys
import threading
import time

ROOT = "/private/tmp/claude-501/-Users-nabil-Git-glue-solar/07d33ef8-b8df-4ddb-b55c-24b6271a724b/scratchpad/sst-stress"
GS = f"{ROOT}/gs"
VOUT = f"{ROOT}/verify/out"
GB = 2**30
os.makedirs(VOUT, exist_ok=True)
sys.path.insert(0, GS)

_libc = ctypes.CDLL("libc.dylib", use_errno=True)
_proc = ctypes.CDLL("/usr/lib/libproc.dylib")


class _RU(ctypes.Structure):  # rusage_info_v2
    _fields_ = [("uuid", ctypes.c_uint8 * 16)] + [(n, ctypes.c_uint64) for n in (
        "user", "system", "pkg_idle", "intr", "pageins", "wired", "rss", "footprint", "start", "exit",
        "cu", "cs", "cpi", "cii", "cpageins", "celapsed", "bytesread", "byteswritten")]


def ru():
    r = _RU()
    _proc.proc_pid_rusage(os.getpid(), 2, ctypes.byref(r))
    return {"rss": r.rss / GB, "fp": r.footprint / GB, "read": r.bytesread / GB, "pageins": r.pageins}


def cached(path):
    """Fraction of path's pages resident in the page cache (mmap + mincore, no reads)."""
    size = os.path.getsize(path)
    pg = os.sysconf("SC_PAGE_SIZE")
    n = (size + pg - 1) // pg
    _libc.mmap.restype = ctypes.c_void_p
    _libc.mmap.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_long]
    _libc.mincore.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p]
    _libc.munmap.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
    fd = os.open(path, os.O_RDONLY)
    try:
        a = _libc.mmap(None, size, 1, 1, fd, 0)
        v = (ctypes.c_ubyte * n)()
        rc = _libc.mincore(a, size, v)
        _libc.munmap(a, size)
    finally:
        os.close(fd)
    return round(sum(b & 1 for b in bytes(v)) / n, 4) if rc == 0 else None


class Peak(threading.Thread):
    """Samples RSS/footprint every 20 ms; kills the process past 20 GB RSS."""

    def __init__(self, log):
        super().__init__(daemon=True)
        self.log, self.rss, self.fp = log, 0.0, 0.0

    def reset(self):
        self.rss, self.fp = 0.0, 0.0

    def run(self):
        while True:
            r = ru()
            self.rss, self.fp = max(self.rss, r["rss"]), max(self.fp, r["fp"])
            if r["rss"] > 20:
                self.log.put("KILLED_RSS", r)
                os._exit(3)
            time.sleep(0.02)


class Log:
    def __init__(self, name):
        self.path, self.d = f"{VOUT}/{name}.json", {}

    def put(self, k, v):
        self.d[k] = v
        print(k, json.dumps(v, default=str)[:600], flush=True)
        with open(self.path, "w") as f:
            json.dump(self.d, f, indent=1, default=str)


DIALOGS = []


def app_setup():
    """GlueApplication 1600x1000 with glue-solar loaded from the worktree; message boxes answered OK."""
    from qtpy.QtWidgets import QMessageBox, QDialog, QInputDialog

    def mb_exec(self, *a, **k):
        DIALOGS.append(("msgbox", self.text()[:120], (self.informativeText() or "")[:300]))
        return QMessageBox.Ok

    QMessageBox.exec = QMessageBox.exec_ = mb_exec
    for name in ("critical", "warning", "information", "question"):
        setattr(QMessageBox, name, staticmethod(lambda *a, _n=name, **k: (DIALOGS.append((_n, str(a[1:3])[:300])), QMessageBox.Ok)[1]))

    def dlg_exec(self, *a, **k):
        DIALOGS.append(("dialog", type(self).__name__))
        return 0

    QDialog.exec = QDialog.exec_ = dlg_exec
    from glue_qt.app import GlueApplication
    from glue.main import load_plugins

    load_plugins()
    import glue_solar

    assert glue_solar.__file__.startswith(GS), glue_solar.__file__
    app = GlueApplication()
    app.resize(1600, 1000)
    app.show()
    return app


def pending(app):
    for tab in app.viewers:
        for v in tab:
            c = v.figure.canvas
            if getattr(c, "_draw_pending", False):
                return True
            for la in v.layers:
                w = getattr(la, "_worker", None)
                if w is not None and (w.running or not w.work_queue.empty()):
                    return True
    co = getattr(app.data_collection, "_solar_coordinator", None)
    return co is not None and co._timer.isActive()


def idle(app, t0=None, quiet=0.06, timeout=1200):
    """Pump events until nothing is pending for `quiet` s; return seconds from t0 to the start of the quiet."""
    from glue_qt.utils import get_qapp

    q = get_qapp()
    t0 = t0 or time.perf_counter()
    last = time.perf_counter()
    while time.perf_counter() - t0 < timeout:
        tp = time.perf_counter()
        q.processEvents()
        now = time.perf_counter()
        if pending(app) or now - tp > 0.002:  # something ran inside processEvents, or still queued
            last = now
        elif now - last > quiet:
            return last - t0
        time.sleep(0.001)
    return time.perf_counter() - t0


class Timer:
    """Wrap callables, splitting main-thread and other-thread wall time."""

    def __init__(self):
        self.t = {}
        self.lock = threading.Lock()

    def wrap(self, owner, name, key=None):
        f = getattr(owner, name)
        key = key or f"{getattr(owner, '__name__', owner)}.{name}"
        T = self

        depth = threading.local()

        def w(*a, **k):
            if getattr(depth, "n", 0):  # nested call (chunking): counted in the outer one
                return f(*a, **k)
            depth.n = 1
            t = time.perf_counter()
            try:
                return f(*a, **k)
            finally:
                depth.n = 0
                dt = time.perf_counter() - t
                main = threading.current_thread() is threading.main_thread()
                with T.lock:
                    rec = T.t.setdefault(key, [0, 0.0, 0, 0.0])
                    if main:
                        rec[0] += 1
                        rec[1] += dt
                    else:
                        rec[2] += 1
                        rec[3] += dt

        setattr(owner, name, w)

    def reset(self):
        self.t = {}

    def report(self):
        return {k: {"main_n": v[0], "main_s": round(v[1], 3), "thr_n": v[2], "thr_s": round(v[3], 3)} for k, v in self.t.items()}


def mouse(viewer, kind, x, y):
    """Matplotlib mouse event at data coordinates (x, y) on viewer."""
    from matplotlib.backend_bases import MouseEvent

    ax = viewer.axes
    px, py = ax.transData.transform((x, y))
    ev = MouseEvent({"press": "button_press_event", "move": "motion_notify_event", "release": "button_release_event"}[kind],
                    viewer.figure.canvas, px, py, button=1 if kind != "move" else 1)
    viewer.figure.canvas.callbacks.process(ev.name, ev)
