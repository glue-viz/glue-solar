"""Verifier: do the 2020 SSTRED cubes show in an Image viewer, and does SPECSYS explain it? usage: spec.py CUBE NAME"""

import os
import sys
import time
import traceback
import warnings

warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import h  # noqa: E402

cube_path, name = sys.argv[1], sys.argv[2]
log = h.Log(name)
from astropy.io import fits  # noqa: E402

hd = fits.getheader(cube_path)
log.put("header", {k: hd.get(k) for k in ("SPECSYS", "OBSGEO-X", "OBSGEO-Y", "OBSGEO-Z", "DATE-BEG", "MJDREF", "CTYPE1",
                                           "CTYPE2", "CTYPE3", "CTYPE4", "CTYPE5", "CWDIS3", "VELOSYS")})
app = h.app_setup()
from glue.core.data_factories.helpers import auto_data, load_data  # noqa: E402
from glue_qt.viewers.image import ImageViewer  # noqa: E402

ds = load_data(cube_path, factory=auto_data)
app.add_datasets(ds)
cube = max(ds, key=lambda d: d.size)
w = cube.coords
try:
    w.world_axis_object_classes
    log.put("object_classes", "ok")
except Exception as e:  # noqa: BLE001
    log.put("object_classes", f"{type(e).__name__}: {e}")
for attempt in ((["specsys_topocent"] if "--fix-first" in sys.argv else ["as_shipped", "specsys_topocent"])):
    if attempt == "specsys_topocent":
        for d in ds:
            if getattr(d.coords, "wcs", None) is not None and not d.coords.wcs.specsys:
                d.coords.wcs.specsys = "TOPOCENT"
    n0 = len(h.DIALOGS)
    t = time.perf_counter()
    try:
        iv = app.new_data_viewer(ImageViewer, data=cube)
        h.idle(app)
        ok = {"layers": len(iv.layers), "ref": iv.state.reference_data is cube}
        iv.figure.canvas.draw()
        ok["drawn"] = True
    except Exception as e:  # noqa: BLE001
        ok = {"raised": f"{type(e).__name__}: {e}", "tb": traceback.format_exc()[-800:]}
    ok["s"] = round(time.perf_counter() - t, 2)
    ok["dialogs"] = h.DIALOGS[n0:]
    log.put(attempt, ok)
os._exit(0)
