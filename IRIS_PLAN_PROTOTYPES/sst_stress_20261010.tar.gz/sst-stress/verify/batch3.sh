#!/bin/bash
V=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/07d33ef8-b8df-4ddb-b55c-24b6271a724b/scratchpad/sst-stress/verify
f=$(ls /Users/nabil/DATA/SST/SST-archive_obs498_20230919_CHROMIS_4846/nb_4846_*_im.fits)
run() { n=$1; shift; echo "$n start $(date +%T) free $(df -g /Users/nabil/DATA | tail -1 | awk '{print $4}')" >> $V/out/batch3.txt; $V/run.sh $n beside.py "$f" $n "$@"; echo "$n end $(date +%T) $(tail -1 $V/out/$n.log)" >> $V/out/batch3.txt; }
run b1 
run b2
run b3 --no-roi
run b4 --no-profile
run b5 --sync
echo "batch3 done $(date +%T)" >> $V/out/batch3.txt
