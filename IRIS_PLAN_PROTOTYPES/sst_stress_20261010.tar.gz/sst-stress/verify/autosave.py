"""Verifier: does glue-solar's close autosave keep an SST session, and does 'Restore last session' then fail?
Also lists the 33 datasets File > Open makes. usage: autosave.py CUBE NAME"""

import os
import sys
import time
import traceback
import warnings

warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import h  # noqa: E402

cube_path, name = sys.argv[1], sys.argv[2]
log = h.Log(name)
app = h.app_setup()
from glue.core.data_factories.helpers import auto_data, load_data  # noqa: E402
from glue_qt.viewers.image import ImageViewer  # noqa: E402

ds = load_data(cube_path, factory=auto_data)
app.add_datasets(ds)
log.put("datasets", [(d.label.split("[")[-1][:20], d.shape, type(d.coords).__name__, len(d.main_components)) for d in ds])
cube = max(ds, key=lambda d: d.size)
app.new_data_viewer(ImageViewer, data=cube)
h.idle(app)
last = os.path.expanduser("~/.glue/glue-solar-last-session.glu")
t = time.perf_counter()
app.close()
from glue_qt.utils import get_qapp  # noqa: E402

for _ in range(50):
    get_qapp().processEvents()
    time.sleep(0.01)
log.put("autosave", {"exists": os.path.exists(last), "kb": os.path.exists(last) and round(os.path.getsize(last) / 1024, 1),
                     "s": round(time.perf_counter() - t, 3), "dialogs": h.DIALOGS})
# glue-solar's Plugins entry 'Restore last session'
import glue_solar  # noqa: E402
from glue.config import menubar_plugin  # noqa: E402

entry = [m for m in menubar_plugin if "last session" in m[0].lower()]
log.put("menu_entry", [e[0] for e in entry])
app2 = h.app_setup.__wrapped__() if hasattr(h.app_setup, "__wrapped__") else None
from glue_qt.app import GlueApplication  # noqa: E402

app2 = GlueApplication()
n0 = len(h.DIALOGS)
try:
    entry[0][1](app2.session, app2.data_collection)
    res = "returned"
except Exception as e:  # noqa: BLE001
    res = f"{type(e).__name__}: {e}"
    log.put("tb", traceback.format_exc()[-1200:])
h.idle(app2)
log.put("restore_last", {"result": res, "dialogs": h.DIALOGS[n0:]})
os._exit(0)
