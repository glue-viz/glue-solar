**Result: in Level 2, 16182 DN holds both iris_prep's saturation flag and plain clipping, and the flag is almost all of it.** OBSID 3860258481 (2014-03-29, X1 flare) has thousands of saturated samples. A second observation, OBSID 3802005374 (2015-01-13, M5.6, unsummed), gives the same picture. Matched pixel by pixel against Level 1, 99.88% of the 16182 DN samples (31,552 of 31,591) sit within 1 px of a Level 1 sample at or above iris_prep's threshold of 16000 DN. The other 39 are bright samples that were never flagged and were clipped anyway. The draft #226 branch handles this data correctly; irispy main does not.

Both files were reprocessed in 2026-03 with iris_prep 3.06 and Level 2 writer L12-2019-08-08. Both are the SDC (sdc.uio.no) copies.

## Files downloaded (121,802,511 B in total, all in /Users/nabil/DATA/IRIS/saturated/)
Each file was HEAD-checked and downloaded on its own with `test/dl.sh`.

**Level 2, from `https://sdc.uio.no/vol/fits/iris/level2/…`:**

| File | Bytes |
|---|---|
| iris_l2_20140329_140938_3860258481_raster_t000_r00000.fits.gz (quiet reference) | 17,204,520 |
| …_r00172.fits.gz | 17,480,824 |
| …_r00173.fits.gz | 17,112,280 |
| …_r00174.fits.gz | 16,153,549 |
| iris_l2_20150113_042117_3802005374_raster_t000_r00000.fits.gz | 9,916,938 |

**Level 1, from `https://www.lmsal.com/solarsoft/irisa/data/level1/YYYY/MM/DD/HHH00/`:**
- 34 frames for 2014, 35,490,240 B: every FUV and NUV frame of r00172 and r00173, plus `iris20140329_17465536_fuv.fits` and `iris20140329_17473287_fuv.fits` from r00174.
- 16 frames for 2015, 8,444,160 B: every FUV and NUV frame of r00000.
- The filenames come from each Level 2 file's auxiliary table.

**Checks on the file mapping:**
- r00173 has DATE_OBS 2014-03-29T17:45:36.510 and RASRPT=174, which is 1-based.
- Its auxiliary table lists Level 1 frames 17:45:40.51 to 17:46:45.97. In JSOC those frames are IIOLRPT=173, which is 0-based (`test/jsoc_20140329.txt`). So file r00173 is JSOC repeat 173.
- r00000 has NSATPIX=0 in every frame of JSOC repeat 0, so it works as the quiet reference.

## 1. Headers (`test/l2_raw.py` → `l2_raw.out`, `l2_raw_2015.out`, `hdr/r00173.txt`)
- **NSATPIX and TSATPXn are 0 in all 5 files.** The only other *SAT* keyword is SAT_ROT. NSPIKES=0.
- **TDMAXn against the stored maximum:**

| Window state | TDMAXn | Stored maximum |
|---|---|---|
| Saturated (2014) | 19,830 to 23,067 | 16182.00 (raw 32760) |
| Saturated (2015) | 20,985 to 21,317 | 16182.00 (raw 32760) |
| Unsaturated | equal to stored maximum within 0.25 DN | |

  Examples: r00173 C II 22736.9, Si IV 23066.9, Mg II k 21150.7. r00174 window 1343 is 19830.2, from one isolated pixel. Unsaturated example: r00173 Fe XII TDMAX 11306.5, stored 11306.50.
- **No raw code above 32760 appears anywhere**, including in 24 local files. That includes 32764, which is the writer's code for samples it receives as +Inf.
- **The saturation HISTORY line differs between the two observations:**
  - The 2014 files have no "saturated" HISTORY line at all.
  - The 2015 file has `HISTORY iris_prep  Set 4055 saturated pixels to Inf`.

## 2. Raw codes (`l2_raw.out`, `topdist.py` → `topdist.out`)

Counts of raw 32760 (16182 DN) per window and per raster step. Every step in these windows had an 8 s exposure.

| File | Window | Steps 0–7 | Total |
|---|---|---|---|
| r00000 (quiet, 14:09) | all | 0 | 0 |
| r00172 (17:44:21) | C II 1336 | 0,0,0,0,35,78,410,884 | 1407 |
| r00172 | Si IV 1403 | 27,6,20,10,37,208,784,1235 | 2327 |
| r00173 (17:45:36) | C II 1336 | 149,521,537,1430,893,1639,439,443 | 6051 |
| r00173 | Si IV 1403 | 616,933,1127,4064,1766,3248,1051,955 | 13760 |
| r00173 | Mg II k 2796 | 0,0,109,989,0,0,0,0 (NUV exposures 8,8,8,8,2.44,2.44,2.44,2.44 s) | 1098 |
| r00174 | C II / Si IV / 1343 | see l2_raw.out | 2905 / 4388 / 2 |
| 2015 r00000 (2 s exposures) | Si IV 1394 | 751,1085,780,507,138,35,0,0 | 3296 |
| 2015 r00000 | Si IV 1403 | 197,340,386,176,0,0,0,0 | 1099 |

- The saturated steps match JSOC: Mg II k at steps 2–3 (NSATPIX 105 and 985), and the FUV peaks at steps 3 and 5 (5695 and 5013).
- **The samples pile up at the ceiling.** Example, r00173 Si IV:

  | DN range | Samples |
  |---|---|
  | [15500, 16000) | 123 |
  | [16000, 16100) | 29 |
  | [16100, 16182) | 34 |
  | exactly 16182 | 13760 |
  | above 16182 | 0 |

## 3. HISTORY N against the count of 32760 samples (`hist_scan.py`, `hist_vs_count.py` → `hist_vs_count.out`)
- **N never equals the count of 32760 samples**, per file or per window.
  - 2015: N=4055, while the file has 4395 samples at 32760 (3296 in Si IV 1394 and 1099 in Si IV 1403).
  - In the local files, N is 3, 6, 18, 45 or 69, while the counts run from 0 to 103.
- **N does equal the sum of Level 1 samples at or above 16000 over the 8 FUV frames of 2015 r00000:** 858+1293+1128+638+117+21+0+0 = 4055 (`l1_nsatpix_2015.out`).
- **N is one value per observation.** All 99 local rasters of OBSID 3602506433 say "Set 6", and all 8 of OBSID 3400109360 say "Set 18".
  - irisl12_savespectraldata.pro lines 571–572 copy HISTORY from the FUV header only while `history` is still empty.
  - The 2014 flare files have no line because repeat 0 had no flagged pixels (JSOC NSATPIX=0).
- **The 2014 flare files carry no line even though every r00173 FUV frame had 734 to 5599 Level 1 samples at or above 16000.**
- **The code being run:** `iris_prep.pro` lines 594–600 run `WHERE(odata ge sat_thresh)`, set the matches to +Inf, and write the HISTORY line. `sat_thresh` defaults to 1.6e4. The Level 2 writer calls iris_prep on a batch of files (savespectraldata lines 355 and 434).

## 4. Shape of the 16182 DN regions (`shape.py` → `shape.out`, `shape_2015.out`)

| File / window | Samples | In regions of ≥10 samples | Isolated single samples | Within 3 px of a line core | Widest run along wavelength |
|---|---|---|---|---|---|
| r00173 C II | 6051 | 99.2% | 1 | 97.5% | 119 px (3.09 Å) |
| r00173 Si IV | 13760 | 99.8% | 0 | 99.8% | 268 px (6.82 Å) |
| r00173 Mg II k | 1098 | 100% | 0 | 98.8% | 69 px |
| r00174 Si IV | 4388 | 99.5% | 2 | 96.5% | 74 px |
| r00174 1343 | 2 | 0% | 2 | 0% | 1 px |
| 2015 Si IV 1403 | 1099 | 98.0% | 0 | 98.5% | 38 px |

- **These are flat plateaus at the line cores.** Example profile, r00173 Si IV step 6: 712, 755, 389, 4282, then 16182 for 68 samples, then 11864, −199, 661.
- **In two rows of r00173 steps 3 and 5, the plateau covers the whole Si IV window** (columns 9–276). In Level 1 those rows are also 16358 across the full width. This may be charge bleeding along the dispersion direction; I did not check the CCD orientation.
- **The 2 isolated samples in window 1343** each come from a single Level 1 pixel at 16358, probably a particle hit. They were stored at 16182 the same way.
- **Samples at −199 DN (raw −32764, the writer's low clip) sit next to plateaus** (`undershoot.py`). In r00173 Si IV, 47 of 107 are within 1 px of a 16182 sample; in r00000, 0 of 6. This is consistent with resampling undershoot.

## 5. Level 1 against Level 2 (`l1_l2.py` → `l1_l2.out`, `l1_l2_summary.out`; `l1_nsatpix.py`)

**What Level 1 looks like:**
- Level 1 is int16 and includes a pedestal of about 100 DN.
- In saturated frames the highest code is 16358. That is the frame's DATAMAX, not 16383.
- The codes below it are quantised (LUTID=4): 16036, 16102, 16168, 16234, 16300, 16358.
- **Level 1 NSATPIX equals the count of samples at or above 15063 in all 50 frames.** So NSATPIX uses a threshold between 15000 and 15063 DN. It is not iris_prep's 16000 and not the 16358 ceiling.

**Method:**
- An FFT search found the overall offset per window. 32-column tiles were then refined by up to ±3 px, and the masks were compared with 1 px tolerance.
- Offsets found: C II (−22, 2–3), Si IV 2014 (8–9, 2–3), Mg II (25–27, −3/−4), 2015 (35–41, 21–23).

| Obs | Window | Steps | L1 ≥16000 | L2 = 16182 | L2 16182 with no L1 flag within 1 px | L1 flag with no L2 16182 within 1 px | L1 flag landing on an L2 missing sample |
|---|---|---|---|---|---|---|---|
| 2014 | C II 1336 | 14 | 8209 | 8414 | 0 | 1 (L2 = −199) | 1 |
| 2014 | Si IV 1403 | 18 | 17756 | 17682 | 2 (L1 15579) | 7 (L2 2710 to 14700) | 1 |
| 2014 | Mg II k 2796 | 2 | 983 | 1098 | 26 (L1 13876 to 15970) | 1 (L2 15758) | 0 |
| 2014 | 1343 | 2 | 2 | 2 | 0 | 0 | 0 |
| 2015 | Si IV 1394 | 6 | 3205 | 3296 | 4 (L1 15774 to 15904) | 12 | 0 |
| 2015 | Si IV 1403 | 4 | 1027 | 1099 | 7 (L1 12158 to 15970) | 2 | 3 |

- **Level 1 flag → Level 2:** every Level 1 sample at or above 16000 lands on a 16182 plateau, except the few in the table.
  - All of them are flagged, including the near-ceiling codes 16036 to 16300.
  - The few misses disappear at 2–3 px tolerance or at a single overall offset.
    - At 3 px, r00173 Si IV steps 3 and 5 have 0 in both directions.
    - 2015 steps 1 and 2 at offset (35, 22) have 0.
  - So the misses come from the alignment, not from flags that were lost.
- **Level 2 16182 → Level 1:** a few unflagged Level 1 samples also became 16182.
  - The clearest case is Mg II step 2: 21 of 109 samples at 1 px, and 9 still at 2 px (`edge_cases.py`).
  - The Level 1 values there are 13876 to 15774. Next to them, unclipped samples show a Level 2 / Level 1 ratio of about 1.2.
  - Over all bright unflagged samples, the Level 2 / Level 1 ratio has a median of 0.94–1.00 and a 99th percentile of 1.2–1.5. So any Level 1 value above about 12000 can calibrate past 16182 and be clipped.

## 6. irispy (`irispy_check.py` → `irispy_main.out`, `irispy_branch.out`; file r00173)

**What the reader returns (main and the branch read the same):**
- Exactly `raw*0.25+7992` (maximum difference 0).
- Every raw 32760 sample becomes 16182.0, with mask False: 13760 of 13760 in Si IV, 6051 in C II, 1098 in Mg II k.
- Nothing is above 16182. The mask covers only raw −32768 and −32764 (−200 and −199 DN).

**irispy main:**
- `calculate_moments(saturation_limit=16182*u.DN)` raises `UnitConversionError: 'DN' and 'DN_IRIS_FUV' are not convertible`.
- With `16182.0` it flags 0 pixels, because the test is a strict `>`.

**Draft #226:**
- I tested the working tree at e3656cd, which has uncommitted edits to moments.py and test_moments.py.
- For both `16182*u.DN` and `16182.0`, the `"saturated"` map is exactly the set of (step, y) pixels that have a 16182 sample:

  | Window | Pixels flagged and set to NaN in intensity |
  |---|---|
  | Si IV | 428 |
  | C II | 213 |
  | Mg II k | 21 |

- On a DN/s cube with mixed exposures (Mg II k, 8 s and 2.44 s), the branch's limit per step gives the same 21. A single limit of 16182/8 DN/s would add 27 false pixels in the 2.44 s steps.

## Conclusion
Raw 32760 (16182 DN) is the Level 2 writer's clip ceiling (savespectraldata lines 941–942).

**What it contains:**
- Every sample iris_prep flagged. The flag is raw Level 1 ≥ 16000 DN, which takes in the top 6 codes, not only the 16358 ceiling. The flag reaches the writer as about 2×10⁴ DN rather than +Inf, so 32764, NSATPIX and TSATPXn never record it.
- A small minority of bright samples that were never flagged and simply calibrated past the ceiling: 39 of 31,591 here (0.12%). In this sample they are concentrated in NUV Mg II, 2.4% of its 16182 samples.

**The HISTORY "Set N" line cannot be used per file.** N is one batch count for the whole observation.

**How sure:**
- High for raster files reprocessed with iris_prep 3.06 and L12-2019-08-08, SDC copies: two flares, 46 window-steps matched pixel by pixel to Level 1.
- Lower elsewhere. Older pipeline versions show the same 32760 ceiling locally, but they have no Level 1 to check against.

**For #226:** a limit of 16182 DN with `>=` and a limit per exposure step is right for this data. Main's strict `>` misses all of it, and main rejects a value given in DN.

**What I could not check:**
- Whether the LMSAL copies match the SDC copies. LMSAL only offers whole-observation tars.
- SJI files.
- A flare processed with a newer pipeline. Candidate 3 (2024) is 2.6 GB.
- Why near-threshold Level 1 codes sit below 16383; the LUT explanation is only inferred.
- Which way the CCD bleeds charge.

Scripts and outputs are in /private/tmp/claude-501/-Users-nabil-Git-glue-solar/cd8c65cb-901c-4bef-8f72-6ed14574399c/scratchpad/satobs/test/.
- Main analysis: `l2_raw.py`, `topdist.py`, `hist_scan.py`, `hist_vs_count.py`, `shape.py`, `undershoot.py`, `l1_l2.py`, `l1_nsatpix.py`.
- Spot checks and irispy: `edge_cases.py`, `irispy_check.py`.
- Download and JSOC query: `dl.sh`, `jsoc_list.py`.
- Each script's output is the matching `*.out` file.
- `src/` holds the fetched `iris_prep.pro` and `irisl12_savespectraldata.pro`.

Nothing outside /Users/nabil/DATA/IRIS/saturated/ and the scratch directory was changed.
