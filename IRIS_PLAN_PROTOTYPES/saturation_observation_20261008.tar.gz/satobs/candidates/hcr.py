"""Query LMSAL HCR for IRIS observations covering a time; print obs and Level 2 file URLs + sizes."""
import json, sys, urllib.request, urllib.parse
t0, t1 = sys.argv[1], sys.argv[2]
want = sys.argv[3] if len(sys.argv) > 3 else None
q = urllib.parse.urlencode({"cmd": "search-events3", "outputformat": "json", "startTime": t0, "stopTime": t1,
                            "instrument": "IRIS", "hasData": "true", "limit": 200})
req = urllib.request.Request("https://www.lmsal.com/hek/hcr?" + q, headers={"User-Agent": "Mozilla/5.0"})
d = json.loads(urllib.request.urlopen(req, timeout=120).read().decode("utf-8", "replace"))
for e in d["Events"]:
    if want and str(e["obsId"]) != want:
        continue
    print(f"{e['obsId']} {e['startTime']} -> {e['stopTime']} | {e.get('goal')} | xy=({e.get('xCen'):.0f},{e.get('yCen'):.0f}) "
          f"| raster_fovx={e.get('raster_fovx')} repeats={e.get('iris_repeats')} l12l2={e.get('iris_l12l2_rundate')} prep={e.get('iris_prep_version')}")
    print("   title:", e.get("obsTitle"), "| planners:", e.get("planners"))
    for g in e.get("groups", []):
        print(f"   {g.get('group_name'):18s} {g.get('comp_data_size_mb')} MB  n={g.get('num_images') or g.get('numrasters')} "
              f"steps={g.get('raster_numsteps')} exp={g.get('min_exptime')}-{g.get('max_exptime')}  {g.get('comp_data_url')}")
