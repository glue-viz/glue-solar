"""Print title and every sentence containing a pattern from arXiv/ar5iv HTML files."""
import html, re, sys
pat = re.compile(sys.argv[1], re.I)
for f in sys.argv[2:]:
    t = open(f, encoding="utf-8", errors="replace").read()
    title = re.search(r"<title>(.*?)</title>", t, re.S)
    t = re.sub(r"<(script|style|math)[^>]*>.*?</\1>", " ", t, flags=re.S)
    t = re.sub(r"<annotation[^>]*>.*?</annotation>", " ", t, flags=re.S)
    t = html.unescape(re.sub(r"<[^>]+>", " ", t))
    t = re.sub(r"\s+", " ", t)
    print("=====", f, "|", html.unescape(title.group(1).strip()) if title else "")
    for s in re.split(r"(?<=[.!?])\s+(?=[A-Z(])", t):
        if pat.search(s):
            print("  -", s.strip()[:700])
