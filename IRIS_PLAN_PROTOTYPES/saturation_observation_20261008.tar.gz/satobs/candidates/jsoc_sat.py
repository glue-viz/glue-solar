"""Query JSOC iris.lev1 for frames with NSATPIX>0 in a time range; summarise per OBSID and IMG_PATH."""
import json, sys, urllib.request, urllib.parse, collections
rng, minsat = sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 1
extra = sys.argv[3] if len(sys.argv) > 3 else ""
ds = f"iris.lev1[{rng}][? NSATPIX > {minsat - 1} {extra} ?]"
url = "http://jsoc.stanford.edu/cgi-bin/ajax/jsoc_info?" + urllib.parse.urlencode(
    {"ds": ds, "op": "rs_list", "key": "T_OBS,ISQOLTID,IMG_PATH,EXPTIME,DATAMAX,NSATPIX,SUMSPTRL,SUMSPAT"})
d = json.load(urllib.request.urlopen(url, timeout=300))
if d.get("status"):
    sys.exit(f"status {d.get('status')}: {d.get('error')}")
kw = {k["name"]: k["values"] for k in d.get("keywords", [])}
print("query:", ds, "count:", d["count"])
g = collections.defaultdict(list)
for i in range(d["count"]):
    g[(kw["ISQOLTID"][i], kw["IMG_PATH"][i])].append(i)
for (obs, path), idx in sorted(g.items()):
    best = max(idx, key=lambda i: int(kw["NSATPIX"][i]))
    print(f"{obs} {path:9s} nframes={len(idx):4d} first={kw['T_OBS'][idx[0]]} last={kw['T_OBS'][idx[-1]]} "
          f"maxNSAT={kw['NSATPIX'][best]} at {kw['T_OBS'][best]} exp={float(kw['EXPTIME'][best]):.3f} "
          f"DATAMAX={sorted(set(kw['DATAMAX'][i] for i in idx))[-3:]} sum={kw['SUMSPTRL'][best]}x{kw['SUMSPAT'][best]}")
