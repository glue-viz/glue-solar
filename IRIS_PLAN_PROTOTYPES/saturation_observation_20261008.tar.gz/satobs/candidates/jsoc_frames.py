"""List saturated FUV/NUV frames with OBS repeat (raster index) and frame-list index."""
import json, sys, urllib.request, urllib.parse
ds = f"iris.lev1[{sys.argv[1]}][? NSATPIX >= {sys.argv[2]} AND ISQOLTID = {sys.argv[3]} AND IMG_PATH IN ('FUV','NUV') ?]"
url = "http://jsoc.stanford.edu/cgi-bin/ajax/jsoc_info?" + urllib.parse.urlencode(
    {"ds": ds, "op": "rs_list", "key": "T_OBS,IMG_PATH,EXPTIME,NSATPIX,DATAMAX,IIOLRPT,IIOLNRPT,IIFLRPT,ISQFLTDX,ISQFLTNX"})
d = json.load(urllib.request.urlopen(url, timeout=300))
kw = {k["name"]: k["values"] for k in d.get("keywords", [])}
print(ds, "count", d["count"])
for i in range(d["count"]):
    print(" ".join(f"{k}={kw[k][i]}" for k in kw))
