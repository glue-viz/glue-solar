"""List GOES flares (HEK, SSW Latest Events / SWPC) in a time window."""
import json, sys, urllib.request, urllib.parse
q = urllib.parse.urlencode({"cosec": 2, "cmd": "search", "type": "column", "event_type": "fl",
    "event_starttime": sys.argv[1], "event_endtime": sys.argv[2], "event_coordsys": "helioprojective",
    "x1": -1200, "x2": 1200, "y1": -1200, "y2": 1200, "result_limit": 100,
    "return": "event_starttime,event_peaktime,event_endtime,fl_goescls,ar_noaanum,frm_name,hpc_x,hpc_y"})
d = json.loads(urllib.request.urlopen("https://www.lmsal.com/hek/her?" + q, timeout=120).read().decode("utf-8", "replace"))
for e in d["result"]:
    if e.get("fl_goescls"):
        print(e["event_starttime"], e["event_peaktime"], e["event_endtime"], e["fl_goescls"], "AR", e.get("ar_noaanum"), e["frm_name"], round(e["hpc_x"]), round(e["hpc_y"]))
