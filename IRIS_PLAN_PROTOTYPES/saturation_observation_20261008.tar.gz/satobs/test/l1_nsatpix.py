"""L1 NSATPIX vs counts at the top codes. Usage: python -I l1_nsatpix.py L1FILE..."""
import sys
import numpy as np
from astropy.io import fits
for p in sorted(sys.argv[1:]):
    with fits.open(p, do_not_scale_image_data=True) as f:
        d = f[1].data; h = f[1].header
    v, c = np.unique(d[d > -32768], return_counts=True)
    cum = np.cumsum(c[::-1])[::-1]  # cum[i] = count(d >= v[i])
    hit = [int(v[i]) for i in range(len(v)) if cum[i] == h["NSATPIX"]]
    print(f"{p.split('/')[-1]:32s} {h['IMG_PATH']} exp={h['EXPTIME']:.2f} LUTID={h['LUTID']} DATAMAX={h['DATAMAX']} NSATPIX={h['NSATPIX']:5d} "
          f"==16358:{int((d == 16358).sum()):5d} >=16000:{int((d >= 16000).sum()):5d} | top codes {list(zip(v[-4:].tolist(), c[-4:].tolist()))} | threshold giving NSATPIX: {hit or 'none'}")
