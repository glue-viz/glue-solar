"""List JSOC iris.lev1 frames (all, not only saturated) in a time range for one OBSID."""
import json, sys, urllib.request, urllib.parse
ds = f"iris.lev1[{sys.argv[1]}][? ISQOLTID = {sys.argv[2]} ?]"
url = "http://jsoc.stanford.edu/cgi-bin/ajax/jsoc_info?" + urllib.parse.urlencode(
    {"ds": ds, "op": "rs_list", "key": "T_OBS,IMG_PATH,EXPTIME,NSATPIX,DATAMAX,IIOLRPT,ISQFLTDX,SUMSPTRL,SUMSPAT"})
d = json.load(urllib.request.urlopen(url, timeout=300))
kw = {k["name"]: k["values"] for k in d.get("keywords", [])}
print(ds, "count", d["count"])
for i in range(d["count"]):
    print(" ".join(f"{k}={kw[k][i]}" for k in kw))
