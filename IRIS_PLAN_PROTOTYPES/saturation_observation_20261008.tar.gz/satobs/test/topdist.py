"""Item 2: Level 2 samples near the ceiling, in DN bins, per window. Usage: python -I topdist.py FILE..."""
import sys
import numpy as np
from astropy.io import fits
EDGES = [12000, 14000, 15000, 15500, 16000, 16100, 16182, 16182.01, 1e9]
for p in sys.argv[1:]:
    f = fits.open(p, do_not_scale_image_data=True); h = f[0].header
    for n in (1, 5, 9):
        dn = f[n].data * 0.25 + 7992
        c = np.histogram(dn, EDGES)[0]
        print(f"{p.split('_')[-1][:6]} {h['DATE_OBS'][11:19]} win {n} {h[f'TDESC{n}']:<12} " + " ".join(
            f"[{a:g},{b:g}):{x}" if b < 1e8 and a != 16182 else (f"==16182:{x}" if a == 16182 else f">16182.01:{x}")
            for a, b, x in zip(EDGES[:-1], EDGES[1:], c)))
