"""-199 DN (raw -32764, the writer's low clip) next to 16182 DN plateaus vs elsewhere. Usage: python -I undershoot.py FILE..."""
import sys
import numpy as np
from astropy.io import fits
from scipy import ndimage
for p in sys.argv[1:]:
    f = fits.open(p, do_not_scale_image_data=True); h = f[0].header
    for n in range(1, h["NWIN"] + 1):
        d = f[n].data; low = d == -32764; top = d == 32760
        near = np.stack([ndimage.binary_dilation(t, np.ones((3, 3), bool)) for t in top])
        if low.sum() or top.sum():
            print(f"{p.split('_')[-1][:6]} win {n} {h[f'TDESC{n}']:<12} raw -32764 (-199 DN): {low.sum():5d}, of them within 1 px of 32760: {(low & near).sum():5d} | 32760: {top.sum()}")
