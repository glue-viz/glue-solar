"""Item 5: Level 1 raw values vs Level 2 raw codes at the same pixels.

Usage: python -I l1_l2.py DATADIR L2FILE [L2FILE...]
For each L2 window with any 32760 code, and each step whose L1 frame (named in the L2 aux
table) is in DATADIR: crop L1 around TSCn..TECn, find the global integer (dy, dx) offset by FFT
correlation of the L1 >= 16000 mask (iris_prep's sat_thresh) with the L2 32760 mask, then refine
it per 32-column tile within +-3 px (the warp is not a pure shift), and compare both masks with a
1 px tolerance. L1 flags that land on L2 missing samples (-200 DN, raw -32768) are counted apart.
"""
import re, sys
import numpy as np
from astropy.io import fits
from scipy import ndimage, signal

L2TOP, SAT, PY, PX, TILE, R = 32760, 16000, 25, 40, 32, 3
datadir = sys.argv[1]
K = np.ones((3, 3), bool)
ratios = []

for l2path in sys.argv[2:]:
    f = fits.open(l2path, do_not_scale_image_data=True)
    h = f[0].header; tab = f[-1].data
    print(f"\n=== {l2path.split('/')[-1]}")
    for n in range(1, h["NWIN"] + 1):
        d2 = f[n].data
        if not (d2 == L2TOP).any():
            continue
        nuv = h[f"TDET{n}"] == "NUV"
        c0, r0 = h[f"TSC{n}"] - 1, h[f"TSR{n}"] - 1
        for s in range(d2.shape[0]):
            name = re.search(r"iris\d{8}_\d{8}_[fn]uv\.fits", tab["NUVfilename" if nuv else "FUVfilename"][s]).group(0)
            try:
                with fits.open(f"{datadir}/{name}", do_not_scale_image_data=True) as g:
                    d1, h1 = g[1].data.astype(np.int32), g[1].header
            except FileNotFoundError:
                continue
            l2 = d2[s].astype(np.int32); m2 = l2 == L2TOP; ny, nx = l2.shape
            big = np.pad(d1, ((PY + R, PY + R), (PX + R, PX + R)), constant_values=-32768)
            crop = big[R + r0: R + r0 + ny + 2 * PY, R + c0: R + c0 + nx + 2 * PX]
            cor = signal.correlate((crop >= SAT).astype(float), m2.astype(float), mode="valid", method="fft")
            iy, ix = np.unravel_index(np.argmax(cor), cor.shape)
            gy, gx = iy - PY + r0, ix - PX  # L2 (y, x) <-> L1 (y+gy, c0+x+gx)
            l1a = np.empty_like(l2); shifts = set()
            for t0 in range(0, nx, TILE):
                t1 = min(t0 + TILE, nx); best = (-1, 0, 0)
                for ddy in range(-R, R + 1):
                    for ddx in range(-R, R + 1):
                        y0, x0 = PY + R + gy + ddy, PX + R + c0 + gx + ddx
                        sub = big[y0: y0 + ny, x0 + t0: x0 + t1]
                        sc = ((sub >= SAT) & m2[:, t0:t1]).sum() - ((sub >= SAT) ^ m2[:, t0:t1]).sum()
                        if sc > best[0] or (sc == best[0] and abs(ddy) + abs(ddx) < abs(best[1]) + abs(best[2])):
                            best = (sc, ddy, ddx)
                _, ddy, ddx = best; shifts.add((gy + ddy, gx + ddx))
                y0, x0 = PY + R + gy + ddy, PX + R + c0 + gx + ddx
                l1a[:, t0:t1] = big[y0: y0 + ny, x0 + t0: x0 + t1]
            missing = l2 == -32768
            for thr in (16358, SAT):
                m1 = l1a >= thr
                m1d, m2d = ndimage.binary_dilation(m1, K), ndimage.binary_dilation(m2, K)
                a = m2 & ~m1d; b = m1 & ~m2d & ~missing; bm = m1 & missing
                l1max3 = ndimage.maximum_filter(l1a, 3)
                tag = "==16358" if thr == 16358 else ">=16000"
                print(f"win {n} {h[f'TDESC{n}']:<12} step {s} {name[4:-5]} exp={h1['EXPTIME']:.2f}s NSATPIX={h1['NSATPIX']:5d} "
                      f"L1{tag} frame={int((d1 >= thr).sum()):5d} win={int(m1.sum()):5d} | L2top={int(m2.sum()):5d} | "
                      f"L2top w/o L1flag<=1px: {int(a.sum())}{' L1 3x3 max ' + str(sorted(l1max3[a].tolist())[:8]) if a.any() else ''} | "
                      f"L1flag w/o L2top<=1px: {int(b.sum())}{' L2 DN ' + str(sorted((l2[b] * .25 + 7992).tolist())[:8]) if b.any() else ''} "
                      f"| L1flag on L2 missing: {int(bm.sum())}")
            print(f"     offsets used (dy,dx): {sorted(shifts)}")
            # gain L2 DN / L1 raw for bright unflagged pixels well inside unflagged areas
            ok = (l1a >= 4000) & (l1a < SAT) & ~ndimage.binary_dilation(l1a >= SAT, K, iterations=2) & (l2 < L2TOP) & ~missing
            if ok.sum() > 50:
                r = (l2[ok] * .25 + 7992) / l1a[ok]
                ratios.append(r)
                print(f"     L2DN/L1raw for {ok.sum()} unflagged L1 in [4000,16000): p1={np.percentile(r,1):.3f} p50={np.median(r):.3f} p99={np.percentile(r,99):.3f} max={r.max():.3f}")
if ratios:
    r = np.concatenate(ratios)
    print(f"\nALL: L2DN/L1raw for {r.size} unflagged L1 in [4000,16000): p1={np.percentile(r,1):.3f} p50={np.median(r):.3f} p99={np.percentile(r,99):.3f} p99.9={np.percentile(r,99.9):.3f} max={r.max():.3f}")
