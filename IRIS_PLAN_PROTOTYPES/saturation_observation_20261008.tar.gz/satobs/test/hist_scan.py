"""Which local Level 2 primary headers carry an iris_prep saturation HISTORY line. Usage: python -I hist_scan.py FILE..."""
import sys
from astropy.io import fits
for p in sys.argv[1:]:
    try:
        h = fits.getheader(p)
    except Exception as e:
        continue
    hits = [str(x) for x in h.get("HISTORY", []) if "satur" in str(x).lower()]
    print(f"{p.split('/')[-1]} INSTRUME={h.get('INSTRUME')} IPRPVER={h.get('IPRPVER')} VER_RF2={h.get('VER_RF2')} DATE_RF2={h.get('DATE_RF2')} NSATPIX={h.get('NSATPIX')} {hits[:2]}")
