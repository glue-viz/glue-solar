"""Items 1-4: Level 2 raster headers and raw int16 codes. Usage: python -I l2_raw.py FILE..."""
import re, sys
import numpy as np
from astropy.io import fits
from scipy import ndimage

TOP = 32760  # raw code of 16182 DN with BSCALE 0.25, BZERO 7992

for path in sys.argv[1:]:
    f = fits.open(path, do_not_scale_image_data=True)
    h = f[0].header
    print(f"\n=== {path.split('/')[-1]}  DATE_OBS={h['DATE_OBS']} RASRPT={h['RASRPT']} iris_prep={h.get('IPRPVER')}")
    print("SAT keys:", {k: h[k] for k in h if "SAT" in k})
    print("DATAMAX", h["DATAMAX"], "DATAMIN", h["DATAMIN"], "NSPIKES", h["NSPIKES"], "MISSVALS", h["MISSVALS"])
    hist = [str(x) for x in h.get("HISTORY", [])]
    print("HISTORY matching sat/inf/clip:", [x for x in hist if re.search(r"sat|inf\b|clip|nan", x, re.I)] or "none")
    aux = f[-2].data; ah = f[-2].header
    for n in range(1, h["NWIN"] + 1):
        e = f[n]; d = e.data  # (step, y, lambda) int16
        bs, bz = e.header["BSCALE"], e.header["BZERO"]
        det = h[f"TDET{n}"]
        expcol = ah["EXPTIMEN"] if det == "NUV" else ah["EXPTIMEF"]
        stored_max = d.max() * bs + bz
        print(f"-- win {n} {h[f'TDESC{n}']:<12} {det} TDMAX={h[f'TDMAX{n}']:.1f} stored max={stored_max:.2f} DN (raw {d.max()}) "
              f"TSATPX={h[f'TSATPX{n}']} raw>=32760:{(d >= TOP).sum()} ==32760:{(d == TOP).sum()} >32760:{(d > TOP).sum()} "
              f"raw==-32768:{(d == -32768).sum()}")
        vals, cnts = np.unique(d, return_counts=True)
        print("   top 6 raw codes:", list(zip(vals[-6:].tolist(), cnts[-6:].tolist())))
        for s in range(d.shape[0]):
            m = d[s] == TOP
            if not m.any():
                continue
            lab, nlab = ndimage.label(m)  # 4-connected in (y, lambda)
            sizes = np.bincount(lab.ravel())[1:]
            ys, xs = np.nonzero(m)
            # next-highest code below TOP in this step, and how many samples sit just below
            below = d[s][(d[s] < TOP) & (d[s] > -32768)]
            print(f"   step {s} exp={aux[s, expcol]:.2f}s n32760={m.sum():5d} regions={nlab:4d} singletons={(sizes == 1).sum():3d} "
                  f"largest={sizes.max():4d} lambda-px range={xs.min()}-{xs.max()} y range={ys.min()}-{ys.max()} "
                  f"next code below={below.max()} (n in 32700..32759: {((d[s] >= 32700) & (d[s] < TOP)).sum()})")
