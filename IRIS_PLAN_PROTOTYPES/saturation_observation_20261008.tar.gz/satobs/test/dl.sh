#!/bin/bash
# usage: dl.sh URL  -- HEAD for size, refuse > 100 MB, download one file into /Users/nabil/DATA/IRIS/saturated/
set -e
url="$1"; dest=/Users/nabil/DATA/IRIS/saturated/$(basename "$url")
size=$(curl -sIL "$url" | awk 'tolower($1)=="content-length:"{s=$2} END{print s+0}')
code=$(curl -sIL -o /dev/null -w '%{http_code}' "$url")
echo "HEAD $code $size $url"
[ "$code" = 200 ] || exit 1
[ "$size" -le 100000000 ] || { echo "too big"; exit 1; }
[ -e "$dest" ] && { echo "exists"; ls -l "$dest"; exit 0; }
curl -sfL -o "$dest" "$url"
ls -l "$dest"
