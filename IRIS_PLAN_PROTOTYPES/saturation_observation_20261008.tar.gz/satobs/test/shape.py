"""Item 4: shape of the 16182 DN (raw 32760) regions. Usage: python -I shape.py FILE..."""
import sys
import numpy as np
from astropy.io import fits
from scipy import ndimage

LINES = {"C II 1336": (1334.532, 1335.708), "Si IV 1403": (1402.770,), "Mg II k 2796": (2796.352, 2803.531), "1343": (1343.5,)}
for p in sys.argv[1:]:
    f = fits.open(p, do_not_scale_image_data=True); h = f[0].header
    print(f"\n=== {p.split('/')[-1]}")
    for n in range(1, h["NWIN"] + 1):
        d = f[n].data; e = f[n].header; desc = h[f"TDESC{n}"]
        if not (d == 32760).any():
            continue
        lam = e["CRVAL1"] + (np.arange(d.shape[2]) + 1 - e["CRPIX1"]) * e["CDELT1"]
        cores = [int(np.argmin(abs(lam - l))) for l in LINES.get(desc, ())]
        tot = big = single = core = 0; runs = []
        for s in range(d.shape[0]):
            m = d[s] == 32760
            lab, nl = ndimage.label(m)
            if nl == 0:
                continue
            sizes = np.bincount(lab.ravel())[1:]
            tot += m.sum(); single += (sizes == 1).sum(); big += sizes[sizes >= 10].sum()
            for sl, lbl in zip(ndimage.find_objects(lab), range(1, nl + 1)):
                reg = lab[sl] == lbl
                runs.append(int(reg.sum(axis=1).max()))  # longest wavelength extent in one row
                if any(sl[1].start - 3 <= c < sl[1].stop + 3 for c in cores):
                    core += reg.sum()
        print(f"win {n} {desc:<12} 32760 samples={tot:5d} | in regions >=10 samples: {100 * big / tot:5.1f}% | singletons={single} "
              f"| regions={len(runs)} | within 3 px of a line core ({[round(l, 2) for l in LINES.get(desc, ())]} A, cols {cores}): {100 * core / tot:5.1f}% "
              f"| widest run along wavelength per region: median={int(np.median(runs))} max={max(runs)} px ({max(runs) * e['CDELT1']:.2f} A)")
    # sample plateau: the brightest saturated row of the Si IV window, profile around the core
    for n in range(1, h["NWIN"] + 1):
        if h[f"TDESC{n}"] == "Si IV 1403" and (f[n].data == 32760).any():
            d = f[n].data; cnt = (d == 32760).sum(axis=2); s, y = np.unravel_index(np.argmax(cnt), cnt.shape)
            row = d[s, y] * 0.25 + 7992; on = np.nonzero(row == 16182)[0]
            lo, hi = max(on.min() - 4, 0), min(on.max() + 5, row.size)
            print(f"  Si IV step {s} row {y}: {cnt[s, y]} samples at 16182 DN, cols {on.min()}-{on.max()}; profile cols {lo}-{hi - 1} (DN): {np.round(row[lo:hi]).astype(int).tolist()}")
