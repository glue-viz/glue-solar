"""Item 3: HISTORY 'Set N saturated pixels to Inf' N vs raw 32760 / 32764 counts. Usage: python -I hist_vs_count.py FILE..."""
import re, sys
import numpy as np
from astropy.io import fits
for p in sys.argv[1:]:
    with fits.open(p, do_not_scale_image_data=True) as f:
        h = f[0].header
        m = [re.search(r"Set (\d+) saturated", str(x)) for x in h.get("HISTORY", [])]
        N = next((int(x.group(1)) for x in m if x), None)
        per = []
        for n in range(1, h["NWIN"] + 1):
            d = f[n].data
            per.append((int((d == 32760).sum()), int((d > 32760).sum())))
        bs = {(f[n].header["BSCALE"], f[n].header["BZERO"]) for n in range(1, h["NWIN"] + 1)}
        print(f"{p.split('/')[-1]} HISTORY N={N} NSATPIX={h['NSATPIX']} BSCALE/BZERO={bs} raw==32760 total={sum(a for a, _ in per)} "
              f"raw>32760 total={sum(b for _, b in per)} per window (==32760)={[a for a, _ in per]}")
