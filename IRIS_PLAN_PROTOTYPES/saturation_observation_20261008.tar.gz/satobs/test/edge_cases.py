"""Print L1 and L2 neighbourhoods at the few mask disagreements. Usage: python -I edge_cases.py L2FILE L1FILE WIN STEP DY DX"""
import sys
import numpy as np
from astropy.io import fits
from scipy import ndimage

l2f, l1f, n, s, dy, dx = sys.argv[1], sys.argv[2], *map(int, sys.argv[3:])
f = fits.open(l2f, do_not_scale_image_data=True)
c0 = f[0].header[f"TSC{n}"] - 1
l2 = f[n].data[s].astype(np.int32)
d1 = fits.open(l1f, do_not_scale_image_data=True)[1].data.astype(np.int32)
ny, nx = l2.shape
big = np.pad(d1, ((50, 50), (50, 50)), constant_values=-32768)
l1a = big[50 + dy: 50 + dy + ny, 50 + c0 + dx: 50 + c0 + dx + nx]
m1, m2 = l1a >= 16000, l2 == 32760
for tol in (1, 2):
    k = np.ones((2 * tol + 1,) * 2, bool)
    a = m2 & ~ndimage.binary_dilation(m1, k); b = m1 & ~ndimage.binary_dilation(m2, k)
    print(f"tol {tol}px: L2top w/o L1>=16000: {a.sum()}  L1>=16000 w/o L2top: {b.sum()}")
k = np.ones((3, 3), bool)
a = m2 & ~ndimage.binary_dilation(m1, k); b = m1 & ~ndimage.binary_dilation(m2, k)
for name, m in (("L2top w/o L1flag", a), ("L1flag w/o L2top", b)):
    for y, x in list(zip(*np.nonzero(m)))[:3]:
        print(f"{name} at y={y} x={x}\n L1 raw 5x5:\n{l1a[y-2:y+3, x-2:x+3]}\n L2 DN 5x5:\n{l2[y-2:y+3, x-2:x+3] * 0.25 + 7992}")
