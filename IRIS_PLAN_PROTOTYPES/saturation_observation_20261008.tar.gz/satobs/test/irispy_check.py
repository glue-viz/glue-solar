"""Item 6: what irispy's reader gives at the raw 32760 samples, and calculate_moments with saturation_limit=16182 DN.

Usage: python irispy_check.py L2FILE   (run once with irispy main, once with PYTHONPATH=<draft #226 checkout>)
"""
import sys, warnings
import numpy as np
import astropy.units as u
from astropy.io import fits
import irispy
from irispy.io.spectrograph import read_spectrograph_lvl2
from irispy.utils.moments import calculate_moments

warnings.simplefilter("ignore")
path = sys.argv[1]
print("irispy", irispy.__version__, irispy.__file__)
WINS = {"Si IV 1403": 1402.77 * u.AA, "C II 1336": 1335.71 * u.AA, "Mg II k 2796": 2796.35 * u.AA}
rc = read_spectrograph_lvl2(path, spectral_windows=list(WINS))
raw = fits.open(path, do_not_scale_image_data=True)
desc = {raw[0].header[f"TDESC{n}"]: n for n in range(1, raw[0].header["NWIN"] + 1)}
for name, rest in WINS.items():
    cube = rc[name][0]
    r = raw[desc[name]].data
    top = r == 32760
    data = np.asarray(cube.data); mask = np.asarray(cube.mask) if cube.mask is not None else np.zeros_like(data, bool)
    print(f"\n-- {name}: unit={cube.unit} shape={data.shape} raw shape={r.shape} dtype={data.dtype}")
    print(f"   max |reader - (raw*0.25+7992)| = {np.nanmax(abs(data - (r * 0.25 + 7992))):.3g}")
    print(f"   at raw 32760 ({top.sum()} samples): values {np.unique(data[top]).tolist()}, mask True: {int(mask[top].sum())}")
    print(f"   reader max = {np.nanmax(data)}; samples == 16182: {(data == 16182).sum()}; > 16182: {(data > 16182).sum()}; mask True total: {int(mask.sum())} "
          f"(raw -32768: {(r == -32768).sum()}, raw -32764: {(r == -32764).sum()})")
    expected = top.any(axis=-1)  # (step, y) with any 16182 sample in the window
    for lim in (16182 * u.DN, 16182.0):
        try:
            mom = calculate_moments(cube, rest_wavelength=rest, saturation_limit=lim)
        except Exception as e:
            print(f"   calculate_moments(saturation_limit={lim!r}) raised {type(e).__name__}: {e}")
            continue
        base = calculate_moments(cube, rest_wavelength=rest)
        I, I0 = np.asarray(mom["intensity"].data), np.asarray(base["intensity"].data)
        newnan = np.isnan(I) & ~np.isnan(I0)
        sat = np.asarray(mom["saturated"].data).astype(bool) if "saturated" in mom else None
        print(f"   saturation_limit={lim!r}: new NaN intensity pixels={newnan.sum()} | (step,y) with a 16182 sample={expected.sum()} | "
              f"NaN == expected: {np.array_equal(newnan, expected & ~np.isnan(I0))} | 'saturated' map: "
              f"{'absent' if sat is None else f'{sat.sum()} True, equal to expected: {np.array_equal(sat, expected)}'}")
    # DN/s: per-step exposure times differ in the NUV window of r00173 (8.0 s and 2.44 s)
    try:
        cps = cube.apply_exposure_time_correction()
        et = np.atleast_1d(cps.meta.get("exposure time")).ravel()
        mom = calculate_moments(cps, rest_wavelength=rest, saturation_limit=16182 * u.DN)
        sat = np.asarray(mom["saturated"].data).astype(bool) if "saturated" in mom else None
        print(f"   DN/s cube (unit {cps.unit}, exposure times {np.unique(np.round(u.Quantity(et).to_value(u.s), 2)).tolist()} s): 'saturated' map "
              f"{'absent' if sat is None else f'{sat.sum()} True, equal to the DN result: {np.array_equal(sat, expected)}'}")
        flat = calculate_moments(cps, rest_wavelength=rest, saturation_limit=(16182 / 8.0) * u.DN / u.s)
        satf = np.asarray(flat["saturated"].data).astype(bool) if "saturated" in flat else np.isnan(np.asarray(flat["intensity"].data))
        print(f"   for contrast, one DN/s limit 16182/8 s for every step flags {satf.sum()} (step,y) pixels; per step: "
              f"{satf.reshape(satf.shape[0], -1).sum(axis=1).tolist()} vs expected {expected.reshape(expected.shape[0], -1).sum(axis=1).tolist()}")
    except Exception as e:
        print(f"   DN/s check raised {type(e).__name__}: {e}")
