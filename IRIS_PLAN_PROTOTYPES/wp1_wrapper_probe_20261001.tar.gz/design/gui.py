"""
Quicklook on 3610108077 (or 4000255147 with SJI 1400) through the tree on PYTHONPATH: what the slider, readout and
Profile show against irispy, the drawn tick labels and their overlaps per panel, and the draw time per panel.
Usage: gui.py OBSID WINDOW OUTPNG_PREFIX
"""
import sys
import time
import warnings
from glob import glob

import numpy as np

warnings.simplefilter("ignore")
obs, window, prefix = sys.argv[1:4]


def main():
    import astropy.units as u
    from astropy.visualization.wcsaxes.ticklabels import TickLabels
    from glue_qt.app import GlueApplication
    from glue_qt.utils import process_events
    from glue_qt.viewers.profile import ProfileViewer
    from irispy.io import read_files
    from matplotlib.text import Text

    import glue_solar
    from glue_solar.quicklook import quicklook
    from glue_solar.sources.loaders.iris import image_data, raster_data

    print("glue_solar", glue_solar.__file__)
    files = sorted(glob(f"/Users/nabil/DATA/IRIS/*{obs}_raster/*.fits"))
    [raster] = raster_data(files, [window])
    datasets = [raster]
    sji = glob(f"/Users/nabil/DATA/IRIS/*{obs}_SJI_1400_t000.fits.gz")
    if sji:
        datasets.append(image_data(sji[0]))
    ProfileViewer.warn = lambda *a, **k: True
    glue_solar.setup()
    app = GlueApplication()
    app.resize(1800, 1100)
    app.show()
    t = time.perf_counter()
    viewers = quicklook(app, datasets, window)
    process_events()
    print(f"quicklook() {time.perf_counter() - t:.2f} s; roles {sorted(viewers)}")

    cube = read_files(files[0], spectral_windows=[window], memmap=True, uncertainty=False)[window][0]
    ref = cube.axis_world_coords("em.wl")[0].to_value(u.AA)

    # slider: its world values and its text, against irispy
    [slider] = [s for s in viewers["map"].options_widget().slice_helper._sliders if s is not None]
    world = np.asarray(slider._world) * u.Unit(slider.text_slider_unit.text()).to(u.AA)
    text_err = []
    for k in range(len(ref)):
        slider.state.slice_center = k
        text_err.append(abs(float(slider.text_slider_label.text()) * u.Unit(slider.text_slider_unit.text()).to(u.AA) - ref[k]))
    print(f"slider: unit {slider.text_slider_unit.text()!r} text {slider.text_slider_label.text()!r}; "
          f"world values vs irispy max {np.abs(world - ref).max():.3g} A; text vs irispy max {max(text_err):.3g} A")
    slider.state.slice_center = len(ref) // 2
    process_events()

    # readout on the wavelength panel at a few wavelength pixels
    wl = viewers["wavelength"]
    wl.figure.canvas.draw()
    tool = wl.toolbar.tools["solar:cursor_readout"]
    s = wl.state
    for k in (64, 65, len(ref) // 2):
        x, y = (k, (s.y_min + s.y_max) / 2) if s.x_att.axis == 2 else ((s.x_min + s.x_max) / 2, k)
        print(f"readout λ[{k}] irispy {ref[k]:.6f} A: {tool.describe(x, y)!r}")

    # Profile
    from glue_solar.tests.helpers import select_point
    select_point(viewers["map"], raster.shape[0] // 2, raster.shape[1] // 2)
    process_events()
    spectrum = viewers["spectrum"]
    spectrum.figure.canvas.draw()
    layer = next(ls for ls in spectrum.state.layers if ls.visible and ls.profile is not None)
    print(f"Profile: x_display_unit {spectrum.state.x_display_unit!r} x_att {spectrum.state.x_att.label!r} "
          f"xlim {spectrum.state.x_min:.4f}..{spectrum.state.x_max:.4f} ticks "
          f"{[t.get_text() for t in spectrum.axes.get_xticklabels()]}")
    try:
        x, _ = layer.profile
        conv = u.Unit(spectrum.state.x_display_unit).to(u.AA) if spectrum.state.x_display_unit else 1
        print(f"Profile x vs irispy max {np.abs(np.asarray(x) * conv - ref).max():.3g} A")
    except Exception as exc:  # noqa: BLE001
        print("Profile x:", type(exc).__name__, exc)

    # drawn tick labels and overlaps
    record = []
    original = Text.draw

    def spy(self, renderer):
        original(self, renderer)
        if isinstance(self, TickLabels) and self.get_visible() and self.get_text():
            record.append((self.get_text(), self.get_window_extent(renderer)))

    for role in sorted(viewers):
        viewer = viewers[role]
        viewer = (viewer or [None])[0] if isinstance(viewer, list) else viewer
        if viewer is None:
            continue
        if not hasattr(viewer.axes, "coords"):
            continue
        canvas = viewer.figure.canvas
        record.clear()
        Text.draw = spy
        canvas.draw()
        Text.draw = original
        width, height = canvas.get_width_height()
        pairs = sum(
            1 for i in range(len(record)) for j in range(i + 1, len(record))
            if min(record[i][1].x1, record[j][1].x1) - max(record[i][1].x0, record[j][1].x0) > 0.5
            and min(record[i][1].y1, record[j][1].y1) - max(record[i][1].y0, record[j][1].y0) > 0.5
        )
        clipped = sum(1 for _, bb in record if bb.x0 < 0 or bb.x1 > width or bb.y0 < 0 or bb.y1 > height)
        times = []
        for _ in range(15):
            t = time.perf_counter()
            canvas.draw()
            times.append(time.perf_counter() - t)
        hidden = [c.default_label if hasattr(c, "default_label") else c.coord_index
                  for c in viewer.axes.coords if c.coord_type in ("longitude", "latitude") and not c.get_ticklabel_position()]
        print(f"{role:12s} labels {len(record):2d} overlapping pairs {pairs:2d} clipped {clipped} "
              f"draw {1e3 * np.median(times):.1f} ms; hidden {hidden}; sample {[t for t, _ in record[:8]]}")
        viewer.figure.savefig(f"{prefix}-{role}.png")


main()
