"""Cost of _hide_flat_angles per glue axes reset, on the 3610108077 quicklook panels (prototype tree)."""
import sys
import time
import warnings
from glob import glob

import numpy as np

warnings.simplefilter("ignore")


def main():
    from glue_qt.app import GlueApplication
    from glue_qt.utils import process_events
    from glue_qt.viewers.profile import ProfileViewer

    import glue_solar
    from glue_solar import tools
    from glue_solar.quicklook import quicklook
    from glue_solar.sources.loaders.iris import raster_data

    obs, window = sys.argv[1:3]
    files = sorted(glob(f"/Users/nabil/DATA/IRIS/*{obs}_raster/*.fits"))
    [raster] = raster_data(files, [window])
    ProfileViewer.warn = lambda *a, **k: True
    glue_solar.setup()
    app = GlueApplication()
    app.resize(1800, 1100)
    app.show()
    viewers = quicklook(app, [raster], window)
    process_events()
    original = tools._hide_flat_angles
    spent = []

    def timed(*args):
        t = time.perf_counter()
        original(*args)
        spent.append(time.perf_counter() - t)

    for role in ("wavelength", "spectrogram", "map"):
        viewer = viewers[role]
        out = {}
        for name, hide in (("off", lambda *a: None), ("on", timed)):
            tools._hide_flat_angles = hide
            resets, draws = [], []
            for i in range(20):
                t = time.perf_counter()
                viewer._set_wcs(relim=False)
                resets.append(time.perf_counter() - t)
                t = time.perf_counter()
                viewer.figure.canvas.draw()
                draws.append(time.perf_counter() - t)
            out[name] = (1e3 * np.median(resets), 1e3 * np.median(draws))
        print(f"{role:12s} reset off/on {out['off'][0]:.2f}/{out['on'][0]:.2f} ms, draw off/on "
              f"{out['off'][1]:.1f}/{out['on'][1]:.1f} ms, _hide_flat_angles median {1e3 * np.median(spent):.3f} ms "
              f"max {1e3 * np.max(spent):.3f} ms")
        spent.clear()


main()
