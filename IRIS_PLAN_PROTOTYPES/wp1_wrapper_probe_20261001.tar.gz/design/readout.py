"""Option for decision A: the readout's wavelength at 0.001 A, the other coordinates and the ticks as WCSAxes has them."""
import warnings
from glob import glob

warnings.simplefilter("ignore")
from glue_qt.app import GlueApplication  # noqa: E402
from glue_qt.utils import process_events  # noqa: E402
from glue_qt.viewers.profile import ProfileViewer  # noqa: E402
from irispy.io import read_files  # noqa: E402

import astropy.units as u  # noqa: E402

import glue_solar  # noqa: E402
from glue_solar.quicklook import quicklook  # noqa: E402
from glue_solar.sources.loaders.iris import raster_data  # noqa: E402

files = sorted(glob("/Users/nabil/DATA/IRIS/*3610108077_raster/*.fits"))
window = "Mg II k 2796"
[raster] = raster_data(files, [window])
ref = read_files(files[0], spectral_windows=[window], memmap=True, uncertainty=False)[window][0].axis_world_coords("em.wl")[0].to_value(u.AA)
ProfileViewer.warn = lambda *a, **k: True
glue_solar.setup()
app = GlueApplication()
app.resize(1800, 1100)
app.show()
viewers = quicklook(app, [raster], window)
process_events()
panel = viewers["wavelength"]
for coord in panel.axes.coords:
    if coord.coord_type == "scalar" and coord.get_format_unit() == u.AA:
        coord.format_coord = lambda value, format="auto": f"{value:.3f}"
panel.figure.canvas.draw()
tool = panel.toolbar.tools["solar:cursor_readout"]
for k in (64, 65):
    print(f"λ[{k}] irispy {ref[k]:.6f}: {tool.describe(k, 100)!r}; ticks",
          list(panel.axes.coords[0]._ticklabels.text.get("b", []))[:4] if hasattr(panel.axes.coords[0]._ticklabels, "text") else "")
