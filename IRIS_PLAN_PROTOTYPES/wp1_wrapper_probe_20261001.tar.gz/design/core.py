"""
Prototype check of the _GlueWCS change (run with PYTHONPATH=<tree>): units, wavelength against irispy,
pixel->world->pixel through the wrapper and the wrapped WCS, high-level objects, WCSLink, and timings.
"""
import sys
import time
import warnings
from glob import glob

import numpy as np

warnings.simplefilter("ignore")
import astropy.units as u  # noqa: E402
from astropy.wcs.wcsapi import HighLevelWCSWrapper  # noqa: E402
from glue.plugins.wcs_autolinking.wcs_autolinking import WCSLink  # noqa: E402
from irispy.io import read_files  # noqa: E402

import glue_solar.sources.loaders.iris as iris  # noqa: E402
from glue_solar.sources.loaders.iris import image_data, raster_data  # noqa: E402

print("module", iris.__file__)
D = "/Users/nabil/DATA/IRIS/"
NEW = hasattr(iris, "_shown_unit")
rng = np.random.default_rng(0)


def files(obs):
    return sorted(glob(f"{D}*{obs}_raster/*.fits"))


def roundtrip(wcs, shape, n=2000):
    """max |dp| per pixel axis (WCS order) and NaN count, uniform over [-0.5, n-0.5]."""
    pix = [rng.uniform(-0.5, s - 0.5, n) for s in shape[::-1]]
    back = wcs.world_to_pixel_values(*wcs.pixel_to_world_values(*pix))
    back = back if isinstance(back, tuple) else (back,)
    d = [np.abs(np.asarray(b) - p) for b, p in zip(back, pix)]
    return [float(np.nanmax(x)) for x in d], int(sum(np.isnan(x).sum() for x in d)), pix


def inner(wcs, shape, n=2000):
    """as roundtrip, but over [0, n-1]: no outer half pixel."""
    pix = [rng.uniform(0, s - 1, n) for s in shape[::-1]]
    back = wcs.world_to_pixel_values(*wcs.pixel_to_world_values(*pix))
    return [float(np.nanmax(np.abs(np.asarray(b) - p))) for b, p in zip(back, pix)]


def report(label, data, cube=None):
    w, raw = data.coords, data.coords._wcs
    print(f"\n== {label} {data.shape}")
    print("  units", w.world_axis_units, "raw", raw.world_axis_units)
    if cube is not None:
        ref = cube.axis_world_coords("em.wl")[0].to_value(u.AA)
        k = w.world_axis_physical_types.index("em.wl")
        idx = [0] * w.pixel_n_dim
        mine = []
        for j in range(len(ref)):
            idx[0] = j
            mine.append(w.pixel_to_world_values(*idx)[k])
        mine = np.asarray(mine) * (u.Unit(w.world_axis_units[k]).to(u.AA))
        print(f"  wavelength vs irispy max|d| {np.abs(mine - ref).max():.3g} A")
    for name, wcs in (("wrapper", w), ("wrapped", raw)):
        m, nans, _ = roundtrip(wcs, data.shape)
        print(f"  p->w->p {name:8s} outer-incl max {['%.2g' % x for x in m]} nan {nans}; inner",
              ['%.2g' % x for x in inner(wcs, data.shape)])
    # what the wrapper adds: same pixels through both
    pix = [rng.uniform(0, s - 1, 2000) for s in data.shape[::-1]]
    a = w.world_to_pixel_values(*w.pixel_to_world_values(*pix))
    b = raw.world_to_pixel_values(*raw.pixel_to_world_values(*pix))
    a, b = (a if isinstance(a, tuple) else (a,)), (b if isinstance(b, tuple) else (b,))
    print("  wrapper minus wrapped round trip max", ['%.2g' % float(np.nanmax(np.abs(np.asarray(x) - y))) for x, y in zip(a, b)])
    # high level
    centre = [np.array([s // 2 + 0.25]) for s in data.shape[::-1]]
    try:
        hw, hr = HighLevelWCSWrapper(w), HighLevelWCSWrapper(raw)
        ow, orr = hw.pixel_to_world(*centre), hr.pixel_to_world(*centre)
        ow = ow if isinstance(ow, list) else [ow]
        orr = orr if isinstance(orr, list) else [orr]
        same = []
        for x, y in zip(ow, orr):
            if hasattr(x, "jd"):
                same.append(float(abs((x - y).to_value(u.s)).max()))
            elif hasattr(x, "Tx"):
                same.append(float(max(abs((x.Tx - y.Tx).to_value(u.arcsec)).max(), abs((x.Ty - y.Ty).to_value(u.arcsec)).max())))
            elif hasattr(x, "to_value") and x.unit.physical_type == "length":
                same.append(float(abs((x - y).to_value(u.AA)).max()))
            elif hasattr(x, "jd"):
                same.append(float(abs((x - y).to_value(u.s)).max()))
            else:
                same.append(float(np.abs(np.asarray(x) - np.asarray(y)).max()))
        back = hw.world_to_pixel(*ow)
        back = back if isinstance(back, tuple) else (back,)
        print("  high-level objects vs wrapped max|d| (arcsec / A / s / plain)", ['%.2g' % s for s in same],
              "; high-level p->w->p |d|", ['%.2g' % float(np.abs(np.asarray(b) - c).max()) for b, c in zip(back, centre)])
    except Exception as exc:  # noqa: BLE001
        print("  high-level:", type(exc).__name__, str(exc)[:140])


def timing(data, label):
    w = data.coords
    shape = data.shape[::-1]
    reps = 30
    t_p2w, t_w2p = [], []
    for r in range(reps):
        pix = [rng.uniform(0, s - 1, 2000) for s in shape]  # new inputs each time: no memo hit
        t = time.perf_counter()
        world = w.pixel_to_world_values(*pix)
        t_p2w.append(time.perf_counter() - t)
        t = time.perf_counter()
        w.world_to_pixel_values(*world)
        t_w2p.append(time.perf_counter() - t)
    # the unit arithmetic alone
    vals = list(w._wcs.pixel_to_world_values(*pix))
    conv = getattr(w, "_converted", None) or getattr(w, "_helioprojective")
    t_arith = []
    for r in range(reps):
        t = time.perf_counter()
        v = list(vals)
        for i, to_shown, _, full_circle in conv:
            v[i] = np.asarray(v[i])
            if full_circle is not None:
                v[i] = (v[i] + full_circle / 2) % full_circle - full_circle / 2
            v[i] = v[i] * to_shown
        t_arith.append(time.perf_counter() - t)
    med = lambda x: 1e3 * float(np.median(x))  # noqa: E731
    print(f"  timing {label}: p2w 2000 pts {med(t_p2w):.3f} ms, w2p {med(t_w2p):.3f} ms, unit arithmetic {med(t_arith)*1e3:.1f} us")


which = sys.argv[1:] or ["3610108077", "4000255147", "stack", "sji", "aia", "link"]
if "3610108077" in which:
    fs = files("3610108077")
    windows = read_files(fs, memmap=True, uncertainty=False)
    for data in raster_data(fs):
        name = next(w for w in windows if str(w).replace(" ", "_") == data.label.split("-")[0])
        report(data.label[:24], data, windows[name][0])
        if "Si_IV_1394" in data.label:
            timing(data, "3610108077 Si IV 1394")
if "4000255147" in which:
    fs = files("4000255147")
    data = raster_data(fs, ["Si IV 1403"])[0]
    report("4000255147 Si IV 1403 (sit-and-stare)", data, read_files(fs, spectral_windows=["Si IV 1403"], memmap=True, uncertainty=False)["Si IV 1403"][0])
if "stack" in which:
    for obs, window in (("3400109360", "Mg II k 2796"), ("4000005156", "Si IV 1403")):
        data = raster_data(files(obs), [window], stack=True)[0]
        report(f"{obs} {window} stack", data)
        if obs == "4000005156":
            timing(data, "4000005156 stack")
if "sji" in which:
    data = image_data(glob(D + "*4000255147_SJI_1400_t000.fits.gz")[0])
    report("4000255147 SJI 1400", data)
    timing(data, "SJI 1400")
if "aia" in which:
    from glue_solar.sources.loaders.iris import read_files as _  # noqa: F401
    path = [p for p in sorted(glob(D + "*3640107442_SDO/*.fits")) if "1600" in p][0]
    report("3640107442 AIA 1600", image_data(path))
if "link" in which:
    a, b = raster_data(files("3610108077"), ["Si IV 1394", "Si IV 1403"])
    for name, (ca, cb) in (("wrapper", (a.coords, b.coords)), ("unwrapped", (a.coords._wcs, b.coords._wcs))):
        from glue.core import Data
        da = Data(x=np.zeros(a.shape), coords=ca, label="a")
        db = Data(x=np.zeros(b.shape), coords=cb, label="b")
        try:
            link = WCSLink(da, db)
            sel = [np.array([float(a.shape[c.axis] // 2)]) for c in link.cids1]
            print(f"WCSLink 1394->1403 via {name}: forwards(centre)",
                  [np.round(np.asarray(v), 6).tolist() for v in link.forwards(*sel)])
        except Exception as exc:  # noqa: BLE001
            print(f"WCSLink via {name}: {type(exc).__name__}: {str(exc)[:120]}")
    s = raster_data(files("4000255147"), ["Si IV 1403"])[0]
    sji = image_data(glob(D + "*4000255147_SJI_1400_t000.fits.gz")[0])
    c = [np.array([s.shape[i] // 2 + 0.0]) for i in (2, 1, 0)]
    for name, wcs in (("wrapper", s.coords), ("unwrapped", s.coords._wcs)):
        try:
            sky = HighLevelWCSWrapper(wcs).pixel_to_world(*c)[1]
            print(f"4000255147 high-level centre via {name}: Tx {sky.Tx.to_value(u.arcsec)} Ty {sky.Ty.to_value(u.arcsec)}")
        except Exception as exc:  # noqa: BLE001
            print(f"4000255147 high-level via {name}: {type(exc).__name__}: {str(exc)[:120]}")
