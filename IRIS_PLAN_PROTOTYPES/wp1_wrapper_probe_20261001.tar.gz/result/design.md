# wp1-m1-wrapper-coherence: implementation design

## Summary

I built the design as a prototype in a scratch copy of main (fbb36b3) and ran the full suite against it with remote data: 170 passed, 3 skipped. The 9 changed or new tests fail on main and pass on the prototype. The touched tests also pass in `iris-plan-floor` (24 passed).

The change has three parts:
- `_GlueWCS` reports Å for `em.wl`, next to its existing arcsec. It converts the values, the units and the high-level object metadata with the same per-axis scales.
- glue then shows Å on the slider, readout, Profile and ticks without any glue-side code.
- A `FrameTimeTool` reset hook hides the tick labels of a helioprojective coordinate that barely changes across a panel.

On 3610108077 and 4000255147 this:
- puts every value in Å, equal to irispy (0 Å difference);
- makes glue's WCS link work between rasters;
- removes every overlapping or clipped tick label;
- makes the λ–step panel draw 43 % faster (26.9 → 15.4 ms).

Two done criteria can't be met as written: the 1e-6 Å readout and the 1e-9 px round trip. They need your decision (A and B below).

## 1. What `_GlueWCS` changes (`glue_solar/sources/loaders/iris.py`)

A module function `_shown_unit(physical_type)` gives `u.AA` for `em.wl`, `u.arcsec` for `custom:pos.helioprojective.*`, and None otherwise. Time, Scan and SJI arcsec keep their own unit.

| APE-14 member | Prototype |
|---|---|
| `world_axis_units` | Converts: `_shown_unit(t).to_string()`, so 'Angstrom' and 'arcsec'; other axes pass through |
| `_helioprojective` → `_converted` (cached) | Per converted axis: `(index, unit.to(shown), shown.to(unit), full_circle)`. These are the scales a Quantity conversion multiplies by, so the existing bit-for-bit test keeps holding |
| `pixel_to_world_values` | Same code over `_converted`: the longitude wrap, then × the scale. The memo stores the shown values, and its key is unchanged |
| `world_to_pixel_values` | × the scale back, under `WCS_LOCK` as now |
| `world_axis_object_components` (new, cached) | The wrapped WCS's components. Each converted axis's value getter becomes `np.asarray(get(obj)) * to_shown` (`operator.attrgetter` for string attributes). A Helioprojective SkyCoord already wraps longitude at 180°, which matches the values |
| `world_axis_object_classes` (new, cached) | The wrapped WCS's classes, as 4-tuples whose factory multiplies plain number or array arguments (positional or keyword) by `from_shown` and then calls the original factory or class. Quantity, SkyCoord and other objects, which `world_to_pixel` passes in (astropy `high_level_api.py:254, 286`), go through unchanged. Both properties read the wrapped WCS under `WCS_LOCK`, because a FITS WCS reads wcslib for them |
| Unchanged | `world_axis_physical_types`, `pixel_shape`, `pixel_bounds`, `serialized_classes` (False on every IRIS kind), `world_axis_names`, `axis_correlation_matrix` (already locked), `has_celestial = False` |

Size: about +60 lines in `iris.py`. Prototype at `iris.py:84-219` of the scratch tree.

Why the high-level members must change too: astropy's FITS WCS builds `SkyCoord(unit=(deg, deg))` (`fitswcs.py:445-460`) and a spectral factory in metres (`fitswcs.py:699-712`). On main that already breaks glue's WCS link for arcsec values (latitude > 90° raises; sit-and-stare positions come out 3600× too far). An Å change alone would also put spectral objects off by 1e10.

## 2. How Å reaches the slider, readout and Profile (D18: no glue-side code)

Every path reads `world_axis_units` and `pixel_to_world_values`:

| Display | Where glue reads it | Result on 3610108077 Mg II k |
|---|---|---|
| Slider | unit from `glue_qt/viewers/common/slice_widget.py:108`; text format from `format_minimal`, `data_slice_widget.py:73` | 'Angstrom' / '2809.95' |
| World components | `glue/core/component.py:248` | 'Angstrom' |
| Profile | default `x_display_unit = component.units` (`glue/viewers/profile/state.py:283`) | 'Angstrom'; ticks 2790.0…2810.0 |
| Ticks and readout | WCSAxes uses the axis unit for a scalar coordinate (`wcsapi.py:153-156`); readout via `coordinate_helpers.py:474-494` | ticks 2795 / 2800 / 2805; readout '2794 288.1" −331"' |

glue-solar's own consumers already convert through `world_axis_units` (`quicklook._wavelengths`, `quicklook.py:662-668`) or assume arcsec only (`_lon_lat`, `_sji_pixels`), so they need no change.

glue-qt's Profile Navigate compares display-unit x with native values (`profile_tools.py:163-176`). It is now right by default (Å with Å) and wrong only for another display unit such as nm.

## 3. Links, sessions, lazy data, memo

- **`link_hpc`:** the arcsec values are bit-identical. Wavelength is never linked.
- **glue's WCS link:** works on the prototype.
  - Between 3610108077 Si IV 1394 and 1403, the centre maps to [-175, 274.000001, 159.999999], identical to the unwrapped link. Main raises IncompatibleWCS.
  - The 4000255147 high-level centre reads (105.679″, 63.913″), as the wrapped WCS does.
  - Raster↔SJI still raises IncompatibleWCS on glue 1.27.0 (time axis), as before (#2595 / M4).
- **glue's autolinker:** `wcs_autolink` still skips `_GlueWCS`, which is low-level only (`wcs_autolinking.py:320-322`). That is unchanged, and D1 is kept.
- **`LinkSameWithUnits`** (`wp1-m1-sunpy-maps`): arcsec against deg still converts.
- **Sessions:** `_GlueWCS` has no saver yet (`glue/core/state.py:905`; `wp3-wcs-saver`, Later). So no saved session carries 'm', and nothing breaks.
  - Note for wp3: save the wrapped WCS or a file reference; `__init__` derives the units again.
  - A saved Profile `x_display_unit='Angstrom'` will restore through glue.
- **Lazy data:** coordinates are separate from LazyData and RawComponent, so nothing changes.
- **Memo:** it now caches values in Å. The extra multiply costs about 1 µs per 2000 points (unit arithmetic 9.3 µs against 8.5 µs on main). p→w for 2000 points takes 0.083 ms against 0.089, and w→p 53.3 against 56.1 ms (noise).
- **Breaking for scripts:** `pixel_to_world_values` now returns Å. This needs a `changelog/*.breaking.rst` entry, plus `docs/user_guide/scripting-iris-data.rst:33` ("in metres" → "in Angstrom").

## 4. Tick-overlap fix and its cost (`glue_solar/tools.py`)

`_hide_flat_angles(axes, (nx, ny))`, about 20 lines:
- It finds the two `longitude`/`latitude` coordinate helpers.
- It samples the displayed array's 4 edges (64 points each, pixel 0..n−1, because -TAB has no coordinates past the outer centres) through the public `coord.transform`.
- It calls `set_ticklabel_position("")` on a coordinate whose span is below `_FLAT = 0.05` of the other's.

It is called from `FrameTimeTool._label_exposures`, guarded by `axes.coords is not self._flat_checked`. glue's `_set_wcs` replaces `axes.coords` and resets both axis labels on every reset (`glue/viewers/image/viewer.py:117-121`), which fires that callback. This is the same hook the sit-and-stare exposure ticks rely on, so the fix reaches every Image viewer.

It is decided on the whole array rather than the view, so zooming never flips it. It is a display default, not a workaround, so it gets no row in the workaround register.

Measured on the 1800×1100 app at offscreen DPR 1, median of 15 full Agg draws, main → prototype:

| Panel | Labels | Overlapping pairs | Clipped | Draw (ms) |
|---|---|---|---|---|
| 3610108077 λ–step (Mg II k) | 33 → 9 | 25 → 0 | 6 → 0 | 26.9 → 15.4 |
| 3610108077 spectrogram | 11 → 7 | 0 → 0 | 4 → 0 | 17.0 → 13.3 |
| 3610108077 map | 10 → 10 | 0 → 0 | 0 → 0 | 15.1 → 14.9 |
| 4000255147 Si IV spectrogram | 14 → 10 | 6 → 0 | 5 → 0 | 18.7 → 14.2 |
| 4000255147 Si IV λ–t | 11 → 11 | 6 → 0 (fixed by Å) | 1 → 0 | 20.3 → 18.8 |
| 4000255147 Mg II k spectrogram | 14 → 10 | 6 → 0 | 4 → 0 | 18.7 → 14.1 |
| 4000255147 Mg II k λ–t | 11 → 11 | 6 → 0 (fixed by Å) | 0 → 0 | 20.6 → 18.4 |
| 4000255147 map and SJI | unchanged | | | |

- **Cost of the condition:** 0.057 ms median (max 0.093 ms) per glue reset. A reset goes from 1.46 to 1.51 ms on 3610108077 and from 2.16 to 2.19 ms on 4000255147.
- **`exclude_overlapping` as a safety net:** skipped. It still leaves repeated '288.1"' labels and keeps longitude clipped.
- **Labels after the fix:** on the λ–step panel, longitude moves to the left spine under glue's 'Helioprojective Longitude' label. The wavelength axis label stays plain 'Wavelength'.

## 5. Tests (glue side only; bundled irispy files plus irispy-data assets)

3610108077 is not in `IRISPY_DATA_HASHES` (`conftest.py:250-259`), so it is a manual probe only. All tests below fail on main and pass on the prototype.

**Updated:**
- `test_importer.py:251`: the stack's units become ("Angstrom", "arcsec", "arcsec", "").
- The stack's world comparison converts em.wl too.
- `test_arcsec_coordinates_read_the_axes_once` gets a `_shown()` helper: bit-for-bit Quantity conversion for Å and arcsec in both directions, and still 2 axis reads.
- `test_documented_workflows.py:53-54`: Å.
- `test_plugin.py` `test_axis_labels_on_their_coordinates_draw_as_glues[λ–step]`: with latitude hidden, the canvas now equals glue's. The assertion for that case changes from "differs" to "same canvas"; the rolled-60° case still differs.

**New:**
- `test_importer.py::test_high_level_objects_agree_with_the_values`: on the sns raster, SJI 1400 and the 3860258481 stack, `HighLevelWCSWrapper(coords)` objects equal the wrapped WCS's (1e-9″), and `world_to_pixel` matches the wrapped WCS to 1e-9 px.
- `test_linking.py::test_wcs_link_between_two_raster_windows`: WCSLink between the sns C II and Si IV windows equals the unwrapped link to 1e-9.
- `test_quicklook.py::test_raster_panels_show_wavelengths_in_angstrom`, on the `scans` fixture, checks against the dataset's own wrapped WCS:
  - the world component in Å within 1e-6;
  - the slider (via `findChildren(SliceWidget)`) reads 'Angstrom' and its label is within its own rounding;
  - Profile `x_display_unit` is 'Angstrom' and x is within 1e-6 Å;
  - the readout's first token is within its printed precision.
- `test_quicklook.py::test_flat_helioprojective_coordinates_have_no_tick_labels`:
  - the λ–step panel hides latitude and keeps longitude on 'l';
  - the spectrogram hides longitude;
  - the map hides nothing;
  - latitude stays hidden after a slit step (a reset).
- `test_quicklook.py::test_quicklook_of_a_full_raster` (remote, 4000005156 Si IV, which had 6/6 longitude labels clipped on main): no tick label overlaps another or leaves the canvas on the map, spectrogram or λ–step panel.

One lint fix is still needed: ruff import order in the new `_drawn_labels` helper.

## 6. Manual probe (3610108077 and the other local data)

Archive `core.py`, `gui.py`, `hidecost.py` and `readout.py` as `IRIS_PLAN_PROTOTYPES/wp1_wrapper_probe/`. Each runs with `PYTHONPATH=<checkout>`.

- **`core.py [3610108077|4000255147|stack|sji|aia|link]`:**
  - units, and wavelength against `axis_world_coords("em.wl")`;
  - p→w→p per axis through the wrapper and the wrapped WCS (2000 random points, with and without the outer half pixel);
  - high-level objects against the wrapped WCS, WCSLink 1394↔1403, and timings.
- **`gui.py OBSID WINDOW PREFIX`:** quicklook; slider, readout and Profile against irispy; drawn labels, overlaps, clipping and draw ms per panel; PNGs.
- **`hidecost.py`:** the per-reset cost of the hide.

Results to record (prototype):
- **All 7 windows of 3610108077:** units (Angstrom, arcsec, arcsec); every value equals irispy (0 Å); high-level objects equal the wrapped WCS's.
- **Round trip on 3610108077:** λ 1.5e-11 px (wrapped 5.2e-12), slit 1.3e-6, step 1.1e-6 px, the same as the wrapped WCS. The outer half pixel gives NaN at 8–46 of 2000 points, as the wrapped WCS does.
- **Stacks:** 3400109360 and 4000005156 at 1.2e-6 / 2.3e-6 px.
- **SJI 1400 and AIA 1600:** 7.2e-10 and 1.9e-10 px.
- **4000255147 exposure axis:** off by 6 px, the same as the wrapped WCS (ill-posed).

## 7. Risks

1. External scripts that expect metres from `pixel_to_world_values` will be wrong by 1e10 without an error. Mitigation: the breaking changelog entry and the docs line.
2. The class factory assumes `serialized_classes` is False and that component attributes are ints or names. That holds for astropy FITS WCS, gWCS, ndcube `CompoundLowLevelWCS` and `SlicedLowLevelWCS`, which cover every IRIS kind. A serialized wrapped WCS would break; no guard is added.
3. The hide relies on glue resetting the axis labels at each `_set_wcs`. The exposure labels already rely on this, and tests pin it.
4. Readout text precision is unchanged in substance: WCSAxes prints at the tick spacing, so about 1 Å on NUV. See decision A.
5. Changing #90's label test: on λ–step panels glue's own labels and #90's patch now draw identically.

## 8. Decisions for the user

**A. "Slider, readout and Profile x show Å within 1e-6 Å of irispy."** The values are within 0 Å. The texts round: slider to 0.005 Å (glue-qt `format_minimal`), readout to the tick spacing ('2794' for 2793.9137).
1. **(Recommended)** Read the criterion as the values behind each display in Å within 1e-6 Å, with glue/WCSAxes text precision kept. Readout precision moves to `wp11-cursor-readout`, which reworks the readout anyway (Time, exposure, km/s).
2. Also print the readout wavelength to 0.001 Å. This means setting the wavelength coordinate helper's `format_coord` to `f"{value:.3f}"` in the same reset hook, about 3 lines. Measured: '2793.914 288.1" −353"', with ticks still '2795 2800 2805'. It re-implements WCSAxes' readout formatting for one coordinate.

   Neither option can show 1e-6 Å in the slider text without patching glue-qt.

**B. "pixel→world→pixel holds to 1e-9 px."** The wrapper adds nothing beyond a Quantity conversion, and that is tested bit for bit. The remaining error is wcslib's -TAB inverse tolerance (1e-10° in `tab.c` → 1.3e-6 px), and the sit-and-stare exposure axis cannot be inverted (off by 6 px).
1. **(Recommended)** Restate the criterion as:
   - 1e-9 px on the gWCS kinds (SJI, AIA);
   - at most 2e-6 px on -TAB rasters and stacks, equal to the wrapped WCS;
   - the sit-and-stare exposure axis exempt (time axis, WP11);
   - the wcslib tolerance added to `wp0-report-candidates`.
2. Add 2 Newton steps in `world_to_pixel_values` for -TAB rasters. The iris-wcs mapping measured 2.8e-10 px and +0.6 ms per 2000 points, against 53 ms for wcslib's inverse. It costs about 20 lines and a workaround-register row, the gain is invisible, and it still fails on sit-and-stare.

**C. The hide's scope and threshold.**
1. **(Recommended)** Every Image viewer, through `FrameTimeTool`. The threshold is 0.05: the panels that need hiding measured 0.003–0.011, maps 0.66 or more, and sit-and-stare λ–t 0.099–0.20, which `FrameTimeTool` already handles. No `exclude_overlapping` safety net.
2. Quicklook panels only, through a `QuicklookImageViewer._set_wcs` override. Plain Image viewers of a raster would keep the overlap.

## 9. Plan edits to make once decided

- **The item's done-when:** reword it per decisions A and B.
- **`wp4-m1-spectral-coupling`:** change "(Å needs Qt #70)" to "(a Profile unit other than the data's, such as nm, needs Qt #70)".
- **WP11 note:** the metres part is fixed by this item; the helioprojective coordinates along the exposure axis ('1401 63.9" 106"') stay with `wp11-cursor-readout`.
- **Not done:** units in the axis labels (still plain 'Wavelength'); add them only if you ask.

Files are in `/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/wrapper/design/`:
- `wrapper_coherence.patch` — the full prototype diff against main fbb36b3. It lacks the later WCS_LOCK refinement, which is only in `tree/glue_solar/sources/loaders/iris.py`.
- `tree/` — the patched copy of main.
- `core.py`, `gui.py`, `hidecost.py`, `readout.py` — the probe scripts.
- `core_new.out`, `core_main.out`, `gui_{new,main}-*.out`, `hidecost.out`, `readout.out`, `suite_new_full.out` — the outputs.
- `png/` — panel images, main and prototype.