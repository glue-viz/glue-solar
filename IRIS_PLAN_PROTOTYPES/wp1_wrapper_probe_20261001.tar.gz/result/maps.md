=== MAP glue-paths ===
**glue-paths report for wp1-m1-wrapper-coherence: how glue reads world coordinates and units from IRIS `_GlueWCS` data (measured on 3610108077 Si IV 1394, (320, 548, 194), and 4000255147 Si IV 1403, sit-and-stare)**

## Summary

1. Every display path gets its units from `world_axis_units` and its values from `pixel_to_world_values`. `_GlueWCS` changes both for helioprojective axes only (iris.py:110-114, 131-158), so wavelength shows metres everywhere: slider, Profile x, world components, WCSAxes ticks and the readout.
2. WCSLink, and so the M4 autolink, does not work on `_GlueWCS` rasters today. `world_axis_object_components` and `world_axis_object_classes` pass straight through to the wrapped irispy WCS (astropy wrappers/base.py:39-45). That WCS still says SkyCoord in degrees, but the values are now arcsec. Between two 3610108077 windows, WCSLink raises IncompatibleWCS ("Latitude angle(s) must be within -90 deg <= angle <= 90 deg, got 196.85 deg"). On the unwrapped WCS the same link works. On 4000255147 the SkyCoord comes out 3600 times too large ((380444″, 230090″) instead of (105.68″, 63.91″)).
3. A scratch-only patch of `_GlueWCS` puts every glue path into Å. It changes `world_axis_units`, the two `*_values` methods, and the object components and classes, with one scale per axis. All paths followed it with no glue-side change, and WCSLink then gave the same result as the unwrapped WCS. The WCSAxes-only route (`set_format_unit`) is worse: ticks read '1392.0000000000', and glue's next axis reset drops the setting.
4. Two done criteria cannot be met by the wrapper alone; the orchestrator needs to decide on both:
   - **Round trip to 1e-9 px.** irispy 0.9.1's raster WCS uses a lookup table (HPLT-TAB / HPLN-TAB). Its own pixel→world→pixel error is up to 1.3e-6 px inside the cube, and it returns NaN in the outer half pixel of the step and slit axes (11 of 2000 random pixels). `_GlueWCS` adds at most about 5e-10 px. The plain WCS built from the file header round-trips to 3e-10 px.
   - **Readout within 1e-6 Å.** WCSAxes formats the readout at the tick spacing (coordinate_helpers.py:474-494). Even in Å it reads '1393' where irispy gives 1392.830628 Å. To meet the criterion, glue-solar's `CursorReadoutTool` (tools.py:315) would have to format the world values itself. The slider text also rounds ('1393.77', format '{:.2f}'), though the values behind it match irispy exactly.

## Path map
Rows A–D, G and N–Q were measured on real data; the others come from reading the code. Paths are under `site-packages`. "Today" means measured on 3610108077 Si IV 1394 unless stated.

| # | glue path (file:line) | `_GlueWCS` API used | Today | Follows a wrapper change? |
|---|---|---|---|---|
| A | Slice slider: glue_qt/viewers/common/slice_widget.py:103-120 → `coordinate_helpers.world_axis` 129-160 → `pixel2world_single_axis` 15-69; text from data_slice_widget.py:72-78, 110-119 | `pixel_n_dim`, `axis_correlation_matrix`, `pixel_to_world_values`, `world_axis_units[i]`; label from `world_component_ids[i].label` | unit 'm', text '1.39377e-07' (format '{:.5e}'); `_world`×1e10 vs irispy 4.6e-13 Å. Lat/lon sliders show the index with unit '' (correlated axes, `world_warning`) | Yes: 'Angstrom', '1393.77', values 0 Å from irispy |
| B | World components: data.py:1161-1196 (`CoordinateComponent`, `CoordinateComponentLink`); component.py:246-249 (`units`), 255-340 (`_calculate`); label from coordinate_helpers.py:186-189 | `world_n_dim`, `world_axis_units`, `world_axis_names`, `axis_correlation_matrix`, `pixel_to_world_values`; links also `world_to_pixel_values` | units ('arcsec', 'arcsec', 'm') | Yes: ('arcsec', 'arcsec', 'Angstrom'). `axis_label` checks `names[axis]` but returns `names[n-1-axis]`; harmless while every name is set. 'Time (UTC)' shows as 'Time (Utc)' |
| C | Image viewer WCSAxes: image/viewer.py:100-145 `reset_wcs(slices, wcs=coords)` → wcsaxes/wcsapi.py:126-292 (`coord_meta`, `apply_slices`); `WCSPixel2WorldTransform` 398-446, `WCSWorld2PixelTransform` 330-379; ranges coordinate_range.py:53 | `world_n_dim`, `world_axis_physical_types`, `world_axis_units`, `world_axis_names`, `axis_correlation_matrix`, `pixel_to_world_values` / `world_to_pixel_values` (through `SlicedLowLevelWCS`) | Helioprojective: type longitude/latitude, format unit arcsec. astropy's built-in helioprojective mapping (wcsapi.py:39-58) gives arcsec even when the WCS says degrees. Wavelength: scalar, unit m, ticks '0.0000001392'. Axis labels are glue's `x_att_world.label`, with no unit | Yes: ticks '1392'…'1396'. glue builds new coordinate helpers on every reset, so per-helper settings are lost (measured: `format_unit` back to m after an axis swap) |
| D | Cursor readout: tools.py:315 `axes.format_coord` → wcsaxes/core.py:155-183 → `CoordinateHelper.format_coord` coordinate_helpers.py:474-494 | as C, plus tick spacing | λ–step: '0.0000001393 288.1" −331"'. On 4000255147 λ–time: '0.0000001402 64.5" 104"' (every world axis kept by the slice; this is the WP11 note) | Units yes ('1393 288.1" −331"'), precision no |
| E | Image state axis labels: image/state.py:247-300; viewer.py:77-80 | `world_component_ids` → `world_axis_names` | 'Wavelength', 'Helioprojective Latitude/Longitude' (from `_AXIS_NAMES`) | Not unit-bearing |
| F | Re-slice decision: image/viewer.py:130-145 (`dependent_axes`, coordinate_helpers.py:163-175) | `axis_correlation_matrix` | n/a | n/a |
| G | Profile x: profile/state.py:271-284 (`x_display_unit` = `component.units`); 181-210 limits; 480-485 x values; core/units.py:9-56 `UnitConverter` (reads `get_component(cid).units`); profile/viewer.py:23 label | `world_axis_units` (via B), `pixel_to_world_values` | `x_display_unit` 'm'; x×1e10 vs irispy 4.6e-13 Å; ticks '1.391' with an offset; label 'Wavelength'. Choosing 'Angstrom' gives 0 Å difference | Yes: 'Angstrom' by default, 0 Å, ticks '1391'… |
| H | Profile x range → subset: profile/viewer.py:35-58 (display→native, then a `RangeSubsetState` on the world component) | as G | consistent | Yes |
| I | Profile Navigate: glue_qt/viewers/profile/profile_tools.py:163-176 compares display-unit x with native values | as G | Display Å with native m → index 193 instead of 64 (glue-qt bug) | Yes: native Å gives (2, 64) |
| J | Image → Profile tool: glue_qt/viewers/image/profile_viewer_tool.py:77-80 | `world_component_ids` | n/a | follows B |
| K | `link_hpc` (iris.py:392-423, `LinkSame` of world components) → `CoordinateComponentLink.using` component_link.py:375-395 (`default_world_coords` 8-12 gives zeros for a non-FITS WCS); world→pixel goes through glue_patches.py:51-77 | `world_axis_physical_types`, `pixel_to_world_values`, `world_to_pixel_values`, `axis_correlation_matrix` | arcsec on both sides, by construction | Unaffected; arcsec already |
| L | `LinkSameWithUnits` (wp1-m1-sunpy-maps): link_helpers.py:438-461 | `world_axis_units` (via B) | 'arcsec' vs a map's 'deg' converts | Yes |
| M | Fixed-resolution buffer and pixel subsets across links: fixed_resolution_buffer.py:80-92; link_manager.py:371; `PixelSubsetState._to_linked_pixel_coords` (glue_patches.py:241-273) | as B/K | n/a | follows K |
| N | WCSLink: wcs_autolinking.py:110-215 (`has_celestial` 146; `SlicedLowLevelWCS` + `HighLevelWCSWrapper`) → `get_cids_and_functions` 79-98 → astropy `pixel_to_pixel` wcs/utils.py:887-946 → high_level_api.py:164-275, 314-380 | `pixel_n_dim`, `world_n_dim`, `world_axis_physical_types`, `world_axis_object_components`, `world_axis_object_classes`, `serialized_classes` (False) | IncompatibleWCS for 1394↔1403 and for raster↔SJI. Root cause: components and classes still carry the wrapped WCS's degrees and metres | Yes, once components and classes are overridden: forwards(centre) = [-175, 274.000001, 159.999999], identical to the unwrapped link. Raster↔SJI fails unwrapped as well ("Expected … SkyCoord, Time"); that is glue's #2595 / M4 work |
| O | `wcs_autolink`: wcs_autolinking.py:320-322 | `isinstance(coords, BaseHighLevelWCS)` | `_GlueWCS` is low-level only → [] (measured) | n/a until M4 |
| P | glue derived slices: data_derived.py:48-52 `SlicedLowLevelWCS(_GlueWCS)`; path_slicer/path_sliced_data.py:69-98; glue_qt pv_slicer.py:212, 274 | delegated through sliced_wcs.py:209-210 (units), 239-260 (values), 292-296 (objects) | n/a | follows the wrapper |
| Q | Export and sessions: gridded_fits.py:52 and glue_patches.py:195 (`isinstance(coords, WCS)` is False → no WCS header); core/state.py:906-907 needs a `_GlueWCS` saver (wp3) | none | not a display path | n/a |

glue never reads `low_level_wcs` on `Data.coords`. astropy reads it only through `HighLevelWCSWrapper` (`pixel_to_pixel`, utils.py:787-789) and in `reset_wcs` for high-level WCSes (core.py:432-433).

## IRIS WCS kinds (all wrapped by `_GlueWCS`)

| Kind | Wrapped WCS | Wrapped units | `_GlueWCS` units today | Low-level p→w→p | High-level (`HighLevelWCSWrapper(_GlueWCS)`) |
|---|---|---|---|---|---|
| Raster scan (3610108077, 3400109360) | astropy WCS with -TAB | (m, deg, deg) | (m, arcsec, arcsec) | 1.3e-6 px, same as wrapped | fails: latitude 287.9 / 382.6 "deg" |
| Sit-and-stare (4000255147) | astropy WCS with -TAB | (m, deg, deg) | (m, arcsec, arcsec) | 6.2 px on the exposure axis, same as wrapped (degenerate axis) | SkyCoord 3600 times too large |
| 4-D stack, lazy (4000005156) | `CompoundLowLevelWCS(WCS, Sliced 'Scan')` | (m, deg, deg, '') | (m, arcsec, arcsec, '') | 2.3e-6 px | SkyCoord 3600 times too large |
| SJI 1400 and AIA 171 cutout | gWCS | (arcsec, arcsec, s) | unchanged | 7e-10 px (wrapped 6.5e-10) | matches the wrapped WCS. SJI high-level round trip at fractional frame 199.5 is off by 0.3 px in x; that is the gWCS Time inverse, not chased |

With the scratch patch, the stack's high-level objects equal the wrapped WCS's and the high-level round trip matches the low-level one.

## Tick-label overlap and the cost of exclusion (offscreen, 640×480 at 100 dpi, median of 30 draws)
- **3610108077 λ–step panel, latitude:** 24 labels placed with 20 overlapping pairs. Latitude spans about 0.3″ (287.8″–288.1″), not monotonically, so the same values repeat ('288.1″' about 14 times). `exclude_overlapping=True` draws 12 labels with 0 overlaps.
- **Cost:** a draw went from 34.3 to 30.5 ms (32.2 to 28.5 ms with Å), and the label drawing itself from 15.1 to 11.4 ms. It got faster, because WCSAxes already measures every label's box whether or not exclusion is on (ticklabels.py:335-338); exclusion only adds an overlap check (344-346). On panels with no overlap the difference was ±0.3 ms.
- **Before/after images:** the exclusion PNG still shows repeated non-monotonic labels such as '288.1″'. That favours the plan's other option: no latitude labels where latitude barely changes.
- **Wavelength labels:** in metres they overlap on 4000255147's spectrogram and λ–time panels (7 labels, 6 pairs). With Å there are none.
- **Keeping the setting:** glue's `_set_wcs` replaces `axes.coords`, so it must be applied again after each reset (as `FrameTimeTool._label_exposures` already does at tools.py:199-203).

## glue-solar code, tests and docs that depend on the units
- **Already unit-agnostic:**
  - `quicklook._wavelengths` (quicklook.py:662-668) converts using `world_axis_units`.
  - `_lon_lat` and `_sji_pixels` (90-114) assume arcsec, which stays the same.
- **Will break on an Å change:** test_importer.py:251 asserts `("m", "arcsec", "arcsec", "")`, and test_documented_workflows.py:54 asserts `"m"`.
- **Follow the change:** test_quicklook.py:222 and 260.
- **Docs:** docs/user_guide/scripting-iris-data.rst:33 says "wavelength (in metres)".

## How measured
All probes ran in iris-plan with a scratch HOME, offscreen Qt, Agg and `PYTHONPATH=/Users/nabil/Git/glue-solar-accept`. irispy's `axis_world_coords("em.wl")` was the wavelength reference. Scripts and outputs are in `/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/wrapper/glue-paths/`:
- `wcs_kinds.py` → `wcs_kinds.out`
- `roundtrip.py` → `roundtrip.out`
- `gui_paths.py` → `gui_paths.out`, `gui_paths_4000255147.out`
- `links.py` → `links.out`
- `readout_nav.py` → `readout_nav.out`
- `proto_wrapper.py` (the scratch patch; not an implementation) and `proto_paths.py` → `proto_paths.out`
- `wavelength_panel_before.png` and `wavelength_panel_exclude.png`

=== MAP iris-wcs ===
**IRIS WCS kinds that glue-solar wraps (task `iris-wcs`)**

`_GlueWCS` already reports arcsec on every IRIS WCS kind. It leaves wavelength in metres, and it never touches the high-level object classes. On the -TAB rasters and stacks those classes still say degrees, so glue's WCS link fails or lands in the wrong place on IRIS rasters. Pixel→world→pixel to 1e-9 px holds today only on the SJI and AIA cubes (gWCS). The -TAB rasters stop at about 1.3e-6 px because of a fixed tolerance inside wcslib. On the sit-and-stare raster the step axis cannot round-trip at all: the inverse is off by up to 6 exposures.

**How it was measured**
- Data were loaded with glue-solar's own loaders from `/Users/nabil/Git/glue-solar-accept` (main at fbb36b3). `PYTHONPATH` was set to that checkout, and I printed the module path to confirm it, because the env's editable install points at `~/Git/glue-solar`.
- Env `iris-plan`: astropy 8.0.1, glue 1.27.0, irispy 0.9.1, ndcube 2.4.2, gwcs 1.0.3. Runs used a scratch HOME, offscreen Qt and Agg.
- Each round trip used 2000 random pixels plus 2000 integer pixels, uniform over each axis. Every check was run through both `_GlueWCS` and the native WCS it wraps.
- Scripts and output: `/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/wrapper/iris-wcs/` (`probe.py`/`probe.out`, `probe2.py`/`probe2.out`, `probe3.py`/`probe3.out`, `probe4.py`).

## 1. The WCS kinds and what `_GlueWCS` does to each

World axes are listed in APE-14 order. Glue's world components are in the reverse order.

| Kind (dataset) | What `_GlueWCS` wraps | Native units | Native physical types | Native names | `_GlueWCS` units | `_GlueWCS` names |
|---|---|---|---|---|---|---|
| Raster, -TAB, one WCS per scan (3610108077, 7 windows) | astropy `WCS` with WAVE, HPLT-TAB, HPLN-TAB (`irispy/io/spectrograph.py:57-112`) | m, deg, deg | em.wl, …helioprojective.lat, …helioprojective.lon | '', '', '' | m, arcsec, arcsec | Wavelength, Helioprojective Latitude, Helioprojective Longitude |
| Sit-and-stare raster, -TAB (4000255147, 9 windows, 1600 exposures) | same | m, deg, deg | same | same | m, arcsec, arcsec | same |
| Stack (3400109360, 8 scans, 7 windows) | `CompoundLowLevelWCS(scan-0 -TAB WCS, sliced LINEAR "Scan")` (`stack_spectrograms.py:67-79`) | m, deg, deg, '' | em.wl, lat, lon, None | '', '', '', 'Scan' | m, arcsec, arcsec, '' | Wavelength, …Latitude, …Longitude, Scan |
| SJI 1400 (4000255147) | `gwcs.WCS`: VaryingCelestialTransform & time lookup (`irispy/io/sji.py:66-115`) | arcsec, arcsec, s | …lon, …lat, time | Longitude, Latitude, Time (UTC) | unchanged | Helioprojective Longitude, Helioprojective Latitude, Time (UTC) |
| AIA cutout (3640107442, 1600 Å) | the same gWCS; `read_files` sends AIA files through `read_sji_lvl2` | arcsec, arcsec, s | same as SJI | same as SJI | unchanged | same as SJI |

**Where the units come from**
- Raster headers say `CUNIT1=Angstrom` and `CUNIT2/3=arcsec`.
- irispy rewrites the two helioprojective axes to deg for -TAB (`spectrograph.py:63, 91-94`).
- wcslib's `wcs_units` turns spectral axes into SI metres (`astropy/cextern/wcslib/C/wcs.c:3306-3375`).
- Raster world order is (λ, lat, lon), because CTYPE2 is HPLT and CTYPE3 is HPLN.
- Rasters have no time world axis. Time exists only as glue's "Time" component (`iris.py:216-218`). That is why a sit-and-stare exposure axis reads lon/lat (the WP11 note).

**What `_GlueWCS` changes** (`glue_solar/sources/loaders/iris.py:82-166`)
- `world_axis_units`: any helioprojective axis becomes 'arcsec'. Everything else passes through, so wavelength stays 'm' and time stays 's' (`iris.py:110-114`).
- `pixel_to_world_values`: multiplies helioprojective values by their scale to arcsec and wraps longitude to ±180° (`iris.py:148-152`). On the gWCS cubes the scale is 1, so only the wrap applies.
- `world_to_pixel_values`: scales helioprojective values back (`iris.py:161-166`).
- `world_axis_names` is renamed, `axis_correlation_matrix` is taken under the lock, and `has_celestial=False` is set.
- Passed through untouched (`astropy/wcs/wcsapi/wrappers/base.py:32-69`): `world_axis_physical_types`, `world_axis_object_classes`, `world_axis_object_components`, `pixel_shape`, `pixel_bounds`, `serialized_classes`.

**Correlation matrices**
- Rasters: lat and lon each depend on both slit and step; wavelength stands alone.
- Stack: same, plus an independent Scan axis.
- SJI/AIA: lon and lat depend on x, y and t; time depends on t only.

## 2. Measurements

Pixel→world samples at pixel (0, …) and the centre, in native units, then through `_GlueWCS`:
- **3610108077 C II:**
  - Native: (1.33176765e-7 m, 0.05468° lat, −0.10856° lon); centre (1.33610e-7 m, 0.07997°, −0.09192°).
  - Wrapper: (1.33176765e-7 m, 196.8517″, −390.8050″); centre (…, 287.8965″, −330.9012″).
- **4000255147 C II centre:** wrapper (1.33636e-7 m, 63.914″, 105.679″).
- **SJI 1400 centre:** (105.64604″, 63.91321″, 2370.605 s).
- **AIA 1600 centre:** (854.1201″, 510.1284″, 2124.003 s).

Wavelength against irispy (3610108077, every window): `_GlueWCS` value × 1e10 matches `cube.axis_world_coords("em.wl")` in Å to 4.5e-13 Å (FUV windows) and 9.1e-13 Å (NUV windows). The values are already right; only the unit ('m') is wrong for the 1e-6 Å target.

Round trip, maximum |Δp| per pixel axis:

| Dataset | λ | slit / y | step / x | scan / t | Native WCS | Time for 2000 points |
|---|---|---|---|---|---|---|
| 3610108077, all 7 windows | 5e-12 | **1.30e-6** | **1.08e-6** | – | identical | 59 ms |
| 3400109360 stack, all 7 windows | 5e-12 | **1.25e-6** | **3.8e-7** | 4e-16 | – | 24–30 ms |
| 4000255147 sit-and-stare, all 9 windows | 5e-12 to 1e-11 | **0.27** | **6.04 (6.09 at integer pixels)** | – | identical | **12.4–16.5 s (6–8 ms per point)** |
| SJI 1400 | – | 6.9e-10 | 6.8e-10 | 1e-13 | 6.6e-10 | 286 ms |
| AIA 1600 | – | 1.9e-10 | 1.9e-10 | 6e-14 | 1.8e-10 | 129 ms |

No NaNs on any dataset. Only the SJI and AIA cubes pass 1e-9 px today, and the SJI's margin is about 30%, set by gWCS itself.

## 3. Findings

**1. Wavelength reaches every glue path in metres.** All three places named in the done criterion read it from `world_axis_units`:
- Slider: `glue_qt/viewers/common/slice_widget.py:108`.
- World-component units, used for Profile x: `glue/core/component.py:248`.
- WCSAxes ticks and the mouse-over readout: em.wl maps to 'scalar', so `format_unit` is the axis unit (`astropy/visualization/wcsaxes/wcsapi.py:153-156`).

glue-solar's own consumers will survive a switch to Å:
- `quicklook.py:663-668` converts through `world_axis_units`.
- `quicklook.py:90-115` assumes arcsec only for lon/lat.

**2. The high-level API through `_GlueWCS` is wrong on every -TAB raster and stack.**
- The inherited `world_axis_object_classes` keep `unit=(deg, deg)` (`astropy/wcs/wcsapi/fitswcs.py:445-450`) while the values are arcsec.
- On 4000255147, `HighLevelWCSWrapper(_GlueWCS).pixel_to_world` gives Tx/Ty = (380444.6″, 230090.6″) where the native WCS gives (105.679″, 63.914″).
- On 3610108077 it raises `ValueError: Latitude … got 287.9 deg`.
- Glue's 'WCS link' helper reaches this through `wcs_autolinking.py:196-201` and its `pixel_to_pixel` probe (79-97). So:
  - `WCSLink` between the 3610108077 C II and Si IV 1403 windows → `IncompatibleWCS`.
  - Raster (slit 200, step 114) through the high-level path to SJI 1400 frame 0 → (nan, nan). The low-level arcsec path gives (199.37, 201.97).
- Autolinking skips IRIS data anyway: `BaseWCSWrapper` is only a `BaseLowLevelWCS` (`base.py:6`), and `wcs_autolink` keeps only `BaseHighLevelWCS` datasets (`wcs_autolinking.py:320-321`).
- SJI and AIA (gWCS) are consistent: their classes say arcsec.
- The same trap applies to wavelength once it reports Å: the spectral class and component carry `unit=cunit`, i.e. m (`fitswcs.py:656, 699-712`). So the wrapper must override `world_axis_object_classes` and `world_axis_object_components` together with the units.

**3. The 1e-9 px round trip fails on all -TAB rasters and stacks because of a wcslib tolerance.**
- `tabvox` accepts a match within `tol = 1e-10` in the table's units, which are deg (`astropy/cextern/wcslib/C/tab.c:1669, 1731`).
- That is 3.6e-7″, or about 1e-6 px at 0.33″ per slit pixel.
- The measured world residual after the inverse is 1.1e-10° on each axis, which confirms it.
- FITS-TAB celestial tables must be in deg, so irispy cannot change the unit.
- Newton steps after wcslib's answer, using the cheap forward transform, bring it within budget:
  - 3 steps on the native deg WCS → 2.3e-11 px.
  - Through `_GlueWCS` in arcsec → 2.8e-10 px.
  - 2 steps cost 0.6 ms for 2000 points, against 58.7 ms for wcslib's inverse.
- The 2.8e-10 px floor through the wrapper comes from its longitude wrap `(v+180)%360-180` (`iris.py:151`), which costs up to 5.1e-11″. Wrapping only out-of-range values would remove it.

**4. On the sit-and-stare raster, world→pixel is ill-posed on the exposure axis.** This confirms GLUE_SPEED.md R8.
- After the inverse, the world residual is 3.8e-7″, so the answers are valid points, just not the original exposure.
- They are off by up to 6.1 exposures and 0.27 px along the slit.
- Along the 1600 exposures at the central slit row: lon spans 13.02″ with a median step of 0.0002″, 12 zero steps and 479 direction changes; lat spans 1.32″.
- Each point costs 6–8 ms.
- 1e-9 px cannot hold on that axis while lon/lat are its only world coordinates. The exposure axis would need time as its world axis, which is also what WP11 asks for.

**5. Why the latitude tick labels overlap on the λ–t panel.**
- 3610108077: along 320 steps, latitude spans only 0.392″ and changes direction 196 times, at every slit row checked. WCSAxes therefore places latitude ticks at many crossings of the y axis.
- 4000255147: 1.32″ with 108 direction changes.
- I did not measure the cost of `exclude_overlapping`.

**6. Stack pointing.**
- The Scan axis has physical type None and unit ''.
- Every scan uses scan 0's pointing. Compared with each scan's own WCS, scan 5 is off by 1.03″ in lon and scans 1–7 by 0.02–0.04″ in lat. This is the M3 item `wp1-stack-per-scan-wcs`.
- 3400109360 has STEPS_AV −0.998, so irispy flips its step axis.

**7. Minor.** Glue labels the SJI and AIA time world component 'Time (Utc)'. The native name is 'Time (UTC)'.

=== MAP gui ===
# GUI mapping for wp1-m1-wrapper-coherence: where 3610108077 and 4000255147 show metres or degrees

No helioprojective coordinate shows in degrees anywhere in the quicklook. Every wavelength shows in metres: the wavelength slider, the Image tick labels, the cursor readout and the Profile. Nanometres never appear unless the user picks 'nm' in the Profile's unit menu. The overlap problem differs between the two observations:
- **3610108077:** the λ–step panel's latitude labels overlap.
- **4000255147:** the overlapping labels on the λ–time and spectrogram panels are the wavelength labels in metres. The latitude labels are already hidden on that axis.

## How it was run
- **Code:** glue-solar main at `/Users/nabil/Git/glue-solar-accept` (fbb36b3, #96 lazy loading).
- **Env and settings:** the `iris-plan` env, `HOME=$(mktemp -d)`, `QT_QPA_PLATFORM=offscreen`, `MPLBACKEND=agg`.
- **Driving:** `GlueApplication` resized to 1800×1100 and shown, then `quicklook(app, datasets, window)`.
- **Mouse:** a real `motion_notify_event` was sent through `glue_solar.tests.helpers.mouse` at 50%/50% and 25%/75% of each panel's limits. The status bar text matched `CursorReadoutTool.describe()`.
- **Drawn tick labels:** recorded with a spy on `Text.draw` for `TickLabels` after `canvas.draw()`. Overlap counts come from pairwise checks of the drawn label boxes.
- **Draw cost:** measured in a separate script with no spy. Each figure is the median of 14 full Agg `canvas.draw()` calls, with the label modes interleaved.
- **Cases:**
  - 3610108077 Mg II k 2796 and Si IV 1403 (320 steps, 7 windows, no local SJI).
  - 4000255147 Mg II k 2796 and Si IV 1403, each with SJI 1400.
- **Files** (all under `/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/wrapper/gui/`):
  - scripts: `probe.py`, `timing.py`
  - logs: `log-*.txt`, `timing-*.txt`
  - JSON and screenshots: `out/*.json` and `out/*.png`. Screenshots per case and panel are `-app`, `-<role>-window`, `-<role>-figure`, `-<role>-figure-excl`, `-<role>-options`, `-spectrum-figure-AA`.

## WCS facts for each dataset kind

| Dataset | Wrapped WCS | Units glue gets from `_GlueWCS` | Units of the wrapped WCS | Round trip, max px (λ or x, slit or y, step or z) |
|---|---|---|---|---|
| 3610108077 raster | astropy WCS `WAVE, HPLT-TAB, HPLN-TAB` | m, arcsec, arcsec | m, deg, deg | 5.2e-12, **1.2e-6, 1.1e-6** |
| 4000255147 raster (sit-and-stare) | astropy WCS, also `-TAB` | m, arcsec, arcsec | m, deg, deg | 1.0e-11, **0.16, 5.78** |
| 4000255147 SJI 1400 | gwcs | arcsec, arcsec, s | arcsec, arcsec, s | 5.9e-10, 4.7e-10, 5.7e-14 |

- **Method:** 50 random fractional pixels with seed 0.
- **The wrapper is not the cause:** the wrapped irispy WCS gives the same numbers (`timing-*.txt`). The 1e-9 px target fails inside wcslib's `-TAB` inverse on 3610108077.
- **Sit-and-stare cannot be inverted along the exposures:** at slit row 208, latitude spans 63.35″ to 64.67″ and reverses direction 108 times across the exposures. Longitude spans 99.19″ to 112.21″.
- **Wavelength values are right:** the dataset's wavelength coordinate converted to Å equals irispy's `cube.axis_world_coords("em.wl")` exactly (max |Δ| = 0.0 Å) in all four window cases.

## Every place a wavelength shows in metres

1. **Wavelength slider on the map panel** (the "slit vs time" panel on 4000255147):
   - It reads `Wavelength 2.79621e-07 m` on 3610108077 Mg II and `1.40278e-07 m` on Si IV.
   - The format is `{:.5e}`. The string differs from irispy by at most 0.00498 Å over 380 pixels (3610108077) and 0.00499 Å over 555 pixels (4000255147). Every pixel still gets its own label.
   - Source: glue-qt takes the unit from `coords.world_axis_units` (`glue_qt/viewers/common/slice_widget.py:108`) and formats it at `glue_qt/viewers/common/data_slice_widget.py:73` and `:118-119`.
   - `_GlueWCS.world_axis_units` passes 'm' through unchanged (`glue_solar/sources/loaders/iris.py:109-114`).
2. **Bottom tick labels on the spectrogram and λ–step / λ–time panels:**
   - Labels look like `0.0000002795`, `0.0000002800`, `0.0000002805`. The axis label is plain 'Wavelength', with no unit.
   - WCSAxes uses the axis unit as the format unit (`astropy/visualization/wcsaxes/wcsapi.py:156`). The decimals come from the tick spacing (`formatter_locator.py:638-656`).
   - On 4000255147 there are 7 labels with **6 overlapping pairs** on both panels and both windows (`*-wavelength-window.png`).
3. **Cursor readout on the spectrogram and λ panels:**
   - Example: `0.0000002800 288" −330.7" (world) | value = 153`.
   - The wavelength has the tick-label precision (`coordinate_helpers.py:488`), so it changes in 1 Å steps. That is about 20 pixels per readout step on 3610108077 NUV and about 40 on 4000255147 NUV.
   - The readout is `axes.format_coord` (`glue_solar/tools.py:315`, which calls `astropy/visualization/wcsaxes/core.py:156-183`).
4. **Profile x axis:**
   - The component unit is 'm' (`glue/core/component.py:245-248`) and `x_display_unit` defaults to 'm' (`glue/viewers/profile/state.py:280-284`).
   - The ticks read `2.7900 … 2.8100` with offset text `1e−7`, and the label is plain 'Wavelength'.
   - The x limits are 2.79065e-07 to 2.80995e-07, in metres.
   - Matplotlib's `format_coord` gives `(x, y) = (2.80030e−07, 0)`.
   - The options panel's "x unit" combo shows 'm' (`*-spectrum-options.png`).
5. **The Profile's x-unit menu is hard to use:**
   - It lists 131 length units (pc, AU, lyr, solRad, …) in an order that changes from run to run. 'Angstrom' was at index 123, 63, 54 and 31 in the four runs, and 'nm' at 93, 120, 49 and 90 (`glue/core/units.py:59-71`).
   - Picking 'Angstrom' already works: limits become 2790.65–2809.95 and ticks `2790.0 … 2810.0`, though the label stays 'Wavelength'.
   - y-unit choices are `[None, 'DN_IRIS_NUV']` (or `DN_IRIS_FUV`) and the y label is 'Data values'.
6. **Not visible:** WCSAxes' default label `Wavelength [m]` sits on the map panel's wavelength coordinate, which is never drawn.

## Helioprojective coordinates in degrees
None appear on screen.
- **Tick labels:** the map, spectrogram, λ panels and SJI all format HPLN and HPLT in arcsec. The labels look like `−380"`, `350"`, `105.4"` and `288.1"`. This works because `_GlueWCS` reports arcsec and WCSAxes formats helioprojective axes in arcsec (`wcsapi.py:39-45`).
- **Readouts:** they show arcsec, for example `288" −331" (world)`.
- **Step and slit sliders:** they show the pixel index (`160`, `274`, `800`, `208`). Their world toggle starts off because each axis depends on both the step and slit axes (`dependent_axes` = (0, 1); `slice_widget.py:109`, `data_slice_widget.py:99`). Turned on, they show arcsec:
  - format `{:.1f}` on 3610108077;
  - format `{:.14e}` on the 4000255147 step slider, because the sit-and-stare longitudes nearly repeat.

## Other readout and label findings
- **Readout order and labels:** values come in the WCS world order (λ, HPLT, HPLN) with no names. On the map panel, whose x axis is longitude, the first number is the latitude.
- **Sit-and-stare readout (the WP11 note is confirmed):**
  - On the "slit vs time" panel at exposure 799.5 the readout is `64" 106" (world)`.
  - On the λ–time panel it is `0.0000002801 63.9" 106" (world)`.
  - Both show helioprojective coordinates along the exposure axis instead of the exposure or time, and the wavelength in metres.
- **3610108077 λ–step panel:**
  - The left axis shows **24 latitude labels** (`287.8"` to `288.1"`) with **26 overlapping pairs**, in both windows. Along the steps the latitude spans 287.787″ to 288.178″ and reverses direction 196 times, so each tick value crosses the left edge many times.
  - The left axis title reads 'Helioprojective Latitude', although glue's `y_axislabel` is 'Helioprojective Longitude'.
  - The step axis's own coordinate (longitude) has its ticks on the right edge, where the figure cuts the labels off (`−3…`). The spectrogram panel's right-hand longitude labels are cut off the same way (`*-wavelength-window.png`, `*-app.png`).
- **4000255147 λ–time panel:** glue-solar already replaces HPLN/HPLT with exposure-index ticks 0–1500 (`glue_solar/tools.py:88-112`). The only overlap there is the wavelength labels.
- **SJI slider:** it is labelled 'Time (Utc)', because glue title-cases the axis name (`glue/core/coordinate_helpers.py:189`). Its world values are seconds since the first frame (0 to 4741.2 s), and the index shows by default.
- **Frame time readout:** it contains no length or angle units. Examples:
  - `2018-01-02T15:56:32.930 UTC · exp 7.999 s · time master, step 160`
  - Si IV map: `… · exp 0–7.999 s · …`
  - SJI: `2013-09-02T17:19:16.220 UTC · exp 2 s · Δt +3.0 s`

## Cost of `exclude_overlapping`, in ms per full draw
WCSAxes measures every label's box whether or not the option is on (`ticklabels.py:331-349`). The option only adds an overlap check and draws fewer labels, so it costs nothing.

| Panel | Plain | Exclude on all coords | Exclude on latitude only | Latitude labels hidden |
|---|---|---|---|---|
| 3610108077 λ–step | 27.0 | 22.9 | 22.8 | **16.2** |
| 3610108077 map | 14.4 | 14.4 | 14.2 | 11.7 |
| 3610108077 spectrogram | 16.8 | 17.1 | 16.8 | 14.3 |
| 4000255147 λ–time | 19.6 | 18.2 | 19.7 | 19.6 (already hidden) |
| 4000255147 map | 14.3 | 14.4 | 14.4 | 12.2 |
| 4000255147 spectrogram | 17.7 | 16.2 | 17.8 | 15.7 |

The "latitude labels hidden" column is only meaningful for the λ–step panel; on the map and spectrogram that option would remove labels the user needs.

What each option leaves on screen:
- **3610108077 λ–step:** `exclude_overlapping` still leaves 11 latitude labels with repeated values (`288.1"` six times; `*-wavelength-figure-excl.png`). Hiding latitude labels where latitude barely changes is cleaner and saves about 11 ms per draw.
- **4000255147 λ–time:** `exclude_overlapping` cuts the wavelength labels from 7 to 4 with no overlaps. Showing them in Å ('2794' instead of '0.0000002794') would shorten each label from 12 characters to 4. That would probably remove the overlap without the option, but I did not measure it.

## Done criteria to adjust in the plan
- **"Within 1e-6 Å of irispy":** this can only be checked on values, not on displayed text. The underlying values already match irispy exactly, but every display rounds: the slider to 0.005 Å, the readout to 1 Å.
- **"pixel→world→pixel to 1e-9 px":** this fails inside the wrapped irispy `-TAB` WCS itself (1.2e-6 px on 3610108077). On sit-and-stare data the exposure axis cannot be inverted at all.
- **"latitude tick labels":** this matches 3610108077's λ–step panel. On the 4000255147 λ–time panel the overlapping labels are wavelengths.

Not covered here: the 4D stack (another WCS kind) and nm displays (none exist by default).

=== MAP ticks ===
**λ–t / λ–step tick-label overlap: measurements and the cheapest fix (wp1-m1-wrapper-coherence)**

**Result.** The cheapest fix is to hide a helioprojective coordinate's tick labels when it barely changes across the panel, using `set_ticklabel_position("")`. On 3610108077 this removes all 34 overlapping latitude pairs and makes every draw about 11 ms faster (27 → 16 ms, −41 %). `set_ticklabel(exclude_overlapping=True)` also removes the overlap, saving about 5 ms, but it leaves confusing repeated labels and keeps longitude clipped off the panel. The wavelength labels in metres also overlap, and the item's Å change alone fixes that.

### Setup (how I measured)
- **Code and environment:** main at fbb36b3 (`/Users/nabil/Git/glue-solar-accept`), `iris-plan` env, offscreen Qt with Agg, scratch HOME. Same app as the acceptance probe: GlueApplication at 1600x1000, `quicklook(app, [raster])` on scan 0, no SJI.
- **Panel size:** the wavelength panel's canvas is 414x337 px and its axes are 289x262 px, at DPR1.
- **Each option:** glue's own `viewer._set_wcs(relim=False)` (the reset a slit step does, so FrameTimeTool reapplies its labels), then the option, then `canvas.draw()`.
- **Instrumentation:**
  - `TickLabels._get_bb` records each label's bbox.
  - `Text.draw` marks which labels were actually drawn.
  - `Text.get_window_extent` calls from `TickLabels` are counted.
  - Time inside `TickLabels.draw` is summed.
- **Overlap:** a pair of drawn tick labels whose boxes intersect by more than 0.5 px in both x and y. "Clipped" means a box extends past the canvas.
- **Timing:** 3 rotated rounds × 15 draws per option. The figure is the median of the per-round medians.
- **Å emulation (`AA=1`):** patches `_GlueWCS` so `em.wl` reads Angstrom, values ×1e10. This approximates the post-item state, since the real Å wrapper does not exist yet.

### Cause
- irispy 0.9.1 builds this raster's WCS as HPLT-TAB/HPLN-TAB from the per-step pointing (`irispy/io/spectrograph.py:57-114`).
- At a fixed slit row, latitude along the step axis is not monotonic. It jitters by −0.013 to +0.028″ per step and spans only 0.38″ over 320 steps. Longitude spans 118.7″.
- WCSAxes adds one label for every crossing of a tick value between adjacent frame samples (`coordinate_helpers.py:1137-1149`). So 4 values (287.8–288.1″) become 24 labels.
- `auto_assign_coord_positions` picks the spine layout with the most labels (`_auto.py:79-111`, spine order "bltr" from `frame.py:371`). So jittery latitude takes the left spine and longitude goes right.
- On the right, all 6 longitude labels and glue's "Helioprojective Longitude" axis label are cut off at the 414 px canvas edge. The left spine shows WCSAxes' default "Helioprojective Latitude" label instead.
- On 4000255147 (sit-and-stare λ–time) there are no latitude labels at all: FrameTimeTool's `_index_ticks` (`tools.py:85-112`) keeps only wavelength and exposure-index ticks.
  - Today's overlap there is the wavelength in metres: 7 labels like "0.0000001400", 6 overlapping pairs, and 1 clipped on Si IV 1403.
  - With Å it is 0 overlaps and 0 clipped.

### 3610108077 λ–step panel (identical spread on C II 1336, Si IV 1403 and Mg II k 2796)
"Δ draw" is the change against a 26.5–28.4 ms draw (labels 12.7–15.1 ms of it). "Lat overlaps" is overlapping latitude pairs. "Lon clipped" is longitude labels cut off at the right edge.

| Option | Δ draw | Labels measured (extents/draw) | Lat overlaps | Lon clipped | Notes |
|---|---|---|---|---|---|
| base | 0 | 33–35 (66–70) | 34 | 6/6 | wl in metres adds 2–4 overlapping pairs |
| `exclude_overlapping` on lat | −4.6 to −5.0 ms | 33–35 (66–70) | 0 | 6/6 | 9 lat labels left, repeated values ("288.1″" ×5) |
| `exclude_overlapping` on all | −4.7 to −6.1 ms | 33–35 | 0 | 6/6 | metres: drops 1–3 wl labels |
| **hide lat, conditional** (`set_ticklabel_position("")`) | **−11.0 to −11.4 ms** | **9–11 (18–22)** | **0** | **0** | lon moves left, glue's y label shows |
| `set_ticklabel_visible(False)` on lat | −10.5 to −11.1 ms | 9–11 | 0 | 6/6 | lat still wins the left spine, lon stays clipped |
| `set_ticks(number=2 or 3)` on lat | −7.4 to −8.1 ms | 16–18 | 7 | 6/6 | |
| `set_ticks(spacing=1″)` on lat | −9.4 to −10.1 ms | 12–14 | 1 | 6/6 | 3 identical "288″" labels |
| lat labels forced to the right spine | ±0.5 ms | 33–35 | 34 | lat 24 clipped | |

With Å, hide + Å gives 0 overlaps and 0 clipped, at 15.7–16.6 ms against 27.0–27.9 ms (labels 3.3–4.0 ms against 12.7–13.4 ms).

**Costs of the two candidates:**
- **`exclude_overlapping`:** it measures no extra labels. WCSAxes already measures every label twice per draw, at `ticklabels.py:239` and `:305`, both before the exclusion check at `:343-349`. The check itself is 33 `Bbox.count_overlaps` calls, 0.15 ms per draw. It ends up net faster only because it skips drawing about 15 labels.
- **The condition:** compare each helioprojective coordinate's span along the panel's 4 edges (256 samples) with the other's, and hide it below 5 %. That costs 0.16 ms median on 3610108077 and 0.1–1.0 ms on the other observations. It is paid once per glue `_set_wcs`, not per draw.

### Does the condition hold on other data? (with Å, 2 rounds × 10 draws)
"Ratio" is the latitude span over the longitude span across the panel; the condition hides latitude below 0.05.

| Observation and panel | Ratio | Base | With hide |
|---|---|---|---|
| 3824262996 λ–step | 0.009 | 21 lat overlaps, 19.5 ms | 0 overlaps, −4.8 ms |
| 3400109360 λ–step (negative step) | 0.008 | 9 lat overlaps | 0, −5.7 ms |
| 4000005156 λ–step | 0.007 | no overlaps, lon 6/6 clipped | lon moves left, −2.5 ms |
| 3893012099 λ–step | 0.011 | no overlaps, lon 4/4 clipped | lon moves left, −2.2 ms |
| 3660259102 λ–time (sit-and-stare) | 0.20 | no lat labels (FrameTimeTool), 0 overlaps | no change |
| 4000255147 λ–time | 0.099 | 0 overlaps with Å | no change |
| 3602506433 99-scan stack λ–scan | — | lat/lon constant across scans (span 0), not shown, 0 overlaps | does not fire |
| map panels (3610108077, 4000255147 Mg II k) | 1.5, 5.1 | no overlaps | does not fire |
| spectrogram, 3610108077 (lon 2.06″ vs lat 182″) | 0.011 | lon on right, 4/4 clipped | lon hidden, −2.6 ms |
| spectrogram, 4000255147 (lon 0.78″ vs lat 69″) | 0.011 | lon on right, 4/4 clipped | lon hidden, −2.9 ms |

On sit-and-stare λ–t panels, latitude also jitters, but the 0.05 rule would not hide it (ratio 0.099–0.20). FrameTimeTool already covers those panels. Forcing those latitude labels onto a spine shows 24 labels, 28 overlapping pairs and +8.9 ms.

### What the fix needs
- glue's `_set_wcs` rebuilds the WCSAxes coordinates (`glue/viewers/image/viewer.py:100-125`), which drops any coordinate setting. So the hide has to be reapplied after every reset, by glue-solar acting on astropy's coordinates after glue runs (per D18).
- glue only sets tick label sizes (`viewer.py:56-71`) and has nothing for per-coordinate visibility.
- Two places could carry it:
  - The callbacks FrameTimeTool already registers after every reset (`tools.py:160-167`, `:183-206`), which reach every Image viewer.
  - An override of `_set_wcs` in `QuicklookImageViewer` (`quicklook.py:636`) that calls glue's first. This covers quicklook panels only.

### Decisions for you
1. **Scope:** wavelength panel only, or every IRIS raster panel? Every panel also hides the spectrogram's longitude labels, which are clipped there today.
2. **Threshold:** I used a 0.05 ratio. Panels that need hiding measured 0.003–0.011; maps measured 0.66 or more. 0.05 hides only for rolls under about 3°.
3. **Safety net:** whether to also turn on `exclude_overlapping` for all coordinates (0.15 ms per draw) for narrower or tiled panels. With Å it changes nothing at quicklook size.

### Smaller things seen along the way
- **Å labels:** with the Å emulation, wavelength ticks read "2795" with no unit, and the x label is just "Wavelength".
- **Exposure label:** on 4000255147 λ–time, the two-line exposure label is 266 px tall against 262 px axes. It touches the "1500" tick label by about 3 px.

Everything is in `/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/wrapper/ticks/`:
- `ticks_probe.py` (options and the `AA=1` / `STACK=1` / `PANEL=` switches)
- `sweep.sh`, `extras.sh`, `summary.py`, `overlapcost.py`, `axlabel.py`
- `out/sweep_AA{0,1}_*.jsonl`, `out/extra_*.jsonl`, `out/panel_*.jsonl`
- `out/*.png` (one per option; same-named files hold the last run, mostly the Å one)