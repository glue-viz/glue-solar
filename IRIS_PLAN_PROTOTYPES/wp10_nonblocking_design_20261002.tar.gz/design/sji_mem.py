import sys, resource, gc
import numpy as np
sys.argv = sys.argv[:3]
src = open(sys.argv[0].replace("sji_mem.py", "sji_once.py")).read().split("path = sys.argv[1]")[0]
exec(src)
from irispy.io import read_files; import irispy.io.sji, sunpy.map, ndcube
from glue.core.data import Data
gc.collect()
base = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 2**20
path, which = sys.argv[1], sys.argv[2]
data = (iris.image_data if which == "main" else image_data_once)(path)
peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 2**20
print(which, "post-import peak MB", round(base), "peak after read", round(peak), "increase", round(peak - base), "data MB", round(data.size * 2 / 2**20))
