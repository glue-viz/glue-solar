import glob, time
import numpy as np
from astropy.io import fits
D = "/Users/nabil/DATA/IRIS/"
for pat in ["*3824262996_raster/*r00000.fits", "*4000255147_raster/*r00000.fits", "*3602506433_raster/*r00000.fits"]:
    [p] = glob.glob(D + pat)
    with fits.open(p, do_not_scale_image_data=True) as h:
        print(p.split("/")[-1], [(h[0].header[f"TDESC{i}"], h[i].shape, h[i].header["BITPIX"]) for i in range(1, h[0].header["NWIN"] + 1)])
print(len(glob.glob(D + "*3602506433_raster/*.fits")))
