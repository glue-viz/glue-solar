"""
The proposed tests, run against the prototype: generated files only, gated on counted reads, never sleeps.
"""

import gzip
import shutil
import threading

import numpy as np
import pytest
from qtpy.QtCore import QMetaObject, Qt
from qtpy.QtWidgets import QDialog

from glue_solar.conftest import IsolatedQSettings, _header, _write_image, _write_raster, startobs
from glue_solar.sources.loaders import iris

import proto

D, T, O = "20240101", "000000", "1234567890"
STEM = f"iris_l2_{D}_{T}_{O}"


@pytest.fixture(autouse=True)
def _prototype(tmp_path, monkeypatch):
    monkeypatch.setattr(IsolatedQSettings, "directory", str(tmp_path))
    monkeypatch.setattr(iris, "QSettings", IsolatedQSettings)
    monkeypatch.setattr(iris, "image_data", proto.image_data)
    monkeypatch.setattr(iris, "_raster_windows_data", proto._raster_windows_data)


def observation(folder, scans):
    """A slit-jaw file and ``scans`` raster files of one observation."""
    folder.mkdir()
    _write_image(folder / f"{STEM}_SJI_1400_t000.fits",
                 _header("SJI", O, startobs(D, T), TDESC1="SJI_1400", TWAVE1=1400.0, NWIN=1))
    for scan in range(scans):
        _write_raster(folder / f"{STEM}_raster_t000_r{scan:05d}.fits", O, startobs(D, T))
    return folder


def tick(dialog, *prefixes):
    row = dialog.obs_tree.topLevelItem(0)
    for item in (row.child(i) for i in range(row.childCount())):
        if item.text(0).startswith(prefixes):
            item.setCheckState(0, Qt.Checked)


def counted_reads(monkeypatch, on_read=None):
    """Each raster file read_files reads, with whether it ran on the GUI thread; ``on_read(n)`` after the n-th."""
    from irispy.io import read_files

    reads = []

    def read(files, **kwargs):
        out = read_files(files, **kwargs)
        if "raster" in str(files[0] if isinstance(files, list) else files):
            reads.append(threading.current_thread() is threading.main_thread())
            if on_read is not None:
                on_read(len(reads))
        return out

    monkeypatch.setattr("irispy.io.read_files", read)
    return reads


def load(qtbot, dialog):
    """Press Load selected and wait for the load's result."""
    dialog.ok.click()
    assert not dialog.ok.isEnabled() and dialog.cancel.text() == "Stop"
    qtbot.waitUntil(lambda: dialog.ok.isEnabled() and not proto._RUNNING, timeout=60_000)


def test_reads_run_off_the_gui_thread_with_per_file_progress(qtbot, tmp_path, monkeypatch):
    dialog = proto.QtIRISImporter(observation(tmp_path / "obs", scans=4))
    qtbot.addWidget(dialog)
    tick(dialog, "SJI_1400", "Mg II k")
    dialog.stack.setChecked(True)
    reads = counted_reads(monkeypatch)
    values = []
    dialog.progress.valueChanged.connect(values.append)
    load(qtbot, dialog)
    assert dialog.result() == QDialog.Accepted
    assert reads == [False] * 4  # one read per file, none on the GUI thread
    assert values == [0, 20, 40, 60, 80, 100] or values == [20, 40, 60, 80, 100]
    assert [data.ndim for data in dialog.datasets] == [3, 4]


def test_stop_acts_between_raster_files_and_keeps_earlier_picks(qtbot, tmp_path, monkeypatch):
    dialog = proto.QtIRISImporter(observation(tmp_path / "obs", scans=4))
    qtbot.addWidget(dialog)
    tick(dialog, "SJI_1400", "Mg II k")
    dialog.stack.setChecked(True)

    def stop_after_second(n):
        if n == 2:  # the user presses Stop while file 2 is read; the worker waits until it is pressed
            QMetaObject.invokeMethod(dialog.cancel, "click", Qt.BlockingQueuedConnection)

    reads = counted_reads(monkeypatch, stop_after_second)
    load(qtbot, dialog)
    assert len(reads) == 2  # files 3 and 4 never read
    assert dialog.result() == QDialog.Accepted
    assert [data.label for data in dialog.datasets] == [f"SJI_1400-{O}-2024-01-01T00:00:00"]
    assert [kind for _, kind, _, _ in dialog.loaded] == ["sji"]


def test_closing_the_dialog_drops_the_running_load(qtbot, tmp_path, monkeypatch):
    dialog = proto.QtIRISImporter(observation(tmp_path / "obs", scans=4))
    qtbot.addWidget(dialog)
    tick(dialog, "Mg II k")

    def close_after_first(n):
        if n == 1:
            QMetaObject.invokeMethod(dialog, "reject", Qt.BlockingQueuedConnection)

    reads = counted_reads(monkeypatch, close_after_first)
    dialog.ok.click()
    qtbot.waitUntil(lambda: not proto._RUNNING, timeout=60_000)
    assert len(reads) == 1
    assert dialog.result() == QDialog.Rejected
    assert dialog.datasets == [] and dialog.loaded == []


def test_reader_failure_stays_in_dialog(qtbot, tmp_path):
    folder = tmp_path / "bad"
    folder.mkdir()
    from astropy.io import fits

    fits.PrimaryHDU(header=_header("SJI", O, startobs(D, T), TDESC1="SJI_1400", TWAVE1=1400)).writeto(
        folder / f"{STEM}_SJI_1400_t000.fits")
    dialog = proto.QtIRISImporter(folder)
    qtbot.addWidget(dialog)
    dialog.obs_tree.topLevelItem(0).setCheckState(0, Qt.Checked)
    load(qtbot, dialog)
    assert dialog.result() == 0
    assert dialog.datasets == []
    assert dialog.progress.format().startswith("Loading SJI_1400 failed:")
    assert dialog.cancel.text() == "Cancel"


def test_gzipped_slit_jaw_file_is_decompressed_once(tmp_path, monkeypatch):
    folder = observation(tmp_path / "obs", scans=0)
    plain = folder / f"{STEM}_SJI_1400_t000.fits"
    gzipped = tmp_path / f"{plain.name}.gz"
    with open(plain, "rb") as source, gzip.open(gzipped, "wb") as target:
        shutil.copyfileobj(source, target)
    expected = proto.image_data(str(plain))
    opened = []
    init = gzip.GzipFile.__init__
    monkeypatch.setattr(gzip.GzipFile, "__init__", lambda self, *a, **k: opened.append(1) or init(self, *a, **k))
    data = proto.image_data(str(gzipped))
    assert len(opened) == 1
    assert data.label == expected.label
    for cid in ("Time", "Exposure time"):
        np.testing.assert_array_equal(data[cid], expected[cid])
    np.testing.assert_array_equal(data[data.main_components[0]], expected[expected.main_components[0]])
    assert sorted(data.meta) == sorted(expected.meta)
