import glob, time, threading
import numpy as np
from astropy.io import fits
D = "/Users/nabil/DATA/IRIS/"
[p] = glob.glob(D + "*3824262996_raster/*r00000.fits")
h = fits.open(p, memmap=True, do_not_scale_image_data=True)
raw = h[8].data  # Mg II k
print(raw.shape, raw.dtype)

def current(raw):
    counts = np.zeros(65536, np.int64)
    for plane in range(raw.shape[0]):
        values = np.asarray(raw[plane])
        counts += np.bincount(values.ravel().astype(np.int32) + 32768, minlength=65536)
    return counts

def u16(raw):
    counts = np.zeros(65536, np.int64)
    for plane in range(raw.shape[0]):
        counts += np.bincount(np.asarray(raw[plane]).ravel().view(np.uint16), minlength=65536)
    return np.roll(counts, 32768)

for f in (current, current):
    t = time.perf_counter(); c = f(raw); print(f.__name__, round(time.perf_counter() - t, 3))
pass

# does the per-plane loop let another thread run? measure the longest wait of a 5 ms ticker thread
gaps = []
def ticker(stop):
    last = time.perf_counter()
    while not stop.is_set():
        time.sleep(0.005); now = time.perf_counter(); gaps.append(now - last); last = now
stop = threading.Event(); th = threading.Thread(target=ticker, args=(stop,)); th.start()
time.sleep(0.05); current(raw); stop.set(); th.join()
print("ticker max gap while counting on main thread", round(max(gaps), 4))
