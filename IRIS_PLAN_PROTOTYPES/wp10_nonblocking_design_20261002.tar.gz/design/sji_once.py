"""Read a gzipped SJI once (decompress into memory, hand irispy the bytes) and compare with main's image_data."""
import glob, gzip, io, sys, time, resource
import numpy as np
from astropy.io import fits
from glue_solar.sources.loaders import iris
from glue_solar.sources.loaders.iris import _image_cube_data, _raw_scaling
from glue_solar.sources.loaders.lazy import allow_open_files

def image_data_once(path):
    from irispy.io.sji import read_sji_lvl2
    with open(path, "rb") as file:
        gzipped = file.read(2) == b"\x1f\x8b"
    if gzipped:
        with gzip.open(path) as file:
            content = file.read()  # the one decompression; astropy and irispy then read from memory
    source = (lambda: io.BytesIO(content)) if gzipped else (lambda: path)
    with fits.open(source(), memmap=True, do_not_scale_image_data=True) as hdulist:
        scaling = _raw_scaling(hdulist[0].header)
        raw = hdulist[0].data if scaling else None
    if scaling:
        allow_open_files()
    return _image_cube_data(read_sji_lvl2(source(), memmap=bool(scaling), uncertainty=False), path, raw, scaling)

path = sys.argv[1]
which = sys.argv[2]
from irispy.io import read_files  # imports paid outside the timing
import irispy.io.sji
gunzips = []
orig = gzip.GzipFile.read
t = time.perf_counter()
data = (iris.image_data if which == "main" else image_data_once)(path)
dt = time.perf_counter() - t
print(which, "seconds", round(dt, 3), "maxrss MB", resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 2**20)
comp = data.get_component(data.main_components[0])
raw = comp._source.raw
print("raw", raw.dtype, raw.shape, type(raw).__name__, raw.flags.writeable, "owns", raw.base is None)
np.save(f"/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/nonblocking/design/out_{which}.npy",
        np.array([data.label, str(sorted(data.meta.keys())), str([c.label for c in data.components]),
                  repr(np.asarray(raw[::7, ::97, ::89]).tolist()),
                  repr(data.coords.pixel_to_world_values(np.arange(0, 1000, 77.), np.arange(0, 1000, 77.), np.arange(13.))),
                  repr(data["Time"][:, 0, 0].tolist()), repr(data["Exposure time"][:, 0, 0].tolist()),
                  repr({k: np.asarray(data.meta[k]).tolist() for k in ("pztx", "xcenix")}),
                  repr(data[data.main_components[0], 5][::50, ::50].tolist())]))
