"""
Measure GUI gaps of the IRIS browser on main and on the prototype, through browse_iris as the menu runs it.

usage: run.py CASE MODE [--quicklook] [--count] [--incremental] [--stop PERCENT] [--warm]
  CASE: mgk (3824262996 Mg II k), all255 (4000255147 SJI 1400 + every window), stack (3602506433 Mg II k stacked),
        stackall (3602506433 every window stacked), stop (4000255147 SJI 1400, then the 3602506433 Mg II k stack)
  MODE: main | worker
Prints one JSON line.
"""

import argparse
import json
import sys
import time

DATA = "/Users/nabil/DATA/IRIS"
OBS = {"mgk": "3824262996", "all255": "4000255147", "stack": "3602506433", "stackall": "3602506433"}

parser = argparse.ArgumentParser()
parser.add_argument("case")
parser.add_argument("mode")
parser.add_argument("--quicklook", action="store_true")
parser.add_argument("--count", action="store_true")
parser.add_argument("--incremental", action="store_true")
parser.add_argument("--stop", type=float)
parser.add_argument("--warm", action="store_true", help="import irispy, sunpy.map and ndcube before the load")
args = parser.parse_args()
import os
if os.environ.get('SWITCH'):
    sys.setswitchinterval(float(os.environ['SWITCH']))

from glue.main import load_plugins  # noqa: E402

load_plugins(require_qt_plugins=True)
from glue_qt.app.application import GlueApplication  # noqa: E402
from glue_qt.utils import process_events  # noqa: E402
from qtpy import QtCore, QtWidgets  # noqa: E402
from qtpy.QtCore import Qt  # noqa: E402

import glue_solar  # noqa: E402
import glue_solar.quicklook as ql  # noqa: E402
import glue_solar.sources.iris as sources  # noqa: E402
from glue_solar.sources.loaders import iris  # noqa: E402

assert glue_solar.__file__.startswith("/Users/nabil/Git/glue-solar-accept/"), glue_solar.__file__

if args.warm:
    import irispy.io  # noqa: F401
    import irispy.io.sji  # noqa: F401
    import ndcube  # noqa: F401
    import sunpy.map  # noqa: F401

marks = {}
reads = []  # (time, file) of each raster read_files call, to see where a stop acts

if args.mode == "worker":
    import proto

    proto.install()
    Base = proto.QtIRISImporter
    if args.count:
        Base.shown = staticmethod(proto.quicklook_shown)
else:
    Base = iris.QtIRISImporter

if args.stop is not None:  # count raster reads; this imports irispy before the load
    import irispy.io as _irispy_io  # read_files is imported inside the loaders at each read

    _read_files = _irispy_io.read_files

    def counted_read_files(files, **kwargs):
        out = _read_files(files, **kwargs)
        reads.append((time.perf_counter(), len(files) if isinstance(files, list) else 1))
        return out

    _irispy_io.read_files = counted_read_files

import threading  # noqa: E402

from glue_solar.sources.loaders.lazy import RawComponent  # noqa: E402

phases = []  # (name, start, seconds) on the GUI thread
_sample = RawComponent._sample


def timed_sample(self):
    fresh = self._counts is None
    t = time.perf_counter()
    out = _sample(self)
    if fresh and threading.current_thread() is threading.main_thread():
        phases.append(("limits on GUI", t, time.perf_counter() - t))
    return out


RawComponent._sample = timed_sample


def timed(name, func):
    def wrapper(*a, **k):
        t = time.perf_counter()
        out = func(*a, **k)
        phases.append((name, t, time.perf_counter() - t))
        return out
    return wrapper


ql._image = timed("viewer", ql._image)
ql._profile = timed("profile", ql._profile)
ql.quicklook = timed("quicklook", ql.quicklook)
sources.quicklook = ql.quicklook
sources.keep_hpc_linked = timed("keep_hpc_linked", sources.keep_hpc_linked)

if args.incremental:  # a turn of the event loop, without user input, before and after each quicklook viewer
    from qtpy.QtCore import QEventLoop

    def turn():
        QtWidgets.QApplication.processEvents(QEventLoop.ExcludeUserInputEvents)

    image, profile = ql._image, ql._profile

    def _image(*a, **k):
        turn()
        viewer = image(*a, **k)
        turn()
        return viewer

    def _profile(*a, **k):
        turn()
        out = profile(*a, **k)
        turn()
        return out

    ql._image, ql._profile = _image, _profile


class Importer(Base):
    def __init__(self, directory=None, parent=None):
        super().__init__(directory, parent)
        Importer.current = self
        self.accepted.connect(lambda: marks.setdefault("accepted", time.perf_counter()))
        self.finished.connect(lambda _r: marks.setdefault("closed", time.perf_counter()))
        QtCore.QTimer.singleShot(300, self._go)

    def _go(self):
        obsids = ["4000255147", "3602506433"] if args.case == "stop" else [OBS[args.case]]
        tree = self.obs_tree
        for row in (tree.topLevelItem(i) for i in range(tree.topLevelItemCount())):
            if row.text(1) not in obsids:
                continue
            for item in (row.child(j) for j in range(row.childCount())):
                text = item.text(0)
                if text.startswith("Extract"):
                    continue
                want = {
                    "mgk": text.startswith("Mg II k"),
                    "all255": True,
                    "stack": text.startswith("Mg II k"),
                    "stackall": "raster file" in text,
                    "stop": text.startswith("Mg II k") if row.text(1) == "3602506433" else text == "SJI_1400",
                }[args.case]
                if want:
                    item.setCheckState(0, Qt.Checked)
        self.stack.setChecked(args.case in ("stack", "stackall", "stop"))
        self.quicklook.setChecked(args.quicklook)
        marks["picks"] = [p[1:] for p in self.selected()]
        if args.stop is not None:
            self.progress.valueChanged.connect(self._maybe_stop)
        marks["irispy_imported"] = "irispy.io" in sys.modules
        marks["ok"] = time.perf_counter()
        self.ok.click()

    def _maybe_stop(self, value):
        if value >= args.stop and "stop" not in marks and self.cancel.text() == "Stop":
            marks["stop"] = time.perf_counter()
            marks["stop_value"] = value
            self.cancel.click()


sources.QtIRISImporter = Importer
QtWidgets.QFileDialog.getExistingDirectory = staticmethod(lambda *a, **k: DATA)

app = GlueApplication()
app.show()
process_events()

ticks = []
timer = QtCore.QTimer()
timer.setTimerType(Qt.PreciseTimer)
timer.setInterval(5)
timer.timeout.connect(lambda: ticks.append(time.perf_counter()))
timer.start()


def browse():
    sources.browse_iris(app.session, app.data_collection)
    marks["returned"] = time.perf_counter()
    QtCore.QTimer.singleShot(2000, QtWidgets.QApplication.instance().quit)


QtCore.QTimer.singleShot(100, browse)
QtWidgets.QApplication.instance().exec_()
timer.stop()


def gaps(start, end):
    """(gap, start) of each interval between ticks that ends in (start, end]."""
    return [(b - a, a) for a, b in zip(ticks, ticks[1:]) if start < b <= end]


ok, acc = marks["ok"], marks.get("accepted", marks.get("closed"))
load = gaps(ok, acc) or [(0, ok)]
post = gaps(acc, marks["returned"] + 2.0)
out = {
    "case": args.case, "mode": args.mode, "quicklook": args.quicklook, "count": args.count,
    "incremental": args.incremental, "warm": args.warm,
    "load_s": round(acc - ok, 3),
    "load_max_gap": round(max(g for g, _ in load), 3),
    "load_gaps_over_0.2": sum(g > 0.2 for g, _ in load),
    "after_max_gap": round(max((g for g, _ in post), default=0), 3),
    "after_gaps_over_0.2": sum(g > 0.2 for g, _ in post),
    "after_top": sorted([(round(g, 3), round(a - acc, 3)) for g, a in post], reverse=True)[:6],
    "accept_to_return": round(marks["returned"] - acc, 3),
    "datasets": len(app.data_collection), "irispy_imported_before": marks["irispy_imported"],
    "labels": sorted(d.label for d in app.data_collection)[:3],
}
out["phases"] = [(name, round(t - acc, 3), round(dt, 3)) for name, t, dt in phases]
if "stop" in marks:
    stop = marks["stop"]
    out["stop_at_percent"] = marks["stop_value"]
    out["stop_to_result"] = round(acc - stop, 3)
    out["reads_after_stop"] = sum(t > stop for t, _ in reads)
    out["reads_before_stop"] = sum(t <= stop for t, _ in reads)
    out["kept"] = sorted(d.label for d in app.data_collection)
print(json.dumps(out))
sys.stdout.flush()

# WHERE: with where.py, name what overlaps each load gap over 0.1 s
if "events" in globals():
    for g, a in sorted(load, reverse=True)[:6]:
        if g < 0.08:
            break
        b = a + g
        over = sorted({(n, th) for n, t0, t1, th in events if t0 < b and t1 > a})
        print(f"gap {g:.3f} at {a - ok:.3f}:", over)
    gcs = [(round(t1 - t0, 3), th) for n, t0, t1, th in events if n == "gc gen2" and ok <= t0 <= acc]
    print("gen2 collections during the load:", gcs)
