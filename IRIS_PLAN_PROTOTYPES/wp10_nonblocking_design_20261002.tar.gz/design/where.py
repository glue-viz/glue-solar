"""Run run.py's stackall/stack worker case with worker phases and GC logged, and say what overlaps each long load gap."""
import gc, sys, threading, time, runpy
events = []  # (name, start, end, thread)
gc_start = {}
def gc_cb(phase, info):
    if info["generation"] != 2:
        return
    if phase == "start":
        gc_start[threading.get_ident()] = time.perf_counter()
    else:
        t0 = gc_start.pop(threading.get_ident(), None)
        if t0:
            events.append(("gc gen2", t0, time.perf_counter(), threading.current_thread().name))
gc.callbacks.append(gc_cb)
sys.path.insert(0, "/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/nonblocking/design")
import proto
from glue_solar.sources.loaders import iris as _iris
def span(name, func):
    def wrapper(*a, **k):
        t = time.perf_counter()
        try:
            return func(*a, **k)
        finally:
            events.append((name, t, time.perf_counter(), threading.current_thread().name))
    return wrapper
proto._raster_collection_data = span("build Data", proto._raster_collection_data)
proto._window_scaling = span("header", proto._window_scaling)
import irispy.io
irispy.io.read_files = span("read_files", irispy.io.read_files)
import builtins
sys.argv = ["run.py"] + sys.argv[1:]
ns = {}
try:
    runpy.run_path("/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/nonblocking/design/run.py", run_name="__main__", init_globals={"events": events})
except SystemExit:
    pass
