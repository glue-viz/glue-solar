"""Medians per case and variant from matrix.jsonl."""
import json, statistics as st, sys
from collections import defaultdict
rows = defaultdict(list)
for line in open(sys.argv[1] if len(sys.argv) > 1 else "matrix.jsonl"):
    if line.strip():
        d = json.loads(line)
        rows[(d["case"], d["mode"], d["count"], d["incremental"])].append(d)
med = lambda xs: round(st.median(xs), 3)
print("case      variant                  n  load_s  load_gap  after_gap(max of runs)  after>0.2  limits_on_GUI  quicklook_s")
for (case, mode, count, inc), ds in rows.items():
    variant = mode + (" +count" if count else "") + (" +turns" if inc else "")
    lim = [sum(p[2] for p in d["phases"] if p[0] == "limits on GUI") for d in ds]
    qls = [sum(p[2] for p in d["phases"] if p[0] == "quicklook") for d in ds]
    print(f"{case:9} {variant:24} {len(ds)}  {med([d['load_s'] for d in ds]):6}  {med([d['load_max_gap'] for d in ds]):8}"
          f"  {med([d['after_max_gap'] for d in ds]):6} ({max(d['after_max_gap'] for d in ds):5})          "
          f"{med([d['after_gaps_over_0.2'] for d in ds]):4}       {med(lim):6}        {med(qls)}")
    if case == "stop":
        for d in ds:
            print("   stop at", d["stop_at_percent"], "% -> result", d["stop_to_result"], "s; reads before/after", d["reads_before_stop"], d["reads_after_stop"], "kept", d["kept"])
