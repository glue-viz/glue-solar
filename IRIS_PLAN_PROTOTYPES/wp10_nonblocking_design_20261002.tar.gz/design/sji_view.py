import sys, resource, gc, time, gzip, io
import numpy as np
from astropy.io import fits
from glue_solar.sources.loaders import iris
from glue_solar.sources.loaders.iris import _image_cube_data, _raw_scaling
from glue_solar.sources.loaders.lazy import allow_open_files

def image_data_view(path):
    from irispy.io.sji import read_sji_lvl2
    with open(path, "rb") as file:
        gzipped = file.read(2) == b"\x1f\x8b"
    if not gzipped:
        return iris.image_data(path)
    with gzip.open(path) as file:
        content = file.read()  # the one decompression
    with fits.open(io.BytesIO(content), do_not_scale_image_data=True) as hdulist:
        hdu = hdulist[0]
        scaling = _raw_scaling(hdu.header)
        # the raw int16 where they lie in the decompressed bytes, not a copy
        raw = np.ndarray(hdu.shape, f">i{abs(hdu.header['BITPIX']) // 8}", content, hdu.fileinfo()["datLoc"]) if scaling else None
    return _image_cube_data(read_sji_lvl2(io.BytesIO(content), memmap=bool(scaling), uncertainty=False), path, raw, scaling)

from irispy.io import read_files; import irispy.io.sji, sunpy.map, ndcube
gc.collect()
base = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 2**20
t = time.perf_counter()
data = image_data_view(sys.argv[1])
dt = time.perf_counter() - t
peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 2**20
print("view seconds", round(dt, 3), "increase MB", round(peak - base))
ref = iris.image_data(sys.argv[1])
a, b = data.get_component(data.main_components[0])._source.raw, ref.get_component(ref.main_components[0])._source.raw
print("raw equal", np.array_equal(a, b), "writeable", a.flags.writeable, "label", data.label == ref.label,
      "values equal", np.array_equal(data[data.main_components[0], 7], ref[ref.main_components[0], 7], equal_nan=True),
      "time", np.array_equal(data["Time"], ref["Time"]), "meta keys", sorted(data.meta) == sorted(ref.meta))
