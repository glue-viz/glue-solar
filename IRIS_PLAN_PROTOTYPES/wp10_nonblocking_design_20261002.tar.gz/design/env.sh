# source me: run the env python outside ~/Git with an isolated HOME, offscreen; bytecode kept in scratch
export HOME="$(mktemp -d)" QT_QPA_PLATFORM=offscreen MPLBACKEND=agg PYTHONPATH=/Users/nabil/Git/glue-solar-accept
export PYTHONPYCACHEPREFIX=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/nonblocking/design/pycache
PY=/Users/nabil/mamba/envs/iris-plan/bin/python
export MPLCONFIGDIR=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/nonblocking/design/mplcfg
