#!/bin/bash
# 1 warm + 5 measured runs per case and variant; one JSON line per run in matrix.jsonl
D=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/nonblocking/design
source $D/env.sh
cd /private/tmp
OUT=$D/matrix.jsonl
: > $OUT
for case in mgk all255 stack stackall; do
  for variant in "main --quicklook" "worker --quicklook" "worker --quicklook --count" "worker --quicklook --count --incremental"; do
    for i in 0 1 2 3 4 5; do
      line=$($PY $D/run.py $case $variant 2>/dev/null | grep '^{')
      [ $i -gt 0 ] && echo "$line" >> $OUT
    done
  done
done
for i in 0 1 2 3 4 5; do
  line=$($PY $D/run.py stop worker --stop 40 2>/dev/null | grep '^{')
  [ $i -gt 0 ] && echo "$line" >> $OUT
done
echo done >> $D/matrix.done
