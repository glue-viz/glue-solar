import sys, tarfile, tempfile, time, shutil, os
src = sys.argv[1]
with tempfile.TemporaryDirectory(dir=os.path.dirname(__file__)) as out:
    t = time.perf_counter()
    with tarfile.open(src, "r:*") as tar:
        tar.extractall(out, filter="data")
    dt = time.perf_counter() - t
    size = sum(os.path.getsize(os.path.join(r, f)) for r, _, fs in os.walk(out) for f in fs)
print(os.path.basename(src)[33:], f"{os.path.getsize(src)/1e6:.0f} MB -> {size/1e6:.0f} MB in {dt:.2f} s")
