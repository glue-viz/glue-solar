"""
Prototype of wp10-nonblocking-load on origin/main a4f14c2: the proposed loaders/iris.py changes, applied as
overrides so the harness can measure them. Not the PR; scratch only.
"""

import gzip
import io
import threading

import numpy as np
from astropy.io import fits
from glue_qt.utils.threading import Worker
from qtpy.QtCore import Signal

from glue_solar.sources.loaders import iris
from glue_solar.sources.loaders.iris import (
    _image_cube_data, _raster_collection_data, _raw_scaling, _window_scaling, load_entry,
)
from glue_solar.sources.loaders.lazy import RawComponent, allow_open_files

# ---------------------------------------------------------------- one decompression of a .fits.gz SJI


def image_data(path):
    """main's image_data, with a gzipped file decompressed once and read from memory by astropy and irispy."""
    from irispy.io.sji import read_sji_lvl2

    with open(path, "rb") as file:
        gzipped = file.read(2) == b"\x1f\x8b"
    if not gzipped:
        return MAIN_IMAGE_DATA(path)
    with gzip.open(path) as file:
        content = file.read()  # astropy and irispy would each decompress it again, about four times in all
    with fits.open(io.BytesIO(content), do_not_scale_image_data=True) as hdulist:
        hdu = hdulist[0]
        scaling = _raw_scaling(hdu.header)
        # the raw int16 where they lie in the decompressed bytes, rather than a copy
        raw = np.ndarray(hdu.shape, ">i2", content, hdu.fileinfo()["datLoc"]) if scaling else None
    return _image_cube_data(read_sji_lvl2(io.BytesIO(content), memmap=bool(scaling), uncertainty=False), path, raw,
                            scaling)


MAIN_IMAGE_DATA = iris.image_data

# ---------------------------------------------------------------- one read per raster file, a stop between files


def _raster_windows_data(files, windows=None, stack=False, stop=None, step=None):
    """
    main's _raster_windows_data, reading one file at a time: None once ``stop`` (a threading.Event) is set
    between files, and ``step()`` after each file.
    """
    scaling = _window_scaling(files[0])
    if any(_window_scaling(path) != scaling for path in files[1:]):
        scaling = None
    if scaling:
        allow_open_files()
    from irispy.io import read_files

    scans = {}
    for path in files:
        if stop is not None and stop.is_set():
            return None
        for window, sequence in read_files([path], spectral_windows=windows, memmap=bool(scaling),
                                           uncertainty=False).items():
            scans.setdefault(window, []).extend(sequence)
        if step is not None:
            step()
    return {window: _raster_collection_data({window: cubes}, stack=stack, scaling=scaling)
            for window, cubes in scans.items()}


# ---------------------------------------------------------------- the worker


def _load(load, observations, picks, stack, stop, report, shown=None):
    """
    Runs on the worker: read the ticked entries until ``stop`` is set.

    Returns ``(load, loaded, error)``: the entries read in full, as ``QtIRISImporter.loaded`` holds them, and the
    text of a reader error (nothing is then loaded).
    """
    windows = {}
    for i, kind, name in picks:
        if kind == "raster":
            windows.setdefault(i, []).append(name)
    total = sum(len(observations[i].rasters) for i in windows) + sum(kind != "raster" for _, kind, _ in picks)
    done = 0

    def step():
        nonlocal done
        done += 1
        report(load, int(100 * done / total))

    loaded, rasters = [], {}
    for i, kind, name in picks:
        if stop.is_set():
            break
        obs = observations[i]
        try:
            if kind == "raster":
                if i not in rasters:
                    rasters[i] = _raster_windows_data(obs.rasters, windows[i], stack=stack, stop=stop, step=step)
                if rasters[i] is None:  # stopped between its files
                    break
                datasets = rasters[i][name]
            else:
                datasets = load_entry(obs, kind, name)
                step()
        except Exception as error:  # noqa: BLE001
            return load, [], f"Loading {name} failed: {error}"
        loaded.append((obs, kind, name, datasets))
    if shown is not None:  # variant: colour-limit counts of what the first viewers show, before the GUI asks
        for data in shown(loaded):
            if stop.is_set():
                break
            for cid in data.main_components:
                component = data.get_component(cid)
                if isinstance(component, RawComponent):
                    component._sample()
    return load, loaded, None


_RUNNING = set()  # workers still running: a QThread destroyed while it runs takes the process down


class QtIRISImporter(iris.QtIRISImporter):
    """The dialog with finalize on glue-qt's Worker."""

    progressed = Signal(int, int)  # (load, percent), emitted on the worker, queued to the GUI thread
    shown = None  # variant hook

    def __init__(self, directory=None, parent=None):
        self._load, self._stop = 0, threading.Event()
        super().__init__(directory, parent)
        self.cancel.clicked.disconnect()
        self.cancel.clicked.connect(self._cancel)
        self.progressed.connect(self._progressed)

    def finalize(self):
        picks = self.selected()
        if any(kind == "archive" for _, kind, _ in picks):
            return super().finalize()  # unchanged in the prototype
        self.progress.setFormat("%p%")
        self.progress.setValue(0)
        self._load += 1
        self._stop = threading.Event()
        self._busy(True)
        worker = Worker(_load, self._load, self.observations, picks, self.stack.isChecked(), self._stop,
                        self.progressed.emit, self.shown)
        worker.result.connect(self._loaded)
        _RUNNING.add(worker)
        worker.finished.connect(lambda: _RUNNING.discard(worker))
        worker.start()

    def _busy(self, busy):
        for widget in (self.ok, self.change, self.recursive):
            widget.setEnabled(not busy)
        self.cancel.setText("Stop" if busy else "Cancel")

    def _cancel(self):
        if self.ok.isEnabled():
            self.reject()
        else:
            self._stop.set()  # keeps what is read in full

    def reject(self):
        self._load += 1  # drop the running load
        self._stop.set()
        super().reject()

    def _progressed(self, load, percent):
        if load == self._load:
            self.progress.setValue(percent)

    def _loaded(self, result):
        load, loaded, error = result
        if load != self._load:
            return
        self._busy(False)
        if error:
            self.progress.setFormat(error)
            return
        self.loaded = loaded
        self.datasets = [data for *_, datasets in loaded for data in datasets]
        self.first_image = next((datasets[0] for _, kind, _, datasets in loaded if kind != "raster"), None)
        self.progress.setValue(100)
        self.accept()


def quicklook_shown(loaded):
    """What browse_iris's quicklooks show first: each observation's picked raster and its slit-jaw images."""
    from glue_solar.quicklook import _pick_raster, _pick_sjis, _role

    observations = {}
    for observation, kind, name, datasets in loaded:
        got, windows = observations.get(id(observation), ([], []))
        observations[id(observation)] = (got + datasets, windows + [name] * (kind == "raster"))
    for datasets, windows in observations.values():
        rasters = [data for data in datasets if _role(data) == "raster"]
        if rasters:
            yield _pick_raster(rasters, windows[0] if len(windows) == 1 else None)
        yield from _pick_sjis([data for data in datasets if _role(data) == "sji"])[0]


def install():
    iris.image_data = image_data
    iris._raster_windows_data = _raster_windows_data
