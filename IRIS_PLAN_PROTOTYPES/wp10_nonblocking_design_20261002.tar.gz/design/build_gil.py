"""Which step of building the 3602506433 stacks holds the GIL long: a 5 ms ticker thread's longest wait per step."""
import glob, threading, time
import numpy as np
from glue_solar.sources.loaders import iris, stack_spectrograms as ss
import proto

files = sorted(glob.glob("/Users/nabil/DATA/IRIS/*3602506433_raster/*.fits"))
from irispy.io import read_files
scans = {}
for f in files:
    for w, seq in read_files([f], memmap=True, uncertainty=False).items():
        scans.setdefault(w, []).extend(seq)
scaling = iris._window_scaling(files[0])

ticks = []
stop = threading.Event()
def ticker():
    while not stop.is_set():
        time.sleep(0.005); ticks.append(time.perf_counter())
th = threading.Thread(target=ticker, daemon=True); th.start(); time.sleep(0.05)

spans = []
import gc
_gc = {}
def gc_cb(phase, info):
    if phase == "start":
        _gc["t"] = time.perf_counter()
    elif "t" in _gc:
        spans.append((f"gc gen{info['generation']} ({info['collected']} freed)", _gc.pop("t"), time.perf_counter()))
gc.callbacks.append(gc_cb)
def span(name, func):
    def wrapper(*a, **k):
        t = time.perf_counter()
        try:
            return func(*a, **k)
        finally:
            spans.append((name, t, time.perf_counter()))
    return wrapper
iris.stack_times = span("stack_times", iris.stack_times)
iris.stack_wcs = span("stack_wcs", iris.stack_wcs)
iris._dataset = span("_dataset", iris._dataset)
iris.RawStack = span("RawStack", iris.RawStack)
import glue.core.data as gd
gd.Data.add_component = span("add_component", gd.Data.add_component)
t0 = time.perf_counter()
for w, cubes in scans.items():
    tw = time.perf_counter()
    iris._raster_collection_data({w: cubes}, stack=True, scaling=scaling)
    spans.append((f"window {w}", tw, time.perf_counter()))
stop.set(); th.join()
gaps = [(b - a, a, b) for a, b in zip(ticks, ticks[1:]) if a >= t0]
for g, a, b in sorted(gaps, reverse=True)[:5]:
    inner = [(n, round(e - s, 3)) for n, s, e in spans if s < b and e > a and not n.startswith("window") and (e - s) > 0.005]
    win = [n for n, s, e in spans if s < b and e > a and n.startswith("window")]
    print(f"wait {g:.3f}", win, inner)
tot = {}
for n, s, e in spans:
    if not n.startswith("window"):
        tot[n] = tot.get(n, 0) + e - s
print({k: round(v, 3) for k, v in tot.items()}, "total", round(time.perf_counter() - t0, 3))
