import time, statistics as st
from glue_solar.sources.loaders.scan import scan_directory
ts = []
for i in range(6):
    t = time.perf_counter(); obs = scan_directory("/Users/nabil/DATA/IRIS"); ts.append(time.perf_counter() - t)
print("scan_directory DATA/IRIS:", len(obs), "observations; first", round(ts[0], 3), "median of rest", round(st.median(ts[1:]), 3))
