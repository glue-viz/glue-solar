"""Per-file reads (prototype) against main's one read: values, Time, Exposure time, meta, coordinates."""
import glob, sys
import numpy as np
from glue_solar.sources.loaders import iris
import proto

files = sorted(glob.glob(sys.argv[1]))[: int(sys.argv[2])]
windows = sys.argv[3].split(",")
for stack in (True, False):
    a = iris._raster_windows_data(files, windows, stack)
    b = proto._raster_windows_data(files, windows, stack)
    for w in windows:
        for da, db in zip(a[w], b[w], strict=True):
            assert da.label == db.label and da.shape == db.shape
            cid = da.main_components[0]
            idx = tuple(np.linspace(0, n - 1, 5).astype(int) for n in da.shape)
            grid = np.ix_(*idx)
            same = {
                "values": np.array_equal(da.get_component(cid)[grid], db.get_component(db.main_components[0])[grid], equal_nan=True),
                "Time": np.array_equal(da["Time"], db["Time"]),
                "Exposure": np.array_equal(da["Exposure time"], db["Exposure time"]),
                "meta keys": sorted(da.meta) == sorted(db.meta),
            }
            diff = [k for k in da.meta if not np.array_equal(np.asarray(da.meta[k], dtype=object), np.asarray(db.meta[k], dtype=object))] if same["meta keys"] else None
            pix = [np.linspace(0, n - 1, 7) for n in da.shape[::-1]]
            wa, wb = da.coords.pixel_to_world_values(*pix), db.coords.pixel_to_world_values(*pix)
            same["world"] = all(np.allclose(x, y, rtol=0, atol=1e-9) for x, y in zip(wa, wb))
            obstime = lambda d: getattr(getattr(d.coords, "_wcs", None), "wcs", None)
            print(w, "stack" if stack else da.label[-8:], same, "meta differing:", diff)
            if not stack:
                break  # first scan only; then the last
        if not stack:
            da, db = a[w][-1], b[w][-1]
            ta = getattr(da.coords._wcs, "wcs", None); tb = getattr(db.coords._wcs, "wcs", None)
            print("  last scan DATE-OBS of its WCS:", ta.dateobs if ta is not None else None, "->", tb.dateobs if tb is not None else None,
                  "world equal", all(np.allclose(x, y, rtol=0, atol=1e-9) for x, y in zip(da.coords.pixel_to_world_values(*[np.linspace(0, n - 1, 7) for n in da.shape[::-1]]), db.coords.pixel_to_world_values(*[np.linspace(0, n - 1, 7) for n in da.shape[::-1]]))))
