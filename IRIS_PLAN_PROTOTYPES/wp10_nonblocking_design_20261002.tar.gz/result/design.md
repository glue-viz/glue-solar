## wp10-nonblocking-load design

**Answer.** On main (a4f14c2), the worker design meets the done-when for the load. With the reads in glue-qt's `Worker`, the longest GUI gaps are 0.011 s for 3824262996 Mg II k and 0.076 s for 4000255147 (every window plus SJI 1400). A stop in the 3602506433 stack takes effect 1–20 ms after the click, with at most the one file already being read finishing, and the earlier picks are kept.

What still blocks is opening the quicklook, which is on by default. It freezes the GUI for 1.1–1.7 s, and about half of that is the colour-limit count. The quicklook also meets ≤ 0.2 s if two more changes go in: the count runs on the worker for the datasets the quicklook will show, and the quicklook lets the event loop turn between viewers. Measured that way it peaks at 0.173 s and 0.188 s, so the margin is thin. Whether the done-when covers the quicklook is your call (Decision 1).

I checked the prototype against main's code at a4f14c2 in `/Users/nabil/Git/glue-solar-accept`. Figures are medians of 5 runs after a warm-up, each in a fresh process. Each run goes through `browse_iris` with the app shown offscreen and a 5 ms PreciseTimer measuring the gaps.

### Measurements (seconds)

| Case | Main: one combined gap (load + quicklook) | Worker: load gap | Worker: quicklook gap | Worker + count on worker | Worker + count + event-loop turns |
|---|---|---|---|---|---|
| 3824262996 Mg II k | 1.21 | 0.011 | 1.13 | 0.54 | **0.173** (max 0.181) |
| 4000255147, 9 windows + SJI 1400 `.gz` | 2.39 for the load, then 1.64 | 0.076 | 1.70 | 0.87 | **0.188** (max 0.191) |
| 3602506433 stack, Mg II k | 2.68 | 0.031 | 1.31 | 0.67 | 0.202 (max 0.22) |
| 3602506433 stack, all 7 windows | 3.62 for the load, then 1.16 | 0.165 | 1.16 | 0.58 | 0.172 |

- **Load wall time with the worker:**
  - Mg II k: 0.06 s.
  - 4000255147: 0.67 s, down from 2.5 s, because of the single gunzip below.
  - Stack Mg II k: 2.25 s, up from 1.45 s.
  - All 7 windows: 4.3 s, up from 3.6 s.
  - The stacks are slower because each file gets its own read and the GUI thread shares the GIL with the worker.
  - Counting on the worker adds 0.55–0.9 s to the load and takes the same amount off the quicklook, so the time until the quicklook is up does not change.
- **Stop at 40 %** (SJI 1400 picked first, then the 99-file stack): the result arrives 0.001–0.02 s after the click and at most one file is read after it. The SJI is kept and the stack is dropped.
- **Gzipped SJI read once:** decompressing it once into memory and handing irispy the bytes takes 0.52–0.56 s instead of 2.3–2.4 s. The label, values, Time, Exposure time, meta and coordinates are identical. This also speeds up File→Open of that file, which stays on the GUI thread because glue's dialog is synchronous (D18). Peak memory rises by about 110 MB while it reads (the increase goes from 382 MB to about 495 MB); what stays in memory afterwards is unchanged.
- **One read per raster file:** the result equals main's single read (values, Time, Exposure, meta and world values) for stacked and unstacked loads. The one difference is that each unstacked scan's WCS now carries its own DATE-OBS (scan 11: 21:52:33 becomes 22:00:12), which is what File→Open of that file already gives. World values are unchanged.
- **Also blocking today, outside the gate:**
  - Archive extraction runs on the GUI thread: 0.81 s for 135 MB and 6.26 s for the 914 MB 3602506433 archive.
  - The folder scan takes 0.10 s warm, or 0.78 s the first time in a process. That belongs to `wp8-filter-stop`.

### Design

1. **`image_data`** (in `loaders/iris.py`): a `.fits.gz` file is decompressed once. The raw int16 is taken as a read-only view into the decompressed bytes rather than copied, and irispy reads the same bytes through `irispy.io.sji.read_sji_lvl2`. Plain `.fits` files are read as today.
   ```python
   with gzip.open(path) as file:
       content = file.read()
   with fits.open(io.BytesIO(content), do_not_scale_image_data=True) as hdulist:
       hdu = hdulist[0]; scaling = _raw_scaling(hdu.header)
       raw = np.ndarray(hdu.shape, ">i2", content, hdu.fileinfo()["datLoc"]) if scaling else None
   return _image_cube_data(read_sji_lvl2(io.BytesIO(content), memmap=bool(scaling), uncertainty=False), path, raw, scaling)
   ```
2. **`_raster_windows_data(files, windows, stack, stop=None, step=None)`**: one `read_files([path])` per file, merged into lists of cubes per window. It returns None once `stop` is set between files and calls `step()` after each file. `raster_data` and File→Open use the same code path.
3. **`_load(load, observations, picks, stack, stop, report)`**: a module function that runs on the worker. It is the current `finalize` loop, minus `processEvents`. It returns `(load, loaded, error)`, where `loaded` holds only the picks read in full and `error` is the existing "Loading X failed" text. Progress goes up one step per raster file and per SJI or AIA pick. Data are built on the worker with no hub; `browse_iris` already adds them on the GUI thread after `exec()`, so `browse_iris` does not change.
4. **`QtIRISImporter`**:
   - It gets `progressed = Signal(int, int)` carrying the load id and the percentage.
   - `finalize` starts the `Worker`, connecting `result` to the bound method `_loaded` and `error` to the same failure text.
   - The worker is kept in a module set `_RUNNING` until `finished`, as glue-qt does with its own workers. Nothing calls `wait()` on the GUI thread.
   - While a load runs, `ok`, `change` and `recursive` are disabled and Cancel reads "Stop":
     - **Stop** sets the event, so the dialog accepts what was read in full.
     - **`reject`** (Esc or closing the dialog) bumps the load id and sets the event, so the result is dropped.
     - `_loaded` and `_progressed` ignore results from a stale load id. `wp8-filter-stop` reuses this lifecycle.
5. **Optional, only if the quicklook is gated (Decision 1):**
   - (a) After reading, the worker computes `RawComponent._sample()` for what the first viewers will show: each observation's `_pick_raster` and `_pick_sjis`, or `first_image` when the quicklook box is unticked. `browse_iris` passes this in as a hook, and the grouping it already does moves into a helper that both use. About 25 lines.
   - (b) In `quicklook`, one turn of the event loop (`processEvents(ExcludeUserInputEvents)`) after each viewer. About 5 lines.

### Thread safety

- **glue:** glue's hub has no locks, so Data are built without a hub on the worker and all adds, links and viewers happen on the GUI thread. Results come back through bound methods of the dialog, which Qt queues to the GUI thread under PyQt5 and PySide alike.
- **`WCS_LOCK`:** the worker does not take it, because it only builds new WCSes that no viewer holds yet. The earlier stress test (693 WCS builds on the worker against about 1,700 conversions on the GUI thread) gave 0 crashes. Taking the lock for a read would make GUI draws wait for up to 0.5 s.
- **Memory maps and open files:** memory maps work from any thread, and `allow_open_files` is process-wide and safe to call again.
- **GIL:**
  - Long Python-heavy stretches on the worker still hold the GIL in pieces: `stack_times` holds it for 40–70 ms at a time and a generation-2 garbage collection takes about 80 ms. With all 7 stack windows this gives gaps of 0.12–0.24 s.
  - `sys.setswitchinterval(0.001)` brings that case down to about 0.08 s. It is process-wide, so it is not proposed.
- **Warnings:** `warnings.catch_warnings` is not thread-safe on Python 3.13. At worst a warning filter gets mixed up between threads.

### Tests

The first five are prototyped in `test_proto.py`; they use generated files only (via conftest's `_write_raster` and `_write_image`) and wait on counted reads, never on sleeps. They passed 20 of 20 runs at about 2.6 s each.
1. Reads run off the GUI thread, one per file, with progress 20/40/60/80/100.
2. Stop between raster files: the Stop button is clicked through a `BlockingQueuedConnection` during the second file. Exactly 2 reads happen, the SJI is kept and the stack is dropped.
3. Closing the dialog during a load: 1 read happens, the result is Rejected and nothing is loaded.
4. A reader failure stays in the dialog and the button goes back to Cancel.
5. A gzipped SJI opens `GzipFile` once and gives Data equal to the uncompressed copy.

Changes to existing tests:
- The 10 `finalize()` calls and two `exec` monkeypatches switch to a `load(qtbot, dialog)` helper that waits until `ok` is enabled again and no worker is running.
- `test_ticked_raster_windows_of_an_observation_are_read_at_once` should expect one read per file covering all ticked windows.

If Decision 1 gates the quicklook:
- The shown window's counts are computed on the worker and the other windows' are not.
- A 0 ms repeating timer fires at least once per viewer while `quicklook` runs.

### Manual probe on ~/DATA

`run.py CASE worker [--quicklook --count --incremental] [--stop 40]` through `browse_iris`, with CASE one of mgk, all255, stack, stackall or stop. `matrix.sh` runs the whole matrix and `aggregate.py` reduces it.

### Risks

- The quicklook margin is thin: at most 0.191 s against the 0.2 s limit, and the stack reaches 0.22 s. While the event loop turns between viewers, user input waits for up to about 1 s.
- Gaps from GIL contention during long stack builds, as above.
- One read per file adds about 0.5 s of worker time per 99 files.
- The extra ~110 MB peak memory during a gzipped SJI read.
- If glue exits during a load (at most one file), the running thread can abort the process. glue-qt's own fit worker has the same exposure, and the modal dialog makes this unlikely.
- `read_sji_lvl2` is not in `irispy.io.__all__`.
- The existing error at exit after a quicklook (`Coordinator.unregister`: `RuntimeError: wrapped C/C++ object of type QTimer has been deleted`) still appears.

### Decisions for the user

1. **Scope of the done-when.**
   - (a) Restate it to the load, from "Load selected" until the dialog closes with the Data added. This is met now (0.011 / 0.076 s), and the quicklook would stay at a 1.1–1.7 s freeze.
   - (b) Keep it as written, including the default quicklook. That needs the worker count plus the event-loop turns, measured at 0.173 / 0.188 s.
   - **Recommendation: (b)**, because it is what the done-when asks for and it takes about 30 more lines. Choose (a) for the smallest PR.
2. **Stop semantics.** Stop closes the dialog with the picks read in full, while Esc or closing drops the load. With nothing read yet, Stop acts like Cancel. Recommended as prototyped.
3. **Archive extraction on the worker too,** with a stop between archives. This removes the 6.3 s freeze on the 914 MB archive. Recommended; about 10 lines.
4. **The single gunzip in this PR**, rather than as its own item. Recommended.
5. **One read per file everywhere, including `raster_data`**, which gives each unstacked scan its own DATE-OBS as File→Open already does, rather than only in the browser. Recommended.

My first few runs, before I set `PYTHONPYCACHEPREFIX`, rewrote ignored `.pyc` files in `/Users/nabil/Git/glue-solar-accept/glue_solar/**/__pycache__`, replacing stale ones from the old checkout. Nothing that git tracks changed.

All scripts and results are in `/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/nonblocking/design/`. The earlier baseline and threading-map scratch folders no longer exist.
- `proto.py` – the prototype of the proposed code
- `run.py` – the browser gap harness
- `matrix.sh`, `matrix.jsonl`, `aggregate.py`, `summary.txt` – the measurement runs and their medians
- `test_proto.py` – the prototyped tests
- `sji_once.py`, `sji_view.py`, `sji_mem.py` – the gzipped SJI read and its memory
- `perfile_eq.py` – per-file read equality
- `build_gil.py`, `where.py` – where the long gaps come from
- `extract_time.py`, `scan_time.py`, `sample_speed.py` – extraction, scan and count timings
- `env.sh` – the run environment