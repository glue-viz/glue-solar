import os, sys, types, time
sys.modules["glue_solar.version"] = types.SimpleNamespace(version="0+review")
from qtpy import QtWidgets
from glue.main import load_plugins
load_plugins(require_qt_plugins=True)
import glue_solar; glue_solar.setup()
from glue_qt.app import GlueApplication
from glue.core.data_factories import load_data
from irispy.data.test import ROOTDIR
from glue_qt.app.plugin_manager import QtPluginManager
app = GlueApplication(); app.show()
q = QtWidgets.QApplication.instance()
files = sorted((ROOTDIR / "sns").glob("*.fits")) + sorted((ROOTDIR / "raster" / "iris_l2_20140329_140938_3860258481_raster").glob("*.fits")) + [ROOTDIR / "sot" / "sot_l2_20150830_070953_3603259402_20150830100400_Gband4305_FG_test.fits"]
for f in files:
    got = load_data(str(f)); app.data_collection.extend(got if isinstance(got, list) else [got])
app.run_startup_action("iris_quicklook")
for _ in range(100): q.processEvents(); time.sleep(0.02)
print([app.tab_bar.tabText(i) for i in range(app.tab_bar.count())])
print(app.statusBar().currentMessage())
for i in range(app.tab_widget.count()):
    print(app.tab_bar.tabText(i), [w.widget().windowTitle() for w in app.tab_widget.widget(i).subWindowList()])
m = QtPluginManager(); m.ui.show()
for _ in range(20): q.processEvents(); time.sleep(0.02)
tree = m.ui.tree
print('plugin manager:', [tree.topLevelItem(i).text(0) for i in range(tree.topLevelItemCount())])
m.ui.grab().save(os.path.join(os.path.dirname(os.path.abspath(__file__)), "shots", "dialog_plugin_manager.png"))
app.setVisible(False); os._exit(0)
