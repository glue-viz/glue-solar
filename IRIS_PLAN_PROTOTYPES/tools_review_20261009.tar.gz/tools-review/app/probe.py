"""Read-only inventory probe of glue + glue-solar at application level (headless)."""

import json
import os
import sys
import time
import traceback
import types
import warnings

OUT = os.path.dirname(os.path.abspath(__file__))
SHOTS = os.path.join(OUT, "shots")
os.makedirs(SHOTS, exist_ok=True)
R = {}
warnings.simplefilter("always")
CAUGHT = []
_showwarning = warnings.showwarning
warnings.showwarning = lambda m, c, f, l, *a, **k: CAUGHT.append(f"{c.__name__}: {m}")

sys.modules["glue_solar.version"] = types.SimpleNamespace(version="0+review")  # setuptools_scm file absent

from qtpy import QtCore, QtGui, QtWidgets  # noqa: E402
from qtpy.QtCore import QSettings, Qt  # noqa: E402

from glue.main import load_plugins  # noqa: E402

load_plugins(require_qt_plugins=True)
import glue_solar  # noqa: E402

glue_solar.setup()
R["glue_solar_file"] = glue_solar.__file__

from glue_solar.sources.loaders import iris as loader_iris  # noqa: E402


class IniSettings(QSettings):  # keep the browser's settings out of the user's macOS defaults
    def __init__(self, organization, application):
        super().__init__(os.path.join(os.environ["HOME"], f"{organization}-{application}.ini"), QSettings.IniFormat)


loader_iris.QSettings = IniSettings

# Never block, never open a browser: record instead
LOG = []
QtWidgets.QDialog.exec = lambda self: (LOG.append(("dialog", self.windowTitle())), 0)[1]
QtWidgets.QDialog.exec_ = QtWidgets.QDialog.exec
QtWidgets.QMessageBox.exec = lambda self: (LOG.append(("messagebox", self.windowTitle(), self.text())), 0)[1]
QtWidgets.QMessageBox.exec_ = QtWidgets.QMessageBox.exec
for name in ("information", "warning", "critical", "question"):
    setattr(QtWidgets.QMessageBox, name, staticmethod(lambda *a, _n=name, **k: (LOG.append(("messagebox." + _n, *[str(x) for x in a[1:3]])), 0)[1]))
QtWidgets.QInputDialog.getItem = staticmethod(lambda *a, **k: (LOG.append(("getItem", *[str(x) for x in a[1:4]])), ("", False))[1])
QtWidgets.QInputDialog.getText = staticmethod(lambda *a, **k: (LOG.append(("getText", *[str(x) for x in a[1:3]])), ("", False))[1])
QtWidgets.QFileDialog.getSaveFileName = staticmethod(lambda *a, **k: (LOG.append(("getSaveFileName", *[str(x) for x in a[1:4]])), ("", ""))[1])
QtWidgets.QFileDialog.getOpenFileName = staticmethod(lambda *a, **k: (LOG.append(("getOpenFileName", *[str(x) for x in a[1:4]])), ("", ""))[1])
QtWidgets.QFileDialog.getExistingDirectory = staticmethod(lambda *a, **k: (LOG.append(("getExistingDirectory", *[str(x) for x in a[1:3]])), "")[1])
URLS = []
import glue_solar.sources.iris as src_iris  # noqa: E402

src_iris.QtGui = types.SimpleNamespace(QDesktopServices=types.SimpleNamespace(openUrl=lambda url: URLS.append(url.toString())))


def name(obj):
    return f"{getattr(obj, '__module__', '?')}.{getattr(obj, '__qualname__', getattr(obj, '__name__', repr(obj)))}"


def section(key):
    def wrap(f):
        try:
            R[key] = f()
        except Exception:
            R[key] = {"probe_error": traceback.format_exc()}
        return f

    return wrap


def keytext(seq):
    seq = QtGui.QKeySequence(seq)
    return seq.toString(QtGui.QKeySequence.PortableText)


# ---------------------------------------------------------------- registries
from glue import config as gc  # noqa: E402
from glue_qt import config as gqc  # noqa: E402


@section("registries")
def _():
    out = {}
    out["data_factory"] = [
        {"label": f.label, "priority": f.priority, "function": name(f.function), "identifier": name(f.identifier)}
        for f in gc.data_factory.members
    ]
    out["importer"] = [{"label": lab, "function": name(fn)} for lab, fn in gc.importer]
    out["session_exporters"] = [{"label": e[0], "function": name(e[1]), "mode": str(e[3])} for e in gc.exporters]
    out["data_exporter"] = [
        {"label": e.label, "extension": e.extension, "function": name(e.function)} for e in gc.data_exporter.members
    ]
    out["subset_mask_importer"] = [repr(m)[:160] for m in gc.subset_mask_importer.members]
    out["subset_mask_exporter"] = [repr(m)[:160] for m in gc.subset_mask_exporter.members]
    out["layer_action"] = [
        {k: (name(v) if k == "callback" else v) for k, v in item._asdict().items()} for item in gqc.layer_action
    ]
    out["menubar_plugin"] = [{"label": lab, "function": name(fn)} for lab, fn in gqc.menubar_plugin]
    out["startup_action"] = {k: name(v) for k, v in gqc.startup_action.members.items()}
    out["keyboard_shortcut"] = {
        (v.__name__ if v is not None else "None(application)"): {keytext(k): name(f) for k, f in fns.items()}
        for v, fns in gqc.keyboard_shortcut.members.items()
    }
    out["settings"] = {k: repr(v) for k, v in gc.settings._defaults.items()}
    out["preference_panes"] = [(lab, name(cls)) for lab, cls in gqc.preference_panes]
    out["qt_client"] = [(getattr(c, "LABEL", c.__name__), name(c)) for c in gqc.qt_client.members]
    out["qt_fixed_layout_tab"] = [name(c) for c in gqc.qt_fixed_layout_tab.members]
    out["layer_artist_maker"] = [repr(m)[:200] for m in gc.layer_artist_maker.members]
    out["unit_converter"] = {k: name(v) for k, v in gc.unit_converter.members.items()}
    out["fit_plugin"] = [name(c) for c in gc.fit_plugin.members]
    out["stretches"] = {k: gc.stretches.display_func(k) if hasattr(gc.stretches, "display_func") else "" for k in gc.stretches.members}
    try:
        out["stretches_display"] = dict(gc.stretches._display)
    except Exception:
        pass
    cms = list(gc.colormaps.members)
    out["colormaps_total"] = len(cms)
    out["colormaps_from_sunpy"] = [label for label, cm in cms if "sunpy" in type(cm).__module__ or label in __import__("sunpy.visualization.colormaps", fromlist=["cmlist"]).cmlist or getattr(cm, "name", "") in {c.name for c in __import__("sunpy.visualization.colormaps", fromlist=["cmlist"]).cmlist.values()}]
    out["session_patch"] = [repr(m)[:160] for m in getattr(gc.session_patch, "members", [])]
    out["qglue_parser"] = [repr(m)[:160] for m in gc.qglue_parser.members]
    out["link_function_glue_solar"] = [repr(m)[:120] for m in gc.link_function.members if "glue_solar" in repr(m)]
    out["link_helper_glue_solar"] = [repr(m)[:120] for m in gc.link_helper.members if "glue_solar" in repr(m)]
    out["viewer_tool"] = {
        tid: {
            "module": cls.__module__,
            "class": cls.__name__,
            "shortcut": getattr(cls, "shortcut", None),
            "action_text": getattr(cls, "action_text", None),
            "tool_tip": getattr(cls, "tool_tip", None),
        }
        for tid, cls in gc.viewer_tool.members.items()
    }
    return out


# ---------------------------------------------------------------- application
from glue_qt.app import GlueApplication  # noqa: E402

app = GlueApplication()
app.resize(1500, 950)
app.show()
qapp = QtWidgets.QApplication.instance()


def pump(seconds=0.2):
    end = time.time() + seconds
    while time.time() < end:
        qapp.processEvents()
        time.sleep(0.01)


pump(0.5)
app.grab().save(os.path.join(SHOTS, "main_window_empty.png"))
R["closeEvent_wrapped"] = GlueApplication.closeEvent is glue_solar._close_event


def walk_menu(menu, depth=0):
    rows = []
    for a in menu.actions():
        row = {
            "text": a.text(),
            "separator": a.isSeparator(),
            "shortcut": keytext(a.shortcut()) if not a.shortcut().isEmpty() else "",
            "shortcut_native": a.shortcut().toString(QtGui.QKeySequence.NativeText) if not a.shortcut().isEmpty() else "",
            "tooltip": a.toolTip(),
            "statustip": a.statusTip(),
            "enabled": a.isEnabled(),
            "visible": a.isVisible(),
            "menuRole": str(a.menuRole()),
        }
        if a.menu() is not None and depth < 3:
            row["submenu"] = walk_menu(a.menu(), depth + 1)
        rows.append(row)
    return rows


def shoot_menu(menu, fname):
    menu.popup(app.mapToGlobal(QtCore.QPoint(40, 40)))
    pump(0.15)
    menu.grab().save(os.path.join(SHOTS, fname))
    menu.hide()
    pump(0.05)


@section("menubar_empty")
def _():
    out = {}
    for a in app.menuBar().actions():
        out[a.text()] = walk_menu(a.menu())
        safe = a.text().replace("&", "").strip().replace(" ", "_").lower()
        shoot_menu(a.menu(), f"menu_{safe}_empty.png")
        for sub in a.menu().actions():
            if sub.menu() is not None:
                ssafe = sub.text().replace("&", "").strip().replace(" ", "_").lower()
                shoot_menu(sub.menu(), f"menu_{safe}_{ssafe}.png")
    return out


@section("main_toolbars")
def _():
    out = []
    for tb in app.findChildren(QtWidgets.QToolBar):
        widgets = []
        for w in tb.findChildren(QtWidgets.QAbstractButton):
            widgets.append({"text": w.text(), "tooltip": w.toolTip(), "visible": w.isVisible()})
        out.append({"name": tb.objectName(), "title": tb.windowTitle(), "buttons": widgets})
        tb.grab().save(os.path.join(SHOTS, f"main_toolbar_{tb.objectName() or len(out)}.png"))
    return out


# ---------------------------------------------------------------- dialogs without data
@section("plugin_dialogs_no_data")
def _():
    out = {}
    LOG.clear()
    glue_solar.restore_last_session(app.session, app.data_collection)
    out["Restore last session"] = list(LOG)
    LOG.clear()
    src_iris.quicklook_iris(app.session, app.data_collection)
    out["IRIS: quicklook…"] = list(LOG)
    LOG.clear()
    src_iris.help_iris(app.session, app.data_collection)
    out["IRIS: user guide and issues"] = list(URLS)
    LOG.clear()
    src_iris.browse_iris(app.session, app.data_collection)
    out["IRIS: browse observations… (folder picker)"] = list(LOG)
    LOG.clear()
    src_iris.link_iris(app.session, app.data_collection)
    out["IRIS: link helioprojective coordinates (no data)"] = list(LOG) or "nothing visible"
    return out


@section("open_data_dialog")
def _():
    from glue_qt.dialogs.data_wizard.data_wizard_dialog import GlueDataDialog

    d = GlueDataDialog(parent=app)
    fd = d._fd
    fd.setOption(QtWidgets.QFileDialog.DontUseNativeDialog, True)
    fd.resize(900, 520)
    fd.show()
    pump(0.3)
    fd.grab().save(os.path.join(SHOTS, "dialog_file_open_data.png"))
    combo = [c for c in fd.findChildren(QtWidgets.QComboBox) if c.objectName() == "fileTypeCombo"]
    if combo:
        combo[0].showPopup()
        pump(0.2)
        view = combo[0].view().window()
        view.grab().save(os.path.join(SHOTS, "dialog_file_open_data_types.png"))
        combo[0].hidePopup()
    filters = fd.nameFilters()
    fd.hide()
    return {"name_filters": filters, "count": len(filters)}


@section("preferences_dialog")
def _():
    from glue_qt.app.preferences import PreferencesDialog

    d = PreferencesDialog(app)
    d.show()
    pump(0.3)
    d.grab().save(os.path.join(SHOTS, "dialog_preferences.png"))
    tabs = [t for t in d.findChildren(QtWidgets.QTabWidget)]
    names = [t.tabText(i) for t in tabs for i in range(t.count())]
    labels = sorted({w.text() for w in d.findChildren(QtWidgets.QLabel) if w.text()} | {w.text() for w in d.findChildren(QtWidgets.QCheckBox)})
    d.hide()
    return {"tabs": names, "labels": labels}


@section("browser_dialog")
def _():
    from irispy.data.test import ROOTDIR

    d = loader_iris.QtIRISImporter(str(ROOTDIR / "sns"), parent=app, shown=src_iris._shown)
    d.resize(1100, 600)
    d.show()
    t0 = time.time()
    while time.time() - t0 < 30 and d.obs_tree.topLevelItemCount() == 0:
        pump(0.2)
    pump(0.5)
    if d.obs_tree.topLevelItemCount():
        d.obs_tree.expandAll()
        pump(0.2)
    d.grab().save(os.path.join(SHOTS, "dialog_iris_observation_browser.png"))
    widgets = []
    for w in d.findChildren(QtWidgets.QWidget):
        if isinstance(w, (QtWidgets.QPushButton, QtWidgets.QCheckBox, QtWidgets.QLineEdit, QtWidgets.QComboBox)):
            widgets.append(
                {
                    "kind": type(w).__name__,
                    "name": w.objectName(),
                    "text": getattr(w, "text", lambda: "")() if not isinstance(w, QtWidgets.QComboBox) else "",
                    "placeholder": w.placeholderText() if isinstance(w, QtWidgets.QLineEdit) else "",
                    "tooltip": w.toolTip(),
                    "checked": w.isChecked() if isinstance(w, QtWidgets.QAbstractButton) and w.isCheckable() else None,
                    "default": w.isDefault() if isinstance(w, QtWidgets.QPushButton) else None,
                }
            )
    rows = []
    for i in range(d.obs_tree.topLevelItemCount()):
        top = d.obs_tree.topLevelItem(i)
        rows.append([top.text(c) for c in range(top.columnCount())] + [[top.child(j).text(0) for j in range(top.childCount())]])
    shortcuts = [(s.key().toString(), s.parent().objectName()) for s in d.findChildren(QtGui.QShortcut)]
    d.reject()
    return {"title": d.windowTitle(), "widgets": widgets, "rows": rows, "shortcuts": shortcuts}


# ---------------------------------------------------------------- data
from irispy.data.test import ROOTDIR  # noqa: E402
from glue.core.data_factories import find_factory, load_data  # noqa: E402
from glue.core import Data  # noqa: E402

FILES = {
    "sns_raster": ROOTDIR / "sns" / "iris_l2_20210905_001833_3620258102_raster_t000_r00000_test.fits",
    "sns_sji_1400": ROOTDIR / "sns" / "iris_l2_20210905_001833_3620258102_SJI_1400_t000_test.fits",
    "sns_sji_1330": ROOTDIR / "sns" / "iris_l2_20210905_001833_3620258102_SJI_1330_t000_test.fits",
    "sns_sji_2796": ROOTDIR / "sns" / "iris_l2_20210905_001833_3620258102_SJI_2796_t000_test.fits",
    "scan_r0": ROOTDIR / "raster" / "iris_l2_20140329_140938_3860258481_raster" / "iris_l2_20140329_140938_3860258481_raster_t000_r00000_test.fits",
    "scan_r1": ROOTDIR / "raster" / "iris_l2_20140329_140938_3860258481_raster" / "iris_l2_20140329_140938_3860258481_raster_t000_r00001_test.fits",
    "sot_gband": ROOTDIR / "sot" / "sot_l2_20150830_070953_3603259402_20150830100400_Gband4305_FG_test.fits",
}
DATA = {}


@section("factories_per_file")
def _():
    out = {}
    for key, path in FILES.items():
        ident = {}
        for f in gc.data_factory.members:
            try:
                ident[f.label] = bool(f.identifier(str(path)))
            except Exception as e:
                ident[f.label] = f"error {type(e).__name__}"
        chosen = find_factory(str(path))
        got = load_data(str(path))
        got = got if isinstance(got, list) else [got]
        DATA[key] = got
        out[key] = {
            "auto_factory": getattr(chosen, "label", name(chosen)),
            "identified_by": [k for k, v in ident.items() if v is True],
            "labels": [d.label for d in got],
        }
    return out


for got in DATA.values():
    app.data_collection.extend(got)
loader_iris.keep_hpc_linked(app.data_collection)
table = Data(label="plain table", x=[1.0, 2.0, 3.0], y=[2.0, 3.0, 4.0])
app.data_collection.append(table)
pump(0.3)

tree = app._layer_widget.ui.layerTree
sns_win = DATA["sns_raster"][0]
sji = DATA["sns_sji_1400"][0]
scan_win = DATA["scan_r0"][0]
sot = DATA["sot_gband"][0]
subset_group = app.data_collection.new_subset_group("probe subset", None)
pump(0.2)


def actions_for(selection):
    tree.set_selected_layers(selection)
    pump(0.15)
    return [
        {
            "text": a.text(),
            "visible": a.isVisible(),
            "enabled": a.isEnabled(),
            "shortcut": keytext(a.shortcut()) if not a.shortcut().isEmpty() else "",
            "tooltip": a.toolTip(),
        }
        for a in tree.actions()
        if not a.isSeparator()
    ]


@section("context_menu")
def _():
    sels = {
        "nothing": [],
        "sns raster window": [sns_win],
        "sns SJI 1400": [sji],
        "scanning raster window": [scan_win],
        "SOT G-band": [sot],
        "plain table": [table],
        "subset group": [subset_group],
        "subset of SJI": [subset_group.subsets[[s.data for s in subset_group.subsets].index(sji)]],
        "two datasets": [sns_win, sji],
    }
    out = {}
    for label, sel in sels.items():
        out[label] = actions_for(sel)
        menu = QtWidgets.QMenu()
        menu.addActions(tree.actions())
        shoot_menu(menu, "context_menu_" + label.replace(" ", "_").lower() + ".png")
    out["_all_titles_in_registration_order"] = [a.text() for a in tree.actions()]
    return out


@section("data_manager_menu")
def _():
    tree.set_selected_layers([sns_win])
    pump(0.15)
    for a in app.menuBar().actions():
        if "Data" in a.text():
            shoot_menu(a.menu(), "menu_data_manager_raster_selected.png")
            return walk_menu(a.menu())


@section("save_data_dialog")
def _():
    from glue_qt.app.save_data import SaveDataDialog

    d = SaveDataDialog(data_collection=app.data_collection, parent=app)
    d.show()
    pump(0.3)
    d.grab().save(os.path.join(SHOTS, "dialog_export_data_subsets.png"))
    combos = {}
    for c in d.findChildren(QtWidgets.QComboBox):
        combos[c.objectName()] = [c.itemText(i) for i in range(c.count())]
        if "exporter" in c.objectName():
            c.showPopup()
            pump(0.2)
            c.view().window().grab().save(os.path.join(SHOTS, "dialog_export_data_subsets_formats.png"))
            c.hidePopup()
    d.hide()
    return combos


# ---------------------------------------------------------------- run glue-solar layer actions on each kind
@section("layer_action_outcomes")
def _():
    os.environ["GLUE_TESTING"] = "True"  # messagebox_on_error raises instead of showing a box
    kinds = {"sns raster window": sns_win, "sns SJI 1400": sji, "scanning raster window": scan_win, "SOT G-band": sot, "plain table": table}
    out = {}
    for item in gqc.layer_action:
        if "glue_solar" not in item.callback.__module__:
            continue
        res = {}
        for kind, data in kinds.items():
            if not item.single and kind != "sns raster window":
                continue
            LOG.clear()
            before = (len(app.data_collection), {d.label: len(d.components) for d in app.data_collection})
            try:
                arg = data if item.single else [data]
                item.callback(arg, app.data_collection)
                pump(0.3)
                after_n = len(app.data_collection)
                added = [d.label for d in list(app.data_collection)[before[0]:]]
                comp = {d.label: len(d.components) - before[1].get(d.label, 0) for d in app.data_collection if before[1].get(d.label) is not None and len(d.components) != before[1][d.label]}
                res[kind] = {"outcome": "dialog cancelled" if LOG else "ran", "dialogs": [list(x) for x in LOG], "added_datasets": added, "added_components": comp}
            except Exception as e:
                res[kind] = {"outcome": "error", "message": f"{type(e).__name__}: {e}"[:300], "dialogs": [list(x) for x in LOG]}
        out[item.label] = res
    os.environ.pop("GLUE_TESTING")
    return out


@section("exporter_outcomes")
def _():
    import tempfile

    os.environ["GLUE_TESTING"] = "True"
    out = {}
    tmp = tempfile.mkdtemp(dir=os.environ["HOME"])
    for e in gc.data_exporter.members:
        if "glue_solar" not in e.function.__module__ and e.function.__name__ != "export_fits":
            continue
        res = {}
        for kind, data in {"sns SJI 1400 (3-D)": sji, "plain table (1-D)": table, "sns raster window (3-D)": sns_win}.items():
            try:
                e.function(os.path.join(tmp, f"x.{e.extension[0] if e.extension else 'out'}"), data)
                res[kind] = "ok"
            except Exception as err:
                res[kind] = f"error {type(err).__name__}: {err}"[:240]
        out[e.label] = res
    os.environ.pop("GLUE_TESTING")
    return out


# ---------------------------------------------------------------- quicklook + keys
@section("quicklook")
def _():
    from glue_solar.quicklook import quicklook

    sns = [d for d in app.data_collection if d.meta.get("OBSID") == sns_win.meta.get("OBSID") and "3620258102" in d.label]
    result = quicklook(app, DATA["sns_raster"] + DATA["sns_sji_1400"] + DATA["sns_sji_1330"] + DATA["sns_sji_2796"])
    pump(1.5)
    tab = app.current_tab
    viewers = [(type(w.widget()).__name__, w.widget().windowTitle()) for w in tab.subWindowList()]
    app.grab().save(os.path.join(SHOTS, "main_window_quicklook.png"))
    sub = tab.subWindowList()[0]
    sysmenu = [(a.text(), keytext(a.shortcut())) for a in sub.systemMenu().actions()] if sub.systemMenu() else []
    return {"result_keys": sorted(result) if isinstance(result, dict) else repr(result)[:200], "viewers": viewers, "subwindow_system_menu": sysmenu, "tab_title": app.tab_bar.tabText(app.tab_bar.currentIndex()) if hasattr(app, "tab_bar") else ""}


@section("menubar_with_data")
def _():
    out = {}
    for a in app.menuBar().actions():
        out[a.text()] = [r["text"] + ("  [" + r["shortcut"] + "]" if r["shortcut"] else "") for r in walk_menu(a.menu()) if not r["separator"]]
        if "Plugins" in a.text():
            shoot_menu(a.menu(), "menu_plugins.png")
        if "File" in a.text():
            shoot_menu(a.menu(), "menu_file.png")
    return out


@section("key_dispatch")
def _():
    from glue_solar.quicklook import coordinator, observation_key
    from glue_solar.tools import _first_slider

    tab = app.current_tab
    out = {}
    raster_sub = next(w for w in tab.subWindowList() if w.widget().state.reference_data is not None and w.widget().state.reference_data.ndim >= 3)
    tab.setActiveSubWindow(raster_sub)
    pump(0.2)
    viewer = raster_sub.widget()
    out["active_viewer"] = (type(viewer).__name__, viewer.state.reference_data.label)

    def state():
        return {"slices": [str(getattr(s, "center", s)) for s in viewer.state.slices]}

    for key in (Qt.Key_F, Qt.Key_D, Qt.Key_S, Qt.Key_A):
        before = state()
        app.keyPressEvent(QtGui.QKeyEvent(QtCore.QEvent.KeyPress, key, Qt.NoModifier))
        pump(0.4)
        out[keytext(key) + " via app.keyPressEvent"] = {"before": before, "after": state()}
    # does a key typed with the canvas focused reach glue-qt's application handler?
    from qtpy.QtTest import QTest

    canvas = viewer.central_widget
    canvas.setFocus()
    pump(0.1)
    before = state()
    QTest.keyClick(canvas, Qt.Key_F)
    pump(0.4)
    out["F typed on focused canvas (QTest)"] = {"focus": type(qapp.focusWidget()).__name__ if qapp.focusWidget() else None, "before": before, "after": state()}
    before = state()
    QTest.keyClick(canvas, Qt.Key_F, Qt.ControlModifier)
    pump(0.4)
    out["Ctrl+F typed on focused canvas (QTest)"] = {"before": before, "after": state()}
    # matplotlib's own bindings left on: does L over a Profile viewer change its y scale?
    from matplotlib.backend_bases import KeyEvent
    from matplotlib import rcParams

    prof = next((w.widget() for w in tab.subWindowList() if type(w.widget()).__name__ == "ProfileViewer"), None)
    mpl = {}
    if prof is not None:
        ax = prof.axes
        x, y = ax.transAxes.transform((0.5, 0.5))
        for k in ("l", "k", "g", "L", "q"):
            yscale, xscale, grid = ax.get_yscale(), ax.get_xscale(), any(line.get_visible() for line in ax.get_xgridlines())
            try:
                KeyEvent("key_press_event", prof.figure.canvas, k, x, y)._process()
                pump(0.2)
                mpl[k] = {"yscale": f"{yscale}->{ax.get_yscale()}", "xscale": f"{xscale}->{ax.get_xscale()}", "grid": f"{grid}->{any(line.get_visible() for line in ax.get_xgridlines())}", "viewer_open": prof.isVisible()}
            except Exception as e:
                mpl[k] = f"error {type(e).__name__}: {e}"
            ax.set_yscale("linear"); ax.set_xscale("linear")
    out["matplotlib_keys_on_profile"] = mpl
    out["manager_key_handler_connected"] = getattr(getattr(viewer.central_widget.canvas, "manager", None), "key_press_handler_id", None) is not None if hasattr(viewer.central_widget, "canvas") else None
    out["rc_keymaps"] = {k: v for k, v in rcParams.items() if k.startswith("keymap.")}
    return out


@section("viewer_shortcuts")
def _():
    """Every viewer class's toolbar tools (and menu entries) with the shortcut glue-qt actually set."""
    from glue_qt.viewers.image import ImageViewer
    from glue_qt.viewers.profile import ProfileViewer
    from glue_qt.viewers.scatter import ScatterViewer
    from glue_qt.viewers.histogram import HistogramViewer
    from glue_qt.viewers.table import TableViewer
    from glue_solar.quicklook import QuicklookImageViewer

    out = {}
    CAUGHT.clear()
    for cls, data in ((ImageViewer, sji), (ProfileViewer, sns_win), (ScatterViewer, table), (HistogramViewer, table), (TableViewer, table)):
        v = app.new_data_viewer(cls, data=data)
        pump(0.5)
        rows = []
        tb = v.toolbar
        for tid, tool in tb.tools.items():
            act = tb.actions.get(tid)
            rows.append({"tool_id": tid, "class_shortcut": getattr(tool, "shortcut", None), "action_shortcut": keytext(act.shortcut()) if act is not None and not act.shortcut().isEmpty() else "", "tooltip": act.toolTip() if act is not None else ""})
        qs = [(keytext(s.key()), s.parent().objectName() or type(s.parent()).__name__) for s in tb.findChildren(QtGui.QShortcut)]
        out[cls.__name__] = {"tools": rows, "glue_solar_qshortcuts": qs}
    tab = app.current_tab
    qv = next((w.widget() for t in range(app.tab_widget.count()) for w in app.tab_widget.widget(t).subWindowList() if type(w.widget()) is QuicklookImageViewer), None)
    if qv is not None:
        tb = qv.toolbar
        out["QuicklookImageViewer"] = {"tools": [{"tool_id": tid, "action_shortcut": keytext(tb.actions[tid].shortcut()) if tid in tb.actions and not tb.actions[tid].shortcut().isEmpty() else ""} for tid in tb.tools], "glue_solar_qshortcuts": [(keytext(s.key()), type(s.parent()).__name__) for s in tb.findChildren(QtGui.QShortcut)]}
    out["warnings_while_building"] = [w for w in CAUGHT if "shortcut" in w.lower()]
    return out


@section("startup_action_run")
def _():
    LOG.clear()
    n_tabs = app.tab_widget.count()
    app.run_startup_action("iris_quicklook")
    pump(1.5)
    return {"tabs_before": n_tabs, "tabs_after": app.tab_widget.count(), "status": app.statusBar().currentMessage(), "dialogs": [list(x) for x in LOG]}


R["warnings"] = sorted(set(CAUGHT))[:60]
R["log_tail"] = [list(x) for x in LOG][-20:]
with open(os.path.join(OUT, "probe.json"), "w") as f:
    json.dump(R, f, indent=1, default=str)
# Close without glue's own save-session prompt or a kept session
app.setVisible(False)
os._exit(0)
