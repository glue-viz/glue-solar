"""Keys over a quicklook: does a key typed on a viewer's canvas reach glue-qt's handler, matplotlib's, or both?"""

import json
import os
import sys
import time
import types

OUT = os.path.dirname(os.path.abspath(__file__))
sys.modules["glue_solar.version"] = types.SimpleNamespace(version="0+review")
from qtpy import QtCore, QtGui, QtWidgets  # noqa: E402
from qtpy.QtCore import Qt  # noqa: E402
from glue.main import load_plugins  # noqa: E402

load_plugins(require_qt_plugins=True)
import glue_solar  # noqa: E402

glue_solar.setup()
QtWidgets.QMessageBox.exec = lambda self: 0
for n in ("information", "warning", "critical", "question"):
    setattr(QtWidgets.QMessageBox, n, staticmethod(lambda *a, **k: 0))
from glue_qt.app import GlueApplication  # noqa: E402
from glue.core.data_factories import load_data  # noqa: E402
from irispy.data.test import ROOTDIR  # noqa: E402
from glue_solar.quicklook import quicklook, coordinator, observation_key  # noqa: E402
from glue_solar.sources.loaders.iris import keep_hpc_linked  # noqa: E402

app = GlueApplication()
app.resize(1500, 950)
app.show()
qapp = QtWidgets.QApplication.instance()


def pump(s=0.3):
    end = time.time() + s
    while time.time() < end:
        qapp.processEvents()
        time.sleep(0.01)


sns = ROOTDIR / "sns"
datasets = []
for f in sorted(sns.glob("*.fits")):
    got = load_data(str(f))
    datasets += got if isinstance(got, list) else [got]
quicklook(app, datasets)
pump(1.5)
tab = app.current_tab
subs = {w.widget().windowTitle(): w for w in tab.subWindowList()}
R = {"panels": list(subs)}
sync = coordinator(app.data_collection)


def master_state(viewer):
    data = viewer.state.reference_data
    m = sync._master(observation_key(data))
    return {"master": m.label if m is not None else None, "index": int(sync._timing(m)[0]) if m is not None else None, "slices": [str(getattr(s, "center", s)) for s in viewer.state.slices]}


def send(widget, key, mod=Qt.NoModifier, text=""):
    ev = QtGui.QKeyEvent(QtCore.QEvent.KeyPress, key, mod, text)
    QtWidgets.QApplication.sendEvent(widget, ev)
    QtWidgets.QApplication.sendEvent(widget, QtGui.QKeyEvent(QtCore.QEvent.KeyRelease, key, mod, text))
    pump(0.4)
    return ev.isAccepted()


for title in ("Mg II k 2796 slit vs time", "SJI 1400"):
    sub = subs[title]
    tab.setActiveSubWindow(sub)
    pump(0.2)
    v = sub.widget()
    canvas = v.central_widget.canvas if hasattr(v.central_widget, "canvas") else v.central_widget
    ax = v.axes
    out = {}
    for label, key, text in (("F", Qt.Key_F, "f"), ("D", Qt.Key_D, "d"), ("S", Qt.Key_S, "s"), ("A", Qt.Key_A, "a")):
        b = master_state(v)
        app.keyPressEvent(QtGui.QKeyEvent(QtCore.QEvent.KeyPress, key, Qt.NoModifier, text))
        pump(0.4)
        out[f"{label} to the application"] = {"before": b, "after": master_state(v)}
    for label, key, text in (("F", Qt.Key_F, "f"), ("S", Qt.Key_S, "s")):
        b = master_state(v)
        acc = send(canvas, key, text=text)
        out[f"{label} typed on the canvas"] = {"before": b, "after": master_state(v), "accepted": acc}
    b = master_state(v)
    send(canvas, Qt.Key_F, Qt.ControlModifier, "\x06")
    out["Ctrl+F typed on the canvas"] = {"before": b, "after": master_state(v)}
    # matplotlib's own keys on the image
    for label, key, text in (("l", Qt.Key_L, "l"), ("g", Qt.Key_G, "g"), ("p", Qt.Key_P, "p"), ("o", Qt.Key_O, "o"), ("k", Qt.Key_K, "k")):
        x0, y0 = ax.get_xlim(), ax.get_ylim()
        ys, xs = ax.get_yscale(), ax.get_xscale()
        # matplotlib takes the axes from the mouse position: put it on the image
        cx, cy = ax.transAxes.transform((0.5, 0.5))
        canvas._lastKey = None
        from matplotlib.backend_bases import KeyEvent

        err = None
        try:
            KeyEvent("key_press_event", canvas, text, cx, cy)._process()
            pump(0.3)
            canvas.draw()
        except Exception as e:
            err = f"{type(e).__name__}: {e}"
        tb = getattr(canvas, "toolbar", None) or getattr(getattr(canvas, "manager", None), "toolbar", None)
        out[f"matplotlib '{label}' on the image"] = {
            "yscale": f"{ys}->{ax.get_yscale()}",
            "xscale": f"{xs}->{ax.get_xscale()}",
            "error": err,
            "nav_mode": str(getattr(tb, "mode", None)),
            "glue_active_tool": getattr(v.toolbar.active_tool, "tool_id", None),
        }
        if ax.get_yscale() != "linear":
            ax.set_yscale("linear")
        if ax.get_xscale() != "linear":
            ax.set_xscale("linear")
        if tb is not None and str(getattr(tb, "mode", "")):
            getattr(tb, "pan" if "pan" in str(tb.mode) else "zoom")()  # off again
    out["canvas_has_manager_toolbar"] = type(getattr(getattr(canvas, "manager", None), "toolbar", None)).__name__
    R[title] = out

with open(os.path.join(OUT, "probe_keys.json"), "w") as f:
    json.dump(R, f, indent=1, default=str)
app.setVisible(False)
os._exit(0)
