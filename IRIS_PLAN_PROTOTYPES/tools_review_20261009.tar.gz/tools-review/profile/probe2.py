"""Behaviour checks: fit, keys, matplotlib keys, Save profiles, Set rest wavelength, Table on times, layer menu."""
import atexit
import json
import os
from pathlib import Path

import numpy as np

HERE = Path(__file__).parent
SHOTS = HERE / "shots"
OUT = {}
atexit.register(lambda: (HERE / "probe2.json").write_text(json.dumps(OUT, indent=1, default=str)))

import glue_solar  # noqa: E402

glue_solar.setup()
from glue.config import fit_plugin
from glue.core import Data
from glue_qt.app.application import GlueApplication
from glue_qt.viewers.profile import ProfileViewer
from glue_qt.viewers.scatter import ScatterViewer
from glue_qt.viewers.table import TableViewer
from qtpy import QtWidgets, QtCore
from qtpy.QtTest import QTest
from irispy.data.test import ROOTDIR

from glue_solar import lines
from glue_solar.quicklook import quicklook, _light_curve, _point_curves, _window, _wavelengths, coordinator, observation_key
from glue_solar.sources.loaders.iris import raster_data, image_data

Qt = QtCore.Qt
DIALOGS = []
OUT["dialogs"] = DIALOGS


def wait(ms=200):
    QTest.qWait(ms)


def _close_modal():
    w = QtWidgets.QApplication.activeModalWidget()
    if w is None:
        return
    DIALOGS.append({"class": type(w).__name__, "title": w.windowTitle(),
                    "text": w.text() if hasattr(w, "text") and callable(w.text) else None})
    w.reject() if hasattr(w, "reject") else w.close()


def _fake_exec(self, *a):
    DIALOGS.append({"class": type(self).__name__, "title": self.windowTitle(),
                    "text": self.text() if hasattr(self, "text") and callable(self.text) else None,
                    "informative": self.informativeText() if hasattr(self, "informativeText") else None})
    self.grab().save(str(SHOTS / f"probe2-dialog-{len(DIALOGS)}.png"))
    return 0


QtWidgets.QMessageBox.exec = _fake_exec
QtWidgets.QMessageBox.exec_ = _fake_exec
_t = QtCore.QTimer()
_t.timeout.connect(_close_modal)
_t.start(300)

app = GlueApplication()
app.resize(1600, 1000)
app.show()
wait(300)
sns = ROOTDIR / "sns"
rasters = raster_data([str(next(sns.glob("*raster*_test.fits")))])
sjis = [image_data(str(next(sns.glob(f"*SJI_{c}_t000_test.fits")))) for c in (1400, 2796)]
viewers = quicklook(app, rasters, window=["Mg II k 2796", "2832"])
wait(1500)
spec = viewers["spectrum"]
mg = spec.state.reference_data
waves = _wavelengths(mg)[0]
OUT["mg_wavelengths"] = [float(waves.min()), float(waves.max()), len(waves)]

# ---- fit with a range covering enough samples
pa = spec.toolbar.tools["profile-analysis"]
spec.toolbar.actions["profile-analysis"].trigger()
pt = pa._profile_tools
pt.ui.tabs.setCurrentIndex(1)
from glue_solar.fitters import GaussianConstantFitter

pt.fit_function = GaussianConstantFitter
for lo, hi, name in ((2795.6, 2797.2, "wide"), (2802.9, 2804.2, "mg_h")):
    pt.rng_mode.state.x_min, pt.rng_mode.state.x_max = lo, hi
    pt.ui.text_log.clear()
    pt.ui.button_fit.click()
    for _ in range(80):
        wait(100)
        if pt.ui.button_fit.text() == "Fit" and pt.ui.text_log.toPlainText().strip():
            break
    OUT[f"fit_{name}"] = pt.ui.text_log.toPlainText()
    pt.grab().save(str(SHOTS / f"profile-tools-fit-{name}.png"))
spec.grab().save(str(SHOTS / "quicklook-spectrum-fit.png"))
OUT["profile_range_for_moments"] = None
from glue_solar.sources.moments import _profile_range
OUT["profile_range_for_moments"] = _profile_range(mg, app.data_collection)
spec.toolbar.actions["profile-analysis"].trigger()  # hide

# ---- keys on the spectrum panel: D/F move the time master, A/S the map wavelength, Space plays
coord = coordinator(app.data_collection)
key = observation_key(mg)


def master_index():
    m = coord._master(key)
    return None if m is None else (m.label, coord._timing(m)[0])


def map_slices():
    return tuple(viewers["map"].state.slices)


app.current_tab.setActiveSubWindow(spec.parent())
wait(100)
canvas = spec.figure.canvas
canvas.setFocus()
rec = {"before": (master_index(), map_slices())}
for k, name in ((Qt.Key_F, "F"), (Qt.Key_D, "D"), (Qt.Key_S, "S"), (Qt.Key_A, "A")):
    QTest.keyClick(canvas, k)
    wait(300)
    rec[name] = (master_index(), map_slices())
QTest.keyClick(canvas, Qt.Key_Space)
wait(500)
rec["space_playing"] = [(s is not None and s._play_timer.isActive()) for v in [viewers["map"], viewers["spectrogram"], viewers["wavelength"]]
                        for s in [v.options_widget().slice_helper._sliders[0]] if v.options_widget().slice_helper._sliders]
QTest.keyClick(canvas, Qt.Key_Space)
wait(300)
rec["space_again_playing"] = [(s is not None and s._play_timer.isActive()) for v in [viewers["map"], viewers["spectrogram"], viewers["wavelength"]]
                              for s in [v.options_widget().slice_helper._sliders[0]] if v.options_widget().slice_helper._sliders]
OUT["keys_on_quicklook_spectrum"] = rec

# matplotlib keys over the profile canvas
mpl = {}
for ch in ("l", "k", "g"):
    before = (spec.axes.get_yscale(), spec.axes.get_xscale(), spec.state.y_log, spec.state.x_log,
              any(gl.get_visible() for gl in spec.axes.get_xgridlines()))
    QTest.keyClick(canvas, ch)
    wait(200)
    after = (spec.axes.get_yscale(), spec.axes.get_xscale(), spec.state.y_log, spec.state.x_log,
             any(gl.get_visible() for gl in spec.axes.get_xgridlines()))
    mpl[ch] = {"before(yscale,xscale,state.y_log,state.x_log,grid)": before, "after": after}
    QTest.keyClick(canvas, ch)  # back
    wait(200)
spec.grab().save(str(SHOTS / "quicklook-spectrum-after-keys.png"))
OUT["mpl_keys_on_profile"] = mpl

# keys on a Scatter (point curves) and the light-curve Profile
lc = _light_curve(viewers["map"]) if False else None  # sit-and-stare map: needs Coordinate entry, done below
try:
    lc = _light_curve(viewers["map"])
    wait(1000)
    app.current_tab.setActiveSubWindow(lc.parent())
    wait(100)
    b = master_index()
    QTest.keyClick(lc.figure.canvas, Qt.Key_F)
    wait(300)
    OUT["F_on_light_curve_profile"] = (b, master_index())
    OUT["light_curve_lines_tool_positions"] = lc.toolbar.tools["solar:lines"].positions()
except Exception as e:
    OUT["light_curve_err"] = repr(e)
try:
    sc = _point_curves(viewers["map"])
    wait(1000)
    app.current_tab.setActiveSubWindow(sc.parent())
    wait(100)
    b = master_index()
    QTest.keyClick(sc.figure.canvas, Qt.Key_F)
    wait(300)
    OUT["F_on_point_curves_scatter"] = (b, master_index())
    OUT["subset_groups"] = [g.label for g in app.data_collection.subset_groups]
    sc.grab().save(str(SHOTS / "point-curves-scatter-master-exposure.png"))
except Exception as e:
    OUT["point_curves_err"] = repr(e)

# ---- Save profiles as ECSV through the menu entry, file dialog answered
target = HERE / "saved-profiles.ecsv"
QtWidgets.QFileDialog.getSaveFileName = staticmethod(lambda *a, **k: (str(target), "ECSV table (*.ecsv)"))
button = spec.toolbar.widgetForAction(spec.toolbar.actions["save"])
entry = next(a for a in button.menu().actions() if a.text() == "Save profiles as ECSV…")
entry.trigger()
wait(300)
from astropy.table import Table

t = Table.read(target, format="ascii.ecsv")
OUT["saved_profiles"] = {"columns": t.colnames, "meta": {k: str(v) for k, v in t.meta.items()},
                         "status": app.statusBar().currentMessage()}
# a light curve with times
if lc is not None:
    button = lc.toolbar.widgetForAction(lc.toolbar.actions["save"])
    next(a for a in button.menu().actions() if a.text() == "Save profiles as ECSV…").trigger()
    wait(300)
    t = Table.read(target, format="ascii.ecsv")
    OUT["saved_light_curve"] = {"columns": t.colnames, "time_type": type(t.columns[-1]).__name__}

# ---- 2832 window: km / s absent, Velocity axis silent; Set rest wavelength adds it
w2832 = viewers["windows"][0]["spectrum"]
st = w2832.state
OUT["2832"] = {"title": st.title, "rest": lines.rest_wavelength(st.reference_data),
               "kms_offered": "km / s" in type(st).x_display_unit.get_choices(st),
               "lines_positions": w2832.toolbar.tools["solar:lines"].positions()}
w2832.toolbar.actions["solar:velocity"].trigger()
wait(200)
OUT["2832"]["velocity_after_click"] = {"shown": w2832.toolbar.tools["solar:velocity"].shown,
                                       "axis": w2832.toolbar.tools["solar:velocity"].axis is not None,
                                       "status": app.statusBar().currentMessage()}
QtWidgets.QInputDialog.getItem = staticmethod(lambda *a, **k: ("2832.0", True))
lines.rest_wavelength_iris(st.reference_data, app.data_collection)
wait(300)
OUT["2832"]["after_set_rest"] = {"rest": lines.rest_wavelength(st.reference_data),
                                 "kms_offered": "km / s" in type(st).x_display_unit.get_choices(st),
                                 "axis": w2832.toolbar.tools["solar:velocity"].axis is not None,
                                 "label": (w2832.toolbar.tools["solar:velocity"].axis.get_xlabel()
                                           if w2832.toolbar.tools["solar:velocity"].axis is not None else None)}
w2832.grab().save(str(SHOTS / "quicklook-2832-spectrum-after-rest.png"))
# a typed wrong value
QtWidgets.QInputDialog.getItem = staticmethod(lambda *a, **k: ("abc", True))
lines.rest_wavelength_iris(st.reference_data, app.data_collection)
wait(600)

# ---- layer (data collection) context menu for the raster
lw = app._layer_widget
tree = lw.ui.layerTree
lw.data_collection  # noqa
from glue_qt.app.layer_tree_widget import LayerTreeWidget  # noqa

tree.set_selected_layers([mg]) if hasattr(tree, "set_selected_layers") else lw.set_selected_layers([mg])
wait(100)
acts = []
menu = QtWidgets.QMenu()
for a in tree.actions():
    if a.isSeparator():
        acts.append("---")
        menu.addSeparator()
        continue
    acts.append({"text": a.text(), "visible": a.isVisible(), "enabled": a.isEnabled(), "tooltip": a.toolTip(),
                 "shortcut": a.shortcut().toString()})
    if a.isVisible():
        menu.addAction(a)
OUT["raster_layer_menu"] = acts
menu.popup(QtCore.QPoint(0, 0))
wait(50)
menu.grab().save(str(SHOTS / "data-collection-raster-context-menu.png"))
menu.hide()

# ---- Table viewer of a dataset with times: with glue-solar
t_data = Data(label="times", Time=np.array(["2021-09-05T00:00", "2021-09-05T00:01"], "datetime64[ns]"), Value=[1.0, 2.0])
app.data_collection.append(t_data)
n = len(DIALOGS)
tv = app.new_data_viewer(TableViewer, data=t_data)
wait(500)
OUT["table_on_times"] = {"viewer": tv is not None, "dialogs": DIALOGS[n:]}
os._exit(0) if False else None
OUT["done"] = True
os._exit((HERE / "probe2.json").write_text(json.dumps(OUT, indent=1, default=str)) and 0)
