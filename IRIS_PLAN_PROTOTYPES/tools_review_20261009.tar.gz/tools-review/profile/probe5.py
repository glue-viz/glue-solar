import os
from pathlib import Path
import glue_solar; glue_solar.setup()
from glue_qt.app.application import GlueApplication
from glue_qt.viewers.profile import ProfileViewer
from qtpy import QtWidgets
from qtpy.QtTest import QTest
from irispy.data.test import ROOTDIR
from glue_solar import lines
from glue_solar.quicklook import _wavelengths
from glue_solar.sources.loaders.iris import raster_data
SHOTS = Path(__file__).parent / "shots"
app = GlueApplication(); app.resize(1400, 900); app.show()
rasters = raster_data([str(next((ROOTDIR / "sns").glob("*raster*_test.fits")))])
app.data_collection.extend(rasters)
mg = rasters[-1]
pv = app.new_data_viewer(ProfileViewer, data=mg)
pv.state.x_att = mg.world_component_ids[_wavelengths(mg)[1]]
QTest.qWait(800)
app.current_tab.setActiveSubWindow(pv.parent()); QTest.qWait(200)
combo = pv.options_widget().ui.combosel_x_display_unit
combo.showPopup(); QTest.qWait(200)
combo.view().window().grab().save(str(SHOTS / "profile-x-unit-dropdown.png"))
combo.view().scrollToBottom(); QTest.qWait(100)
combo.view().window().grab().save(str(SHOTS / "profile-x-unit-dropdown-end.png"))
combo.hidePopup()
print("x unit count", combo.count(), "index of km/s", combo.findText("km / s"), flush=True)
def fake_get_item(parent, title, label, items, current, editable):
    dlg = QtWidgets.QInputDialog(parent)
    dlg.setWindowTitle(title); dlg.setLabelText(label); dlg.setComboBoxItems(items); dlg.setComboBoxEditable(editable)
    dlg.setTextValue(items[current]); dlg.show(); QTest.qWait(150)
    dlg.grab().save(str(SHOTS / "set-rest-wavelength-dialog.png"))
    print("dialog", repr(title), repr(label), items, current, flush=True)
    dlg.hide()
    return items[current], False
QtWidgets.QInputDialog.getItem = staticmethod(fake_get_item)
lines.rest_wavelength_iris(mg, app.data_collection)
os._exit(0)
