import os, numpy as np
import glue_solar; glue_solar.setup()
from astropy.table import Table
from astropy.time import Time
from glue_qt.app.application import GlueApplication
from glue_qt.viewers.table import TableViewer
from qtpy import QtWidgets
from qtpy.QtTest import QTest
from glue_solar.sources.bursts import _table
MSG = []
QtWidgets.QMessageBox.exec = QtWidgets.QMessageBox.exec_ = lambda self, *a: MSG.append(self.text()) or 0
app = GlueApplication(); app.show()
events = Table({"label": [1, 2], "time": Time(["2013-09-02T16:40:00", "2013-09-02T16:41:00"]), "area": [3.0, 4.0]})
d = _table(events, "x burst events", {}, (0, 0))
app.data_collection.append(d)
v = app.new_data_viewer(TableViewer, data=d)
QTest.qWait(300)
print("opened:", v is not None, MSG, flush=True)
os._exit(0)
