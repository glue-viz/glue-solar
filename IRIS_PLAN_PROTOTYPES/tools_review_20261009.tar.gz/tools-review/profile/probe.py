"""Inventory probe: Profile, Scatter, Histogram, Table viewers with glue-solar, offscreen."""
import json
import os
import sys
import warnings
from pathlib import Path

HERE = Path(__file__).parent
SHOTS = HERE / "shots"
SHOTS.mkdir(exist_ok=True)
OUT = {}

import glue_solar  # noqa: E402

OUT["glue_solar_file"] = glue_solar.__file__
glue_solar.setup()

from glue.config import fit_plugin, keyboard_shortcut as _k  # noqa
from glue_qt.config import keyboard_shortcut, qt_client
from glue_qt.app.application import GlueApplication
from glue_qt.viewers.profile import ProfileViewer
from glue_qt.viewers.scatter import ScatterViewer
from glue_qt.viewers.histogram import HistogramViewer
from glue_qt.viewers.table import TableViewer
from glue_qt.viewers.image import ImageViewer
from qtpy import QtWidgets, QtCore, QtGui
from qtpy.QtTest import QTest
from matplotlib import rcParams
from irispy.data.test import ROOTDIR

from glue_solar.quicklook import quicklook, QuicklookImageViewer, _light_curve, _point_curves
from glue_solar.sources.loaders.iris import raster_data, image_data


def wait(ms=200):
    QTest.qWait(ms)


def provider(obj):
    mod = type(obj).__module__ if not isinstance(obj, type) else obj.__module__
    return mod.split(".")[0]


def menu_entries(menu, depth=0):
    out = []
    for a in menu.actions():
        if a.isSeparator():
            out.append({"separator": True})
            continue
        e = {
            "text": a.text(),
            "tooltip": a.toolTip(),
            "statustip": a.statusTip(),
            "shortcut": a.shortcut().toString(),
            "checkable": a.isCheckable(),
            "checked": a.isChecked(),
            "enabled": a.isEnabled(),
            "visible": a.isVisible(),
        }
        if a.menu() is not None:
            e["submenu"] = menu_entries(a.menu(), depth + 1)
        out.append(e)
    return out


def grab_menu(menu, name):
    menu.popup(QtCore.QPoint(0, 0))
    wait(50)
    menu.grab().save(str(SHOTS / f"{name}.png"))
    menu.hide()


def walk_toolbar(viewer, name):
    tb = viewer.toolbar
    tb.grab().save(str(SHOTS / f"{name}-toolbar.png"))
    rows = []
    for tool_id, action in tb.actions.items():
        tool = tb.tools[tool_id]
        button = tb.widgetForAction(action)
        row = {
            "tool_id": tool_id,
            "class": f"{type(tool).__module__}.{type(tool).__name__}",
            "provider": provider(tool),
            "action_text": action.text(),
            "tool_action_text": tool.action_text,
            "action_tooltip": action.toolTip(),
            "button_tooltip": button.toolTip() if button is not None else None,
            "tool_tip": tool.tool_tip,
            "status_tip": getattr(tool, "status_tip", None),
            "shortcut": tool.shortcut,
            "qt_shortcut": action.shortcut().toString(),
            "checkable": action.isCheckable(),
            "checked": action.isChecked(),
            "enabled": action.isEnabled(),
            "visible": action.isVisible(),
            "icon": tool.icon if isinstance(tool.icon, str) else repr(tool.icon),
            "button_text": button.text() if isinstance(button, QtWidgets.QToolButton) else None,
        }
        menu = button.menu() if isinstance(button, QtWidgets.QToolButton) else None
        if menu is not None:
            row["menu"] = menu_entries(menu)
            subs = getattr(tool, "subtools", [])
            row["subtools"] = [
                {"tool_id": s.tool_id, "provider": provider(s), "text": s.action_text, "tip": s.tool_tip,
                 "shortcut": s.shortcut} for s in subs
            ]
            grab_menu(menu, f"{name}-menu-{tool_id.replace(':', '_')}")
        rows.append(row)
    return rows


def combos(widget):
    out = {}
    for c in widget.findChildren(QtWidgets.QComboBox):
        if not c.objectName():
            continue
        out[c.objectName()] = {
            "items": [c.itemText(i) for i in range(c.count())],
            "current": c.currentText(),
            "visible": c.isVisibleTo(widget),
            "tooltip": c.toolTip(),
        }
    return out


def labels(widget):
    out = []
    for w in widget.findChildren((QtWidgets.QLabel, QtWidgets.QCheckBox, QtWidgets.QPushButton, QtWidgets.QToolButton,
                                  QtWidgets.QRadioButton)):
        if w.text().strip() and w.isVisibleTo(widget):
            out.append({"type": type(w).__name__, "name": w.objectName(), "text": w.text(), "tooltip": w.toolTip()})
    return out


def dashboard(app, viewer, name):
    app.current_tab.setActiveSubWindow(viewer.parent())
    wait(100)
    opts = viewer.options_widget()
    opts.grab().save(str(SHOTS / f"{name}-options.png"))
    res = {"options_class": f"{type(opts).__module__}.{type(opts).__name__}", "combos": combos(opts),
           "labels": labels(opts)}
    # the layer list and the style editor of the first layer
    try:
        app._ui.plot_layers.grab().save(str(SHOTS / f"{name}-layers.png"))
    except Exception as e:
        res["layers_err"] = repr(e)
    return res


app = GlueApplication()
app.resize(1600, 1000)
app.show()
wait(300)

DIALOGS = []
STEP = ["start"]


def _close_modal():
    w = QtWidgets.QApplication.activeModalWidget()
    if w is None:
        return
    rec = {"step": STEP[0], "class": type(w).__name__, "title": w.windowTitle(),
           "text": w.text() if hasattr(w, "text") and callable(w.text) else None, "labels": labels(w)}
    n = len(DIALOGS)
    w.grab().save(str(SHOTS / f"dialog-{n}.png"))
    rec["shot"] = f"dialog-{n}.png"
    DIALOGS.append(rec)
    w.reject() if hasattr(w, "reject") else w.close()


_timer = QtCore.QTimer()
_timer.timeout.connect(_close_modal)
_timer.start(300)

import atexit
INV = {}
def _dump():
    OUT["dialogs"] = DIALOGS
    OUT["inventory"] = INV
    (HERE / "probe.json").write_text(json.dumps(OUT, indent=1, default=str))
atexit.register(_dump)

STEP[0] = "data"
sns = ROOTDIR / "sns"
raster_file = next(sns.glob("*raster*_test.fits"))
sns_rasters = raster_data([str(raster_file)])
OUT["sns_windows"] = [d.label for d in sns_rasters]
sjis = [image_data(str(next(sns.glob(f"*SJI_{c}_t000_test.fits")))) for c in (1400, 2796)]
scan_files = sorted(str(p) for p in (ROOTDIR / "raster").rglob("*3860258481_raster*_test.fits"))
scanning = raster_data(scan_files[:1])
OUT["scan_windows"] = [d.label for d in scanning]
stack = raster_data(scan_files, ["C II 1336"], stack=True)

STEP[0] = "quicklook of the sit-and-stare"
from glue_solar.quicklook import _window  # noqa
names = [_window(d)[0] for d in sns_rasters]
OUT["sns_window_names"] = names
others = [n for n in names if n and n != "Mg II k 2796"][:2]
viewers = quicklook(app, sns_rasters + sjis, window=["Mg II k 2796", *others])
wait(1500)
spectrum = viewers["spectrum"]
OUT["quicklook_roles"] = {k: (type(v).__name__ if not isinstance(v, list) else [
    (type(x).__name__ if not isinstance(x, dict) else {kk: type(vv).__name__ for kk, vv in x.items()}) for x in v])
    for k, v in viewers.items()}
app.grab().save(str(SHOTS / "quicklook-tab.png"))
spectrum.grab().save(str(SHOTS / "quicklook-spectrum-panel.png"))

INV["quicklook_spectrum"] = walk_toolbar(spectrum, "quicklook-spectrum")
for i, panels in enumerate(viewers["windows"]):
    INV[f"quicklook_window{i}_spectrum"] = walk_toolbar(panels["spectrum"], f"quicklook-window{i}-spectrum")
    INV[f"quicklook_window{i}_spectrum_title"] = panels["spectrum"].state.title

OUT["quicklook_spectrum_dashboard"] = dashboard(app, spectrum, "quicklook-spectrum")
st = spectrum.state
OUT["quicklook_spectrum_state"] = {
    "title": st.title, "function": st.function, "x_att": st.x_att.label, "x_display_unit": st.x_display_unit,
    "x_unit_choices": [str(c) for c in type(st).x_display_unit.get_choices(st)],
    "y_unit_choices": [str(c) for c in type(st).y_display_unit.get_choices(st)],
    "function_choices": [str(c) for c in type(st).function.get_choices(st)],
    "layers": [(l.layer.label, l.visible, getattr(l.attribute, "label", None)) for l in st.layers],
}

# IRIS lines labels drawn
lines_tool = spectrum.toolbar.tools["solar:lines"]
OUT["iris_lines_positions_quicklook"] = [(lab, [round(float(x), 3) for x in xs]) for lab, xs in lines_tool.positions()]

# Velocity axis on
vel = spectrum.toolbar.tools["solar:velocity"]
spectrum.toolbar.actions["solar:velocity"].trigger()
wait(200)
OUT["velocity_axis_after_trigger"] = {"shown": vel.shown, "axis": vel.axis is not None,
                                      "label": vel.axis.get_xlabel() if vel.axis is not None else None}
spectrum.grab().save(str(SHOTS / "quicklook-spectrum-velocity-axis.png"))

# Profile analysis Options: tabs, Fit combo, Collapse combo
pa = spectrum.toolbar.tools["profile-analysis"]
spectrum.toolbar.actions["profile-analysis"].trigger()
wait(200)
pt = pa._profile_tools
tabs = pt.ui.tabs
OUT["profile_tools"] = {"tabs": [tabs.tabText(i) for i in range(tabs.count())], "combos": combos(pt),
                        "fit_plugins": [(f.__module__ + "." + f.__name__, f.label) for f in fit_plugin]}
for i in range(tabs.count()):
    tabs.setCurrentIndex(i)
    wait(100)
    pt.grab().save(str(SHOTS / f"profile-tools-tab-{tabs.tabText(i).lower()}.png"))
    OUT["profile_tools"][f"tab_{tabs.tabText(i)}_labels"] = labels(tabs.widget(i))
spectrum.grab().save(str(SHOTS / "quicklook-spectrum-with-options.png"))

# Fit with glue-solar's fitter on the mean spectrum: range over Mg II k
tabs.setCurrentIndex(1)
from glue_solar.fitters import GaussianConstantFitter  # noqa
pt.fit_function = next(f for f in fit_plugin if f is GaussianConstantFitter)
pt.rng_mode.state.x_min, pt.rng_mode.state.x_max = 2796.0, 2796.8
wait(100)
STEP[0] = 'pt.ui.button_fit.click()'; pt.ui.button_fit.click()
for _ in range(50):
    wait(100)
    if pt.ui.text_log.toPlainText().strip():
        break
OUT["fit_report"] = pt.ui.text_log.toPlainText()
pt.grab().save(str(SHOTS / "profile-tools-fit-gaussian-constant.png"))
# Settings dialog of the fitter
try:
    from glue_qt.core.fitters import FitSettingsWidget
    STEP[0] = 'w = FitSettingsWidget'; w = FitSettingsWidget(pt.fit_function())
    OUT["fit_settings_labels"] = labels(w.ui) if hasattr(w, "ui") else labels(w)
    w.ui.grab().save(str(SHOTS / "fit-settings-gaussian-constant.png")) if hasattr(w, "ui") else None
except Exception as e:
    OUT["fit_settings_err"] = repr(e)

# save menu: profile table (no dialog)
from glue_solar.tools import _profile_table  # noqa
try:
    table, skipped = _profile_table(spectrum)
    OUT["save_profile_quicklook"] = {"columns": table.colnames, "skipped": skipped, "meta": str(table.meta)[:300]}
except Exception as e:
    OUT["save_profile_quicklook"] = repr(e)

STEP[0] = "plain Profile viewers"
app.new_tab()
mg = next(d for d in sns_rasters if _window(d)[0] == "Mg II k 2796")
plain = app.new_data_viewer(ProfileViewer, data=mg)
wait(1500)
INV["plain_profile_sns"] = walk_toolbar(plain, "plain-profile")
OUT["plain_profile_state_initial"] = {"x_att": plain.state.x_att.label, "function": plain.state.function,
                                      "x_display_unit": plain.state.x_display_unit,
                                      "x_unit_choices": [str(c) for c in type(plain.state).x_display_unit.get_choices(plain.state)]}
OUT["iris_lines_positions_plain_initial"] = plain.toolbar.tools["solar:lines"].positions()
plain.state.x_att = mg.world_component_ids[-1] if False else plain.state.x_att
# set x to wavelength
from glue_solar.quicklook import _wavelengths  # noqa
plain.state.x_att = mg.world_component_ids[_wavelengths(mg)[1]]
wait(1000)
OUT["plain_profile_state_wavelength"] = {"x_att": plain.state.x_att.label, "x_display_unit": plain.state.x_display_unit,
                                         "x_unit_choices": [str(c) for c in type(plain.state).x_display_unit.get_choices(plain.state)]}
OUT["iris_lines_positions_plain_wavelength"] = [(lab, len(xs)) for lab, xs in plain.toolbar.tools["solar:lines"].positions()]
plain.grab().save(str(SHOTS / "plain-profile-wavelength.png"))
OUT["plain_profile_dashboard"] = dashboard(app, plain, "plain-profile")
# km / s as x unit
if "km / s" in type(plain.state).x_display_unit.get_choices(plain.state):
    plain.state.x_display_unit = "km / s"
    wait(800)
    OUT["iris_lines_positions_plain_kms"] = [(lab, [round(float(x), 1) for x in xs]) for lab, xs in plain.toolbar.tools["solar:lines"].positions()]
    plain.toolbar.actions["solar:velocity"].trigger()
    wait(200)
    OUT["velocity_axis_in_kms"] = plain.toolbar.tools["solar:velocity"].axis is not None
    plain.grab().save(str(SHOTS / "plain-profile-kms.png"))
    plain.toolbar.actions["solar:velocity"].trigger()
    STEP[0] = 'plain.state.x_display_unit = "'; plain.state.x_display_unit = "Angstrom"
    wait(500)

# plain profile on a window without rest wavelength (photospheric 2832/2814 etc.)
from glue_solar.lines import rest_wavelength  # noqa
OUT["rest_wavelengths"] = {d.label: rest_wavelength(d) for d in sns_rasters + scanning}

# plain profile on the scanning raster
c2 = scanning[0]
app.data_collection.extend(scanning + stack); STEP[0] = 'plain_scan'; plain_scan = app.new_data_viewer(ProfileViewer, data=c2)
wait(1500)
OUT["plain_profile_scan_initial_x"] = plain_scan.state.x_att.label
INV["plain_profile_scan"] = walk_toolbar(plain_scan, "plain-profile-scan")

# an empty Profile viewer
STEP[0] = 'empty = app.new_data_viewer'; empty = app.new_data_viewer(ProfileViewer)
wait(300)
INV["empty_profile"] = walk_toolbar(empty, "empty-profile")
for tid in ("solar:lines", "solar:velocity"):
    try:
        empty.toolbar.actions[tid].trigger()
        OUT[f"empty_profile_{tid}"] = "ok"
    except Exception as e:
        OUT[f"empty_profile_{tid}"] = repr(e)
try:
    _profile_table(empty)
except Exception as e:
    OUT["empty_profile_save"] = repr(e)

STEP[0] = "Light curve at the point (Profile) and point curves (Scatter)"
app.current_tab_index = 0 if hasattr(app, "current_tab_index") else None
try:
    app.tab_widget.setCurrentIndex(0)
except Exception:
    pass
wait(200)
try:
    STEP[0] = 'lc = _light_curve'; lc = _light_curve(viewers["map"])
    wait(1500)
    INV["light_curve_profile"] = walk_toolbar(lc, "light-curve-profile")
    OUT["light_curve_profile_state"] = {"title": lc.state.title, "x_att": lc.state.x_att.label,
                                        "x_unit_choices": [str(c) for c in type(lc.state).x_display_unit.get_choices(lc.state)]}
    OUT["iris_lines_positions_light_curve"] = lc.toolbar.tools["solar:lines"].positions()
    t, sk = _profile_table(lc)
    OUT["save_profile_light_curve"] = {"columns": t.colnames, "skipped": sk}
    lc.grab().save(str(SHOTS / "light-curve-profile.png"))
except Exception as e:
    OUT["light_curve_err"] = repr(e)
try:
    STEP[0] = 'sc = _point_curves'; sc = _point_curves(viewers["map"])
    wait(1500)
    INV["point_curves_scatter"] = walk_toolbar(sc, "point-curves-scatter")
    OUT["point_curves_scatter_dashboard"] = dashboard(app, sc, "point-curves-scatter")
    sc.grab().save(str(SHOTS / "point-curves-scatter.png"))
except Exception as e:
    OUT["point_curves_err"] = repr(e)

STEP[0] = "plain Scatter, Histogram, Table"
app.tab_widget.setCurrentIndex(1)
curve = next((d for d in app.data_collection if d.label.endswith("light curve")), None)
STEP[0] = 's = app.new_data_viewer(Scatte'; s = app.new_data_viewer(ScatterViewer, data=curve or mg)
h = app.new_data_viewer(HistogramViewer, data=curve or mg)
t = app.new_data_viewer(TableViewer, data=curve) if curve is not None else None
wait(800)
INV["plain_scatter"] = walk_toolbar(s, "plain-scatter")
INV["plain_histogram"] = walk_toolbar(h, "plain-histogram")
OUT["curve_label"] = getattr(curve, "label", None)
if t is not None:
    INV["plain_table"] = walk_toolbar(t, "plain-table")
OUT["plain_scatter_dashboard"] = dashboard(app, s, "plain-scatter")
OUT["plain_histogram_dashboard"] = dashboard(app, h, "plain-histogram")

STEP[0] = "keys"
def keyname(k):
    try:
        return QtGui.QKeySequence(int(k)).toString()
    except Exception:
        return str(k)


OUT["keyboard_shortcuts"] = {
    (cls.__name__ if cls is not None else "None"): {keyname(k): f"{f.func.__module__}.{f.func.__name__}{f.args}" if hasattr(f, "func") else f"{f.__module__}.{f.__name__}"
                                                     for k, f in members.items()}
    for cls, members in keyboard_shortcut.members.items()
}
OUT["mpl_keymap"] = {k: v for k, v in rcParams.items() if k.startswith("keymap.")}
OUT["qt_clients"] = [f"{c.__module__}.{c.__name__}:{getattr(c, 'LABEL', '')}" for c in qt_client.members]

STEP[0] = "data collection menu for a raster (layer actions)"
from glue.config import layer_action  # noqa
OUT["layer_actions"] = [(a.label, a.tooltip, a.single, a.data, a.subset, a.callback.__module__) for a in layer_action]

OUT["dialogs"] = DIALOGS
OUT["inventory"] = INV
_dump()
print("done", len(INV))
sys.stdout.flush(); os._exit(0)
