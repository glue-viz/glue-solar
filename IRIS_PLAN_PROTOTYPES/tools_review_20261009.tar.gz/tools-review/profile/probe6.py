import os, numpy as np
from pathlib import Path
import glue_solar; glue_solar.setup()
from glue.core import Data
from glue_qt.app.application import GlueApplication
from glue_qt.viewers.table import TableViewer
from qtpy import QtWidgets
from qtpy.QtTest import QTest
SHOTS = Path(__file__).parent / "shots"
app = GlueApplication(); app.show()
d = Data(label="slopes", start=np.array(["2021-09-05T00:00:00.000"]), speed=[12.5])
app.data_collection.append(d)
v = app.new_data_viewer(TableViewer, data=d)
QTest.qWait(300)
tb = v.toolbar
tb.grab().save(str(SHOTS / "plain-table-toolbar.png"))
v.grab().save(str(SHOTS / "plain-table.png"))
for tid, a in tb.actions.items():
    t = tb.tools[tid]; b = tb.widgetForAction(a)
    m = b.menu() if isinstance(b, QtWidgets.QToolButton) else None
    print(tid, type(t).__module__, repr(a.text()), repr(a.toolTip()), repr(b.toolTip() if b else None), t.shortcut, a.isCheckable(),
          [x.text() for x in m.actions()] if m else None, flush=True)
os._exit(0)
