"""Table viewer on datetime data with or without glue-solar; matplotlib keys over a Profile plot."""
import json
import os
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).parent
WITH = sys.argv[1] == "with"
OUT = {"with_glue_solar": WITH}
if WITH:
    import glue_solar

    glue_solar.setup()
from glue.core import Data
from glue_qt.app.application import GlueApplication
from glue_qt.viewers.profile import ProfileViewer
from glue_qt.viewers.table import TableViewer
from matplotlib.backend_bases import KeyEvent
from qtpy import QtWidgets
from qtpy.QtTest import QTest

MSG = []


def _fake_exec(self, *a):
    MSG.append(self.text())
    return 0


QtWidgets.QMessageBox.exec = QtWidgets.QMessageBox.exec_ = _fake_exec
app = GlueApplication()
app.show()
OUT["glue_solar_loaded"] = "glue_solar" in sys.modules
d = Data(label="times", Time=np.array(["2021-09-05T00:00", "2021-09-05T00:01"], "datetime64[ns]"), Value=[1.0, 2.0])
app.data_collection.append(d)
tv = app.new_data_viewer(TableViewer, data=d)
QTest.qWait(300)
OUT["table_opened"] = tv is not None
OUT["messages"] = list(MSG)

# matplotlib keys with the mouse over the axes of a Profile viewer
p = Data(label="p", y=np.arange(1.0, 11.0))
app.data_collection.append(p)
pv = app.new_data_viewer(ProfileViewer, data=p)
QTest.qWait(500)
canvas = pv.figure.canvas
x, y = pv.axes.transAxes.transform((0.5, 0.5))
keys = {}
for key in (("l", "k", "g", "q", "s", "f", "p", "o", "c") if WITH else ("l",)):
    before = (pv.axes.get_yscale(), pv.axes.get_xscale(), pv.state.y_log, pv.state.x_log, pv.axes.xaxis._major_tick_kw.get("gridOn"))
    canvas.callbacks.process("key_press_event", KeyEvent("key_press_event", canvas, key, x, y))
    QTest.qWait(100)
    after = (pv.axes.get_yscale(), pv.axes.get_xscale(), pv.state.y_log, pv.state.x_log, pv.axes.xaxis._major_tick_kw.get("gridOn"))
    keys[key] = {"changed": before != after, "after": after, "viewer_alive": not pv._closed,
                 "windows": [type(w).__name__ for w in QtWidgets.QApplication.topLevelWidgets() if w.isVisible()]}
OUT["mpl_keys_over_profile(yscale,xscale,state.y_log,state.x_log,grid)"] = keys
(HERE / f"probe3-{sys.argv[1]}.json").write_text(json.dumps(OUT, indent=1, default=str))
os._exit(0)
