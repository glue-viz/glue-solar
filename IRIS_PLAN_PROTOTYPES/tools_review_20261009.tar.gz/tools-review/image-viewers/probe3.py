# Part 3, exec'd inside probe.py: grid key, toolbar-focus keys, Coordinate entries with a point (read-only probe)
import builtins
import json as _json

from qtpy import QtCore as _C, QtWidgets as _W
from qtpy.QtTest import QTest as _T

P = builtins._probe
app, plain, ql, ql2, pump = P["app"], P["plain"], P["ql"], P["ql2"], P["pump"]
out = {"messages": []}
_m = out["messages"]
for _name in ("critical", "warning", "information", "question"):
    setattr(_W.QMessageBox, _name, staticmethod(
        lambda parent, title, text, *a, _n=_name, **k: _m.append(f"{_n}: {title}: {str(text)[:200]}") or _W.QMessageBox.StandardButton.Ok))
_W.QMessageBox.exec = lambda self: (_m.append(f"box: {self.windowTitle()}: {self.text()[:200]}") or _W.QMessageBox.StandardButton.Ok)

viewer = plain["plain_sji"]
app.current_tab.setActiveSubWindow(viewer.parent())
canvas = viewer.figure.canvas
coord = viewer.axes.coords[0]
out["grid_before"] = bool(coord.grid_lines_kwargs.get("visible", False)) if hasattr(coord, "grid_lines_kwargs") else None
_T.mouseMove(canvas, canvas.rect().center())
_T.keyClick(canvas, _C.Qt.Key.Key_G)
pump(2)
out["grid_after_g"] = [bool(getattr(c, "grid_lines_kwargs", {}).get("visible", False)) for c in viewer.axes.coords]
out["grid_draw_flags"] = [getattr(c, "_grid_lines", None) is not None for c in viewer.axes.coords]

# toolbar-focused keys, with the window activated
app.activateWindow()
_W.QApplication.setActiveWindow(app) if hasattr(_W.QApplication, "setActiveWindow") else None
tb = viewer.toolbar
res = {}
for key in "HMZRXYCGULP":
    tb.active_tool = None
    tb.setFocus()
    pump(2)
    focus = _W.QApplication.focusWidget()
    _T.keyClick(tb, getattr(_C.Qt.Key, "Key_" + key))
    pump(2)
    res[key] = {"tool": getattr(tb.active_tool, "tool_id", None), "focus_is_toolbar": focus is tb,
                "focus": type(focus).__name__ if focus else None}
tb.active_tool = None
out["toolbar_keys"] = res

# Coordinate entries with the quicklook's point in place
def entry(v, text):
    tbar = v.toolbar
    menu = tbar.widgetForAction(tbar.actions["solar:coordinate"]).menu()
    menu.aboutToShow.emit()
    action = next(a for a in menu.actions() if a.text() == text)
    n_data, n_viewers, start = len(app.data_collection), sum(len(t) for t in app.viewers), len(_m)
    action.trigger()
    pump(5)
    return {"new_data": len(app.data_collection) - n_data, "new_viewers": sum(len(t) for t in app.viewers) - n_viewers,
            "messages": _m[start:]}


if ql:
    out["ql_sns_map: Light curve at the point"] = entry(ql["map"], "Light curve at the point")
    out["ql_sns_map: Light curves at this point (windows, SJI)"] = entry(ql["map"], "Light curves at this point (windows, SJI)")
    out["ql_sns_sji1: Light curve at the point"] = entry(ql["sji"][1], "Light curve at the point")
if ql2:
    out["ql_stack_map: Light curve at the point"] = entry(ql2["map"], "Light curve at the point")
sot = plain.get("plain_sot")
if sot is not None:
    from glue_solar.quicklook import coordinator as _coord, observation_key as _key  # noqa: E402

    c = _coord(app.data_collection)
    out["plain_sot: Time master"] = entry(sot, "Time master")
    out["plain_sot master set"] = str(c.masters.get(_key(sot.state.reference_data)))[:120]
    out["plain_sot: Raster overlays"] = entry(sot, "Raster overlays")
    out["plain_sot: Blink (no partner)"] = entry(sot, "Blink")
(OUT / "probe3.json").write_text(_json.dumps(out, indent=1, default=str))
print("done part 3", flush=True)
