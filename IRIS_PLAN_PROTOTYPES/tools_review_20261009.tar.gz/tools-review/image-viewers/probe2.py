# Part 2, exec'd inside probe.py: keys and what each menu entry does on each data kind (read-only probe)
import builtins
import json as _json

from qtpy import QtCore as _C, QtWidgets as _W
from qtpy.QtTest import QTest as _T

P = builtins._probe
app, plain, ql, pump, report = P["app"], P["plain"], P["ql"], P["pump"], P["report"]
part2 = {"keys": {}, "entries": {}, "messages": []}

# ---- capture dialogs instead of showing them
_messages = part2["messages"]


def _box_exec(self):
    _messages.append({"title": self.windowTitle(), "text": self.text()[:300], "info": self.informativeText()[:300]})
    return _W.QMessageBox.StandardButton.Ok


_W.QMessageBox.exec = _box_exec
_W.QMessageBox.exec_ = _box_exec
for _name in ("critical", "warning", "information", "question"):
    setattr(_W.QMessageBox, _name, staticmethod(
        lambda parent, title, text, *a, _n=_name, **k: _messages.append({"title": title, "text": str(text)[:300], "kind": _n})
        or _W.QMessageBox.StandardButton.Ok))
_W.QInputDialog.getText = staticmethod(lambda *a, **k: (_messages.append({"input": "getText", "args": [str(x) for x in a[1:3]], "default": k.get("text")}) or ("", False)))
_W.QInputDialog.getItem = staticmethod(lambda *a, **k: (_messages.append({"input": "getItem", "args": [str(x) for x in a[1:5]]}) or ("", False)))
_W.QFileDialog.getSaveFileName = staticmethod(lambda *a, **k: (_messages.append({"input": "getSaveFileName", "args": [str(x) for x in a[1:4]]}) or ("", "")))
_W.QFileDialog.getOpenFileName = staticmethod(lambda *a, **k: (_messages.append({"input": "getOpenFileName", "args": [str(x) for x in a[1:4]]}) or ("", "")))
_W.QDialog.exec = lambda self: (_messages.append({"dialog": self.windowTitle()}) or 0)
_W.QDialog.exec_ = _W.QDialog.exec

# ---- every Coordinate / View / Modes entry, triggered on each plain viewer and the quicklook map and SJI panel
targets = dict(plain)
if ql:
    targets["ql_sns_map"] = ql["map"]
    targets["ql_sns_sji1"] = ql["sji"][1]
    targets["ql_sns_spectrogram"] = ql["spectrogram"]
skip = {"Blink"}  # starts a timer; tested separately
for name, viewer in targets.items():
    rows = []
    tb = viewer.toolbar
    for menu_id in ("solar:coordinate", "solar:view", "solar:modes", "save"):
        button = tb.widgetForAction(tb.actions[menu_id])
        menu = button.menu()
        menu.aboutToShow.emit()
        for action in menu.actions():
            if action.menu() is not None or action.isSeparator() or not action.isVisible():
                continue
            text = action.text()
            if text in skip or text in ("Save plot to file", "Save Python script to reproduce plot"):
                continue
            start = len(_messages)
            app.statusBar().clearMessage()
            viewer.set_status("")
            before_tool = getattr(tb.active_tool, "tool_id", None)
            n_data, n_viewers = len(app.data_collection), sum(len(t) for t in app.viewers)
            try:
                action.trigger()
                pump(3)
                error = None
            except Exception as exc:  # noqa: BLE001
                error = repr(exc)[:300]
            rows.append({
                "menu": menu_id, "entry": text, "error": error,
                "dialogs": _messages[start:],
                "app_status": app.statusBar().currentMessage()[:200],
                "viewer_status": viewer.statusBar().currentMessage()[:200],
                "tool_before": before_tool, "tool_after": getattr(tb.active_tool, "tool_id", None),
                "checked_after": action.isChecked() if action.isCheckable() else None,
                "new_data": len(app.data_collection) - n_data,
                "new_viewers": sum(len(t) for t in app.viewers) - n_viewers,
            })
            # undo toggles so the next entry starts from the default
            if action.isCheckable() and action.isChecked() and menu_id == "solar:view":
                action.trigger()
                pump(2)
            if menu_id == "solar:modes":
                tb.active_tool = None
    part2["entries"][name] = rows

# ---- keys over the canvas of the plain slit-jaw viewer
viewer = plain.get("plain_sji")
if viewer is not None:
    sub = viewer.parent()
    app.current_tab.setActiveSubWindow(sub)
    canvas = viewer.central_widget.canvas if hasattr(viewer, "central_widget") else viewer.figure.canvas
    canvas.setFocus()
    pump(2)
    axes = viewer.axes

    def snap():
        s = viewer.state
        return {
            "slices": str(s.slices), "yscale": axes.get_yscale(), "xscale": axes.get_xscale(),
            "grid": any(line.get_visible() for line in axes.get_xgridlines()) if hasattr(axes, "get_xgridlines") else None,
            "limits": [round(v, 1) if v is not None else None for v in (s.x_min, s.x_max, s.y_min, s.y_max)],
            "tool": getattr(viewer.toolbar.active_tool, "tool_id", None),
            "closed": viewer.parent() is None or not viewer.isVisible(),
            "readout": viewer.axes.format_coord(30, 30)[:80],
        }

    centre = canvas.rect().center()
    for key, mod in [("d", None), ("f", None), ("a", None), ("s", None), ("space", None), ("l", None),
                     ("L", "shift"), ("k", None), ("g", None), ("G", "shift"), ("o", None), ("p", None), ("h", None),
                     ("r", None), ("c", None), ("v", None), ("w", None), ("u", None), ("q", None), ("tab", None)]:
        before = snap()
        _T.mouseMove(canvas, centre)
        qt_key = {"space": _C.Qt.Key.Key_Space, "tab": _C.Qt.Key.Key_Tab}.get(key) or getattr(_C.Qt.Key, "Key_" + key.upper())
        modifier = _C.Qt.KeyboardModifier.ShiftModifier if mod == "shift" else _C.Qt.KeyboardModifier.NoModifier
        try:
            _T.keyClick(canvas, qt_key, modifier)
            pump(3)
            err = None
        except Exception as exc:  # noqa: BLE001
            err = repr(exc)[:200]
        after = snap()
        part2["keys"][f"canvas:{key}"] = {"changed": {k: (before[k], after[k]) for k in before if before[k] != after[k]}, "error": err}
        # restore
        if after["yscale"] != "linear":
            axes.set_yscale("linear")
        if after["xscale"] != "linear":
            axes.set_xscale("linear")
        # stop playback started by Space
        for s in viewer.options_widget().slice_helper._sliders:
            if s is not None and s._play_timer.isActive():
                s.button_stop.click()
    # toolbar-focused letter keys
    tb = viewer.toolbar
    for key in "HMZRXYCGUL P".replace(" ", ""):
        tb.setFocus()
        pump(1)
        viewer.toolbar.active_tool = None
        _T.keyClick(tb, getattr(_C.Qt.Key, "Key_" + key))
        pump(2)
        part2["keys"][f"toolbar:{key}"] = getattr(viewer.toolbar.active_tool, "tool_id", None)
    viewer.toolbar.active_tool = None

# Backspace over a throwaway viewer
from glue_qt.viewers.image import ImageViewer as _IV  # noqa: E402

throw = app.new_data_viewer(_IV, data=P["sns_sjis"][0])
pump(3)
app.current_tab.setActiveSubWindow(throw.parent())
start = len(_messages)
_T.keyClick(throw.figure.canvas, _C.Qt.Key.Key_Backspace)
pump(3)
part2["keys"]["canvas:backspace"] = {"dialogs": _messages[start:], "still_open": throw.isVisible()}

from glue_qt.config import qt_client  # noqa: E402

part2["new_viewer_types"] = [getattr(c, "LABEL", c.__name__) + f" ({c.__module__}.{c.__name__})" for c in qt_client.members]
from glue_qt.viewers.image import ImageViewer as _IV2  # noqa: E402

part2["cursor_status_in_glue_qt"] = hasattr(_IV2, "cursor_status")
part2["image_viewer_tools"] = list(_IV2.tools)
part2["image_viewer_subtools"] = {k: list(v) for k, v in _IV2.subtools.items()}
(OUT / _os.environ.get("PROBE2_JSON", "probe2.json")).write_text(_json.dumps(part2, indent=1, default=str))
print("done part 2", flush=True)
