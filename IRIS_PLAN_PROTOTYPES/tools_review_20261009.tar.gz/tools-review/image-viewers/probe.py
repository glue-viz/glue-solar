"""Headless inventory of glue-solar Image viewer toolbars, menus and keys (read-only probe)."""

import json
import sys
import traceback
import types
import warnings
from pathlib import Path

# the checkout has no generated version.py
_version = types.ModuleType("glue_solar.version")
_version.version = "main-probe"
sys.modules["glue_solar.version"] = _version

OUT = Path(sys.argv[1])
SHOTS = OUT / "shots"
SHOTS.mkdir(parents=True, exist_ok=True)
caught = []
warnings.simplefilter("always")
_showwarning = warnings.showwarning
warnings.showwarning = lambda m, c, f, l, *a, **k: caught.append(f"{c.__name__}: {m} ({Path(f).name}:{l})")

from qtpy import QtCore, QtGui, QtWidgets  # noqa: E402
from qtpy.QtTest import QTest  # noqa: E402

from glue_qt.app.application import GlueApplication  # noqa: E402

import glue_solar  # noqa: E402

from glue.config import viewer_tool  # noqa: E402
from glue_qt.config import keyboard_shortcut  # noqa: E402
from glue_qt.viewers.image import ImageViewer  # noqa: E402
from irispy.data.test import ROOTDIR  # noqa: E402

from glue_solar.quicklook import QuicklookImageViewer, quicklook  # noqa: E402
from glue_solar.sources.loaders.iris import image_data, raster_data  # noqa: E402

import os as _os
app = GlueApplication()  # loads every plugin, glue_solar:setup included, in entry-point order, as `glue` does
glue_solar.setup()  # again: idempotent
app.resize(*map(int, _os.environ.get("APP_SIZE", "1600x1000").split("x")))
app.show()
qapp = QtWidgets.QApplication.instance()


def pump(n=5):
    for _ in range(n):
        qapp.processEvents()


pump()
print("glue_solar from", glue_solar.__file__, flush=True)


def provider(obj):
    mod = type(obj).__module__
    return "glue-solar" if mod.startswith("glue_solar") else "glue-qt" if mod.startswith("glue_qt") else (
        "glue-core" if mod.startswith("glue") else mod)


def menu_entries(menu, prefix, shots_name=None):
    rows = []
    for action in menu.actions():
        row = {
            "text": action.text(),
            "separator": action.isSeparator(),
            "visible": action.isVisible(),
            "enabled": action.isEnabled(),
            "checkable": action.isCheckable(),
            "checked": action.isChecked(),
            "shortcut": action.shortcut().toString(),
            "tooltip": action.toolTip(),
            "icon": not action.icon().isNull(),
        }
        if action.menu() is not None:
            row["submenu"] = menu_entries(action.menu(), prefix + " > " + action.text())
        rows.append(row)
    return {"path": prefix, "tooltips_visible": menu.toolTipsVisible(), "entries": rows}


def shoot_menu(menu, name):
    try:
        menu.aboutToShow.emit()
        menu.popup(QtCore.QPoint(10, 10))
        pump(3)
        menu.grab().save(str(SHOTS / f"{name}.png"))
        menu.hide()
        pump(2)
    except Exception as error:  # noqa: BLE001
        print("shot failed", name, error)


def walk(viewer, name, shoot=True):
    tb = viewer.toolbar
    tools_by_action = {id(action): tid for tid, action in tb.actions.items()}
    pump()
    record = {
        "name": name,
        "class": type(viewer).__name__,
        "data": getattr(viewer.state.reference_data, "label", None),
        "ndim": getattr(viewer.state.reference_data, "ndim", None),
        "viewer_size": [viewer.width(), viewer.height()],
        "toolbar_size": [tb.width(), tb.height()],
        "active_tool": getattr(tb.active_tool, "tool_id", None),
        "viewer_enabled": viewer.isEnabled(),
        "toolbar_enabled": tb.isEnabled(),
        "title": viewer.state.title,
        "aspect": viewer.state.aspect,
        "buttons": [],
    }
    for action in QtWidgets.QToolBar.actions(tb):
        tid = tools_by_action.get(id(action))
        tool = tb.tools.get(tid)
        widget = tb.widgetForAction(action)
        row = {
            "tool_id": tid,
            "provider": provider(tool) if tool else None,
            "class": type(tool).__name__ if tool else None,
            "text": action.text() or (widget.text() if hasattr(widget, "text") else ""),
            "action_text": getattr(tool, "action_text", None),
            "icon": getattr(tool, "icon", None),
            "action_tooltip": action.toolTip(),
            "button_tooltip": widget.toolTip() if widget is not None else None,
            "shortcut": action.shortcut().toString(),
            "tool_shortcut": getattr(tool, "shortcut", None),
            "status_tip": getattr(tool, "status_tip", None),
            "checkable": action.isCheckable(),
            "visible_action": action.isVisible(),
            "enabled": action.isEnabled(),
            "on_bar": bool(widget is not None and widget.isVisible()),
            "kind": type(tool).__mro__[1].__name__ if tool else None,
        }
        menu = widget.menu() if isinstance(widget, QtWidgets.QToolButton) else None
        row["widget_enabled"] = bool(widget is not None and widget.isEnabled())
        if menu is not None:
            menu.aboutToShow.emit()
            row["menu_enabled"] = menu.isEnabled()
            row["menu"] = menu_entries(menu, f"{name} toolbar > {tid}")
            if shoot:
                shoot_menu(menu, f"{name}__menu_{tid.replace(':', '_')}")
        record["buttons"].append(row)
    if shoot:
        tb.grab().save(str(SHOTS / f"{name}__toolbar.png"))
        viewer.grab().save(str(SHOTS / f"{name}__viewer.png"))
    return record


report = {"warnings": caught, "viewers": [], "errors": []}


def attempt(label, function, *args, **kwargs):
    try:
        return function(*args, **kwargs)
    except Exception:  # noqa: BLE001
        report["errors"].append({"where": label, "trace": traceback.format_exc()})
        print("ERROR", label, traceback.format_exc(), flush=True)
        return None


# -------- data
sns_dir = ROOTDIR / "sns"
sns_raster = raster_data([next(sns_dir.glob("*raster*.fits"))])
sns_sjis = [image_data(p) for p in sorted(sns_dir.glob("*SJI*.fits"))]
scan_files = sorted((ROOTDIR / "raster" / "iris_l2_20140329_140938_3860258481_raster").glob("*.fits"))
scan_r0 = raster_data(scan_files[:1])
stack = raster_data(scan_files, stack=True)
sot = [image_data(p) for p in sorted((ROOTDIR / "sot").glob("*.fits"))]
report["datasets"] = {
    "sns_raster": [(d.label, d.shape) for d in sns_raster],
    "sns_sjis": [(d.label, d.shape) for d in sns_sjis],
    "scan_r0": [(d.label, d.shape) for d in scan_r0],
    "stack": [(d.label, d.shape) for d in stack],
    "sot": [(d.label, d.shape) for d in sot],
}
print(json.dumps(report["datasets"], default=str), flush=True)
dc = app.data_collection

# -------- quicklook of the sit-and-stare observation
ql = attempt("quicklook sns", quicklook, app, [*sns_raster, *sns_sjis])
pump(10)
if ql:
    report["quicklook_sns_tab"] = {"tab": app.tab_names[app.tab_count - 1], "geometry": {}}
    for role in ("map", "spectrogram", "wavelength"):
        if role in ql:
            report["viewers"].append(walk(ql[role], f"ql_sns_{role}"))
    for i, v in enumerate(ql["sji"]):
        report["viewers"].append(walk(v, f"ql_sns_sji{i}", shoot=(i == 0)))
    for i, panels in enumerate(ql["windows"]):
        if "wavelength" in panels:
            report["viewers"].append(walk(panels["wavelength"], f"ql_sns_window{i}_wavelength", shoot=(i == 0)))
    app.current_tab.grab().save(str(SHOTS / "ql_sns__tab.png"))

# -------- quicklook of the stack (scanning raster)
ql2 = attempt("quicklook stack", quicklook, app, list(stack))
pump(10)
if ql2:
    for role in ("map", "spectrogram", "wavelength"):
        if role in ql2:
            report["viewers"].append(walk(ql2[role], f"ql_stack_{role}"))
    app.current_tab.grab().save(str(SHOTS / "ql_stack__tab.png"))

# -------- plain Image viewers, by data kind
app.new_tab()
plain = {}


def plain_viewer(name, data, x=None, y=None):
    if data not in dc:
        dc.append(data)
    viewer = app.new_data_viewer(ImageViewer, data=data)
    if x is not None:
        viewer.state.x_att = data.pixel_component_ids[x]
        viewer.state.y_att = data.pixel_component_ids[y]
    viewer.parent().resize(760, 620)
    pump(5)
    plain[name] = viewer
    return viewer


kinds = [
    ("plain_sns_raster", sns_raster[0]),
    ("plain_scan_raster", scan_r0[0]),
    ("plain_stack", stack[0]),
    ("plain_sji", sns_sjis[1]),
    ("plain_sot", sot[0]),
]
for name, data in kinds:
    v = attempt(name, plain_viewer, name, data)
    if v is not None:
        report["viewers"].append(walk(v, name, shoot=name in ("plain_sns_raster", "plain_sji", "plain_sot")))

# a derived 2D map: line moments of a raster window
from glue_solar.sources import moments as _moments  # noqa: E402

si_iv = next((d for d in scan_r0 if "Si_IV_1403" in d.label), scan_r0[0])
centre = 1402.77 if "Si_IV_1403" in si_iv.label else None
mom = attempt("line_moments", _moments.line_moments, si_iv, centre or 2796.35) if centre else None
if mom is None:
    mg = next((d for d in scan_r0 if "Mg_II_k" in d.label), None)
    mom = attempt("line_moments mg", _moments.line_moments, mg, 2796.35) if mg is not None else None
if mom is not None:
    report["derived"] = (mom.label, mom.shape)
    v = attempt("plain_moments", plain_viewer, "plain_moments", mom)
    if v is not None:
        report["viewers"].append(walk(v, "plain_moments"))

# a path diagram, drawn on the slit-jaw viewer
if "plain_sji" in plain:
    v = plain["plain_sji"]
    tool = v.toolbar.tools["solar:path"]
    import numpy as np  # noqa: E402

    x = np.linspace(20, 80, 61)
    y = np.linspace(20, 50, 61)
    attempt("path extract", tool._extract, x, y, "truncate")
    pump(10)
    diagram_viewer = tool._slice_viewer
    if diagram_viewer is not None:
        report["viewers"].append(walk(diagram_viewer, "plain_path_diagram"))
        plain["plain_path_diagram"] = diagram_viewer

# north up of the slit-jaw image
from glue_solar import regrid  # noqa: E402

before = set(id(w) for tab in app.viewers for w in tab)
attempt("north_up", regrid.north_up_iris, sns_sjis[1], dc)
pump(5)
new = [w for tab in app.viewers for w in tab if id(w) not in before]
if new:
    report["viewers"].append(walk(new[-1], "plain_north_up", shoot=False))

# -------- keys
report["keyboard_shortcuts"] = {
    cls.__name__: sorted(QtGui.QKeySequence(k).toString() + f" -> {getattr(f, '__name__', None) or getattr(getattr(f, 'func', None), '__name__', repr(f))}"
                         for k, f in keyboard_shortcut.members.get(cls, {}).items())
    for cls in (ImageViewer, QuicklookImageViewer)
}
report["tool_shortcuts"] = sorted(
    (cls.shortcut, tid, cls.__module__) for tid, cls in viewer_tool.members.items() if getattr(cls, "shortcut", None)
)
import matplotlib  # noqa: E402

report["mpl_keymaps"] = {k: v for k, v in matplotlib.rcParams.items() if k.startswith("keymap")}
report["warnings"] = caught
(OUT / _os.environ.get("PROBE_JSON", "probe1.json")).write_text(json.dumps(report, indent=1, default=str))
print("done part 1", flush=True)

# keep objects for part 2 (key tests) in this process
import builtins  # noqa: E402

builtins._probe = dict(app=app, ql=ql, ql2=ql2, plain=plain, report=report, pump=pump, sns_sjis=sns_sjis)
if len(sys.argv) > 2:
    exec(Path(sys.argv[2]).read_text())
import os  # noqa: E402

os._exit(0)
