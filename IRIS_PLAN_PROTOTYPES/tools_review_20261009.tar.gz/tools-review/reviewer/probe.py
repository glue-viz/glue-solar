"""Reviewer re-probe of doubtful inventory entries (read-only, headless)."""

import json
import sys
import types
from pathlib import Path

_version = types.ModuleType("glue_solar.version")
_version.version = "review-probe"
sys.modules["glue_solar.version"] = _version

OUT = Path(sys.argv[1])
SHOTS = OUT / "shots"
SHOTS.mkdir(parents=True, exist_ok=True)

import numpy as np  # noqa: E402
from qtpy import QtWidgets  # noqa: E402

from glue.core import Data  # noqa: E402
from glue_qt.app.application import GlueApplication  # noqa: E402
from glue_qt.config import qt_client  # noqa: E402
from glue_qt.viewers.image import ImageViewer  # noqa: E402
from irispy.data.test import ROOTDIR  # noqa: E402

import glue_solar  # noqa: E402
from glue_solar.quicklook import quicklook  # noqa: E402
from glue_solar.sources.loaders.iris import image_data, raster_data  # noqa: E402

app = GlueApplication()
glue_solar.setup()
app.resize(1600, 1000)
app.show()
qapp = QtWidgets.QApplication.instance()
R = {"glue_solar": glue_solar.__file__}


def pump(n=5):
    for _ in range(n):
        qapp.processEvents()


def order(viewer):
    """Tool ids in toolbar order, with whether each is a menu."""
    toolbar = viewer.toolbar
    by_action = {id(a): tid for tid, a in toolbar.actions.items()}
    out = []
    for a in QtWidgets.QToolBar.actions(toolbar):  # glue-qt shadows QToolBar.actions with its dict
        tid = by_action.get(id(a))
        if tid is not None and tid in viewer.tools:
            out.append(tid)
    return out


def menu_entries(viewer, tool_id):
    toolbar = viewer.toolbar
    button = toolbar.widgetForAction(toolbar.actions[tool_id])
    menu = button.menu()
    entries = []
    for a in menu.actions():
        if a.isSeparator():
            continue
        entries.append({
            "text": a.text(), "visible": a.isVisible(), "enabled": a.isEnabled(),
            "checkable": a.isCheckable(), "checked": a.isChecked(), "key": a.shortcut().toString(),
            "submenu": [s.text() for s in a.menu().actions()] if a.menu() else None,
        })
    return {"button_tooltip": button.toolTip(), "tooltips_visible": menu.toolTipsVisible(), "entries": entries}


def shoot_menu(viewer, tool_id, name):
    toolbar = viewer.toolbar
    button = toolbar.widgetForAction(toolbar.actions[tool_id])
    menu = button.menu()
    menu.popup(button.mapToGlobal(button.rect().bottomLeft()))
    pump(3)
    menu.grab().save(str(SHOTS / name))
    menu.hide()
    pump(2)


R["new_data_viewer_list"] = [c.__name__ for c in qt_client.members]

# --- sit-and-stare quicklook: the spectrogram's Wavelength band entry
sns_dir = ROOTDIR / "sns"
sns_raster = raster_data([next(sns_dir.glob("*raster*.fits"))])
sns_sjis = [image_data(p) for p in sorted(sns_dir.glob("*SJI*.fits"))]
ql = quicklook(app, [*sns_raster, *sns_sjis])
pump(10)
spec = ql["spectrogram"]
band = spec.toolbar.tools["solar:band"]
before = list(spec.state.slices)
QtWidgets.QInputDialog.getItem = staticmethod(lambda *a, **k: ("9", True))
band.activate()
pump(5)
R["spectrogram_band"] = {
    "title": spec.windowTitle() if hasattr(spec, "windowTitle") else None,
    "enabled": band.enabled, "checked_before_after": None,
    "slices_before": [str(s) for s in before], "slices_after": [str(s) for s in spec.state.slices],
    "x_att": str(spec.state.x_att), "y_att": str(spec.state.y_att),
}
R["ql_map_order"] = order(ql["map"])
R["ql_panel_titles"] = {k: ql[k].parent().windowTitle() for k in ("map", "spectrogram", "wavelength")}
R["ql_sji_titles"] = [v.parent().windowTitle() for v in ql["sji"]]
R["ql_map_view_menu"] = menu_entries(ql["map"], "solar:view")
R["ql_spectrogram_view_menu"] = menu_entries(spec, "solar:view")

# --- a plain 2-D array with no coordinates: which entries still show
app.new_tab()
flat = Data(label="flat2d", x=np.random.rand(20, 30))
app.data_collection.append(flat)
v = app.new_data_viewer(ImageViewer, data=flat)
v.parent().resize(760, 620)
pump(8)
R["flat2d_order"] = order(v)
R["flat2d_menus"] = {tid: menu_entries(v, tid) for tid in ("solar:modes", "solar:coordinate", "solar:view", "save")}
ft = v.toolbar.tools["solar:frame_time"]
R["flat2d_frame_time"] = {"checked": ft.checked, "label": ft.label.text() if hasattr(ft, "label") else None}
R["flat2d_tools_enabled"] = {tid: t.enabled for tid, t in v.toolbar.tools.items()}
for tid, name in (("solar:coordinate", "flat2d_menu_coordinate.png"), ("solar:view", "flat2d_menu_view.png"),
                  ("solar:modes", "flat2d_menu_modes.png")):
    shoot_menu(v, tid, name)
v.toolbar.grab().save(str(SHOTS / "flat2d_toolbar.png"))

# --- the Coordinate entries on the plain viewer: which error, which do nothing
LOG = []
for n in ("information", "warning", "critical"):
    setattr(QtWidgets.QMessageBox, n, staticmethod(lambda *a, _n=n, **k: (LOG.append((_n, str(a[1]), str(a[2])[:120])), 0)[1]))
QtWidgets.QMessageBox.exec = lambda self: (LOG.append(("exec", self.windowTitle(), self.text()[:120])), 0)[1]
QtWidgets.QInputDialog.getText = staticmethod(lambda *a, **k: ("", False))
outcomes = {}
for tid in ("solar:time_master", "solar:clear_point", "solar:go_to_utc", "solar:loop", "solar:raster_overlays",
            "solar:light_curve", "solar:point_curves", "solar:blink_partner", "solar:blink"):
    n0 = len(LOG)
    try:
        v.toolbar.tools[tid].activate()
        pump(3)
        outcomes[tid] = {"result": "ran", "messages": LOG[n0:]}
    except Exception as e:  # noqa: BLE001
        outcomes[tid] = {"result": f"raised {type(e).__name__}: {str(e)[:140]}", "messages": LOG[n0:]}
R["flat2d_coordinate_outcomes"] = outcomes

(OUT / "probe.json").write_text(json.dumps(R, indent=1, ensure_ascii=False, default=str))
print(json.dumps(R, indent=1, ensure_ascii=False, default=str))
