import json
import sys

R = sys.argv[1]
im = json.load(open(f"{R}/image-viewers/probe1.json"))
for v in im["viewers"]:
    off = [b["tool_id"] for b in v["buttons"] if not b.get("on_bar", True)]
    print(f"{v['name']:28s} {v['class']:22s} size={v['viewer_size']} tools={len(v['buttons'])} overflow={len(off)}: {off}")
print("keyboard_shortcuts:", json.dumps(im["keyboard_shortcuts"], ensure_ascii=False)[:700])
for size in ("size1280x800", "size1920x1080", "size2560x1440"):
    try:
        d = json.load(open(f"{R}/image-viewers/{size}/probe1.json"))
    except Exception:
        try:
            import glob
            d = json.load(open(glob.glob(f"{R}/image-viewers/{size}/*.json")[0]))
        except Exception as e:
            print(size, "no json", e)
            continue
    for v in d["viewers"]:
        if v["name"].startswith("ql_sns"):
            off = [b["tool_id"] for b in v["buttons"] if not b.get("on_bar", True)]
            print(f"  {size} {v['name']:24s} width={v['viewer_size'][0]} overflow={len(off)}: {off}")
