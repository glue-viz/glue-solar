# glue-solar main (7640306): tools and layout review

Scope: glue-solar origin/main as a user sees it in glue (glue-core 1.27.0, glue-qt 0.4.2, PyQt6, env iris-plan-qt6), from three live inventories (Image viewers, Profile and other viewers, application level) plus my own re-probe of the disputed entries. No repository was edited; the detached worktree is removed.

**Verified and corrected before writing**

- The data-collection right-click menu on any one dataset shows **25 entries, 14 of them glue-solar's** (the application inventory said 13: it left out "IRIS: line ratio diagnostic…", whose `single=False` makes it show for any non-empty selection, including a subset group). Source: `app/probe.json` context_menu, all five data kinds.
- X range and Y range *are* named in the docs (Profile guide; X range also in the loading page); Rectangular, Circular and Polygonal ROI are not. The Image inventory's "not named" was wrong for X and Y range.
- The Profile inventory's "glue-solar adds Y range to the quicklook's wavelength panel" is wrong: `quicklook.py` never touches `select:yrange`; the panel is an Image viewer and has it anyway.
- Re-probed on the sit-and-stare quicklook: "Wavelength band…" on the spectrogram is enabled, its dialog accepts 9, and `state.slices` stays (93, 20, 11): the entry does nothing where wavelength is an image axis.
- Re-probed on a 20×30 array with no coordinates (`flat2d`): all 10 Coordinate entries are visible; Modes hides everything but Measure; View hides only Wavelength band; "Frame time" is ticked with an empty label. The Coordinate entries are also not registered in `toolbar.tools` (unlike the Modes and View entries, `_ToolMenu._add_entries`, tools.py:2600-2612), so scripts and the key machinery cannot reach them by id.
- Toolbar order confirmed: …, profile-viewer, **slice**, Follow/lock, Modes, Coordinate, View, both on a plain viewer and every quicklook panel.

---

## 1. Counts

### By surface

| Surface | Top-level controls | Menu entries (radio options) | glue-solar share |
|---|---|---|---|
| Image viewer toolbar (plain 2D Image and every quicklook panel) | 18 buttons: 8 glue-qt, 6 glue-core, 4 glue-solar | 31 in 5 menus + 2 submenus (7 radio) | 4 buttons, 27 entries, 7 options |
| Profile viewer toolbar (quicklook spectrum, light-curve Profile, plain) | 9: 7 glue, 2 glue-solar | Save 3, Window 2; Options panel 3 tabs, 3 fitters, 7 collapse functions; x unit list 132 | 2 buttons, 1 save entry, 1 fitter, 1 unit |
| Scatter | 10 | Save 2, Window 2 | 0 (the "Light curves at the point" Scatter is glue's own) |
| Histogram | 6 | 4 | 0 |
| Table | 2 | 2 | 0 |
| Main menu bar | 7 menus: File 8 (+Import data 2), Edit 2, View 1, Canvas 5, Data Manager 33 (+Paste Special 4), Plugins 6, Help 3 | | 5 Plugins entries; nothing in File, View, Help |
| Main-window toolbars | 3 toolbars, 14 controls | | 0 |
| Data collection right-click | 33 actions (+4 Paste Special) | visible: nothing 4, one dataset 25, subset group 8, two datasets 5 | 14 actions (9 with "IRIS: ", 5 without) |
| File > Open data types | 20 factories, 19 listed | | 2 (IRIS Level 2 FITS, sunpy Map), listed 18th and 19th |
| Export formats | 9 | | 2 (+ the function behind glue's "FITS (1 component/HDU)" swapped) |
| Importers | 2 | | 0 |
| Startup / close | 1 startup action, 1 close hook | | both |
| Keys (app level) | Image/Quicklook 7, Profile 5, Scatter 2, Histogram 2, DataTableModel 2 | | D F A S Space on 3 viewer classes |
| Keys (toolbar focus) | Image 11 (H M Z R X Y C G P U L), Scatter 8, Profile/Histogram 4 | | U, L |
| Keys (canvas) | Enter, Esc per mode; W; live matplotlib l k L g G p o; ~12 inert | | F/S removed everywhere |
| Settings / registries | 13 settings, 8 stretches, 102 colormaps, 3 fit plugins, 1 unit converter, 2 layer-artist makers | | 1 setting (no Preferences pane), 4 stretches, 87 colormaps, 1 fitter, converter replaced, 2 makers |
| glue-solar dialogs | ~18 (browser + folder picker, observation picker, Save frames ×2, Go to UTC, Loop, Wavelength band, Path on other data, Rest wavelength, 8 layer-action dialogs, 2 information boxes) | | all |

### By kind (glue-solar only, colormaps and stretches aside)

Toolbar buttons 6 · mouse modes 5 (Follow/lock, Measure, Path diagram, Show position on original path, Slope) · toolbar menu entries 28 + 7 radio options · save subtools 2 · Plugins entries 5 · layer context actions 14 · data factories 2 · exporters 2 (+1 patched) · fitter 1 · x unit 1 · keys 5 · setting 1 · startup action 1 · close hook 1 · dialogs ~18. **About 75 user-facing controls**, against roughly 110 of glue's own on the same surfaces (14 Image buttons + 4 entries, 7 Profile buttons + 14 panel controls, 10 + 4 Scatter, 6 + 4 Histogram, 2 + 2 Table, 28 menu-bar entries, 14 toolbar buttons, 19 context actions, 18 factories, 2 importers, 6 exporters).

Live viewers walked across the three inventories: 21 Image viewers (two quicklooks, 8 plain kinds), 5 Profiles, 2 Scatters, 1 Histogram, 1 Table.

---

## 2. Layout map

★ = glue-solar. Order is the real order in the running app. "(hidden on …)" = the entry's `enabled` hides it.

```
Image viewer toolbar  [18]  — identical on quicklook panels
├─ 💾 Save ▾ (no tooltip)         Save plot to file · ★Save frames or movie… · Save Python script to reproduce plot
├─ 🗗 Window ▾ (no tooltip)       Move to another tab · Change viewer title
├─ Home (H) · Pan (M) · Zoom (Z)
├─ Rectangular ROI (R) · X range (X) · Y range (Y) · Circular ROI (C) · Polygonal ROI (G)
├─ Pixel · Contrast/Bias
├─ (spectrum icon, no text, no tooltip)  profile-viewer
├─ Slice Extraction (P)           (hidden on 4D stacks and 2D data)
├─ ★Follow/lock
├─ ★✎ Modes ▾
│   Measure (U) · Path diagram (L) (hidden on 2D, on diagrams) · Show position on original path (diagrams only)
│   · Slope (diagrams only) · Save path as ECSV… (diagrams) · Open path from ECSV… (3D/4D)
│   · Path on other data… (diagram or image with a path) · Path sampling ▸ Truncate ● | Nearest | Linear
├─ ★🔗 Coordinate ▾               (no entry ever hidden)
│   Time master · Clear point · Go to UTC… · Loop… · Raster overlays · Light curve at the point
│   · Light curves at this point (windows, SJI) · Set blink partner here · Blink ☐ · Blink interval ▸ 0.25 s | 0.5 s ● | 1 s | 2 s
└─ ★⚙ View ▾
    Frame time ☑ · Hide axes ☐ · Per-frame limits ☐ · Wavelength band… ☐ (hidden without a wavelength axis)
    · Physical aspect ☐ · Zoom 1:1 · Colour bar ☐ · Cursor readout ☑

Quicklook tab "IRIS <OBSID>"  (★ QuicklookImageViewer + glue ProfileViewer; not in New Data Viewer)
├─ "<window> slit vs time" | "<window> map" (stack)     Pixel active; regions select by sky outline
├─ "<window> spectrogram"
├─ "<window> λ–time" | "λ–step" | "λ–scan"
├─ "SJI 1330" · "SJI 1400" · "SJI 2796" · "SJI 2832"   aspect equal
└─ "<window> spectrum"  Profile: Mean, x = Wavelength, raster layer hidden, Point shown
   Toolbars of panels not in focus are greyed (glue-qt hide_toolbars).
   At 1600×1000: raster panels 418 px wide hide 8 of 18 buttons (Pixel … View); slit-jaw panels 248 px hide 13.

Profile viewer toolbar  [9]
├─ 💾 Save ▾   Save plot to file · ★Save profiles as ECSV… · Save Python script to reproduce plot
├─ 🗗 Window ▾ Move to another tab · Change viewer title
├─ Home (H) · Pan (M) · Zoom (Z) · X range (X)
├─ Options (text only, no icon) → side panel: Navigate | Fit [Polynomial · Gaussian · ★Gaussian + constant (IRIS); Settings · Fit · Clear] | Collapse [Mean … Moment 2; Collapse]
├─ ★IRIS lines  (toggle, no check state, starts on)
└─ ★Velocity axis (toggle, no check state, "forward" arrow icon)
   Left panel > General > x unit: 132 entries, ★km / s last.

Scatter  [10]  Save ▾ · Window ▾ · Home · Pan · Zoom · Rectangular ROI · X range · Y range · Circular ROI · Polygonal ROI
Histogram [6]  Save ▾ · Window ▾ · Home · Pan · Zoom · X range
Table     [2]  Select row(s) · Window ▾        (refuses any dataset with a datetime component, glue-qt 0.4.2)

Main window
├─ File     Open Data Set ⌘O · Import data ▸ Import from file | Import from directory · Reset Session · Open Session · Export Session · Export Data/Subsets · ─ · Edit Preferences · Quit
├─ Edit     Undo ⌘Z · Redo ⌘Y
├─ View     Console Log
├─ Canvas   New Tab ⌘T · New Data Viewer ⌘N · New Fixed Layout Tab (always disabled) · ─ · Gather Windows ⌘G · Rename Tab ⌘R
├─ Data Manager   = the right-click menu below, all 33 greyed until a selection
├─ Plugins  Plugin Manager · ★IRIS: browse observations… · ★IRIS: link helioprojective coordinates · ★IRIS: quicklook… · ★IRIS: user guide and issues · ★Restore last session
├─ Help     Online Documentation (glue's) · Send Feedback · Version information
└─ Toolbars  [Open Session · Export Session · Import Data · Export Data/Subsets · Link Data · Arithmetic attributes]  [Active Subset ▾ · Replace | Or | And | Xor | Not]  [Terminal · Preferences · Error Console]  — no tooltips except the 5 modes

Data collection right-click, one dataset selected  [25 visible of 33]
  Export data values · Import subset mask(s) · Export subset mask(s) · New Subset ⌘⇧N · Delete Layer ⌫ · Create faceted subsets
  · View metadata/header ⌘I · Link Data · Add/edit arithmetic attributes · Reorder/rename data attributes
  · ★Set rest wavelength… · ★IRIS: line moments… · ★IRIS: subtract mean spectrum · ★Regrid on time · ★North up · ★Rebin… · ★Shift pointing…
  · ★IRIS: detect UV bursts… · ★IRIS: remove dust · ★IRIS: radiometric calibration · ★IRIS: Doppler image… · ★IRIS: line ratio diagnostic…
  · ★IRIS: Mg II features… · ★IRIS: red-blue asymmetry… · Create new viewer
  (subset group: Export subset values, Copy/Paste/Paste Special…, Invert, New, Clear ⌘K, Delete, ★IRIS: line ratio diagnostic…)

File > Open Data Set types (19)   … Numpy save file · ASCII Table · ★sunpy Map · ★IRIS Level 2 FITS
Export formats (9, alphabetical)   Comma-separated table · ★ECSV (with Time) · FITS (1 component/HDU)† · FITS Table · HDF5 · IPAC Catalog · ★IRIS FITS (coordinates and Time) · LaTeX Table · VO Table
  († glue's label, glue-solar's function)

Keys
  Active Image/quicklook/Profile viewer   ★D/F frame back/on · ★A/S wavelength back/on · ★Space play/pause
  Active Image/quicklook/Scatter/Histogram ⌫ close (asks) · Tab (never fires)
  Toolbar focused   H M Z R X Y C G P (glue) · ★U Measure · ★L Path diagram
  In a mode         Enter accept / Esc clear (Polygonal ROI, Slice, Path diagram, Slope) · Esc unlock (Follow/lock)
  Mouse over image  W world↔pixel (WCSAxes) · l, k, L log scales · g, G NotImplementedError traceback · p, o hidden mpl pan/zoom (matplotlib, live)
  Data collection   ⌘C ⌘V ⌘⇧N ⌘K ⌘I ⌫ Delete Layer (no undo)
```

---

## 3. Findings, most important first

**F1. Quicklook panels hide every glue-solar tool behind the toolbar's » button.** glue-solar's four buttons come last (`ImageViewer.tools.append`, `__init__.py:157-159`), so they overflow first. Measured (Fusion style, offscreen): raster panels 392 / 418 / 525 px wide at 1280×800 / 1600×1000 / 1920×1080 hide 9 / 8 / 5 buttons, always Follow/lock, Modes, Coordinate and View; slit-jaw panels 232–312 px hide 11–13, leaving Save, Window, Home, Pan, Zoom and a few ROI tools. Only at 2560×1440 do raster panels (738 px) show all 18, and slit-jaw panels (440 px) still hide 7. The docs promise "fits a viewer 700 pixels wide" (viewer-tools-and-windows.rst:12-13), and #156 was done so "narrow viewers stop hiding them": in the quicklook, the one place they matter, they are still hidden. Evidence: `image-viewers/probe1.json` on_bar per button; shots `ql_sns__tab.png` at three sizes.

**F2. Help text written for menu entries never appears.** glue-qt sets each tool's tooltip on the QAction (`glue_qt/viewers/common/toolbar.py:168-171`) and its QMenus keep `toolTipsVisible` False (verified on every menu in both runs), with no status tip. So the 27 glue-solar menu entries' `tool_tip`s (e.g. tools.py:1831, 1848, 1866, 1876, 2076) are unreachable, as are glue's 4 save/window entries. glue-solar copies the tooltip onto its *own* three menu buttons (tools.py:2492, 2604) but leaves glue's Save and Window buttons with an empty tooltip, and glue-qt's profile-viewer button has neither text nor tooltip. Save/Window/Options on Profile, Scatter, Histogram and Table show nothing either. Evidence: `button_tooltip: ""` for `save` in `reviewer/probe.json` and `probe1.json`.

**F3. The 14 layer actions appear on every dataset and mostly end in an error box.** glue-qt's `LayerAction` can only tell a dataset from a subset, so every `@layer_action(single=True, data=True)` (lines.py:269, regrid.py:142/219/353, sources/iris.py:188, moments.py:414/487, bursts.py:236, calibration.py:89/153, doppler.py:145, mg_features.py:160, red_blue.py:144) shows on a plain table, a SOT cube, an SJI and a raster alike. Live outcomes (app `layer_action_outcomes`): sns raster window 9 of 13 single-dataset actions work or open their dialog, scanning window 8, SJI 1400 6, SOT 4, plain table 0. "IRIS: Mg II features…" works only on a Mg II window, "IRIS: detect UV bursts…" only on Si IV or SJI 1400; "IRIS: line ratio diagnostic…" (`single=False`, line_ratio.py:202) even shows for a subset group and for two unrelated datasets. The labels do not say which data they need; the tooltips do, but see F2 (the right-click menu does show them, the Data Manager menu does not).

**F4. The Coordinate menu hides nothing, while Modes and View hide by data kind.** On a 20×30 array with no coordinates all 10 Coordinate entries show (re-probe `flat2d`), as on SOT, moment maps, path diagrams and north-up grids. `_CoordinateEntry` (tools.py:1816-1826) has no `enabled` logic. Outcomes on such data: silent no-ops (Raster overlays; Clear point with no point), silently accepted (Time master made a SOT cube the master), error boxes (Light curve at the point: works only on a sit-and-stare or stack *map*; Light curves at this point without a point; Go to UTC… and Loop… on 2D data and on the sit-and-stare "slit vs time" panel; Blink without a partner). Related: "Wavelength band…" is offered on the spectrogram and λ panels where it changes nothing (re-probe: slices unchanged after accepting 9; `BandTool._enable`, tools.py:725-726, tests for a wavelength axis, not for one that is a slider); "Frame time" is ticked with an empty label on data with no Time (re-probe).

**F5. Naming is inconsistent, including the "IRIS:" prefix.**
- Layer actions: 9 of 14 start with "IRIS: "; "Set rest wavelength…", "Regrid on time", "North up", "Rebin…", "Shift pointing…" do not, yet Shift pointing's tooltip says "this IRIS dataset's" (sources/iris.py:192) and North up's names "slit-jaw image, AIA cutout or SOT cube". Plugins: 4 of 5 prefixed; "Restore last session" is not (logged as PROVISIONAL "no IRIS: prefix" under #206 in the plan). In toolbars the brand is inline ("IRIS lines", lines.py:60) or a suffix ("Gaussian + constant (IRIS)"). Layer-artist makers are prefixed but invisible.
- Near-duplicate labels: "Light curve at the point" (tools.py:1865) and "Light curves at this point (windows, SJI)" (tools.py:1875) differ by "the"/"this" and a plural, but one opens a Profile of the shown window, the other adds 9 datasets and a Scatter. The docs' loading page lists both in one sentence (loading-iris-level-2-raster-and-sji-data.rst:169-170).
- Ellipsis: glue-solar "…", glue "Paste Special..." in the same menu; iris-quicklook.rst:349 writes "Go to UTC" without it.
- Spelling: "Colour bar" beside glue's "One color per layer"; "km / s" (unit list, axis label "Velocity from … Å [km / s]") against "km/s" in the fit report, the moments dialog and the docs; "Angstrom" in the unit list, "Å" in glue-solar's labels.
- Panel titles "slit vs time", "λ–time" against the docs' "slit against time", "wavelength against time" (iris-quicklook.rst:44). The browser shows "C II 1336" and "SJI_1330"; the datasets are "C_II_1336-…" and the panels "SJI 1330".
- glue-core's wording "Show position on original path" (glue/plugins/tools/path_slicer/matplotlib_mode.py:143) sits inside glue-solar's menu; glue's dialog entries "Change viewer title", "Move to another tab", "Save plot to file" have no "…".

**F6. Duplicates and overlaps.** Slice Extraction (glue-qt, P, 3D only) and Path diagram (★, L, 3D/4D) do the same job; Path diagram keeps glue-core's status tip "Draw a path then press ENTER to extract slice" (matplotlib_mode.py:51, not overridden at tools.py:1349-1352). Pixel and Follow/lock both place the point. Icons are reused: pencil for the Modes button, Measure and Slope (tools.py:1049, 1642, 2638); the X-range icon for Wavelength band (705), the Y-range icon for Colour bar (980), the Zoom icon for Zoom 1:1 (909); Velocity axis uses glue's "forward" arrow (lines.py:187), which reads as "next". IRIS lines and Velocity axis are toggles built on `Tool`, not `CheckableTool` (lines.py:51, 179), so they show no on/off state, unlike the View entries.

**F7. Key clashes, verified live.**
- U and L (documented for Measure and Path diagram) work only while the toolbar has the keyboard. Over the image matplotlib's keys are live: l sets the image's y axis to log, k or Shift+L the x axis; g and G raise `NotImplementedError` from WCSAxes with a terminal traceback; p and o turn on matplotlib's hidden pan/zoom while glue's Pixel tool stays active. `glue_patches.canvas_init` removes only f/Ctrl+F and s/Ctrl+S.
- C, G, H, P, R mean a tool with the toolbar focused and something else (or nothing) over the canvas.
- Backspace: close the viewer (asks), Delete Layer in the data collection (no confirm, no undo), matplotlib "back" (inert).
- Modifiers are ignored by glue-qt: Ctrl+F steps the frame.
- Coverage holes: glue-qt registers Tab and Backspace on `DataTableModel`, not `TableViewer` (keyboard_shortcuts.py:32, 43), so Table gets nothing; Profile gets only glue-solar's five; the "Light curves at the point" Scatter gets none of D/F/A/S/Space; removing F/S everywhere leaves them dead in Scatter and Histogram. Tab never fires (docs say so).

**F8. Long and mixed menus.** The Data Manager menu shows all 33 entries greyed before any selection (`menu_data_manager_empty.png`). Right-clicking a dataset gives 25 entries, 14 of them glue-solar's in module-import order (lines, moments, regrid, iris, bursts, calibration, doppler, line_ratio, mg_features, red_blue), with glue's "Create new viewer" pushed to the bottom. Coordinate holds 10 entries covering five jobs (time sync, the point, playback, overlays, blink) with no separators. The Profile x unit list has 132 entries with km / s last. The Open dialog's 19 types end with glue-solar's two; the exporter list is alphabetical so glue-solar's two sit 2nd and 7th, and three exporters share `*.fits`.

**F9. Order is set by plugin load order, not design.** `slice` lands between profile-viewer and glue-solar's buttons because pv_slicer loads first; "Save frames or movie…" and "Save profiles as ECSV…" sit between glue's two save entries (`subtools["save"].append`, `__init__.py:160-164`).

**F10. Docs vs the running app.**
- viewer-tools-and-windows.rst:338 says "Save Session"; the menu says "Export Session".
- loading-iris-level-2-raster-and-sji-data.rst:166-171 lists the Coordinate menu without "Raster overlays" and "Blink interval".
- The file type "IRIS Level 2 FITS" is never named; it is also auto-chosen for SOT cubes and aligned AIA cutouts (priority 200, sources/iris.py:72), so the name undersells it. "sunpy Map" matches every FITS file but is never auto-chosen.
- iris-bursts.rst:13 tells the user to drag the bursts table onto a Table viewer; the Table viewer refuses any dataset with a datetime component ("argument of type numpy.datetime64 is not iterable", glue-qt 0.4.2 `data_viewer.py:169`, reproduced without glue-solar). Light-curve datasets fail the same way; Slope's table avoids it by storing times as strings.
- Not named anywhere: the three ROI tools, "Change viewer title", "Select row(s)", "Import from file/directory", the Plugin Manager; the fit Settings dialog appears only in dev_guide/manual-checks.rst. Docs mix "->" and "→" in menu paths.

**F11. Smaller things.**
- `iris_quicklook` and "IRIS: quicklook…" count a SOT cube's OBSID as an observation; a SOT-only startup opens an empty tab "IRIS 3603259402".
- `SOLAR_SHOW_AXES` can only be set from glue's terminal; no Preferences pane.
- Observation browser: Change…, Search subfolders, Add current folder…, Filter, Cancel and Load selected have no tooltips; the Stack tick box has one tooltip in the .ui and another set in code; Load selected is not the default button; no keyboard shortcuts.
- "Gaussian + constant (IRIS)" gives a raw scipy traceback with fewer than 4 samples in the range (glue's Gaussian accepts 3) and exposes irispy's parameter names amplitude_0, amplitude_1, mean_1, stddev_1 in Settings.
- Per-frame limits on: a session saved with it does not reopen (glue-core 1.27.0).
- glue-qt's own, for the record: no tooltips on the 9 main-toolbar buttons, "Edit " and "View " menu titles end in a space, New Fixed Layout Tab is always disabled, the Collapse tab's instruction is copied from Fit, the options panel says "y_unit" beside "x unit", Redo shows Ctrl+Y offscreen.

---

## 4. Recommendations

Each says what would change. **[decision]** marks ones that need your call.

**R1. Make glue-solar's tools visible in quicklook panels** (F1). Options, one needed:
 (a) Put Follow/lock, Modes, Coordinate and View right after Zoom in `ImageViewer.tools` (insert instead of append), so glue's five ROI tools, Contrast/Bias, profile-viewer and Slice overflow first. Changes every Image viewer's order; the docs' toolbar paragraph.
 (b) Give `QuicklookImageViewer` its own shorter `tools` list (drop the ROI tools, Contrast/Bias, profile-viewer, Slice), keeping the plain viewer as is. Changes only quicklook panels; region selection on panels would need the Pixel/Follow-lock path or the plain viewer.
 (c) One "IRIS" menu holding Follow/lock, Modes, Coordinate and View as submenus: one button survives any width; two levels deep. **[decision: a, b or c]**
 Either way, correct the "700 pixels wide" sentence to say what a quicklook panel shows at 1600 and 1920 px.

**R2. Show the menu help text** (F2). Turn `toolTipsVisible` on in `_ToolMenu._add_entries` and `CoordinateTool._add_blink_menu`, or copy each `tool_tip` into the action's status tip so the status bar shows it on hover; set glue's Save and Window buttons' tooltips the same way glue-solar sets its own; give the profile-viewer button a tooltip. No decision needed; small change in tools.py only.

**R3. Hide, or label, layer actions by data kind** (F3, F8). glue-qt's `LayerAction` cannot see the data, so pick one:
 (a) Keep them all shown but order them by data kind and name the kind where it is narrow: "IRIS: remove dust (SJI)", "IRIS: detect UV bursts… (Si IV, SJI 1400)", "IRIS: Mg II features… (Mg II window)", "North up (SJI, AIA, SOT)", "Regrid on time (sit-and-stare, SJI, stack)". Changes 6–8 labels and the registration order (import order in `__init__.py:31` or an explicit list).
 (b) A small glue-qt patch (fork branch, as other upstream fixes) letting a layer action supply an `applies(data)` predicate that `LayerAction._can_trigger` consults; glue-solar then hides each action where its own guard would raise. Changes glue-qt in the fork and one line per action. **[decision: a, b, or both]**
 Also give "IRIS: line ratio diagnostic…" a guard so it does not appear for a subset group.

**R4. Hide or grey Coordinate entries that cannot work** (F4), as Modes and View already do: Light curve at the point only on a sit-and-stare or stack map; Raster overlays only when the observation has a raster; Go to UTC… and Loop… only when the viewer or master has a time slider; Blink greyed until a partner is set; Wavelength band… only where wavelength is a slider axis; Frame time only where the data has a Time. Register the Coordinate entries in `toolbar.tools`/`toolbar.actions` like `_ToolMenu` does so the same `enabled` → `setVisible` wiring applies. **[decision: hide vs grey; glue hides]**

**R5. Settle the naming rules** (F5). Suggested rule: "IRIS: " on everything glue-solar adds to a *shared* glue menu (all 14 layer actions, all 5 Plugins entries), no prefix inside glue-solar's own toolbar menus. That renames Set rest wavelength…, Regrid on time, North up, Rebin…, Shift pointing… and Restore last session (reversing the #206 provisional). **[decision]** Separately:
 - "Light curve at the point" → "Light curve of this window…" / "Light curves at this point (windows, SJI)" → "Light curves of every window and SJI…", or merge them into one dialog with a tick list. **[decision]**
 - "km / s" → "km/s" (format the unit string once in `DopplerConverter`); "Angstrom" stays astropy's.
 - "Colour" vs "Color": glue-solar is consistently British, glue American; pick one for glue-solar-wide text. **[decision]**
 - Match the panel titles and the docs: either rename panels to "slit against time" or change iris-quicklook.rst:44 to "slit vs time" and "λ–time". Fix "Go to UTC" (iris-quicklook.rst:349). Make the browser's names match the datasets ("SJI 1330").
 - Override Path diagram's `status_tip` and rename "Show position on original path" to "Position on the path" or similar so the menu reads as one voice.

**R6. Group the Coordinate menu** (F8). Cheapest: three separators (time: Time master, Go to UTC…, Loop… | point: Clear point, Light curve…, Light curves…, Raster overlays | blink: Set blink partner here, Blink, Blink interval). Alternative: move the three blink entries to View and Raster overlays to View, leaving Coordinate with time and point only. **[decision: separators only, or move]**

**R7. Remove the duplicate mode** (F6). Hide glue-qt's Slice Extraction where Path diagram is offered (it is a global `ImageViewer.tools` list, so this affects every Image viewer, IRIS or not), or leave both and give Path diagram a distinct icon. **[decision]** Give Wavelength band, Colour bar, Zoom 1:1, Slope and Velocity axis icons of their own (or none: menu entries need none).

**R8. Make the Profile toggles show state** (F6). Give IRIS lines and Velocity axis a `checked` state (as the View entries have) or put them, with Save profiles, in a Profile "View" menu with check marks; grey Velocity axis until a rest wavelength exists instead of arming it silently.

**R9. Tame the canvas keys** (F7). Extend `glue_patches.canvas_init` to drop matplotlib's g/G (they raise), l/k/L (they bypass glue's log option) and p/o (they fight glue's modes), as it already drops f/s. Document that U and L need the toolbar focused, with the toolbar's letters, in the Keys table. Consider registering D/F/A/S/Space on `ScatterViewer` so the light-curve Scatter follows them. **[decision on removing matplotlib keys outright]**

**R10. Docs fixes, no decision needed** (F10): "Export Session"; add Raster overlays and Blink interval to the loading page's Coordinate list; name the "IRIS Level 2 FITS" type and say it also opens SOT cubes and AIA cutouts; replace the Table-viewer route in iris-bursts.rst with one that works (or note the glue-qt datetime bug); one arrow style for menu paths; name the ROI tools once.

**R11. Small fixes, no decision needed** (F11): skip observations with neither raster nor SJI in `iris_quicklook` and the quicklook picker; tooltips and a default button in the browser, one tooltip for the Stack box; a clear message from the IRIS fitter when the range has fewer than 4 samples; a Preferences pane or at least a documented `SOLAR_SHOW_AXES` path.

**R12. Order glue-solar's entries deliberately** (F9): put "Save frames or movie…" / "Save profiles as ECSV…" after glue's two save entries (append after `save:python`, or insert at a fixed index), and insert `slice` explicitly relative to glue-solar's buttons rather than relying on entry-point order.

---

## Screenshots worth showing

Base: `/private/tmp/claude-501/-Users-nabil-Git-glue-solar/07d33ef8-b8df-4ddb-b55c-24b6271a724b/scratchpad/tools-review/`

Toolbar overflow in the quicklook (F1):
- `image-viewers/size1280x800/shots/ql_sns__tab.png`
- `image-viewers/shots/ql_sns__tab.png` (1600×1000)
- `image-viewers/size1920x1080/shots/ql_sns__tab.png`
- `image-viewers/size2560x1440/shots/ql_sns__tab.png`
- `image-viewers/shots/ql_sns_map__toolbar.png`, `image-viewers/shots/ql_sns_sji0__toolbar.png`

Image viewer toolbar and its menus (F2, F5, F6, F8):
- `image-viewers/shots/plain_sns_raster__toolbar.png`
- `image-viewers/shots/plain_sns_raster__menu_solar_modes.png`
- `image-viewers/shots/plain_sns_raster__menu_solar_coordinate.png`
- `image-viewers/shots/plain_sns_raster__menu_solar_view.png`
- `image-viewers/shots/plain_path_diagram__menu_solar_modes.png`

Entries shown where they cannot work (F4), on a 2-D array with no coordinates:
- `reviewer/shots/flat2d_toolbar.png`
- `reviewer/shots/flat2d_menu_coordinate.png`
- `reviewer/shots/flat2d_menu_view.png`
- `reviewer/shots/flat2d_menu_modes.png`

Profile viewer (F6, F8):
- `profile/shots/quicklook-spectrum-toolbar.png`
- `profile/shots/profile-tools-fit-gaussian-constant.png`
- `profile/shots/profile-x-unit-dropdown-end.png`
- `profile/shots/light-curve-profile-toolbar.png`
- `profile/shots/point-curves-scatter-toolbar.png`

Application level (F3, F5, F8, F10, F11):
- `app/shots/context_menu_sns_raster_window.png`
- `app/shots/context_menu_plain_table.png`
- `app/shots/context_menu_subset_group.png`
- `app/shots/menu_data_manager_empty.png`
- `app/shots/menu_plugins.png`
- `app/shots/main_toolbar_1.png`
- `app/shots/dialog_file_open_data_types.png`
- `app/shots/dialog_export_data_subsets_formats.png`
- `app/shots/dialog_iris_observation_browser.png`

Probe scripts and raw results: `reviewer/probe.py`, `reviewer/probe.json`, `reviewer/overflow.py`; the three inventories' own in `image-viewers/`, `profile/`, `app/`.