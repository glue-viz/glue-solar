"""fits.getheader (what scan_directory uses) against reading only the primary header blocks, for every FITS file under DATA."""
import gzip, statistics, time
from pathlib import Path
from astropy.io import fits

files = sorted(p for p in Path("/Users/nabil/DATA/IRIS").rglob("*") if p.name.endswith((".fits", ".fits.gz")))

def primary_header(path):
    opener = gzip.open if path.name.endswith(".gz") else open
    with opener(path, "rb") as f:
        return fits.Header.fromfile(f)

res = {}
for fn in (fits.getheader, primary_header):
    totals = []
    for _ in range(5):
        t0 = time.perf_counter()
        for p in files:
            h = fn(p)
        totals.append(time.perf_counter() - t0)
    res[fn.__name__] = statistics.median(totals)
gz = [p for p in files if p.name.endswith(".gz")]
per = {}
for fn in (fits.getheader, primary_header):
    per[fn.__name__] = statistics.median([sum((lambda t0: (fn(p), time.perf_counter() - t0)[1])(time.perf_counter()) for p in gz) for _ in range(5)])
same = all(dict(fits.getheader(p)) == dict(primary_header(p)) for p in files[:20] + gz)
print(f"{len(files)} files ({len(gz)} gz): all-files median of 5: getheader {res['getheader']:.3f}s, primary_header {res['primary_header']:.3f}s; gz only: {per['getheader']:.3f}s vs {per['primary_header']:.3f}s; same headers: {same}")
