"""Medians of whatif_runs.jsonl per (scenario, mode), and the saving against the baseline."""
import json
import os
import statistics as st
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
runs = defaultdict(list)
for line in open(os.path.join(HERE, "whatif_runs.jsonl")):
    r = json.loads(line)
    runs[(r["scenario"], r["mode"])].append(r)

keys = ["import_glue", "splash", "load_plugins", "time_to_window", "first_image_viewer", "first_profile_viewer",
        "second_image_viewer"]
base = {m: {k: st.median(r["phases"][k] for r in runs[("none", m)]) for k in keys} for m in ("with", "without")}
print(f"{'scenario':70s} {'mode':8s} n solar " + " ".join(f"{k[:14]:>14s}" for k in keys) + "  saving_to_window  modules  rss")
for (sc, m), rs in runs.items():
    med = {k: st.median(r["phases"][k] for r in rs) for k in keys}
    spread = st.median(abs(r["phases"]["time_to_window"] - med["time_to_window"]) for r in rs)
    print(f"{sc:70s} {m:8s} {len(rs)} {'y' if rs[0]['glue_solar'] else 'n':5s} "
          + " ".join(f"{med[k]:14.3f}" for k in keys)
          + f"  {base[m]['time_to_window'] - med['time_to_window']:+.3f} (MAD {spread:.3f})"
          + f"  {st.median(r['n_modules'] for r in rs):.0f}  {st.median(r['maxrss_mb']['show_and_settle'] for r in rs):.0f}")
