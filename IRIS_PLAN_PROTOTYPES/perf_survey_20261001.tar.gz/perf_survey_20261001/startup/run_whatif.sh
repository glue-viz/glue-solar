#!/bin/sh
# 7 interleaved repeats of every what-if configuration; one JSON line per run in whatif_runs.jsonl
cd /private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/perf
S=$PWD/startup
: > $S/whatif_runs.jsonl
CONFIGS="none:with none:without lazy_terminal:with lazy_ipython:with lazy_ipython:without lazy_wcs_autolinking:with lazy_wcs_autolinking:without no_qtquick:with lazy_irispy:with lazy_irispy,no_dask:with no_dask:without lazy_ipython,lazy_wcs_autolinking,no_qtquick,lazy_irispy,no_dask:with lazy_ipython,lazy_wcs_autolinking,no_qtquick,no_dask:without"
for i in 1 2 3 4 5 6 7; do
  for c in $CONFIGS; do
    sc=${c%%:*}; m=${c##*:}
    env HOME="$(mktemp -d)" QT_QPA_PLATFORM=offscreen MPLBACKEND=agg MPLCONFIGDIR=$S/mplconfig PYTHONPYCACHEPREFIX=$S/pycache \
      /Users/nabil/mamba/envs/iris-plan/bin/python startup/whatif.py $sc $m 2>/dev/null | grep '^{' | sed "s/^{/{\"scenario\": \"$sc\", /" >> $S/whatif_runs.jsonl
  done
done
echo done
