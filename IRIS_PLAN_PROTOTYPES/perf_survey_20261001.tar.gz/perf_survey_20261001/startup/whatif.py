"""
Estimate what making an eager import lazy would save: stub or block it in this process only, then run phases.py.

    whatif.py <scenario[,scenario...]|none> with|without

Nothing on disk changes; stubs only stand in for modules that a normal launch (no data, no terminal) never uses.
"""
import runpy
import sys
import types

HERE = sys.path[0]


def stub(name, **attrs):
    mod = types.ModuleType(name)
    mod.__dict__.update(attrs)
    mod.__path__ = []  # lets "from stub import submodule" resolve to other stubs
    sys.modules[name] = mod


SCENARIOS = {
    # glue-qt: import the IPython terminal only when the user opens it
    "lazy_terminal": lambda: stub("glue_qt.app.terminal", glue_terminal=None, IPythonTerminalError=RuntimeError),
    # glue-core + glue-qt: with the terminal lazy, check sys.modules for IPython instead of importing it
    "lazy_ipython": lambda: (
        stub("glue_qt.app.terminal", glue_terminal=None, IPythonTerminalError=RuntimeError),
        stub("IPython", get_ipython=lambda: None, version_info=(8, 37, 0)),
    ),
    # glue-core: import scipy.optimize.leastsq inside the WCS autolinker functions
    "lazy_wcs_autolinking": lambda: stub("glue.plugins.wcs_autolinking.wcs_autolinking"),
    # glue-core: isinstance checks against dask arrays without importing dask.array
    "no_dask": lambda: sys.modules.update({"dask": None, "dask.array": None}),
    # glue-qt: import QtQuick only on Qt6, where it is used
    "no_qtquick": lambda: stub("qtpy.QtQuick"),
    # glue-solar: import irispy and sunpy.map when a file is read, not at plugin load
    "lazy_irispy": lambda: (
        stub("irispy"), stub("irispy.io", read_files=None), stub("irispy.obsid"),
        stub("sunpy.map", GenericMap=type("GenericMap", (), {})),
        stub("sunpy.map.mapbase", GenericMap=sys.modules["sunpy.map"].GenericMap),
    ),
}

scenarios, mode = sys.argv[1], sys.argv[2]
for s in filter(None, scenarios.split(",")):
    if s != "none":
        SCENARIOS[s]()
sys.argv = ["phases.py", mode]
runpy.run_path(f"{HERE}/phases.py", run_name="__main__")
