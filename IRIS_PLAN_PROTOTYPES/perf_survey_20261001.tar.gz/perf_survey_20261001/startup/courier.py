"""First-use cost of glue-qt's profile-fit log font QFont('Courier') against the system fixed font (fresh process)."""
import sys, time
from qtpy import QtGui, QtWidgets
app = QtWidgets.QApplication([""])
edit = QtWidgets.QTextEdit()
t0 = time.perf_counter()
if sys.argv[1] == "courier":
    font = QtGui.QFont("Courier")
    font.setStyleHint(QtGui.QFont.Monospace)
else:
    font = QtGui.QFontDatabase.systemFont(QtGui.QFontDatabase.FixedFont)
edit.document().setDefaultFont(font)
edit.setPlainText("fit log")
edit.show(); app.processEvents()
print(sys.argv[1], round(time.perf_counter() - t0, 4), QtGui.QFontInfo(font).family())
