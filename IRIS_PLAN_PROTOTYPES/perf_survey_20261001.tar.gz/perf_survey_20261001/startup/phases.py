"""
Time glue's startup the way glue_qt.main.start_glue runs it, phase by phase, in this process.

    phases.py with|without [profile|perplugin]

with/without: glue-solar plugin enabled or disabled (through ~/.glue/plugins.cfg in the temporary HOME).
profile: also write a cProfile per phase to prof/<mode>-<phase>.pstats (timings then include its overhead).
perplugin: time import + setup of each glue.plugins entry point in load_plugins' order, then stop.
"""
import json
import os
import resource
import sys
import time

SOLAR = "/Users/nabil/Git/glue-solar-main"
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SOLAR)
mode = sys.argv[1]
extra = sys.argv[2] if len(sys.argv) > 2 else ""

os.makedirs(os.path.expanduser("~/.glue"), exist_ok=True)
if mode == "without":
    with open(os.path.expanduser("~/.glue/plugins.cfg"), "w") as f:
        f.write("[plugins]\nglue_solar = 0\n")

T, RSS, DRAWS = {}, {}, []
if extra == "profile":
    import cProfile
    os.makedirs(os.path.join(HERE, "prof"), exist_ok=True)


def rss_mb():
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 2**20  # bytes on macOS


def phase(name, fn):
    prof = cProfile.Profile() if extra == "profile" else None
    if prof:
        prof.enable()
    t0 = time.perf_counter()
    out = fn()
    T[name] = time.perf_counter() - t0
    if prof:
        prof.disable()
        prof.dump_stats(os.path.join(HERE, "prof", f"{mode}-{name}.pstats"))
    RSS[name] = rss_mb()
    return out


def settle(n=30):
    from glue_qt.utils import get_qapp
    app = get_qapp()
    for _ in range(n):
        app.processEvents()


t_start = time.perf_counter()
glue = phase("import_glue", lambda: __import__("glue"))


def webengine():
    try:
        from qtpy import QtWebEngineWidgets  # noqa: F401  (start_glue does this)
    except ImportError:
        pass


phase("import_qtwebengine", webengine)
from glue_qt.utils import get_qapp  # noqa: E402

app = phase("get_qapp", get_qapp)

if extra == "perplugin":
    from importlib import import_module
    from importlib.metadata import entry_points
    t0 = time.perf_counter()
    eps = list(entry_points(group="glue.plugins"))
    print(f"entry_points(group='glue.plugins'): {time.perf_counter() - t0:.4f}s for {len(eps)}")
    rows = []
    for ep in eps:
        if mode == "without" and ep.name == "glue_solar":
            continue
        t0 = t1 = time.perf_counter()
        err = None
        try:  # load_plugins also swallows failures of optional plugins
            mod = import_module(ep.module)
            t1 = time.perf_counter()
            getattr(mod, ep.attr)()
        except Exception as e:
            err = repr(e)[:80]
        t2 = time.perf_counter()
        rows.append((ep.name, t1 - t0, t2 - t1, err))
    print(json.dumps({"perplugin": rows}))
    sys.exit(0)


def splash():
    from glue_qt.main import get_splash
    s = get_splash()
    s.show()
    return s


sp = phase("splash", splash)
from glue.main import load_plugins  # noqa: E402

phase("load_plugins", lambda: load_plugins(splash=sp, require_qt_plugins=True))
GlueApplication = phase("import_glue_qt_app", lambda: __import__("glue_qt.app", fromlist=["GlueApplication"]).GlueApplication)
sp.close()


def make_app():
    dc = glue.core.DataCollection()
    session = glue.core.Session(data_collection=dc, hub=dc.hub)
    return GlueApplication(session=session)


ga = phase("GlueApplication", make_app)


def show():
    ga.start(block=False, maximized=False)
    ga.resize(1600, 1000)
    settle()


phase("show_and_settle", show)
T["time_to_window"] = time.perf_counter() - t_start

# Time every Agg canvas draw from here on (harness instrumentation only).
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg  # noqa: E402

_draw = FigureCanvasQTAgg.draw


def timed_draw(self):
    t0 = time.perf_counter()
    _draw(self)
    DRAWS.append(time.perf_counter() - t0)


FigureCanvasQTAgg.draw = timed_draw

import numpy as np  # noqa: E402
from glue.core import Data  # noqa: E402
from glue_qt.viewers.image import ImageViewer  # noqa: E402
from glue_qt.viewers.profile import ProfileViewer  # noqa: E402

rng = np.random.default_rng(0)
data = Data(x=rng.random((50, 400, 400), dtype=np.float32), label="cube")
phase("add_data", lambda: ga.data_collection.append(data))
viewer = phase("first_image_viewer", lambda: ga.new_data_viewer(ImageViewer, data=data))
n0 = len(DRAWS)
phase("first_image_settle", settle)
first_draws = DRAWS[n0:]
canvas = viewer.figure.canvas
warm = []
for _ in range(10):
    t0 = time.perf_counter()
    canvas.draw()
    warm.append(time.perf_counter() - t0)
pviewer = phase("first_profile_viewer", lambda: ga.new_data_viewer(ProfileViewer, data=data))
n1 = len(DRAWS)
phase("first_profile_settle", settle)
second_viewer = phase("second_image_viewer", lambda: ga.new_data_viewer(ImageViewer, data=data))
n2 = len(DRAWS)
phase("second_image_settle", settle)

print(json.dumps({
    "mode": mode, "extra": extra,
    "glue_solar": sys.modules["glue_solar"].__file__ if "glue_solar" in sys.modules else None,
    "phases": {k: round(v, 4) for k, v in T.items()},
    "maxrss_mb": {k: round(v) for k, v in RSS.items()},
    "first_image_draws": [round(d, 4) for d in first_draws],
    "warm_image_draw_median": round(float(np.median(warm)), 4),
    "profile_draws": [round(d, 4) for d in DRAWS[n1:n2]],
    "second_image_draws": [round(d, 4) for d in DRAWS[n2:]],
    "canvas_size": [canvas.width(), canvas.height(), canvas.devicePixelRatioF()],
    "n_modules": len(sys.modules),
}))
