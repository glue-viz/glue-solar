"""
Open the observation browser on /Users/nabil/DATA/IRIS, load 4000005156 (Mg II k 2796, both scans, and the
deconvolved SJI 2796) and open its quicklook, as browse_iris does, timing each step.

    quicklook_open.py [profile]
"""
import json
import os
import resource
import sys
import time

sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
HERE = os.path.dirname(os.path.abspath(__file__))
PROFILE = "profile" in sys.argv[1:]
DATA = "/Users/nabil/DATA/IRIS"
OBSID, WINDOW = "4000005156", "Mg II k 2796"
T, RSS, DRAWS = {}, {}, []
if PROFILE:
    import cProfile
    os.makedirs(os.path.join(HERE, "prof"), exist_ok=True)


def phase(name, fn):
    prof = cProfile.Profile() if PROFILE else None
    if prof:
        prof.enable()
    t0 = time.perf_counter()
    out = fn()
    T[name] = round(time.perf_counter() - t0, 4)
    if prof:
        prof.disable()
        prof.dump_stats(os.path.join(HERE, "prof", f"quicklook-{name}.pstats"))
    RSS[name] = round(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 2**20)
    return out


import glue  # noqa: E402
from glue.main import load_plugins  # noqa: E402
from glue_qt.utils import get_qapp  # noqa: E402

app = get_qapp()
load_plugins(require_qt_plugins=True)
import glue_solar  # noqa: E402
from glue_qt.app import GlueApplication  # noqa: E402
from qtpy.QtCore import QSettings  # noqa: E402

import glue_solar.sources.loaders.iris as loader  # noqa: E402

# Keep the browser's "last folder" out of the real macOS preferences (harness only)
_ini = os.path.join(os.path.expanduser("~"), "glue-solar.ini")
loader.QSettings = lambda *_: QSettings(_ini, QSettings.IniFormat)

dc = glue.core.DataCollection()
ga = GlueApplication(session=glue.core.Session(data_collection=dc, hub=dc.hub))
ga.start(block=False, maximized=False)
ga.resize(1600, 1000)
for _ in range(30):
    app.processEvents()

from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg  # noqa: E402

_draw = FigureCanvasQTAgg.draw


def timed_draw(self):
    t0 = time.perf_counter()
    _draw(self)
    DRAWS.append((time.perf_counter(), time.perf_counter() - t0))


FigureCanvasQTAgg.draw = timed_draw

# Main-thread inclusive time of selected functions (outermost call of each only); harness instrumentation
import threading  # noqa: E402
from collections import defaultdict  # noqa: E402

ACC, DEPTH = defaultdict(lambda: [0, 0.0]), defaultdict(int)


def instrument(owner, attr, label):
    original = getattr(owner, attr)

    def wrapper(*args, **kwargs):
        if threading.current_thread() is not threading.main_thread():
            return original(*args, **kwargs)
        DEPTH[label] += 1
        t0 = time.perf_counter()
        try:
            return original(*args, **kwargs)
        finally:
            DEPTH[label] -= 1
            ACC[label][0] += 1
            if DEPTH[label] == 0:
                ACC[label][1] += time.perf_counter() - t0

    setattr(owner, attr, wrapper)


if "instrument" in sys.argv[1:]:
    from astropy.visualization.wcsaxes import WCSAxes
    from glue.viewers.image.viewer import MatplotlibImageMixin
    from glue.viewers.matplotlib.viewer import MatplotlibViewerMixin
    from glue_qt.utils.colors import QColormapCombo
    from glue_qt.core.layer_artist_model import LayerArtistWidget
    from glue_qt.app.application import GlueApplication as _GA
    import glue_qt.utils.helpers as _helpers
    instrument(WCSAxes, "_update_tick_and_label_positions", "astropy WCSAxes._update_tick_and_label_positions")
    instrument(WCSAxes, "set_xlabel", "astropy WCSAxes.set_xlabel")
    instrument(WCSAxes, "set_ylabel", "astropy WCSAxes.set_ylabel")
    instrument(WCSAxes, "reset_wcs", "astropy WCSAxes.reset_wcs")
    instrument(MatplotlibImageMixin, "_set_wcs", "glue MatplotlibImageMixin._set_wcs")
    instrument(MatplotlibViewerMixin, "update_x_axislabel", "glue update_x_axislabel")
    instrument(MatplotlibViewerMixin, "update_y_axislabel", "glue update_y_axislabel")
    instrument(QColormapCombo, "_update_icons", "glue-qt QColormapCombo._update_icons")
    instrument(LayerArtistWidget, "on_artist_add", "glue-qt LayerArtistWidget.on_artist_add (style editors)")
    instrument(_GA, "new_data_viewer", "glue-qt GlueApplication.new_data_viewer")
    instrument(loader._GlueWCS, "pixel_to_world_values", "glue-solar _GlueWCS.pixel_to_world_values")
    instrument(loader._GlueWCS, "world_to_pixel_values", "glue-solar _GlueWCS.world_to_pixel_values")

# What-ifs (harness only): upper bounds for two candidate fixes
if "whatif_labels" in sys.argv[1:]:
    # setting an axis label no longer recomputes ticks; the next draw does it
    from astropy.visualization.wcsaxes import WCSAxes
    for _name in ("set_xlabel", "set_ylabel"):
        def _skip(self, *a, _orig=getattr(WCSAxes, _name), **k):
            self._update_tick_and_label_positions = lambda *_a, **_k: None
            try:
                return _orig(self, *a, **k)
            finally:
                del self._update_tick_and_label_positions
        setattr(WCSAxes, _name, _skip)
if "whatif_cmapcache" in sys.argv[1:]:
    # colormap icons cached per (colormap, size) across combos and resizes
    import glue_qt.utils.colors as _colors
    _orig_c2p, _cache = _colors.cmap2pixmap, {}

    def _cached(cmap, steps=50, size=(100, 100)):
        key = (cmap.name, steps, tuple(size))
        if key not in _cache:
            _cache[key] = _orig_c2p(cmap, steps=steps, size=size)
        return _cache[key]
    _colors.cmap2pixmap = _cached

from glue_solar.sources.loaders.scan import scan_directory  # noqa: E402

phase("scan_directory_all", lambda: scan_directory(DATA, recursive=True))
dialog = phase("browser_open_all", lambda: loader.QtIRISImporter(DATA, parent=ga))
dialog.show()
for _ in range(10):
    app.processEvents()
n_obs = len(dialog.observations)

# Tick the SJI 2796 (deconvolved) and Mg II k 2796 raster entries of 4000005156, as a user would
from qtpy.QtCore import Qt  # noqa: E402

root = dialog.obs_tree.invisibleRootItem()
ticked = []
for i in range(root.childCount()):
    top = root.child(i)
    for item in [top] + [top.child(j) for j in range(top.childCount())]:
        index = item.data(0, Qt.UserRole)
        if index is None:
            continue
        obs_i, kind, name = dialog._payloads[index]
        if dialog.observations[obs_i].obsid == OBSID and (kind == "sji" or (kind == "raster" and name == WINDOW)):
            item.setCheckState(0, Qt.Checked)
            ticked.append((kind, str(name)))

phase("browser_load", dialog.finalize)
datasets = dialog.datasets
shapes = [(d.label, d.shape, [c.label for c in d.main_components]) for d in datasets]


def add():
    dc.extend(datasets)
    loader.keep_hpc_linked(dc)


phase("extend_and_link", add)
from glue_solar.quicklook import quicklook  # noqa: E402

n0 = len(DRAWS)
t_ql = time.perf_counter()
viewers = phase("quicklook_call", lambda: quicklook(ga, datasets, window=WINDOW))
ACC_CALL = {k: (v[0], round(v[1], 4)) for k, v in ACC.items()}
ACC.clear()


def settle(quiet=1.0, limit=60):
    """Process events until no canvas has drawn for ``quiet`` seconds (glue computes profiles on a thread)."""
    t_end = time.perf_counter() + limit
    last = time.perf_counter()
    seen = len(DRAWS)
    while time.perf_counter() < t_end:
        app.processEvents()
        if len(DRAWS) != seen:
            seen, last = len(DRAWS), time.perf_counter()
        elif time.perf_counter() - last > quiet:
            break
        time.sleep(0.002)


phase("quicklook_settle", settle)
ql_draws = DRAWS[n0:]
T["quicklook_to_last_draw"] = round(ql_draws[-1][0] - t_ql, 4) if ql_draws else None
T["quicklook_draw_time_sum"] = round(sum(d for _, d in ql_draws), 4)

viewer_list = [viewers[k] for k in ("map", "spectrogram", "wavelength", "spectrum") if k in viewers] + viewers["sji"]
warm = {}
for v in viewer_list:
    c = v.figure.canvas
    times = []
    for _ in range(5):
        t0 = time.perf_counter()
        c.draw()
        times.append(time.perf_counter() - t0)
    warm[v.state.title or type(v).__name__] = (round(sorted(times)[2], 4), c.width(), c.height())

print(json.dumps({
    "glue_solar": glue_solar.__file__, "observations": n_obs, "ticked": ticked, "datasets": shapes,
    "phases": T, "maxrss_mb": RSS, "n_quicklook_draws": len(ql_draws),
    "quicklook_draws": [round(d, 4) for _, d in ql_draws], "warm_draw_median": warm,
    "instrumented_quicklook_call": ACC_CALL if "instrument" in sys.argv[1:] else None,
    "instrumented_settle_and_warm_draws": {k: (v[0], round(v[1], 4)) for k, v in ACC.items()} if "instrument" in sys.argv[1:] else None,
}))
