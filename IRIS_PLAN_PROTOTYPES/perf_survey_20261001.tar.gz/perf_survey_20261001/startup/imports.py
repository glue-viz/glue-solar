"""Median -X importtime per target, in fresh subprocesses. Usage: python imports.py [N]"""
import os
import re
import statistics
import subprocess
import sys
import tempfile
import time
from collections import defaultdict

PY = "/Users/nabil/mamba/envs/iris-plan/bin/python"
SOLAR = "/Users/nabil/Git/glue-solar-main"
HERE = os.path.dirname(os.path.abspath(__file__))
N = int(sys.argv[1]) if len(sys.argv) > 1 else 7
LINE = re.compile(r"import time:\s+(\d+) \|\s+(\d+) \|(\s+)(\S+)")

TARGETS = {
    "pass": "pass",
    "glue": "import glue",
    "glue_without_glue_qt": "import sys\nclass B:\n def find_spec(self, n, *a):\n  if n.split('.')[0]=='glue_qt': raise ImportError(n)\nsys.meta_path.insert(0, B())\nimport glue",
    "matplotlib.pyplot": "import matplotlib.pyplot",
    "matplotlib.axes": "import matplotlib.axes",
    "glue_qt": "import glue_qt",
    "glue_qt.app": "import glue_qt.app",
    "glue_qt.main": "import glue_qt.main",
    "glue_solar": "import glue_solar; print(glue_solar.__file__)",
    "all_plugins": "import glue_qt.app, glue_qt.viewers.image, glue_qt.viewers.scatter, glue_qt.viewers.histogram, "
    "glue_qt.viewers.profile, glue_qt.viewers.table, glue_qt.plugins.tools.pv_slicer, glue_qt.io.directory_importer, "
    "glue_qt.plugins.dendro_viewer, glue.plugins.coordinate_helpers, glue.core.data_exporters, glue.plugins.dendro_viewer, "
    "glue.plugins.tools, glue.io.formats.fits, glue.plugins.wcs_autolinking",
}


def env():
    e = dict(os.environ, HOME=tempfile.mkdtemp(dir=HERE, prefix="home-"), QT_QPA_PLATFORM="offscreen",
             MPLBACKEND="agg", PYTHONPATH=SOLAR, PYTHONPYCACHEPREFIX=os.path.join(HERE, "pycache"))
    if not os.environ.get("COLD_MPL"):
        e["MPLCONFIGDIR"] = os.path.join(HERE, "mplconfig")  # a returning user's font cache
    return e


def run(code):
    t0 = time.perf_counter()
    p = subprocess.run([PY, "-X", "importtime", "-c", code], env=env(), capture_output=True, text=True)
    wall = time.perf_counter() - t0
    if p.returncode:
        raise SystemExit(p.stderr[-3000:])
    rows = [(int(m[1]), int(m[2]), len(m[3]), m[4]) for m in map(LINE.match, p.stderr.splitlines()) if m]
    return wall, rows, p.stdout.strip()


def main():
    for name, code in TARGETS.items():
        run(code)  # warm the pycache and the OS file cache
        walls, cum, top_self, out = [], defaultdict(list), defaultdict(list), ""
        for _ in range(N):
            wall, rows, out = run(code)
            walls.append(wall)
            per_top = defaultdict(int)
            for self_us, cum_us, indent, mod in rows:
                cum[mod].append(cum_us)
                per_top[mod.split(".")[0]] += self_us
            for k, v in per_top.items():
                top_self[k].append(v)
        print(f"\n=== {name}: wall median {statistics.median(walls):.3f}s "
              f"(min {min(walls):.3f}, max {max(walls):.3f}, n={N}) {out}")
        total = statistics.median(sum(v) for v in zip(*[top_self[k] for k in top_self])) if top_self else 0
        print(f"  sum of self times (median): {sum(statistics.median(v) for v in top_self.values())/1e6:.3f}s")
        print("  self time by top-level package (median s):")
        for k, v in sorted(top_self.items(), key=lambda kv: -statistics.median(kv[1]))[:25]:
            print(f"    {statistics.median(v)/1e6:7.3f}  {k}")
        print("  largest cumulative imports (median s):")
        for k, v in sorted(cum.items(), key=lambda kv: -statistics.median(kv[1]))[:45]:
            print(f"    {statistics.median(v)/1e6:7.3f}  {k}")


if __name__ == "__main__":
    main()
