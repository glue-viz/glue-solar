"""
Where a new Image/Profile viewer's creation time goes (glue + glue-qt only, a plain 50x400x400 cube), median of
viewers 2..11 in one session.  viewer_parts.py with|without
"""
import json
import os
import statistics
import sys
import threading
import time
from collections import defaultdict

sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
os.makedirs(os.path.expanduser("~/.glue"), exist_ok=True)
if sys.argv[1] == "without":
    with open(os.path.expanduser("~/.glue/plugins.cfg"), "w") as f:
        f.write("[plugins]\nglue_solar = 0\n")

import numpy as np  # noqa: E402
import glue  # noqa: E402
from glue.main import load_plugins  # noqa: E402
from glue_qt.utils import get_qapp  # noqa: E402

app = get_qapp()
load_plugins(require_qt_plugins=True)
from glue_qt.app import GlueApplication  # noqa: E402
from glue_qt.viewers.image import ImageViewer  # noqa: E402
from glue_qt.viewers.profile import ProfileViewer  # noqa: E402

ACC, DEPTH = defaultdict(lambda: [0, 0.0]), defaultdict(int)


def instrument(owner, attr, label):
    original = getattr(owner, attr)

    def wrapper(*args, **kwargs):
        if threading.current_thread() is not threading.main_thread():
            return original(*args, **kwargs)
        DEPTH[label] += 1
        t0 = time.perf_counter()
        try:
            return original(*args, **kwargs)
        finally:
            DEPTH[label] -= 1
            ACC[label][0] += 1
            if DEPTH[label] == 0:
                ACC[label][1] += time.perf_counter() - t0

    setattr(owner, attr, wrapper)


import glue_qt.utils.helpers as helpers  # noqa: E402
from astropy.visualization.wcsaxes import WCSAxes  # noqa: E402
from glue_qt.core.layer_artist_model import LayerArtistWidget  # noqa: E402
from glue_qt.utils.colors import QColormapCombo  # noqa: E402
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg  # noqa: E402

instrument(helpers, "loadUi", "PyQt uic.loadUi (glue_qt.utils.helpers.load_ui)")
instrument(QColormapCombo, "_update_icons", "QColormapCombo._update_icons")
instrument(LayerArtistWidget, "on_artist_add", "LayerArtistWidget.on_artist_add (style editor)")
instrument(WCSAxes, "set_xlabel", "WCSAxes.set_xlabel")
instrument(WCSAxes, "set_ylabel", "WCSAxes.set_ylabel")
instrument(WCSAxes, "_update_tick_and_label_positions", "WCSAxes._update_tick_and_label_positions")
instrument(ImageViewer, "_set_wcs", "ImageViewer._set_wcs")
instrument(FigureCanvasQTAgg, "draw", "canvas draw")

dc = glue.core.DataCollection()
ga = GlueApplication(session=glue.core.Session(data_collection=dc, hub=dc.hub))
ga.start(block=False, maximized=False)
ga.resize(1600, 1000)
for _ in range(30):
    app.processEvents()
data = glue.core.Data(x=np.random.default_rng(0).random((50, 400, 400), dtype=np.float32), label="cube")
dc.append(data)

out = {}
for cls in (ImageViewer, ProfileViewer):
    totals, parts = [], defaultdict(list)
    for i in range(11):
        ACC.clear()
        t0 = time.perf_counter()
        ga.new_data_viewer(cls, data=data)
        for _ in range(30):
            app.processEvents()
        if i:  # viewer 1 pays one-off imports and font setup
            totals.append(time.perf_counter() - t0)
            for k, (n, t) in ACC.items():
                parts[k].append((n, t))
    out[cls.__name__] = {"total_incl_first_draw_ms": round(statistics.median(totals) * 1e3, 1),
                         "parts_ms": {k: (v[0][0], round(statistics.median(t for _, t in v) * 1e3, 1))
                                      for k, v in sorted(parts.items(), key=lambda kv: -statistics.median(t for _, t in kv[1]))}}
print(json.dumps({"mode": sys.argv[1], **out}))
