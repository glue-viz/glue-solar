"""
Cost of glue-qt's QColormapCombo (built for every image layer's style editor), with and without
glue-solar's sunpy colormaps registered.  cmap_combo.py with|without
"""
import json
import statistics
import sys
import time

sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
from glue.config import colormaps  # noqa: E402
from glue_qt.utils import get_qapp  # noqa: E402

app = get_qapp()
if sys.argv[1] == "with":
    import glue_solar
    glue_solar.setup()
from glue_qt.utils.colors import QColormapCombo, cmap2pixmap  # noqa: E402
from qtpy import QtWidgets  # noqa: E402

n = len(colormaps.members)
cmap = colormaps.members[0][1]
pix = []
for _ in range(200):
    t0 = time.perf_counter()
    cmap2pixmap(cmap, size=(200, 15), steps=200)
    pix.append(time.perf_counter() - t0)

create, resize = [], []
host = QtWidgets.QWidget()
host.resize(400, 200)
host.show()
for i in range(15):
    t0 = time.perf_counter()
    combo = QColormapCombo(host)
    create.append(time.perf_counter() - t0)
    combo.show()
    app.processEvents()
    t0 = time.perf_counter()
    combo.resize(180 + i, 24)  # a layout pass that changes the combo's width
    app.processEvents()
    resize.append(time.perf_counter() - t0)
    combo.deleteLater()
    app.processEvents()

print(json.dumps({
    "mode": sys.argv[1], "n_colormaps": n,
    "cmap2pixmap_median_ms": round(statistics.median(pix) * 1e3, 3),
    "combo_create_median_ms": round(statistics.median(create) * 1e3, 1),
    "combo_resize_median_ms": round(statistics.median(resize) * 1e3, 1),
}))
