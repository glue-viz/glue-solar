"""File -> Open of a gzipped SJI: what glue's data-factory identification costs before any reading."""
import statistics, sys, time
sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
from glue.main import load_plugins
load_plugins(require_qt_plugins=False)
import glue_solar
from glue.core.data_factories import find_factory, is_fits
from glue_solar.sources.iris import is_iris_fits

for name in ("534d789bb0a2821fb2b78eb36d1d6753-iris_l2_20130902_163935_4000255147_SJI_1400_t000.fits.gz",
             "c844c41797b93a28fbad181337864edd-iris_l2_20130902_182935_4000005156_SJI_2796_t000_deconvolved.fits.gz"):
    path = "/Users/nabil/DATA/IRIS/" + name
    out = {}
    for label, fn in (("find_factory", lambda: find_factory(path)), ("is_iris_fits", lambda: is_iris_fits(path)),
                      ("glue is_fits", lambda: is_fits(path))):
        ts = []
        for _ in range(5):
            t0 = time.perf_counter(); r = fn(); ts.append(time.perf_counter() - t0)
        out[label] = (round(statistics.median(ts), 3), getattr(r, "label", r))
    print(name[33:], out, glue_solar.__file__)
