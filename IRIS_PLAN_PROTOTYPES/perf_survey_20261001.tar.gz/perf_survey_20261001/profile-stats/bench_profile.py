"""Profile-viewer statistics without a GUI: pixel, ROI and whole-data profiles through glue's own code."""
import sys, time, cProfile, pstats, tracemalloc, io
import numpy as np
import common
from common import bench, rss_mb
from glue.core import DataCollection
from glue.core.roi import RectangularROI
from glue.core.subset import RoiSubsetState
from glue.viewers.image.pixel_selection_subset_state import PixelSubsetState
from glue.viewers.profile.state import ProfileViewerState, ProfileLayerState

which = sys.argv[1]
data = common.load_ss() if which == 'ss' else common.load_stack()
dc = DataCollection([data])
cid = data.main_components[0]
pix = data.pixel_component_ids
spectral = data.ndim - 1
if data.ndim == 3:
    mx, my = 0, 1     # map axes: step/time, slit
else:
    mx, my = 1, 2     # scan, step, slit, wavelength
centre = [s // 2 for s in data.shape]
axes = tuple(i for i in range(data.ndim) if i != spectral)

# Pixel point, as glue-solar's quicklook builds it
slices = [slice(c, c + 1) for c in centre]
slices[spectral] = slice(None)
point = PixelSubsetState(data, slices)
# 40x40-pixel rectangle on the map, as glue's image viewer apply_roi makes it
roi = RectangularROI(centre[mx] - 20, centre[mx] + 20, centre[my] - 20, centre[my] + 20)
rect = RoiSubsetState(pix[mx], pix[my], roi)

def cs(subset_state):
    return data.compute_statistic('mean', cid, axis=axes, subset_state=subset_state)

print('size', data.size, 'n_chunk_max 4e7 -> chunked:', data.size > 4e7)
bench('compute_statistic mean, pixel point', lambda: cs(point), n=20)
bench('compute_statistic mean, 40x40 ROI', lambda: cs(rect), n=10)
# Cube-wide mean profile: what glue computes when the data layer itself is visible in a Profile viewer
t_full = bench('compute_statistic mean, whole data layer', lambda: cs(None), n=3)

# Direct numpy reference for the ROI: slice the box, nanmean
box = [slice(None)] * data.ndim
box[mx] = slice(centre[mx] - 20, centre[mx] + 21)
box[my] = slice(centre[my] - 20, centre[my] + 21)
if data.ndim == 4:
    box[0] = slice(None)
arr = data.get_component(cid).data
bench('numpy reference: nanmean of the ROI box', lambda: np.nanmean(arr[tuple(box)], axis=axes), n=10)
bench('numpy reference: nanmean of whole cube float32', lambda: np.nanmean(arr, axis=axes), n=3)

# Check results agree
r_glue = cs(rect)
r_np = np.nanmean(arr[tuple(box)], axis=axes)
print('ROI result max abs diff (glue vs box; ROI edges differ by 1 px):', np.nanmax(np.abs(r_glue - r_np)))

# Through ProfileLayerState, the way the viewer does (subset layer)
vs = ProfileViewerState()
from glue.core.subset_group import SubsetGroup
grp = dc.new_subset_group('Point', point)
sub = grp.subsets[0]
ls_sub = ProfileLayerState(layer=sub, viewer_state=vs)
ls_data = ProfileLayerState(layer=data, viewer_state=vs)
vs.layers = [ls_data, ls_sub]
vs.reference_data = data
vs.function = 'mean'
vs.x_att = data.world_component_ids[spectral]
def upd(ls):
    ls.reset_cache(); ls.update_profile()
bench('ProfileLayerState.update_profile, point subset', lambda: upd(ls_sub), n=20)
grp.subset_state = rect
bench('ProfileLayerState.update_profile, ROI subset', lambda: upd(ls_sub), n=10)

# cProfile the ROI and whole-data paths
for label, fn in [('ROI', lambda: cs(rect)), ('whole', lambda: cs(None))]:
    pr = cProfile.Profile(); pr.enable(); fn(); pr.disable()
    s = io.StringIO(); pstats.Stats(pr, stream=s).sort_stats('tottime').print_stats(8)
    print(f'--- cProfile {label} (tottime) ---'); print('\n'.join(s.getvalue().splitlines()[:30]))

# Peak traced memory of the whole-data profile
tracemalloc.start()
cs(None)
cur, peak = tracemalloc.get_traced_memory()
tracemalloc.stop()
print(f'whole-data profile: tracemalloc peak {peak/2**20:.0f} MB above baseline; data component {arr.nbytes/2**20:.0f} MB')
tracemalloc.start()
np.nanmean(arr, axis=axes)
cur, peak = tracemalloc.get_traced_memory(); tracemalloc.stop()
print(f'numpy nanmean float32 whole: tracemalloc peak {peak/2**20:.0f} MB')
