"""
glue-only Profile viewer on an IRIS cube: what add_data computes and where, and the latency of a
pixel-point profile update through the threaded worker. Usage: gui_spectrum.py ss|stack
"""
import sys, time, statistics, traceback, threading
import numpy as np
import common
from common import rss_mb
import instrument
from instrument import CALLS, DRAWS, summarize, draws_since
from glue.core.data import Data
from glue.core.hub import HubListener
from glue.core.message import ComputationEndedMessage, ComputationStartedMessage
from glue.core.roi import RectangularROI
from glue.core.subset import RoiSubsetState
from glue.viewers.image.pixel_selection_subset_state import PixelSubsetState
from glue_qt.app import GlueApplication
from glue_qt.utils import get_qapp
from glue_qt.viewers.profile import ProfileViewer

which = sys.argv[1]
qapp = get_qapp()

# Where are whole-cube profiles computed on the main thread? Record the stack of each.
STACKS = []
_cs = Data.compute_statistic
def cs_stack(self, statistic, cid, subset_state=None, axis=None, view=None, **kw):
    if axis is not None and subset_state is None and view is None and threading.current_thread() is threading.main_thread():
        STACKS.append(''.join(traceback.format_stack(limit=22)[:-1]))
    return _cs(self, statistic, cid, subset_state=subset_state, axis=axis, view=view, **kw)
Data.compute_statistic = cs_stack


def pump(until=None, timeout=10.0, settle=0.15):
    t0 = time.perf_counter()
    while until is not None and not until() and time.perf_counter() - t0 < timeout:
        qapp.processEvents(); time.sleep(0.0005)
    last, quiet = len(DRAWS), time.perf_counter()
    while time.perf_counter() - quiet < settle:
        qapp.processEvents(); time.sleep(0.001)
        if len(DRAWS) != last:
            last, quiet = len(DRAWS), time.perf_counter()
    return time.perf_counter() - t0


app = GlueApplication()
app.resize(1600, 1000); app.show(); pump()
raster = common.load_ss() if which == 'ss' else common.load_stack()
app.data_collection.append(raster)
spectral = raster.ndim - 1
mx = 0 if raster.ndim == 3 else 1
my = mx + 1

# ---- add the cube to a Profile viewer, the plain-glue way (data layer visible) ----------------------
viewer = app.new_data_viewer(ProfileViewer)
viewer.large_data_size = None
viewer.viewer_size = (800, 400)
pump()
t = time.perf_counter()
viewer.add_data(raster)
t_add = time.perf_counter() - t
[data_artist] = list(viewer.layers)
pump(lambda: not data_artist.is_computing, timeout=60, settle=0.3)
print(f'\n== ProfileViewer.add_data(cube): main thread blocked {t_add*1e3:.0f} ms; idle after {(time.perf_counter()-t)*1e3:.0f} ms; x_att={viewer.state.x_att}; peak {rss_mb():.0f} MB')
summarize(CALLS, since=t)
for s in STACKS:
    print('--- main-thread whole-cube profile, stack ---'); print(s[-2500:])
STACKS.clear()
t = time.perf_counter()
viewer.state.x_att = raster.world_component_ids[spectral]
pump(lambda: not data_artist.is_computing, timeout=60, settle=0.3)
print(f'\n== set x_att to Wavelength: idle after {(time.perf_counter()-t)*1e3:.0f} ms; peak {rss_mb():.0f} MB')
summarize(CALLS, since=t)
print('main-thread whole-cube stacks during x_att change:', len(STACKS))
for s in STACKS[:1]:
    print(s[-2000:])
STACKS.clear()

# ---- a Point subset, then move it ------------------------------------------------------------------
centre = [s // 2 for s in raster.shape]
slices = [slice(c, c + 1) for c in centre]; slices[spectral] = slice(None)
if raster.ndim == 4:
    slices[0] = slice(0, 1)
group = app.data_collection.new_subset_group('Point', PixelSubsetState(raster, slices))
pump(settle=0.5)
[sub_artist] = [a for a in viewer.layers if a.state.layer is not raster]
data_artist.state.visible = False   # as glue-solar does: only the point's spectrum
pump(settle=0.5)

runs = []
w = sub_artist._worker
orig_fn = w.function
def counted(reset=False):
    runs.append(time.perf_counter())
    return orig_fn(reset=reset)
w.function = counted


class Msgs(HubListener):
    def __init__(self):
        self.start, self.end = [], []
        raster.hub.subscribe(self, ComputationStartedMessage, handler=lambda m: self.start.append(time.perf_counter()),
                             filter=lambda m: m.sender is sub_artist)
        raster.hub.subscribe(self, ComputationEndedMessage, handler=lambda m: self.end.append(time.perf_counter()),
                             filter=lambda m: m.sender is sub_artist)
msgs = Msgs()
cid = id(viewer.figure.canvas)


def move(k, roi=False):
    n_end, n_runs, n_draw = len(msgs.end), len(runs), len(DRAWS)
    i = (raster.shape[mx] // 2 + 5 * (k + 1)) % raster.shape[mx]
    if roi:
        state = RoiSubsetState(raster.pixel_component_ids[mx], raster.pixel_component_ids[my],
                               RectangularROI(i - 20, i + 20, centre[my] - 20, centre[my] + 20))
    else:
        sl = list(group.subset_state.slices); sl[mx] = slice(i, i + 1)
        state = PixelSubsetState(raster, sl)
    t = time.perf_counter()
    group.subset_state = state
    pump(lambda: len(msgs.end) > n_end and any(c == cid and ts > msgs.end[-1] for ts, c, _ in DRAWS[n_draw:]), timeout=10, settle=0)
    t_first = time.perf_counter() - t
    pump(settle=0.3)
    d = [dt for ts, c, dt in DRAWS[n_draw:] if c == cid]
    return t_first, len(runs) - n_runs, len(msgs.end) - n_end, len(d), sum(d)


def report(label, res):
    res = res[2:]
    print(f'== {label}: n={len(res)}: spectrum first drawn after median {statistics.median(r[0] for r in res)*1e3:.1f} ms '
          f'(min {min(r[0] for r in res)*1e3:.1f}, max {max(r[0] for r in res)*1e3:.1f}); worker runs/move {statistics.median(r[1] for r in res)}, '
          f'compute-ended msgs/move {statistics.median(r[2] for r in res)}, spectrum draws/move {statistics.median(r[3] for r in res)} '
          f'({statistics.median(r[4] for r in res)*1e3:.1f} ms of drawing)')


t = time.perf_counter()
report('point move, glue-qt threaded worker (layer size > 1e7)', [move(k) for k in range(22)])
report('ROI 40x40 move, glue-qt threaded worker', [move(k, roi=True) for k in range(12)])
print('statistics calls:'); summarize(CALLS, since=t)

# Comparison: run this layer's profile on the main thread (base-class path, in-process only)
from glue.viewers.profile.layer_artist import ProfileLayerArtist
sub_artist._calculate_profile = lambda reset=False: ProfileLayerArtist._calculate_profile(sub_artist, reset=reset)
sub_artist._calculate_profile_postthread = lambda: ProfileLayerArtist._calculate_profile_postthread(sub_artist)
group.subset_state = PixelSubsetState(raster, slices); pump(settle=0.3)
report('point move, synchronous (comparison)', [move(k) for k in range(22)])
report('ROI 40x40 move, synchronous (comparison)', [move(k, roi=True) for k in range(12)])
print(f'final peak RSS {rss_mb():.0f} MB')
