"""In-process timing wrappers around glue's statistics entry points and canvas draws (no files changed)."""
import threading, time, statistics
from glue.core.data import Data
from glue_qt.viewers.matplotlib.widget import MplCanvas

CALLS = []      # (t_start, name, thread, description, seconds, data label)
DRAWS = []      # (t_start, canvas id, seconds)
_tl = threading.local()


def _describe(name, args, kwargs):
    if name == 'compute_statistic':
        stat = args[0] if args else kwargs.get('statistic')
        ss = kwargs.get('subset_state')
        return (f"{stat} axis={kwargs.get('axis')} subset={type(ss).__name__ if ss is not None else None} "
                f"random_subset={kwargs.get('random_subset')} view={'yes' if kwargs.get('view') is not None else 'no'}")
    if name == 'compute_histogram':
        ss = kwargs.get('subset_state')
        return f"subset={type(ss).__name__ if ss is not None else None} random_subset={kwargs.get('random_subset')}"
    if name == 'compute_fixed_resolution_buffer':
        bounds = args[0] if args else kwargs.get('bounds')
        ss = kwargs.get('subset_state')
        return f"bounds={[b if not isinstance(b, tuple) else b[2] for b in bounds]} subset={type(ss).__name__ if ss is not None else None}"
    return ''


def _wrap(name):
    orig = getattr(Data, name)

    def wrapper(self, *args, **kwargs):
        depth = getattr(_tl, 'depth', 0)
        _tl.depth = depth + 1
        t = time.perf_counter()
        try:
            return orig(self, *args, **kwargs)
        finally:
            _tl.depth = depth
            if depth == 0:
                CALLS.append((t, name, threading.current_thread().name, _describe(name, args, kwargs),
                              time.perf_counter() - t, self.label[:24]))
    setattr(Data, name, wrapper)


for _name in ('compute_statistic', 'compute_histogram', 'compute_fixed_resolution_buffer'):
    _wrap(_name)

_orig_draw = MplCanvas.draw


def _draw(self, *args, **kwargs):
    t = time.perf_counter()
    try:
        return _orig_draw(self, *args, **kwargs)
    finally:
        DRAWS.append((t, id(self), time.perf_counter() - t))


MplCanvas.draw = _draw


def summarize(calls, names=None, since=0.0):
    """Group calls since `since` by (name, thread, description): count, total and max seconds."""
    groups = {}
    for t, name, thread, desc, dt, label in calls:
        if t < since:
            continue
        key = (name, 'main' if thread == 'MainThread' else 'worker', desc, label)
        groups.setdefault(key, []).append(dt)
    for key, dts in sorted(groups.items(), key=lambda kv: -sum(kv[1])):
        print(f'  {key[0]:32s} {key[1]:6s} n={len(dts):3d} total={sum(dts)*1e3:8.1f} ms max={max(dts)*1e3:7.1f} ms  {key[2]}  [{key[3]}]')


def draws_since(since, names):
    out = {}
    for t, cid, dt in DRAWS:
        if t >= since:
            out.setdefault(names.get(cid, cid), []).append(dt)
    return out
