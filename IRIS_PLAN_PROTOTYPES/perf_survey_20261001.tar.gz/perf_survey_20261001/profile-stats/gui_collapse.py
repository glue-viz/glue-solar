"""Collapse (AggregateSlice) on a glue Image viewer of an IRIS cube: where a redraw's time goes."""
import sys, time, statistics, cProfile, pstats, io
import numpy as np
import common
from common import rss_mb
import instrument
from instrument import CALLS, DRAWS, summarize
from glue.viewers.image.pixel_selection_subset_state import PixelSubsetState
from glue.viewers.image.state import AggregateSlice
from glue_qt.app import GlueApplication
from glue_qt.utils import get_qapp
from glue_qt.viewers.image import ImageViewer

which = sys.argv[1]
qapp = get_qapp()


def pump(settle=0.15):
    last, quiet = len(DRAWS), time.perf_counter()
    while time.perf_counter() - quiet < settle:
        qapp.processEvents(); time.sleep(0.001)
        if len(DRAWS) != last:
            last, quiet = len(DRAWS), time.perf_counter()


app = GlueApplication(); app.resize(1600, 1000); app.show(); pump()
raster = common.load_ss() if which == 'ss' else common.load_stack()
app.data_collection.append(raster)
spectral = raster.ndim - 1
mx = 0 if raster.ndim == 3 else 1
v = app.new_data_viewer(ImageViewer, data=raster)
v.viewer_size = (600, 450)
pix = raster.pixel_component_ids
v.state.x_att = pix[mx]; v.state.y_att = pix[mx + 1]
w0 = 150 if raster.shape[spectral] > 200 else raster.shape[spectral] // 2
sl = [0] * raster.ndim; sl[spectral] = w0
v.state.slices = tuple(sl)
v.state.aspect = 'auto'
v.state.reset_limits()
pump(0.5)
cid = id(v.figure.canvas)
print('canvas', v.figure.canvas.width(), v.figure.canvas.height(), 'dpr', v.figure.canvas.devicePixelRatio())


def redraws(n=8):
    out = []
    for k in range(n):
        dx = 0.37 * (1 if k % 2 else -1)
        n0 = len(DRAWS)
        v.state.x_min += dx; v.state.x_max += dx
        pump(0.08)
        out.append(sum(dt for ts, c, dt in DRAWS[n0:] if c == cid))
    return statistics.median(out[2:]) * 1e3


centre = [s // 2 for s in raster.shape]
point = [slice(c, c + 1) for c in centre]; point[spectral] = slice(None)
for with_point in (False, True):
    if with_point:
        group = app.data_collection.new_subset_group('Point', PixelSubsetState(raster, point)); pump(0.3)
    print(f'\n### {"with" if with_point else "without"} a Point subset layer')
    sl = list(v.state.slices); sl[spectral] = w0; v.state.slices = tuple(sl); pump(0.3)
    print(f'plain slice: map redraw after pan median {redraws():.1f} ms')
    for width in (20, 100):
        for func in (np.nanmean, np.nanmedian):
            sl = list(v.state.slices); sl[spectral] = AggregateSlice(slice(w0 - width // 2, w0 + width // 2), w0, func)
            v.state.slices = tuple(sl); pump(0.3)
            t = time.perf_counter()
            print(f'Collapse {func.__name__:9s} {width:3d} px: map redraw after pan median {redraws():.1f} ms')
            summarize(CALLS, since=t)
    pr = cProfile.Profile(); pr.enable(); redraws(4); pr.disable()
    s = io.StringIO(); st = pstats.Stats(pr, stream=s); st.sort_stats('cumulative').print_stats(r'glue|numpy|image.py|scatter_density', 30)
    print('--- cProfile 4 pans, nanmedian 100 px (cumulative, filtered) ---'); print('\n'.join(s.getvalue().splitlines()[:50]))
    s = io.StringIO(); st = pstats.Stats(pr, stream=s); st.sort_stats('tottime').print_callers(r'argsort|partition')
    print('\n'.join(s.getvalue().splitlines()[:30]))
    if with_point:
        # point moves while collapsed
        out = []
        for k in range(8):
            p = list(group.subset_state.slices); i = centre[mx] + 5 * (k + 1); p[mx] = slice(i, i + 1)
            n0 = len(DRAWS); t = time.perf_counter()
            group.subset_state = PixelSubsetState(raster, p); pump(0.08)
            out.append(sum(dt for ts, c, dt in DRAWS[n0:] if c == cid))
        print(f'point move while collapsed (nanmedian 100 px): map draw per move median {statistics.median(out[2:])*1e3:.1f} ms')
        t = time.perf_counter() - 1.0
print(f'peak RSS {rss_mb():.0f} MB')
