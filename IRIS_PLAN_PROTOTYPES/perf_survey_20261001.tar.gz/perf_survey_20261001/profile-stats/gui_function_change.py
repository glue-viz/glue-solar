"""Plain glue: Profile viewer with the cube's own layer visible; change the collapse function."""
import sys, time
import common
from common import rss_mb
import instrument
from instrument import CALLS, DRAWS, summarize
from glue_qt.app import GlueApplication
from glue_qt.utils import get_qapp
from glue_qt.viewers.profile import ProfileViewer

which = sys.argv[1]
qapp = get_qapp()


def pump(until=None, timeout=60.0, settle=0.3):
    t0 = time.perf_counter()
    while until is not None and not until() and time.perf_counter() - t0 < timeout:
        qapp.processEvents(); time.sleep(0.001)
    last, quiet = len(DRAWS), time.perf_counter()
    while time.perf_counter() - quiet < settle:
        qapp.processEvents(); time.sleep(0.001)
        if len(DRAWS) != last:
            last, quiet = len(DRAWS), time.perf_counter()


app = GlueApplication(); app.resize(1600, 1000); app.show(); pump()
raster = common.load_ss() if which == 'ss' else common.load_stack()
app.data_collection.append(raster)
v = app.new_data_viewer(ProfileViewer)
v.large_data_size = None
v.add_data(raster)
v.state.x_att = raster.world_component_ids[raster.ndim - 1]
[artist] = list(v.layers)
n0 = len(CALLS)
pump(lambda: len([c for c in CALLS[n0:] if c[2] != 'MainThread']) >= 1, settle=2.0)
for func in ('mean', 'median', 'maximum'):
    t = time.perf_counter()
    v.state.function = func
    blocked = time.perf_counter() - t
    n0 = len(CALLS)
    pump(lambda: any(c[2] != 'MainThread' and c[1] == 'compute_statistic' for c in CALLS[n0:]), settle=1.0)
    worker_done = max([c[0] + c[4] for c in CALLS if c[0] >= t] + [t]) - t
    print(f'\n== function -> {func}: main thread blocked {blocked*1e3:.0f} ms in the setter; last statistic finished at {worker_done*1e3:.0f} ms; peak {rss_mb():.0f} MB')
    summarize(CALLS, since=t)
