"""
Point-move latency of a glue Profile viewer under in-process variants of glue's code (comparison only,
nothing on disk changes). Usage: gui_worker_variants.py ss|stack orig|no_vlim|blocking|both
  no_vlim : ProfileLayerArtist._update_profile without 'v_min'/'v_max' in its recompute triggers
  blocking: ComputeWorker.run waits on its queue instead of polling every 40 ms
"""
import sys, time, statistics, queue
import common
import instrument
from instrument import DRAWS
from glue.core.hub import HubListener
from glue.core.message import ComputationEndedMessage
from glue.viewers.image.pixel_selection_subset_state import PixelSubsetState
from glue.viewers.profile.layer_artist import ProfileLayerArtist
from glue_qt.viewers.matplotlib.compute_worker import ComputeWorker
from glue_qt.app import GlueApplication
from glue_qt.utils import get_qapp
from glue_qt.viewers.profile import ProfileViewer
from glue.utils import queue_to_list

which, variant = sys.argv[1], sys.argv[2]

if variant in ('no_vlim', 'both'):
    def _update_profile(self, force=False, **kwargs):
        if (self._viewer_state.x_att is None or self.state.attribute is None or self.state.layer is None):
            return
        changed = self.pop_changed_properties()
        if force or any(prop in changed for prop in ('layer', 'x_att', 'attribute', 'function', 'normalize',
                                                     'visible', 'x_display_unit', 'y_display_unit')):
            self._calculate_profile(reset=force)
            force = True
        if force or any(prop in changed for prop in ('alpha', 'color', 'zorder', 'linewidth', 'as_steps')):
            self._update_visual_attributes()
    ProfileLayerArtist._update_profile = _update_profile

if variant in ('blocking', 'both'):
    def run(self):
        while True:
            msgs = [self.work_queue.get()] + queue_to_list(self.work_queue)
            if 'stop' in msgs:
                return
            self.running = True
            self.compute_start.emit()
            try:
                self.function(reset=any(msgs))
            except Exception:
                self.running = self.work_queue.qsize() > 0
                self.compute_error.emit(sys.exc_info())
            else:
                self.running = self.work_queue.qsize() > 0
                if not self.running:
                    self.compute_end.emit()
    ComputeWorker.run = run

qapp = get_qapp()


def pump(until=None, timeout=10.0, settle=0.15):
    t0 = time.perf_counter()
    while until is not None and not until() and time.perf_counter() - t0 < timeout:
        qapp.processEvents(); time.sleep(0.0005)
    last, quiet = len(DRAWS), time.perf_counter()
    while time.perf_counter() - quiet < settle:
        qapp.processEvents(); time.sleep(0.001)
        if len(DRAWS) != last:
            last, quiet = len(DRAWS), time.perf_counter()


app = GlueApplication(); app.resize(1600, 1000); app.show(); pump()
raster = common.load_ss() if which == 'ss' else common.load_stack()
app.data_collection.append(raster)
spectral = raster.ndim - 1
mx = 0 if raster.ndim == 3 else 1
viewer = app.new_data_viewer(ProfileViewer)
viewer.large_data_size = None
viewer.viewer_size = (800, 400)
viewer.state.function = 'mean'
viewer.add_data(raster)
viewer.state.layers[0].visible = False
viewer.state.x_att = raster.world_component_ids[spectral]
centre = [s // 2 for s in raster.shape]
slices = [slice(c, c + 1) for c in centre]; slices[spectral] = slice(None)
group = app.data_collection.new_subset_group('Point', PixelSubsetState(raster, slices))
pump(settle=1.0)
[sub_artist] = [a for a in viewer.layers if a.state.layer is not raster]
cid = id(viewer.figure.canvas)
ends = []


class L(HubListener):
    pass


listener = L()
raster.hub.subscribe(listener, ComputationEndedMessage, handler=lambda m: ends.append(time.perf_counter()),
                     filter=lambda m: m.sender is sub_artist)
res = []
for k in range(32):
    n_end, n_draw = len(ends), len(DRAWS)
    sl = list(group.subset_state.slices); i = centre[mx] + 5 * (k % 10 + 1); sl[mx] = slice(i, i + 1)
    t = time.perf_counter()
    group.subset_state = PixelSubsetState(raster, sl)
    pump(lambda: len(ends) > n_end and any(c == cid and ts > ends[-1] for ts, c, _ in DRAWS[n_draw:]), settle=0)
    first = time.perf_counter() - t
    pump(settle=0.3)
    d = [dt for ts, c, dt in DRAWS[n_draw:] if c == cid]
    res.append((first, len(d), sum(d)))
res = res[2:]
f = sorted(r[0] for r in res)
print(f'{which} {variant:9s}: n={len(res)} spectrum first drawn median {statistics.median(f)*1e3:.1f} ms '
      f'(p10 {f[len(f)//10]*1e3:.1f}, p90 {f[9*len(f)//10]*1e3:.1f}); draws/move {statistics.median(r[1] for r in res)}, '
      f'drawing {statistics.median(r[2] for r in res)*1e3:.1f} ms/move')
# check the spectrum is right: compare plotted y with numpy
import numpy as np
x, y = sub_artist.plot_artist.get_data()
ref = np.nanmean(raster.get_component(raster.main_components[0]).data[tuple(group.subset_state.slices)], axis=tuple(range(raster.ndim - 1)))
print('  plotted == numpy mean:', np.allclose(y, ref, equal_nan=True))
