"""
Candidate-fix prototypes, timed against glue's current code on the same data (scratch code only).
Usage: proto_stats.py ss|stack
"""
import sys, time, tracemalloc
import numpy as np
import common
from common import bench
from glue.core import DataCollection
from glue.utils import iterate_chunks, view_shape
from glue.viewers.image.pixel_selection_subset_state import PixelSubsetState
from fast_histogram import histogram1d

which = sys.argv[1]
data = common.load_ss() if which == 'ss' else common.load_stack()
dc = DataCollection([data])
cid = data.main_components[0]
arr = data.get_component(cid).data
spectral = data.ndim - 1
axes = tuple(range(data.ndim - 1))           # profile along wavelength
N_CHUNK = 40000000


def chunks():
    chunk_shape = list(data.shape)
    chunk_shape[spectral] = max(1, int(chunk_shape[spectral] / (data.size / N_CHUNK)))
    return iterate_chunks(data.shape, chunk_shape=chunk_shape)


def alt_stat(statistic):
    """Same chunking as glue, but no float64 copy: reduce the native array with where=isfinite."""
    out = np.empty(data.shape[spectral])
    for view in chunks():
        c = arr[view]
        fin = np.isfinite(c)
        if statistic == 'mean':
            r = np.sum(c, axis=axes, where=fin, dtype=np.float64) / np.count_nonzero(fin, axis=axes)
        elif statistic == 'maximum':
            r = np.max(c, axis=axes, where=fin, initial=-np.inf)
        out[view[spectral]] = r
    return out


print('\n## whole-data profile along wavelength (what a visible data layer costs)')
for stat in ('mean', 'maximum'):
    g = lambda: data.compute_statistic(stat, cid, axis=axes)
    a = lambda: alt_stat(stat)
    bench(f'glue compute_statistic {stat}', g, n=3)
    bench(f'prototype where=isfinite {stat}', a, n=3)
    ok = np.allclose(g(), a(), rtol=1e-5, equal_nan=True)
    print('  results agree:', ok)
    for label, fn in (('glue', g), ('prototype', a)):
        tracemalloc.start(); fn(); peak = tracemalloc.get_traced_memory()[1]; tracemalloc.stop()
        print(f'  {label} {stat}: tracemalloc peak {peak/2**20:.0f} MB')
bench('glue compute_statistic median', lambda: data.compute_statistic('median', cid, axis=axes), n=1, warm=0)

print('\n## histogram of the Point subset (a PixelSubsetState)')
centre = [s // 2 for s in data.shape]
sl = [slice(c, c + 1) for c in centre]; sl[spectral] = slice(None)
point = PixelSubsetState(data, sl)
lo, hi = np.nanpercentile(arr[::7, ::7, ...].ravel()[:1000000], [0, 100])
g = lambda: data.compute_histogram([cid], range=[(lo, hi)], bins=[15], log=[False], subset_state=point)
a = lambda: histogram1d(point.to_array(data, cid)[np.isfinite(point.to_array(data, cid))].ravel(), range=(lo, hi + 10 * np.spacing(hi)), bins=15)
bench('glue compute_histogram, Point subset', g, n=10)
bench('prototype: SliceSubsetState.to_array then histogram', a, n=10)
print('  results agree:', np.array_equal(g(), a()))
tracemalloc.start(); g(); peak = tracemalloc.get_traced_memory()[1]; tracemalloc.stop()
print(f'  glue subset histogram tracemalloc peak {peak/2**20:.0f} MB')

print('\n## histogram of the whole cube (Histogram viewer data layer)')
g = lambda: data.compute_histogram([cid], range=[(lo, hi)], bins=[15], log=[False])
bench('glue compute_histogram, whole cube', g, n=3)
tracemalloc.start(); g(); peak = tracemalloc.get_traced_memory()[1]; tracemalloc.stop()
print(f'  glue whole histogram tracemalloc peak {peak/2**20:.0f} MB')
print('  fast_histogram skips NaN itself?', histogram1d(np.array([np.nan, 0.5, 1.5]), bins=2, range=(0, 2)))
a = lambda: histogram1d(arr.ravel(), range=(lo, hi + 10 * np.spacing(hi)), bins=15)
bench('prototype: histogram1d on the raw array (no keep mask/copy)', a, n=3)
print('  results agree:', np.array_equal(g(), a()))
tracemalloc.start(); a(); peak = tracemalloc.get_traced_memory()[1]; tracemalloc.stop()
print(f'  prototype tracemalloc peak {peak/2**20:.0f} MB')
r = lambda: data.compute_histogram([cid], range=[(lo, hi)], bins=[15], log=[False], random_subset=1000000)
bench('glue compute_histogram with random_subset=1e6 (viewer option)', r, n=3)

print('\n## Collapse: the fixed-resolution buffer of a 100-px nanmedian/nanmean map (bounds as measured on screen)')
ny, nx, nagg = 196, 333, 100
w0 = 150 if data.shape[spectral] > 200 else data.shape[spectral] // 2
if data.ndim == 3:
    bounds = [(0, data.shape[0] - 1, nx), (0, data.shape[1] - 1, ny), (w0 - 50, w0 + 49, nagg)]
else:
    bounds = [0, (0, data.shape[1] - 1, nx), (0, data.shape[2] - 1, ny), (w0 - 50, w0 + 49, nagg)]
frb = lambda: data.compute_fixed_resolution_buffer(bounds, target_data=data, target_cid=cid, broadcast=False)
buf = frb()
print('buffer', buf.shape, buf.dtype, f'{buf.nbytes/2**20:.0f} MB')
bench('glue FRB gather (data layer)', frb, n=5)
bench('np.nanmedian on the buffer (as glue applies it)', lambda: np.nanmedian(buf, axis=-1), n=5)
bench('np.nanmean on the buffer', lambda: np.nanmean(buf, axis=-1), n=5)


def nanmedian_sort(b, axis=-1):
    s = np.sort(b, axis=axis)                       # NaN sort last
    n = np.count_nonzero(~np.isnan(b), axis=axis)
    lo_i = np.maximum((n - 1) // 2, 0)[..., None]; hi_i = np.maximum(n // 2, 0)[..., None]
    r = 0.5 * (np.take_along_axis(s, lo_i, axis) + np.take_along_axis(s, hi_i, axis))[..., 0]
    return np.where(n > 0, r, np.nan)


bench('prototype sort-based nanmedian on the buffer', lambda: nanmedian_sort(buf), n=5)
print('  results agree:', np.allclose(np.nanmedian(buf, axis=-1), nanmedian_sort(buf), equal_nan=True))
# subset layer: the Point's mask buffer, aggregated with the same function
mbuf = data.compute_fixed_resolution_buffer(bounds, target_data=data, subset_state=point, broadcast=False)
bench('glue FRB gather (Point subset mask)', lambda: data.compute_fixed_resolution_buffer(bounds, target_data=data, subset_state=point, broadcast=False), n=5)
bench('np.nanmedian on the bool mask buffer (as glue applies it)', lambda: np.nanmedian(mbuf, axis=-1), n=5)
bench('prototype np.any on the mask buffer', lambda: np.any(mbuf, axis=-1), n=5)
print('  any vs nanmedian>0 agree:', np.array_equal(np.any(mbuf, axis=-1), np.nanmedian(mbuf, axis=-1) > 0))
# view_shape on the gathered index arrays
pc = [np.linspace(*b) if isinstance(b, tuple) else b for b in bounds]
idx = tuple(np.round(c).astype(int) for c in np.meshgrid(*pc, indexing='ij', copy=False))
bench('glue view_shape(shape, index arrays)', lambda: view_shape(data.shape, idx), n=5)
bench('prototype np.broadcast_shapes(*index shapes)', lambda: np.broadcast_shapes(*(i.shape for i in idx)), n=5)
# collapse once at native resolution, then the FRB is a plain 2D slice
nat = [slice(None)] * data.ndim; nat[spectral] = slice(w0 - 50, w0 + 50)
if data.ndim == 4:
    nat[0] = 0
bench('prototype: nanmean once at native resolution over 100 px', lambda: np.nanmean(arr[tuple(nat)], axis=-1), n=2)
bench('prototype: sort-nanmedian once at native resolution over 100 px', lambda: nanmedian_sort(arr[tuple(nat)].astype(np.float32)), n=2, warm=0)
