"""
Quicklook in a real (offscreen) GlueApplication: open, point moves (spectrum latency), Collapse map,
per-slice percentile, Histogram viewer. Usage: gui_quicklook.py ss|stack
"""
import sys, time, statistics, cProfile, pstats, io
import numpy as np
import common
from common import rss_mb
import instrument
from instrument import CALLS, DRAWS, summarize, draws_since

from glue.core.hub import HubListener
from glue.core.message import ComputationEndedMessage
from glue.viewers.image.pixel_selection_subset_state import PixelSubsetState
from glue.viewers.image.state import AggregateSlice
from glue_qt.app import GlueApplication
from glue_qt.utils import get_qapp
from glue_solar.quicklook import quicklook
from glue_solar.sources.loaders.iris import image_data

which = sys.argv[1]
qapp = get_qapp()


def pump(until=None, timeout=5.0, settle=0.15):
    """Process events until `until()` is true (or timeout), then until nothing has drawn for `settle` s."""
    t0 = time.perf_counter()
    while until is not None and not until() and time.perf_counter() - t0 < timeout:
        qapp.processEvents(); time.sleep(0.0005)
    last = len(DRAWS)
    quiet = time.perf_counter()
    while time.perf_counter() - quiet < settle and time.perf_counter() - t0 < timeout + 5:
        qapp.processEvents(); time.sleep(0.001)
        if len(DRAWS) != last:
            last = len(DRAWS); quiet = time.perf_counter()
    return time.perf_counter() - t0


app = GlueApplication()
app.resize(1600, 1000)
app.show()
pump()

if which == 'ss':
    raster = common.load_ss()
    sji = image_data(common.SS_SJI)
else:
    raster = common.load_stack()
    sji = image_data(common.SCAN_SJI)
print('SJI', sji.label, sji.shape, f'peak {rss_mb():.0f} MB')

# ---- open the quicklook --------------------------------------------------------------------------
t0 = time.perf_counter()
pr = cProfile.Profile(); pr.enable()
viewers = quicklook(app, [raster, sji])
t_ql = time.perf_counter() - t0
pump(timeout=10, settle=1.0)
pr.disable()
t_open = time.perf_counter() - t0
names = {}
for role in ('map', 'spectrogram', 'wavelength', 'spectrum'):
    names[id(viewers[role].figure.canvas)] = role
for i, v in enumerate(viewers['sji']):
    names[id(v.figure.canvas)] = f'sji{i}'
print(f'\n== quicklook() returned in {t_ql:.2f} s; settled (incl. 1 s idle wait) at {t_open:.2f} s; peak {rss_mb():.0f} MB')
print('statistics calls during open:'); summarize(CALLS, since=t0)
s = io.StringIO(); pstats.Stats(pr, stream=s).sort_stats('cumulative').print_stats(25)
print('\n'.join(s.getvalue().splitlines()[:45]))
print('draws during open:', {k: (len(v), round(sum(v) * 1e3)) for k, v in draws_since(t0, names).items()})
print('viewer sizes:', {r: (viewers[r].figure.canvas.width(), viewers[r].figure.canvas.height(), viewers[r].figure.canvas.devicePixelRatio()) for r in ('map', 'spectrum')})

# ---- point moves -----------------------------------------------------------------------------------
spectrum = viewers['spectrum']
group = [g for g in app.data_collection.subset_groups if g.label == 'Point'][0]
[sub] = [s for s in group.subsets if s.data is raster]
[spec_artist] = [a for a in spectrum.layers if a.state.layer is sub]
print('spectrum subset artist:', type(spec_artist).__name__, 'threaded because size', raster.size, '> 1e7')


class Ends(HubListener):
    def __init__(self):
        self.t = []
        raster.hub.subscribe(self, ComputationEndedMessage, handler=lambda m: self.t.append(time.perf_counter()),
                             filter=lambda m: m.sender is spec_artist)


ends = Ends()
spec_cid = id(spectrum.figure.canvas)
mx = 0 if raster.ndim == 3 else 1


def move_point(k):
    slices = list(group.subset_state.slices)
    i = (raster.shape[mx] // 2 + 7 * (k + 1)) % raster.shape[mx]
    slices[mx] = slice(i, i + 1)
    n_end = len(ends.t)
    t = time.perf_counter()
    group.subset_state = PixelSubsetState(raster, slices)
    t_set = time.perf_counter() - t

    def spectrum_drawn():
        return len(ends.t) > n_end and any(c == spec_cid and ts > ends.t[-1] for ts, c, _ in DRAWS[-20:])
    pump(spectrum_drawn, timeout=5, settle=0.0)
    t_spec = time.perf_counter() - t
    t_end = ends.t[-1] - t if len(ends.t) > n_end else float('nan')
    pump(settle=0.25)
    d = draws_since(t, names)
    return t_set, t_end, t_spec, d


def run_moves(label, n=12):
    res = [move_point(k) for k in range(n)]
    res = res[2:]   # warm-up
    med = lambda xs: statistics.median(xs) * 1e3
    print(f'\n== point move [{label}] n={len(res)} medians: set subset_state {med([r[0] for r in res]):.1f} ms, '
          f'compute end {med([r[1] for r in res]):.1f} ms, spectrum drawn {med([r[2] for r in res]):.1f} ms')
    allroles = sorted({k for r in res for k in r[3]}, key=str)
    for role in allroles:
        per = [sum(r[3].get(role, [])) for r in res]
        cnt = [len(r[3].get(role, [])) for r in res]
        print(f'   draws of {role}: median {statistics.median(cnt)} per move, median {med(per):.1f} ms per move')


t_moves = time.perf_counter()
run_moves('glue-qt threaded worker')
print('statistics calls during moves:'); summarize(CALLS, since=t_moves)

# In-process comparison: compute this layer's profile synchronously (the base class path)
from glue.viewers.profile.layer_artist import ProfileLayerArtist
spec_artist._calculate_profile = lambda reset=False: ProfileLayerArtist._calculate_profile(spec_artist, reset=reset)
spec_artist._calculate_profile_postthread = lambda: ProfileLayerArtist._calculate_profile_postthread(spec_artist)
run_moves('synchronous profile (in-process monkeypatch, comparison only)')

# cProfile one synchronous move on the main thread
pr = cProfile.Profile(); pr.enable()
for k in range(5):
    move_point(20 + k)
pr.disable()
s = io.StringIO(); pstats.Stats(pr, stream=s).sort_stats('tottime').print_stats(20)
print('--- cProfile 5 synchronous moves, by tottime (includes 0.25 s settle pumps) ---')
print('\n'.join(s.getvalue().splitlines()[:40]))
s = io.StringIO(); pstats.Stats(pr, stream=s).sort_stats('cumulative').print_stats(40)
print('--- by cumulative ---')
print('\n'.join(s.getvalue().splitlines()[:60]))

# ---- slider ticks with global vs per-slice percentile --------------------------------------------
mp = viewers['map']
spectral = raster.ndim - 1


def tick_map(n=12):
    out = []
    for k in range(n):
        sl = list(mp.state.slices)
        sl[spectral] = (sl[spectral] + 1) % raster.shape[spectral] if not isinstance(sl[spectral], AggregateSlice) else sl[spectral]
        t = time.perf_counter(); c0 = len(CALLS)
        mp.state.slices = tuple(sl)
        pump(settle=0.1)
        d = draws_since(t, names).get('map', [])
        out.append((sum(d), len(d), sum(c[4] for c in CALLS[c0:] if c[1] == 'compute_statistic')))
    out = out[2:]
    return (statistics.median([o[0] for o in out]) * 1e3, statistics.median([o[1] for o in out]),
            statistics.median([o[2] for o in out]) * 1e3)


layer = mp.state.layers[0]
print(f'\n== map wavelength slider tick (stretch_global={layer.stretch_global}): map draw median %.1f ms, %.0f draws, compute_statistic %.1f ms' % tick_map())
layer.stretch_global = False
pump()
print(f'== map wavelength slider tick (stretch_global={layer.stretch_global}): map draw median %.1f ms, %.0f draws, compute_statistic %.1f ms' % tick_map())
t = time.perf_counter(); summarize(CALLS, since=t - 3)
layer.stretch_global = True
pump()

# ---- Collapse (AggregateSlice) on the map -------------------------------------------------------
sl = list(mp.state.slices)
centre = sl[spectral]
w0 = int(centre)


def map_redraw_times(n=6, pan=True):
    """Pan by a fraction of a pixel each time so the fixed-resolution buffer is recomputed, then time the map draws."""
    out = []
    for k in range(n):
        t = time.perf_counter()
        if pan:
            dx = 0.37 * (1 if k % 2 else -1)
            mp.state.x_min += dx; mp.state.x_max += dx
        pump(settle=0.1)
        d = draws_since(t, names).get('map', [])
        out.append(sum(d))
    return statistics.median(out[1:]) * 1e3


print(f'\n== map redraw after pan, plain slice: median {map_redraw_times():.1f} ms')
for width in (20, 100):
    for func in (np.nanmean, np.nanmedian):
        sl = list(mp.state.slices)
        sl[spectral] = AggregateSlice(slice(max(w0 - width // 2, 0), w0 + width // 2), w0, func)
        t = time.perf_counter(); c0 = len(CALLS)
        mp.state.slices = tuple(sl)
        pump(settle=0.2)
        first = sum(draws_since(t, names).get('map', []))
        print(f'== Collapse {func.__name__} over {width} px: first map draw {first*1e3:.0f} ms; redraw after pan median {map_redraw_times():.0f} ms; peak {rss_mb():.0f} MB')
        summarize(CALLS, since=t)
pr = cProfile.Profile(); pr.enable()
map_redraw_times(n=3)
pr.disable()
s = io.StringIO(); pstats.Stats(pr, stream=s).sort_stats('tottime').print_stats(12)
print('--- cProfile Collapse nanmedian 100 px pans, by tottime ---')
print('\n'.join(s.getvalue().splitlines()[:30]))
# point move while collapsed
run_moves('with Collapse nanmedian 100 px on the map', n=6)
sl = list(mp.state.slices); sl[spectral] = w0; mp.state.slices = tuple(sl); pump()

# ---- Histogram viewer on the cube ----------------------------------------------------------------
from glue_qt.viewers.histogram import HistogramViewer
t = time.perf_counter()
hv = app.new_data_viewer(HistogramViewer)
hv.large_data_size = None
hv.add_data(raster)
names[id(hv.figure.canvas)] = 'histogram'
artists = list(hv.layers)
pump(lambda: not any(getattr(a, 'is_computing', False) for a in artists), timeout=60, settle=0.5)
print(f'\n== Histogram viewer + add_data(raster): {time.perf_counter() - t:.2f} s until idle; x_att={hv.state.x_att}; peak {rss_mb():.0f} MB')
summarize(CALLS, since=t)
print('layers in histogram:', [(type(a.state.layer).__name__, a.state.layer.label) for a in hv.layers])
t = time.perf_counter()
run_moves('with a Histogram viewer of the cube open', n=6)
print('statistics calls during moves:'); summarize(CALLS, since=t)
print(f'final peak RSS {rss_mb():.0f} MB')
