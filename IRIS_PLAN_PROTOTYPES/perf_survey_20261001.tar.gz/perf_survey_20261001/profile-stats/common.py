"""Shared helpers: load IRIS data through glue-solar, timing, memory."""
import sys, glob, time, resource, statistics
sys.path.insert(0, '/Users/nabil/Git/glue-solar-main')
import glue_solar
print('glue_solar from', glue_solar.__file__, flush=True)

D = '/Users/nabil/DATA/IRIS'
SS_RASTER = glob.glob(f'{D}/*4000255147_raster/*_r00000.fits')
SS_SJI = glob.glob(f'{D}/*4000255147_SJI_1400_t000.fits.gz')[0]
SCAN_RASTERS = sorted(glob.glob(f'{D}/*4000005156_raster/*.fits'))
SCAN_SJI = glob.glob(f'{D}/*4000005156_SJI_2796_t000_deconvolved.fits.gz')[0]


def rss_mb():
    # macOS ru_maxrss is bytes
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 2**20


def load_ss(window='Si IV 1403'):
    from glue_solar.sources.loaders.iris import raster_data
    t = time.perf_counter()
    [data] = raster_data(SS_RASTER, windows=[window])
    print(f'load {window} sit-and-stare: {time.perf_counter() - t:.2f} s shape {data.shape} peak {rss_mb():.0f} MB', flush=True)
    return data


def load_stack(window='Si IV 1403'):
    from glue_solar.sources.loaders.iris import raster_data
    t = time.perf_counter()
    [data] = raster_data(SCAN_RASTERS, windows=[window], stack=True)
    print(f'load {window} stack: {time.perf_counter() - t:.2f} s shape {data.shape} peak {rss_mb():.0f} MB', flush=True)
    return data


def bench(label, fn, n=5, warm=1):
    for _ in range(warm):
        fn()
    ts = []
    for _ in range(n):
        t = time.perf_counter()
        fn()
        ts.append(time.perf_counter() - t)
    med = statistics.median(ts)
    print(f'{label}: median {med*1e3:.1f} ms  (n={n}, min {min(ts)*1e3:.1f}, max {max(ts)*1e3:.1f})  peak {rss_mb():.0f} MB', flush=True)
    return med
