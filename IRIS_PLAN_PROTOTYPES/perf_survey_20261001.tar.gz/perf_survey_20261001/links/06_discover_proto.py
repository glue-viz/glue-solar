"""(3) Expected gain of a level-by-level discover_links (indexed by input cid) against glue's, on the same links."""
import itertools
import sys
import time
from collections import defaultdict

from common import OBS, banner, rss_mb

banner()
SIZES = [int(n) for n in (sys.argv[1].split(",") if len(sys.argv) > 1 else "9,36".split(","))]
SKIP_GLUE_PAIRS_ABOVE = int(sys.argv[2]) if len(sys.argv) > 2 else 36

from glue.core import DataCollection
from glue.core.link_helpers import LinkSame
from glue.core.link_manager import discover_links
from glue_solar.sources.loaders.iris import link_hpc, raster_data


def discover_links_levels(data, links):
    """Same contract as glue's discover_links: cid -> the link that derives it at the least depth."""
    by_input = defaultdict(list)
    free = []
    for link in links:
        inputs = set(link.get_from_ids())
        (free if not inputs else None) is not None and free.append(link)
        for cid in inputs:
            by_input[cid].append(link)
    depth = {cid: 0 for cid in data.main_components + data.coordinate_components}
    cid_links = {}
    for link in free:
        to = link.get_to_id()
        if to not in depth:
            depth[to], cid_links[to] = 1, link
    frontier, level = [c for c, d in depth.items()], 0
    while frontier:
        nxt = []
        for link in {id(l): l for c in frontier for l in by_input[c]}.values():
            inputs = link.get_from_ids()
            if all(c in depth for c in inputs):
                to = link.get_to_id()
                cost = max(depth[c] for c in inputs) + 1
                if to not in depth or cost < depth[to]:
                    depth[to], cid_links[to] = cost, link
                    nxt.append(to)
        frontier, level = nxt, level + 1
    return cid_links


def depths(data, cid_links):
    own = set(data.main_components + data.coordinate_components)
    memo = {}

    def d(cid):
        if cid in own:
            return 0
        if cid not in memo:
            memo[cid] = max((d(c) for c in cid_links[cid].get_from_ids()), default=0) + 1
        return memo[cid]

    return {cid: d(cid) for cid in cid_links}


def hpc(data):
    return [cid for p, cid in zip(data.coords.world_axis_physical_types[::-1], data.world_component_ids)
            if p and p.startswith("custom:pos.helioprojective.")]


def pairs(dc):
    return [LinkSame(x, y) for a, b in itertools.combinations(list(dc), 2) for x, y in zip(hpc(a), hpc(b))]


for n in SIZES:
    for topo, make in (("star", link_hpc), ("all-pairs", pairs)):
        dc = DataCollection(raster_data(OBS["3602506433"]["raster"][:n], windows=["Si IV 1394"]))
        lm = dc._link_manager
        lm._external_links.extend(make(dc))  # no update yet: time discovery on its own
        links = lm._links | lm._inverse_links
        t = time.perf_counter()
        new = [discover_links_levels(d, links) for d in dc]
        t_new = time.perf_counter() - t
        if topo == "all-pairs" and n > SKIP_GLUE_PAIRS_ABOVE:
            print(f"N={n:3d} {topo:9s} links {len(links):6d}: levels {t_new:.3f} s (glue's skipped)")
            continue
        t = time.perf_counter()
        old = [discover_links(d, links) for d in dc]
        t_old = time.perf_counter() - t
        same = all(set(a) == set(b) and depths(d, a) == depths(d, b) for d, a, b in zip(dc, old, new))
        print(f"N={n:3d} {topo:9s} links {len(links):6d}: glue discover_links {t_old:.3f} s, levels {t_new:.3f} s "
              f"({t_old / t_new:.0f}x), same cids and depths: {same}")
print("rss MB", round(rss_mb()))
