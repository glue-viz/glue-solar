"""Shared setup for the links/subsets measurements (measure only, nothing patched)."""
import glob
import resource
import statistics
import sys
import time

sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
import glue_solar  # noqa: E402

D = "/Users/nabil/DATA/IRIS"
OBS = {
    "4000255147": dict(
        raster=sorted(glob.glob(f"{D}/*4000255147_raster/*_r00000.fits")),
        sji=glob.glob(f"{D}/*4000255147_SJI_1400_t000.fits.gz")[0],
    ),
    "4000005156": dict(
        raster=sorted(glob.glob(f"{D}/*4000005156_raster/*.fits")),
        sji=glob.glob(f"{D}/*4000005156_SJI_2796_t000_deconvolved.fits.gz")[0],
    ),
    "3602506433": dict(raster=sorted(glob.glob(f"{D}/*3602506433_raster/*.fits")), sji=None),
    "3824262996": dict(raster=sorted(glob.glob(f"{D}/*3824262996_raster/*.fits")), sji=None),
}


def rss_mb():
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 2**20  # macOS: bytes


def banner():
    import glue
    import irispy
    import importlib.metadata as m

    print("glue_solar", glue_solar.__file__)
    print("glue", glue.__version__, "glue-qt", m.version("glue-qt"), "irispy", irispy.__version__)


def timeit(fn, n):
    out = []
    for _ in range(n):
        t = time.perf_counter()
        fn()
        out.append(time.perf_counter() - t)
    return out


def summary(ts):
    return f"median {statistics.median(ts):.4f} s  min {min(ts):.4f}  max {max(ts):.4f}  n={len(ts)}"


def make_app():
    from glue_qt.app import GlueApplication
    from glue_qt.utils import get_qapp

    get_qapp()
    app = GlueApplication()
    app.resize(1600, 1000)
    app.show()
    events()
    return app


def events(n=3):
    from glue_qt.utils import process_events

    for _ in range(n):
        process_events()


def load(obs, windows=("Si IV 1403",), sji=True):
    from glue_solar.sources.loaders.iris import image_data, raster_data

    o = OBS[obs]
    out = raster_data(o["raster"], windows=list(windows))
    if sji and o["sji"]:
        out.append(image_data(o["sji"]))
    return out


class Sampler:
    """Poor man's sampling profiler of the main thread (cProfile in 3.13 mixes in Qt worker threads)."""

    def __init__(self, interval=0.001):
        import collections
        import threading

        self.interval, self.main = interval, threading.main_thread().ident
        self.incl, self.excl, self.n = collections.Counter(), collections.Counter(), 0
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True)

    def _run(self):
        while not self._stop.is_set():
            frame = sys._current_frames().get(self.main)
            seen = set()
            leaf = True
            while frame is not None:
                code = frame.f_code
                key = f"{code.co_filename.split('site-packages/')[-1]}:{code.co_firstlineno}({code.co_name})"
                if leaf:
                    self.excl[key] += 1
                    leaf = False
                if key not in seen:
                    self.incl[key] += 1
                    seen.add(key)
                frame = frame.f_back
            self.n += 1
            time.sleep(self.interval)

    def __enter__(self):
        self._thread.start()
        return self

    def __exit__(self, *exc):
        self._stop.set()
        self._thread.join()

    def report(self, top=30, match=("glue", "matplotlib", "astropy", "numpy", "mpl_scatter")):
        print(f"--- sampler: {self.n} samples of the main thread")
        print("inclusive:")
        for key, c in self.incl.most_common(400)[:400]:
            if any(m in key for m in match) and top > 0:
                print(f"  {100 * c / self.n:5.1f}%  {key}")
                top -= 1
        print("exclusive (leaf):")
        for key, c in self.excl.most_common(15):
            print(f"  {100 * c / self.n:5.1f}%  {key}")
