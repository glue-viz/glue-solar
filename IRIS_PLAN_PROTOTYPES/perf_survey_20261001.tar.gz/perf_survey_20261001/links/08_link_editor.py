"""(3) glue-qt's Link Data dialog with N linked IRIS datasets: open, and OK without changes."""
import sys
import time

from common import OBS, banner, events, rss_mb

banner()
N = int(sys.argv[1]) if len(sys.argv) > 1 else 36
from glue.core import DataCollection
from glue.core.hub import HubListener
from glue.core.message import ExternallyDerivableComponentsChangedMessage
from glue_qt.dialogs.link_editor.link_editor import LinkEditor
from glue_qt.utils import get_qapp
from glue_solar.sources.loaders.iris import link_hpc, raster_data

get_qapp()
dc = DataCollection(raster_data(OBS["3602506433"]["raster"][:N], windows=["Si IV 1394"]))
dc.add_link(link_hpc(dc))
lm = dc._link_manager
calls = {"update": 0, "msg": 0}
orig = lm.update_externally_derivable_components


def counted(*a, **k):
    calls["update"] += 1
    return orig(*a, **k)


lm.update_externally_derivable_components = counted


class L(HubListener):
    def __init__(self):
        dc.hub.subscribe(self, ExternallyDerivableComponentsChangedMessage, handler=self.on)

    def on(self, m):
        calls["msg"] += 1


listener = L()
t0 = time.perf_counter()
editor = LinkEditor(dc)
editor.show()
events()
t1 = time.perf_counter()
editor.accept()
t2 = time.perf_counter()
print(f"N={N} links {len(dc.external_links)}: open Link Data {t1 - t0:.3f} s; OK without changes {t2 - t1:.3f} s; "
      f"link updates {calls['update']}, ExternallyDerivableComponentsChangedMessage x{calls['msg']}")
print("rss MB", round(rss_mb()))
