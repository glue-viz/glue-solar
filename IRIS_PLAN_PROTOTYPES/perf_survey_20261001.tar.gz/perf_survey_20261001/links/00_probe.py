"""Probe: WCS types and the link chain glue builds from an SJI to the raster's pixel axes."""
import sys

from common import banner, load, rss_mb

banner()
obs = sys.argv[1] if len(sys.argv) > 1 else "4000255147"
from glue.core import DataCollection
from glue_solar.sources.loaders.iris import keep_hpc_linked

ds = load(obs)
dc = DataCollection(ds)
keep_hpc_linked(dc)
for d in ds:
    print(d.label, d.shape, type(d.coords._wcs).__name__, d.coords.axis_correlation_matrix.astype(int).tolist(),
          d.coords.world_axis_physical_types)
print("links", len(dc.links))
sji, raster = ds[-1], ds[0]


def chain(data, cid, depth=0):
    link = data._get_external_link(cid)
    if link is None:
        print("  " * depth, cid, "(own)" if cid.parent is data else "?")
        return
    print("  " * depth, cid, "<-", type(link).__name__, getattr(link, "pixel2world", ""), [str(f) for f in link.get_from_ids()])
    for f in link.get_from_ids():
        chain(data, f, depth + 1)


for pix in raster.pixel_component_ids:
    print("raster pixel on SJI:", pix)
    chain(sji, pix)
print("rss MB", rss_mb())
