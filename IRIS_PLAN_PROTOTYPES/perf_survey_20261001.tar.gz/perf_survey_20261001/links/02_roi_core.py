"""(1) Single-threaded breakdown of the SJI mask of a raster-pixel ROI (no Qt, so cProfile is clean)."""
import cProfile
import pstats
import sys
import time

import numpy as np
from common import banner, load, rss_mb, summary, timeit

banner()
obs = sys.argv[1] if len(sys.argv) > 1 else "4000255147"
# frame, y0, y1, ny, x0, x1, nx: the bounds glue's FRB artist used in 01 (dpr 1); SCALE=2 for dpr 2
T, Y0, Y1, NY, X0, X1, NX = (float(v) for v in sys.argv[2:9])
SCALE = int(sys.argv[9]) if len(sys.argv) > 9 else 1
T, NY, NX = int(T), int(NY) * SCALE, int(NX) * SCALE
REP = 3

from glue.core import DataCollection
from glue.core.roi import RectangularROI
from glue.core.subset import RoiSubsetState
from glue_solar.sources.loaders.iris import keep_hpc_linked

ds = load(obs)
dc = DataCollection(ds)
keep_hpc_linked(dc)
raster, sji = ds[0], ds[-1]
print(raster.label, raster.shape, sji.label, sji.shape, "rss MB", round(rss_mb()))
print("raster WCS\n", raster.coords._wcs)
nx, ny = raster.shape[0], raster.shape[1]
state = RoiSubsetState(raster.pixel_component_ids[0], raster.pixel_component_ids[1],
                       RectangularROI(0.25 * nx, 0.75 * nx, 0.25 * ny, 0.75 * ny))
t = T
bounds = [t, (Y0, Y1, NY), (X0, X1, NX)]
print("screen buffer", NX, "x", NY, "=", NX * NY, "pixels")


def frb():
    return sji.compute_fixed_resolution_buffer(bounds, target_data=sji, subset_state=state)


mask = frb()
print("mask true fraction", mask.mean(), "shape", mask.shape)
ts = timeit(frb, REP)
print("FRB mask (what one SJI frame draw computes)", summary(ts))
total = np.median(ts)

# The same view glue builds, then each piece on its own
pix = np.meshgrid(*[np.linspace(*b) if isinstance(b, tuple) else b for b in bounds], indexing="ij", copy=False)
view = tuple(np.broadcast_to(np.round(p).astype(int), pix[0].shape) for p in pix)
parts = {}
for i, cid in enumerate(raster.pixel_component_ids[:2]):
    parts[f"sji[raster pixel {i}] (link chain)"] = lambda cid=cid: sji[cid, view]
for i, cid in enumerate(sji.world_component_ids):
    parts[f"sji[own world {i} {cid.label}]"] = lambda cid=cid: sji[cid, view]
for i, cid in enumerate(raster.world_component_ids):
    try:
        sji[cid, view]
        parts[f"sji[raster world {i} {cid.label}] (LinkSame)"] = lambda cid=cid: sji[cid, view]
    except Exception as e:
        print("raster world", i, "not on sji:", type(e).__name__)
x0 = sji[raster.pixel_component_ids[0], view]
x1 = sji[raster.pixel_component_ids[1], view]
parts["roi.contains"] = lambda: state.roi.contains(x0, x1)

# raw WCS calls on the same number of points
p3 = [v.ravel().astype(float) for v in view[::-1]]  # WCS order x, y, t
wl = sji.coords.pixel_to_world_values(*p3)
parts["SJI _GlueWCS.pixel_to_world_values (all axes, 1 call)"] = lambda: sji.coords.pixel_to_world_values(*p3)
parts["SJI astropy pixel_to_world_values (unwrapped, 1 call)"] = lambda: sji.coords._wcs.pixel_to_world_values(*p3)
lon, lat = wl[0], wl[1]
rw = [np.full_like(lon, 0.0), lat, lon]  # raster world order: wavelength, lat, lon (arcsec in the wrapper)
raster_wcs_axes = raster.coords.world_axis_physical_types
print("raster world axes", raster_wcs_axes)
order = {p: i for i, p in enumerate(raster_wcs_axes)}
rw = [None] * 3
rw[order["em.wl"]] = np.zeros_like(lon)
rw[order["custom:pos.helioprojective.lat"]] = lat
rw[order["custom:pos.helioprojective.lon"]] = lon
parts["raster _GlueWCS.world_to_pixel_values (1 call)"] = lambda: raster.coords.world_to_pixel_values(*rw)
print("finite raster pixels from world:", [np.isfinite(a).mean() for a in raster.coords.world_to_pixel_values(*rw)])

res = {}
for name, fn in (parts.items() if SCALE == 1 else ()):
    ts = timeit(fn, REP)
    res[name] = np.median(ts)
    print(f"{name:60s} {summary(ts)}  ({100 * res[name] / total:.0f}% of FRB)")

# Candidate fix (b): only invert where the ROI can be. Map the ROI outline forward (raster pixel ->
# world -> SJI pixel at frame t: cheap) and invert only the screen pixels in its bounding box.
r = state.roi
edge = np.linspace(0, 1, 50)
rx = np.concatenate([r.xmin + (r.xmax - r.xmin) * edge, np.full(50, r.xmax), r.xmax - (r.xmax - r.xmin) * edge, np.full(50, r.xmin)])
ry = np.concatenate([np.full(50, r.ymin), r.ymin + (r.ymax - r.ymin) * edge, np.full(50, r.ymax), r.ymax - (r.ymax - r.ymin) * edge])


def culled():
    rpix = [np.zeros_like(rx)] * 3
    rpix = [np.zeros_like(rx), ry, rx]  # raster WCS pixel order: wave, slit, step
    rworld = raster.coords.pixel_to_world_values(*rpix)
    w = {p: rworld[i] for i, p in enumerate(raster.coords.world_axis_physical_types)}
    sw = [None] * 3
    for i, p in enumerate(sji.coords.world_axis_physical_types):
        sw[i] = {"custom:pos.helioprojective.lon": w["custom:pos.helioprojective.lon"],
                 "custom:pos.helioprojective.lat": w["custom:pos.helioprojective.lat"]}.get(p)
    tw = sji.coords.pixel_to_world_values(0.0, 0.0, float(t))[2]
    sw[2] = np.full_like(rx, tw)
    sx, sy, _ = sji.coords.world_to_pixel_values(*sw)
    inside = (view[2] >= np.nanmin(sx) - 2) & (view[2] <= np.nanmax(sx) + 2) & (view[1] >= np.nanmin(sy) - 2) & (view[1] <= np.nanmax(sy) + 2)
    out = np.zeros(view[0].shape, bool)
    if inside.any():
        sub = tuple(v[inside].astype(float) for v in view[::-1])
        ww = sji.coords.pixel_to_world_values(*sub)
        rw2 = [None] * 3
        rw2[order["em.wl"]] = np.zeros_like(ww[0])
        rw2[order["custom:pos.helioprojective.lat"]] = ww[1]
        rw2[order["custom:pos.helioprojective.lon"]] = ww[0]
        p = raster.coords.world_to_pixel_values(*rw2)
        out[inside] = r.contains(p[2], p[1])
    return out, inside.mean()


cm, frac = culled()
ts = timeit(culled, REP)
print(f"candidate (b) bbox-culled single inversion: {summary(ts)} ({100 * np.median(ts) / total:.1f}% of FRB), "
      f"bbox covers {100 * frac:.1f}% of the buffer; mask agrees with glue's: {np.mean(cm == mask) * 100:.3f}%")

pr = cProfile.Profile()
pr.enable()
frb()
pr.disable()
pr.dump_stats(f"links/02_roi_core_{obs}_{NX}x{NY}.prof")
st = pstats.Stats(pr)
st.sort_stats("cumulative").print_stats(30)
st.sort_stats("tottime").print_stats(15)
print("rss MB", round(rss_mb()))
