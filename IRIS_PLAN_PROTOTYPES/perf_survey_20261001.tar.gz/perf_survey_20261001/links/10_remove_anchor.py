"""(3) Removing the dataset the link_hpc star is anchored on: glue runs one full link update per removed link."""
import sys
import time

from common import OBS, banner

banner()
from glue.core import DataCollection
from glue_solar.sources.loaders.iris import link_hpc, raster_data

for n in [int(v) for v in sys.argv[1].split(",")]:
    dc = DataCollection(raster_data(OBS["3602506433"]["raster"][:n], windows=["Si IV 1394"]))
    dc.add_link(link_hpc(dc))
    lm = dc._link_manager
    t = time.perf_counter()
    lm.update_externally_derivable_components()
    one = time.perf_counter() - t
    count = [0]
    orig = lm.update_externally_derivable_components

    def counted(*a, **k):
        count[0] += 1
        return orig(*a, **k)

    lm.update_externally_derivable_components = counted
    t = time.perf_counter()
    dc.remove(dc[0])
    print(f"N={n}: one update {one:.3f} s; remove the anchor: {count[0]} updates, {time.perf_counter() - t:.2f} s; "
          f"links left {len(dc.external_links)}")
