"""(4) get_data of linked and derived components: cost, repeats (no caching) and memory."""
import tracemalloc

import numpy as np
from common import banner, load, rss_mb, summary, timeit

banner()
from glue.core import DataCollection
from glue_solar.sources.loaders.iris import keep_hpc_linked

ds = load("4000255147")
dc = DataCollection(ds)
keep_hpc_linked(dc)
raster, sji = ds[0], ds[-1]
print(raster.label, raster.shape, sji.label, sji.shape, "rss MB", round(rss_mb()))
R = 3


def run(name, fn):
    tracemalloc.start()
    out = fn()
    peak = tracemalloc.get_traced_memory()[1]
    tracemalloc.stop()
    del out
    ts = timeit(fn, R)
    print(f"{name:75s} {summary(ts)}  peak alloc {peak / 2**20:7.1f} MB")
    return np.median(ts)


hp = {p: c for p, c in zip(sji.coords.world_axis_physical_types[::-1], sji.world_component_ids)}
rp = {p: c for p, c in zip(raster.coords.world_axis_physical_types[::-1], raster.world_component_ids)}
LON, LAT = "custom:pos.helioprojective.lon", "custom:pos.helioprojective.lat"
t0 = sji.shape[0] // 2
for k in (1, 10):
    v = (slice(t0, t0 + k), slice(None), slice(None))
    n = k * sji.shape[1] * sji.shape[2]
    print(f"\n-- SJI view of {k} frame(s) = {n} pixels")
    own = run("sji[own lon]", lambda: sji[hp[LON], v])
    run("sji[own lat]", lambda: sji[hp[LAT], v])
    pix = [np.arange(s, dtype=float)[sl] for s, sl in zip(sji.shape, v)]
    grid = np.meshgrid(*pix, indexing="ij")
    run("sji.coords.pixel_to_world_values (lon, lat, time at once)", lambda: sji.coords.pixel_to_world_values(*grid[::-1]))
    run("sji[raster lon] (LinkSame to the raster's lon)", lambda: sji[rp[LON], v])
    del grid
# the raster's own pixel axis seen from the SJI: the -TAB inverse; one frame, a 100x100 corner on the slit
v = (t0, slice(150, 250), slice(150, 250))
print("\n-- SJI 100x100 pixels of one frame")
run("sji[raster pixel 1] (world->pixel through the raster's -TAB WCS)", lambda: sji[raster.pixel_component_ids[1], v])
run("sji[raster pixel 0]", lambda: sji[raster.pixel_component_ids[0], v])

print(f"\n-- raster ({raster.size / 1e6:.0f} M elements)")
comp = raster.main_components[0]
raster["twice"] = raster.id[comp.label] * 2  # a derived (arithmetic) component, as the arithmetic editor makes
run("raster[own data component]", lambda: raster[comp])
run("raster['twice'] (derived: recomputed on every get_data)", lambda: raster[raster.id["twice"]])
run("raster['twice'] one spectrogram view [t]", lambda: raster[raster.id["twice"], (800, slice(None), slice(None))])
run("raster[own lon] (full cube, broadcast)", lambda: raster[rp[LON]])
run("raster[sji lon] (LinkSame, full cube)", lambda: raster[hp[LON]])
print("rss MB", round(rss_mb()))
