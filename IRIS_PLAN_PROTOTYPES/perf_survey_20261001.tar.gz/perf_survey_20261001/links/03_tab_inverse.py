"""(1) Cost per point of irispy's -TAB raster WCS: world->pixel inside vs outside the raster, and pixel->world."""
import sys

import numpy as np
from common import OBS, banner, rss_mb, summary, timeit

banner()
import astropy.wcs
from irispy.io import read_files

print("astropy wcslib", astropy.wcs._wcs.__version__ if hasattr(astropy.wcs._wcs, "__version__") else astropy.wcs.WCSLIB_VERSION if hasattr(astropy.wcs, "WCSLIB_VERSION") else "?")
N = 20000
rng = np.random.default_rng(0)
for obs in sys.argv[1:] or ["4000255147", "4000005156", "3824262996"]:
    coll = read_files(OBS[obs]["raster"][:1], spectral_windows=["Fe XII 1349" if obs != "3602506433" else "O I 1356"], memmap=True, uncertainty=False)
    cube = next(iter(coll.values()))[0]
    w = cube.wcs.low_level_wcs
    print(f"\n{obs} shape {cube.shape} ctype {list(w.wcs.ctype)} tables:",
          [tuple(t.K) for t in w.wcs.tab] if w.wcs.tab else None)
    shape = cube.shape  # numpy: step, slit, wave
    px = [rng.uniform(0, shape[2] - 1, N), rng.uniform(0, shape[1] - 1, N), rng.uniform(0, shape[0] - 1, N)]
    world = w.pixel_to_world_values(*px)
    back = w.world_to_pixel_values(*world)
    err = np.nanmax(np.abs(np.array(back[1:]) - np.array(px[1:])))
    print("round-trip max error (pixels, slit/step)", err)
    ts = timeit(lambda: w.pixel_to_world_values(*px), 3)
    print(f"pixel->world {N} pts: {summary(ts)}  {np.median(ts) / N * 1e6:.2f} us/pt")
    ts = timeit(lambda: w.world_to_pixel_values(*world), 3)
    print(f"world->pixel inside {N} pts: {summary(ts)}  {np.median(ts) / N * 1e6:.2f} us/pt")
    out = [world[0], world[1] + 0.2, world[2] + 0.2]  # 0.2 deg = 720 arcsec away: off the raster
    n2 = 2000
    out_small = [a[:n2] for a in out]
    ts = timeit(lambda: w.world_to_pixel_values(*out_small), 3)
    print(f"world->pixel outside {n2} pts: {summary(ts)}  {np.median(ts) / n2 * 1e6:.2f} us/pt",
          "finite", np.isfinite(w.world_to_pixel_values(*out_small)[1]).mean())
    nan_in = [world[0][:n2], np.full(n2, np.nan), np.full(n2, np.nan)]
    ts = timeit(lambda: w.world_to_pixel_values(*nan_in), 3)
    print(f"world->pixel NaN {n2} pts: {summary(ts)}  {np.median(ts) / n2 * 1e6:.2f} us/pt")
    del coll, cube
print("rss MB", round(rss_mb()))
