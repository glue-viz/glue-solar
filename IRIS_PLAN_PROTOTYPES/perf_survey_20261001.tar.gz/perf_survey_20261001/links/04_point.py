"""(2) A Pixel point moved on the quicklook's raster map, propagating to the linked viewers."""
import sys
import time

import numpy as np
from common import Sampler, banner, events, load, make_app, rss_mb, summary, timeit

banner()
obs = sys.argv[1] if len(sys.argv) > 1 else "4000255147"
N = int(sys.argv[2]) if len(sys.argv) > 2 else 8

from glue.core.command import ApplySubsetState
from glue.core.edit_subset_mode import ReplaceMode
from glue.core.link_manager import pixel_cid_to_pixel_cid_matrix
from glue.viewers.image.pixel_selection_subset_state import PixelSubsetState
from glue_solar.quicklook import quicklook
from glue_qt.utils import process_events

app = make_app()
datasets = load(obs)
viewers = quicklook(app, datasets)
events(10)
mapv, sji, spec = viewers["map"], viewers["sji"][0], viewers["spectrum"]
raster, sdata = mapv.state.reference_data, sji.state.reference_data
image_viewers = [viewers[r] for r in ("map", "spectrogram", "wavelength")] + viewers["sji"]
allv = image_viewers + [spec]
print(raster.label, raster.shape, sdata.label, sdata.shape, "rss MB", round(rss_mb()))


def busy():
    return any(v.figure.stale for v in allv) or any(getattr(l, "is_computing", False) for l in spec.layers)


def settle(cap=60.0):
    t0 = time.perf_counter()
    while time.perf_counter() - t0 < cap:
        process_events()
        if not busy():
            process_events()
            if not busy():
                return True
        time.sleep(0.005)
    return False


settle()
m = mapv.state
nx, ny = raster.shape[m.x_att.axis], raster.shape[m.y_att.axis]
positions = [(int(x), int(y)) for x, y in zip(np.linspace(0.3 * nx, 0.7 * nx, N), np.linspace(0.3 * ny, 0.7 * ny, N))]


def move(x, y):
    slices = [slice(None)] * raster.ndim
    slices[m.x_att.axis] = slice(x, x + 1)
    slices[m.y_att.axis] = slice(y, y + 1)
    app.session.edit_subset_mode.mode = ReplaceMode
    cmd = ApplySubsetState(data_collection=app.data_collection, subset_state=PixelSubsetState(raster, slices), override_mode=None)
    app.session.command_stack.do(cmd)


draws = {}
for v in allv:
    canvas = v.figure.canvas
    def counted(_orig=canvas.draw, _name=v.state.title, *a, **k):
        draws[_name] = draws.get(_name, 0) + 1
        return _orig(*a, **k)
    canvas.draw = counted
wcs_calls = {}
for v in image_viewers:
    def counted_wcs(*a, _orig=v._set_wcs, _name=v.state.title, **k):
        wcs_calls[_name] = wcs_calls.get(_name, 0) + 1
        return _orig(*a, **k)
    v._set_wcs = counted_wcs
sync, total, cpu = [], [], []
sampler = Sampler()
sampler.__enter__()
for x, y in positions:
    w0, c0 = time.perf_counter(), time.thread_time()
    move(x, y)
    w1 = time.perf_counter()
    ok = settle()
    w2, c2 = time.perf_counter(), time.thread_time()
    sync.append(w1 - w0)
    total.append(w2 - w0)
    cpu.append(c2 - c0)
    if not ok:
        print("did not settle")
sampler.__exit__()
print("canvas draws per point move", {k: v / len(positions) for k, v in draws.items()})
print("_set_wcs calls per point move", {k: v / len(positions) for k, v in wcs_calls.items()})
print("point move: synchronous part ", summary(sync))
print("point move: until all viewers drawn and the spectrum computed", summary(total))
print("point move: main-thread CPU", summary(cpu))

sampler.report(400)
# Pieces, called directly on the settled state
group = [g for g in app.data_collection.subset_groups if g.label == "Point"][0]
point = group.subset_state
print("point", point.slices)
parts = {
    "pixel_cid_to_pixel_cid_matrix(raster, sji)": lambda: pixel_cid_to_pixel_cid_matrix(raster, sdata),
}


def get_xy():
    try:
        return point.get_xy(sdata, sji.state.x_att.axis, sji.state.y_att.axis)
    except Exception as e:  # the SJI time axis is not linked to the raster: no crosshair
        return type(e).__name__


print("point.get_xy(sji) ->", get_xy())
parts["point.get_xy(sji) (SJI crosshair position, incl. failure)"] = get_xy
for role in ("map", "spectrogram", "wavelength"):
    v = viewers[role]
    from glue.core.fixed_resolution_buffer import ARRAY_CACHE

    [ls] = [l for l in v.state.layers if getattr(l.layer, "group", None) is group]
    bounds = ARRAY_CACHE[ls.uuid]["hash"][1] if ls.uuid in ARRAY_CACHE else None
    if bounds is not None:
        b = [x if isinstance(x, tuple) else v.state.slices[i] for i, x in enumerate(bounds)]
        parts[f"Point mask FRB on the {role} panel {[x[2] for x in b if isinstance(x, tuple)]}"] = (
            lambda ls=ls, b=b: raster.compute_fixed_resolution_buffer(b, target_data=raster, subset_state=ls.layer.subset_state))
for v in image_viewers:
    parts[f"_set_wcs(relim=False) {v.state.title}"] = lambda v=v: v._set_wcs(relim=False)
    parts[f"  of which axes.reset_wcs only {v.state.title}"] = lambda v=v: v.axes.reset_wcs(
        slices=v.state.wcsaxes_slice, wcs=v.state.reference_data.coords)
for v in viewers["sji"]:
    parts[f"canvas.draw() {v.state.title}"] = v.figure.canvas.draw
for role in ("map", "spectrogram", "wavelength", "spectrum"):
    parts[f"canvas.draw() {role}"] = viewers[role].figure.canvas.draw
[sub] = [s for s in group.subsets if s.data is raster]
x_cid = spec.state.x_att
parts["spectrum: raster.compute_statistic(mean, subset, axis=other)"] = lambda: raster.compute_statistic(
    "mean", raster.main_components[0], subset_state=sub.subset_state,
    axis=tuple(i for i in range(raster.ndim) if i != raster.ndim - 1))
for name, fn in parts.items():
    ts = timeit(fn, 5)
    print(f"{name:70s} {summary(ts)}")
print("rss MB", round(rss_mb()))
