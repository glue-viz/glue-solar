"""(1) A raster-map ROI shown on the slit-jaw viewer: per-frame draw cost and where it goes."""
import cProfile
import pstats
import sys
import time

import numpy as np
from common import banner, events, load, make_app, rss_mb, summary

banner()
obs = sys.argv[1] if len(sys.argv) > 1 else "4000255147"
N = int(sys.argv[2]) if len(sys.argv) > 2 else 5
OUT = f"links/01_roi_sji_{obs}"

from glue.core.roi import RectangularROI
from glue_solar.quicklook import quicklook

app = make_app()
datasets = load(obs)
viewers = quicklook(app, datasets)
events(10)
sji = viewers["sji"][0]
raster = viewers["map"].state.reference_data
sdata = sji.state.reference_data
print("raster", raster.label, raster.shape, "sji", sdata.label, sdata.shape, "rss MB", round(rss_mb()))
bbox = sji.axes.get_window_extent()
print("sji axes px", round(bbox.width), round(bbox.height), "dpr", sji.figure.canvas.devicePixelRatio() if hasattr(sji.figure.canvas, "devicePixelRatio") else "?")
nt = sdata.shape[0]
frames = [int(f) for f in np.linspace(nt // 4, 3 * nt // 4, N)]


def draw_frame(t):
    sji.state.slices = (t,) + tuple(sji.state.slices[1:])
    sji.figure.canvas.draw()


def run(label):
    ts = []
    for t in frames:
        t0 = time.perf_counter()
        draw_frame(t)
        ts.append(time.perf_counter() - t0)
        events()
    print(f"{label}: SJI frame change + draw", summary(ts), [round(x, 3) for x in ts])
    return ts


base = run("no ROI")

# A rectangle on the raster map, in its pixel axes, as the map viewer's ROI tool would make
m = viewers["map"].state
nx, ny = raster.shape[m.x_att.axis], raster.shape[m.y_att.axis]
roi = RectangularROI(0.25 * nx, 0.75 * nx, 0.25 * ny, 0.75 * ny)
app.session.edit_subset_mode.edit_subset = []  # a new subset, not the quicklook's point
t0 = time.perf_counter()
viewers["map"].apply_roi(roi)
t1 = time.perf_counter()
events()
t2 = time.perf_counter()
print(f"apply_roi {t1 - t0:.3f} s, then process_events {t2 - t1:.3f} s")
[group] = [g for g in app.data_collection.subset_groups if g.label != "Point"]
print("subset state", type(group.subset_state).__name__, group.subset_state.xatt, group.subset_state.yatt)
sub = [s for s in group.subsets if s.data is sdata][0]
print("roi on sji: mask true fraction (frame 0)", None)

with_roi = run("ROI")
from glue.core.fixed_resolution_buffer import ARRAY_CACHE
[sl] = [l for l in sji.state.layers if getattr(l.layer, "group", None) is group]
print("ROI layer FRB bounds", ARRAY_CACHE[sl.uuid]["hash"][1] if sl.uuid in ARRAY_CACHE else "?", "mask true fraction",
      ARRAY_CACHE[sl.uuid]["array"].mean() if sl.uuid in ARRAY_CACHE else "?")
sl.visible = False
events()
run("ROI layer hidden on the SJI viewer")
sl.visible = True
events()

# Loading and linking an unrelated dataset while the ROI shows on the SJI viewer
from common import OBS
from glue_solar.sources.loaders.iris import keep_hpc_linked, raster_data

ts = []
for _ in range(3):
    t0 = time.perf_counter()
    sji.figure.canvas.draw()
    ts.append(time.perf_counter() - t0)
print("SJI redraw, nothing changed (cached mask):", summary(ts))
for i in range(2):
    new = raster_data(OBS["3602506433"]["raster"][i:i + 1], windows=["Si IV 1394"])[0]
    t0 = time.perf_counter()
    app.data_collection.append(new)
    keep_hpc_linked(app.data_collection)
    t1 = time.perf_counter()
    sji.figure.canvas.draw()
    t2 = time.perf_counter()
    events()
    print(f"append + link an unrelated scan: {t1 - t0:.3f} s; next SJI draw {t2 - t1:.3f} s")

pr = cProfile.Profile()
pr.enable()
draw_frame(frames[0] + 1)
pr.disable()
events()
pr.dump_stats(OUT + ".prof")
st = pstats.Stats(pr)
st.sort_stats("cumulative").print_stats(35)
st.sort_stats("tottime").print_stats(25)
print("rss MB", round(rss_mb()))
