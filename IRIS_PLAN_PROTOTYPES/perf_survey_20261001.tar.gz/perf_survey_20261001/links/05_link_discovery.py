"""(3) glue's link discovery against the number of IRIS datasets, star (link_hpc) vs every pair, and what re-runs it."""
import itertools
import statistics
import sys
import time

import numpy as np
from common import OBS, banner, rss_mb

banner()
SIZES = [int(n) for n in (sys.argv[1].split(",") if len(sys.argv) > 1 else "2,9,36,99".split(","))]
CAP = float(sys.argv[2]) if len(sys.argv) > 2 else 60.0  # skip timing repeats above this many seconds

from glue.core import DataCollection
from glue.core.autolinking import find_possible_links
from glue.core.component import Component
from glue.core.link_helpers import LinkSame
from glue.core.link_manager import discover_links, equivalent_pixel_cids
from glue_solar.sources.loaders.iris import _GlueWCS, link_hpc, raster_data

t = time.perf_counter()
ALL = raster_data(OBS["3602506433"]["raster"][: max(SIZES)], windows=["Si IV 1394"])
print(f"loaded {len(ALL)} scans of {ALL[0].shape} in {time.perf_counter() - t:.1f} s, rss {rss_mb():.0f} MB")


def hpc(data):
    return [cid for p, cid in zip(data.coords.world_axis_physical_types[::-1], data.world_component_ids)
            if p and p.startswith("custom:pos.helioprojective.")]


def pairs(dc):
    out = []
    for a, b in itertools.combinations(list(dc), 2):
        out += [LinkSame(x, y) for x, y in zip(hpc(a), hpc(b))]
    return out


class Counter:
    """Count (and optionally skip) LinkManager.update_externally_derivable_components calls."""

    def __init__(self, lm, run=True):
        self.lm, self.run, self.n, self.orig = lm, run, 0, lm.update_externally_derivable_components

    def __enter__(self):
        def wrapped(*a, **k):
            self.n += 1
            if self.run:
                return self.orig(*a, **k)

        self.lm.update_externally_derivable_components = wrapped
        return self

    def __exit__(self, *exc):
        del self.lm.update_externally_derivable_components


def timed(fn):
    t = time.perf_counter()
    r = fn()
    return time.perf_counter() - t, r


for n in SIZES:
    for topo, make in (("star", link_hpc), ("all-pairs", pairs)):
        ds = raster_data(OBS["3602506433"]["raster"][:n], windows=["Si IV 1394"])  # Data binds to one hub
        dc = DataCollection()
        t_extend, _ = timed(lambda: dc.extend(ds))
        links = make(dc)
        t_add, _ = timed(lambda: dc.add_link(links))
        lm = dc._link_manager
        nlinks = len(lm._links)
        derived = statistics.mean(len(d._externally_derivable_components) for d in dc)
        reps = [t_add] if t_add > CAP else []
        while len(reps) < 3 and sum(reps) < CAP:
            reps.append(timed(lm.update_externally_derivable_components)[0])
        upd = statistics.median(reps)
        links_set = lm._links | lm._inverse_links
        t_disc, _ = timed(lambda: [discover_links(d, links_set) for d in dc]) if upd < CAP else (float("nan"), None)
        t_props, _ = timed(lambda: lm._links | lm._inverse_links)
        t_align, _ = timed(lambda: [equivalent_pixel_cids(b, a) for a in dc for b in dc if a is not b])
        print(f"\nN={n:3d} {topo:9s}: LinkSame {len(links):5d}  ComponentLinks {nlinks:6d}  derivable/dataset {derived:6.1f}")
        print(f"  extend {t_extend:.3f} s   add_link(all at once) {t_add:.3f} s")
        print(f"  one update_externally_derivable_components: median {upd:.3f} s (n={len(reps)}) = "
              f"discover_links {t_disc:.3f} s + pixel-aligned pairs {t_align:.3f} s + link-set build {t_props:.3f} s")
        # what re-runs it
        with Counter(lm, run=upd < CAP / 3) as c:
            t1, _ = timed(lambda: dc.add_link([]))
        print(f"  add_link([]): {c.n} update(s), {t1:.3f} s")
        with Counter(lm, run=upd < CAP / 3) as c:
            t1, _ = timed(lambda: dc[1].add_component(Component(np.zeros(dc[1].shape, np.float32)), "extra"))
        print(f"  add_component on one dataset: {c.n} update(s), {t1:.3f} s")
        with Counter(lm, run=upd < CAP / 3) as c:
            t1, _ = timed(lambda: dc.new_subset_group(label="s"))
        print(f"  new_subset_group: {c.n} update(s), {t1:.3f} s")
        with Counter(lm, run=upd < CAP / 3) as c:
            t1, _ = timed(lambda: dc.remove(dc[-1]))
        print(f"  remove a dataset that is not the anchor: {c.n} update(s), {t1:.3f} s")
        with Counter(lm, run=False) as c:
            dc.remove(dc[0])
        print(f"  remove the anchor (first) dataset: {c.n} update(s) (counted, not run)")
        with Counter(lm, run=False) as c:
            dc.clear()
        print(f"  clear(): {c.n} update(s) (counted, not run)")
        del dc, links, lm, links_set
    # glue-qt's add_datasets runs the autolinkers on every load
    dc = DataCollection(raster_data(OBS["3602506433"]["raster"][:n], windows=["Si IV 1394"]))
    if n <= 36:
        t1, sugg = timed(lambda: find_possible_links(dc))
        print(f"N={n:3d} find_possible_links (glue-qt runs it in add_datasets): {t1:.3f} s, suggestions "
              f"{ {k: len(v) for k, v in sugg.items()} }")
    del dc
print("rss MB", round(rss_mb()))
