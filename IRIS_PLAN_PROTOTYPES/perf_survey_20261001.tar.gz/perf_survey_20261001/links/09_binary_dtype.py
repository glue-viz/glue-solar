"""(4) glue's BinaryComponentLink broadcasts a Python scalar to int64, promoting float32 data to float64."""
import time
import tracemalloc

import numpy as np
from glue.core import Data

a = np.ones((1600, 417, 262), np.float32)  # the 4000255147 Si IV 1403 cube's shape and dtype
d = Data(x=a, label="cube")
d["twice"] = d.id["x"] * 2
for name, fn in (("glue get_data(x * 2)", lambda: d["twice"]), ("numpy a * 2 (what NEP 50 gives)", lambda: a * 2)):
    tracemalloc.start()
    r = fn()
    peak = tracemalloc.get_traced_memory()[1]
    tracemalloc.stop()
    dtype = r.dtype
    del r
    ts = []
    for _ in range(5):
        t = time.perf_counter()
        r = fn()
        ts.append(time.perf_counter() - t)
        del r
    print(f"{name:35s} dtype {dtype}  median {np.median(ts):.3f} s (n=5)  peak alloc {peak / 2**20:.0f} MB")
