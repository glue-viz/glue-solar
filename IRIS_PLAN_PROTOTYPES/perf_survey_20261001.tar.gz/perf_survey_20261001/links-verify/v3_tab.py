"""Verify finding 3: per-point cost of the -TAB raster WCS inverse, and whether sit-and-stare overlap is the cause."""
import copy
import glob
import statistics
import sys
import time

sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
import glue_solar  # noqa: E402
import numpy as np  # noqa: E402
from irispy.io import read_files  # noqa: E402

print("glue_solar", glue_solar.__file__)
D = "/Users/nabil/DATA/IRIS"
rng = np.random.default_rng(1)


def med(fn, n=3):
    ts = []
    for _ in range(n):
        t = time.perf_counter()
        fn()
        ts.append(time.perf_counter() - t)
    return statistics.median(ts)


def probe(w, shape, n, label):
    px = [rng.uniform(0, shape[2] - 1, n), rng.uniform(0, shape[1] - 1, n), rng.uniform(0, shape[0] - 1, n)]
    world = w.pixel_to_world_values(*px)
    back = w.world_to_pixel_values(*world)
    err = np.abs(np.array(back[1:]) - np.array(px[1:]))
    tf = med(lambda: w.pixel_to_world_values(*px))
    ti = med(lambda: w.world_to_pixel_values(*world))
    far = [world[0], world[1] + 0.2, world[2] + 0.2]
    to = med(lambda: w.world_to_pixel_values(*far))
    print(f"  {label}: n={n} pix->world {tf / n * 1e6:.2f} us/pt; world->pix inside {ti / n * 1e6:.1f} us/pt; "
          f"0.2 deg off {to / n * 1e6:.2f} us/pt; round-trip err slit/step max {np.nanmax(err[0]):.2g}/{np.nanmax(err[1]):.2g} px, "
          f"frac >0.01 px {np.mean(err.max(0) > 0.01):.3f}")


for obs, pat, n in (("4000255147", "*4000255147_raster/*_r00000.fits", 1000),
                    ("4000005156", "*4000005156_raster/*.fits", 20000),
                    ("3824262996", "*3824262996_raster/*.fits", 20000)):
    f = sorted(glob.glob(f"{D}/{pat}"))[:1]
    coll = read_files(f, spectral_windows=["Fe XII 1349"], memmap=True, uncertainty=False)
    cube = next(iter(coll.values()))[0]
    w = cube.wcs.low_level_wcs
    tab = w.wcs.tab[0]
    c = np.array(tab.coord)  # (K2 steps, K1, M) in deg
    print(f"{obs} shape {cube.shape} ctype {list(w.wcs.ctype)} table K {tuple(tab.K)} coord {c.shape}")
    # spread of the slit (first table row) across exposures, in arcsec
    for m in range(c.shape[-1]):
        v = c[:, 0, m] * 3600
        print(f"  table axis {m}: range over steps {np.ptp(v):.2f} arcsec, median |step diff| {np.median(np.abs(np.diff(v))):.3f} arcsec")
    probe(w, cube.shape, n, "as read")
    if obs == "4000255147":
        # Same table but with the steps spread out like a scan (0.35 arcsec per step in table axis 1 = lon):
        # if the inverse is slow because exposures overlap, this one should be fast.
        w2 = copy.deepcopy(w)
        c2 = c.copy()
        c2[:, :, 1] += (np.arange(c.shape[0]) * 0.35 / 3600)[:, None]
        w2.wcs.tab[0].coord = c2
        w2.wcs.set()
        print("  synthetic scan table: lon range", round(np.ptp(c2[:, 0, 1]) * 3600, 1), "arcsec")
        probe(w2, cube.shape, 20000, "synthetic 1600-step scan")
    del coll, cube
