"""Verify findings 4 and 5: glue's link discovery and dataset removal against N IRIS scans. Measure only."""
import collections
import glob
import itertools
import statistics
import sys
import time

sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
import glue_solar  # noqa: E402

print("glue_solar", glue_solar.__file__)
from glue.core import DataCollection  # noqa: E402
from glue.core.link_helpers import LinkSame  # noqa: E402
from glue.core.link_manager import discover_links  # noqa: E402
from glue_solar.sources.loaders.iris import link_hpc, raster_data  # noqa: E402

FILES = sorted(glob.glob("/Users/nabil/DATA/IRIS/*3602506433_raster/*.fits"))
MODE = sys.argv[1]  # "discover" or "remove"
SIZES = [int(v) for v in sys.argv[2].split(",")]
TOPOS = sys.argv[3].split(",")
CAP = float(sys.argv[4]) if len(sys.argv) > 4 else 30


def timed(fn):
    t = time.perf_counter()
    r = fn()
    return time.perf_counter() - t, r


def reps(fn, n=3):
    ts = []
    while len(ts) < n and sum(ts) < CAP:
        ts.append(timed(fn)[0])
    return statistics.median(ts), len(ts)


def pairs(dc):
    def hpc(d):
        return [c for p, c in zip(d.coords.world_axis_physical_types[::-1], d.world_component_ids) if p.startswith("custom:pos.helioprojective.")]
    return [LinkSame(x, y) for a, b in itertools.combinations(list(dc), 2) for x, y in zip(hpc(a), hpc(b))]


def make(n, topo):
    dc = DataCollection(raster_data(FILES[:n], windows=["Si IV 1394"]))
    with dc._ignore_link_manager_update():  # no update here: every update below is timed explicitly
        dc.add_link(link_hpc(dc) if topo == "star" else pairs(dc))
    return dc


def bfs(data, links):
    """Level-by-level discovery: same contract as glue's discover_links (minimal depth per cid)."""
    by_input = collections.defaultdict(list)
    for link in links:
        for f in set(link.get_from_ids()):
            by_input[f].append(link)
    depth = {c: 0 for c in data.main_components + data.coordinate_components}
    out, frontier, level = {}, set(depth), 0
    cand = [link for link in links if not link.get_from_ids()]
    while frontier or cand:
        level += 1
        cand = {link for f in frontier for link in by_input[f]} | set(cand)
        new = set()
        for link in cand:
            to = link.get_to_id()
            if to not in depth and all(f in depth and depth[f] < level for f in link.get_from_ids()):
                new.add(to)
                out[to] = link
        for to in new:
            depth[to] = level
        frontier, cand = new, []
    return out


def depths(data, cid_links):
    base = set(data.main_components + data.coordinate_components)
    memo = {}

    def d(c):
        if c in base:
            return 0
        if c not in memo:
            memo[c] = 1 + max((d(f) for f in cid_links[c].get_from_ids()), default=0)
        return memo[c]
    return {c: d(c) for c in cid_links}


class Count:
    def __init__(self, lm, run=True):
        self.lm, self.run, self.n, self.orig = lm, run, 0, lm.update_externally_derivable_components

    def __enter__(self):
        def wrapped(*a, **k):
            self.n += 1
            return self.orig(*a, **k) if self.run else None
        self.lm.update_externally_derivable_components = wrapped
        return self

    def __exit__(self, *exc):
        del self.lm.update_externally_derivable_components


for n in SIZES:
    for topo in TOPOS:
        dc = make(n, topo)
        lm = dc._link_manager
        links = lm._links | lm._inverse_links
        if MODE == "discover":
            upd, k = reps(lm.update_externally_derivable_components)
            nder = statistics.mean(len(d._externally_derivable_components) for d in dc)
            t_glue, k2 = reps(lambda: [discover_links(d, links) for d in dc])
            t_bfs, _ = reps(lambda: [bfs(d, links) for d in dc])
            same = all(depths(d, discover_links(d, links)) == depths(d, bfs(d, links)) for d in list(dc)[:: max(1, n // 9)]) if t_glue < CAP else "not checked"
            print(f"N={n:3d} {topo:9s} links {len(links):6d} derivable/dataset {nder:6.1f}: update median {upd:.3f} s (n={k}); "
                  f"discover_links x N {t_glue:.3f} s (n={k2}, {100 * t_glue / upd:.0f}% of update); bfs x N {t_bfs:.4f} s "
                  f"({t_glue / t_bfs:.0f}x); same cids+depths (sampled datasets): {same}", flush=True)
        else:
            one, _ = timed(lm.update_externally_derivable_components)
            with Count(lm) as c:
                t, _ = timed(lambda: dc.remove(dc[-1]))
            after, _ = timed(lm.update_externally_derivable_components)
            print(f"N={n:3d} {topo:9s} one update {one:.3f} s; remove a leaf: {c.n} updates {t:.2f} s; "
                  f"one update afterwards (= fixed cost) {after:.3f} s", flush=True)
            run_anchor = sys.argv[5] == "run" if len(sys.argv) > 5 else False
            with Count(lm, run=run_anchor) as c:
                t, _ = timed(lambda: dc.remove(dc[0]))
            after, _ = timed(lm.update_externally_derivable_components)
            print(f"            remove the anchor: {c.n} updates" + (f" {t:.2f} s" if run_anchor else " (counted, not run)")
                  + f"; links left {len(dc.external_links)}; one update afterwards {after:.3f} s", flush=True)
            with Count(lm, run=False) as c:
                dc.clear()
            print(f"            clear() of the remaining {n - 2}: {c.n} updates (counted, not run)", flush=True)
        del dc, lm, links
