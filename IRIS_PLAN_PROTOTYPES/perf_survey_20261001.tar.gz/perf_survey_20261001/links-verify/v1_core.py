"""Verify findings 1-3: the SJI mask of a raster-pixel ROI, single-threaded, no Qt. Measure only."""
import cProfile
import glob
import pstats
import resource
import statistics
import sys
import time

sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
import glue_solar  # noqa: E402
import numpy as np  # noqa: E402

print("glue_solar", glue_solar.__file__)
D = "/Users/nabil/DATA/IRIS"
FILES = {
    "4000255147": (sorted(glob.glob(f"{D}/*4000255147_raster/*_r00000.fits")), glob.glob(f"{D}/*4000255147_SJI_1400_t000.fits.gz")[0]),
    "4000005156": (sorted(glob.glob(f"{D}/*4000005156_raster/*.fits"))[:1], glob.glob(f"{D}/*4000005156_SJI_2796_t000_deconvolved.fits.gz")[0]),
}
obs = sys.argv[1]
T = int(sys.argv[2])
Y0, Y1, NY, X0, X1, NX = (float(v) for v in sys.argv[3:9])
SCALE = int(sys.argv[9])
REP = int(sys.argv[10])
NY, NX = int(NY) * SCALE, int(NX) * SCALE


def med(fn, n=REP):
    ts = []
    for _ in range(n):
        t = time.perf_counter()
        out = fn()
        ts.append(time.perf_counter() - t)
    return statistics.median(ts), ts, out


def fmt(m, ts):
    return f"median {m:.4f} s n={len(ts)} [{', '.join(f'{x:.3f}' for x in ts)}]"


from glue.core import DataCollection  # noqa: E402
from glue.core.roi import RectangularROI  # noqa: E402
from glue.core.subset import RoiSubsetState  # noqa: E402
from glue_solar.sources.loaders.iris import image_data, keep_hpc_linked, raster_data  # noqa: E402

rfiles, sfile = FILES[obs]
raster = raster_data(rfiles, windows=["Si IV 1403"])[0]
sji = image_data(sfile)
dc = DataCollection([raster, sji])
keep_hpc_linked(dc)
print(raster.label, raster.shape, sji.label, sji.shape, "maxrss MB", resource.getrusage(resource.RUSAGE_SELF).ru_maxrss >> 20)
n0, n1 = raster.shape[0], raster.shape[1]
roi = RectangularROI(0.25 * n0, 0.75 * n0, 0.25 * n1, 0.75 * n1)
state = RoiSubsetState(raster.pixel_component_ids[0], raster.pixel_component_ids[1], roi)
bounds = [T, (Y0, Y1, NY), (X0, X1, NX)]
print("buffer", NX, "x", NY, "=", NX * NY)

frb = lambda: sji.compute_fixed_resolution_buffer(bounds, target_data=sji, subset_state=state)  # noqa: E731
m_frb, ts, mask = med(frb, REP if SCALE == 1 else 1)
print("A. glue FRB mask:", fmt(m_frb, ts), "true frac", round(mask.mean(), 4))

pr = cProfile.Profile()
pr.enable()
frb()
pr.disable()
st = pstats.Stats(pr)
tot = sum(v[3] for k, v in st.stats.items() if k[2] == "compute_fixed_resolution_buffer" and "fixed_resolution_buffer" in k[0])
for k, v in st.stats.items():
    if k[2] in ("<method 's2p' of 'astropy.wcs.Wcsprm' objects>", "world_to_pixel_values", "world2pixel_single_axis", "to_mask"):
        print(f"   cProfile {k[0].split('site-packages/')[-1]}:{k[1]}({k[2]}) ncalls {v[1]} cum {v[3]:.3f} s ({100 * v[3] / tot:.1f}% of FRB {tot:.3f} s)")

# The same integer view glue builds for target_data == data
grid = np.meshgrid(T, np.round(np.linspace(Y0, Y1, NY)).astype(int), np.round(np.linspace(X0, X1, NX)).astype(int), indexing="ij")
view = tuple(np.broadcast_to(g, (1, NY, NX)) for g in grid)
if SCALE == 1:
    for i, cid in enumerate(state.attributes):
        m, ts, _ = med(lambda cid=cid: sji[cid, view])
        print(f"B. sji[{cid}] alone: {fmt(m, ts)} ({100 * m / m_frb:.0f}% of A)")

# World coordinates of the SJI screen pixels, then the raster inversion: once, all axes
sp = [view[2].ravel().astype(float), view[1].ravel().astype(float), view[0].ravel().astype(float)]  # x, y, t
spt = sji.coords.world_axis_physical_types
rpt = raster.coords.world_axis_physical_types


def to_raster_world(sw):
    by = dict(zip(spt, sw))
    return [np.zeros_like(sw[0]) if p == "em.wl" else by[p] for p in rpt]


def shared_inversion():
    rw = to_raster_world(sji.coords.pixel_to_world_values(*sp))
    p = raster.coords.world_to_pixel_values(*rw)  # wave, slit, step
    return roi.contains(p[2], p[1]).reshape(NY, NX)


m1, ts, mk1 = med(shared_inversion)
print(f"C. fix 1 estimate (SJI world once + one raster world_to_pixel_values + contains): {fmt(m1, ts)}; "
      f"{m_frb / m1:.2f}x faster than A; same mask as glue: {np.mean(mk1 == mask[...]) * 100:.3f}%")

rw_all = to_raster_world(sji.coords.pixel_to_world_values(*sp))
m, ts, pall = med(lambda: raster.coords.world_to_pixel_values(*rw_all))
fin = np.isfinite(pall[1])
print(f"D. one raster world_to_pixel_values on all {fin.size} points: {fmt(m, ts)}; finite {fin.mean():.4f}")
if SCALE == 1:
    mi, ts, _ = med(lambda: raster.coords.world_to_pixel_values(*[a[fin] for a in rw_all]))
    print(f"   finite-result points only ({fin.sum()}): {fmt(mi, ts)} = {mi / fin.sum() * 1e6:.1f} us/pt")
    mo, ts, _ = med(lambda: raster.coords.world_to_pixel_values(*[a[~fin] for a in rw_all]))
    print(f"   non-finite points only ({(~fin).sum()}): {fmt(mo, ts)} = {mo / (~fin).sum() * 1e6:.1f} us/pt")

# Finding 2: invert only the screen pixels inside the forward-mapped ROI outline's bounding box
e = np.linspace(0, 1, 100)
ox = np.concatenate([roi.xmin + (roi.xmax - roi.xmin) * e, np.full(100, roi.xmax), roi.xmin + (roi.xmax - roi.xmin) * e, np.full(100, roi.xmin)])
oy = np.concatenate([np.full(100, roi.ymin), roi.ymin + (roi.ymax - roi.ymin) * e, np.full(100, roi.ymax), roi.ymin + (roi.ymax - roi.ymin) * e])


def culled():
    rw = dict(zip(rpt, raster.coords.pixel_to_world_values(np.zeros_like(ox), oy, ox)))
    tw = dict(zip(spt, sji.coords.pixel_to_world_values(0.0, 0.0, float(T))))
    sw = [rw[p] if p in rw else np.full_like(ox, tw[p]) for p in spt]
    sx, sy, _ = sji.coords.world_to_pixel_values(*sw)
    inside = ((sp[0] >= np.nanmin(sx) - 2) & (sp[0] <= np.nanmax(sx) + 2)
              & (sp[1] >= np.nanmin(sy) - 2) & (sp[1] <= np.nanmax(sy) + 2))
    out = np.zeros(sp[0].size, bool)
    if inside.any():
        w = to_raster_world(sji.coords.pixel_to_world_values(*[a[inside] for a in sp]))
        p = raster.coords.world_to_pixel_values(*w)
        out[inside] = roi.contains(p[2], p[1])
    return out.reshape(NY, NX), inside.mean()


m2, ts, (mk2, frac) = med(culled)
print(f"E. fix 2 estimate (bbox-culled single inversion): {fmt(m2, ts)}; bbox covers {100 * frac:.2f}% of buffer; "
      f"{m_frb / m2:.1f}x vs A, {m1 / m2:.1f}x vs C; same mask as glue: {np.mean(mk2 == mask) * 100:.3f}%")
print("maxrss MB", resource.getrusage(resource.RUSAGE_SELF).ru_maxrss >> 20)
