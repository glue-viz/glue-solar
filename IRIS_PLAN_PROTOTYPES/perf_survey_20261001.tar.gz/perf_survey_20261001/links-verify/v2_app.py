"""Verify findings 1 and 6 in the app: SJI frame changes with a raster ROI shown, and what drops its mask."""
import glob
import statistics
import sys
import time

sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
import glue_solar  # noqa: E402
import numpy as np  # noqa: E402

print("glue_solar", glue_solar.__file__)
D = "/Users/nabil/DATA/IRIS"
FILES = {
    "4000255147": (sorted(glob.glob(f"{D}/*4000255147_raster/*_r00000.fits")), glob.glob(f"{D}/*4000255147_SJI_1400_t000.fits.gz")[0]),
    "4000005156": (sorted(glob.glob(f"{D}/*4000005156_raster/*.fits"))[:1], glob.glob(f"{D}/*4000005156_SJI_2796_t000_deconvolved.fits.gz")[0]),
}
obs = sys.argv[1]
N = 5

from glue.core.hub import HubListener  # noqa: E402
from glue.core.message import ExternallyDerivableComponentsChangedMessage  # noqa: E402
from glue.core.roi import RectangularROI  # noqa: E402
from glue_qt.app import GlueApplication  # noqa: E402
from glue_qt.dialogs.link_editor.link_editor import LinkEditor  # noqa: E402
from glue_qt.utils import get_qapp, process_events  # noqa: E402
from glue_solar.quicklook import quicklook  # noqa: E402
from glue_solar.sources.loaders.iris import image_data, keep_hpc_linked, raster_data  # noqa: E402


def events(n=3):
    for _ in range(n):
        process_events()


get_qapp()
app = GlueApplication()
app.resize(1600, 1000)
app.show()
events()
rfiles, sfile = FILES[obs]
viewers = quicklook(app, [raster_data(rfiles, windows=["Si IV 1403"])[0], image_data(sfile)])
events(10)
sji, mp = viewers["sji"][0], viewers["map"]
sdata, raster = sji.state.reference_data, mp.state.reference_data
dc = app.data_collection
bb = sji.axes.get_window_extent()
print(raster.label, raster.shape, sdata.label, sdata.shape, "sji axes px", round(bb.width), round(bb.height),
      "dpr", sji.figure.canvas.devicePixelRatio())
frames = [int(f) for f in np.linspace(sdata.shape[0] // 4, 3 * sdata.shape[0] // 4, N)]


def frame_change(label):
    draw, after = [], []
    for t in frames:
        t0 = time.perf_counter()
        sji.state.slices = (t,) + tuple(sji.state.slices[1:])
        sji.figure.canvas.draw()
        t1 = time.perf_counter()
        events()
        after.append(time.perf_counter() - t1)
        draw.append(t1 - t0)
    print(f"{label}: frame change + draw median {statistics.median(draw):.4f} s n={len(draw)} {[round(x, 3) for x in draw]}; "
          f"events afterwards median {statistics.median(after):.4f} s")
    return statistics.median(draw)


base = frame_change("no ROI")
m = mp.state
roi = RectangularROI(0.25 * raster.shape[m.x_att.axis], 0.75 * raster.shape[m.x_att.axis],
                     0.25 * raster.shape[m.y_att.axis], 0.75 * raster.shape[m.y_att.axis])
app.session.edit_subset_mode.edit_subset = []
mp.apply_roi(roi)
events()
[group] = [g for g in dc.subset_groups if g.label != "Point"]
print("ROI state", type(group.subset_state).__name__, group.subset_state.xatt, group.subset_state.yatt)
with_roi = frame_change("raster ROI shown on SJI")
[layer] = [s for s in sji.state.layers if getattr(s.layer, "group", None) is group]
layer.visible = False
events()
frame_change("ROI layer hidden on SJI")
layer.visible = True
events()
sji.figure.canvas.draw()
print(f"mask share of a frame change: {100 * (with_roi - base) / with_roi:.0f}%")


class Msgs(HubListener):
    def __init__(self):
        self.n = 0
        dc.hub.subscribe(self, ExternallyDerivableComponentsChangedMessage, handler=self.on)

    def on(self, msg):
        self.n += msg.sender is sdata


msgs = Msgs()


def redraw():
    t0 = time.perf_counter()
    sji.figure.canvas.draw()
    return time.perf_counter() - t0


print("redraw, nothing changed:", [round(redraw(), 4) for _ in range(3)])
other = sorted(glob.glob(f"{D}/*3602506433_raster/*.fits"))
for i in range(2):
    new = raster_data(other[i:i + 1], windows=["Si IV 1394"])[0]
    msgs.n = 0
    t0 = time.perf_counter()
    dc.append(new)
    keep_hpc_linked(dc)
    t1 = time.perf_counter()
    d = redraw()
    events()
    print(f"append + keep_hpc_linked an unrelated scan: {t1 - t0:.3f} s, SJI messages {msgs.n}; next SJI draw {d:.3f} s; "
          f"redraw after {redraw():.4f} s")
for i in range(2):
    msgs.n = 0
    editor = LinkEditor(dc)
    editor.show()
    events()
    t0 = time.perf_counter()
    editor.accept()
    t1 = time.perf_counter()
    d = redraw()
    events()
    print(f"Link Data OK, no edits: {t1 - t0:.3f} s, SJI messages {msgs.n}; next SJI draw {d:.3f} s; redraw after {redraw():.4f} s")
