"""
Time glue's launch as glue_qt.main.start_glue runs it, with candidate fixes applied in memory (overlay.py).

    startup.py <scenario[,scenario]|base> with|without
"""
import json
import os
import resource
import sys
import time

t_start = time.perf_counter()
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
sys.path.insert(1, HERE)
import overlay  # noqa: E402

scen, mode = sys.argv[1], sys.argv[2]
overlay.install(scen)
os.makedirs(os.path.expanduser("~/.glue"), exist_ok=True)
if mode == "without":
    with open(os.path.expanduser("~/.glue/plugins.cfg"), "w") as f:
        f.write("[plugins]\nglue_solar = 0\n")

T = {}
t0 = time.perf_counter()
import glue  # noqa: E402
try:
    from qtpy import QtWebEngineWidgets  # noqa: F401
except ImportError:
    pass
from glue_qt.utils import get_qapp  # noqa: E402
app = get_qapp()
from glue_qt.main import get_splash  # noqa: E402
splash = get_splash()
splash.show()
T["pre_plugins"] = time.perf_counter() - t0
t0 = time.perf_counter()
from glue.main import load_plugins  # noqa: E402
load_plugins(splash=splash, require_qt_plugins=True)
T["load_plugins"] = time.perf_counter() - t0
t0 = time.perf_counter()
from glue_qt.app import GlueApplication  # noqa: E402
splash.close()
dc = glue.core.DataCollection()
ga = GlueApplication(session=glue.core.Session(data_collection=dc, hub=dc.hub))
ga.start(block=False, maximized=False)
ga.resize(1600, 1000)
for _ in range(30):
    app.processEvents()
T["app_and_show"] = time.perf_counter() - t0
T["to_window"] = time.perf_counter() - t_start
mods = sys.modules
print(json.dumps({
    "scen": scen, "mode": mode, **{k: round(v, 4) for k, v in T.items()},
    "rss_mb": round(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 2**20),
    "n_mod": len(mods),
    "has": {m: m in mods for m in ["IPython", "qtconsole", "irispy", "sunpy.map", "scipy.optimize", "scipy.stats", "dask"]},
    "glue_solar": getattr(mods.get("glue_solar"), "__file__", None),
}))
