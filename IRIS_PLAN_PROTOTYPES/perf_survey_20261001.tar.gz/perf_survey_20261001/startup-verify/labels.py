"""
Finding 2 (and 5's quicklook share): open the IRIS quicklook of 4000005156 (Mg II k 2796, both scans, SJI 2796
deconvolved), loaded through glue-solar's loaders, and count label/tick/icon work.

    labels.py none|labels|cmapcache
"""
import glob
import json
import os
import statistics
import sys
import time

sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
sys.path.insert(1, os.path.dirname(os.path.abspath(__file__)))
import instr  # noqa: E402

what = sys.argv[1]
D = "/Users/nabil/DATA/IRIS"
WINDOW = "Mg II k 2796"
import glue  # noqa: E402
from glue.main import load_plugins  # noqa: E402
from glue_qt.utils import get_qapp  # noqa: E402

app = get_qapp()
load_plugins(require_qt_plugins=True)
from glue_qt.app import GlueApplication  # noqa: E402
from glue_solar.quicklook import quicklook  # noqa: E402
from glue_solar.sources.loaders.iris import image_data, raster_data  # noqa: E402

instr.whatif(what)
instr.install_all()
dc = glue.core.DataCollection()
ga = GlueApplication(session=glue.core.Session(data_collection=dc, hub=dc.hub))
ga.start(block=False, maximized=False)
ga.resize(1600, 1000)
for _ in range(30):
    app.processEvents()

t0 = time.perf_counter()
files = sorted(glob.glob(f"{D}/*4000005156_raster/*.fits"))
datasets = raster_data(files, windows=[WINDOW]) + [image_data(glob.glob(f"{D}/*4000005156_SJI_2796*.fits.gz")[0])]
t_load = time.perf_counter() - t0
base = instr.snapshot()
n0 = len(instr.DRAWS)
t0 = time.perf_counter()
viewers = quicklook(ga, datasets, window=WINDOW)
t_call = time.perf_counter() - t0
in_call = {k: (v[0] - base.get(k, (0, 0))[0], round(v[1] - base.get(k, (0, 0))[1], 4)) for k, v in instr.snapshot().items()}
# settle: until no canvas has drawn for 1 s
last, seen, t_end = time.perf_counter(), len(instr.DRAWS), time.perf_counter() + 60
while time.perf_counter() < t_end:
    app.processEvents()
    if len(instr.DRAWS) != seen:
        seen, last = len(instr.DRAWS), time.perf_counter()
    elif time.perf_counter() - last > 1.0:
        break
draws = instr.DRAWS[n0:]
t_last_draw = (draws[-1][0] - t0) if draws else None

# Hot function alone: one label set and one tick recomputation on each viewer's axes, median of 15
alone = {}
for name, v in [("map", viewers.get("map")), ("spectrogram", viewers.get("spectrogram")), ("sji", viewers["sji"][0])]:
    ax = v.axes
    ts, tt = [], []
    for _ in range(15):
        a = time.perf_counter()
        ax.set_xlabel(ax.get_xlabel() or "x")
        ts.append(time.perf_counter() - a)
        a = time.perf_counter()
        type(ax)._update_tick_and_label_positions(ax)
        tt.append(time.perf_counter() - a)
    alone[name] = {"set_xlabel_ms": round(1e3 * statistics.median(ts), 2), "ticks_ms": round(1e3 * statistics.median(tt), 2)}

print(json.dumps({"what": what, "load_s": round(t_load, 3), "quicklook_call_s": round(t_call, 4),
                  "to_last_draw_s": round(t_last_draw, 4) if t_last_draw else None,
                  "n_draws": len(draws), "draw_total_s": round(sum(d for _, d in draws), 4),
                  "in_call": in_call, "alone": alone, "datasets": [(d.label[:40], d.shape) for d in datasets],
                  "glue_solar": sys.modules["glue_solar"].__file__}))
