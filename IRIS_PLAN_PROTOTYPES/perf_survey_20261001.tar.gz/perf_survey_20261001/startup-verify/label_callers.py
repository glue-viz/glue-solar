"""Who sets the axis labels while a plain image viewer is created (second viewer, 50x400x400 cube)."""
import cProfile, pstats, io, sys
sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
import numpy as np, glue
from glue.main import load_plugins
from glue_qt.utils import get_qapp
app = get_qapp(); load_plugins(require_qt_plugins=True)
from glue_qt.app import GlueApplication
from glue_qt.viewers.image import ImageViewer
dc = glue.core.DataCollection()
ga = GlueApplication(session=glue.core.Session(data_collection=dc, hub=dc.hub)); ga.start(block=False, maximized=False); ga.resize(1600, 1000)
for _ in range(30): app.processEvents()
d = glue.core.Data(x=np.random.default_rng(0).random((50, 400, 400), dtype=np.float32), label="cube"); dc.append(d)
ga.new_data_viewer(ImageViewer, data=d)
for _ in range(30): app.processEvents()
pr = cProfile.Profile(); pr.enable(); ga.new_data_viewer(ImageViewer, data=d)
for _ in range(30): app.processEvents()
pr.disable()
st = pstats.Stats(pr)
for (fn, ln, name), (cc, nc, tt, ct, callers) in st.stats.items():
    if name in ("set_xlabel", "set_ylabel", "_set_wcs", "update_x_axislabel", "_update_tick_and_label_positions") :
        print(f"{name} ({fn.split('site-packages/')[-1]}:{ln}) calls={nc} cum={ct:.4f}")
        for c, v in callers.items():
            print(f"    <- {c[2]} {c[0].split('site-packages/')[-1]}:{c[1]} x{v[1]}")
