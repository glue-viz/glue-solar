import os, sys
sys.argv = [sys.argv[0]] + sys.argv[1:3]
here = os.path.dirname(os.path.abspath(__file__))
g = {"__file__": os.path.join(here, "startup.py"), "__name__": "__main__"}
exec(open(g["__file__"]).read(), g)
print("MODS", {m: m in sys.modules for m in ["gwcs", "ndcube", "reproject", "dkist", "aiohttp", "parfive", "scipy.signal", "scipy.stats", "scipy.optimize", "astropy_healpix", "dask.array", "IPython", "qtconsole", "zmq"]})
