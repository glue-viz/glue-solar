"""
Findings 2 and 5 on a plain cube: cost of creating image viewers 1..11 (50x400x400 float32), with the label
and colormap-icon work counted, plus a standalone QColormapCombo micro-benchmark.

    viewers.py with|without none|labels|cmapcache
"""
import json
import os
import statistics
import sys
import time

sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
sys.path.insert(1, os.path.dirname(os.path.abspath(__file__)))
import instr  # noqa: E402

mode, what = sys.argv[1], sys.argv[2]
os.makedirs(os.path.expanduser("~/.glue"), exist_ok=True)
if mode == "without":
    with open(os.path.expanduser("~/.glue/plugins.cfg"), "w") as f:
        f.write("[plugins]\nglue_solar = 0\n")

import numpy as np  # noqa: E402
import glue  # noqa: E402
from glue.main import load_plugins  # noqa: E402
from glue_qt.utils import get_qapp  # noqa: E402

app = get_qapp()
load_plugins(require_qt_plugins=True)
from glue.config import colormaps  # noqa: E402
from glue_qt.app import GlueApplication  # noqa: E402
from glue_qt.viewers.image import ImageViewer  # noqa: E402

instr.whatif(what)
instr.install_all()
dc = glue.core.DataCollection()
ga = GlueApplication(session=glue.core.Session(data_collection=dc, hub=dc.hub))
ga.start(block=False, maximized=False)
ga.resize(1600, 1000)


def settle(n=30):
    for _ in range(n):
        app.processEvents()


settle()
data = glue.core.Data(x=np.random.default_rng(0).random((50, 400, 400), dtype=np.float32), label="cube")
dc.append(data)
rows = []
for i in range(11):
    before = instr.snapshot()
    t0 = time.perf_counter()
    ga.new_data_viewer(ImageViewer, data=data)
    t_new = time.perf_counter() - t0
    settle()
    t_all = time.perf_counter() - t0
    after = instr.snapshot()
    rows.append({"new": t_new, "with_settle": t_all,
                 **{k: (after[k][0] - before.get(k, (0, 0))[0], after[k][1] - before.get(k, (0, 0))[1]) for k in after}})


def med(key, idx=None):
    vals = [r[key] if idx is None else r.get(key, (0, 0))[idx] for r in rows[1:]]
    return round(statistics.median(vals), 4)


summary = {"new_viewer_s": med("new"), "new_viewer_with_settle_s": med("with_settle")}
for k in ("set_xlabel", "set_ylabel", "ticks", "_set_wcs", "_update_icons", "combo_init"):
    summary[k] = (med(k, 0), med(k, 1))

# Standalone combo: construction and one width change (its resizeEvent rebuilds the icons)
from glue_qt.utils.colors import QColormapCombo, cmap2pixmap  # noqa: E402
import glue_qt.utils.colors as colors  # noqa: E402
ti, tr = [], []
for _ in range(15):
    t0 = time.perf_counter()
    c = QColormapCombo()
    ti.append(time.perf_counter() - t0)
    c.show()
    settle(3)
    t0 = time.perf_counter()
    c.resize(c.width() + 37, c.height())
    settle(3)
    tr.append(time.perf_counter() - t0)
    c.close()
    c.deleteLater()
cm = colormaps.members[0][1]
tp = []
for _ in range(200):
    t0 = time.perf_counter()
    colors.cmap2pixmap(cm, size=(100, 15), steps=200)
    tp.append(time.perf_counter() - t0)
print(json.dumps({"mode": mode, "what": what, "n_colormaps": len(colormaps.members), **summary,
                  "combo_init_ms": round(1e3 * statistics.median(ti), 2), "combo_resize_ms": round(1e3 * statistics.median(tr), 2),
                  "cmap2pixmap_ms": round(1e3 * statistics.median(tp), 3),
                  "glue_solar": getattr(sys.modules.get("glue_solar"), "__file__", None)}))
