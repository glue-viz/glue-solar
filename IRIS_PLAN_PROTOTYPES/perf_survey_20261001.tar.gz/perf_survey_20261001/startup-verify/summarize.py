import json
import statistics
import sys
from collections import defaultdict

rows = [json.loads(line) for line in open(sys.argv[1])]
g = defaultdict(list)
for r in rows:
    g[(r["scen"], r["mode"])].append(r)


def mad(xs):
    m = statistics.median(xs)
    return statistics.median(abs(x - m) for x in xs)


base = {m: statistics.median(r["to_window"] for r in g[("base", m)]) for m in ("with", "without") if g[("base", m)]}
print(f"{'scenario':32s} {'mode':8s} n  to_window (MAD)   saving  load_plugins pre_plugins app_show  mods  rss  IPython irispy scipy.opt")
for (s, m), rs in g.items():
    tw = [r["to_window"] for r in rs]
    med = lambda k: statistics.median(r[k] for r in rs)  # noqa: E731
    h = rs[0]["has"]
    print(f"{s:32s} {m:8s} {len(rs)}  {statistics.median(tw):.3f} ({mad(tw):.3f})  {base.get(m, float("nan"))-statistics.median(tw):+.3f}"
          f"  {med('load_plugins'):.3f}       {med('pre_plugins'):.3f}      {med('app_and_show'):.3f}   {med('n_mod'):.0f} {med('rss_mb'):.0f}"
          f"  {h['IPython']!s:5s}  {h['irispy']!s:5s}  {h['scipy.optimize']}")
