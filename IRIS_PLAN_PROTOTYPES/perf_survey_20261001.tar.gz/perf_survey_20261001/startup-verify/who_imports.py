"""Print the import chain that first brings in a module during a launch with the given overlays."""
import importlib.abc, os, sys, traceback
target = sys.argv[3]
class Spy(importlib.abc.MetaPathFinder):
    def find_spec(self, name, path, target_=None):
        if name == target:
            stack = [f"{os.path.relpath(f.filename, '/Users/nabil/mamba/envs/iris-plan/lib/python3.13/site-packages')}:{f.lineno}"
                     for f in traceback.extract_stack() if "<frozen" not in f.filename]
            print("FIRST IMPORT OF", target, "\n  " + "\n  ".join(stack[-14:]))
            sys.meta_path.remove(self)
        return None
sys.meta_path.insert(0, Spy())
sys.argv = sys.argv[:3]
exec(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "startup.py")).read(), {"__file__": os.path.abspath(__file__).replace("who_imports", "startup"), "__name__": "__main__"})
