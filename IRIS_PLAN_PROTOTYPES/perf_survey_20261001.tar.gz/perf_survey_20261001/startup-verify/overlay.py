"""
Apply a candidate fix in memory: load named modules from their real source with text replacements.

Nothing on disk changes. Each replacement must match exactly once, so a fix that no longer fits the
installed source fails loudly instead of silently measuring the unpatched code.
"""
import importlib.abc
import importlib.machinery
import importlib.util
import sys


class _Loader(importlib.abc.SourceLoader):
    def __init__(self, fullname, path, edits):
        self.fullname, self.path, self.edits = fullname, path, edits

    def get_filename(self, fullname):
        return self.path

    def get_data(self, path):
        with open(path, "rb") as f:
            src = f.read().decode()
        if path == self.path:
            for old, new in self.edits:
                assert src.count(old) == 1, (self.fullname, old)
                src = src.replace(old, new)
        return src.encode()

    def path_stats(self, path):  # no bytecode cache for edited sources
        raise OSError


class _Finder(importlib.abc.MetaPathFinder):
    def __init__(self, fixes):
        self.fixes = fixes

    def find_spec(self, fullname, path, target=None):
        if fullname not in self.fixes:
            return None
        spec = importlib.machinery.PathFinder.find_spec(fullname, path)
        loader = _Loader(fullname, spec.origin, self.fixes[fullname])
        return importlib.util.spec_from_file_location(
            fullname, spec.origin, loader=loader, submodule_search_locations=spec.submodule_search_locations)


GLUE_SOLAR = {
    "glue_solar.sources.loaders.iris": [(
        "from irispy.io import read_files\n",
        "def read_files(*a, **k):\n    from irispy.io import read_files as f\n    return f(*a, **k)\n",
    )],
    "glue_solar.sources.maps": [
        ("import sunpy.map\nfrom sunpy.map.mapbase import GenericMap\n", "class GenericMap:\n    pass\n"),
        ("    sunpy_map_data = _parse_sunpy_map(", "    import sunpy.map\n    sunpy_map_data = _parse_sunpy_map("),
    ],
}

# The finding's fix as written: viewer cleanup checks sys.modules; terminal imported on first use.
IPY_AS_WRITTEN = {
    "glue.viewers.common.viewer": [
        ("from IPython import get_ipython\n", "import sys\n"),
        ("        shell = get_ipython()\n",
         "        shell = sys.modules['IPython'].get_ipython() if 'IPython' in sys.modules else None\n"),
    ],
    "glue_qt.app.application": [
        ("from glue_qt.app.terminal import glue_terminal, IPythonTerminalError\n", ""),
        ("            widget = glue_terminal(",
         "            from glue_qt.app.terminal import glue_terminal, IPythonTerminalError\n"
         "            widget = glue_terminal("),
    ],
}

# Plus the third site the finding does not mention: GlueApplication.start() -> _fix_ipython_pylab().
IPY_FULL = {
    "glue.viewers.common.viewer": IPY_AS_WRITTEN["glue.viewers.common.viewer"],
    "glue_qt.app.application": IPY_AS_WRITTEN["glue_qt.app.application"] + [(
        "    try:\n        from IPython import get_ipython\n    except ImportError:\n        return\n",
        "    if 'IPython' not in sys.modules:\n        return\n    get_ipython = sys.modules['IPython'].get_ipython\n",
    )],
}

AUTOLINK = {
    "glue.plugins.wcs_autolinking.wcs_autolinking": [
        ("from scipy.optimize import leastsq\n", ""),
        ("        best, _ = leastsq(transform_offset", "        from scipy.optimize import leastsq\n        best, _ = leastsq(transform_offset"),
        ("        best, _ = leastsq(transform_affine", "        from scipy.optimize import leastsq\n        best, _ = leastsq(transform_affine"),
    ],
}

# glue-solar, one step further: stack_spectrograms' module-level ndcube import (ndcube -> gwcs -> scipy.optimize)
NDCUBE = {
    "glue_solar.sources.loaders.stack_spectrograms": [
        ("from ndcube import NDCube\nfrom ndcube.wcs.wrappers import CompoundLowLevelWCS\n", ""),
        ("    out_wcs = CompoundLowLevelWCS(", "    from ndcube import NDCube\n    from ndcube.wcs.wrappers import CompoundLowLevelWCS\n    out_wcs = CompoundLowLevelWCS("),
    ],
}

SCENARIOS = {"ndcube": NDCUBE, "solar": GLUE_SOLAR, "ipy_written": IPY_AS_WRITTEN, "ipy_full": IPY_FULL, "autolink": AUTOLINK}


def install(names):
    fixes = {}
    for n in filter(None, names.split(",")):
        if n != "base":
            for mod, edits in SCENARIOS[n].items():
                fixes[mod] = fixes.get(mod, []) + [e for e in edits if e not in fixes.get(mod, [])]
    if fixes:
        sys.meta_path.insert(0, _Finder(fixes))
    return fixes
