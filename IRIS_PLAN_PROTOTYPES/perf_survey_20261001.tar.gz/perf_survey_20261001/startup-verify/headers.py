"""Finding 3: header-only reads of .fits.gz decompress the whole primary array (scan_directory, identifiers)."""
import cProfile
import gzip
import pstats
import statistics
import sys
import time
from pathlib import Path

sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
from astropy.io import fits  # noqa: E402

ROOT = Path("/Users/nabil/DATA/IRIS")


def med(fn, n=5):
    ts = []
    for _ in range(n):
        t0 = time.perf_counter()
        out = fn()
        ts.append(time.perf_counter() - t0)
    return statistics.median(ts), out


def primary_header(p):
    with (gzip.open(p, "rb") if str(p).endswith(".gz") else open(p, "rb")) as f:
        return fits.Header.fromfile(f)


files = sorted(p for p in ROOT.rglob("*") if p.is_file() and p.name.endswith((".fits", ".fits.gz")))
gz = [p for p in files if p.name.endswith(".gz")]
print(f"{len(files)} files ({len(gz)} gz)")
t_all, h1 = med(lambda: [fits.getheader(p) for p in files])
t_pri, h2 = med(lambda: [primary_header(p) for p in files])
t_gz, _ = med(lambda: [fits.getheader(p) for p in gz])
t_gzp, _ = med(lambda: [primary_header(p) for p in gz])
same = all(a.tostring() == b.tostring() for a, b in zip(h1, h2))
print(f"getheader all {t_all:.3f}s  primary-only {t_pri:.3f}s | gz: {t_gz:.3f}s vs {t_gzp:.3f}s | identical: {same}")
for p in gz:
    t, _ = med(lambda: fits.getheader(p), 3)
    raw = gzip.open(p).seek(0, 2)
    print(f"  {p.name[33:70]:38s} gz {p.stat().st_size/1e6:6.1f} MB raw {raw/1e6:6.1f} MB getheader {t:.3f}s")

# Who spends the time on the biggest gz?
big = max(gz, key=lambda p: p.stat().st_size)
pr = cProfile.Profile()
pr.enable()
fits.getheader(big)
pr.disable()
st = pstats.Stats(pr)
tot = st.total_tt
for (fn, ln, name), (cc, nc, tt, ct, callers) in st.stats.items():
    if name in ("seek", "decompress", "read") and ct > 0.05 * tot:
        print(f"  profile: {Path(fn).name}:{ln} {name} cum {ct:.3f}s of {tot:.3f}s; callers:",
              [f"{Path(c[0]).name}:{c[1]} {c[2]}" for c in callers])

# glue-solar's browser scan, as is and with getheader swapped for primary_header (in this process only)
from glue_solar.sources.loaders import scan  # noqa: E402
t_scan, obs = med(lambda: scan.scan_directory(ROOT), 5)
orig = scan.fits.getheader
scan.fits.getheader = lambda p, *a, **k: primary_header(p)
t_scan2, obs2 = med(lambda: scan.scan_directory(ROOT), 5)
scan.fits.getheader = orig
print(f"scan_directory {t_scan:.3f}s -> {t_scan2:.3f}s with primary-header reads; same result: {repr(obs) == repr(obs2)} ({len(obs)} obs)")

# File -> Open identification
from glue.main import load_plugins  # noqa: E402
load_plugins(require_qt_plugins=False)
from glue.config import data_factory  # noqa: E402
from glue.core.data_factories import find_factory, is_fits  # noqa: E402
from glue_solar.sources.iris import is_iris_fits  # noqa: E402
print("factories >=100:", [(d.label, d.priority) for d in data_factory if d.priority >= 100])
for p in gz:
    r = {}
    for label, fn in (("find_factory", lambda: find_factory(str(p))), ("is_iris_fits", lambda: is_iris_fits(str(p))),
                      ("glue is_fits", lambda: is_fits(str(p))), ("primary_header", lambda: primary_header(p))):
        t, out = med(fn, 3)
        r[label] = (round(t, 3), getattr(out, "label", out if not isinstance(out, fits.Header) else "hdr"))
    print(f"  {p.name[33:70]:38s}", r)
print(sys.modules["glue_solar"].__file__)
