"""Harness-only instrumentation and in-process what-ifs shared by labels.py and viewers.py."""
import threading
import time
from collections import defaultdict

ACC = defaultdict(lambda: [0, 0.0])  # label -> [calls, outermost inclusive seconds] (main thread)
_DEPTH = defaultdict(int)
DRAWS = []


def instrument(owner, attr, label):
    original = getattr(owner, attr)

    def wrapper(*args, **kwargs):
        if threading.current_thread() is not threading.main_thread():
            return original(*args, **kwargs)
        _DEPTH[label] += 1
        t0 = time.perf_counter()
        try:
            return original(*args, **kwargs)
        finally:
            _DEPTH[label] -= 1
            ACC[label][0] += 1
            if _DEPTH[label] == 0:
                ACC[label][1] += time.perf_counter() - t0

    setattr(owner, attr, wrapper)


def snapshot():
    return {k: (v[0], round(v[1], 4)) for k, v in ACC.items()}


def install_all():
    from astropy.visualization.wcsaxes import WCSAxes
    from glue.viewers.image.viewer import MatplotlibImageMixin
    from glue_qt.utils.colors import QColormapCombo
    from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
    instrument(WCSAxes, "_update_tick_and_label_positions", "ticks")
    instrument(WCSAxes, "set_xlabel", "set_xlabel")
    instrument(WCSAxes, "set_ylabel", "set_ylabel")
    instrument(MatplotlibImageMixin, "_set_wcs", "_set_wcs")
    instrument(QColormapCombo, "_update_icons", "_update_icons")
    instrument(QColormapCombo, "__init__", "combo_init")
    _draw = FigureCanvasQTAgg.draw

    def timed_draw(self):
        t0 = time.perf_counter()
        _draw(self)
        DRAWS.append((time.perf_counter(), time.perf_counter() - t0))

    FigureCanvasQTAgg.draw = timed_draw


def whatif(name):
    if name == "labels":
        # Upper bound: setting an axis label no longer recomputes ticks (draw still does).
        from astropy.visualization.wcsaxes import WCSAxes
        for attr in ("set_xlabel", "set_ylabel"):
            def skip(self, *a, _orig=getattr(WCSAxes, attr), **k):
                self._update_tick_and_label_positions = lambda *_a, **_k: None
                try:
                    return _orig(self, *a, **k)
                finally:
                    del self._update_tick_and_label_positions
            setattr(WCSAxes, attr, skip)
    elif name == "cmapcache":
        import glue_qt.utils.colors as colors
        orig, cache = colors.cmap2pixmap, {}

        def cached(cmap, steps=50, size=(100, 100)):
            key = (cmap.name, steps, tuple(size))
            if key not in cache:
                cache[key] = orig(cmap, steps=steps, size=size)
            return cache[key]
        colors.cmap2pixmap = cached
    elif name != "none":
        raise ValueError(name)
