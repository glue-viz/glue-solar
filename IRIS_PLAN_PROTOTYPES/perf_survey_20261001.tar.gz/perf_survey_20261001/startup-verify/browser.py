"""Open Plugins -> IRIS: browse observations on /Users/nabil/DATA/IRIS (dialog construction + show), as is and with
primary-header reads swapped in (in-process); 5 alternating repeats each."""
import gzip, os, statistics, sys, time
sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
import glue
from glue.main import load_plugins
from glue_qt.utils import get_qapp
app = get_qapp(); load_plugins(require_qt_plugins=True)
from astropy.io import fits
from glue_qt.app import GlueApplication
from qtpy.QtCore import QSettings
import glue_solar.sources.loaders.iris as loader
from glue_solar.sources.loaders import scan
loader.QSettings = lambda *_: QSettings(os.path.expanduser("~/gs.ini"), QSettings.IniFormat)  # keep macOS prefs untouched
dc = glue.core.DataCollection()
ga = GlueApplication(session=glue.core.Session(data_collection=dc, hub=dc.hub)); ga.start(block=False, maximized=False); ga.resize(1600, 1000)
for _ in range(30): app.processEvents()
orig = scan.fits.getheader
def primary(p, *a, **k):
    with (gzip.open(p, "rb") if str(p).endswith(".gz") else open(p, "rb")) as f:
        return fits.Header.fromfile(f)
res = {"as_is": [], "primary": [], "scan_as_is": []}
for i in range(5):
    for k in ("as_is", "primary"):
        scan.fits.getheader = orig if k == "as_is" else primary
        t0 = time.perf_counter(); d = loader.QtIRISImporter("/Users/nabil/DATA/IRIS", parent=ga); d.show()
        for _ in range(10): app.processEvents()
        res[k].append(time.perf_counter() - t0); n = len(d.observations); d.close(); d.deleteLater()
    scan.fits.getheader = orig
    t0 = time.perf_counter(); scan.scan_directory("/Users/nabil/DATA/IRIS"); res["scan_as_is"].append(time.perf_counter() - t0)
print({k: round(statistics.median(v), 3) for k, v in res.items()}, "observations", n, sys.modules["glue_solar"].__file__)
