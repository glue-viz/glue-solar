import sys, glob, time
sys.path.insert(0, '/Users/nabil/Git/glue-solar-main')
DATA = "/Users/nabil/DATA/IRIS"
from glue_solar.sources.loaders.iris import image_data, raster_data
import glue_solar, glue_solar.quicklook as ql
[raster] = raster_data(glob.glob(f"{DATA}/*4000255147_raster/*_r00000.fits"), windows=["Si IV 1403"])
sji = image_data(glob.glob(f"{DATA}/*4000255147_SJI_1400_t000.fits.gz")[0])
from glue_qt.app import GlueApplication
from glue_qt.utils import get_qapp
from qtpy import QtCore
from qtpy.QtTest import QTest
get_qapp(); glue_solar.setup()
app = GlueApplication(); app.resize(1600, 1000); app.show()
def pump(s=1.0):
    t = time.perf_counter()
    while time.perf_counter() - t < s:
        get_qapp().processEvents(); time.sleep(0.002)
V = ql.quicklook(app, [raster, sji]); pump(2)
mp = V["map"]; coord = app.data_collection._solar_coordinator
def show(tag):
    s = mp.state
    print(tag, "tool", getattr(mp.toolbar.active_tool, "tool_id", None), "x", s.x_att, "y", s.y_att, "lims", [round(v,1) for v in (s.x_min, s.x_max, s.y_min, s.y_max)], "point", coord.point.slices if coord.point else None, "edit", app.session.edit_subset_mode.edit_subset, "wcsflag", mp._changing_slice_requires_wcs_update, flush=True)
def click(xd, yd):
    c = mp.figure.canvas
    xs, ys = mp.axes.transData.transform((xd, yd))
    pos = QtCore.QPoint(int(xs), int(c.height() - ys))
    QTest.mousePress(c, QtCore.Qt.LeftButton, QtCore.Qt.NoModifier, pos)
    QTest.mouseRelease(c, QtCore.Qt.LeftButton, QtCore.Qt.NoModifier, pos)
    pump(0.6)
show("start")
click(840, 228); show("after click 1")
mp.state.x_att = mp.state.y_att; pump(0.5); show("after swap 1")
mp.state.x_att = mp.state.y_att; pump(0.5); show("after swap 2")
click(760, 188); show("after click 2")
app.close()
