"""
Independent re-measurement of the 'events' findings (measure only: nothing on disk is changed).

Light instrumentation only: a few method wrappers that count/time (no echo or hub wrappers).
Fix emulations are harness-level (public calls / instance state in this process), never file edits.

usage: python verify.py [all|click]   (GS_PATH picks the glue_solar checkout)
"""

import functools
import glob
import os
import resource
import statistics
import sys
import threading
import time
from collections import Counter, defaultdict

GS = os.environ.get("GS_PATH", "/Users/nabil/Git/glue-solar-main")
sys.path.insert(0, GS)
MODE = sys.argv[1] if len(sys.argv) > 1 else "all"
HERE = os.path.dirname(os.path.abspath(__file__))
DATA = "/Users/nabil/DATA/IRIS"
RASTER = glob.glob(f"{DATA}/*4000255147_raster/*_r00000.fits")
SJI = glob.glob(f"{DATA}/*4000255147_SJI_1400_t000.fits.gz")[0]
MAIN = threading.get_ident()
OUT = open(os.path.join(HERE, f"verify_{MODE}_{os.path.basename(GS)}.log"), "w")


def say(*a):
    text = " ".join(str(x) for x in a)
    print(text, flush=True)
    OUT.write(text + "\n")
    OUT.flush()


class R:
    on = False
    n = Counter()
    t = defaultdict(float)
    tl = []
    t0 = 0.0
    stack = []

    @classmethod
    def reset(cls):
        cls.n, cls.t, cls.tl, cls.stack = Counter(), defaultdict(float), [], []
        cls.t0 = time.perf_counter()


CANVAS = {}


def cname(obj):
    canvas = getattr(obj, "figure", None)
    canvas = getattr(canvas, "canvas", obj)
    return CANVAS.get(id(canvas), "other")


def wrap(cls, attr, key, worker=False, per_canvas=None):
    orig = getattr(cls, attr)

    @functools.wraps(orig)
    def w(*a, **k):
        if not R.on:
            return orig(*a, **k)
        main = threading.get_ident() == MAIN
        if not main and not worker:
            return orig(*a, **k)
        name = key if main else "worker " + key
        if per_canvas and main:
            name += " " + cname(per_canvas(a[0]))
        ctx = R.stack[-1].split()[0] if (main and R.stack) else None
        if main:
            R.stack.append(name)
        R.tl.append((time.perf_counter() - R.t0, "begin", name))
        t = time.perf_counter()
        try:
            return orig(*a, **k)
        finally:
            dt = time.perf_counter() - t
            if main:
                R.stack.pop()
            R.n[name] += 1
            R.t[name] += dt
            if ctx:
                R.n[f"{key} in {ctx}"] += 1
                R.t[f"{key} in {ctx}"] += dt
            R.tl.append((time.perf_counter() - R.t0, "end", name))

    setattr(cls, attr, w)


def install():
    from astropy.visualization.wcsaxes.core import WCSAxes
    from glue.viewers.image.layer_artist import ImageSubsetLayerArtist
    from glue.viewers.image.viewer import MatplotlibImageMixin
    from glue.viewers.matplotlib.viewer import MatplotlibViewerMixin
    from glue.viewers.profile.layer_artist import ProfileLayerArtist
    from glue_qt.utils.colors import QColormapCombo
    from glue_qt.viewers.matplotlib.widget import MplCanvas
    from glue_qt.viewers.profile.layer_artist import QThreadedProfileLayerArtist

    import glue_solar.quicklook as ql

    from glue_qt.viewers.image.data_viewer import ImageViewer

    # glue-qt's ImageViewer holds its own defer_draw-decorated copies of the mixins' methods
    # (decorate_all_methods), so the wrappers go on that class
    viewer_axes = lambda v: v.axes  # noqa: E731
    wrap(ImageViewer, "_set_wcs", "_set_wcs", per_canvas=viewer_axes)
    wrap(ImageViewer, "_on_slice_change", "slicecb", per_canvas=viewer_axes)
    wrap(ImageViewer, "update_x_axislabel", "xlabelcb", per_canvas=viewer_axes)
    wrap(ImageViewer, "update_y_axislabel", "ylabelcb", per_canvas=viewer_axes)
    wrap(WCSAxes, "_update_tick_and_label_positions", "ticks")
    wrap(WCSAxes, "reset_wcs", "reset_wcs")
    wrap(MplCanvas, "draw", "draw", per_canvas=lambda c: c)
    wrap(QColormapCombo, "_update_icons", "cmap_icons")
    wrap(QColormapCombo, "resizeEvent", "cmap_resize")
    wrap(ProfileLayerArtist, "_calculate_profile_thread", "profile_thread", worker=True)
    wrap(QThreadedProfileLayerArtist, "_calculate_profile", "profile_request")
    wrap(QThreadedProfileLayerArtist, "_calculate_profile_postthread", "postthread")
    wrap(ImageSubsetLayerArtist, "update", "subset_update", per_canvas=lambda la: la.axes)
    wrap(ql.Coordinator, "_update", "coord_update")
    wrap(ql.Coordinator, "point_on", "point_on")
    orig_px = ql._sji_pixels

    def _sji_pixels(*a, **k):
        if not R.on:
            return orig_px(*a, **k)
        t = time.perf_counter()
        try:
            return orig_px(*a, **k)
        finally:
            R.n["_sji_pixels"] += 1
            R.t["_sji_pixels"] += time.perf_counter() - t

    ql._sji_pixels = _sji_pixels


def busy(app):
    from glue_qt.utils import get_qapp  # noqa: F401

    for tab in app.viewers:
        for viewer in tab:
            if getattr(viewer.figure.canvas, "_draw_pending", False):
                return True
            for layer in viewer.layers:
                if getattr(layer, "is_computing", False):
                    return True
                worker = getattr(layer, "_worker", None)
                if worker is not None and not worker.work_queue.empty():
                    return True
    coord = getattr(app.data_collection, "_solar_coordinator", None)
    return coord is not None and coord._timer.isActive()


def settle(app, timeout=20.0):
    """Process events until 0.1 s of quiet; returns the time at which the quiet began."""
    from glue_qt.utils import get_qapp

    q = get_qapp()
    t0 = time.perf_counter()
    quiet = None
    while time.perf_counter() - t0 < timeout:
        q.processEvents()
        if busy(app):
            quiet = None
        else:
            quiet = quiet or time.perf_counter()
            if time.perf_counter() - quiet > 0.1:
                return quiet - t0
        time.sleep(0.001)
    return time.perf_counter() - t0


def med(xs):
    return statistics.median(xs) * 1e3


def rng(xs):
    return f"{min(xs) * 1e3:.0f}-{max(xs) * 1e3:.0f}"


install()
from glue_solar.sources.loaders.iris import image_data, raster_data  # noqa: E402

import glue_solar  # noqa: E402

say("glue_solar from", glue_solar.__file__)
t = time.perf_counter()
[raster] = raster_data(RASTER, windows=["Si IV 1403"])
sji = image_data(SJI)
say(f"load {time.perf_counter() - t:.1f} s raster {raster.shape} sji {sji.shape}")

from glue.config import colormaps  # noqa: E402
from glue_qt.app import GlueApplication  # noqa: E402
from glue_qt.utils import get_qapp  # noqa: E402

import glue_solar.quicklook as ql  # noqa: E402

n_glue_cmaps = len(colormaps.members)
get_qapp()
app = GlueApplication()  # loads the glue_solar plugin entry point, which calls glue_solar.setup() once
say(f"colormaps: glue {n_glue_cmaps}, after GlueApplication() (plugin setup) {len(colormaps.members)}")
app.resize(1600, 1000)
app.show()
settle(app)

# ---- quicklook open
R.reset()
R.on = True
t = time.perf_counter()
V = ql.quicklook(app, [raster, sji])
t_sync = time.perf_counter() - t
t_idle = t_sync + settle(app)
R.on = False
say(f"\n[open] quicklook() call {t_sync * 1e3:.0f} ms, to idle {t_idle * 1e3:.0f} ms")
for k in sorted(R.n):
    if k.startswith(("_set_wcs", "_set_wcs in", "cmap", "ticks", "slicecb", "draw", "reset_wcs")):
        say(f"   {k:40s} n={R.n[k]:3d}  {R.t[k] * 1e3:7.1f} ms")
open_counts = (dict(R.n), dict(R.t))
t = time.perf_counter()
while time.perf_counter() - t < 1.5:
    get_qapp().processEvents()
    time.sleep(0.005)
settle(app)

mp, sp, wl, spec, sj = V["map"], V["spectrogram"], V["wavelength"], V["spectrum"], V["sji"][0]
for name, v in dict(map=mp, spectrogram=sp, wavelength=wl, spectrum=spec, sji=sj).items():
    CANVAS[id(v.figure.canvas)] = name
    c = v.figure.canvas
    say(f"   {name}: canvas {c.width()}x{c.height()} dpr {c.device_pixel_ratio} "
        f"wcs-on-slice {getattr(v, '_changing_slice_requires_wcs_update', None)} "
        f"layers {[(l.layer.label[:14], l.state.visible) for l in v.layers]}")
coord = app.data_collection._solar_coordinator

from qtpy import QtCore, QtWidgets  # noqa: E402
from qtpy.QtTest import QTest  # noqa: E402


def stepper(viewer, axis):
    k = {"n": 0}

    def act():
        # looked up per call: glue-qt rebuilds the sliders on an axis change
        qs = viewer.options_widget().slice_helper._sliders[axis].findChild(QtWidgets.QSlider, "value_slice_center")
        k["n"] += 1
        qs.triggerAction(QtWidgets.QAbstractSlider.SliderSingleStepAdd if k["n"] % 2 else
                         QtWidgets.QAbstractSlider.SliderSingleStepSub)
    return act


ny, nx = raster.shape[1], raster.shape[0]
PTS = [(nx // 2 + 40, ny // 2 + 20), (nx // 2 - 40, ny // 2 - 20)]
kc = {"n": 0}


def click():
    kc["n"] += 1
    xd, yd = PTS[kc["n"] % 2]
    canvas = mp.figure.canvas
    xs, ys = mp.axes.transData.transform((xd, yd))
    dpr = canvas.device_pixel_ratio
    pos = QtCore.QPoint(int(xs / dpr), int(canvas.height() - ys / dpr))
    QTest.mousePress(canvas, QtCore.Qt.LeftButton, QtCore.Qt.NoModifier, pos)
    QTest.mouseRelease(canvas, QtCore.Qt.LeftButton, QtCore.Qt.NoModifier, pos)


def swap():
    mp.state.x_att = mp.state.y_att


ACT = {
    "sji_step": stepper(sj, 0),
    "exposure_step": stepper(sp, 0),
    "wavelength_step": stepper(mp, 2),
    "click": click,
    "axis_swap": swap,
}


def run(act, rec=True):
    """One action: wall to idle and a copy of the counters/timeline."""
    R.reset()
    R.on = rec
    t = time.perf_counter()
    act()
    wall = time.perf_counter() - t + settle(app)
    R.on = False
    return wall, dict(R.n), dict(R.t), list(R.tl)


def per_action(rows, key):
    return statistics.median(r[1].get(key, 0) for r in rows), med([r[2].get(key, 0) for r in rows])


def summary(label, rows, keys):
    walls = [r[0] for r in rows]
    say(f"  {label:42s} wall-to-idle median {med(walls):6.1f} ms (range {rng(walls)}, n={len(rows)})")
    for key in keys:
        n, ms = per_action(rows, key)
        if n:
            say(f"      {key:40s} n={n:4.1f}  median {ms:6.1f} ms  ({100 * ms / med(walls):.0f}% of wall)")


def draws(rows):
    c = Counter()
    for r in rows:
        for k, v in r[1].items():
            if k.startswith("draw "):
                c[k[5:]] += v
    return {k: round(v / len(rows), 1) for k, v in c.items()}


def lean(v):
    """The slice-only WCS refresh the finding proposes: reset_wcs, labels on glue's coordinate, sizes."""
    s, ax = v.state, v.axes
    nd = s.reference_data.ndim
    ax.reset_wcs(slices=s.wcsaxes_slice, wcs=s.reference_data.coords)
    ax.coords[nd - 1 - s.x_att.axis].set_axislabel(s.x_axislabel, weight=s.x_axislabel_weight, size=s.x_axislabel_size)
    ax.coords[nd - 1 - s.y_att.axis].set_axislabel(s.y_axislabel, weight=s.y_axislabel_weight, size=s.y_axislabel_size)
    v._update_appearance_from_settings()
    v.update_x_ticklabel()
    v.update_y_ticklabel()


FIX = {"lean": False}
for v in (mp, sp, wl, sj):
    v.state.add_callback("slices", lambda *_, v=v: FIX["lean"] and WCS_FLAG[v] and lean(v))
WCS_FLAG = {v: v._changing_slice_requires_wcs_update for v in (mp, sp, wl, sj)}


def set_lean(on):
    FIX["lean"] = on
    for v, flag in WCS_FLAG.items():
        v._changing_slice_requires_wcs_update = (False if on and flag else flag)


def ab(label, act_a, act_b, n=9, setup_a=None, setup_b=None, keys=()):
    """Alternate A and B n times each after one warm-up of each."""
    A, B = [], []
    for i in range(n + 1):
        for setup, act, rows in ((setup_a, act_a, A), (setup_b, act_b, B)):
            if setup:
                setup()
            r = run(act)
            if i:
                rows.append(r)
    if setup_a:
        setup_a()
    summary(label + " A", A, keys)
    say(f"      draws A {draws(A)}")
    summary(label + " B", B, keys)
    say(f"      draws B {draws(B)}")
    say(f"      B - A: {med([r[0] for r in B]) - med([r[0] for r in A]):+.1f} ms")
    return A, B


if MODE == "click":
    keys = ["_set_wcs sji", "_set_wcs spectrogram", "_set_wcs wavelength", "ticks", "ylabelcb wavelength",
            "ylabelcb spectrogram", "xlabelcb sji", "coord_update"]
    run(click)
    rows = [run(click) for _ in range(9)]
    summary("click", rows, keys)
    say(f"      draws {draws(rows)}")
    own = lambda k, p: k.startswith(p) and " in " not in k  # noqa: E731
    for p in ("xlabelcb ", "ylabelcb ", "_set_wcs ", "ticks"):
        say(f"      {p:10s} per click: n={statistics.median(sum(v for k, v in r[1].items() if own(k, p)) for r in rows)}"
            f" median {med([sum(v for k, v in r[2].items() if own(k, p)) for r in rows]):.1f} ms")
    app.close()
    sys.exit()

# ---- F1: actions as is
say("\n[F1] actions as glue leaves them (n=9 after 1 warm-up)")
K1 = ["_set_wcs sji", "_set_wcs spectrogram", "_set_wcs wavelength", "_set_wcs map", "ticks in _set_wcs",
      "ticks in draw", "reset_wcs", "coord_update"]
BASE = {}
for name in ("sji_step", "exposure_step", "click", "wavelength_step", "axis_swap"):
    run(ACT[name])
    rows = [run(ACT[name]) for _ in range(9)]
    BASE[name] = rows
    summary(name, rows, K1)
    sw = [sum(v for k, v in r[2].items() if k.startswith("_set_wcs ")) for r in rows]
    nsw = statistics.median(sum(v for k, v in r[1].items() if k.startswith("_set_wcs ")) for r in rows)
    say(f"      _set_wcs all viewers: n={nsw} median {med(sw):.1f} ms = {100 * med(sw) / med([r[0] for r in rows]):.0f}% of wall;"
        f" draws {draws(rows)}")

# an x change to the current y makes glue pick y itself, alternating (1,2) and (2,1): put the map back
say(f"   map after the axis changes x={mp.state.x_att} y={mp.state.y_att}")
_pc = raster.pixel_component_ids
mp.state.x_att = _pc[0]
if mp.state.y_att is not _pc[1]:
    mp.state.y_att = _pc[1]
settle(app)
say(f"   map restored x={mp.state.x_att} y={mp.state.y_att} limits {mp.state.x_min, mp.state.x_max, mp.state.y_min, mp.state.y_max}")
say("\n[F1] _set_wcs and parts called directly (median of 9, settle between; ms)")
for name, v in (("sji", sj), ("spectrogram", sp), ("map", mp)):
    s, ax = v.state, v.axes

    def timed(f, n=9):
        ts = []
        for _ in range(n):
            t = time.perf_counter()
            f()
            ts.append(time.perf_counter() - t)
            settle(app)
        return med(ts)

    full = timed(lambda: v._set_wcs(relim=False))
    tick = timed(lambda: ax._update_tick_and_label_positions())
    leant = timed(lambda: lean(v))
    v._set_wcs(relim=False)
    settle(app)
    say(f"   {name:12s} full _set_wcs {full:6.1f} | one tick update {tick:5.1f} | lean path {leant:4.1f}")

    # does the lean path render the same figure, and is the following draw the same cost?
    import numpy as np

    c = v.figure.canvas
    v._set_wcs(relim=False)
    t = time.perf_counter(); c.draw(); d_full = time.perf_counter() - t
    img_full = np.array(c.buffer_rgba())
    lean(v)
    t = time.perf_counter(); c.draw(); d_lean = time.perf_counter() - t
    img_lean = np.array(c.buffer_rgba())
    diff = np.count_nonzero(np.any(img_full != img_lean, axis=-1))
    say(f"      next draw after full {d_full * 1e3:.1f} ms vs after lean {d_lean * 1e3:.1f} ms; pixels differing {diff}"
        f" of {img_full.shape[0] * img_full.shape[1]}")
    v._set_wcs(relim=False)
    settle(app)

say("\n[F1] fix emulated: slice-only changes take the lean path (alternating, n=9)")
for name in ("sji_step", "exposure_step", "click"):
    ab(name, ACT[name], ACT[name], setup_a=lambda: set_lean(False), setup_b=lambda: set_lean(True),
       keys=["_set_wcs sji", "_set_wcs spectrogram", "_set_wcs wavelength", "ticks"])
set_lean(False)

# ---- F2: spectrum tail and worker latency
say("\n[F2] spectrum tail after the image panels, worker runs (from the as-is rows)")
for name in ("exposure_step", "click"):
    tails, runs, sdraws, img_done, spec_done = [], [], [], [], []
    for wall, n, tt, tl in BASE[name]:
        ends = [(t, nm) for t, ev, nm in tl if ev == "end" and nm.startswith("draw ")]
        img = max(t for t, nm in ends if nm != "draw spectrum")
        sp_end = max(t for t, nm in ends if nm == "draw spectrum")
        tails.append(sp_end - img)
        img_done.append(img)
        spec_done.append(sp_end)
        runs.append(n.get("worker profile_thread", 0))
        sdraws.append(n.get("draw spectrum", 0))
    say(f"   {name:14s} images done {med(img_done):6.1f} | spectrum done {med(spec_done):6.1f} | tail median {med(tails):5.1f} ms "
        f"(range {rng(tails)}) | worker runs {runs} | spectrum draws {sdraws} | spectrum draw median "
        f"{med([r[2].get('draw spectrum', 0) / max(r[1].get('draw spectrum', 1), 1) for r in BASE[name]]):.1f} ms")

from glue.viewers.profile.layer_artist import ProfileLayerArtist  # noqa: E402

pla = next(la for la in spec.layers if getattr(la.layer, "group", None) is not None)
say(f"   point profile layer size {pla.state.layer.size:.3g} (threaded above 1e7)")
rows = []
for _ in range(15):
    wall, n, tt, tl = run(lambda: pla._calculate_profile(reset=True))
    req = [t for t, ev, nm in tl if ev == "begin" and nm == "profile_request"]
    wb = [t for t, ev, nm in tl if ev == "begin" and nm == "worker profile_thread"]
    we = [t for t, ev, nm in tl if ev == "end" and nm == "worker profile_thread"]
    pb = [t for t, ev, nm in tl if ev == "begin" and nm == "postthread"]
    rows.append((wb[0] - req[0], we[0] - wb[0], pb[0] - we[0], wall, len(wb), len(req)))
say(f"   idle recompute n=15: request->worker start median {med([r[0] for r in rows]):.1f} ms (range {rng([r[0] for r in rows])});"
    f" compute {med([r[1] for r in rows]):.2f} ms; compute end->postthread {med([r[2] for r in rows]):.1f} ms (range {rng([r[2] for r in rows])});"
    f" request->idle {med([r[3] for r in rows]):.1f} ms; worker runs {[r[4] for r in rows]}; requests {[r[5] for r in rows]}")

# who asks for the second run? record the property change that drove each request during one time step
import traceback  # noqa: E402

causes = Counter()
orig_req = type(pla)._calculate_profile


def spy(self, reset=False):
    if R.on and self is pla:
        stack = [f.name for f in traceback.extract_stack(limit=40)]
        causes["inside postthread/update_limits" if "update_limits" in stack else "other: " + "<".join(stack[-6:-1])] += 1
    return orig_req(self, reset=reset)


type(pla)._calculate_profile = spy
for _ in range(3):
    run(ACT["exposure_step"])
type(pla)._calculate_profile = orig_req
say(f"   requests per 3 time steps, from inside a postthread (v_min/v_max) = True: {dict(causes)}")


def sync_profile(on):
    if on:
        pla._calculate_profile = functools.partial(ProfileLayerArtist._calculate_profile, pla)
    else:
        pla.__dict__.pop("_calculate_profile", None)


say("   emulated zero-latency worker (profile computed synchronously on the main thread, instance override in this process only)")
for name in ("exposure_step", "click"):
    A, B = ab(name, ACT[name], ACT[name], setup_a=lambda: sync_profile(False), setup_b=lambda: sync_profile(True),
              keys=["worker profile_thread", "draw spectrum"])
sync_profile(False)

# ---- F3: hidden Point layer on the SJI
say("\n[F3] SJI Point layer hidden vs removed (alternating, n=9)")
hidden = [la for la in sj.layers if getattr(la.layer, "group", None) is not None]
say(f"   SJI subset layers {[(la.layer.label, la.state.visible) for la in hidden]}")
subset = hidden[0].layer


def hide_state(removed):
    def f():
        present = any(la.layer is subset for la in sj.layers)
        if removed and present:
            sj.remove_subset(subset)
        elif not removed and not present:
            sj.add_subset(subset)
            for la in sj.layers:
                if la.layer is subset:
                    la.state.visible = False
        settle(app)
    return f


for name in ("exposure_step", "click"):
    ab(name, ACT[name], ACT[name], setup_a=hide_state(False), setup_b=hide_state(True),
       keys=["subset_update sji", "draw sji"])
hide_state(False)()

# ---- F5: coordinator applies the point before glue's draws
say("\n[F5] coordinator _update called right after the action (alternating, n=9)")


def early(act):
    def f():
        act()
        coord._update()
        coord._timer.stop()
    return f


for name in ("click", "exposure_step"):
    ab(name, ACT[name], early(ACT[name]), keys=["coord_update", "_set_wcs sji", "_set_wcs spectrogram", "_set_wcs wavelength"])

# ---- F6: wavelength step and the coordinator's sync
say("\n[F6] wavelength step on the map")


def no_sync(act):
    def f():
        act()
        coord._timer.stop()
    return f


ab("wavelength_step", ACT["wavelength_step"], no_sync(ACT["wavelength_step"]), keys=["coord_update", "point_on", "_sji_pixels", "draw map"])
rows = []
for _ in range(15):
    rows.append(run(coord._update))
summary("coord._update alone, nothing moved (n=15)", rows, ["coord_update", "point_on", "_sji_pixels"])
from glue_solar.quicklook import _lon_lat  # noqa: E402

pt = coord.point
pixel = [s.start if s.start is not None else 0 for s in pt.slices]
lon, lat = _lon_lat(pt.reference_data, pixel)
frame = ql._sji_frame(sj.state)
ts = []
for _ in range(30):
    t = time.perf_counter()
    ql._sji_pixels(sji, frame, lon, lat)
    ts.append(time.perf_counter() - t)
say(f"   _sji_pixels alone median {med(ts):.2f} ms (n=30)")

# ---- F4: colormap combo
say("\n[F4] QColormapCombo")
from glue_qt.utils.colors import QColormapCombo, cmap2pixmap  # noqa: E402
from qtpy import QtGui  # noqa: E402

for k in ("cmap_icons", "cmap_resize", "cmap_icons in cmap_resize"):
    say(f"   during quicklook open: {k} n={open_counts[0].get(k, 0)} {open_counts[1].get(k, 0) * 1e3:.1f} ms")
ts = []
for _ in range(7):
    t = time.perf_counter()
    combo = QColormapCombo()
    ts.append(time.perf_counter() - t)
    combo.deleteLater()
say(f"   QColormapCombo() with {len(colormaps.members)} colormaps: median {med(ts):.1f} ms (n=7), width {combo.width()}")
combo = QColormapCombo()
w = combo.width()
pix = [cmap2pixmap(combo.itemData(i).data, size=(w, 15), steps=200) for i in range(combo.count())]
ts = []
for _ in range(7):
    t = time.perf_counter()
    for i, p in enumerate(pix):
        combo.setItemIcon(i, QtGui.QIcon(p))
    ts.append(time.perf_counter() - t)
say(f"   icons from cached pixmaps (setItemIcon x{len(pix)}): median {med(ts):.2f} ms (n=7)")
few = colormaps.members[:n_glue_cmaps] + [
    [lab, cm] for lab, cm in colormaps.members[n_glue_cmaps:] if str(getattr(cm, "name", lab)).lower().startswith(("irissji", "sdoaia"))]
say(f"   combo items {combo.count()}, registry members {len(colormaps.members)}, unique labels {len({lab for lab, _ in colormaps.members})}")
ts = []
for _ in range(7):
    t = time.perf_counter()
    combo.refresh_options(colormaps=few)
    ts.append(time.perf_counter() - t)
say(f"   _update_icons with {len(few)} colormaps (glue's + irissji*/sdoaia*): median {med(ts):.1f} ms (n=7)")

# add a layer: a copy of the SJI linked pixel-to-pixel
from glue.core import Data  # noqa: E402
from glue.core.link_helpers import LinkSame  # noqa: E402

copy = Data(label="SJI copy", coords=sji.coords)
copy.meta.update(sji.meta)
copy.add_component(sji.get_component(sji.main_components[0]), "SJI copy")
app.data_collection.append(copy)
app.data_collection.add_link([LinkSame(a, b) for a, b in zip(sji.pixel_component_ids, copy.pixel_component_ids)])
settle(app)
rows = []
for i in range(8):
    r = run(lambda: sj.add_data(copy))
    sj.remove_data(copy)
    settle(app)
    if i:
        rows.append(r)
summary("add a data layer to the SJI viewer", rows, ["cmap_icons", "cmap_resize", "draw sji", "_set_wcs sji"])
say(f"\nmaxrss {resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1e6:.0f} MB")
app.close()
