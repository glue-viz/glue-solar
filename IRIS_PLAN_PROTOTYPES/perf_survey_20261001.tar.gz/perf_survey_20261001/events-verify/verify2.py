"""
Independent re-measurement of the 'events' findings (measure only: nothing on disk is changed).

Light instrumentation only: a few method wrappers that count/time (no echo or hub wrappers).
Fix emulations are harness-level (public calls / instance state in this process), never file edits.

usage: python verify.py [all|click]   (GS_PATH picks the glue_solar checkout)
"""

import functools
import glob
import os
import resource
import statistics
import sys
import threading
import time
from collections import Counter, defaultdict

GS = os.environ.get("GS_PATH", "/Users/nabil/Git/glue-solar-main")
sys.path.insert(0, GS)
MODE = sys.argv[1] if len(sys.argv) > 1 else "all"
HERE = os.path.dirname(os.path.abspath(__file__))
DATA = "/Users/nabil/DATA/IRIS"
RASTER = glob.glob(f"{DATA}/*4000255147_raster/*_r00000.fits")
SJI = glob.glob(f"{DATA}/*4000255147_SJI_1400_t000.fits.gz")[0]
MAIN = threading.get_ident()
OUT = open(os.path.join(HERE, f"verify2_{MODE}_{os.path.basename(GS)}.log"), "w")


def say(*a):
    text = " ".join(str(x) for x in a)
    print(text, flush=True)
    OUT.write(text + "\n")
    OUT.flush()


class R:
    on = False
    n = Counter()
    t = defaultdict(float)
    tl = []
    t0 = 0.0
    stack = []

    @classmethod
    def reset(cls):
        cls.n, cls.t, cls.tl, cls.stack = Counter(), defaultdict(float), [], []
        cls.t0 = time.perf_counter()


CANVAS = {}


def cname(obj):
    canvas = getattr(obj, "figure", None)
    canvas = getattr(canvas, "canvas", obj)
    return CANVAS.get(id(canvas), "other")


def wrap(cls, attr, key, worker=False, per_canvas=None):
    orig = getattr(cls, attr)

    @functools.wraps(orig)
    def w(*a, **k):
        if not R.on:
            return orig(*a, **k)
        main = threading.get_ident() == MAIN
        if not main and not worker:
            return orig(*a, **k)
        name = key if main else "worker " + key
        if per_canvas and main:
            name += " " + cname(per_canvas(a[0]))
        ctx = R.stack[-1].split()[0] if (main and R.stack) else None
        if main:
            R.stack.append(name)
        R.tl.append((time.perf_counter() - R.t0, "begin", name))
        t = time.perf_counter()
        try:
            return orig(*a, **k)
        finally:
            dt = time.perf_counter() - t
            if main:
                R.stack.pop()
            R.n[name] += 1
            R.t[name] += dt
            if ctx:
                R.n[f"{key} in {ctx}"] += 1
                R.t[f"{key} in {ctx}"] += dt
            R.tl.append((time.perf_counter() - R.t0, "end", name))

    setattr(cls, attr, w)


def install():
    from astropy.visualization.wcsaxes.core import WCSAxes
    from glue.viewers.image.layer_artist import ImageSubsetLayerArtist
    from glue.viewers.image.viewer import MatplotlibImageMixin
    from glue.viewers.matplotlib.viewer import MatplotlibViewerMixin
    from glue.viewers.profile.layer_artist import ProfileLayerArtist
    from glue_qt.utils.colors import QColormapCombo
    from glue_qt.viewers.matplotlib.widget import MplCanvas
    from glue_qt.viewers.profile.layer_artist import QThreadedProfileLayerArtist

    import glue_solar.quicklook as ql

    from glue_qt.viewers.image.data_viewer import ImageViewer

    # glue-qt's ImageViewer holds its own defer_draw-decorated copies of the mixins' methods
    # (decorate_all_methods), so the wrappers go on that class
    viewer_axes = lambda v: v.axes  # noqa: E731
    wrap(ImageViewer, "_set_wcs", "_set_wcs", per_canvas=viewer_axes)
    wrap(ImageViewer, "_on_slice_change", "slicecb", per_canvas=viewer_axes)
    wrap(ImageViewer, "update_x_axislabel", "xlabelcb", per_canvas=viewer_axes)
    wrap(ImageViewer, "update_y_axislabel", "ylabelcb", per_canvas=viewer_axes)
    wrap(WCSAxes, "_update_tick_and_label_positions", "ticks")
    wrap(WCSAxes, "reset_wcs", "reset_wcs")
    wrap(MplCanvas, "draw", "draw", per_canvas=lambda c: c)
    wrap(QColormapCombo, "_update_icons", "cmap_icons")
    wrap(QColormapCombo, "resizeEvent", "cmap_resize")
    wrap(ProfileLayerArtist, "_calculate_profile_thread", "profile_thread", worker=True)
    wrap(QThreadedProfileLayerArtist, "_calculate_profile", "profile_request")
    wrap(QThreadedProfileLayerArtist, "_calculate_profile_postthread", "postthread")
    wrap(ImageSubsetLayerArtist, "update", "subset_update", per_canvas=lambda la: la.axes)
    wrap(ql.Coordinator, "_update", "coord_update")
    wrap(ql.Coordinator, "point_on", "point_on")
    orig_px = ql._sji_pixels

    def _sji_pixels(*a, **k):
        if not R.on:
            return orig_px(*a, **k)
        t = time.perf_counter()
        try:
            return orig_px(*a, **k)
        finally:
            R.n["_sji_pixels"] += 1
            R.t["_sji_pixels"] += time.perf_counter() - t

    ql._sji_pixels = _sji_pixels


def busy(app):
    from glue_qt.utils import get_qapp  # noqa: F401

    for tab in app.viewers:
        for viewer in tab:
            if getattr(viewer.figure.canvas, "_draw_pending", False):
                return True
            for layer in viewer.layers:
                if getattr(layer, "is_computing", False):
                    return True
                worker = getattr(layer, "_worker", None)
                if worker is not None and not worker.work_queue.empty():
                    return True
    coord = getattr(app.data_collection, "_solar_coordinator", None)
    return coord is not None and coord._timer.isActive()


def settle(app, timeout=20.0):
    """Process events until 0.1 s of quiet; returns the time at which the quiet began."""
    from glue_qt.utils import get_qapp

    q = get_qapp()
    t0 = time.perf_counter()
    quiet = None
    while time.perf_counter() - t0 < timeout:
        q.processEvents()
        if busy(app):
            quiet = None
        else:
            quiet = quiet or time.perf_counter()
            if time.perf_counter() - quiet > 0.1:
                return quiet - t0
        time.sleep(0.001)
    return time.perf_counter() - t0


def med(xs):
    return statistics.median(xs) * 1e3


def rng(xs):
    return f"{min(xs) * 1e3:.0f}-{max(xs) * 1e3:.0f}"


install()
from glue_solar.sources.loaders.iris import image_data, raster_data  # noqa: E402

import glue_solar  # noqa: E402

say("glue_solar from", glue_solar.__file__)
t = time.perf_counter()
[raster] = raster_data(RASTER, windows=["Si IV 1403"])
sji = image_data(SJI)
say(f"load {time.perf_counter() - t:.1f} s raster {raster.shape} sji {sji.shape}")

from glue.config import colormaps  # noqa: E402
from glue_qt.app import GlueApplication  # noqa: E402
from glue_qt.utils import get_qapp  # noqa: E402

import glue_solar.quicklook as ql  # noqa: E402

n_glue_cmaps = len(colormaps.members)
get_qapp()
app = GlueApplication()  # loads the glue_solar plugin entry point, which calls glue_solar.setup() once
say(f"colormaps: glue {n_glue_cmaps}, after GlueApplication() (plugin setup) {len(colormaps.members)}")
app.resize(1600, 1000)
app.show()
settle(app)

# ---- quicklook open
R.reset()
R.on = True
t = time.perf_counter()
V = ql.quicklook(app, [raster, sji])
t_sync = time.perf_counter() - t
t_idle = t_sync + settle(app)
R.on = False
say(f"\n[open] quicklook() call {t_sync * 1e3:.0f} ms, to idle {t_idle * 1e3:.0f} ms")
for k in sorted(R.n):
    if k.startswith(("_set_wcs", "_set_wcs in", "cmap", "ticks", "slicecb", "draw", "reset_wcs")):
        say(f"   {k:40s} n={R.n[k]:3d}  {R.t[k] * 1e3:7.1f} ms")
open_counts = (dict(R.n), dict(R.t))
t = time.perf_counter()
while time.perf_counter() - t < 1.5:
    get_qapp().processEvents()
    time.sleep(0.005)
settle(app)

mp, sp, wl, spec, sj = V["map"], V["spectrogram"], V["wavelength"], V["spectrum"], V["sji"][0]
for name, v in dict(map=mp, spectrogram=sp, wavelength=wl, spectrum=spec, sji=sj).items():
    CANVAS[id(v.figure.canvas)] = name
    c = v.figure.canvas
    say(f"   {name}: canvas {c.width()}x{c.height()} dpr {c.device_pixel_ratio} "
        f"wcs-on-slice {getattr(v, '_changing_slice_requires_wcs_update', None)} "
        f"layers {[(l.layer.label[:14], l.state.visible) for l in v.layers]}")
coord = app.data_collection._solar_coordinator

from qtpy import QtCore, QtWidgets  # noqa: E402
from qtpy.QtTest import QTest  # noqa: E402


def stepper(viewer, axis):
    k = {"n": 0}

    def act():
        # looked up per call: glue-qt rebuilds the sliders on an axis change
        qs = viewer.options_widget().slice_helper._sliders[axis].findChild(QtWidgets.QSlider, "value_slice_center")
        k["n"] += 1
        qs.triggerAction(QtWidgets.QAbstractSlider.SliderSingleStepAdd if k["n"] % 2 else
                         QtWidgets.QAbstractSlider.SliderSingleStepSub)
    return act


ny, nx = raster.shape[1], raster.shape[0]
PTS = [(nx // 2 + 40, ny // 2 + 20), (nx // 2 - 40, ny // 2 - 20)]
kc = {"n": 0}


def click():
    kc["n"] += 1
    xd, yd = PTS[kc["n"] % 2]
    canvas = mp.figure.canvas
    xs, ys = mp.axes.transData.transform((xd, yd))
    dpr = canvas.device_pixel_ratio
    pos = QtCore.QPoint(int(xs / dpr), int(canvas.height() - ys / dpr))
    QTest.mousePress(canvas, QtCore.Qt.LeftButton, QtCore.Qt.NoModifier, pos)
    QTest.mouseRelease(canvas, QtCore.Qt.LeftButton, QtCore.Qt.NoModifier, pos)


def swap():
    mp.state.x_att = mp.state.y_att


ACT = {
    "sji_step": stepper(sj, 0),
    "exposure_step": stepper(sp, 0),
    "wavelength_step": stepper(mp, 2),
    "click": click,
    "axis_swap": swap,
}


def run(act, rec=True):
    """One action: wall to idle and a copy of the counters/timeline."""
    R.reset()
    R.on = rec
    t = time.perf_counter()
    act()
    wall = time.perf_counter() - t + settle(app)
    R.on = False
    return wall, dict(R.n), dict(R.t), list(R.tl)


def per_action(rows, key):
    return statistics.median(r[1].get(key, 0) for r in rows), med([r[2].get(key, 0) for r in rows])


def summary(label, rows, keys):
    walls = [r[0] for r in rows]
    say(f"  {label:42s} wall-to-idle median {med(walls):6.1f} ms (range {rng(walls)}, n={len(rows)})")
    for key in keys:
        n, ms = per_action(rows, key)
        if n:
            say(f"      {key:40s} n={n:4.1f}  median {ms:6.1f} ms  ({100 * ms / med(walls):.0f}% of wall)")


def draws(rows):
    c = Counter()
    for r in rows:
        for k, v in r[1].items():
            if k.startswith("draw "):
                c[k[5:]] += v
    return {k: round(v / len(rows), 1) for k, v in c.items()}


def lean(v):
    """The slice-only WCS refresh the finding proposes: reset_wcs, labels on glue's coordinate, sizes."""
    s, ax = v.state, v.axes
    nd = s.reference_data.ndim
    ax.reset_wcs(slices=s.wcsaxes_slice, wcs=s.reference_data.coords)
    ax.coords[nd - 1 - s.x_att.axis].set_axislabel(s.x_axislabel, weight=s.x_axislabel_weight, size=s.x_axislabel_size)
    ax.coords[nd - 1 - s.y_att.axis].set_axislabel(s.y_axislabel, weight=s.y_axislabel_weight, size=s.y_axislabel_size)
    v._update_appearance_from_settings()
    v.update_x_ticklabel()
    v.update_y_ticklabel()


FIX = {"lean": False}
for v in (mp, sp, wl, sj):
    v.state.add_callback("slices", lambda *_, v=v: FIX["lean"] and WCS_FLAG[v] and lean(v))
WCS_FLAG = {v: v._changing_slice_requires_wcs_update for v in (mp, sp, wl, sj)}


def set_lean(on):
    FIX["lean"] = on
    for v, flag in WCS_FLAG.items():
        v._changing_slice_requires_wcs_update = (False if on and flag else flag)


def ab(label, act_a, act_b, n=9, setup_a=None, setup_b=None, keys=()):
    """Alternate A and B n times each after one warm-up of each."""
    A, B = [], []
    for i in range(n + 1):
        for setup, act, rows in ((setup_a, act_a, A), (setup_b, act_b, B)):
            if setup:
                setup()
            r = run(act)
            if i:
                rows.append(r)
    if setup_a:
        setup_a()
    summary(label + " A", A, keys)
    say(f"      draws A {draws(A)}")
    summary(label + " B", B, keys)
    say(f"      draws B {draws(B)}")
    say(f"      B - A: {med([r[0] for r in B]) - med([r[0] for r in A]):+.1f} ms")
    return A, B


if MODE == "click":
    keys = ["_set_wcs sji", "_set_wcs spectrogram", "_set_wcs wavelength", "ticks", "ylabelcb wavelength",
            "ylabelcb spectrogram", "xlabelcb sji", "coord_update"]
    run(click)
    rows = [run(click) for _ in range(9)]
    summary("click", rows, keys)
    say(f"      draws {draws(rows)}")
    say(f"      label callbacks per click: x {sum(statistics.median(r[1].get(k, 0) for r in rows) for k in rows[0][1] if k.startswith('xlabelcb '))}"
        f" y {sum(statistics.median(r[1].get(k, 0) for r in rows) for k in rows[0][1] if k.startswith('ylabelcb '))}")
    say(f"      _set_wcs total per click median {med([sum(v for k, v in r[2].items() if k.startswith('_set_wcs ')) for r in rows]):.1f} ms")
    app.close()
    sys.exit()


# ---- repeats with n=15 for the findings whose first-run differences were small against the noise
N = 15
from glue.viewers.profile.layer_artist import ProfileLayerArtist  # noqa: E402

say("\n[F1] lean path emulated, exposure step and click (alternating, n=15)")
for name in ("exposure_step", "click"):
    ab(name, ACT[name], ACT[name], n=N, setup_a=lambda: set_lean(False), setup_b=lambda: set_lean(True),
       keys=["_set_wcs spectrogram", "_set_wcs sji", "_set_wcs wavelength"])
set_lean(False)

say("\n[F3] SJI Point layer hidden vs removed (alternating, n=15)")
subset = next(la.layer for la in sj.layers if getattr(la.layer, "group", None) is not None)


def hide_state(removed):
    def f():
        present = any(la.layer is subset for la in sj.layers)
        if removed and present:
            sj.remove_subset(subset)
        elif not removed and not present:
            sj.add_subset(subset)
            for la in sj.layers:
                if la.layer is subset:
                    la.state.visible = False
        settle(app)
    return f


for name in ("exposure_step", "click"):
    ab(name, ACT[name], ACT[name], n=N, setup_a=hide_state(False), setup_b=hide_state(True), keys=["subset_update sji", "draw sji"])
hide_state(False)()

say("\n[F5] coordinator _update right after the click (alternating, n=15)")


def early(act):
    def f():
        act()
        coord._update()
        coord._timer.stop()
    return f


A, B = ab("click", ACT["click"], early(ACT["click"]), n=N, keys=["coord_update"])
for lab, rows in (("A", A), ("B", B)):
    img = []
    tails = []
    for wall, n, tt, tl in rows:
        ends = [(t, nm) for t, ev, nm in tl if ev == "end" and nm.startswith("draw ")]
        i = max(t for t, nm in ends if nm != "draw spectrum")
        img.append(i)
        tails.append(max(t for t, nm in ends if nm == "draw spectrum") - i)
    say(f"      {lab}: images done median {med(img):.1f} ms, spectrum after images {med(tails):.1f} ms; main-thread draw time "
        f"{med([sum(v for k, v in r[2].items() if k.startswith('draw ')) for r in rows]):.1f} ms")

say("\n[F2] spectrum tail, n=15 time steps")
tails, img_done = [], []
for i in range(N + 1):
    wall, n, tt, tl = run(ACT["exposure_step"])
    if not i:
        continue
    ends = [(t, nm) for t, ev, nm in tl if ev == "end" and nm.startswith("draw ")]
    im = max(t for t, nm in ends if nm != "draw spectrum")
    img_done.append(im)
    tails.append(max(t for t, nm in ends if nm == "draw spectrum") - im)
say(f"   images done median {med(img_done):.1f} ms, tail median {med(tails):.1f} ms, tails sorted {sorted(round(t * 1e3) for t in tails)}")
app.close()
