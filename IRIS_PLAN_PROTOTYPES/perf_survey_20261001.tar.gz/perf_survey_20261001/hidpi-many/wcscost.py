"""
Per-call cost of the WCS transform WCSAxes uses for the SJI / Si IV axes, and of one
_update_tick_and_label_positions; plus how many transform calls one update makes.
usage: wcscost.py sji|siiv
"""
import sys
import time

import numpy as np
from common import load_siiv, load_sji, make_app, med, settle

from astropy.visualization.wcsaxes import core as wcore
from astropy.visualization.wcsaxes import wcsapi
from glue_qt.viewers.image import ImageViewer

CALLS = []
_tr = wcsapi.WCSPixel2WorldTransform.transform


def tr(self, pixel):
    CALLS.append(len(pixel))
    return _tr(self, pixel)


wcsapi.WCSPixel2WorldTransform.transform = tr

kind = sys.argv[1]
app = make_app()
data = load_sji() if kind == "sji" else load_siiv()
app.data_collection.append(data)
v = app.new_data_viewer(ImageViewer, data=data)
v.parent().resize(800, 500)
settle()
wcs = data.coords  # glue-solar's _GlueWCS
raw = wcs._wcs
print("coords", type(wcs).__name__, "wrapping", type(raw).__name__, "pixel/world dims", wcs.pixel_n_dim, wcs.world_n_dim)
for n in (2, 1000):
    px = [np.linspace(0, s - 1, n) for s in data.shape[::-1]]
    for name, w in (("glue-solar _GlueWCS", wcs), ("irispy/gWCS raw", raw)):
        ts = []
        for _ in range(50):
            t = time.perf_counter()
            w.pixel_to_world_values(*px)
            ts.append(time.perf_counter() - t)
        print(f"  pixel_to_world_values n={n:5d} {name:20s} median {med(ts)*1e3:.3f} ms")
ax = v.axes
ts = []
for _ in range(20):
    CALLS.clear()
    t = time.perf_counter()
    ax._update_tick_and_label_positions()
    ts.append(time.perf_counter() - t)
print(f"_update_tick_and_label_positions median {med(ts)*1e3:.1f} ms; {len(CALLS)} transform calls, points per call "
      f"{sorted(set(CALLS))}; world coords on axes: {[c.coord_type for c in ax.coords]}")
