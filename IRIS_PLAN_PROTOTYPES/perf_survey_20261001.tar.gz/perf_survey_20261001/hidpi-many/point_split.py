"""
Where does a viewer's redraw go when only a Pixel point (subset) moves? One SJI viewer, full tab,
15 point moves, medians per move. Wrappers in this process only.
usage: point_split.py N   (N viewers tiled; reports totals over all viewers)
"""
import sys
import time
from collections import defaultdict

from common import DRAWS, env_line, load_sji, make_app, med, settle

from astropy.visualization.wcsaxes import core as wcore
from glue.viewers.image import composite_array as ca
from glue.viewers.image import frb_artist
from glue.viewers.image import layer_artist as la
from glue.viewers.image.pixel_selection_subset_state import PixelSubsetState
from glue_qt.viewers.image import ImageViewer

ACC = defaultdict(float)


def wrap(owner, name, label_of):
    orig = getattr(owner, name)

    def w(self, *a, **k):
        t = time.perf_counter()
        try:
            return orig(self, *a, **k)
        finally:
            ACC[label_of(self)] += time.perf_counter() - t

    setattr(owner, name, w)


wrap(wcore.WCSAxes, "_update_tick_and_label_positions", lambda s: "WCSAxes tick placement (per draw)")
wrap(frb_artist.FRBArtist, "make_image",
     lambda s: "image layer make_image" if s._array_maker.__class__ is ca.CompositeArray else "subset mask make_image")
wrap(la.ImageSubsetArray, "__call__", lambda s: "  of which subset mask FRB (get_mask)")
wrap(ca.CompositeArray, "__call__", lambda s: "  of which image FRB+colormap")

N = int(sys.argv[1])
app = make_app()
print(env_line())
sji = load_sji()
app.data_collection.append(sji)
viewers = [app.new_data_viewer(ImageViewer, data=sji) for _ in range(N)]
app.current_tab.tileSubWindows()
settle()
time.sleep(0.6)
settle()
c = viewers[0].figure.canvas
print(f"N={N} canvas {c.width()}x{c.height()}")
group = app.data_collection.new_subset_group(label="Point", subset_state=PixelSubsetState(sji, [slice(None), slice(200, 201), slice(190, 191)]))
settle()
per, walls, draws = defaultdict(list), [], []
for i in range(15):
    before = dict(ACC)
    DRAWS.clear()
    y, x = 100 + (i * 13) % 200, 100 + (i * 17) % 200
    t = time.perf_counter()
    group.subset_state = PixelSubsetState(sji, [slice(None), slice(y, y + 1), slice(x, x + 1)])
    settle()
    walls.append(time.perf_counter() - t)
    draws.append(sum(d[2] for d in DRAWS))
    for k in ACC:
        per[k].append(ACC[k] - before.get(k, 0.0))
print(f"point move: wall {med(walls)*1e3:.1f} ms, canvas draws total {med(draws)*1e3:.1f} ms")
for k in sorted(per):
    print(f"  {k:40s} {med(per[k])*1e3:7.1f} ms")
