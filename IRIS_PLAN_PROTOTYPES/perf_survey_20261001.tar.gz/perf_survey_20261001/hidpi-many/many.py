"""
N Image viewers of the same SJI 1400 cube, tiled in one tab of a 1600x1000 window.

usage: many.py N
Per N, 15 repeats each, medians:
  tick    - move viewer 0's slider: which canvases draw, wall time until drawn
  point   - move a Pixel-selection point (a subset group on the SJI, as the quicklook's point):
            every viewer recomputes and draws its subset layer
  hidden  - the same point moves while the viewers' tab is hidden behind a second tab
"""
import sys
import time
from collections import Counter

from common import DRAWS, PAINTS, env_line, load_sji, make_app, med, rss_mb, settle

from glue.viewers.image.pixel_selection_subset_state import PixelSubsetState
from glue_qt.viewers.image import ImageViewer

N = int(sys.argv[1])
app = make_app()
print(env_line())
sji = load_sji()
app.data_collection.append(sji)
viewers = [app.new_data_viewer(ImageViewer, data=sji) for _ in range(N)]
settle()
mdi = app.current_tab
mdi.tileSubWindows()
settle()
time.sleep(0.6)
settle()
ids = [id(v.figure.canvas) for v in viewers]
c0 = viewers[0].figure.canvas
print(f"N={N} canvas sizes {[(v.figure.canvas.width(), v.figure.canvas.height()) for v in viewers[:3]]}... "
      f"dpr {c0.device_pixel_ratio}")


def run(action, reps=15):
    walls, ndraws, drawsum, who = [], [], [], Counter()
    for i in range(reps):
        DRAWS.clear()
        PAINTS.clear()
        t = time.perf_counter()
        action(i)
        settle()
        walls.append(time.perf_counter() - t)
        mine = [d for d in DRAWS if d[0] in ids]
        ndraws.append(len(mine))
        drawsum.append(sum(d[2] for d in mine))
        who.update(ids.index(d[0]) for d in mine)
    return (f"wall {med(walls)*1e3:7.1f} ms  draws/rep {med(ndraws):4.1f}  draw time/rep {med(drawsum)*1e3:7.1f} ms  "
            f"paints/rep {len(PAINTS)}  viewers drawn {sorted(who)}")


def tick(i):
    sl = list(viewers[0].state.slices)
    sl[0] = (i * 37 + 5) % sji.shape[0]
    viewers[0].state.slices = tuple(sl)


group = app.data_collection.new_subset_group(label="Point", subset_state=PixelSubsetState(sji, [slice(None), slice(200, 201), slice(190, 191)]))
settle()


def point(i):
    y, x = 100 + (i * 13) % 200, 100 + (i * 17) % 200
    group.subset_state = PixelSubsetState(sji, [slice(None), slice(y, y + 1), slice(x, x + 1)])


print(f"N={N} tick   ", run(tick), flush=True)
print(f"N={N} point  ", run(point), flush=True)
for v in viewers[1:]:
    for layer in v.layers:
        if layer.layer is not sji:
            layer.state.visible = False
settle()
print(f"N={N} point, subset layer hidden in viewers 1..N-1", run(point), flush=True)
for v in viewers[1:]:
    for layer in v.layers:
        layer.state.visible = True
settle()
app.new_tab()
app.tab_widget.setCurrentIndex(1)
settle()
print(f"hidden tab: viewer 0 visible? {viewers[0].isVisible()} canvas visible? {c0.isVisible()}")
print(f"N={N} hidden point", run(point), flush=True)
print(f"N={N} hidden tick ", run(tick), flush=True)
print(f"rss peak {rss_mb():.0f}MB")
