"""Candidate B of labelfix.py as an importable function (labels straight onto the WCSAxes coordinates)."""
from echo import ignore_callback
from glue.core.coordinate_helpers import dependent_axes


def set_wcs(self, before=None, after=None, relim=True, mode="A"):
    """glue 1.27.0 MatplotlibImageMixin._set_wcs with the label steps changed (see module doc)."""
    if self.state.x_att is None or self.state.y_att is None or self.state.reference_data is None:
        return
    if after is not None and before is after:
        return
    ref_coords = self.state.reference_data.coords
    self.axes.reset_wcs(slices=self.state.wcsaxes_slice, wcs=ref_coords)
    with ignore_callback(self.state, "x_axislabel", "y_axislabel"):
        self.state.x_axislabel = self.state.x_att_world.label
        self.state.y_axislabel = self.state.y_att_world.label
    if mode == "A":
        self.update_x_axislabel()
        self.update_y_axislabel()
    else:
        ndim = self.state.reference_data.ndim
        for att, prop in ((self.state.x_att, "x"), (self.state.y_att, "y")):
            self.axes.coords[ndim - att.axis - 1].set_axislabel(
                getattr(self.state, f"{prop}_axislabel"),
                weight=getattr(self.state, f"{prop}_axislabel_weight"),
                size=getattr(self.state, f"{prop}_axislabel_size"),
            )
    self._update_appearance_from_settings()
    self.update_x_ticklabel()
    self.update_y_ticklabel()
    if relim:
        self.state.reset_limits()
    ix, iy = self.state.x_att.axis, self.state.y_att.axis
    dep = (set(dependent_axes(ref_coords, ix)) | set(dependent_axes(ref_coords, iy))) - {ix, iy}
    self._changing_slice_requires_wcs_update = bool(dep)
    self._wcs_set = True
