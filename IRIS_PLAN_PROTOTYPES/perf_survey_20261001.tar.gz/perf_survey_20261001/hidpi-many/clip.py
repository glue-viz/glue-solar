"""
Is Agg's draw_image slow because glue clips the image to the axes patch path (frb_artist.py:72-74)?
Static redraws with the default clip path vs clip box only (runtime toggle in this process).

usage: clip.py sji|siiv   (DPR from QT_SCALE_FACTOR)
"""
import sys
from matplotlib.backends import backend_agg  # noqa
import time

from common import env_line, load_siiv, load_sji, make_app, med, settle

from glue_qt.viewers.image import ImageViewer
from matplotlib.backends import backend_agg

T = []
_di = None


def _timed_di(*a, **k):
    t = time.perf_counter()
    try:
        return _di(*a, **k)
    finally:
        T.append(time.perf_counter() - t)



kind = sys.argv[1]
app = make_app()
print(env_line())
data = load_sji() if kind == "sji" else load_siiv()
app.data_collection.append(data)
v = app.new_data_viewer(ImageViewer, data=data)
settle()
c = v.figure.canvas
im = v.axes._composite_image
clip_path = im.get_clip_path()
print("image clip path:", type(clip_path).__name__, "clip box:", im.get_clip_box())

def make_image_split(n=10):
    r = c.get_renderer()
    mk, dr = [], []
    for _ in range(n):
        im.stale = True
        t = time.perf_counter()
        out = im.make_image(r, r.get_image_magnification())
        mk.append(time.perf_counter() - t)
        gc = r.new_gc()
        im._set_gc_clip(gc)
        t = time.perf_counter()
        _di(gc, *out[1:3], out[0])
        dr.append(time.perf_counter() - t)
        gc.restore()
    return med(mk) * 1e3, med(dr) * 1e3, out[0].shape


for w, h in [(800, 500), (1580, 900)]:
    v.parent().resize(w, h)
    settle()
    time.sleep(0.6)
    settle()
    r = c.get_renderer()
    _di = r._renderer.draw_image  # RendererAgg proxies draw_image as an instance attribute
    r.draw_image = _timed_di
    for name in ("clip to axes patch (glue default)", "clip box only"):
        im.set_clip_path(clip_path if name.startswith("clip to") else None)
        if name == "clip box only":
            im.set_clip_box(v.axes.bbox)
        draws = []
        T.clear()
        for _ in range(15):
            t = time.perf_counter()
            c.draw()
            draws.append(time.perf_counter() - t)
        print(f"{kind} {r.width}x{r.height} px dpr {c.device_pixel_ratio}: {name:36s} draw {med(draws)*1e3:6.1f} ms, "
              f"Agg draw_image {med(T)*1e3:6.1f} ms", flush=True)
    im.set_clip_path(clip_path)
    mk, dr, shp = make_image_split()
    print(f"   direct: make_image {mk:.1f} ms (output {shp}), Agg draw_image with clip path {dr:.1f} ms")
