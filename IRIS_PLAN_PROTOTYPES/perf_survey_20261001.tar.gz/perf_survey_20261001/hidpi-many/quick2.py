"""
Two glue-solar quicklooks (two observations, two tabs). With tab B shown, move B's point (as a
Pixel click does) and B's raster slider; count draws on the hidden tab A's canvases.
Obs A: 4000255147 Si IV 1403 sit-and-stare + SJI 1400. Obs B: 4000005156 Si IV 1403 scan r00000 +
SJI 2796 deconvolved. 15 repeats, medians.
"""
import glob
import time
from collections import Counter

from common import DATA, DRAWS, PAINTS, env_line, load_siiv, load_sji, make_app, med, rss_mb, settle

from glue.viewers.image.pixel_selection_subset_state import PixelSubsetState
from glue_solar.quicklook import coordinator, quicklook
from glue_solar.sources.loaders.iris import image_data, raster_data

app = make_app()
print(env_line())
rA, sA = load_siiv(), load_sji()
vA = quicklook(app, [rA, sA], window="Si IV 1403")
settle()
rB = raster_data(sorted(glob.glob(f"{DATA}/*4000005156_raster/*_r00000.fits")), windows=["Si IV 1403"])
rB = rB[0] if isinstance(rB, list) else rB
sB = image_data(glob.glob(f"{DATA}/*4000005156_SJI_2796_t000_deconvolved.fits.gz")[0])
sB = sB[0] if isinstance(sB, list) else sB
print("B shapes", rB.shape, sB.shape, f"rss {rss_mb():.0f}MB")
vB = quicklook(app, [rB, sB], window="Si IV 1403")
settle()
time.sleep(0.6)
settle()


def canvases(vs):
    out = {}
    for role, v in vs.items():
        for i, x in enumerate(v if isinstance(v, list) else [v]):
            out[id(x.figure.canvas)] = f"{role}{i if isinstance(v, list) else ''}"
    return out


cA, cB = canvases(vA), canvases(vB)
print("tab A viewers", sorted(cA.values()), "visible:", [x.isVisible() for x in [vA["map"]]], "| tab B viewers",
      sorted(cB.values()), "visible:", vB["map"].isVisible())
print("app visible", app.isVisible(), "current tab", app.tab_widget.currentIndex(), "of", app.tab_count,
      "B canvas visible", vB["map"].figure.canvas.isVisible(), "A canvas visible", vA["map"].figure.canvas.isVisible(),
      "B subwindow visible", vB["map"].parent().isVisible())
group = coordinator(app.data_collection).group
print("followed group", group.label, "point on", group.subset_state.reference_data.label, group.subset_state.slices)


def run(name, action, reps=15):
    walls, nA, nB, tA, tB, who = [], [], [], [], [], Counter()
    for i in range(reps):
        DRAWS.clear()
        PAINTS.clear()
        t = time.perf_counter()
        action(i)
        settle()
        walls.append(time.perf_counter() - t)
        a = [d for d in DRAWS if d[0] in cA]
        b = [d for d in DRAWS if d[0] in cB]
        nA.append(len(a)); nB.append(len(b))
        tA.append(sum(d[2] for d in a)); tB.append(sum(d[2] for d in b))
        who.update(cA[d[0]] for d in a)
    print(f"{name:28s} wall {med(walls)*1e3:7.1f} ms | shown tab B: {med(nB):.0f} draws {med(tB)*1e3:6.1f} ms | "
          f"hidden tab A: {med(nA):.0f} draws {med(tA)*1e3:6.1f} ms {dict(who)} | paints in last rep: B {sum(1 for p in PAINTS if p[0] in cB)} A {sum(1 for p in PAINTS if p[0] in cA)}", flush=True)


def move_point(i):
    p = group.subset_state
    sl = list(p.slices)
    y = 200 + (i * 13) % 300
    sl[1] = slice(y, y + 1)  # along the slit
    group.subset_state = PixelSubsetState(p.reference_data, sl)


def move_slider(i):
    v = vB["spectrogram"]
    sl = list(v.state.slices)
    sl[0] = (i * 7 + 3) % rB.shape[0]
    v.state.slices = tuple(sl)


run("B point move (Pixel click)", move_point)
run("B spectrogram slider tick", move_slider)
print(f"rss peak {rss_mb():.0f}MB")
