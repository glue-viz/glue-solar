"""
Simulated slider drag on one Image viewer's slice slider (glue-qt's QSlider 'value_slice_center').

usage: drag.py sji|siiv uncompressed|compressed glueqt|throttled|coalesce
The drag runs 2 s at 60 Hz (120 positions, 2 values apart for the SJI, 4 for Si IV), then releases.
Positions are due at fixed wall times and queue while the app is busy, as real input does:
  uncompressed - every due position is posted as its own event (Wayland/macOS-like delivery)
  compressed   - only the latest due position is posted (X11-like motion compression)
Each position is applied as QSlider does during a drag: setSliderDown(True), setSliderPosition(v).
glueqt: glue-qt's own slider (tracking on: every position is applied). glue-solar's FrameTimeTool
throttle (b34c35d, in 2fdb847) is undone in this process for this mode.
throttled: glue-solar's throttle (tracking off; the dragged position applied at most every 100 ms).
coalesce: candidate (not in any repo): tracking off, and a 0 ms single-shot timer applies the latest
dragged position once pending input is handled, so ticks run back to back with no fixed wait.
"""
import os
import sys
import time

from common import DRAWS, env_line, load_siiv, load_sji, make_app, med, settle

from qtpy import QtCore, QtWidgets
from glue_qt.viewers.image import ImageViewer

kind, mode, slider_mode = sys.argv[1], sys.argv[2], sys.argv[3]
app = make_app()
print(env_line())
data = load_sji() if kind == "sji" else load_siiv()
app.data_collection.append(data)
v = app.new_data_viewer(ImageViewer, data=data)
v.parent().resize(800, 500)
settle()
time.sleep(0.6)
settle()
axis = next(i for i in range(data.ndim) if i not in (v.state.x_att.axis, v.state.y_att.axis))
if os.environ.get("LABELFIX"):  # candidate B from labelfix.py: no tick re-placement in the setter
    import types

    from labelfix_fn import set_wcs

    v._set_wcs = types.MethodType(lambda self, *a, **k: set_wcs(self, *a, mode="B", **k), v)
[slider] = v.options_widget().findChildren(QtWidgets.QSlider, "value_slice_center")
if slider_mode == "glueqt":
    slider.setTracking(True)
    slider.sliderMoved.disconnect()  # glue-qt itself connects only valueChanged
elif slider_mode == "coalesce":
    slider.sliderMoved.disconnect()
    coalesce = QtCore.QTimer(slider)
    coalesce.setSingleShot(True)
    coalesce.setInterval(0)
    coalesce.timeout.connect(lambda: slider.setValue(slider.sliderPosition()))
    slider.sliderMoved.connect(lambda _p: coalesce.isActive() or coalesce.start())
print(f"slider tracking {slider.hasTracking()} range {slider.minimum()}-{slider.maximum()}")

RATE, DUR, STEP = 60, 2.0, (2 if kind == "sji" else 4)
applied = []  # (time, value) whenever the viewer's slice changes
shown = []  # (draw end time, value drawn)
v.state.add_callback("slices", lambda s: applied.append((time.perf_counter(), s[axis])))
v.figure.canvas.mpl_connect("draw_event", lambda e: shown.append((time.perf_counter(), v.state.slices[axis])))
EV = QtCore.QEvent.Type(QtCore.QEvent.registerEventType())


class Move(QtCore.QEvent):
    def __init__(self, value):
        super().__init__(EV)
        self.value = value


class Driver(QtCore.QObject):
    def event(self, e):
        global released
        if e.type() == EV:
            if e.value is None:
                released = time.perf_counter()
                slider.setSliderDown(False)  # release: an untracked slider applies its position now
            else:
                slider.setSliderPosition(e.value)
            return True
        return super().event(e)


driver = Driver()
n = int(RATE * DUR)
due = [(k / RATE, (k + 1) * STEP) for k in range(n)]  # (seconds after start, value)
posted = 0
start = None
released = None


def pump():
    global posted
    now = time.perf_counter() - start
    ready = [i for i in range(posted, n) if due[i][0] <= now]
    if ready:
        batch = ready if mode == "uncompressed" else ready[-1:]
        for i in batch:
            QtCore.QCoreApplication.postEvent(driver, Move(due[i][1]))
        posted = ready[-1] + 1
    if posted >= n and now >= DUR:
        QtCore.QCoreApplication.postEvent(driver, Move(None))  # the release queues behind the moves
        timer.stop()


DRAWS.clear()
slider.setSliderDown(True)
timer = QtCore.QTimer()
timer.setInterval(1)
timer.timeout.connect(pump)
start = time.perf_counter()
timer.start()
while released is None:
    app_ = QtWidgets.QApplication.instance()
    app_.processEvents(QtCore.QEventLoop.AllEvents, 5)
settle()
end = time.perf_counter()
final = v.state.slices[axis]
drag_draws = [s for s in shown if s[0] <= released]
# display lag: how long ago the drawn value's position was due
lag = [t - (start + due[min(n - 1, max(0, val // STEP - 1))][0]) for t, val in shown]
print(f"{kind} {mode:12s} {slider_mode:9s}{'+labelfixB' if os.environ.get('LABELFIX') else ''}: "
      f"{n} positions in {DUR:.0f} s; values applied {len(applied)}; draws {len(shown)} "
      f"({len(drag_draws) / (released - start):.1f}/s until release at {released - start:.2f} s); median draw {med([d[2] for d in DRAWS])*1e3:.0f} ms; "
      f"release→settled {(end - released)*1e3:.0f} ms; drag start→settled {(end - start):.2f} s; "
      f"display lag median {med(lag)*1e3:.0f} ms max {max(lag)*1e3:.0f} ms; final value {final} (target {due[-1][1]})",
      flush=True)
