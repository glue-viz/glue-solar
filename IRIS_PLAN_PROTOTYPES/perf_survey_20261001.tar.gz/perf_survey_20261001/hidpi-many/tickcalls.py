"""
Attribute the WCS transform calls (and their time) of one WCSAxes._update_tick_and_label_positions
to its steps: frame update, coordinate range, and each coordinate helper's _update_ticks.
usage: tickcalls.py sji|siiv
"""
import sys
import time
from collections import defaultdict

from common import load_siiv, load_sji, make_app, med, settle

from astropy.visualization.wcsaxes import coordinate_helpers as ch
from astropy.visualization.wcsaxes import coordinates_map as cm
from astropy.visualization.wcsaxes import wcsapi
from glue_qt.viewers.image import ImageViewer

STEP = ["other"]
N, T = defaultdict(int), defaultdict(float)
_tr = wcsapi.WCSPixel2WorldTransform.transform


def tr(self, pixel):
    t = time.perf_counter()
    try:
        return _tr(self, pixel)
    finally:
        N[STEP[0]] += 1
        T[STEP[0]] += time.perf_counter() - t


wcsapi.WCSPixel2WorldTransform.transform = tr


def step(owner, name, label):
    orig = getattr(owner, name)

    def w(self, *a, **k):
        prev = STEP[0]
        STEP[0] = label(self)
        try:
            return orig(self, *a, **k)
        finally:
            STEP[0] = prev

    setattr(owner, name, w)


step(cm.CoordinatesMap, "get_coord_range", lambda s: "get_coord_range")
step(ch.CoordinateHelper, "_update_ticks", lambda s: f"_update_ticks[{s.coord_index}:{s.coord_type}]")

kind = sys.argv[1]
app = make_app()
data = load_sji() if kind == "sji" else load_siiv()
app.data_collection.append(data)
v = app.new_data_viewer(ImageViewer, data=data)
v.parent().resize(800, 500)
settle()
tot = []
for _ in range(10):
    N.clear(), T.clear()
    t = time.perf_counter()
    v.axes._update_tick_and_label_positions()
    tot.append(time.perf_counter() - t)
print(f"{kind}: one update {med(tot)*1e3:.1f} ms; transform calls by step (last of 10):")
for k in sorted(N):
    print(f"  {k:40s} {N[k]:3d} calls {T[k]*1e3:6.1f} ms")
print(f"  total {sum(N.values())} calls {sum(T.values())*1e3:.1f} ms")
