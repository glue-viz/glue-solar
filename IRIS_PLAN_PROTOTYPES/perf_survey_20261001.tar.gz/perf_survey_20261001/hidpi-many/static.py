"""
Static redraws (canvas.draw() with nothing changed) of one Image viewer: ticks/labels vs image.

usage: static.py sji|siiv   (DPR from QT_SCALE_FACTOR)
Conditions: full; no ticks/labels; no image; neither. 15 draws each, median.
Then one cProfile of 10 full draws at the largest size, image internals only.
"""
import cProfile
import pstats
import sys
import time

from common import env_line, load_siiv, load_sji, make_app, med, settle

from glue_qt.viewers.image import ImageViewer

kind = sys.argv[1]
app = make_app()
print(env_line())
data = load_sji() if kind == "sji" else load_siiv()
app.data_collection.append(data)
v = app.new_data_viewer(ImageViewer, data=data)
settle()
c = v.figure.canvas
layer = v.layers[0]


def ticks(on):
    for coord in v.axes.coords:
        coord.set_ticklabel_visible(on)
        coord.set_ticks_visible(on)
        coord.set_axislabel_visibility_rule("always" if on else "ticks")


def timed(n=15):
    out = []
    for _ in range(n):
        t = time.perf_counter()
        c.draw()
        out.append(time.perf_counter() - t)
    return med(out) * 1e3


for w, h in [(520, 420), (800, 500), (1580, 900)]:
    v.parent().resize(w, h)
    settle()
    time.sleep(0.6)
    settle()
    r = c.get_renderer()
    res = {}
    for name, tk, img in [("full", True, True), ("no ticks/labels", False, True), ("no image", True, False), ("neither", False, False)]:
        ticks(tk)
        layer.state.visible = img
        settle()
        res[name] = timed()
    ticks(True)
    layer.state.visible = True
    settle()
    print(f"{kind} canvas {c.width()}x{c.height()} logical {r.width}x{r.height} px dpr {c.device_pixel_ratio}: " +
          "  ".join(f"{k} {v_:.1f} ms" for k, v_ in res.items()), flush=True)

p = cProfile.Profile()
p.enable()
for _ in range(10):
    c.draw()
p.disable()
st = pstats.Stats(p)
st.sort_stats("tottime").print_stats(18)
