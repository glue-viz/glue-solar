"""
Prototype check (synthetic 100x400x400 cube, no IRIS data) of two candidate fixes, as runtime
overrides in this process only:
  canvas - glue-qt MplCanvas skips the Agg draw while the canvas is not visible and draws once
           when it is shown again
  subset - ImageSubsetLayerArtist.update only drops its caches while its layer is hidden
Counts draws per Pixel-point move for 5 viewers: (a) tab hidden, (b) subset hidden in 4 viewers.
"""
import time

import numpy as np
from common import DRAWS, make_app, med, settle

from glue.core import Data
from glue.core.fixed_resolution_buffer import ARRAY_CACHE, PIXEL_CACHE
from glue.viewers.image.layer_artist import ImageSubsetLayerArtist
from glue.viewers.image.pixel_selection_subset_state import PixelSubsetState
from glue_qt.viewers.image import ImageViewer
from glue_qt.viewers.matplotlib.widget import MplCanvas

FIX = set()
_draw_idle, _show = MplCanvas._draw_idle, MplCanvas.showEvent


def draw_idle(self):
    if "canvas" in FIX and not self.isVisible():
        self._dirty_while_hidden = self._dirty_while_hidden or getattr(self, "_draw_pending", False)
        self._draw_pending = False
        return
    return _draw_idle(self)


def show(self, event):
    _show(self, event)
    if getattr(self, "_dirty_while_hidden", False):
        self._dirty_while_hidden = False
        self.draw_idle()


MplCanvas._draw_idle, MplCanvas.showEvent, MplCanvas._dirty_while_hidden = draw_idle, show, False
_update = ImageSubsetLayerArtist.update


def update(self, *event):
    if "subset" in FIX and not self.state.visible:
        ARRAY_CACHE.pop(self.state.uuid, None)
        PIXEL_CACHE.pop(self.state.uuid, None)
        self._stale_while_hidden = True  # a real fix redoes _update_data when shown again
        return
    return _update(self, *event)


ImageSubsetLayerArtist.update = update

app = make_app()
data = Data(x=np.random.default_rng(0).random((100, 400, 400), dtype=np.float32), label="cube")
app.data_collection.append(data)
viewers = [app.new_data_viewer(ImageViewer, data=data) for _ in range(5)]
app.current_tab.tileSubWindows()
settle()
ids = {id(v.figure.canvas) for v in viewers}
group = app.data_collection.new_subset_group(label="Point", subset_state=PixelSubsetState(data, [slice(None), slice(200, 201), slice(190, 191)]))
settle()


def moves(label, reps=15):
    walls, n = [], []
    for i in range(reps):
        DRAWS.clear()
        y, x = 100 + (i * 13) % 200, 100 + (i * 17) % 200
        t = time.perf_counter()
        group.subset_state = PixelSubsetState(data, [slice(None), slice(y, y + 1), slice(x, x + 1)])
        settle()
        walls.append(time.perf_counter() - t)
        n.append(sum(1 for d in DRAWS if d[0] in ids))
    print(f"{label:58s} draws/move {med(n):.0f}  wall {med(walls)*1e3:6.1f} ms", flush=True)


for fixes in ((), ("subset",)):
    FIX.clear(); FIX.update(fixes)
    for v in viewers[1:]:
        for layer in v.layers:
            if layer.layer is not data:
                layer.state.visible = False
    settle()
    moves(f"subset hidden in 4 of 5 viewers, fix={fixes or 'none'}")
    for v in viewers[1:]:
        for layer in v.layers:
            layer.state.visible = True
    settle()

app.new_tab()
app.tab_widget.setCurrentIndex(1)
settle()
for fixes in ((), ("canvas",)):
    FIX.clear(); FIX.update(fixes)
    moves(f"5 viewers in a hidden tab, fix={fixes or 'none'}")
DRAWS.clear()
app.tab_widget.setCurrentIndex(0)
settle()
print(f"tab shown again with fix=canvas: {sum(1 for d in DRAWS if d[0] in ids)} draws (one per dirty canvas expected)")
