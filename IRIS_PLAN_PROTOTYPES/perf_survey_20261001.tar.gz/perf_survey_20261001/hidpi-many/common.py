"""Shared setup for the hidpi-many draw measurements (measure only; nothing on disk is patched)."""
import glob
import os
import resource
import statistics
import sys
import time

GS = os.environ.get("GS_PATH", "/Users/nabil/Git/glue-solar-main")
sys.path.insert(0, GS)
import glue_solar  # noqa: E402

print("glue_solar from", glue_solar.__file__, flush=True)

from glue_qt.viewers.matplotlib.widget import MplCanvas  # noqa: E402
from qtpy import QtCore, QtWidgets  # noqa: E402

DATA = "/Users/nabil/DATA/IRIS"
SJI1400 = glob.glob(f"{DATA}/*4000255147_SJI_1400_t000.fits.gz")[0]
RASTER = sorted(glob.glob(f"{DATA}/*4000255147_raster/*_r00000.fits"))

# --- draw accounting: wrap the canvas draw/paint in this process only ---
DRAWS = []  # (canvas id, start, duration)
PAINTS = []
_draw, _paint = MplCanvas.draw, MplCanvas.paintEvent


def _timed_draw(self, *a, **k):
    t = time.perf_counter()
    try:
        return _draw(self, *a, **k)
    finally:
        DRAWS.append((id(self), t, time.perf_counter() - t))


def _timed_paint(self, event):
    t = time.perf_counter()
    try:
        return _paint(self, event)
    finally:
        PAINTS.append((id(self), t, time.perf_counter() - t))


MplCanvas.draw, MplCanvas.paintEvent = _timed_draw, _timed_paint


def rss_mb():
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1e6  # bytes on macOS


def qapp():
    return QtWidgets.QApplication.instance()


def settle(rounds=3, timeout=30):
    """Process events until no canvas draws for ``rounds`` passes in a row."""
    app, quiet, t0 = qapp(), 0, time.perf_counter()
    while quiet < rounds and time.perf_counter() - t0 < timeout:
        n = len(DRAWS)
        app.processEvents(QtCore.QEventLoop.AllEvents, 5)
        pending = any(getattr(c, "_draw_pending", False) for c in app.allWidgets() if isinstance(c, MplCanvas))
        quiet = quiet + 1 if (len(DRAWS) == n and not pending) else 0


def med(xs):
    return statistics.median(xs) if xs else float("nan")


def make_app():
    from glue_qt.app import GlueApplication

    app = GlueApplication()
    app.resize(1600, 1000)
    app.show()
    settle()
    return app


def load_sji():
    from glue_solar.sources.loaders.iris import image_data

    t = time.perf_counter()
    data = image_data(SJI1400)
    data = data[0] if isinstance(data, list) else data
    print(f"SJI load {time.perf_counter() - t:.1f}s shape {data.shape} rss {rss_mb():.0f}MB", flush=True)
    return data


def load_siiv(window="Si IV 1403"):
    from glue_solar.sources.loaders.iris import raster_data

    t = time.perf_counter()
    data = raster_data(RASTER, windows=[window])
    data = data[0] if isinstance(data, list) else data
    print(f"{window} load {time.perf_counter() - t:.1f}s shape {data.shape} rss {rss_mb():.0f}MB", flush=True)
    return data


def env_line():
    import glue
    import importlib.metadata as m
    import matplotlib

    app = qapp()
    s = app.primaryScreen() if app else None
    return (
        f"glue {glue.__version__} glue-qt {m.version('glue-qt')} mpl {matplotlib.__version__} "
        f"qpa {app.platformName() if app else '?'} screen dpr {s.devicePixelRatio() if s else '?'} "
        f"logicalDPI {s.logicalDotsPerInch() if s else '?'}"
    )
