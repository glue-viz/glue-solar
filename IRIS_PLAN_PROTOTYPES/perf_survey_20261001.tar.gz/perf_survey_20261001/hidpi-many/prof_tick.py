"""cProfile of slider ticks on one Image viewer: setter (sync) and the following draw, separately.

usage: prof_tick.py sji|siiv [W H]
"""
import cProfile
import pstats
import sys
import time

from common import load_siiv, load_sji, make_app, settle

from glue_qt.viewers.image import ImageViewer

kind = sys.argv[1]
W, H = (int(sys.argv[2]), int(sys.argv[3])) if len(sys.argv) > 3 else (800, 500)
app = make_app()
data = load_sji() if kind == "sji" else load_siiv()
app.data_collection.append(data)
v = app.new_data_viewer(ImageViewer, data=data)
v.parent().resize(W, H)
settle()
time.sleep(0.6)
settle()
axis = next(i for i in range(data.ndim) if i not in (v.state.x_att.axis, v.state.y_att.axis))
ps, pd = cProfile.Profile(), cProfile.Profile()
N = 20
for i in range(N):
    sl = list(v.state.slices)
    sl[axis] = (i * 37 + 5) % data.shape[axis]
    ps.enable()
    v.state.slices = tuple(sl)
    ps.disable()
    pd.enable()
    settle()
    pd.disable()
for name, p in (("SETTER", ps), ("EVENTS+DRAW", pd)):
    print(f"\n######## {name} ({N} ticks) cumulative")
    st = pstats.Stats(p)
    st.sort_stats("cumulative").print_stats(45)
    st.dump_stats(f"hidpi-many/prof_{kind}_{name.split('+')[0].lower()}.pstats")
    print(f"\n######## {name} callers of _update_tick_and_label_positions")
    st.print_callers("_update_tick_and_label_positions")
