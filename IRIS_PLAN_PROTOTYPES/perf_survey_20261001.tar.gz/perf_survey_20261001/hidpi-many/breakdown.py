"""
Per-tick cost breakdown of one Image viewer at several canvas sizes (DPR from QT_SCALE_FACTOR).

usage: breakdown.py sji|siiv
A tick = set state.slices on the slider axis, then process events until drawn.
Wrappers (this process only) time the named functions; nested labels overlap by design.
"""
import sys
import time
from collections import defaultdict

from common import DRAWS, PAINTS, env_line, load_siiv, load_sji, make_app, med, rss_mb, settle

import matplotlib.image as mimage
import matplotlib.text as mtext
from astropy.visualization.wcsaxes import coordinate_helpers as ch
from astropy.visualization.wcsaxes import core as wcore
from glue.core import fixed_resolution_buffer as frb
from glue.viewers.image import composite_array as ca
from glue.viewers.image import frb_artist
from glue.viewers.image import viewer as gviewer
from glue_qt.viewers.image import ImageViewer

ACC = defaultdict(float)


def wrap(owner, name, label):
    orig = getattr(owner, name)

    def w(*a, **k):
        t = time.perf_counter()
        try:
            return orig(*a, **k)
        finally:
            ACC[label] += time.perf_counter() - t

    setattr(owner, name, w)


wrap(gviewer.MatplotlibImageMixin, "_set_wcs", "sync: glue _set_wcs")
wrap(wcore.WCSAxes, "reset_wcs", "sync: astropy reset_wcs")
wrap(frb_artist.FRBArtist, "make_image", "draw: image total (FRB+cmap+resample)")
wrap(ca.CompositeArray, "__call__", "draw: image composite (FRB+cmap)")
_cfrb = frb.compute_fixed_resolution_buffer  # Data.compute_fixed_resolution_buffer imports it per call


def _timed_cfrb(*a, **k):
    t = time.perf_counter()
    try:
        return _cfrb(*a, **k)
    finally:
        ACC["draw: image FRB fetch"] += time.perf_counter() - t


frb.compute_fixed_resolution_buffer = _timed_cfrb
_resample = mimage._resample


def _timed_resample(*a, **k):
    t = time.perf_counter()
    try:
        return _resample(*a, **k)
    finally:
        ACC["draw: mpl image resample"] += time.perf_counter() - t


mimage._resample = _timed_resample
wrap(wcore.WCSAxes, "draw_wcsaxes", "draw: WCSAxes ticks/labels/grid total")
wrap(wcore.WCSAxes, "_update_tick_and_label_positions", "draw: WCSAxes tick positions")
wrap(ch.CoordinateHelper, "_draw_ticks", "draw: WCSAxes ticks+ticklabels")
wrap(ch.CoordinateHelper, "_draw_axislabels", "draw: WCSAxes axis labels")
wrap(ch.CoordinateHelper, "_draw_grid", "draw: WCSAxes grid")
wrap(mtext.Text, "draw", "draw: mpl Text.draw (all)")
wrap(wcore.WCSAxes, "draw", "draw: WCSAxes.draw (axes)")

kind = sys.argv[1]
app = make_app()
print(env_line())
data = load_sji() if kind == "sji" else load_siiv()
app.data_collection.append(data)
v = app.new_data_viewer(ImageViewer, data=data)
settle()
axis = next(i for i in range(data.ndim) if i not in (v.state.x_att.axis, v.state.y_att.axis))
print("x", v.state.x_att, "y", v.state.y_att, "slider axis", axis, "n", data.shape[axis],
      "slice needs wcs update:", v._changing_slice_requires_wcs_update)
c = v.figure.canvas
N = 25
SIZES = [(520, 420), (800, 500), (1580, 900)]
for text in (True, False):
    for w, h in SIZES:
        v.parent().resize(w, h)
        settle()
        time.sleep(0.6)  # past mpl_scatter_density's 500 ms resize timer
        settle()
        for coord in v.axes.coords:
            coord.set_ticklabel_visible(text)
            coord.set_axislabel_visibility_rule("always" if text else "ticks")
            coord.set_ticks_visible(text)
        if not text:
            v.axes.coords[0].set_axislabel("")
            v.axes.coords[1].set_axislabel("")
        settle()
        ACC.clear()
        DRAWS.clear()
        PAINTS.clear()
        walls, syncs, per = [], [], defaultdict(list)
        for i in range(N):
            before = dict(ACC)
            sl = list(v.state.slices)
            sl[axis] = (i * 37 + 5) % data.shape[axis]
            t = time.perf_counter()
            v.state.slices = tuple(sl)
            syncs.append(time.perf_counter() - t)
            settle()
            walls.append(time.perf_counter() - t)
            for k in ACC:
                per[k].append(ACC[k] - before.get(k, 0.0))
        cid = id(c)
        draws = [d[2] for d in DRAWS if d[0] == cid]
        paints = [p[2] for p in PAINTS if p[0] == cid]
        r = c.get_renderer()
        print(f"\n== {kind} text={'on' if text else 'off'} canvas {c.width()}x{c.height()} logical, "
              f"{r.width}x{r.height} device px (dpr {c.device_pixel_ratio}); {N} ticks")
        print(f"  tick wall      median {med(walls)*1e3:7.1f} ms")
        print(f"  setter (sync)  median {med(syncs)*1e3:7.1f} ms")
        print(f"  canvas.draw    median {med(draws)*1e3:7.1f} ms  (n={len(draws)})")
        print(f"  Qt paintEvent  median {med(paints)*1e3:7.2f} ms  (n={len(paints)})")
        for k in sorted(per):
            print(f"  {k:45s} median {med(per[k])*1e3:7.2f} ms")
print(f"\nrss peak {rss_mb():.0f}MB")
