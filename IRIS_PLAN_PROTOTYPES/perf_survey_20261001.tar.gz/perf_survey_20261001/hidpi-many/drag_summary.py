"""Medians over the repeated drag runs in drag_repeats.log."""
import re
import statistics
from collections import defaultdict

rows = defaultdict(list)
for line in open("hidpi-many/drag_repeats.log"):
    m = re.match(r"(\w+) (\w+)\s+(\w+)\s*:", line)
    if not m:
        continue
    num = lambda pat: float(re.search(pat, line).group(1))  # noqa: E731
    rows[m.groups()].append((num(r"values applied (\d+)"), num(r"draws \d+ \(([\d.]+)/s"), num(r"release at ([\d.]+) s"),
                             num(r"start→settled ([\d.]+) s"), num(r"lag median (\d+)"), num(r"max (\d+) ms; final")))
print("data mode slider: n | values applied | draws/s during drag | release at s | start→settled s | lag median ms | lag max ms")
for key, vals in sorted(rows.items()):
    cols = [statistics.median(c) for c in zip(*vals)]
    print(" ".join(key), f"n={len(vals)} |", " | ".join(f"{c:g}" for c in cols))
