"""
Time per slider tick inside glue-solar's _GlueWCS.pixel_to_world_values vs inside the wrapped WCS.
usage: wrapcost.py sji|siiv    (one viewer 800x500, 20 ticks, medians)
"""
import sys
import time

from common import load_siiv, load_sji, make_app, med, settle

from glue_qt.viewers.image import ImageViewer
from glue_solar.sources.loaders import iris

kind = sys.argv[1]
app = make_app()
data = load_sji() if kind == "sji" else load_siiv()
raw = data.coords._wcs
ACC = {"wrapper total": 0.0, "wrapped WCS": 0.0, "calls": 0}
_outer = iris._GlueWCS.pixel_to_world_values
_inner = type(raw).pixel_to_world_values


def outer(self, *a):
    t = time.perf_counter()
    try:
        return _outer(self, *a)
    finally:
        ACC["wrapper total"] += time.perf_counter() - t
        ACC["calls"] += 1


def inner(self, *a):
    t = time.perf_counter()
    try:
        return _inner(self, *a)
    finally:
        ACC["wrapped WCS"] += time.perf_counter() - t


iris._GlueWCS.pixel_to_world_values = outer
type(raw).pixel_to_world_values = inner
app.data_collection.append(data)
v = app.new_data_viewer(ImageViewer, data=data)
v.parent().resize(800, 500)
settle()
axis = next(i for i in range(data.ndim) if i not in (v.state.x_att.axis, v.state.y_att.axis))
per, walls = {k: [] for k in ACC}, []
for i in range(20):
    before = dict(ACC)
    sl = list(v.state.slices)
    sl[axis] = (i * 37 + 5) % data.shape[axis]
    t = time.perf_counter()
    v.state.slices = tuple(sl)
    settle()
    walls.append(time.perf_counter() - t)
    for k in ACC:
        per[k].append(ACC[k] - before[k])
print(f"{kind} ({type(raw).__module__}.{type(raw).__name__}): tick {med(walls)*1e3:.1f} ms; per tick: {med(per['calls']):.0f} transform calls, "
      f"inside _GlueWCS {med(per['wrapper total'])*1e3:.1f} ms, inside the wrapped WCS {med(per['wrapped WCS'])*1e3:.1f} ms, "
      f"wrapper overhead {med([a - b for a, b in zip(per['wrapper total'], per['wrapped WCS'])])*1e3:.1f} ms")
