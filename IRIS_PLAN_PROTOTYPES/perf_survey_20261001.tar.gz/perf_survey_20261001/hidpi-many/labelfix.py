"""
glue's _set_wcs runs on every slider tick of data whose displayed world coordinates depend on the
slider (SJI pointing, raster exposure). It sets each axis label twice ('' then the world label), and
each WCSAxes.set_xlabel/set_ylabel recomputes every tick position through the WCS. What would
setting them less often save? Instance-level overrides in this process only:
  A: labels applied once per axis (2 tick recomputes in the setter instead of 4)
  B: labels put straight on the WCSAxes coordinate helpers (0 recomputes in the setter)
usage: labelfix.py sji|siiv
"""
import sys
import time

import numpy as np
import types

from common import load_siiv, load_sji, make_app, med, settle

from astropy.visualization.wcsaxes import core as wcore
from echo import ignore_callback
from glue.core.coordinate_helpers import dependent_axes
from glue_qt.viewers.image import ImageViewer

N_UPD = []
_upd = wcore.WCSAxes._update_tick_and_label_positions


def upd(self, *a, **k):
    N_UPD.append(1)
    return _upd(self, *a, **k)


wcore.WCSAxes._update_tick_and_label_positions = upd


def set_wcs(self, before=None, after=None, relim=True, mode="A"):
    """glue 1.27.0 MatplotlibImageMixin._set_wcs with the label steps changed (see module doc)."""
    if self.state.x_att is None or self.state.y_att is None or self.state.reference_data is None:
        return
    if after is not None and before is after:
        return
    ref_coords = self.state.reference_data.coords
    self.axes.reset_wcs(slices=self.state.wcsaxes_slice, wcs=ref_coords)
    with ignore_callback(self.state, "x_axislabel", "y_axislabel"):
        self.state.x_axislabel = self.state.x_att_world.label
        self.state.y_axislabel = self.state.y_att_world.label
    if mode == "A":
        self.update_x_axislabel()
        self.update_y_axislabel()
    else:
        ndim = self.state.reference_data.ndim
        for att, prop in ((self.state.x_att, "x"), (self.state.y_att, "y")):
            self.axes.coords[ndim - att.axis - 1].set_axislabel(
                getattr(self.state, f"{prop}_axislabel"),
                weight=getattr(self.state, f"{prop}_axislabel_weight"),
                size=getattr(self.state, f"{prop}_axislabel_size"),
            )
    self._update_appearance_from_settings()
    self.update_x_ticklabel()
    self.update_y_ticklabel()
    if relim:
        self.state.reset_limits()
    ix, iy = self.state.x_att.axis, self.state.y_att.axis
    dep = (set(dependent_axes(ref_coords, ix)) | set(dependent_axes(ref_coords, iy))) - {ix, iy}
    self._changing_slice_requires_wcs_update = bool(dep)
    self._wcs_set = True


kind = sys.argv[1]
app = make_app()
data = load_sji() if kind == "sji" else load_siiv()
app.data_collection.append(data)
v = app.new_data_viewer(ImageViewer, data=data)
v.parent().resize(800, 500)
settle()
time.sleep(0.6)
settle()
axis = next(i for i in range(data.ndim) if i not in (v.state.x_att.axis, v.state.y_att.axis))
original = v._set_wcs
snaps = {}
for mode in ("glue 1.27.0", "A", "B"):
    if mode == "glue 1.27.0":
        v._set_wcs = original
    else:
        v._set_wcs = types.MethodType(lambda self, *a, _m=mode, **k: set_wcs(self, *a, mode=_m, **k), v)
    walls, syncs, nset = [], [], []
    for i in range(25):
        sl = list(v.state.slices)
        sl[axis] = (i * 37 + 5) % data.shape[axis]
        N_UPD.clear()
        t = time.perf_counter()
        v.state.slices = tuple(sl)
        syncs.append(time.perf_counter() - t)
        nset.append(len(N_UPD))
        settle()
        walls.append(time.perf_counter() - t)
    labels = [c.get_axislabel() for c in v.axes.coords]
    sl = list(v.state.slices)
    sl[axis] = 7
    v.state.slices = tuple(sl)
    settle()
    v.figure.canvas.draw()
    snaps[mode] = np.asarray(v.figure.canvas.get_renderer().buffer_rgba()).copy()
    same = "reference" if mode == "glue 1.27.0" else f"{(snaps[mode] != snaps['glue 1.27.0']).any(axis=2).mean()*100:.3f}% px differ"
    print(f"{kind} {mode:12s} tick wall {med(walls)*1e3:6.1f} ms  setter {med(syncs)*1e3:6.1f} ms  "
          f"tick recomputes in setter {med(nset):.0f}, total per tick {len(N_UPD)}  labels {labels} [{same}]", flush=True)
