#!/bin/sh
# Remaining data-heavy measurements, one at a time. Run from the perf/ directory.
PY=~/mamba/envs/iris-plan/bin/python
run() { env HOME="$(mktemp -d)" QT_QPA_PLATFORM=offscreen MPLBACKEND=agg $PY "$@" 2>&1 | grep -v "propagateSizeHints\|Warning\|font cache\|qt.qpa.fonts\|glue_solar from"; }
for k in sji siiv; do run hidpi-many/tickcalls.py $k; done > hidpi-many/tickcalls.log
for k in sji siiv; do run hidpi-many/wrapcost.py $k; done > hidpi-many/wrapcost.log
for n in 1 10; do run hidpi-many/point_split.py $n; done > hidpi-many/point_split.log
echo done
for k in sji siiv; do for sm in throttled coalesce; do env LABELFIX=1 HOME="$(mktemp -d)" QT_QPA_PLATFORM=offscreen MPLBACKEND=agg ~/mamba/envs/iris-plan/bin/python hidpi-many/drag.py $k uncompressed $sm 2>&1 | grep "positions in"; done; done > hidpi-many/drag_labelfix.log
echo done2
