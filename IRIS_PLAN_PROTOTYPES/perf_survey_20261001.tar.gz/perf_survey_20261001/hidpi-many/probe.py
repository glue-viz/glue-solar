"""Probe: one SJI viewer, report DPR, figure dpi, canvas size and draw/paint timings."""
import time

from common import DRAWS, PAINTS, env_line, load_sji, make_app, med, rss_mb, settle

from glue_qt.viewers.image import ImageViewer

app = make_app()
print(env_line())
sji = load_sji()
app.data_collection.append(sji)
v = app.new_data_viewer(ImageViewer, data=sji)
v.parent().resize(1000, 800) if v.parent() else v.resize(1000, 800)
settle()
c = v.figure.canvas
print("canvas logical", c.width(), c.height(), "dpr", c.device_pixel_ratio, "fig dpi", v.figure.dpi,
      "renderer px", c.get_renderer().width, c.get_renderer().height, "tools", v.toolbar.tools.keys() if v.toolbar else None)
print("slices", v.state.slices, "x_att", v.state.x_att, "y_att", v.state.y_att)
DRAWS.clear(); PAINTS.clear()
ticks = []
for i in range(1, 31):
    t = time.perf_counter()
    v.state.slices = (i * 10,) + tuple(v.state.slices[1:])
    settle()
    ticks.append(time.perf_counter() - t)
print(f"tick wall median {med(ticks)*1e3:.1f} ms; draws {len(DRAWS)} median {med([d[2] for d in DRAWS])*1e3:.1f} ms; "
      f"paints {len(PAINTS)} median {med([p[2] for p in PAINTS])*1e3:.2f} ms; rss {rss_mb():.0f}MB")
