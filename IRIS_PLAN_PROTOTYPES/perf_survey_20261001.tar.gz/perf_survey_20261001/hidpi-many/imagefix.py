"""
What would two candidate glue-core image-path fixes save? Runtime toggles in this process only:
  f32  - CompositeArray returns float32 RGBA instead of float64 (matplotlib then resamples,
         demultiplies and converts float32 at device resolution)
  cap  - the FRB is computed at no more bins than reference-data pixels in view (+1), instead of
         the axes size at 72 dpi; nearest-neighbour upsampling to the screen is then matplotlib's
  interp-none - the FRB artist uses interpolation='none', so Agg scales the uint8 image in C
         (matplotlib's unsampled path) instead of resampling float RGBA at device resolution
usage: imagefix.py sji|siiv   (DPR from QT_SCALE_FACTOR). Static draws, 15 each, median.
"""
import math
import sys
import time

import numpy as np
from common import env_line, load_siiv, load_sji, make_app, med, settle

from glue.viewers.image import composite_array as ca
from glue.viewers.image import frb_artist
from glue_qt.viewers.image import ImageViewer

MODE = set()
_call = ca.CompositeArray.__call__
_afw = frb_artist.FRBArtist.array_func_wrapper
SHAPES = []


def call(self, bounds=None):
    out = _call(self, bounds=bounds)
    if out is not None:
        SHAPES.append(out.shape)
    return out.astype(np.float32) if "f32" in MODE and out is not None else out


def afw(self, bins=None, range=None):
    if "cap" in MODE:
        (ymin, ymax), (xmin, xmax) = range
        bins = (min(bins[0], math.ceil(abs(ymax - ymin)) + 1), min(bins[1], math.ceil(abs(xmax - xmin)) + 1))
    return _afw(self, bins=bins, range=range)


ca.CompositeArray.__call__ = call
frb_artist.FRBArtist.array_func_wrapper = afw

kind = sys.argv[1]
app = make_app()
print(env_line())
data = load_sji() if kind == "sji" else load_siiv()
app.data_collection.append(data)
v = app.new_data_viewer(ImageViewer, data=data)
settle()
c = v.figure.canvas
im = v.axes._composite_image
axis = next(i for i in range(data.ndim) if i not in (v.state.x_att.axis, v.state.y_att.axis))
for w, h in [(800, 500), (1580, 900)]:
    v.parent().resize(w, h)
    settle()
    time.sleep(0.6)
    settle()
    r = c.get_renderer()
    base = None
    for mode in ((), ("f32",), ("cap",), ("f32", "cap"), ("interp-none",), ("interp-none", "cap")):
        MODE.clear()
        MODE.update(mode)
        im.set_interpolation("none" if "interp-none" in mode else "nearest")
        im.stale = True
        c.draw()
        snap = np.asarray(r.buffer_rgba()).copy()
        out = []
        for _ in range(15):
            im.stale = True
            t = time.perf_counter()
            c.draw()
            out.append(time.perf_counter() - t)
        # also a slider tick: new slice, cache miss on the FRB
        ticks = []
        for i in range(10):
            sl = list(v.state.slices)
            sl[axis] = (i * 37 + 5) % data.shape[axis]
            t = time.perf_counter()
            v.state.slices = tuple(sl)
            settle()
            ticks.append(time.perf_counter() - t)
        if base is None:
            base = snap
            diff = "reference"
        else:
            d = np.abs(base.astype(int) - snap.astype(int)).max(axis=2)
            diff = f"{(d > 0).mean() * 100:.3f}% px differ, {(d > 2).mean() * 100:.3f}% by >2 levels"
        print(f"{kind} {r.width}x{r.height} px dpr {c.device_pixel_ratio} {'+'.join(mode) or 'glue 1.27.0':12s} "
              f"static draw {med(out)*1e3:6.1f} ms  slider tick {med(ticks)*1e3:6.1f} ms  composite {SHAPES[-1]}  [{diff}]",
              flush=True)
        # reset to the reference slice for the image comparison
        sl = list(v.state.slices)
        sl[axis] = 0
        v.state.slices = tuple(sl)
        settle()
