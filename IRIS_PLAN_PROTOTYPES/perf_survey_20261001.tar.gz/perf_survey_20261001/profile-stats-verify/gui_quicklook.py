"""Quicklook-level checks for findings 1, 2, 3, 4, 6. Usage: gui_quicklook.py ss|stack glue|sync"""
import sys, time, statistics, threading, warnings, cProfile, pstats, io
import numpy as np
from vcommon import load, rss_mb, StatRecorder, SS_SJI, D
warnings.simplefilter('ignore')
import glob

kind, mode = sys.argv[1], sys.argv[2]
from qtpy.QtCore import QTimer, QEventLoop
from qtpy.QtWidgets import QApplication
from glue_qt.app import GlueApplication
from glue_qt.viewers.matplotlib.widget import MplCanvas
from glue_qt.viewers.profile.layer_artist import QThreadedProfileLayerArtist
from glue.viewers.profile.layer_artist import ProfileLayerArtist
from glue.viewers.image.pixel_selection_subset_state import PixelSubsetState
from glue.viewers.image.state import AggregateSlice

rec = StatRecorder()
draws = []
_draw = MplCanvas.draw
hook = [None]


def draw(self, *a, **k):
    t = time.perf_counter()
    try:
        return _draw(self, *a, **k)
    finally:
        draws.append((self, t, time.perf_counter()))
        if hook[0]:
            hook[0](self)


MplCanvas.draw = draw
paints = []
_paint = MplCanvas.paintEvent


def paintEvent(self, event):
    paints.append((self, time.perf_counter()))
    return _paint(self, event)


MplCanvas.paintEvent = paintEvent
runs = []
_thread = ProfileLayerArtist._calculate_profile_thread


def calc_thread(self, reset=False):
    t = time.perf_counter()
    try:
        return _thread(self, reset=reset)
    finally:
        runs.append((threading.current_thread().name, t))


ProfileLayerArtist._calculate_profile_thread = calc_thread
import variants
variants.apply(mode)
if mode == 'sync':
    QThreadedProfileLayerArtist._calculate_profile = lambda self, reset=False: ProfileLayerArtist._calculate_profile(self, reset=reset)

app = GlueApplication()
app.resize(1600, 1000)
app.show()
tick = QTimer(); tick.start(2)


def pump(seconds):
    end = time.perf_counter() + seconds
    while time.perf_counter() < end:
        QApplication.processEvents(QEventLoop.WaitForMoreEvents)


def pump_until(cond, timeout=5.0):
    end = time.perf_counter() + timeout
    while not cond() and time.perf_counter() < end:
        QApplication.processEvents(QEventLoop.WaitForMoreEvents)


def idle(quiet=0.4, timeout=60):
    t0 = time.perf_counter()
    while time.perf_counter() - t0 < timeout:
        pump(0.05)
        busy = any(getattr(la, 'is_computing', False) for tab in app.viewers for v in tab for la in v.layers)
        last = max([x[2] for x in draws] + [0])
        if not busy and time.perf_counter() - last > quiet:
            return time.perf_counter() - t0


pump(0.5)
from glue_solar.sources.loaders.iris import image_data
from glue_solar.quicklook import quicklook
raster = load(kind)
sji = image_data(SS_SJI if kind == 'ss' else glob.glob(f'{D}/*4000005156_SJI_2796_t000_deconvolved.fits.gz')[0])
print('sji', sji.label, sji.shape, flush=True)

n0 = len(rec.calls)
t = time.perf_counter()
pr = cProfile.Profile(); pr.enable()
viewers = quicklook(app, [raster, sji])
pr.disable()
t_ql = time.perf_counter() - t
t_idle = idle()
print(f'\n== quicklook() [{mode}] returned in {t_ql:.2f} s; idle after a further {t_idle:.2f} s; peak {rss_mb():.0f} MB', flush=True)
rec.report(n0)
s = io.StringIO(); pstats.Stats(pr, stream=s).sort_stats('cumtime').print_stats('_reset_y_limits|reset_limits|quicklook.py:.*\\((_profile|quicklook|_fit)\\)|data.py:.*compute_statistic'); print(s.getvalue()[-2000:])

from glue.core.message import ComputationEndedMessage
from glue.core.hub import HubListener


class Ended(HubListener):
    def __init__(self, artist):
        self.t = []
        raster.hub.subscribe(self, ComputationEndedMessage, handler=lambda m: self.t.append(time.perf_counter()),
                             filter=lambda m: m.sender is artist)


spec = viewers['spectrum']; spec_canvas = spec.figure.canvas
mapv = viewers['map']; map_canvas = mapv.figure.canvas
print('map canvas', map_canvas.width(), map_canvas.height(), 'spectrum canvas', spec_canvas.width(), spec_canvas.height())
group = [g for g in app.data_collection.subset_groups if g.label == 'Point'][0]
sub_artist = [la for la in spec.layers if la.state.layer in group.subsets][0]
print('spectrum subset artist', type(sub_artist).__name__)
ended = Ended(sub_artist)
start = group.subset_state
base = [s.start or 0 for s in start.slices]
wl = raster.ndim - 1
a, b = (0, 1) if raster.ndim == 3 else (1, 2)
raw = raster.get_component(raster.main_components[0]).data


def run_moves(label, n=10, warm=2):
    out = []
    for k in range(1, n + warm + 1):
        p = list(base)
        p[a] = (base[a] + 5 * k) % raster.shape[a]
        p[b] = (base[b] + 3 * k) % raster.shape[b]
        sl = [slice(i, i + 1) for i in p]; sl[wl] = slice(None)
        expected = np.asarray(raw[tuple(sl)], dtype=float).ravel()
        shown = [None]

        def check(c):
            if c is spec_canvas and shown[0] is None:
                y = np.asarray(sub_artist.plot_artist.get_ydata(), dtype=float)
                if y.shape == expected.shape and np.allclose(y, expected, equal_nan=True):
                    shown[0] = time.perf_counter()
        hook[0] = check
        nd, nc = len(draws), len(rec.calls)
        t0 = time.perf_counter()
        group.subset_state = PixelSubsetState(raster, sl)
        pump_until(lambda: shown[0] is not None)
        pump(0.4)
        hook[0] = None
        ds = draws[nd:]
        settled = max([x[2] for x in ds] + [t0]) - t0
        painted = min([p[1] for p in paints if p[0] is spec_canvas and shown[0] is not None and p[1] >= shown[0]] + [np.nan]) - t0
        if k in (3, 4) and label in (mode,):
            roles = {id(v.figure.canvas): r for r, v in viewers.items() if r != 'sji'}
            roles.update({id(v.figure.canvas): f'sji{i}' for i, v in enumerate(viewers['sji'])})
            print('   move', k, 'draws:', [(roles.get(id(x[0]), '?'), round((x[1] - t0) * 1e3), round((x[2] - x[1]) * 1e3)) for x in ds],
                  'ended:', [round((e - t0) * 1e3) for e in ended.t if e > t0], 'runs:', [(r[0][:6], round((r[1] - t0) * 1e3)) for r in runs if r[1] > t0])
        hist = [c for c in rec.calls[nc:] if c[0] == 'compute_histogram']
        out.append(((shown[0] or np.nan) - t0, sum(x[2] - x[1] for x in ds if x[0] is map_canvas),
                    len([x for x in ds if x[0] is spec_canvas]), sum(x[2] - x[1] for x in ds),
                    len(hist), sum(c[2] for c in hist), settled, painted))
    r = out[warm:]
    med = lambda i: statistics.median(x[i] for x in r)
    print(f'== point move [{label}] n={len(r)}: spectrum drawn after median {med(0)*1e3:.1f} ms (min {min(x[0] for x in r)*1e3:.1f}, '
          f'max {max(x[0] for x in r)*1e3:.1f}); map drawing {med(1)*1e3:.1f} ms; spectrum draws {med(2)}; all drawing {med(3)*1e3:.1f} ms; '
          f'compute_histogram calls {med(4)} ({med(5)*1e3:.1f} ms); last draw of the move ends at {med(6)*1e3:.1f} ms; spectrum canvas paintEvent after the new spectrum draw at {med(7)*1e3:.1f} ms', flush=True)


run_moves(mode)
if sys.argv[3:] == ['gap']:
    # sample the main thread's stack every 2 ms during moves, outside canvas draws
    import collections, traceback
    main_id = threading.main_thread().ident
    in_draw = [0]
    _d2 = MplCanvas.draw

    def draw2(self, *a, **k):
        in_draw[0] += 1
        try:
            return _d2(self, *a, **k)
        finally:
            in_draw[0] -= 1
    MplCanvas.draw = draw2
    samples = collections.Counter(); stop = [False]; n_s = [0]

    def sampler():
        while not stop[0]:
            time.sleep(0.002)
            if in_draw[0]:
                continue
            f = sys._current_frames().get(main_id)
            stack = [fr for fr in traceback.extract_stack(f)]
            keys = [f'{fr.filename.split("site-packages/")[-1].split("glue-solar-main/")[-1]}:{fr.lineno} {fr.name}' for fr in stack
                    if ('glue' in fr.filename or 'echo' in fr.filename) and 'profile-stats-verify' not in fr.filename]
            if not keys:
                continue
            n_s[0] += 1
            for kk in set(keys):
                samples[kk] += 1
    th = threading.Thread(target=sampler, daemon=True); th.start()
    run_moves('gap sampling', n=6, warm=0)
    stop[0] = True
    print(f'{n_s[0]} samples (2 ms) outside draws in glue/echo code over 6 moves; frames by inclusive count:')
    for kk, c in samples.most_common(45):
        print(f'   {c:5d} {kk}')
    app.close(); sys.exit()
if sys.argv[3:] == ['moves']:
    app.close(); sys.exit()

if mode == 'glue':
    # Finding 6: wavelength slider tick on the map
    lstate = mapv.state.layers[0]
    for glob_stretch in (True, False):
        lstate.stretch_global = glob_stretch
        idle()
        out = []
        for k in range(8):
            sl = list(mapv.state.slices); sl[wl] = (sl[wl] + 1) % raster.shape[wl]
            nd, nc = len(draws), len(rec.calls)
            mapv.state.slices = tuple(sl)
            pump(0.25)
            md = [x[2] - x[1] for x in draws[nd:] if x[0] is map_canvas]
            out.append((sum(md), len(md), sum(c[2] for c in rec.calls[nc:])))
        print(f'== map slider tick stretch_global={glob_stretch}: map draw median {statistics.median(x[0] for x in out[2:])*1e3:.1f} ms, '
              f'{statistics.median(x[1] for x in out[2:])} draws, statistics {statistics.median(x[2] for x in out[2:])*1e3:.2f} ms', flush=True)
    lstate.stretch_global = True

# Finding 3: Collapse on the quicklook map
sl0 = list(mapv.state.slices)
w0 = sl0[wl]
sl = list(sl0); sl[wl] = AggregateSlice(slice(max(w0 - 50, 0), w0 + 50), w0, np.nanmedian)
mapv.state.slices = tuple(sl)
idle()
run_moves(f'{mode}, Collapse nanmedian 100 px on the map', n=4)
mapv.state.slices = tuple(sl0)
idle()

# Finding 4: Histogram viewer of the raster
from glue_qt.viewers.histogram import HistogramViewer
hv = app.new_data_viewer(HistogramViewer)
hv.large_data_size = None
nc = len(rec.calls)
t = time.perf_counter()
hv.add_data(raster)
blk = time.perf_counter() - t
it = idle()
print(f'\n== Histogram add_data(raster): main thread blocked {blk*1e3:.0f} ms, idle after {(blk+it):.2f} s; peak {rss_mb():.0f} MB', flush=True)
rec.report(nc)
nc = len(rec.calls)
run_moves(f'{mode}, with a Histogram viewer of the raster', n=6)
rec.report(nc)
print(f'final peak RSS {rss_mb():.0f} MB')
app.close()
