"""Finding 3: one-time native-resolution collapse cost over 100 wavelength px. Usage: native.py ss|stack"""
import sys, warnings
import numpy as np
from vcommon import load, bench
warnings.simplefilter('ignore')
d = load(sys.argv[1])
raw = d.get_component(d.main_components[0]).data
w0 = raw.shape[-1] // 2
sub = raw[..., w0 - 50:w0 + 50]
print('sub', sub.shape, sub.dtype)


def sort_nanmedian(a, axis=-1):
    s = np.sort(a, axis=axis)
    n = np.sum(~np.isnan(a), axis=axis, keepdims=True)
    lo = np.take_along_axis(s, np.maximum((n - 1) // 2, 0), axis)
    hi = np.take_along_axis(s, np.maximum(n // 2, 0), axis)
    out = ((lo + hi) / 2).squeeze(axis)
    out[(n == 0).squeeze(axis)] = np.nan
    return out


bench('np.nanmean', lambda: np.nanmean(sub, axis=-1), n=3)
bench('np.nanmedian', lambda: np.nanmedian(sub, axis=-1), n=1, warm=0)
bench('sort-based nanmedian', lambda: sort_nanmedian(sub), n=3)
print('equal:', np.allclose(sort_nanmedian(sub), np.nanmedian(sub, axis=-1), equal_nan=True))
