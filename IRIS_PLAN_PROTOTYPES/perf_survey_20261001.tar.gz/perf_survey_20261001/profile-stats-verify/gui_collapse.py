"""Finding 3: Collapse (AggregateSlice) on a glue-only Image viewer. Usage: gui_collapse.py ss|stack"""
import sys, time, statistics, warnings
import numpy as np
from vcommon import load, rss_mb, bench
warnings.simplefilter('ignore')

from qtpy.QtCore import QTimer, QEventLoop
from qtpy.QtWidgets import QApplication
from glue_qt.app import GlueApplication
from glue_qt.viewers.image import ImageViewer
from glue_qt.viewers.matplotlib.widget import MplCanvas
from glue.viewers.image.state import AggregateSlice
from glue.viewers.image.pixel_selection_subset_state import PixelSubsetState

draws = []
_draw = MplCanvas.draw


def draw(self, *a, **k):
    t = time.perf_counter()
    try:
        return _draw(self, *a, **k)
    finally:
        draws.append((self, t, time.perf_counter()))


MplCanvas.draw = draw
aggs = []  # (input dtype, input shape, seconds)


def counted(func):
    def agg(a, axis=None):
        t = time.perf_counter()
        try:
            return func(a, axis=axis)
        finally:
            aggs.append((a.dtype, a.shape, time.perf_counter() - t))
    agg.__name__ = func.__name__
    return agg


app = GlueApplication(); app.resize(1600, 1000); app.show()
tick = QTimer(); tick.start(2)


def pump(seconds):
    end = time.perf_counter() + seconds
    while time.perf_counter() < end:
        QApplication.processEvents(QEventLoop.WaitForMoreEvents)


pump(0.5)
d = load(sys.argv[1])
app.data_collection.append(d)
wl = d.ndim - 1
a, b = (0, 1) if d.ndim == 3 else (1, 2)
v = app.new_data_viewer(ImageViewer, data=d)
v.viewer_size = (600, 450)
px = d.pixel_component_ids
v.state.x_att = px[a]; v.state.y_att = px[b]
mid = [s // 2 for s in d.shape]
w0 = mid[wl]
v.state.slices = tuple(mid)
v.state.aspect = 'auto'
v.state.reset_limits()
canvas = v.figure.canvas
pump(1.0)
print(f'canvas {canvas.width()}x{canvas.height()}', flush=True)


def pans(n=8):
    out, na = [], []
    x0, x1 = v.state.x_min, v.state.x_max
    for k in range(n):
        dx = (x1 - x0) * 0.02 * (1 if k % 2 else -1)
        nd, nag = len(draws), len(aggs)
        v.state.x_min, v.state.x_max = x0 + dx, x1 + dx
        pump(0.6)
        my = [x[2] - x[1] for x in draws[nd:] if x[0] is canvas]
        out.append(sum(my)); na.append(aggs[nag:])
    return statistics.median(out[2:]), na[-1]


def describe(ag):
    return ', '.join(f'{dt}{list(sh)} {s*1e3:.0f} ms' for dt, sh, s in ag)


def collapse_runs(tag):
    print(f'== [{tag}] plain slice: redraw after pan median {pans()[0]*1e3:.1f} ms', flush=True)
    for width in (20, 100):
        for func in (np.nanmean, np.nanmedian):
            sl = list(v.state.slices)
            sl[wl] = AggregateSlice(slice(w0 - width // 2, w0 + width // 2), w0, counted(func))
            v.state.slices = tuple(sl); pump(0.6)
            med, last = pans()
            print(f'== [{tag}] Collapse {func.__name__} over {width} px: redraw after pan median {med*1e3:.1f} ms; '
                  f'aggregations in last pan: {describe(last)}', flush=True)
            sl[wl] = w0; v.state.slices = tuple(sl); pump(0.6)


collapse_runs('data only')
group = app.data_collection.new_subset_group(label='Point', subset_state=PixelSubsetState(d, [slice(i, i + 1) if j != wl else slice(None) for j, i in enumerate(mid)]))
pump(0.6)
collapse_runs('data + Point subset layer')

# point move while collapsed, nanmedian over 100 px
sl = list(v.state.slices)
sl[wl] = AggregateSlice(slice(w0 - 50, w0 + 50), w0, counted(np.nanmedian))
v.state.slices = tuple(sl); pump(0.8)
out = []
for k in range(1, 9):
    p = list(mid); p[a] = (mid[a] + 7 * k) % d.shape[a]; p[b] = (mid[b] + 3 * k) % d.shape[b]
    nd, nag = len(draws), len(aggs)
    group.subset_state = PixelSubsetState(d, [slice(i, i + 1) if j != wl else slice(None) for j, i in enumerate(p)])
    pump(0.8)
    out.append((sum(x[2] - x[1] for x in draws[nd:] if x[0] is canvas), len([x for x in draws[nd:] if x[0] is canvas]), aggs[nag:]))
print(f'== point move while collapsed (nanmedian 100 px): map drawing per move median {statistics.median(x[0] for x in out[2:])*1e3:.1f} ms, '
      f'{statistics.median(x[1] for x in out[2:])} draws; aggregations in last move: {describe(out[-1][2])}', flush=True)

raw = d.get_component(d.main_components[0]).data
sub = raw[..., w0 - 50:w0 + 50]
bench('native-resolution collapse nanmean 100 px (once)', lambda: np.nanmean(sub, axis=-1), n=3)
bench('native-resolution collapse nanmedian 100 px (once)', lambda: np.nanmedian(sub, axis=-1), n=3)
print(f'final peak RSS {rss_mb():.0f} MB')
app.close()
