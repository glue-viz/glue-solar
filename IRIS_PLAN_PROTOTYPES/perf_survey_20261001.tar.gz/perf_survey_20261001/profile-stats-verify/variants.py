"""In-process fix variants (no file edited): fixab = blocking ComputeWorker + no v_min/v_max trigger; fixb = trigger only."""
import sys
from glue_qt.viewers.matplotlib import compute_worker
from glue.viewers.profile.layer_artist import ProfileLayerArtist
from glue.utils import queue_to_list


def apply(mode):
    if mode == 'fixab':
        def run(self):
            while True:
                msgs = [self.work_queue.get()] + queue_to_list(self.work_queue)
                if 'stop' in msgs:
                    return
                self.running = True
                self.compute_start.emit()
                try:
                    self.function(reset=any(msgs))
                    error = None
                except Exception:
                    error = sys.exc_info()
                if self.work_queue.empty():
                    self.running = False
                    self.compute_end.emit() if error is None else self.compute_error.emit(error)
        compute_worker.ComputeWorker.run = run
    if mode in ('fixab', 'fixb'):
        def _update_profile(self, force=False, **kwargs):
            if self._viewer_state.x_att is None or self.state.attribute is None or self.state.layer is None:
                return
            changed = self.pop_changed_properties()
            if force or any(p in changed for p in ('layer', 'x_att', 'attribute', 'function', 'normalize',
                                                   'visible', 'x_display_unit', 'y_display_unit')):
                self._calculate_profile(reset=force)
                force = True
            if force or any(p in changed for p in ('alpha', 'color', 'zorder', 'linewidth', 'as_steps')):
                self._update_visual_attributes()
        ProfileLayerArtist._update_profile = _update_profile

