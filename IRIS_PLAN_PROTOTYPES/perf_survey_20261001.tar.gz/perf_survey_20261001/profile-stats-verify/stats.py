"""Findings 3 (breakdown), 4, 5, 6: statistics/histogram/FRB costs outside the GUI. Usage: stats.py ss|stack"""
import sys, time, cProfile, pstats, tracemalloc, io, warnings
import numpy as np
from vcommon import load, bench, rss_mb
warnings.simplefilter('ignore')
from glue.core.subset import RoiSubsetState
from glue.core.roi import RectangularROI
from glue.viewers.image.pixel_selection_subset_state import PixelSubsetState
from glue.utils.array import view_shape
from fast_histogram import histogram1d

kind = sys.argv[1]
d = load(kind)
cid = d.main_components[0]
raw = d.get_component(cid).data
print('component', cid, raw.dtype, raw.shape, f'{raw.nbytes/2**20:.0f} MiB', flush=True)
nd = d.ndim
wl = nd - 1
prof_axes = tuple(range(nd - 1))  # profile along wavelength


def peak(fn):
    tracemalloc.start(); tracemalloc.reset_peak()
    fn()
    p = tracemalloc.get_traced_memory()[1]
    tracemalloc.stop()
    return p / 2**20


print('\n== Finding 5: whole-cube profile along wavelength')
for stat in ('mean', 'maximum'):
    bench(f'glue compute_statistic {stat}', lambda: d.compute_statistic(stat, cid, axis=prof_axes), n=3)
    print(f'   tracemalloc peak {peak(lambda: d.compute_statistic(stat, cid, axis=prof_axes)):.0f} MiB')
bench('numpy float32 nanmean (no chunking)', lambda: np.nanmean(raw, axis=prof_axes), n=3)

pr = cProfile.Profile(); t = time.perf_counter(); pr.enable()
ref_mean = d.compute_statistic('mean', cid, axis=prof_axes)
pr.disable(); print(f'cProfile mean: {(time.perf_counter()-t)*1e3:.0f} ms')
s = io.StringIO(); pstats.Stats(pr, stream=s).sort_stats('tottime').print_stats(8); print(s.getvalue()[-2200:])

# prototype: where= reduction per chunk (same chunking as glue: 4e7 elements per chunk along wl)
n_chunks = d.size / 4e7
step = max(1, int(d.shape[wl] / n_chunks))


def proto_mean():
    out = np.empty(d.shape[wl])
    for i0 in range(0, d.shape[wl], step):
        c = raw[..., i0:i0 + step]
        fin = np.isfinite(c)
        with np.errstate(invalid='ignore', divide='ignore'):
            out[i0:i0 + step] = np.sum(c, axis=prof_axes, dtype=np.float64, where=fin) / np.count_nonzero(fin, axis=prof_axes)
    return out


def proto_max():
    out = np.empty(d.shape[wl])
    for i0 in range(0, d.shape[wl], step):
        c = raw[..., i0:i0 + step]
        fin = np.isfinite(c)
        m = np.max(c, axis=prof_axes, initial=-np.inf, where=fin)
        m[~fin.any(axis=prof_axes)] = np.nan
        out[i0:i0 + step] = m
    return out


bench('prototype where-mean', proto_mean, n=3)
print(f'   tracemalloc peak {peak(proto_mean):.0f} MiB; allclose to glue (rtol 1e-5): {np.allclose(proto_mean(), ref_mean, rtol=1e-5, equal_nan=True)}')
bench('prototype where-max', proto_max, n=3)
print(f'   equal to glue maximum: {np.array_equal(proto_max(), d.compute_statistic("maximum", cid, axis=prof_axes), equal_nan=True)}')

# Isolate the components of glue's utils.compute_statistic on one chunk
c = raw[..., :step]
print(f'one chunk {c.shape}:')
bench('  keep = ones & isfinite', lambda: np.ones(c.shape, bool) & np.isfinite(c), n=3)
bench('  np.array(c, float)', lambda: np.array(c, dtype=float), n=3)
c64 = np.array(c, dtype=float)
bench('  np.nanmean(float64 chunk)', lambda: np.nanmean(c64, axis=prof_axes), n=3)
del c64

print('\n== Finding 4: histogram')
mid = [s // 2 for s in d.shape]
slices = [slice(i, i + 1) for i in mid]
slices[wl] = slice(None)
point = PixelSubsetState(d, slices)
sample = raw[np.isfinite(raw)][::1000]
rng = (float(np.percentile(sample, 0.5)), float(np.percentile(sample, 99.5)))
print('range', rng)
bench('glue compute_histogram point subset', lambda: d.compute_histogram([cid], range=[rng], bins=[15], subset_state=point), n=10)
print(f'   tracemalloc peak {peak(lambda: d.compute_histogram([cid], range=[rng], bins=[15], subset_state=point)):.1f} MiB')
h_glue = d.compute_histogram([cid], range=[rng], bins=[15], subset_state=point)
proto = lambda: histogram1d(np.asarray(point.to_array(d, cid), dtype=float).ravel(), range=rng, bins=15)
bench('prototype to_array + histogram1d', proto, n=10)
print('   equal:', np.array_equal(h_glue, proto()))
bench('glue compute_histogram whole cube', lambda: d.compute_histogram([cid], range=[rng], bins=[15]), n=3)
r0 = rss_mb(); print(f'   tracemalloc peak {peak(lambda: d.compute_histogram([cid], range=[rng], bins=[15])):.0f} MiB')
h_all = d.compute_histogram([cid], range=[rng], bins=[15])
proto_all = lambda: histogram1d(raw.ravel(), range=rng, bins=15)
bench('prototype histogram1d(raw)', proto_all, n=3)
print(f'   tracemalloc peak {peak(proto_all):.1f} MiB; equal: {np.array_equal(h_all, proto_all())}')
bench('glue compute_histogram whole cube random_subset=1e6', lambda: d.compute_histogram([cid], range=[rng], bins=[15], random_subset=1000000), n=3)

print('\n== Finding 6: point and ROI profiles')
bench('point mean profile (PixelSubsetState)', lambda: d.compute_statistic('mean', cid, axis=prof_axes, subset_state=point), n=20)
px = d.pixel_component_ids
x0, y0 = mid[0], mid[1]
roi = RoiSubsetState(xatt=px[0], yatt=px[1], roi=RectangularROI(x0 - 20, x0 + 20, y0 - 20, y0 + 20))
if nd == 4:
    roi = RoiSubsetState(xatt=px[1], yatt=px[2], roi=RectangularROI(mid[1] - 20, mid[1] + 20, mid[2] - 20, mid[2] + 20))
bench('ROI 40x40 mean profile', lambda: d.compute_statistic('mean', cid, axis=prof_axes, subset_state=roi), n=10)
pr = cProfile.Profile(); pr.enable()
for _ in range(5):
    d.compute_statistic('mean', cid, axis=prof_axes, subset_state=roi)
pr.disable(); s = io.StringIO(); pstats.Stats(pr, stream=s).sort_stats('cumtime').print_stats('contains|to_mask|compute_statistic'); print(s.getvalue()[-1500:])
bench('percentile 99.5 random_subset=10000', lambda: d.compute_statistic('percentile', cid, percentile=99.5, random_subset=10000), n=10)

print('\n== Finding 3 breakdown: FRB 333x196x100 and aggregation')
if nd == 3:
    bounds = [(0, d.shape[0] - 1, 333), (0, d.shape[1] - 1, 196), (81, 180, 100)]
else:
    bounds = [0, (0, d.shape[1] - 1, 333), (0, d.shape[2] - 1, 196), (81, 180, 100)]
bench('FRB data gather (no cache)', lambda: d.compute_fixed_resolution_buffer(bounds, target_data=d, target_cid=cid, broadcast=False), n=5)
buf = d.compute_fixed_resolution_buffer(bounds, target_data=d, target_cid=cid, broadcast=False)
print('   buffer', buf.shape, buf.dtype)
bench('np.nanmedian(buf, axis=-1)', lambda: np.nanmedian(buf, axis=-1), n=5)
bench('np.nanmean(buf, axis=-1)', lambda: np.nanmean(buf, axis=-1), n=5)


def sort_nanmedian(a, axis=-1):
    s = np.sort(a, axis=axis)  # NaN sort last
    n = np.sum(~np.isnan(a), axis=axis, keepdims=True)
    lo = np.take_along_axis(s, np.maximum((n - 1) // 2, 0), axis)
    hi = np.take_along_axis(s, np.maximum(n // 2, 0), axis)
    out = ((lo + hi) / 2).squeeze(axis)
    out[(n == 0).squeeze(axis)] = np.nan
    return out


bench('sort-based nanmedian', lambda: sort_nanmedian(buf), n=5)
print('   equal to np.nanmedian:', np.allclose(sort_nanmedian(buf), np.nanmedian(buf, axis=-1), equal_nan=True))
bench('FRB mask gather (point subset, no cache)', lambda: d.compute_fixed_resolution_buffer(bounds, target_data=d, subset_state=point, broadcast=False), n=5)
mask = d.compute_fixed_resolution_buffer(bounds, target_data=d, subset_state=point, broadcast=False)
print('   mask', mask.shape, mask.dtype)
pr = cProfile.Profile(); pr.enable()
for _ in range(3):
    d.compute_fixed_resolution_buffer(bounds, target_data=d, subset_state=point, broadcast=False)
pr.disable(); s = io.StringIO(); pstats.Stats(pr, stream=s).sort_stats('tottime').print_stats(8); print(s.getvalue()[-1800:])
idx = np.ix_(*[np.linspace(b[0], b[1], b[2]).round().astype(int) for b in bounds if isinstance(b, tuple)])
idx = tuple(np.broadcast_arrays(*idx))
if nd == 4:
    idx = (np.zeros_like(idx[0]),) + idx
bench('view_shape(shape, index arrays)', lambda: view_shape(d.shape, idx), n=5)
bench('np.broadcast_shapes(index arrays)', lambda: np.broadcast_shapes(*[i.shape for i in idx]), n=5)
bench('np.nanmedian(mask, axis=-1)', lambda: np.nanmedian(mask, axis=-1), n=5)
bench('np.any(mask, axis=-1)', lambda: np.any(mask, axis=-1), n=5)
print(f'final peak RSS {rss_mb():.0f} MB')
