"""Verification helpers: IRIS loads via glue-solar, timing, memory."""
import sys, glob, time, resource, statistics, threading
sys.path.insert(0, '/Users/nabil/Git/glue-solar-main')
import glue_solar
print('glue_solar from', glue_solar.__file__, flush=True)

D = '/Users/nabil/DATA/IRIS'
SS_RASTER = glob.glob(f'{D}/*4000255147_raster/*_r00000.fits')
SS_SJI = glob.glob(f'{D}/*4000255147_SJI_1400_t000.fits.gz')[0]
SCAN_RASTERS = sorted(glob.glob(f'{D}/*4000005156_raster/*.fits'))


def rss_mb():
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 2**20  # macOS: bytes


def load(kind, window='Si IV 1403'):
    from glue_solar.sources.loaders.iris import raster_data
    t = time.perf_counter()
    if kind == 'ss':
        [data] = raster_data(SS_RASTER, windows=[window])
    else:
        [data] = raster_data(SCAN_RASTERS, windows=[window], stack=True)
    print(f'load {kind} {window}: {time.perf_counter() - t:.2f} s shape {data.shape} '
          f'dtype {data.get_component(data.main_components[0]).data.dtype} peak {rss_mb():.0f} MB', flush=True)
    return data


def bench(label, fn, n=5, warm=1):
    for _ in range(warm):
        fn()
    ts = []
    for _ in range(n):
        t = time.perf_counter()
        fn()
        ts.append(time.perf_counter() - t)
    med = statistics.median(ts)
    print(f'{label}: median {med*1e3:.1f} ms (n={n}, min {min(ts)*1e3:.1f}, max {max(ts)*1e3:.1f}) peak {rss_mb():.0f} MB', flush=True)
    return med


class StatRecorder:
    """Wrap Data.compute_statistic / compute_histogram to log thread and time per call."""

    def __init__(self):
        from glue.core.data import Data
        self.calls = []
        self.tl = threading.local()
        for name in ('compute_statistic', 'compute_histogram'):
            orig = getattr(Data, name)
            setattr(Data, name, self._wrap(name, orig))

    def _wrap(self, name, orig):
        rec = self

        def wrapper(self, *args, **kwargs):
            depth = getattr(rec.tl, 'd', 0)
            rec.tl.d = depth + 1
            t = time.perf_counter()
            try:
                return orig(self, *args, **kwargs)
            finally:
                rec.tl.d = depth
                if depth == 0:  # outermost call only (chunking recurses)
                    ss = kwargs.get('subset_state')
                    rec.calls.append((name, threading.current_thread().name, time.perf_counter() - t,
                                      args[0] if name == 'compute_statistic' else '',
                                      kwargs.get('axis'), type(ss).__name__ if ss is not None else None))
        return wrapper

    def report(self, since=0):
        from collections import defaultdict
        agg = defaultdict(list)
        for name, thr, dt, stat, axis, ss in self.calls[since:]:
            agg[(name, 'main' if thr == 'MainThread' else 'worker', stat, axis, ss)].append(dt)
        for k, v in agg.items():
            print(f'   {k}: n={len(v)} total={sum(v)*1e3:.1f} ms max={max(v)*1e3:.1f} ms', flush=True)
        return len(self.calls)
