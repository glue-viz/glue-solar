"""Findings 1 and 2 on a glue-only Profile viewer. Usage: gui_profile.py ss|stack glue|sync|fixab|fixb

glue: installed code. sync: profile computed in-process on the main thread (QThreadedProfileLayerArtist
falls back to ProfileLayerArtist._calculate_profile). fixab: ComputeWorker blocks on its queue and emits
compute_end as soon as the queue is empty; v_min/v_max dropped from the recompute triggers. fixb: only the
trigger change. All variants are in-process monkeypatches in this script; no file is edited.
"""
import sys, time, statistics, threading, queue, warnings
import numpy as np
from vcommon import load, rss_mb, StatRecorder
warnings.simplefilter('ignore')

kind, mode = sys.argv[1], sys.argv[2]
from qtpy.QtCore import QTimer, QEventLoop
from qtpy.QtWidgets import QApplication
from glue_qt.app import GlueApplication
from glue_qt.viewers.profile import ProfileViewer
from glue_qt.viewers.matplotlib.widget import MplCanvas
from glue_qt.viewers.matplotlib import compute_worker
from glue_qt.viewers.profile.layer_artist import QThreadedProfileLayerArtist
from glue.viewers.profile.layer_artist import ProfileLayerArtist
from glue.viewers.image.pixel_selection_subset_state import PixelSubsetState
from glue.core.message import ComputationEndedMessage
from glue.core.hub import HubListener
from glue.utils import queue_to_list

rec = StatRecorder()
draws = []  # (canvas, t0, t1)
_draw = MplCanvas.draw


def draw(self, *a, **k):
    t = time.perf_counter()
    try:
        return _draw(self, *a, **k)
    finally:
        draws.append((self, t, time.perf_counter()))
        if hook[0]:
            hook[0](self)


hook = [None]
MplCanvas.draw = draw
runs = []
_thread = ProfileLayerArtist._calculate_profile_thread


def calc_thread(self, reset=False):
    t = time.perf_counter()
    try:
        return _thread(self, reset=reset)
    finally:
        runs.append((threading.current_thread().name, t, time.perf_counter()))


ProfileLayerArtist._calculate_profile_thread = calc_thread

if mode == 'sync':
    QThreadedProfileLayerArtist._calculate_profile = lambda self, reset=False: ProfileLayerArtist._calculate_profile(self, reset=reset)
if mode == 'fixab':
    def run(self):
        while True:
            msgs = [self.work_queue.get()] + queue_to_list(self.work_queue)
            if 'stop' in msgs:
                return
            self.running = True
            self.compute_start.emit()
            try:
                self.function(reset=any(msgs))
                error = None
            except Exception:
                error = sys.exc_info()
            if self.work_queue.empty():
                self.running = False
                self.compute_end.emit() if error is None else self.compute_error.emit(error)
    compute_worker.ComputeWorker.run = run
if mode in ('fixab', 'fixb'):
    def _update_profile(self, force=False, **kwargs):
        if self._viewer_state.x_att is None or self.state.attribute is None or self.state.layer is None:
            return
        changed = self.pop_changed_properties()
        if force or any(p in changed for p in ('layer', 'x_att', 'attribute', 'function', 'normalize',
                                               'visible', 'x_display_unit', 'y_display_unit')):
            self._calculate_profile(reset=force)
            force = True
        if force or any(p in changed for p in ('alpha', 'color', 'zorder', 'linewidth', 'as_steps')):
            self._update_visual_attributes()
    ProfileLayerArtist._update_profile = _update_profile

app = GlueApplication()
app.resize(1600, 1000)
app.show()
tick = QTimer(); tick.start(2)  # wakes WaitForMoreEvents so the loop releases the GIL between events


def pump(seconds):
    end = time.perf_counter() + seconds
    while time.perf_counter() < end:
        QApplication.processEvents(QEventLoop.WaitForMoreEvents)


def pump_until(cond, timeout=5.0):
    end = time.perf_counter() + timeout
    while not cond() and time.perf_counter() < end:
        QApplication.processEvents(QEventLoop.WaitForMoreEvents)


def idle(v, quiet=0.3, timeout=30):
    """Pump until no layer computes and no draw happened for `quiet` s."""
    t0 = time.perf_counter()
    while time.perf_counter() - t0 < timeout:
        pump(0.05)
        busy = any(getattr(la, 'is_computing', False) for la in v.layers)
        last = max([d[2] for d in draws if d[0] is canvas] + [0])
        if not busy and time.perf_counter() - last > quiet and time.perf_counter() - t0 > quiet:
            return time.perf_counter() - t0


pump(0.5)
d = load(kind)
app.data_collection.append(d)
cid = d.main_components[0]
raw = d.get_component(cid).data
v = app.new_data_viewer(ProfileViewer)
v.viewer_size = (800, 450)
v.large_data_size = None  # the "Add large data set?" prompt, answered yes
canvas = v.figure.canvas
pump(0.5)
print(f'mode {mode}; canvas {canvas.width()}x{canvas.height()} dpr {canvas.devicePixelRatioF()}', flush=True)


class Ended(HubListener):
    def __init__(self):
        self.times = []
        d.hub.subscribe(self, ComputationEndedMessage, handler=lambda m: self.times.append((m.sender, time.perf_counter())))


ended = Ended()

# ---- Finding 2: add_data -------------------------------------------------------------------------
n0, r0 = len(rec.calls), len(runs)
t = time.perf_counter()
v.add_data(d)
blocked = time.perf_counter() - t
idle_t = idle(v)
print(f'\n== add_data(cube) [{mode}]: main thread blocked {blocked*1e3:.0f} ms; idle after {(blocked + idle_t)*1e3:.0f} ms; '
      f'function={v.state.function}; x_att={v.state.x_att}; worker runs {len(runs) - r0}; peak {rss_mb():.0f} MB', flush=True)
rec.report(n0)

cube_layer = [s for s in v.state.layers if s.layer is d][0]
wl = d.ndim - 1
n0 = len(rec.calls)
cube_layer.visible = False
v.state.x_att = d.world_component_ids[wl]
print(f'== hide cube layer, x_att -> {v.state.x_att}: idle after {idle(v)*1e3:.0f} ms', flush=True)
rec.report(n0)

# ---- Finding 1: point moves ----------------------------------------------------------------------
mid = [s // 2 for s in d.shape]


def pixel_slices(k):
    p = list(mid)
    a, b = (0, 1) if d.ndim == 3 else (1, 2)
    p[a] = (mid[a] + 7 * k) % d.shape[a]
    p[b] = (mid[b] + 3 * k) % d.shape[b]
    sl = [slice(i, i + 1) for i in p]
    sl[wl] = slice(None)
    return sl


group = app.data_collection.new_subset_group(label='Point', subset_state=PixelSubsetState(d, pixel_slices(0)))
idle(v)
sub_artist = [la for la in v.layers if la.state.layer is group.subsets[0]][0]
print('subset artist', type(sub_artist).__name__, 'layer.size', sub_artist.state.layer.size, flush=True)

res = []
for k in range(1, 23):
    sl = pixel_slices(k)
    expected = np.asarray(raw[tuple(sl)], dtype=float).ravel()
    shown = [None]

    def check(c):
        if c is canvas and shown[0] is None:
            y = np.asarray(sub_artist.plot_artist.get_ydata(), dtype=float)
            if y.shape == expected.shape and np.allclose(y, expected, equal_nan=True):
                shown[0] = time.perf_counter()

    hook[0] = check
    nd, nr, ne = len(draws), len(runs), len(ended.times)
    t0 = time.perf_counter()
    group.subset_state = PixelSubsetState(d, sl)
    pump_until(lambda: shown[0] is not None)
    pump(0.35)  # let any further worker rounds and draws of this move finish
    hook[0] = None
    my = [x for x in draws[nd:] if x[0] is canvas]
    res.append(((shown[0] or np.nan) - t0, len(runs) - nr, len([e for e in ended.times[ne:] if e[0] is sub_artist]),
                len(my), sum(x[2] - x[1] for x in my)))
r = res[2:]
med = lambda i: statistics.median(x[i] for x in r)
print(f'\n== point move [{mode}] n={len(r)} (2 warm-up dropped): new spectrum drawn after median {med(0)*1e3:.1f} ms '
      f'(min {min(x[0] for x in r)*1e3:.1f}, max {max(x[0] for x in r)*1e3:.1f}); per move: worker/compute runs {med(1)}, '
      f'ComputationEnded(subset) {med(2)}, spectrum draws {med(3)} ({med(4)*1e3:.1f} ms of drawing)', flush=True)
print('   single draw durations (ms):', np.round(np.median([x[2] - x[1] for x in draws if x[0] is canvas][-20:]) * 1e3, 1))

# ---- Finding 2: Function changes with the cube layer visible (installed code only) -----------------
if mode == 'glue':
    cube_layer.visible = True
    idle(v)
    for func in ('mean', 'median', 'maximum', 'mean'):
        n0 = len(rec.calls)
        t = time.perf_counter()
        v.state.function = func
        blocked = time.perf_counter() - t
        it = idle(v)
        print(f'== function -> {func} (cube visible): setter blocked main thread {blocked*1e3:.0f} ms; idle after {(blocked+it)*1e3:.0f} ms', flush=True)
        rec.report(n0)
print(f'final peak RSS {rss_mb():.0f} MB')
app.close()
