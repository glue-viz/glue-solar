"""Finding 4 with the Histogram viewer's default range (min/max from 10000 samples) and glue's xmax nudge."""
import sys, tracemalloc, warnings
import numpy as np
from vcommon import load, bench, rss_mb
warnings.simplefilter('ignore')
from glue.viewers.image.pixel_selection_subset_state import PixelSubsetState
from fast_histogram import histogram1d

d = load(sys.argv[1])
cid = d.main_components[0]
raw = d.get_component(cid).data
lo = d.compute_statistic('minimum', cid, random_subset=10000)
hi = d.compute_statistic('maximum', cid, random_subset=10000)
nudged = (lo, hi + 10 * np.spacing(hi))
fin = np.isfinite(raw)
print(f'range ({lo}, {hi}); finite fraction {fin.mean():.4f}; in-range fraction {((raw >= lo) & (raw <= hi)).mean():.4f}')
del fin


def peak(fn):
    tracemalloc.start(); tracemalloc.reset_peak(); fn()
    p = tracemalloc.get_traced_memory()[1]; tracemalloc.stop(); return p / 2**20


mid = [s // 2 for s in d.shape]
sl = [slice(i, i + 1) for i in mid]; sl[-1] = slice(None)
point = PixelSubsetState(d, sl)
for bins in (15, 30):
    g = lambda: d.compute_histogram([cid], range=[(lo, hi)], bins=[bins], subset_state=point)
    p = lambda: histogram1d(np.asarray(point.to_array(d, cid)).ravel(), range=nudged, bins=bins)
    bench(f'point subset glue bins={bins}', g, n=10)
    bench(f'point subset proto bins={bins}', p, n=10)
    print('   equal:', np.array_equal(g(), p()), f'glue peak {peak(g):.0f} MiB')
g = lambda: d.compute_histogram([cid], range=[(lo, hi)], bins=[15])
p = lambda: histogram1d(raw.ravel(), range=nudged, bins=15)
bench('whole cube glue', g, n=3)
print(f'   tracemalloc peak {peak(g):.0f} MiB')
bench('whole cube proto histogram1d(raw)', p, n=3)
print(f'   tracemalloc peak {peak(p):.1f} MiB; equal: {np.array_equal(g(), p())}')
bench('whole cube glue random_subset=1e6', lambda: d.compute_histogram([cid], range=[(lo, hi)], bins=[15], random_subset=1000000), n=3)
print(f'final peak RSS {rss_mb():.0f} MB')
