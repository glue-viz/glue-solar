"""Skeptic re-measurement of finding 3 (session save). Stub savers registered in this process only.
usage: v_session.py dc1|dc10|app2"""
import cProfile
import glob
import os
import pstats
import resource
import statistics
import sys
import time

sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
import glue_solar  # noqa: E402
import astropy.units as u  # noqa: E402
import numpy as np  # noqa: E402
from glue.core import DataCollection  # noqa: E402
from glue.core.state import GlueSerializer, saver  # noqa: E402
from glue.utils import unbroadcast  # noqa: E402
from glue_qt.utils import get_qapp  # noqa: E402
from glue_solar.sources.loaders import iris as L  # noqa: E402

print("glue_solar:", glue_solar.__file__, flush=True)
qapp = get_qapp()
D = "/Users/nabil/DATA/IRIS"
case = sys.argv[1]
rss = lambda: resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 2**20  # noqa: E731

if case == "dc1":
    data = L.raster_data(sorted(glob.glob(f"{D}/*4000005156_raster/*.fits"))[:1], ["Si IV 1403"])
elif case == "dc10":
    data = L.raster_data(sorted(glob.glob(f"{D}/*3602506433_raster/*.fits"))[:10], ["Si IV 1403"])
else:
    data = L.raster_data(sorted(glob.glob(f"{D}/*3602506433_raster/*.fits"))[:2], ["Si IV 1403"])

if case == "app2":
    from glue_qt.app import GlueApplication
    from glue_solar.quicklook import quicklook
    obj = GlueApplication()
    obj.resize(1600, 1000)
    obj.show()
    obj.data_collection.extend(data)
    L.keep_hpc_linked(obj.data_collection)
    quicklook(obj, data)
    for _ in range(20):
        qapp.processEvents()
else:
    obj = DataCollection(data)
    L.keep_hpc_linked(obj)

arrays = [(cid.label, d.get_component(cid).data) for d in data for cid in d.main_components]
full = sum(a.nbytes for _, a in arrays)
small = sum(unbroadcast(a).nbytes for _, a in arrays)
bcast = sum(a.nbytes for _, a in arrays if 0 in a.strides)
print(f"{case}: {len(data)} datasets; component bytes as saved {full / 1e6:.0f} MB, of which zero-stride "
      f"{bcast / 1e6:.0f} MB ({100 * bcast / full:.0f}%); unbroadcast {small / 1e6:.0f} MB", flush=True)
for lab, a in arrays[:4]:
    print(f"    {lab[:30]:30s} {a.dtype} {a.shape} strides {a.strides}")

try:
    GlueSerializer(obj, include_data=False).dumps()
    print("no stubs: saved fine")
except Exception as e:  # noqa: BLE001
    print(f"no stubs: {type(e).__name__}: {str(e)[:200]}", flush=True)


@saver(L._GlueWCS)
def _wcs_stub(wcs, context):
    return {}


@saver(u.Quantity)
def _q_stub(q, context):
    return dict(value=context.do(np.asarray(q.value)), unit=str(q.unit))


class OnePass(GlueSerializer):
    def do_all(self):
        out = {}
        while len(out) != len(self._objs):
            for k, o in list(self._objs.items()):
                if k not in out:
                    out[k] = self.do(o)
        return out


def bench(cls, include_data=False, n=3):
    ts = []
    for _ in range(n):
        t = time.perf_counter()
        s = cls(obj, include_data=include_data).dumps()
        ts.append(time.perf_counter() - t)
        size = len(s)
        del s
    print(f"RESULT {case} {cls.__name__} include_data={include_data}: median {statistics.median(ts):.3f} s of {n} "
          f"[{', '.join(f'{x:.3f}' for x in ts)}]; JSON {size / 1e6:.0f} MB; rss_peak {rss():.0f} MB", flush=True)
    return statistics.median(ts)


n = 1 if case == "dc1" else 3
bench(GlueSerializer, False, n)
bench(GlueSerializer, True, 1)
bench(OnePass, False, n)
a = GlueSerializer(obj).dumps()
b = OnePass(obj).dumps()
print("one-pass JSON identical:", a == b, flush=True)
del a, b
if case == "app2":
    path = os.path.join(os.environ["HOME"], "s.glu")
    ts = []
    for _ in range(3):
        t = time.perf_counter()
        obj.save_session(path)
        ts.append(time.perf_counter() - t)
    print(f"RESULT app.save_session: median {statistics.median(ts):.3f} s [{', '.join(f'{x:.3f}' for x in ts)}]; "
          f"file {os.path.getsize(path) / 1e6:.0f} MB", flush=True)

pr = cProfile.Profile()
pr.enable()
GlueSerializer(obj).dumps()
pr.disable()
st = pstats.Stats(pr)
for (f, line, fn), (cc, nc, tt, ct, _) in st.stats.items():
    if fn in ("_save_component", "_save_numpy", "b64encode", "do_all", "save", "dumps") or "b2a_base64" in fn:
        print(f"PROFILE {fn} ({os.path.basename(f)}:{line}): {nc} calls, cum {ct:.3f} s")
ncomp = sum(len(d.main_components) for d in data)
print(f"main components in collection: {ncomp}; profile total {st.total_tt:.3f} s", flush=True)
