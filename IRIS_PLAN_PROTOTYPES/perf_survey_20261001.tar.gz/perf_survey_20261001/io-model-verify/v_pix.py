"""Where the time inside equivalent_pixel_cids goes (finding 6 cause check). 102 unlinked datasets, one update."""
import cProfile
import glob
import pstats
import sys

sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
import glue_solar  # noqa: E402,F401
from glue.core import DataCollection  # noqa: E402
from glue_qt.utils import get_qapp  # noqa: E402
from glue_solar.sources.loaders import iris as L  # noqa: E402

get_qapp()
D = "/Users/nabil/DATA/IRIS"
data = (L.raster_data(sorted(glob.glob(f"{D}/*4000005156_raster/*.fits")), ["Si IV 1403"])
        + [L.image_data(glob.glob(f"{D}/*4000005156_SJI_2796_t000_deconvolved.fits.gz")[0])]
        + L.raster_data(sorted(glob.glob(f"{D}/*3602506433_raster/*.fits")), ["Si IV 1403"]))
dc = DataCollection(data)
pr = cProfile.Profile()
pr.enable()
for _ in range(3):
    dc._link_manager.update_externally_derivable_components()
pr.disable()
st = pstats.Stats(pr)
st.sort_stats("tottime").print_stats(12)
st.print_callees("equivalent_pixel_cids")
