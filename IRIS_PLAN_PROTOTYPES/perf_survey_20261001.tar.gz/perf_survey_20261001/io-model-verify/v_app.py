"""Skeptic app-level re-measurement (findings 1, 2, 5). One action per process.
usage: v_app.py browser|add_datasets|add_datasets_nomodel|one_more|remove25 [prof]"""
import cProfile
import glob
import pstats
import resource
import sys
import time

sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
import glue_solar  # noqa: E402
from glue.core import Data  # noqa: E402
from glue.core import message as m  # noqa: E402
from glue_qt.app import GlueApplication  # noqa: E402
from glue_qt.utils import get_qapp  # noqa: E402
from glue_solar.quicklook import quicklook  # noqa: E402
from glue_solar.sources.loaders import iris as L  # noqa: E402

scen = sys.argv[1]
PROF = "prof" in sys.argv
D = "/Users/nabil/DATA/IRIS"
qapp = get_qapp()


def settle(n=30):
    for _ in range(n):
        qapp.processEvents()


obs1 = L.raster_data(sorted(glob.glob(f"{D}/*4000005156_raster/*.fits")), ["Si IV 1403"]) + [
    L.image_data(glob.glob(f"{D}/*4000005156_SJI_2796_t000_deconvolved.fits.gz")[0])]
nscan = 25 if scen == "remove25" else 99
obs2 = L.raster_data(sorted(glob.glob(f"{D}/*3602506433_raster/*.fits"))[:nscan], ["Si IV 1403"])
app = GlueApplication()
app.resize(1600, 1000)
app.show()
dc = app.data_collection
dc.extend(obs1)
L.keep_hpc_linked(dc)
quicklook(app, obs1)
settle()
if scen in ("one_more", "remove25"):
    dc.extend(obs2)
    L.keep_hpc_linked(dc)
    settle()
if scen == "add_datasets_nomodel":
    # what-if: the data tree model does not react per message (upper bound of the glue-qt fix)
    model = app._layer_widget.ui.layerTree._model
    dc.hub.unsubscribe(model, m.DataCollectionAddMessage)
    dc.hub.unsubscribe(model, m.SubsetCreateMessage)
print(f"glue_solar {glue_solar.__file__}; {len(dc)} datasets, {len(dc.external_links)} links, "
      f"{len(dc.subset_groups)} subset groups", flush=True)


def act():
    if scen == "browser":
        dc.extend(obs2)
        L.keep_hpc_linked(dc)
    elif scen.startswith("add_datasets"):
        app.add_datasets(obs2)
    elif scen == "one_more":
        d0 = obs2[0]
        dc.append(Data(label="extra", coords=d0.coords, flux=d0.get_data(d0.main_components[0])))
        L.keep_hpc_linked(dc)
    elif scen == "remove25":
        for d in obs2:
            dc.remove(d)
    settle()


pr = cProfile.Profile() if PROF else None
t = time.perf_counter()
if pr:
    pr.enable()
act()
if pr:
    pr.disable()
wall = time.perf_counter() - t
rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 2**20
print(f"RESULT {scen}{' (cProfile)' if PROF else ''}: {wall:.3f} s wall; rss_peak {rss:.0f} MB", flush=True)
if pr:
    st = pstats.Stats(pr)
    keys = ("update_externally_derivable_components", "discover_links", "_on_add_data", "_on_add_subset",
            "layer_icon", "invalidate", "lstat", "find_possible_links", "equivalent_pixel_cids", "select_indices",
            "remove_link", "add_link")
    agg = {}
    for (f, line, fn), (cc, nc, tt, ct, _) in st.stats.items():
        if fn in keys or ("lstat" in fn):
            a = agg.setdefault(fn, [0, 0.0])
            a[0] += nc
            a[1] = max(a[1], ct)
    print(f"PROFILE total {st.total_tt:.2f} s: " + "; ".join(f"{k} {v[0]} calls cum {v[1]:.2f}" for k, v in agg.items()),
          flush=True)
