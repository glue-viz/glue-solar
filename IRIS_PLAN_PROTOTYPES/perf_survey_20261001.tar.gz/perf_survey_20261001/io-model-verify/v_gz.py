"""Skeptic re-measurement of finding 4 (SJI .fits.gz decompressed several times). Measure only."""
import cProfile
import gc
import glob
import gzip
import io
import pstats
import statistics
import sys
import time

sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
import glue_solar  # noqa: E402
from astropy.io import fits  # noqa: E402
from glue.core.data_factories import load_data  # noqa: E402
from glue.core.data_factories.fits import fits_reader  # noqa: E402
from glue_qt.utils import get_qapp  # noqa: E402
from irispy.io import read_files  # noqa: E402
from glue_solar.sources.iris import is_iris_fits  # noqa: E402
from glue_solar.sources.loaders.iris import image_data  # noqa: E402

print("glue_solar:", glue_solar.__file__, flush=True)
get_qapp()
PATH = glob.glob("/Users/nabil/DATA/IRIS/*4000255147_SJI_1400_t000.fits.gz")[0]

# count decompressed bytes (in-process wrapper of the stdlib reader; nothing on disk changes)
COUNT = [0]
_orig = gzip._GzipReader.read


def _counting_read(self, size=-1):
    b = _orig(self, size)
    COUNT[0] += len(b)
    return b


gzip._GzipReader.read = _counting_read
with gzip.open(PATH) as f:
    UNC = len(f.read())
print(f"uncompressed size {UNC / 1e6:.1f} MB", flush=True)


def all_hdus_once():
    with fits.open(io.BytesIO(gzip.open(PATH).read())) as h:
        return [x.data for x in h]


def open_primary():
    with fits.open(PATH) as h:
        return h[0].data


def header_fromfile():
    with gzip.open(PATH) as f:
        return fits.Header.fromfile(f)["TELESCOP"]


CASES = {
    "gzip decompress once": lambda: gzip.open(PATH).read(),
    "glue load_data (auto)": lambda: load_data(PATH),
    "glue-solar image_data": lambda: image_data(PATH),
    "irispy read_files": lambda: read_files(PATH, memmap=False, uncertainty=False),
    "glue fits_reader": lambda: fits_reader(PATH),
    "glue-solar is_iris_fits": lambda: is_iris_fits(PATH),
    "fits.open + primary data": open_primary,
    "decompress once + fits.open(BytesIO) + all HDU data": all_hdus_once,
    "Header.fromfile(gzip.open) primary header only": header_fromfile,
}
for name, fn in CASES.items():
    fn()  # warm-up
    gc.collect()
    ts, passes = [], []
    for _ in range(3):
        COUNT[0] = 0
        t = time.perf_counter()
        r = fn()
        ts.append(time.perf_counter() - t)
        passes.append(COUNT[0] / UNC)
        del r
        gc.collect()
    print(f"RESULT {name}: median {statistics.median(ts):.3f} s of 3 [{', '.join(f'{x:.3f}' for x in ts)}]; "
          f"decompressed {statistics.median(passes):.2f}x the file", flush=True)

pr = cProfile.Profile()
pr.enable()
load_data(PATH)
pr.disable()
st = pstats.Stats(pr)
zl = {k: v for k, v in st.stats.items() if "decompress" in str(k)}
print(f"PROFILE load_data: total tt {st.total_tt:.2f} s; decompress tottime {sum(v[2] for v in zl.values()):.2f} s "
      f"({100 * sum(v[2] for v in zl.values()) / st.total_tt:.0f}%)", flush=True)
for k, v in zl.items():
    print("   ", k, f"ncalls {v[1]} tottime {v[2]:.3f}")
