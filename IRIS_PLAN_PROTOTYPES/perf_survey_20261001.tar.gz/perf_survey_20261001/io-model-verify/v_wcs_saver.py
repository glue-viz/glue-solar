"""Does a glue-solar dataset save with only the Quantity stub (is _GlueWCS a blocker too)?"""
import glob, sys
sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
import glue_solar, numpy as np, astropy.units as u
from glue.core import DataCollection
from glue.core.state import GlueSerializer, saver
from glue_qt.utils import get_qapp
from glue_solar.sources.loaders import iris as L
get_qapp()
dc = DataCollection(L.raster_data(sorted(glob.glob("/Users/nabil/DATA/IRIS/*3602506433_raster/*.fits"))[:1], ["Si IV 1403"]))
@saver(u.Quantity)
def _q(q, context):
    return dict(value=context.do(np.asarray(q.value)), unit=str(q.unit))
try:
    GlueSerializer(dc).dumps(); print("saved with only the Quantity stub")
except Exception as e:
    print(f"with only the Quantity stub: {type(e).__name__}: {str(e)[:200]}")
