"""Skeptic re-measurement of the link-manager findings (1, 2, 6). Measure only; nothing in glue is patched."""
import cProfile
import glob
import pstats
import resource
import statistics
import sys
import time
from collections import defaultdict

sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
import glue_solar  # noqa: E402

from glue.core import Data, DataCollection  # noqa: E402
from glue.core.link_manager import discover_links, equivalent_pixel_cids  # noqa: E402
from glue_qt.utils import get_qapp  # noqa: E402
from glue_solar.sources.loaders import iris as L  # noqa: E402

print("glue_solar:", glue_solar.__file__, flush=True)
D = "/Users/nabil/DATA/IRIS"
TWO = sorted(glob.glob(f"{D}/*4000005156_raster/*.fits"))
SJI = glob.glob(f"{D}/*4000005156_SJI_2796_t000_deconvolved.fits.gz")[0]
S99 = sorted(glob.glob(f"{D}/*3602506433_raster/*.fits"))
qapp = get_qapp()
WHAT = sys.argv[1:] or ["all"]


def rss():
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 2**20


t0 = time.perf_counter()
BASE = L.raster_data(TWO, ["Si IV 1403"]) + [L.image_data(SJI)] + L.raster_data(S99, ["Si IV 1403"])
print(f"loaded {len(BASE)} in {time.perf_counter() - t0:.1f} s, rss peak {rss():.0f} MB", flush=True)


def copy(d):
    n = Data(label=d.label)
    n.coords = d.coords
    n.meta = d.meta
    for cid in d.main_components:
        n.add_component(d.get_component(cid), cid.label)
    return n


def linked(k):
    dc = DataCollection([copy(d) for d in BASE[:k]])
    L.keep_hpc_linked(dc)
    qapp.processEvents()
    return dc


def med(setup, act, n=3, label=""):
    ts = []
    for _ in range(n):
        s = setup()
        t = time.perf_counter()
        act(s)
        qapp.processEvents()
        ts.append(time.perf_counter() - t)
    m = statistics.median(ts)
    print(f"RESULT {label}: median {m:.3f} s of {n} [{', '.join(f'{x:.3f}' for x in ts)}] rss_peak {rss():.0f} MB",
          flush=True)
    return m


def prof(setup, act, label, funcs):
    s = setup()
    pr = cProfile.Profile()
    t = time.perf_counter()
    pr.enable()
    act(s)
    qapp.processEvents()
    pr.disable()
    wall = time.perf_counter() - t
    st = pstats.Stats(pr)
    out = {}
    for (f, line, fn), (cc, nc, tt, ct, _) in st.stats.items():
        if fn in funcs:
            out.setdefault(fn, [0, 0.0])
            out[fn][0] += nc
            out[fn][1] = max(out[fn][1], ct)
    print(f"PROFILE {label}: profiled wall {wall:.2f} s; total tt {st.total_tt:.2f} s; "
          + "; ".join(f"{k}: {v[0]} calls cum {v[1]:.2f}" for k, v in out.items()), flush=True)


def discover_worklist(data, links):
    """Level-by-level worklist; same minimal depths as glue's discover_links."""
    known = set(data.main_components + data.coordinate_components)
    missing, waiting, ready = {}, defaultdict(list), []
    for link in links:
        need = set(link.get_from_ids()) - known
        missing[link] = len(need)
        for c in need:
            waiting[c].append(link)
        if not need:
            ready.append(link)
    out = {}
    while ready:
        new = {}
        for link in ready:
            to = link.get_to_id()
            if to not in known and to not in new:
                new[to] = link
        known.update(new)
        out.update(new)
        ready = []
        for c in new:
            for link in waiting.pop(c, ()):
                missing[link] -= 1
                if missing[link] == 0:
                    ready.append(link)
    return out


N = len(BASE)

if "all" in WHAT or "append" in WHAT:
    # Finding 1
    med(lambda: DataCollection([copy(d) for d in BASE]), L.keep_hpc_linked, 3, f"keep_hpc_linked on {N} unlinked")
    for k in (12, 27, 52, N):
        med(lambda k=k: (linked(k - 1), copy(BASE[k - 1])), lambda s: s[0].append(s[1]), 3,
            f"append 1 to linked collection of {k - 1}")
    prof(lambda: (linked(N - 1), copy(BASE[N - 1])), lambda s: s[0].append(s[1]), f"append 1 to linked {N - 1}",
         {"discover_links", "accessible_links", "get_from_ids", "update_externally_derivable_components",
          "equivalent_pixel_cids", "_links", "_inverse_links"})

if "all" in WHAT or "proto" in WHAT:
    for k in (10, 25, 50, N):
        dc = linked(k)
        lm = dc._link_manager
        links = lm._links | lm._inverse_links
        derivable = [len(discover_links(d, links)) for d in dc]
        ts_g, ts_w = [], []
        for _ in range(3):
            t = time.perf_counter()
            res_g = [discover_links(d, links) for d in dc]
            ts_g.append(time.perf_counter() - t)
            t = time.perf_counter()
            res_w = [discover_worklist(d, links) for d in dc]
            ts_w.append(time.perf_counter() - t)
        same = all(set(a) == set(b) for a, b in zip(res_g, res_w))
        # links chosen may differ on ties; check each chosen link is valid (output matches)
        valid = all(lk.get_to_id() is c for r in res_w for c, lk in r.items())
        t = time.perf_counter()
        lm.update_externally_derivable_components()
        full = time.perf_counter() - t
        t = time.perf_counter()
        for d1 in dc:
            for d2 in dc:
                if d1 is not d2:
                    equivalent_pixel_cids(d2, d1)
        pix = time.perf_counter() - t
        print(f"PROTO k={k}: {len(links)} links, mean derivable {statistics.mean(derivable):.0f}; glue discover over "
              f"all datasets median {statistics.median(ts_g):.4f} s, worklist {statistics.median(ts_w):.4f} s "
              f"({statistics.median(ts_g) / statistics.median(ts_w):.0f}x); same cid sets {same}, valid {valid}; "
              f"full update {full:.3f} s; pairwise equivalent_pixel_cids pass {pix:.3f} s", flush=True)
        del dc

if "all" in WHAT or "remove" in WHAT:
    # Finding 2
    for k in (13, 28, 53):
        med(lambda k=k: linked(k), lambda dc: dc.remove(dc[len(dc) - 1]), 3, f"remove 1 non-anchor from linked {k}")
    for k in (13, 28):
        med(lambda k=k: linked(k), lambda dc: dc.remove(dc[0]), 3, f"remove anchor from linked {k} incl relink")
    prof(lambda: linked(28), lambda dc: dc.remove(dc[0]), "remove anchor from linked 28",
         {"remove_link", "update_externally_derivable_components", "discover_links"})

    def fixed_anchor(dc):
        # what the batched fix does: drop the anchor's links in one update, then remove, then relink
        lm = dc._link_manager
        anchor = dc[0]
        drop = [lk for lk in lm._external_links if any(c in lk and c.parent is anchor for c in anchor.components)]
        lm.remove_link(drop)
        dc.remove(anchor)

    for k in (13, 28, 53):
        med(lambda k=k: linked(k), fixed_anchor, 3, f"SIMULATED batched fix: remove anchor from linked {k} incl relink")
    med(lambda: linked(53), lambda dc: dc.remove(dc[0]), 1, "remove anchor from linked 53 incl relink")
    med(lambda: linked(28), lambda dc: dc.clear(), 3, "clear() of linked 28")
    med(lambda: linked(53), lambda dc: dc.clear(), 1, "clear() of linked 53")
    med(lambda: linked(53), lambda dc: [dc.remove(d) for d in list(dc)[3:]], 1, "remove 50 scans one by one, linked 53")
    med(lambda: DataCollection([copy(d) for d in BASE[:53]]), lambda dc: dc.remove(dc[52]), 3,
        "remove 1 from unlinked 53")

if "all" in WHAT or "one" in WHAT:
    # Finding 6
    med(lambda: (DataCollection(), [copy(d) for d in BASE]), lambda s: [s[0].append(d) for d in s[1]], 3,
        f"append x{N} one at a time, no links")
    med(lambda: (DataCollection(), [copy(d) for d in BASE]), lambda s: s[0].extend(s[1]), 5, f"extend({N}), no links")
    prof(lambda: (DataCollection(), [copy(d) for d in BASE]), lambda s: [s[0].append(d) for d in s[1]],
         f"append x{N} one at a time", {"equivalent_pixel_cids", "update_externally_derivable_components",
                                        "discover_links"})
    prof(lambda: (DataCollection(), [copy(d) for d in BASE]), lambda s: s[0].extend(s[1]), f"extend({N})",
         {"equivalent_pixel_cids", "update_externally_derivable_components", "discover_links"})
print(f"done, rss peak {rss():.0f} MB", flush=True)
