"""
Split of the subset mask and the main image work in one SJI 1400 viewer (full tab, 1250x799) per Pixel-point move.
15 moves, medians. Also: what a bounding-box-only mask computation would cost (get_sliced_data on a 3x3 view).
"""
import time
from collections import defaultdict

import matplotlib.image as mimage
import numpy as np
import vc
from glue.viewers.image import composite_array as ca
from glue.viewers.image import frb_artist
from glue.viewers.image import layer_artist as la
from glue.viewers.image import state as st
from glue.viewers.image.pixel_selection_subset_state import PixelSubsetState
from glue_qt.viewers.image import ImageViewer

T = defaultdict(float)


def timed(owner, name, key):
    orig = getattr(owner, name)

    def w(self, *a, **k):
        t = time.perf_counter()
        try:
            return orig(self, *a, **k)
        finally:
            T[key(self)] += time.perf_counter() - t
    setattr(owner, name, w)


def kind(artist):
    return "image" if isinstance(getattr(artist, "_array_maker", None), ca.CompositeArray) else "subset"


timed(frb_artist.FRBArtist, "make_image", lambda s: f"{kind(s)}: FRBArtist.make_image (all)")
timed(mimage._ImageBase, "_make_image", lambda s: f"{kind(s)}:   mpl _make_image (resample+composite)")
timed(la.ImageSubsetArray, "__call__", lambda s: "subset:   ImageSubsetArray() (mask+dstack+uint8)")
timed(st.ImageSubsetLayerState, "get_sliced_data", lambda s: "subset:     get_sliced_data (mask FRB)")
timed(ca.CompositeArray, "__call__", lambda s: "image:   CompositeArray() (FRB+stretch+cmap)")

app = vc.app()
sji = vc.sji1400()
app.data_collection.append(sji)
v = app.new_data_viewer(ImageViewer, data=sji)
app.current_tab.tileSubWindows()
vc.settle(); time.sleep(0.5); vc.settle()
c = v.figure.canvas
print(f"canvas {c.width()}x{c.height()}")
group = app.data_collection.new_subset_group(
    label="Point", subset_state=PixelSubsetState(sji, [slice(None), slice(200, 201), slice(190, 191)]))
vc.settle()
per, dr = defaultdict(list), []
for i in range(16):
    T.clear(); vc.DRAWS.clear()
    y, x = 60 + (i * 13) % 250, 60 + (i * 17) % 250
    group.subset_state = PixelSubsetState(sji, [slice(None), slice(y, y + 1), slice(x, x + 1)])
    vc.settle()
    if i:
        dr.append(sum(d for _, d in vc.DRAWS))
        for k, val in T.items():
            per[k].append(val)
print(f"canvas draw {vc.med(dr)*1e3:.1f} ms")
for k in sorted(per):
    print(f"  {k:52s} {vc.med(per[k])*1e3:6.1f} ms  {vc.med(per[k])/vc.med(dr)*100:4.0f}%")

sl = [lyr for lyr in v.layers if lyr.layer is not sji][0]
ny, nx = 799, 1250
full = [(-0.5, 416.5, ny), (-0.5, 387.5, nx)]
y0, x0 = group.subset_state.slices[1].start, group.subset_state.slices[2].start
box = [(y0 - 1.5, y0 + 1.5, 3), (x0 - 1.5, x0 + 1.5, 3)]
for name, b in (("full view", full), ("3x3 px bbox", box)):
    ts = []
    for _ in range(10):
        t = time.perf_counter(); m = sl.state.get_sliced_data(bounds=b); ts.append(time.perf_counter() - t)
    print(f"get_sliced_data {name:12s} {vc.med(ts)*1e3:6.2f} ms  shape {np.shape(m)} selected px {int(np.sum(m))}")
