"""
Simulated 2 s slider drag (120 positions at 60 Hz) on one Image viewer at 800x500.
Input: a 1 ms QTimer posts due positions as events; 'each' posts every due position (no motion
compression), 'latest' only the newest due one. Each event does what QSlider does on a drag move:
setSliderPosition(v) while sliderDown. Release = setSliderDown(False).
Slider modes: throttle (glue-solar 2fdb847 as loaded), glueqt (tracking on, sliderMoved hooks removed),
coalesce (tracking off + 0 ms single-shot apply of sliderPosition).
usage: v_drag.py sji|siiv   (2 runs per configuration)
"""
import sys
import time

import vc
from glue_qt.viewers.image import ImageViewer
from glue_solar.tools import _throttle_slice_sliders
from qtpy import QtCore, QtWidgets

kind = sys.argv[1]
app = vc.app()
data = vc.sji1400() if kind == "sji" else vc.siiv()
app.data_collection.append(data)
v = app.new_data_viewer(ImageViewer, data=data)
v.parent().resize(800, 500)
vc.settle(); time.sleep(0.5); vc.settle()
axis = next(i for i in range(data.ndim) if i not in (v.state.x_att.axis, v.state.y_att.axis))
[slider] = v.options_widget().findChildren(QtWidgets.QSlider, "value_slice_center")
print(f"{kind}: slider tracking as loaded {slider.hasTracking()}", flush=True)
STEP = 2 if kind == "sji" else 4
shown = []
v.figure.canvas.mpl_connect("draw_event", lambda e: shown.append((time.perf_counter(), v.state.slices[axis])))
qa = QtWidgets.QApplication.instance()
ET = QtCore.QEvent.Type(QtCore.QEvent.registerEventType())


class Pos(QtCore.QEvent):
    def __init__(self, val):
        super().__init__(ET)
        self.val = val


class Sink(QtCore.QObject):
    released = None

    def event(self, e):
        if e.type() != ET:
            return super().event(e)
        if e.val is None:
            Sink.released = time.perf_counter()
            slider.setSliderDown(False)
        else:
            slider.setSliderPosition(e.val)
        return True


sink = Sink()


def set_mode(mode):
    try:
        slider.sliderMoved.disconnect()
    except (TypeError, RuntimeError):
        pass
    slider.setTracking(True)
    if mode == "throttle":
        _throttle_slice_sliders(v)
    elif mode == "coalesce":
        slider.setTracking(False)
        t = QtCore.QTimer(slider)
        t.setSingleShot(True)
        t.setInterval(0)
        t.timeout.connect(lambda: slider.setValue(slider.sliderPosition()))
        slider.sliderMoved.connect(lambda _p: t.isActive() or t.start())


def drag(delivery, n=120, rate=60):
    slider.setValue(0); vc.settle()
    due = [(k / rate, (k + 1) * STEP) for k in range(n)]
    state = {"posted": 0}
    Sink.released = None
    shown.clear(); vc.DRAWS.clear()
    slider.setSliderDown(True)
    t0 = time.perf_counter()

    def pump():
        now = time.perf_counter() - t0
        k = state["posted"]
        ready = [i for i in range(k, n) if due[i][0] <= now]
        if ready:
            for i in (ready if delivery == "each" else ready[-1:]):
                QtCore.QCoreApplication.postEvent(sink, Pos(due[i][1]))
            state["posted"] = ready[-1] + 1
        if state["posted"] >= n and now >= n / rate:
            QtCore.QCoreApplication.postEvent(sink, Pos(None))
            timer.stop()

    timer = QtCore.QTimer()
    timer.setInterval(1)
    timer.timeout.connect(pump)
    timer.start()
    while Sink.released is None:
        qa.processEvents(QtCore.QEventLoop.AllEvents, 5)
    vc.settle()
    end = time.perf_counter()
    rel = Sink.released
    during = [s for s in shown if s[0] <= rel]
    lags = [t - (t0 + due[max(0, min(n - 1, val // STEP - 1))][0]) for t, val in shown if val > 0]
    return (len(during) / (rel - t0), rel - t0, end - t0, vc.med(lags), max(lags) if lags else float("nan"),
            v.state.slices[axis] == due[-1][1], vc.med([d for _, d in vc.DRAWS]))


for mode in ("throttle", "glueqt", "coalesce"):
    set_mode(mode)
    for delivery in ("each", "latest"):
        for rep in range(2):
            r = drag(delivery)
            print(f"{kind} {mode:8s} {delivery:6s} run{rep}: draws/s during drag {r[0]:5.1f}; release at {r[1]:.2f} s; "
                  f"settled {r[2]:.2f} s; display lag median {r[3]*1e3:5.0f} ms max {r[4]*1e3:5.0f} ms; final ok {r[5]}; "
                  f"median draw {r[6]*1e3:.0f} ms", flush=True)
print(f"rss peak {vc.rss():.0f}MB")
