"""Own helpers for the hidpi-many re-measurements (process-local wrappers only, nothing patched on disk)."""
import glob
import resource
import statistics
import sys
import time

sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
import glue_solar  # noqa: E402

print("glue_solar", glue_solar.__file__, flush=True)

from glue_qt.viewers.matplotlib.widget import MplCanvas  # noqa: E402
from qtpy import QtCore, QtWidgets  # noqa: E402

D = "/Users/nabil/DATA/IRIS"
DRAWS, PAINTS = [], []
_d, _p = MplCanvas.draw, MplCanvas.paintEvent


def _draw(self, *a, **k):
    t = time.perf_counter()
    try:
        return _d(self, *a, **k)
    finally:
        DRAWS.append((self, time.perf_counter() - t))


def _paint(self, e):
    PAINTS.append(self)
    return _p(self, e)


MplCanvas.draw, MplCanvas.paintEvent = _draw, _paint


def med(x):
    return statistics.median(x) if x else float("nan")


def rss():
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1e6


def settle(quiet_needed=3, timeout=30):
    qa, quiet, t0 = QtWidgets.QApplication.instance(), 0, time.perf_counter()
    while quiet < quiet_needed and time.perf_counter() - t0 < timeout:
        n = len(DRAWS)
        qa.processEvents(QtCore.QEventLoop.AllEvents, 5)
        pend = any(getattr(w, "_draw_pending", False) for w in qa.allWidgets() if isinstance(w, MplCanvas))
        quiet = quiet + 1 if (n == len(DRAWS) and not pend) else 0


def app():
    from glue_qt.app import GlueApplication

    a = GlueApplication()
    a.resize(1600, 1000)
    a.show()
    settle()
    return a


def sji1400():
    from glue_solar.sources.loaders.iris import image_data

    d = image_data(glob.glob(f"{D}/*4000255147_SJI_1400_t000.fits.gz")[0])
    d = d[0] if isinstance(d, list) else d
    print("SJI", d.shape, type(d.coords).__name__, f"rss {rss():.0f}MB", flush=True)
    return d


def siiv():
    from glue_solar.sources.loaders.iris import raster_data

    d = raster_data(sorted(glob.glob(f"{D}/*4000255147_raster/*_r00000.fits")), windows=["Si IV 1403"])
    d = d[0] if isinstance(d, list) else d
    print("SiIV", d.shape, type(d.coords).__name__, f"rss {rss():.0f}MB", flush=True)
    return d
