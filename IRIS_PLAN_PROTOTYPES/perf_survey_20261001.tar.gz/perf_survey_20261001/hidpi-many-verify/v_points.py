"""
Re-measure Pixel-point moves with N tiled SJI 1400 viewers (one tab, 1600x1000 window), 15 moves each, medians:
  visible        - all viewers show the subset layer; split of the draw time
  subset hidden  - subset layer hidden in viewers 1..N-1; then my own emulation of 'skip redraw while hidden'
  hidden tab     - the viewers' tab is behind a second tab; then my own emulation of 'no Agg draw while not visible'
usage: v_points.py N
"""
import sys
import time
from collections import defaultdict

import vc
from astropy.visualization.wcsaxes import core as wcore
from glue.core.fixed_resolution_buffer import ARRAY_CACHE, PIXEL_CACHE
from glue.viewers.image import composite_array as ca
from glue.viewers.image import frb_artist
from glue.viewers.image import layer_artist as la
from glue.viewers.image.pixel_selection_subset_state import PixelSubsetState
from glue_qt.viewers.image import ImageViewer
from glue_qt.viewers.matplotlib.widget import MplCanvas

T = defaultdict(float)


def timed(owner, name, key):
    orig = getattr(owner, name)

    def w(self, *a, **k):
        t = time.perf_counter()
        try:
            return orig(self, *a, **k)
        finally:
            T[key(self) if callable(key) else key] += time.perf_counter() - t
    setattr(owner, name, w)
    return orig


timed(wcore.WCSAxes, "_update_tick_and_label_positions", "tick placement")
timed(frb_artist.FRBArtist, "make_image",
      lambda s: "make_image image" if isinstance(s._array_maker, ca.CompositeArray) else "make_image subset")
timed(la.ImageSubsetArray, "__call__", "  subset ImageSubsetArray()")
timed(ca.CompositeArray, "__call__", "  image CompositeArray()")
timed(la.ImageLayerArtist, "get_image_data", "    image FRB get_image_data")

FIX = set()
_upd = la.ImageSubsetLayerArtist.update


def upd(self, *e):
    if "subset" in FIX and not self.state.visible:
        ARRAY_CACHE.pop(self.state.uuid, None)
        PIXEL_CACHE.pop(self.state.uuid, None)
        return
    return _upd(self, *e)


la.ImageSubsetLayerArtist.update = upd
_di = MplCanvas._draw_idle


def di(self):
    if "canvas" in FIX and not self.isVisible():
        self._dirty_hidden = True
        self._draw_pending = False
        return
    return _di(self)


MplCanvas._draw_idle = di

N = int(sys.argv[1])
app = vc.app()
sji = vc.sji1400()
app.data_collection.append(sji)
viewers = [app.new_data_viewer(ImageViewer, data=sji) for _ in range(N)]
app.current_tab.tileSubWindows()
vc.settle(); time.sleep(0.5); vc.settle()
cv = {v.figure.canvas for v in viewers}
c0 = viewers[0].figure.canvas
print(f"N={N} canvas {c0.width()}x{c0.height()} dpr {c0.device_pixel_ratio}", flush=True)
group = app.data_collection.new_subset_group(
    label="Point", subset_state=PixelSubsetState(sji, [slice(None), slice(200, 201), slice(190, 191)]))
vc.settle()


def moves(label, reps=15, split=False):
    walls, nd, dt, npaint, per = [], [], [], [], defaultdict(list)
    for i in range(reps + 1):
        T.clear(); vc.DRAWS.clear(); vc.PAINTS.clear()
        y, x = 60 + (i * 13) % 250, 60 + (i * 17) % 250
        t = time.perf_counter()
        group.subset_state = PixelSubsetState(sji, [slice(None), slice(y, y + 1), slice(x, x + 1)])
        vc.settle()
        if i == 0:
            continue
        walls.append(time.perf_counter() - t)
        mine = [d for c, d in vc.DRAWS if c in cv]
        nd.append(len(mine)); dt.append(sum(mine)); npaint.append(sum(1 for c in vc.PAINTS if c in cv))
        for k, val in T.items():
            per[k].append(val)
    print(f"N={N} {label:44s} wall {vc.med(walls)*1e3:6.1f} ms  draws {vc.med(nd):.0f}  draw time {vc.med(dt)*1e3:6.1f} ms  "
          f"paints {vc.med(npaint):.0f}", flush=True)
    if split:
        for k in sorted(per):
            print(f"      {k:34s} {vc.med(per[k])*1e3:6.1f} ms  ({vc.med(per[k])/vc.med(dt)*100:.0f}% of draw time)")


moves("visible", split=True)
for v in viewers[1:]:
    for lyr in v.layers:
        if lyr.layer is not sji:
            lyr.state.visible = False
vc.settle()
if N > 1:
    moves("subset hidden in 1..N-1")
    FIX.add("subset")
    moves("subset hidden in 1..N-1, emulated fix")
    FIX.clear()
for v in viewers[1:]:
    for lyr in v.layers:
        lyr.state.visible = True
vc.settle()
app.new_tab()
app.tab_widget.setCurrentIndex(1)
vc.settle()
print(f"hidden tab: canvas visible {c0.isVisible()}")
moves("hidden tab")
FIX.add("canvas")
moves("hidden tab, emulated canvas fix")
vc.DRAWS.clear()
app.tab_widget.setCurrentIndex(0)
# showEvent half of the fix, done by hand here
for c in cv:
    if getattr(c, "_dirty_hidden", False):
        c._dirty_hidden = False
        c.draw_idle()
vc.settle()
print(f"tab shown again: {sum(1 for c, _ in vc.DRAWS if c in cv)} draws")
print(f"rss peak {vc.rss():.0f}MB")
