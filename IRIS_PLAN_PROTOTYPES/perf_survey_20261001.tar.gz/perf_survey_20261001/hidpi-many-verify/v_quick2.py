"""
Two glue-solar quicklooks in two tabs; tab B shown. B point move and B spectrogram slider tick, 15 reps each, medians:
draws/paints on hidden tab A, then the same with my own emulation of 'no Agg draw while the canvas is not visible'.
A: 4000255147 Si IV 1403 + SJI 1400.  B: 4000005156 Si IV 1403 scan r00000 + SJI 2796 deconvolved.
"""
import glob
import time

import vc
from glue.viewers.image.pixel_selection_subset_state import PixelSubsetState
from glue_qt.viewers.matplotlib.widget import MplCanvas
from glue_solar.quicklook import coordinator, quicklook
from glue_solar.sources.loaders.iris import image_data, raster_data

FIX = []
_di = MplCanvas._draw_idle


def di(self):
    if FIX and not self.isVisible():
        self._draw_pending = False
        return
    return _di(self)


MplCanvas._draw_idle = di
from glue.core.fixed_resolution_buffer import ARRAY_CACHE, PIXEL_CACHE
from glue.viewers.image import layer_artist as la
SUBFIX = []
_upd = la.ImageSubsetLayerArtist.update


def upd(self, *e):
    if SUBFIX and not self.state.visible:
        ARRAY_CACHE.pop(self.state.uuid, None)
        PIXEL_CACHE.pop(self.state.uuid, None)
        return
    return _upd(self, *e)


la.ImageSubsetLayerArtist.update = upd

app = vc.app()
vA = quicklook(app, [vc.siiv(), vc.sji1400()], window="Si IV 1403")
vc.settle()
rB = raster_data(sorted(glob.glob(f"{vc.D}/*4000005156_raster/*_r00000.fits")), windows=["Si IV 1403"])
rB = rB[0] if isinstance(rB, list) else rB
sB = image_data(glob.glob(f"{vc.D}/*4000005156_SJI_2796_t000_deconvolved.fits.gz")[0])
sB = sB[0] if isinstance(sB, list) else sB
vB = quicklook(app, [rB, sB], window="Si IV 1403")
vc.settle(); time.sleep(0.5); vc.settle()


def canv(vs):
    return {x.figure.canvas for v in vs.values() for x in (v if isinstance(v, list) else [v])}


cA, cB = canv(vA), canv(vB)
print(f"B shapes {rB.shape} {sB.shape}; current tab {app.tab_widget.currentIndex()}; A canvases visible "
      f"{sum(c.isVisible() for c in cA)}/{len(cA)}, B {sum(c.isVisible() for c in cB)}/{len(cB)}; rss {vc.rss():.0f}MB", flush=True)
group = coordinator(app.data_collection).group


def move_point(i):
    p = group.subset_state
    sl = list(p.slices)
    y = 200 + (i * 13) % 300
    sl[1] = slice(y, y + 1)
    group.subset_state = PixelSubsetState(p.reference_data, sl)


def tick(i):
    v = vB["spectrogram"]
    sl = list(v.state.slices)
    sl[0] = (i * 7 + 3) % rB.shape[0]
    v.state.slices = tuple(sl)


def run(name, action, reps=15):
    w, nA, tA, nB, tB, pA = [], [], [], [], [], []
    for i in range(reps + 1):
        vc.DRAWS.clear(); vc.PAINTS.clear()
        t = time.perf_counter()
        action(i)
        vc.settle()
        if i == 0:
            continue
        w.append(time.perf_counter() - t)
        a = [d for c, d in vc.DRAWS if c in cA]; b = [d for c, d in vc.DRAWS if c in cB]
        nA.append(len(a)); tA.append(sum(a)); nB.append(len(b)); tB.append(sum(b))
        pA.append(sum(1 for c in vc.PAINTS if c in cA))
    print(f"{name:34s} wall {vc.med(w)*1e3:6.1f} ms | B {vc.med(nB):.0f} draws {vc.med(tB)*1e3:6.1f} ms | hidden A "
          f"{vc.med(nA):.0f} draws {vc.med(tA)*1e3:6.1f} ms ({vc.med(tA)/vc.med(w)*100:.0f}% of wall), paints {max(pA)}", flush=True)


grpA = [(type(lyr).__name__, lyr.layer.label, lyr.state.visible) for v in vA.values() for x in (v if isinstance(v, list) else [v])
        for lyr in x.layers if getattr(lyr.layer, "group", None) is group]
print("B's point group layers in tab A viewers (artist, label, visible):", grpA)
for fix, sub in ((False, False), (True, False), (False, True)):
    FIX[:] = [1] if fix else []
    SUBFIX[:] = [1] if sub else []
    tag = " +canvas fix" if fix else (" +subset fix" if sub else "")
    run("B point move" + tag, move_point)
    run("B spectrogram tick" + tag, tick)
print(f"rss peak {vc.rss():.0f}MB")
