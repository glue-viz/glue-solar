"""
Re-measure: slider tick on one Image viewer; who calls WCSAxes tick placement and what it costs;
what an axes-level 'label without placement' override (my own emulation of the proposed fix) saves.
usage: v_tick.py sji|siiv WxH|max      25 ticks per mode, medians
"""
import sys
import time
from collections import Counter, defaultdict

import numpy as np
import vc
from astropy.visualization.wcsaxes import core as wcore
from astropy.visualization.wcsaxes import wcsapi
from glue_qt.viewers.image import ImageViewer

PLACE = []  # (caller, seconds)
TR = []  # (bucket, seconds)
_place = wcore.WCSAxes._update_tick_and_label_positions
_tr = wcsapi.WCSPixel2WorldTransform.transform


def place(self, *a, **k):
    caller = sys._getframe(1).f_code.co_name
    t = time.perf_counter()
    try:
        return _place(self, *a, **k)
    finally:
        PLACE.append((caller, time.perf_counter() - t))


def tr(self, pixel):
    f, bucket = sys._getframe(1), "other"
    for _ in range(8):
        if f is None:
            break
        if f.f_code.co_name == "_update_ticks":
            bucket = f"_update_ticks[{f.f_locals['self'].coord_index}]"
            break
        if f.f_code.co_name == "find_coordinate_range":
            bucket = "coord_range"
            break
        f = f.f_back
    t = time.perf_counter()
    try:
        return _tr(self, pixel)
    finally:
        TR.append((bucket, time.perf_counter() - t))


wcore.WCSAxes._update_tick_and_label_positions = place
wcsapi.WCSPixel2WorldTransform.transform = tr

kind, size = sys.argv[1], sys.argv[2]
app = vc.app()
data = vc.sji1400() if kind == "sji" else vc.siiv()
app.data_collection.append(data)
v = app.new_data_viewer(ImageViewer, data=data)
if size == "max":
    v.parent().showMaximized()
else:
    w, h = map(int, size.split("x"))
    v.parent().resize(w, h)
vc.settle()
time.sleep(0.5)
vc.settle()
c = v.figure.canvas
axis = next(i for i in range(data.ndim) if i not in (v.state.x_att.axis, v.state.y_att.axis))
print(f"{kind} canvas {c.width()}x{c.height()} dpr {c.device_pixel_ratio} slider axis {axis} "
      f"requires wcs update {v._changing_slice_requires_wcs_update}", flush=True)

ax, ndim = v.axes, data.ndim
orig_x, orig_y = ax.set_xlabel, ax.set_ylabel


def label_on_coord(which):
    def f(label=None, labelpad=1, loc=None, **kw):
        att = v.state.x_att if which == "x" else v.state.y_att
        ax.coords[ndim - 1 - att.axis].set_axislabel(label, minpad=labelpad, **kw)
    return f


def skip_empty(orig):
    def f(label=None, *a, **kw):
        if label == "":
            return None
        return orig(label, *a, **kw)
    return f


MODES = {
    "glue 1.27.0": (orig_x, orig_y),
    "A: skip '' labels": (skip_empty(orig_x), skip_empty(orig_y)),
    "B: label on coord, no placement": (label_on_coord("x"), label_on_coord("y")),
}
snap = {}
for mode, (fx, fy) in MODES.items():
    ax.set_xlabel, ax.set_ylabel = fx, fy
    walls, setters, draws, calls, ptime, ntr, ttr = [], [], [], [], [], [], []
    drawplace, bucket_n, bucket_t = [], Counter(), defaultdict(float)
    for i in range(25 + 2):
        sl = list(v.state.slices)
        sl[axis] = (i * 37 + 5) % data.shape[axis]
        PLACE.clear(); TR.clear(); vc.DRAWS.clear()
        t = time.perf_counter()
        v.state.slices = tuple(sl)
        t1 = time.perf_counter()
        vc.settle()
        t2 = time.perf_counter()
        if i < 2:
            continue  # warm-up
        walls.append(t2 - t); setters.append(t1 - t)
        draws.append(sum(d for _, d in vc.DRAWS))
        calls.append(Counter(cl for cl, _ in PLACE))
        ptime.append(sum(d for _, d in PLACE))
        drawplace += [d for cl, d in PLACE if cl == "draw_wcsaxes"]
        ntr.append(len(TR)); ttr.append(sum(d for _, d in TR))
        if i == 26:
            for b, d in TR:
                bucket_n[b] += 1; bucket_t[b] += d
    sl = list(v.state.slices); sl[axis] = 7; v.state.slices = tuple(sl); vc.settle()
    c.draw()
    snap[mode] = np.asarray(c.get_renderer().buffer_rgba()).copy()
    diff = "ref" if mode == "glue 1.27.0" else f"{(snap[mode] != snap['glue 1.27.0']).any(axis=2).mean()*100:.3f}% px differ"
    labels = [co.get_axislabel() for co in ax.coords]
    print(f"\n[{mode}] tick wall {vc.med(walls)*1e3:.1f} ms (min {min(walls)*1e3:.1f}), setter {vc.med(setters)*1e3:.1f} ms, "
          f"canvas draw {vc.med(draws)*1e3:.1f} ms, placements/tick {dict(calls[-1])}, placement time/tick {vc.med(ptime)*1e3:.1f} ms, "
          f"one placement in draw {vc.med(drawplace)*1e3:.1f} ms; WCS transform calls/tick {vc.med(ntr)} time {vc.med(ttr)*1e3:.1f} ms; "
          f"labels {labels}; {diff}", flush=True)
    print("   last tick transform calls by bucket:", {b: (bucket_n[b], round(bucket_t[b] * 1e3, 2)) for b in sorted(bucket_n)})
ax.set_xlabel, ax.set_ylabel = orig_x, orig_y

# hot function alone: one placement, 20 calls, keep_coord_range=True like the draw
PLACE.clear(); TR.clear()
c.draw()
ts = []
for _ in range(20):
    TR.clear()
    t = time.perf_counter(); _place(ax, keep_coord_range=False); ts.append(time.perf_counter() - t)
b = Counter(x for x, _ in TR); bt = defaultdict(float)
for x, d in TR:
    bt[x] += d
print(f"\nplacement alone x20: median {vc.med(ts)*1e3:.2f} ms; transforms per call {len(TR)} {dict(b)} "
      f"time {{{', '.join(f'{k}: {v_*1e3:.2f}' for k, v_ in sorted(bt.items()))}}} ms")
print(f"rss peak {vc.rss():.0f}MB")
