"""
SJI 1400 viewer at 800x500: what the 33 WCS transform calls of one tick placement are (immediate caller, points
per call), and the transform's cost against the number of points (is it per call or per point?).
"""
import sys
import time
from collections import Counter

import numpy as np
import vc
from astropy.visualization.wcsaxes import wcsapi
from glue_qt.viewers.image import ImageViewer

CALLS = []
_tr = wcsapi.WCSPixel2WorldTransform.transform


def tr(self, pixel):
    f = sys._getframe(1)
    CALLS.append((f.f_code.co_name, len(pixel)))
    return _tr(self, pixel)


app = vc.app()
sji = vc.sji1400()
app.data_collection.append(sji)
v = app.new_data_viewer(ImageViewer, data=sji)
v.parent().resize(800, 500)
vc.settle(); time.sleep(0.5); vc.settle()
ax = v.axes
v.figure.canvas.draw()
wcsapi.WCSPixel2WorldTransform.transform = tr
ax._update_tick_and_label_positions()
wcsapi.WCSPixel2WorldTransform.transform = _tr
print("calls by immediate caller:", dict(Counter(c for c, _ in CALLS)))
print("points per call:", sorted(Counter(n for _, n in CALLS).items()))
t = ax.coords[0].transform
rng = np.random.default_rng(0)
for npts in (1, 10, 50, 200, 1000, 5000):
    px = rng.uniform(0, 380, (npts, 2))
    ts = []
    for _ in range(30):
        t0 = time.perf_counter(); _tr(t, px); ts.append(time.perf_counter() - t0)
    print(f"transform {npts:5d} points: {vc.med(ts)*1e3:.3f} ms")
