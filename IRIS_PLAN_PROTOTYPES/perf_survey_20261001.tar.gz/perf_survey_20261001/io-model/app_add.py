"""
Adding and removing data in a running glue-qt app with the 4000005156 quicklook open.

usage: python app_add.py SCENARIO NSCANS   (browser | add_datasets | one_more | remove_scans)
"""

import cProfile
import pstats
import sys
import time
from collections import Counter

from common import SCANS_99, SJI_2796_DECONV, TWO_SCANS, banner

import glue_solar  # noqa: F401
from glue.core import Data
from glue.core.hub import HubListener
from glue.core.message import Message
from glue_qt.app import GlueApplication
from glue_qt.utils import get_qapp
from glue_solar.quicklook import quicklook
from glue_solar.sources.loaders import iris as L

banner()
scenario = sys.argv[1]
qapp = get_qapp()


def settle(n=30):
    for _ in range(n):
        qapp.processEvents()


obs1 = L.raster_data(TWO_SCANS, ["Si IV 1403"]) + [L.image_data(SJI_2796_DECONV)]
obs2 = L.raster_data(SCANS_99[:int(sys.argv[2])], ["Si IV 1403"])
app = GlueApplication()
app.resize(1600, 1000)
app.show()
app.data_collection.extend(obs1)
L.keep_hpc_linked(app.data_collection)
quicklook(app, obs1)
settle()
dc = app.data_collection
if scenario in ("one_more", "remove_scans"):
    dc.extend(obs2)
    L.keep_hpc_linked(dc)
    settle()


class Count(HubListener):
    def __init__(self, hub):
        self.c = Counter()
        hub.subscribe(self, Message, handler=lambda m: self.c.update([type(m).__name__]))


print(f"hub subscribers before: {len(dc.hub._subscriptions)}; viewers: {sum(len(t) for t in app.viewers)}; "
      f"datasets: {len(dc)}; links: {len(dc.external_links)}", flush=True)
count = Count(dc.hub)


def act():
    if scenario == "browser":  # the IRIS browser: extend, then keep_hpc_linked
        dc.extend(obs2)
        L.keep_hpc_linked(dc)
    elif scenario == "add_datasets":  # glue-qt File > Open: add_datasets runs the autolinker
        app.add_datasets(obs2)
    elif scenario == "one_more":  # one more dataset, e.g. a derived map, then relink
        extra = Data(label="extra", coords=obs2[0].coords, flux=obs2[0].get_data(obs2[0].main_components[0]))
        dc.append(extra)
        L.keep_hpc_linked(dc)
    elif scenario == "remove_scans":  # Delete on the 99 selected scans
        for d in obs2:
            dc.remove(d)
    settle()


if sys.argv[3:] == ["time"]:
    t0 = time.perf_counter()
    act()
    print(f"RESULT app {scenario} {sys.argv[2]} scans: {time.perf_counter() - t0:.3f} s wall, no profiler; "
          f"hub messages {sum(count.c.values())}", flush=True)
    raise SystemExit
pr = cProfile.Profile()
t0 = time.perf_counter()
pr.enable()
act()
pr.disable()
wall = time.perf_counter() - t0
print(f"RESULT app {scenario}: {wall:.2f} s under cProfile (single run; app state cannot be repeated cleanly)")
print(f"    hub messages: {sum(count.c.values())} {dict(count.c.most_common(8))}")
st = pstats.Stats(pr)
st.sort_stats("cumulative").print_stats(r"glue|glue_qt|glue_solar|matplotlib/backend|canvas", 30)
st.sort_stats("tottime").print_stats(12)
