"""
Load IRIS files one way per process and report time, memory and array copies.

usage: python load.py CASE MODE   (MODE: time | prof | mem)
"""

import cProfile
import gc
import pstats
import sys
import time
import tracemalloc

from common import SCANS_99, SIT_RASTER, SIT_SJI, SJI_2796_DECONV, TWO_SCANS, banner, rss_peak_mb

case, mode = sys.argv[1], sys.argv[2]

import glue_solar  # noqa: E402,F401  registers the IRIS data factory
from glue.core.data_factories import load_data  # noqa: E402
from glue.core.data_factories.fits import fits_reader  # noqa: E402
from glue_solar.sources.loaders import iris as L  # noqa: E402
from irispy.io import read_files  # noqa: E402

banner()

CASES = {
    "sit_siiv": lambda: L.raster_data([SIT_RASTER], ["Si IV 1403"]),
    "sit_sji1400": lambda: [L.image_data(SIT_SJI)],
    "5156_siiv": lambda: L.raster_data(TWO_SCANS, ["Si IV 1403"]),
    "5156_siiv_stack": lambda: L.raster_data(TWO_SCANS, ["Si IV 1403"], stack=True),
    "5156_sji2796": lambda: [L.image_data(SJI_2796_DECONV)],
    "6433_siiv": lambda: L.raster_data(SCANS_99, ["Si IV 1403"]),
    # glue's own entry point: auto factory picks glue-solar's reader (all windows of the file)
    "5156_load_data_auto": lambda: load_data(TWO_SCANS[0]),
    # glue's built-in FITS reader on the same file (all image and table HDUs)
    "5156_load_data_fits": lambda: load_data(TWO_SCANS[0], factory=fits_reader),
    "sit_sji1400_load_data_auto": lambda: [load_data(SIT_SJI)],
    "sit_sji1400_load_data_fits": lambda: load_data(SIT_SJI, factory=fits_reader),
    "6433_first20_load_data_auto": lambda: [d for p in SCANS_99[:20] for d in load_data(p)],
}
# stage split for the glue-solar raster loader: irispy read vs glue-solar's conversion to Data
STAGED = {
    "sit_siiv": ([SIT_RASTER], ["Si IV 1403"]),
    "5156_siiv": (TWO_SCANS, ["Si IV 1403"]),
    "6433_siiv": (SCANS_99, ["Si IV 1403"]),
}


def summarize(datasets):
    from glue.core.component import CoordinateComponent, DerivedComponent

    datasets = datasets if isinstance(datasets, list) else [datasets]
    total = 0
    for i, data in enumerate(datasets):
        parts = []
        for cid in data.main_components:
            comp = data.get_component(cid)
            if isinstance(comp, (CoordinateComponent, DerivedComponent)):
                continue
            arr = comp.data
            # broadcast views own nothing: count only memory the array really holds
            held = arr.nbytes if all(s != 0 for s in arr.strides) else (arr.base.nbytes if arr.base is not None else 0)
            total += held
            if i < 2:
                parts.append(f"{cid.label}: {arr.dtype} {arr.shape} owndata={arr.flags.owndata} "
                             f"base={type(arr.base).__name__} writeable={arr.flags.writeable} held={held / 2**20:.1f} MB")
        if i < 2:
            print(f"  {data.label} shape={data.shape} coords={type(data.coords).__name__} meta={type(data.meta).__name__}"
                  f"({len(data.meta)} keys)")
            for p in parts:
                print("     ", p)
    print(f"  {len(datasets)} datasets; component arrays hold {total / 2**20:.1f} MB")
    return total


if mode == "time":
    t0 = time.perf_counter()
    out = CASES[case]()
    t = time.perf_counter() - t0
    print(f"RESULT {case} load {t:.3f} s  rss_peak {rss_peak_mb():.0f} MB")
    if case in STAGED:
        del out
        gc.collect()
        files, windows = STAGED[case]
        t0 = time.perf_counter()
        coll = read_files(files, spectral_windows=windows, memmap=False, uncertainty=False)
        t1 = time.perf_counter()
        L._raster_collection_data(coll, windows)
        t2 = time.perf_counter()
        print(f"STAGES {case} irispy.read_files {t1 - t0:.3f} s  glue-solar _raster_collection_data {t2 - t1:.3f} s")
elif mode == "prof":
    prof = cProfile.Profile()
    prof.enable()
    out = CASES[case]()
    prof.disable()
    prof.dump_stats(f"prof_load_{case}.pstats")
    st = pstats.Stats(prof)
    st.sort_stats("cumulative").print_stats(45)
    st.sort_stats("tottime").print_stats(25)
elif mode == "mem":
    tracemalloc.start(25)
    if case in STAGED:
        files, windows = STAGED[case]
        coll = read_files(files, spectral_windows=windows, memmap=False, uncertainty=False)
        cur, peak = tracemalloc.get_traced_memory()
        print(f"MEM {case} after irispy.read_files: current {cur / 2**20:.0f} MB, peak {peak / 2**20:.0f} MB")
        tracemalloc.reset_peak()
        out = L._raster_collection_data(coll, windows)
        cur, peak = tracemalloc.get_traced_memory()
        print(f"MEM {case} after _raster_collection_data: current {cur / 2**20:.0f} MB, peak {peak / 2**20:.0f} MB")
        del coll
        gc.collect()
    else:
        out = CASES[case]()
    cur, peak = tracemalloc.get_traced_memory()
    print(f"MEM {case} retained after load: current {cur / 2**20:.0f} MB, (last) peak {peak / 2**20:.0f} MB; "
          f"rss_peak {rss_peak_mb():.0f} MB")
    snap = tracemalloc.take_snapshot()
    print("largest retained allocations by line:")
    for stat in snap.statistics("lineno")[:8]:
        print(f"   {stat.size / 2**20:8.1f} MB  {stat.count:6d} blocks  {stat.traceback[0]}")
    held = summarize(out)
    print(f"MEM {case} retained beyond component arrays: {(cur - held) / 2**20:.1f} MB")
