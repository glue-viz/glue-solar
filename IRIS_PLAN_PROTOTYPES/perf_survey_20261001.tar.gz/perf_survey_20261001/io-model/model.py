"""
glue's data model with no viewers: DataCollection.extend/append, links, autolink suggestions, removal.

Datasets are loaded once (99 scans of 3602506433 Si IV 1403, 4000005156 Si IV 1403 x2, SJI 2796 deconvolved)
and every repeat works on fresh glue Data objects that share the loaded arrays, WCS and meta.
"""

import cProfile
import pstats
import time
from collections import Counter

import numpy as np
from common import SCANS_99, SJI_2796_DECONV, TWO_SCANS, banner, fmt

import glue_solar  # noqa: F401
from glue.core import Data, DataCollection
from glue.core.autolinking import find_possible_links
from glue.core.hub import HubListener
from glue.core.message import Message
from glue_qt.utils import get_qapp
from glue_solar.sources.loaders import iris as L

banner()
qapp = get_qapp()

t0 = time.perf_counter()
BASE = L.raster_data(TWO_SCANS, ["Si IV 1403"]) + [L.image_data(SJI_2796_DECONV)] + L.raster_data(SCANS_99, ["Si IV 1403"])
print(f"loaded {len(BASE)} datasets in {time.perf_counter() - t0:.1f} s", flush=True)


def clone(d):
    n = Data(label=d.label)
    n.coords = d.coords
    n.meta = d.meta
    for cid in d.main_components:
        n.add_component(d.get_component(cid), cid.label)
    return n


def fresh(k=None):
    return [clone(d) for d in BASE[:k]]


class Count(HubListener):
    def __init__(self, hub):
        self.c = Counter()
        hub.subscribe(self, Message, handler=lambda m: self.c.update([type(m).__name__]))


def median_of(make, act, n=5):
    """make() builds the starting state (untimed), act(state) is timed."""
    ts = []
    for _ in range(n):
        state = make()
        t0 = time.perf_counter()
        act(state)
        qapp.processEvents()  # _Relinker's zero-delay timer, as the event loop would
        ts.append(time.perf_counter() - t0)
    return float(np.median(ts)), ts


def report(name, make, act, n=5, profile_pattern=None):
    med, ts = median_of(make, act, n)
    state = make()
    hub = state.hub if isinstance(state, DataCollection) else state[0].hub
    counter = Count(hub)
    pr = cProfile.Profile()
    pr.enable()
    act(state)
    qapp.processEvents()
    pr.disable()
    st = pstats.Stats(pr)
    calls = {}
    for (file, line, func), (cc, nc, tt, ct, callers) in st.stats.items():
        if func in ("update_externally_derivable_components", "discover_links", "equivalent_pixel_cids",
                    "broadcast", "remove_link", "_set_externally_derivable_components", "_set_pixel_aligned_data",
                    "find_possible_links", "_sync_link_manager") and ("glue/core" in file):
            calls[func] = (nc, round(ct, 3))
    msgs = dict(counter.c.most_common())
    print(f"RESULT {name}: median {med:.3f} s of {n} {fmt(ts)}", flush=True)
    print(f"    glue calls (ncalls, cumtime under profiler): {calls}")
    print(f"    hub messages: {sum(msgs.values())} {msgs}", flush=True)
    if profile_pattern:
        st.sort_stats("cumulative").print_stats(profile_pattern, 12)
    return med


def dc_with(datasets, linked):
    dc = DataCollection(datasets)
    if linked:
        L.keep_hpc_linked(dc)
    return dc


N = len(BASE)
# 1. adding data
report(f"DataCollection.extend({N}) into an empty collection", lambda: (DataCollection(), fresh()),
       lambda s: s[0].extend(s[1]))
report(f"DataCollection.append x{N} (one at a time) into an empty collection", lambda: (DataCollection(), fresh()),
       lambda s: [s[0].append(d) for d in s[1]], n=3)


report(f"keep_hpc_linked on {N} unlinked datasets (link_hpc + add_link)", lambda: dc_with(fresh(), False),
       lambda dc: L.keep_hpc_linked(dc))
report(f"append 1 dataset to a linked collection of {N - 1}",
       lambda: tuple((dc_with(fresh(N - 1), True), [clone(BASE[-1])])), lambda s: s[0].append(s[1][0]))
report(f"append 1 dataset + keep_hpc_linked, linked collection of {N - 1}",
       lambda: tuple((dc_with(fresh(N - 1), True), [clone(BASE[-1])])),
       lambda s: (s[0].append(s[1][0]), L.keep_hpc_linked(s[0])))

# 2. autolink suggestions on glue-solar datasets (glue-qt's add_datasets runs this)
report(f"find_possible_links on {N} glue-solar datasets", lambda: dc_with(fresh(), False), find_possible_links)

# 3. removing data
report(f"remove 1 non-anchor dataset from a linked collection of {N}", lambda: dc_with(fresh(), True),
       lambda dc: dc.remove(dc[N - 1]))
report(f"remove the anchor (first) dataset from a linked collection of {N}, incl. relink",
       lambda: dc_with(fresh(), True), lambda dc: dc.remove(dc[0]), n=3,
       profile_pattern="link_manager|data_collection|iris.py")
report(f"remove 1 non-anchor dataset from an unlinked collection of {N}", lambda: dc_with(fresh(), False),
       lambda dc: dc.remove(dc[N - 1]))
report(f"DataCollection.clear() of a linked collection of {N}", lambda: dc_with(fresh(), True), lambda dc: dc.clear(),
       n=3)
report(f"remove the 99 scans of 3602506433 one by one (glue-qt Delete on a multi-selection), linked {N}",
       lambda: dc_with(fresh(), True), lambda dc: [dc.remove(d) for d in list(dc)[3:]], n=3)

# 4. scaling of a full link-manager update with the number of datasets (star links)
for k in (10, 25, 50, N):
    report(f"update_externally_derivable_components, linked collection of {k}", lambda k=k: dc_with(fresh(k), True),
           lambda dc: dc._link_manager.update_externally_derivable_components(), n=5)
