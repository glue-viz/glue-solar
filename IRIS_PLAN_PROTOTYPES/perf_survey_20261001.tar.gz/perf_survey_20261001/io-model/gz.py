"""How many times is an SJI .fits.gz decompressed when it is opened through each path?"""

import gzip
import zlib

from common import SIT_SJI, banner, fmt, timed

from astropy.io import fits

banner()

# count bytes handed to zlib per path
_orig = zlib._ZlibDecompressor if hasattr(zlib, "_ZlibDecompressor") else None
counter = {"bytes": 0}
import _compression  # noqa: E402

_orig_read = gzip._GzipReader.read


def counting_read(self, size=-1):
    out = _orig_read(self, size)
    counter["bytes"] += len(out)
    return out


gzip._GzipReader.read = counting_read  # measurement hook in this process only

with gzip.open(SIT_SJI) as f:
    size = len(f.read())
print(f"uncompressed size {size / 2**20:.1f} MB")


def run(label, fn, n=3):
    counter["bytes"] = 0
    fn()
    passes = counter["bytes"] / size
    med, ts = timed(fn, n)
    print(f"RESULT {label}: median {med:.3f} s of {n} {fmt(ts)}; decompressed {passes:.2f}x the file")


def full_decompress():
    with gzip.open(SIT_SJI) as f:
        while f.read(1 << 24):
            pass


run("gzip full decompress once", full_decompress)
run("fits.getheader(path) [primary]", lambda: fits.getheader(SIT_SJI))
run("fits.getheader(path, 1)", lambda: fits.getheader(SIT_SJI, 1))


def open_data():
    with fits.open(SIT_SJI) as h:
        h[0].data


run("fits.open + [0].data", open_data)


def glue_is_fits():
    from glue.core.data_factories.fits import is_fits

    is_fits(SIT_SJI)


run("glue is_fits", glue_is_fits)


def glue_fits_reader():
    from glue.core.data_factories.fits import fits_reader

    fits_reader(SIT_SJI)


run("glue fits_reader", glue_fits_reader)


def solar_identifier():
    from glue_solar.sources.iris import is_iris_fits

    is_iris_fits(SIT_SJI)


run("glue-solar is_iris_fits", solar_identifier)


def irispy_read():
    from irispy.io import read_files

    read_files(SIT_SJI, memmap=False, uncertainty=False)


run("irispy read_files", irispy_read)


def find_factory():
    from glue.core.data_factories import find_factory

    find_factory(SIT_SJI)


run("glue find_factory", find_factory)


def glue_load_data():
    from glue.core.data_factories import load_data

    load_data(SIT_SJI)


run("glue load_data (auto)", glue_load_data, n=3)
