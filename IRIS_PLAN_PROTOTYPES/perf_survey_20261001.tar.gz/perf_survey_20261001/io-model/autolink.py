"""
glue's WCS autolinker (run by glue-qt's add_datasets) on IRIS raster scans read with glue's own FITS WCS,
as glue's FITS reader gives them: find_possible_links, then accepting the suggestions (add_link).
Arrays are zero-stride: only coordinates matter here.
"""

import time

import numpy as np
from common import SCANS_99, banner, fmt

import glue_solar  # noqa: F401
from glue.core import Data, DataCollection
from glue.core.autolinking import find_possible_links
from glue.core.coordinates import WCSCoordinates

from astropy.io import fits

banner()
from glue.config import autolinker  # noqa: E402
from glue.main import load_plugins  # noqa: E402

load_plugins()  # as glue-qt does at startup; registers the Astronomy WCS autolinker
print("autolinkers:", [label for label, _ in autolinker], flush=True)
coords = []
for path in SCANS_99:
    with fits.open(path) as h:
        idx = [h[0].header[f"TDESC{i}"] for i in range(1, h[0].header["NWIN"] + 1)].index("Si IV 1403") + 1
        header = h[idx].header
        coords.append((WCSCoordinates(header), (header["NAXIS3"], header["NAXIS2"], header["NAXIS1"])))

for k in (10, 25):
    ts_find, ts_add, n_links = [], [], 0
    for _ in range(3):
        dc = DataCollection([Data(label=f"scan{i}", coords=c, flux=np.broadcast_to(np.float32(0), s))
                             for i, (c, s) in enumerate(coords[:k])])
        t0 = time.perf_counter()
        suggestions = find_possible_links(dc)
        t1 = time.perf_counter()
        links = [link for group in suggestions.values() for link in group]
        dc.add_link(links)  # what 'always accept' does
        t2 = time.perf_counter()
        ts_find.append(t1 - t0)
        ts_add.append(t2 - t1)
        n_links = len(links)
    star_ts = []
    for _ in range(3):
        dc = DataCollection([Data(label=f"scan{i}", coords=c, flux=np.broadcast_to(np.float32(0), s))
                             for i, (c, s) in enumerate(coords[:k])])
        first = dc[0]
        star = [link for group in find_possible_links(dc).values() for link in group if first in (link.data1, link.data2)]
        t0 = time.perf_counter()
        dc.add_link(star)
        star_ts.append(time.perf_counter() - t0)
    print(f"RESULT {k} scans: accepting only the {len(star)} links to the first dataset (a star): median "
          f"{np.median(star_ts):.3f} s {fmt(star_ts)}", flush=True)
    print(f"RESULT {k} scans: find_possible_links median {np.median(ts_find):.3f} s {fmt(ts_find)}; {n_links} WCSLinks; "
          f"add_link(suggestions) median {np.median(ts_add):.3f} s {fmt(ts_add)}", flush=True)
    if k == 50 and np.median(ts_add) > 60:
        break
