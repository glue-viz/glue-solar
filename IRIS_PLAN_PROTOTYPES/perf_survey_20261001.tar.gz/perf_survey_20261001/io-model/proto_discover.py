"""
Candidate fix, measured only: glue's discover_links restarts its scan of every link after each link it
accepts. A worklist over links indexed by input ComponentID gives the same reachable set and depths.
Nothing in glue is patched: both functions run side by side on the same collection.
"""

import time
from collections import defaultdict

import numpy as np
from common import SCANS_99, SJI_2796_DECONV, TWO_SCANS, banner, fmt

import glue_solar  # noqa: F401
from glue.core import Data, DataCollection
from glue.core.link_manager import discover_links, equivalent_pixel_cids
from glue_qt.utils import get_qapp
from glue_solar.sources.loaders import iris as L

banner()
get_qapp()


def discover_links_worklist(data, links):
    """Same contract as glue.core.link_manager.discover_links (minimum depth per derivable cid)."""
    known = set(data.main_components + data.coordinate_components)
    depth = dict.fromkeys(known, 0)
    by_input, missing, cid_links = defaultdict(list), {}, {}
    frontier = []
    for link in links:
        inputs = set(link.get_from_ids())
        missing[link] = len(inputs - known)
        for cid in inputs - known:
            by_input[cid].append(link)
        if missing[link] == 0:
            frontier.append(link)
    while frontier:
        nxt = []
        for link in frontier:
            inputs = link.get_from_ids()
            cost = max((depth[f] for f in inputs), default=0) + 1
            to = link.get_to_id()
            if to in depth and cost >= depth[to]:
                continue
            first = to not in depth
            depth[to] = cost
            cid_links[to] = link
            if first:
                for other in by_input.get(to, ()):
                    missing[other] -= 1
                    if missing[other] == 0:
                        nxt.append(other)
        frontier = nxt
    return cid_links


# Datasets with the real IRIS WCS and shapes; arrays are zero-stride views, links need no values.
real = L.raster_data(TWO_SCANS, ["Si IV 1403"]) + [L.image_data(SJI_2796_DECONV)] + L.raster_data(SCANS_99, ["Si IV 1403"])
shapes = [(d.label, d.coords, d.shape) for d in real]
del real

for k in (10, 25, 50, len(shapes)):
    dc = DataCollection([Data(label=lbl, coords=c, flux=np.broadcast_to(np.float32(0), shp)) for lbl, c, shp in shapes[:k]])
    L.keep_hpc_linked(dc)
    lm = dc._link_manager
    links = lm._links | lm._inverse_links
    t_glue, t_new, same = [], [], True
    for _ in range(3):
        t0 = time.perf_counter()
        a = [discover_links(d, links) for d in dc]
        t_glue.append(time.perf_counter() - t0)
        t0 = time.perf_counter()
        b = [discover_links_worklist(d, links) for d in dc]
        t_new.append(time.perf_counter() - t0)
        same &= all(set(x) == set(y) for x, y in zip(a, b))
    t0 = time.perf_counter()
    for d1 in dc:
        for d2 in dc:
            if d1 is not d2:
                equivalent_pixel_cids(d2, d1)
    t_eq = time.perf_counter() - t0
    derivable = np.mean([len(x) for x in a])
    print(f"RESULT {k} datasets, {len(links)} links incl. inverses: glue discover_links (all datasets) median "
          f"{np.median(t_glue):.3f} s {fmt(t_glue)}; worklist median {np.median(t_new):.4f} s {fmt(t_new)}; "
          f"same derivable cids: {same}; mean derivable cids per dataset {derivable:.0f}; "
          f"equivalent_pixel_cids all pairs {t_eq:.3f} s", flush=True)
