"""
Saving a session: time, size and what dominates, with include_data False and True.

glue-solar's _GlueWCS has no session saver (WP3 is Later), so a stub saver is registered in this process
only, to let the rest be measured. It saves nothing for the WCS.

usage: python session.py CASE
"""

import cProfile
import pstats
import sys
import time

import numpy as np
from common import SJI_2796_DECONV, TWO_SCANS, banner, fmt, rss_peak_mb

import glue_solar  # noqa: F401
from glue.core import DataCollection
from glue.core.data_factories import load_data
from glue.core.data_factories.fits import fits_reader
from glue.core.state import GlueSerializer, saver
from glue_qt.utils import get_qapp
from glue_solar.sources.loaders import iris as L

banner()
qapp = get_qapp()
case = sys.argv[1]


@saver(L._GlueWCS)
def _stub(wcs, context):  # measurement stub, see module docstring
    return {}


import astropy.units as u  # noqa: E402


@saver(u.Quantity)
def _stub_quantity(q, context):  # measurement stub: glue 1.27.0 sends Quantity meta to np.save, which raises
    return dict(value=context.do(np.asarray(q.value)), unit=str(q.unit))


def dc_of(datasets):
    dc = DataCollection(datasets)
    L.keep_hpc_linked(dc)
    return dc


if case == "solar_raster_data":  # the IRIS browser's path: no LoadLog
    obj = dc_of(L.raster_data(TWO_SCANS, ["Si IV 1403"]))
elif case == "solar_load_data":  # glue's File > Open path: LoadLog on every component
    obj = dc_of([load_data(SJI_2796_DECONV)] + load_data(TWO_SCANS[0]))
elif case == "glue_fits_reader":  # glue's own FITS reader, WCSCoordinates
    obj = DataCollection(load_data(SJI_2796_DECONV, factory=fits_reader))
elif case == "app_quicklook":  # a whole app with the 4000005156 quicklook open
    from glue_qt.app import GlueApplication
    from glue_solar.quicklook import quicklook

    datasets = L.raster_data(TWO_SCANS, ["Si IV 1403"])
    app = GlueApplication()
    app.resize(1600, 1000)
    app.show()
    app.data_collection.extend(datasets)
    L.keep_hpc_linked(app.data_collection)
    quicklook(app, datasets)
    for _ in range(20):
        qapp.processEvents()
    obj = app
else:
    raise SystemExit(case)

arrays = 0
dc = obj.data_collection if case == "app_quicklook" else obj
for d in dc:
    arrays += len(d.main_components)
print(f"{case}: {len(dc)} datasets, {arrays} main components, "
      f"{sum(d.get_component(c).data.nbytes for d in dc for c in d.main_components if d.get_component(c).data.strides[-1]) / 2**20:.0f} MB in non-broadcast main components")

for include_data in (False, True) if case != "solar_load_data" else (False,):  # True would embed ~470 MB
    try:
        ts, size = [], None
        for _ in range(3):
            t0 = time.perf_counter()
            text = GlueSerializer(obj, include_data=include_data).dumps()
            ts.append(time.perf_counter() - t0)
            size = len(text)
            del text
    except Exception as error:  # noqa: BLE001
        print(f"RESULT {case} include_data={include_data}: FAILED {type(error).__name__}: {str(error)[:200]}")
        continue
    print(f"RESULT {case} include_data={include_data}: median {np.median(ts):.3f} s of 3 {fmt(ts)}; "
          f"{size / 2**20:.1f} MB JSON; rss_peak {rss_peak_mb():.0f} MB", flush=True)
    pr = cProfile.Profile()
    pr.enable()
    ser = GlueSerializer(obj, include_data=include_data)
    result = ser.dumpo()
    pr.disable()
    st = pstats.Stats(pr)
    keep = {}
    for (file, line, func), (cc, nc, tt, ct, callers) in st.stats.items():
        if func in ("do", "do_all", "_save_numpy", "_save_data_5", "_save_component", "_save_data_collection_4",
                    "b64encode", "save", "dumpo", "_stub_quantity", "_save_data_collection_4", "_save_numpy", "_stub", "__gluestate__", "_save_wcs"):
            keep[f"{func}@{file.split('site-packages/')[-1]}:{line}"] = (nc, round(tt, 3), round(ct, 3))
    print(f"    profile (ncalls, tottime, cumtime): {keep}")
    print(f"    registered objects: {len(ser._objs)}; top-level records by type:")
    sizes = {}
    import json

    for name, rec in result.items():
        typ = rec.get("_type", "?") if isinstance(rec, dict) else "?"
        n = len(json.dumps(rec, default=ser.json_default))
        c, s = sizes.get(typ, (0, 0))
        sizes[typ] = (c + 1, s + n)
    for typ, (c, s) in sorted(sizes.items(), key=lambda kv: -kv[1][1])[:8]:
        print(f"       {s / 2**20:9.3f} MB  {c:5d} x {typ}")
    meta_bytes = sum(len(json.dumps(rec.get("meta"), default=ser.json_default)) for rec in result.values()
                     if isinstance(rec, dict) and "meta" in rec)
    print(f"    meta records inside Data: {meta_bytes / 2**20:.3f} MB", flush=True)
    st.sort_stats("cumulative").print_stats(r"glue/core/state|base64|numpy/lib/_npyio|json", 14)
    del result, ser
