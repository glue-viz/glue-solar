"""Candidate fixes for repeated gzip decompression, timed in this process only (nothing patched)."""
import gzip, io
from common import SIT_SJI, banner, fmt, timed
from astropy.io import fits
banner()

def header_only():
    with gzip.open(SIT_SJI) as f:
        return fits.Header.fromfile(f)["TELESCOP"]

def decompress_once_then_read_all():
    with gzip.open(SIT_SJI) as f:
        buf = io.BytesIO(f.read())
    with fits.open(buf) as h:
        h.verify("fix")
        for hdu in h:
            hdu.data

med, ts = timed(header_only, 5); print(f"RESULT primary header only via Header.fromfile(gzip stream): median {med:.4f} s {fmt(ts)}")
med, ts = timed(decompress_once_then_read_all, 3); print(f"RESULT decompress once to BytesIO + open + all HDU data: median {med:.3f} s {fmt(ts)}")
