"""Shared paths and helpers for the io-model measurements (measure only, nothing patched)."""

import glob
import resource
import sys
import time

sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")

import numpy as np  # noqa: E402

D = "/Users/nabil/DATA/IRIS"
SIT_RASTER = glob.glob(f"{D}/*4000255147_raster/*_r00000.fits")[0]
SIT_SJI = glob.glob(f"{D}/*4000255147_SJI_1400_t000.fits.gz")[0]
TWO_SCANS = sorted(glob.glob(f"{D}/*4000005156_raster/*.fits"))
SJI_2796_DECONV = glob.glob(f"{D}/*4000005156_SJI_2796_t000_deconvolved.fits.gz")[0]
SCANS_99 = sorted(glob.glob(f"{D}/*3602506433_raster/*.fits"))
assert len(TWO_SCANS) == 2 and len(SCANS_99) == 99


def rss_peak_mb():
    # macOS reports ru_maxrss in bytes
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 2**20


def banner():
    import glue
    import glue_solar
    from importlib.metadata import version

    print(f"glue_solar from {glue_solar.__file__}; glue-core {version('glue-core')} at {glue.__file__}; "
          f"glue-qt {version('glue-qt')}; irispy {version('irispy-lmsal')}; astropy {version('astropy')}; "
          f"numpy {np.__version__}", flush=True)


def timed(fn, n=5):
    """Run fn n times, return (median, all times)."""
    times = []
    for _ in range(n):
        t0 = time.perf_counter()
        fn()
        times.append(time.perf_counter() - t0)
    return float(np.median(times)), times


def fmt(times):
    return "[" + ", ".join(f"{t:.4f}" for t in times) + "]"
