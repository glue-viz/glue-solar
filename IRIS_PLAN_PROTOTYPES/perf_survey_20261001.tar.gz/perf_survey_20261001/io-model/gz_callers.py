"""Which calls in glue's fits_reader and irispy's SJI reader trigger the gzip re-decompressions."""
import cProfile, pstats, sys
from common import SIT_SJI, banner
banner()
from glue.core.data_factories.fits import fits_reader
from irispy.io import read_files
for name, fn in [("glue fits_reader", lambda: fits_reader(SIT_SJI)), ("irispy read_files", lambda: read_files(SIT_SJI, memmap=False, uncertainty=False))]:
    pr = cProfile.Profile(); pr.enable(); fn(); pr.disable()
    print("=====", name)
    st = pstats.Stats(pr); st.sort_stats("cumulative")
    st.print_callers(r"gzip.py:\d+\(seek\)|_compression.py:\d+\(seek\)")
    st.print_callers(r"hdulist.py:\d+\(_read_next_hdu\)")
    st.print_callers(r"image.py:\d+\(data\)")
    st.print_callers(r"convenience.py:\d+\(getheader\)|hdulist.py:\d+\(fitsopen\)")
