"""
Data.get_data and Data.get_mask on the 4000255147 sit-and-stare Si IV 1403 raster (1600 x 417 x 262),
linked to its SJI 1400 with link_hpc, for the subset kinds glue and the quicklook create.
"""

import time
import tracemalloc

import numpy as np
from common import SIT_RASTER, SIT_SJI, banner, fmt, timed

import glue_solar  # noqa: F401
from glue.core import DataCollection
from glue.core.roi import PolygonalROI, RectangularROI
from glue.core.subset import RangeSubsetState, RoiSubsetState
from glue.viewers.image.pixel_selection_subset_state import PixelSubsetState
from glue_qt.utils import get_qapp
from glue_solar.sources.loaders import iris as L

banner()
get_qapp()
raster = L.raster_data([SIT_RASTER], ["Si IV 1403"])[0]
sji = L.image_data(SIT_SJI)
dc = DataCollection([sji, raster])  # SJI first: it is link_hpc's anchor, the raster derives its lon/lat
L.keep_hpc_linked(dc)
flux = raster.main_components[0]
pix = raster.pixel_component_ids  # (exposure, slit, wavelength)
world = {c.label: c for c in raster.world_component_ids}
sji_world = {c.label: c for c in sji.world_component_ids}
print("raster world cids:", list(world), "SJI world cids:", list(sji_world))
LON, LAT, WAV = world["Helioprojective Longitude"], world["Helioprojective Latitude"], world["Wavelength"]
print(f"raster {raster.shape}, {len(raster.externally_derivable_components)} externally derivable cids", flush=True)


def measure(label, fn, n=5):
    fn()  # warm caches
    med, ts = timed(fn, n)
    tracemalloc.start()
    out = fn()
    peak = tracemalloc.get_traced_memory()[1]
    tracemalloc.stop()
    shape = getattr(out, "shape", None)
    held = out.nbytes if isinstance(out, np.ndarray) and all(out.strides) else 0
    print(f"RESULT {label}: median {med:.4f} s of {n} {fmt(ts)}; peak alloc {peak / 2**20:.0f} MB; "
          f"result {shape} holding {held / 2**20:.0f} MB", flush=True)


one_wavelength = (slice(None), slice(None), 131)  # what an Image viewer slice of the raster map asks for
one_exposure = (800, slice(None), slice(None))

measure("get_data(flux) view=None", lambda: raster.get_data(flux))
measure("get_data(flux, one wavelength)", lambda: raster.get_data(flux, one_wavelength))
measure("get_data(world lon) view=None", lambda: raster.get_data(LON))
measure("get_data(world lon, one wavelength)", lambda: raster.get_data(LON, one_wavelength))
measure("get_data(world wavelength) view=None", lambda: raster.get_data(WAV))
measure("get_data(SJI-anchor lon, derived through link_hpc) view=None",
        lambda: raster.get_data(sji_world["Helioprojective Longitude"]))

point = PixelSubsetState(raster, [slice(800, 801), slice(200, 201), slice(None)])  # the quicklook's Point
measure("get_mask(Point PixelSubsetState) view=None", lambda: raster.get_mask(point))
measure("get_mask(Point PixelSubsetState, one wavelength)", lambda: raster.get_mask(point, one_wavelength))

rect = RoiSubsetState(pix[1], pix[0], RectangularROI(100, 300, 400, 1200))  # x=slit, y=exposure
measure("get_mask(RectangularROI on pixel axes) view=None", lambda: raster.get_mask(rect))
poly = RoiSubsetState(pix[1], pix[0], PolygonalROI([100, 300, 300, 100], [400, 400, 1200, 900]))
measure("get_mask(PolygonalROI on pixel axes) view=None", lambda: raster.get_mask(poly))
lo, hi = np.nanpercentile(raster.get_data(flux)[::50, ::50, ::10], [90, 99])
rng = RangeSubsetState(lo, hi, flux)
measure("get_mask(RangeSubsetState on flux) view=None", lambda: raster.get_mask(rng), n=3)
measure("get_mask(RangeSubsetState on flux, one wavelength)", lambda: raster.get_mask(rng, one_wavelength))
lon, lat = raster.get_data(LON, one_exposure), raster.get_data(LAT, one_exposure)
wroi = RectangularROI(*np.nanpercentile(lon, [25, 75]), *np.nanpercentile(lat, [25, 75]))
wrect = RoiSubsetState(LON, LAT, wroi)
measure("get_mask(RectangularROI on world lon/lat) view=None", lambda: raster.get_mask(wrect), n=3)
measure("get_mask(RectangularROI on world lon/lat, one wavelength)", lambda: raster.get_mask(wrect, one_wavelength))
srect = RoiSubsetState(sji_world["Helioprojective Longitude"], sji_world["Helioprojective Latitude"], wroi)  # an ROI on the SJI's lon/lat
measure("get_mask(RectangularROI on SJI-anchor lon/lat, derived) view=None", lambda: raster.get_mask(srect), n=3)
