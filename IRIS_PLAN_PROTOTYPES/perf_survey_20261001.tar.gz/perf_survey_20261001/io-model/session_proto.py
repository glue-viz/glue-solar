"""
Session saving, memory-safe sizes, with two candidate fixes measured side by side (glue not patched):
  1. one serialization per registered object instead of re-serializing all of them on every do_all pass;
  2. saving broadcast (zero-stride) arrays unbroadcast, as glue.utils.unbroadcast gives them.
The same stub savers as session.py (_GlueWCS, Quantity) are registered in this process only.

usage: python session_proto.py CASE   (dc10 | app2)
"""

import json
import sys
import time

import astropy.units as u
import numpy as np
from common import SCANS_99, banner, fmt

import glue_solar  # noqa: F401
from glue.core import DataCollection
from glue.core.state import GlueSerializer, _save_numpy, saver
from glue.utils import unbroadcast
from glue_qt.utils import get_qapp
from glue_solar.sources.loaders import iris as L

banner()
qapp = get_qapp()
case = sys.argv[1]


@saver(L._GlueWCS)
def _stub(wcs, context):
    return {}


@saver(u.Quantity)
def _stub_quantity(q, context):
    return dict(value=context.do(np.asarray(q.value)), unit=str(q.unit))


class OnePass(GlueSerializer):
    """Serialize each registered object once; keep going while serializing registers new ones."""

    def do_all(self):
        result = {}
        while len(result) != len(self._objs):
            for name, obj in list(self._objs.items()):
                if name not in result:
                    result[name] = self.do(obj)
        return result


class OnePassUnbroadcast(OnePass):
    """Also save zero-stride arrays unbroadcast, with the full shape to broadcast back to on load."""

    def _dispatch(self, obj):
        if isinstance(obj, np.ndarray) and 0 in obj.strides:
            return (lambda o, ctx: dict(_save_numpy(unbroadcast(o), ctx), shape=list(o.shape))), 1
        return super()._dispatch(obj)


if case == "dc10":
    datasets = L.raster_data(SCANS_99[:10], ["Si IV 1403"])
    obj = DataCollection(datasets)
    L.keep_hpc_linked(obj)
    dc = obj
elif case == "app2":
    from glue_qt.app import GlueApplication
    from glue_solar.quicklook import quicklook

    datasets = L.raster_data(SCANS_99[:2], ["Si IV 1403"])
    obj = GlueApplication()
    obj.resize(1600, 1000)
    obj.show()
    obj.data_collection.extend(datasets)
    L.keep_hpc_linked(obj.data_collection)
    quicklook(obj, datasets)
    for _ in range(20):
        qapp.processEvents()
    dc = obj.data_collection
else:
    raise SystemExit(case)


def run(cls):
    ts = []
    for _ in range(3):
        t0 = time.perf_counter()
        text = cls(obj, include_data=False).dumps()
        ts.append(time.perf_counter() - t0)
    return text, ts


base, t_base = run(GlueSerializer)
one, t_one = run(OnePass)
print(f"RESULT {case} glue GlueSerializer.dumps: median {np.median(t_base):.3f} s {fmt(t_base)}; "
      f"{len(base) / 2**20:.1f} MB JSON", flush=True)
print(f"RESULT {case} one-pass do_all: median {np.median(t_one):.3f} s {fmt(t_one)}; identical JSON: {base == one}",
      flush=True)
both, t_both = run(OnePassUnbroadcast)
print(f"RESULT {case} one-pass + unbroadcast: median {np.median(t_both):.3f} s {fmt(t_both)}; "
      f"{len(both) / 2**20:.1f} MB JSON", flush=True)
del both
del base, one

# Unbroadcast estimate: encode every main component's array as glue does, and unbroadcast
full_b = small_b = 0
t_full = t_small = 0.0
for d in dc:
    for cid in d.main_components:
        arr = d.get_component(cid).data
        if not isinstance(arr, np.ndarray) or arr.dtype.kind == "O":
            continue
        t0 = time.perf_counter()
        full_b += len(_save_numpy(arr, None)["data"])
        t1 = time.perf_counter()
        small_b += len(_save_numpy(unbroadcast(arr), None)["data"])
        t2 = time.perf_counter()
        t_full += t1 - t0
        t_small += t2 - t1
print(f"RESULT {case} encoding main components once: as saved {full_b / 2**20:.1f} MB in {t_full:.3f} s; "
      f"unbroadcast {small_b / 2**20:.1f} MB in {t_small:.3f} s", flush=True)
for d in dc[:1]:
    for cid in d.main_components:
        arr = d.get_component(cid).data
        print(f"    {cid.label[:40]:40s} {str(arr.dtype):14s} strides {arr.strides} -> unbroadcast {unbroadcast(arr).shape}")
