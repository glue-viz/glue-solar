"""Does glue's WCS autolinker see glue-solar IRIS datasets? (plugins loaded as glue-qt does)"""
import time
from common import SCANS_99, banner
import glue_solar  # noqa: F401
from glue.core import DataCollection
from glue.core.autolinking import find_possible_links
from glue.main import load_plugins
from glue_solar.sources.loaders import iris as L
banner()
load_plugins()
dc = DataCollection(L.raster_data(SCANS_99[:25], ["Si IV 1403"]))
t0 = time.perf_counter(); s = find_possible_links(dc); t = time.perf_counter() - t0
print(f"RESULT glue-solar 25 scans: find_possible_links {t:.4f} s, suggestions {[(k, len(v)) for k, v in s.items()]}")
