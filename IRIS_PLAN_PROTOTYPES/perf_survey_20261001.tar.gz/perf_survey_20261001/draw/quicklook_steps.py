"""
Time user actions in the IRIS quicklook: slider steps per panel, pan, zoom, contrast/bias drag.

usage: python quicklook_steps.py A|B [repeats]
  A: 4000255147 sit-and-stare, Si IV 1403 + SJI 1400
  B: 4000005156 two-scan stack, Si IV 1403 + deconvolved SJI 2796
"""

import json
import sys
import time

import common as c
from common import med

case = sys.argv[1]
N = int(sys.argv[2]) if len(sys.argv) > 2 else 15
PROFILE = "--profile" in sys.argv

app, viewers, panels = c.open_quicklook(case)

results = {}


def run(name, viewer, setter, n=N, warm=2):
    """Apply setter(i) n times, each followed by settling; return per-step medians."""
    for i in range(warm):
        setter(-1 - i)
        c.settle()
    rows = []
    for i in range(n):
        c.reset_counters()
        t0 = time.perf_counter()
        setter(i)
        t1 = time.perf_counter()
        c.settle()
        t2 = time.perf_counter()
        times, calls, draws, draw_t = c.snapshot()
        rows.append(dict(set=t1 - t0, total=t2 - t0, times=times, calls=calls, draws=draws,
                         draw_t={k: sum(v) for k, v in draw_t.items()}))
    keys = sorted({k for r in rows for k in r["times"]})
    summary = {
        "set_s": med([r["set"] for r in rows]),
        "total_s": med([r["total"] for r in rows]),
        "draws": {k: med([r["draws"].get(k, 0) for r in rows]) for k in sorted({k for r in rows for k in r["draws"]})},
        "draw_s": {k: med([r["draw_t"].get(k, 0) for r in rows]) for k in sorted({k for r in rows for k in r["draw_t"]})},
        "boundary_s": {k: med([r["times"].get(k, 0) for r in rows]) for k in keys},
        "calls": {k: med([r["calls"].get(k, 0) for r in rows]) for k in keys},
        "n": n,
    }
    results[name] = summary
    print(f"\n== {name}: n={n} median set {summary['set_s']*1e3:.1f} ms, total {summary['total_s']*1e3:.1f} ms "
          f"(min {min(r['total'] for r in rows)*1e3:.1f}, max {max(r['total'] for r in rows)*1e3:.1f})", flush=True)
    print("   draws:", {k: v for k, v in summary["draws"].items()})
    print("   draw ms:", {k: round(v * 1e3, 1) for k, v in summary["draw_s"].items()})
    for k in keys:
        print(f"   {k:32s} {summary['boundary_s'][k]*1e3:8.1f} ms  calls {summary['calls'][k]}")
    return summary


slider, pan, zoom, contrast = c.slider, c.pan, c.zoom, c.contrast

ndim = panels["map"].state.reference_data.ndim
time_axis = 0
if ndim == 3:
    actions = [
        ("spectrogram: exposure step", panels["spectrogram"], slider(panels["spectrogram"], 0)),
        ("slit-vs-time map: wavelength step", panels["map"], slider(panels["map"], 2)),
        ("λ-time: slit step", panels["wavelength"], slider(panels["wavelength"], 1)),
    ]
else:  # stack: scan, step, slit, wavelength
    actions = [
        ("spectrogram: raster step", panels["spectrogram"], slider(panels["spectrogram"], 1)),
        ("spectrogram: scan step", panels["spectrogram"], slider(panels["spectrogram"], 0, start=0)),
        ("map: wavelength step", panels["map"], slider(panels["map"], 3)),
        ("λ-scan: slit step", panels["wavelength"], slider(panels["wavelength"], 2)),
    ]
actions += [
    ("sji: frame step", panels["sji"], slider(panels["sji"], 0)),
    ("spectrogram: pan 5%", panels["spectrogram"], pan(panels["spectrogram"])),
    ("spectrogram: zoom 0.9x", panels["spectrogram"], zoom(panels["spectrogram"])),
    ("sji: pan 5%", panels["sji"], pan(panels["sji"])),
    ("map: contrast/bias drag event", panels["map"], contrast(panels["map"])),
    ("sji: contrast/bias drag event", panels["sji"], contrast(panels["sji"])),
]

only = [a for a in sys.argv[3:] if not a.startswith("--")]
for name, viewer, setter in actions:
    if only and not any(o in name for o in only):
        continue
    if name.endswith("scan step"):
        run(name, viewer, setter, n=1, warm=0)  # a stack has two scans
    else:
        run(name, viewer, setter)

with open(f"draw/quicklook_steps_{case}.json", "w") as fh:
    json.dump(results, fh, indent=1, default=str)
print(f"\nmaxrss {c.rss_gb():.2f} GB")
