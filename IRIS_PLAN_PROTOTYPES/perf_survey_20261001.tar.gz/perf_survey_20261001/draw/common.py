"""Shared setup and runtime-only instrumentation for the draw-path measurements (nothing is patched on disk)."""

import cProfile
import glob
import io
import os
import pstats
import resource
import statistics
import sys
import time
from collections import defaultdict
from contextlib import contextmanager

sys.path.insert(0, os.environ.get("GLUE_SOLAR_PATH", "/Users/nabil/Git/glue-solar-main"))

assert os.environ.get("QT_QPA_PLATFORM") == "offscreen", "run with QT_QPA_PLATFORM=offscreen"
assert not os.environ["HOME"].startswith("/Users/"), "run with an isolated HOME"

import glue_solar  # noqa: E402

print("glue_solar from", glue_solar.__file__, flush=True)

IRIS = "/Users/nabil/DATA/IRIS"


def rss_gb():
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1e9  # macOS: bytes


def files(pattern):
    found = sorted(glob.glob(os.path.join(IRIS, pattern)))
    assert found, pattern
    return found


def make_app():
    from glue_qt.app.application import GlueApplication
    from glue_qt.utils import get_qapp

    get_qapp()
    glue_solar.setup()
    app = GlueApplication()
    app.resize(1600, 1000)
    app.show()
    settle()
    return app


def settle(rounds=6):
    """Process events until no canvas draw is pending (a few extra rounds for 0 ms timers)."""
    from qtpy.QtWidgets import QApplication

    qapp = QApplication.instance()
    for _ in range(200):
        qapp.processEvents()
        if not _pending():
            rounds -= 1
            if rounds <= 0:
                return


_CANVASES = []


def wait(seconds):
    """Run the event loop for ``seconds`` (lets mpl-scatter-density's 500 ms post-resize timer release the images)."""
    from qtpy.QtWidgets import QApplication

    end = time.perf_counter() + seconds
    while time.perf_counter() < end:
        QApplication.instance().processEvents()
        time.sleep(0.005)


def _pending():
    return any(getattr(c, "_draw_pending", False) for c in _CANVASES)


# --- inclusive timers on a few boundaries -------------------------------------------------------

TIMES = defaultdict(float)
CALLS = defaultdict(int)
DRAWS = defaultdict(int)  # canvas label -> draws
DRAW_T = defaultdict(list)  # canvas label -> draw durations


def wrap(owner, name, key=None, per_call=False):
    key = key or f"{getattr(owner, '__name__', owner)}.{name}"
    original = getattr(owner, name)

    def wrapper(*args, **kwargs):
        t = time.perf_counter()
        try:
            return original(*args, **kwargs)
        finally:
            TIMES[key] += time.perf_counter() - t
            CALLS[key] += 1

    wrapper.__wrapped__ = original
    setattr(owner, name, wrapper)


def instrument():
    """Install inclusive timers and call counters on the draw path boundaries."""
    import glue.core.fixed_resolution_buffer as frb
    from astropy.visualization.wcsaxes import WCSAxes
    from astropy.visualization.wcsaxes.coordinate_helpers import CoordinateHelper
    from glue.viewers.image.composite_array import CompositeArray
    from glue.viewers.image.layer_artist import ImageSubsetArray
    from glue.viewers.image.state import ImageLayerState
    from glue_qt.viewers.matplotlib.widget import MplCanvas
    from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
    from matplotlib.image import AxesImage
    from mpl_scatter_density.base_image_artist import BaseImageArtist

    from glue_solar.sources.loaders.iris import _GlueWCS

    wrap(frb, "compute_fixed_resolution_buffer", "frb")
    wrap(frb, "translate_pixel", "frb.translate_pixel")
    wrap(CompositeArray, "__call__", "composite")
    wrap(ImageLayerState, "get_sliced_data", "layer.get_sliced_data")
    wrap(ImageSubsetArray, "__call__", "subset_mask")
    wrap(BaseImageArtist, "make_image", "image.make_image")
    wrap(AxesImage, "make_image", "mpl.AxesImage.make_image")
    wrap(WCSAxes, "draw", "wcsaxes.draw")
    wrap(WCSAxes, "draw_wcsaxes", "wcsaxes.draw_wcsaxes")
    wrap(WCSAxes, "reset_wcs", "wcsaxes.reset_wcs")
    wrap(CoordinateHelper, "_draw_grid", "coord._draw_grid")
    wrap(CoordinateHelper, "_update_ticks", "coord._update_ticks")
    wrap(CoordinateHelper, "_draw_ticks", "coord._draw_ticks")
    wrap(CoordinateHelper, "_draw_axislabels", "coord._draw_axislabels")
    wrap(_GlueWCS, "pixel_to_world_values", "wcs.pixel_to_world_values")
    wrap(_GlueWCS, "world_to_pixel_values", "wcs.world_to_pixel_values")
    wrap(FigureCanvasQTAgg, "paintEvent", "qt.paintEvent")

    # finer WCSAxes / glue / glue-solar boundaries
    import astropy.visualization.wcsaxes.core as wcore
    import matplotlib.text
    from astropy.visualization.wcsaxes.axislabels import AxisLabels
    from astropy.visualization.wcsaxes.coordinates_map import CoordinatesMap
    from astropy.visualization.wcsaxes.frame import BaseFrame, RectangularFrame
    from astropy.visualization.wcsaxes.ticklabels import TickLabels
    from astropy.visualization.wcsaxes.ticks import Ticks
    from glue.viewers.image.viewer import MatplotlibImageMixin

    import glue_solar.quicklook as ql
    import glue_solar.tools as tools

    from glue_qt.viewers.image.data_viewer import ImageViewer as QtImageViewer

    # glue-qt's decorate_all_methods(defer_draw) copies the mixin's methods into the Qt class
    wrap(QtImageViewer if "_set_wcs" in QtImageViewer.__dict__ else MatplotlibImageMixin, "_set_wcs", "glue._set_wcs")
    wrap(WCSAxes, "_update_tick_and_label_positions", "wcsaxes._update_tick_and_label_positions")
    wrap(WCSAxes, "set_xlabel", "wcsaxes.set_xlabel")
    wrap(WCSAxes, "set_ylabel", "wcsaxes.set_ylabel")
    wrap(CoordinatesMap, "get_coord_range", "wcsaxes.get_coord_range")
    wrap(RectangularFrame, "update_spines", "frame.update_spines")
    wrap(BaseFrame, "sample", "frame.sample")
    wrap(BaseFrame, "_update_patch_path", "frame._update_patch_path")
    wrap(BaseFrame, "draw", "frame.draw")
    wrap(TickLabels, "draw", "ticklabels.draw")
    wrap(Ticks, "draw", "ticks.draw")
    wrap(AxisLabels, "draw", "axislabels.draw")
    wrap(wcore, "auto_assign_coord_positions", "wcsaxes.auto_assign_coord_positions")
    wrap(matplotlib.text.Text, "draw", "mpl.Text.draw")
    wrap(ql.Coordinator, "_update", "solar.Coordinator._update")
    wrap(tools.CoordinateTool, "_draw", "solar.CoordinateTool._draw")
    wrap(tools.FrameTimeTool, "_refresh", "solar.FrameTimeTool._refresh")

    original_draw = MplCanvas.draw

    def draw(self, *args, **kwargs):
        if self not in _CANVASES:
            _CANVASES.append(self)
        t = time.perf_counter()
        try:
            return original_draw(self, *args, **kwargs)
        finally:
            dt = time.perf_counter() - t
            label = getattr(self, "_perf_label", "?")
            DRAWS[label] += 1
            DRAW_T[label].append(dt)
            TIMES["canvas.draw"] += dt
            CALLS["canvas.draw"] += 1

    MplCanvas.draw = draw


def label_canvas(viewer, label):
    canvas = viewer.figure.canvas
    canvas._perf_label = label
    if canvas not in _CANVASES:
        _CANVASES.append(canvas)


def reset_counters():
    TIMES.clear()
    CALLS.clear()
    DRAWS.clear()
    DRAW_T.clear()


def snapshot():
    return dict(TIMES), dict(CALLS), dict(DRAWS), {k: list(v) for k, v in DRAW_T.items()}


def med(values):
    return statistics.median(values) if values else float("nan")


@contextmanager
def profiled(path, sort="cumulative", limit=60, strip=True):
    prof = cProfile.Profile()
    prof.enable()
    try:
        yield prof
    finally:
        prof.disable()
        prof.dump_stats(path + ".pstats")
        out = io.StringIO()
        stats = pstats.Stats(prof, stream=out)
        if strip:
            stats.strip_dirs()
        stats.sort_stats(sort).print_stats(limit)
        with open(path + ".txt", "w") as fh:
            fh.write(out.getvalue())


def load_raster(pattern, window, stack=False):
    from glue_solar.sources.loaders.iris import raster_data

    t = time.perf_counter()
    datasets = raster_data(files(pattern), windows=[window], stack=stack)
    print(f"loaded {pattern} [{window}] stack={stack} in {time.perf_counter() - t:.1f} s:",
          [(d.label, d.shape) for d in datasets], f"maxrss {rss_gb():.2f} GB", flush=True)
    return datasets


def load_sji(pattern):
    from glue_solar.sources.loaders.iris import image_data

    t = time.perf_counter()
    [path] = files(pattern)
    data = image_data(path)
    print(f"loaded {data.label} {data.shape} in {time.perf_counter() - t:.1f} s, maxrss {rss_gb():.2f} GB", flush=True)
    return data


def open_quicklook(case):
    """Open the quicklook on case A (4000255147 Si IV 1403 + SJI 1400) or B (4000005156 stack + SJI 2796 deconvolved)."""
    instrument()
    app = make_app()
    if case == "A":
        datasets = load_raster("*4000255147_raster/*_r00000.fits", "Si IV 1403")
        datasets.append(load_sji("*4000255147_SJI_1400_t000.fits.gz"))
    else:
        datasets = load_raster("*4000005156_raster/*.fits", "Si IV 1403", stack=True)
        datasets.append(load_sji("*4000005156_SJI_2796_t000_deconvolved.fits.gz"))
    from glue_solar.quicklook import quicklook

    t = time.perf_counter()
    viewers = quicklook(app, datasets, window="Si IV 1403")
    settle()
    wait(1.0)  # mpl-scatter-density holds the old image for 500 ms after each resize
    pressed = [r for r, v in viewers.items() if r != "sji" and getattr(getattr(v, "axes", None), "_composite_image", None) is not None and v.axes._composite_image._pressed]
    assert not pressed, pressed
    print(f"quicklook opened and settled in {time.perf_counter() - t:.2f} s, maxrss {rss_gb():.2f} GB", flush=True)
    panels = {role: viewers[role] for role in ("map", "spectrogram", "wavelength")}
    panels["sji"] = viewers["sji"][0]
    for role, v in panels.items():
        label_canvas(v, role)
    label_canvas(viewers["spectrum"], "spectrum")
    for role, v in panels.items():
        w, h = v.figure.canvas.width(), v.figure.canvas.height()
        print(f"{role:12s} canvas {w}x{h} px, dpr {v.figure.canvas.device_pixel_ratio}, fig dpi {v.figure.dpi}, "
              f"x={v.state.x_att} y={v.state.y_att} slices={v.state.slices} "
              f"changing_slice_requires_wcs_update={v._changing_slice_requires_wcs_update}", flush=True)
    return app, viewers, panels


def slider(viewer, axis, start=None):
    origin = viewer.state.slices[axis] if start is None else start
    count = [0]

    def setter(i):  # every call moves one step on
        count[0] += 1
        s = list(viewer.state.slices)
        s[axis] = origin + count[0]
        viewer.state.slices = tuple(s)

    return setter


def pan(viewer, frac=0.05):
    from echo import delay_callback

    st = viewer.state

    def setter(i):
        dx = (st.x_max - st.x_min) * frac * (1 if i % 2 == 0 else -1)
        with delay_callback(st, "x_min", "x_max", "y_min", "y_max"):
            st.x_min += dx
            st.x_max += dx

    return setter


def zoom(viewer):
    from echo import delay_callback

    st = viewer.state

    def setter(i):
        f = 0.9 if i % 2 == 0 else 1 / 0.9
        xc, yc = (st.x_min + st.x_max) / 2, (st.y_min + st.y_max) / 2
        hx, hy = (st.x_max - st.x_min) / 2 * f, (st.y_max - st.y_min) / 2 * f
        with delay_callback(st, "x_min", "x_max", "y_min", "y_max"):
            st.x_min, st.x_max, st.y_min, st.y_max = xc - hx, xc + hx, yc - hy, yc + hy

    return setter


def contrast(viewer):
    from echo import delay_callback

    layer = viewer.state.layers[0]

    def setter(i):  # what glue-qt's ContrastBiasMode.move does per mouse event
        with delay_callback(layer, "bias", "contrast"):
            layer.bias = 0.4 + 0.01 * (i % 10)
            layer.contrast = 1.0 + 0.02 * (i % 10)

    return setter
