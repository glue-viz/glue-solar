"""Where CompositeArray spends its time for one opaque colormapped layer at maximized-viewer size."""
import time

import numpy as np

import common as c
from common import med

app, viewers, panels = c.open_quicklook("A")
v = panels["sji"]
v.parent().showMaximized()
c.settle()
c.wait(1.0)
ax = v.axes
w = ax.get_position().width * ax.figure.get_figwidth()
h = ax.get_position().height * ax.figure.get_figheight()
(xmin, xmax), (ymin, ymax) = sorted(ax.get_xlim()), sorted(ax.get_ylim())
bounds = [(ymin, ymax, int(round(h * 72))), (xmin, xmax, int(round(w * 72)))]
comp = ax._composite
comp(bounds=bounds)  # fill the FRB cache
ts = []
for _ in range(30):
    t = time.perf_counter()
    img = comp(bounds=bounds)
    ts.append(time.perf_counter() - t)
print(f"composite {img.shape} {img.dtype}: median {med(ts)*1e3:.2f} ms")
with c.profiled("draw/profile_composite_sji_max", sort="tottime", limit=20):
    for _ in range(20):
        comp(bounds=bounds)
layer = next(iter(comp.layers.values()))
data = layer["array"](bounds=bounds)
cmap = layer["cmap"]
for name, fn in (("cmap(data) float64 RGBA", lambda: cmap(np.clip(data / np.nanmax(data), 0, 1))),
                 ("cmap(data, bytes=True)", lambda: cmap(np.clip(data / np.nanmax(data), 0, 1), bytes=True)),
                 ("cmap.with_extremes(bad=...)", lambda: cmap.with_extremes(bad=(0, 0, 0, 1))),
                 ("cmap(CMAP_SAMPLING)", lambda: cmap(np.concatenate([[np.nan], np.linspace(0, 1, 256)])))):
    tt = []
    for _ in range(30):
        t = time.perf_counter()
        fn()
        tt.append(time.perf_counter() - t)
    print(f"   {name:32s} {med(tt)*1e3:6.2f} ms")
