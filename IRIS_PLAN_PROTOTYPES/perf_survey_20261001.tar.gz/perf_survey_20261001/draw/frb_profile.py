"""
Cost of glue's fixed-resolution buffer for each quicklook panel, as the image artist asks for it.

usage: python frb_profile.py A|B [repeats]
Cases per panel: slider step (ARRAY_CACHE miss, PIXEL_CACHE hit), pan/zoom (both miss), and the Point subset mask.
"""

import sys
import time

import common as c
from common import med

case = sys.argv[1]
N = int(sys.argv[2]) if len(sys.argv) > 2 else 30
app, viewers, panels = c.open_quicklook(case)

from glue.core.fixed_resolution_buffer import ARRAY_CACHE, PIXEL_CACHE  # noqa: E402
from glue.viewers.image.layer_artist import ImageLayerArtist, ImageSubsetLayerArtist  # noqa: E402


def bounds_of(viewer):
    """The bins and range BaseImageArtist.make_image passes for the current view (72 dpi)."""
    ax = viewer.axes
    (xmin, xmax), (ymin, ymax) = sorted(ax.get_xlim()), sorted(ax.get_ylim())
    w = ax.get_position().width * ax.figure.get_figwidth()
    h = ax.get_position().height * ax.figure.get_figheight()
    ny, nx = int(round(h * 72)), int(round(w * 72))
    return [(ymin, ymax, ny), (xmin, xmax, nx)]


def bench(fn, prep, n=N):
    ts = []
    for _ in range(n + 2):
        prep()
        t = time.perf_counter()
        fn()
        ts.append(time.perf_counter() - t)
    return med(ts[2:]) * 1e3


for role, viewer in panels.items():
    b = bounds_of(viewer)
    data_la = next(la for la in viewer.layers if isinstance(la, ImageLayerArtist))
    sub_las = [la for la in viewer.layers if isinstance(la, ImageSubsetLayerArtist) and la.state.layer.label == "Point"]
    st = data_la.state
    shape = viewer.state.reference_data.shape
    print(f"\n== {role}: data {shape} {viewer.state.reference_data.get_component(st.attribute).data.dtype}, "
          f"buffer {b[1][2]}x{b[0][2]} (72 dpi of the axes)")
    get = lambda: st.get_sliced_data(bounds=b)  # noqa: E731
    step = bench(get, lambda: ARRAY_CACHE.pop(st.uuid, None))
    panz = bench(get, lambda: (ARRAY_CACHE.pop(st.uuid, None), PIXEL_CACHE.pop(st.uuid, None)))
    hit = bench(get, lambda: None)
    composite = viewer.axes._composite
    comp = bench(lambda: composite(bounds=b), lambda: None)
    print(f"   data FRB: slider step (array cache miss) {step:6.2f} ms | pan/zoom (both caches miss) {panz:6.2f} ms | "
          f"cache hit {hit:5.2f} ms | CompositeArray incl. hit+colormap {comp:5.2f} ms")
    for la in sub_las:
        sst = la.state
        mask = lambda: la.subset_array(b)  # noqa: E731
        m_step = bench(mask, lambda: ARRAY_CACHE.pop(sst.uuid, None))
        m_panz = bench(mask, lambda: (ARRAY_CACHE.pop(sst.uuid, None), PIXEL_CACHE.pop(sst.uuid, None)))
        print(f"   Point mask ({type(sst.layer.subset_state).__name__}, visible={sst.visible}): "
              f"recompute {m_step:6.2f} ms | pan/zoom {m_panz:6.2f} ms")
    with c.profiled(f"draw/profile_frb_{case}_{role}", sort="tottime", limit=25):
        for _ in range(10):
            ARRAY_CACHE.pop(st.uuid, None)
            get()
            for la in sub_las:
                ARRAY_CACHE.pop(la.state.uuid, None)
                la.subset_array(b)

# --- what-if: a SliceSubsetState mask built from the FRB's index arrays instead of a cube-sized array
import tracemalloc  # noqa: E402

import numpy as np  # noqa: E402
from glue.core.subset import SliceSubsetState  # noqa: E402

original_to_mask = SliceSubsetState.to_mask


def to_mask_from_view(self, data, view=None):
    if data is self.reference_data and isinstance(view, tuple) and view and all(isinstance(v, np.ndarray) for v in view):
        mask = np.ones(np.broadcast_shapes(*(v.shape for v in view)), dtype=bool)
        for v, s, n in zip(view, self.slices, data.shape):
            start, stop, step = s.indices(n)
            if (start, stop, step) != (0, n, 1):
                mask &= (v >= start) & (v < stop) & ((v - start) % step == 0)
        return mask
    return original_to_mask(self, data, view)


print("\n-- Point mask: cube-sized np.zeros (glue) vs built from the index arrays (what-if)")
for role, viewer in panels.items():
    b = bounds_of(viewer)
    for la in [la for la in viewer.layers if isinstance(la, ImageSubsetLayerArtist) and la.state.layer.label == "Point"]:
        sst = la.state
        rows = {}
        for name, fn in (("glue", original_to_mask), ("from view", to_mask_from_view)):
            SliceSubsetState.to_mask = fn
            ARRAY_CACHE.pop(sst.uuid, None)
            tracemalloc.start()
            out = la.subset_array(b)
            peak = tracemalloc.get_traced_memory()[1]
            tracemalloc.stop()
            t = bench(lambda: la.subset_array(b), lambda: ARRAY_CACHE.pop(sst.uuid, None))
            rows[name] = (t, peak, out)
        SliceSubsetState.to_mask = original_to_mask
        same = np.array_equal(rows["glue"][2], rows["from view"][2])
        print(f"   {role:12s} glue {rows['glue'][0]:5.2f} ms, traced peak {rows['glue'][1]/1e6:7.1f} MB | "
              f"from view {rows['from view'][0]:5.2f} ms, peak {rows['from view'][1]/1e6:5.1f} MB | identical RGBA: {same}")
