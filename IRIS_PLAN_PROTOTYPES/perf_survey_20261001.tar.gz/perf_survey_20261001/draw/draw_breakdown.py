"""
Break one canvas draw of each quicklook panel into image path, WCSAxes and the rest.

usage: python draw_breakdown.py A|B [repeats]
Each repeat invalidates the image artist (as a contrast change does: the FRB is cached, the colormap is not)
and calls canvas.draw() directly.
"""

import json
import sys
import time

import common as c
from common import med

case = sys.argv[1]
N = int(sys.argv[2]) if len(sys.argv) > 2 else 30
app, viewers, panels = c.open_quicklook(case)

KEYS = [
    "canvas.draw", "image.make_image", "composite", "layer.get_sliced_data", "frb", "subset_mask",
    "mpl.AxesImage.make_image", "wcsaxes.draw", "frame._update_patch_path", "wcsaxes.draw_wcsaxes",
    "wcsaxes._update_tick_and_label_positions", "wcsaxes.get_coord_range", "coord._update_ticks", "frame.sample",
    "frame.update_spines", "wcsaxes.auto_assign_coord_positions", "coord._draw_grid", "coord._draw_ticks",
    "ticklabels.draw", "ticks.draw", "coord._draw_axislabels", "axislabels.draw", "frame.draw", "mpl.Text.draw",
    "wcs.pixel_to_world_values", "qt.paintEvent",
]
out = {}
for role, viewer in panels.items():
    canvas = viewer.figure.canvas
    rows = []
    for i in range(N + 3):
        viewer.axes._composite_image.invalidate_cache()
        c.reset_counters()
        t = time.perf_counter()
        canvas.draw()
        dt = time.perf_counter() - t
        if i >= 3:
            times, calls, _, _ = c.snapshot()
            rows.append((dt, times, calls))
    summary = {k: med([r[1].get(k, 0) for r in rows]) for k in KEYS}
    calls = {k: med([r[2].get(k, 0) for r in rows]) for k in KEYS}
    total = med([r[0] for r in rows])
    out[role] = dict(total=total, times=summary, calls=calls, size=(canvas.width(), canvas.height()),
                     dpr=canvas.device_pixel_ratio)
    print(f"\n== {role}: canvas {canvas.width()}x{canvas.height()} dpr {canvas.device_pixel_ratio}: "
          f"median draw {total*1e3:.1f} ms over {N}")
    for k in KEYS:
        print(f"   {k:42s} {summary[k]*1e3:7.2f} ms  {100*summary[k]/total:5.1f}%  calls {calls[k]}")
    image = summary["image.make_image"]
    wcsaxes = summary["wcsaxes.draw_wcsaxes"] + summary["frame._update_patch_path"]
    print(f"   -> image artists {image*1e3:.1f} ms ({100*image/total:.0f}%), WCSAxes ticks/labels/frame "
          f"{wcsaxes*1e3:.1f} ms ({100*wcsaxes/total:.0f}%), rest of matplotlib {1e3*(total-image-wcsaxes):.1f} ms")

with open(f"draw/draw_breakdown_{case}_{'dpr2' if c.os.environ.get('QT_SCALE_FACTOR') == '2' else 'dpr1'}.json", "w") as fh:
    json.dump(out, fh, indent=1)
