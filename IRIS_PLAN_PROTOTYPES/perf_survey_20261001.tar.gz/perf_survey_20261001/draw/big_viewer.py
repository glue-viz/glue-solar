"""
How the draw splits when one viewer is large (as a user maximizes it): image path vs WCSAxes.

usage: python big_viewer.py A|B [repeats]
Per panel: a redraw after new image data (FRB array cache dropped, as a slider step does) and a redraw
after a colour change (FRB cached, as a contrast/bias drag does).
"""

import sys
import time

import common as c
from common import med

case = sys.argv[1]
N = int(sys.argv[2]) if len(sys.argv) > 2 else 20
VARIANTS = set(sys.argv[3].split("+")) if len(sys.argv) > 3 else set()  # f32 (composite as float32), nopixmask

if "f32" in VARIANTS:
    import numpy as np
    from glue.viewers.image.composite_array import CompositeArray

    _call = CompositeArray.__call__

    def __call__(self, bounds=None):
        img = _call(self, bounds=bounds)
        return None if img is None else img.astype(np.float32)

    CompositeArray.__call__ = __call__

app, viewers, panels = c.open_quicklook(case)

if "nopixmask" in VARIANTS:
    from glue.viewers.image.layer_artist import ImageSubsetLayerArtist

    for v in panels.values():
        for la in v.layers:
            if isinstance(la, ImageSubsetLayerArtist):
                la.image_artist.set_visible(False)
                la.image_artist.set_visible = lambda *_: None  # glue re-shows it on every update
print("variants:", VARIANTS or "none")

from glue.core.fixed_resolution_buffer import ARRAY_CACHE  # noqa: E402
from glue.viewers.image.layer_artist import ImageLayerArtist, ImageSubsetLayerArtist  # noqa: E402

KEYS = ("image.make_image", "frb", "composite", "subset_mask", "mpl.AxesImage.make_image", "wcsaxes.draw_wcsaxes",
        "frame._update_patch_path", "mpl.Text.draw", "wcs.pixel_to_world_values", "qt.paintEvent")

for role in ("sji", "spectrogram"):
    viewer = panels[role]
    viewer.parent().showMaximized()
    c.settle()
    c.wait(1.0)
    canvas = viewer.figure.canvas
    layers = [la for la in viewer.layers if isinstance(la, (ImageLayerArtist, ImageSubsetLayerArtist))]
    for name, prep in (("new data (slider-like)", lambda: [ARRAY_CACHE.pop(la.state.uuid, None) for la in layers]),
                       ("colour only (contrast-like)", lambda: None)):
        rows = []
        for i in range(N + 3):
            prep()
            viewer.axes._composite_image.invalidate_cache()
            c.reset_counters()
            t = time.perf_counter()
            canvas.draw()
            canvas.repaint()  # the Qt paint that blits the Agg buffer
            dt = time.perf_counter() - t
            if i >= 3:
                rows.append((dt, *c.snapshot()[:2]))
        total = med([r[0] for r in rows])
        parts = {k: med([r[1].get(k, 0) for r in rows]) for k in KEYS}
        wcsaxes = parts["wcsaxes.draw_wcsaxes"] + parts["frame._update_patch_path"]
        print(f"== {role} maximized, canvas {canvas.width()}x{canvas.height()} dpr {canvas.device_pixel_ratio}, "
              f"{name}: draw+paint median {total*1e3:.1f} ms (n={N}); image artists {parts['image.make_image']*1e3:.1f} ms "
              f"[frb {parts['frb']*1e3:.1f}, colormap/stretch {(parts['composite']-0)*1e3:.1f} incl. frb, "
              f"mpl resample {parts['mpl.AxesImage.make_image']*1e3:.1f}], WCSAxes {wcsaxes*1e3:.1f} ms "
              f"({100*wcsaxes/total:.0f}%), Qt paint {parts['qt.paintEvent']*1e3:.1f} ms", flush=True)
    viewer.parent().showNormal()
    c.settle()
