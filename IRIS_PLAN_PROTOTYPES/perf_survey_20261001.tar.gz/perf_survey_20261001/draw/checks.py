"""
Two checks: (1) does a float32 CompositeArray change the rendered pixels; (2) what the λ-time panel's
near-constant latitude tick labels cost per draw (hidden in this process only).
"""
import time

import numpy as np

import common as c
from common import med

app, viewers, panels = c.open_quicklook("A")
from glue.viewers.image.composite_array import CompositeArray  # noqa: E402

# (1) float32 composite: compare Agg buffers
for role in ("sji", "spectrogram"):
    v = panels[role]
    canvas = v.figure.canvas
    v.axes._composite_image.invalidate_cache()
    canvas.draw()
    ref = np.asarray(canvas.buffer_rgba()).copy()
    call = CompositeArray.__call__
    CompositeArray.__call__ = lambda self, bounds=None: (lambda img: None if img is None else img.astype(np.float32))(call(self, bounds=bounds))
    v.axes._composite_image.invalidate_cache()
    canvas.draw()
    f32 = np.asarray(canvas.buffer_rgba()).copy()
    CompositeArray.__call__ = call
    diff = np.abs(ref.astype(int) - f32.astype(int))
    print(f"{role}: float32 composite vs float64: {np.count_nonzero(diff.any(axis=-1))} of {diff.shape[0]*diff.shape[1]} "
          f"pixels differ, max channel difference {diff.max()}")

# (2) λ-time panel without the latitude coordinate's ticks and tick labels
v = panels["wavelength"]
canvas = v.figure.canvas


def draws(n=30):
    ts = []
    for _ in range(n + 3):
        v.axes._composite_image.invalidate_cache()
        t = time.perf_counter()
        canvas.draw()
        ts.append(time.perf_counter() - t)
    return med(ts[3:]) * 1e3


base = draws()
lat = [coord for coord in v.axes.coords if coord.coord_type == "latitude"][0]
labels = {k: len(t) for k, t in lat._ticklabels.text.items()}
lat.set_ticklabel_visible(False)
no_labels = draws()
lat.set_ticks_visible(False)
no_ticks = draws()
print(f"λ-time panel draw: {base:.1f} ms with {labels} latitude tick labels | without them {no_labels:.1f} ms | "
      f"without latitude ticks too {no_ticks:.1f} ms")
