"""
Runtime what-if experiments (this process only; nothing on disk changes) to size candidate fixes.

usage: python whatif.py A|B VARIANT [repeats]
VARIANT:
  base        no change
  inplace     glue: on a slice change, move the slice of the WCS view WCSAxes already holds instead of
              _set_wcs (reset_wcs + four label sets that each recompute all ticks)
  nohidden    glue: a subset layer that is hidden does not redraw its viewer on update
  noticks     astropy: _update_ticks skips coordinates that show no ticks, tick labels or grid
  nopixmask   glue: no mask image for a PixelSubsetState (its crosshair lines remain)
  floor       upper bound: no WCSAxes ticks/labels/frame at all (what blitting the image alone could reach)
Prints per action the median set/total time, draws per canvas, and a fingerprint of the tick labels drawn.
"""

import json
import sys
import time

import numpy as np

import common as c
from common import med

case, variant = sys.argv[1], sys.argv[2]
VARIANTS = set(variant.split("+"))  # e.g. inplace+nohidden+wcscache
N = int(sys.argv[3]) if len(sys.argv) > 3 else 15


def find_sliced(transform):
    from astropy.wcs.wcsapi import SlicedLowLevelWCS

    seen, todo = set(), [transform]
    while todo:
        t = todo.pop()
        if id(t) in seen:
            continue
        seen.add(id(t))
        if isinstance(t, SlicedLowLevelWCS):
            return t
        for name in ("_a", "_b", "wcs", "_child", "_parents"):
            v = getattr(t, name, None)
            if v is not None and not isinstance(v, dict):
                todo.append(v)
    return None


if "inplace" in VARIANTS:
    from glue_qt.viewers.image.data_viewer import ImageViewer

    original = ImageViewer._on_slice_change

    def _on_slice_change(self, event=None):
        if not self._changing_slice_requires_wcs_update:
            return
        sliced = find_sliced(self.axes.coords._transform)
        if sliced is None:
            return original(self, event)
        wcs_slice = [slice(None) if s in ("x", "y") else s for s in self.state.wcsaxes_slice]
        sliced._slices_array = wcs_slice[::-1]
        sliced._slices_pixel = wcs_slice
        self.axes.figure.canvas.draw_idle()

    ImageViewer._on_slice_change = _on_slice_change

if "nohidden" in VARIANTS:
    from glue.utils import defer_draw
    from glue.viewers.image.layer_artist import ImageSubsetLayerArtist

    original_update = ImageSubsetLayerArtist.update

    @defer_draw
    def update(self, *event):
        if self.state.visible:
            return original_update(self, *event)
        # keep the data current without asking the canvas to redraw a layer nobody sees
        redraw, self.redraw = self.redraw, lambda: None
        try:
            original_update(self, *event)
        finally:
            del self.redraw

    ImageSubsetLayerArtist.update = update

if "noticks" in VARIANTS:
    from astropy.visualization.wcsaxes.coordinate_helpers import CoordinateHelper

    original_update_ticks = CoordinateHelper._update_ticks

    def _update_ticks(self):
        shown = (self._ticks.get_visible() and self._ticks.get_visible_axes()) or \
            (self._ticklabels.get_visible() and self._ticklabels.get_visible_axes()) or self._grid_lines_kwargs.get("visible", False)
        if not shown:
            self._ticks.clear()
            self._ticklabels.clear()
            self._lblinfo, self._lbl_world = [], []
            return
        return original_update_ticks(self)

    CoordinateHelper._update_ticks = _update_ticks

if "wcscache" in VARIANTS:
    # astropy: evaluate each distinct pixel array once per tick update instead of once per coordinate/spine
    from astropy.visualization.wcsaxes import WCSAxes
    from astropy.visualization.wcsaxes.wcsapi import WCSPixel2WorldTransform

    CACHE = {}
    original_transform = WCSPixel2WorldTransform.transform

    def transform(self, pixel):
        pixel = np.asarray(pixel)
        key = (id(self), pixel.shape, pixel.tobytes())
        if key not in CACHE:
            CACHE[key] = original_transform(self, pixel)
        return CACHE[key].copy()

    WCSPixel2WorldTransform.transform = WCSPixel2WorldTransform.transform_non_affine = transform
    for name in ("draw", "_update_tick_and_label_positions"):
        original_method = getattr(WCSAxes, name)

        def cleared(self, *a, _original=original_method, **k):
            CACHE.clear()
            try:
                return _original(self, *a, **k)
            finally:
                CACHE.clear()

        setattr(WCSAxes, name, cleared)

if "gluewcs" in VARIANTS:
    # glue-solar: convert helioprojective values with factors computed once per WCS, not unit objects per call
    import astropy.units as u

    from glue_solar.sources.loaders.iris import WCS_LOCK, _GlueWCS

    def pixel_to_world_values(self, *pixel_arrays):
        conv = self.__dict__.get("_perf_conv")
        if conv is None:
            conv = []
            for i, kind in enumerate(self.world_axis_physical_types):
                if kind and kind.startswith("custom:pos.helioprojective."):
                    unit = u.Unit(self._wcs.world_axis_units[i])
                    conv.append((i, kind.endswith(".lon"), (360 * u.deg).to_value(unit), unit.to(u.arcsec)))
            self.__dict__["_perf_conv"] = conv
        with WCS_LOCK:
            values = list(self._wcs.pixel_to_world_values(*pixel_arrays))
        for i, lon, full, factor in conv:
            v = np.asarray(values[i])
            if lon:
                v = (v + full / 2) % full - full / 2
            values[i] = v * factor
        return tuple(values)

    _GlueWCS.pixel_to_world_values = pixel_to_world_values

if "floor" in VARIANTS:
    from astropy.visualization.wcsaxes import WCSAxes

    WCSAxes.draw_wcsaxes = lambda self, renderer: None
    WCSAxes._update_tick_and_label_positions = lambda self, keep_coord_range=False: None

app, viewers, panels = c.open_quicklook(case)

if "nopixmask" in VARIANTS:
    from glue.viewers.image.layer_artist import ImageSubsetLayerArtist

    for v in panels.values():
        for la in v.layers:
            if isinstance(la, ImageSubsetLayerArtist):
                la.image_artist.set_visible(False)
                la.image_artist.set_visible = lambda *_: None  # glue re-shows it on every update

for role, v in panels.items():
    for coord in v.axes.coords:
        print(f"  {role:12s} coord {coord.coord_index} {coord.coord_type:9s} ticks {coord._ticks.get_visible_axes()} "
              f"labels {coord._ticklabels.get_visible_axes()} axislabel {coord._axislabels.get_visible_axes()!r} "
              f"{coord.get_axislabel()!r}")


def fingerprint(viewer):
    out = []
    for coord in viewer.axes.coords:
        texts = coord._ticklabels.text
        where = {k: [tuple(round(float(x), 2) for x in xy) for xy in v] for k, v in coord._ticklabels.data.items()}
        out.append((coord.coord_index, {k: list(v) for k, v in texts.items()}, where, coord.get_axislabel()))
    return out


def run(name, viewer, setter, n=N, warm=2):
    for i in range(warm):
        setter(-1 - i)
        c.settle()
    rows, prints = [], []
    for i in range(n):
        c.reset_counters()
        t0 = time.perf_counter()
        setter(i)
        t1 = time.perf_counter()
        c.settle()
        t2 = time.perf_counter()
        _, _, draws, draw_t = c.snapshot()
        rows.append((t1 - t0, t2 - t0, draws, {k: sum(v) for k, v in draw_t.items()}))
        prints.append({role: fingerprint(v) for role, v in panels.items()})
    labels = sorted({k for r in rows for k in r[2]})
    s = dict(set=med([r[0] for r in rows]), total=med([r[1] for r in rows]),
             draws={k: med([r[2].get(k, 0) for r in rows]) for k in labels},
             draw_ms={k: round(1e3 * med([r[3].get(k, 0) for r in rows]), 1) for k in labels})
    print(f"== {variant:9s} {name:34s} set {s['set']*1e3:6.1f} ms  total {s['total']*1e3:6.1f} ms  "
          f"draws {s['draws']}  draw ms {s['draw_ms']}", flush=True)
    return s, prints


if panels["map"].state.reference_data.ndim == 3:
    actions = [("spectrogram: exposure step", panels["spectrogram"], c.slider(panels["spectrogram"], 0)),
               ("λ-time: slit step", panels["wavelength"], c.slider(panels["wavelength"], 1)),
               ("map: wavelength step", panels["map"], c.slider(panels["map"], 2))]
else:
    actions = [("spectrogram: raster step", panels["spectrogram"], c.slider(panels["spectrogram"], 1)),
               ("λ-scan: slit step", panels["wavelength"], c.slider(panels["wavelength"], 2)),
               ("map: wavelength step", panels["map"], c.slider(panels["map"], 3))]
actions += [("sji: frame step", panels["sji"], c.slider(panels["sji"], 0)),
            ("map: contrast/bias drag event", panels["map"], c.contrast(panels["map"])),
            ("sji: contrast/bias drag event", panels["sji"], c.contrast(panels["sji"])),
            ("spectrogram: pan 5%", panels["spectrogram"], c.pan(panels["spectrogram"]))]

results = {}
for name, viewer, setter in actions:
    results[name] = run(name, viewer, setter)
dpr = "dpr2" if c.os.environ.get("QT_SCALE_FACTOR") == "2" else "dpr1"
with open(f"draw/whatif_{case}_{variant}_{dpr}.json", "w") as fh:
    json.dump(results, fh, default=str)
