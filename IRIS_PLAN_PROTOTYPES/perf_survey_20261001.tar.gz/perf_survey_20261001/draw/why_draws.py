"""
Who asks each canvas to redraw during one user action, and a cProfile of that action.

usage: python why_draws.py A|B
"""

import sys
import time
import traceback
from collections import Counter, defaultdict

import common as c

case = sys.argv[1]
app, viewers, panels = c.open_quicklook(case)

from matplotlib.backends.backend_qt import FigureCanvasQT  # noqa: E402
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg  # noqa: E402

EVENTS = []  # ordered (kind, canvas label, detail)


def short_stack(skip=2):
    frames = traceback.extract_stack()[:-skip]
    keep = [f for f in frames if any(k in f.filename for k in ("glue", "echo/", "mpl_scatter")) and "/draw/" not in f.filename]
    return " < ".join(f"{f.filename.split('site-packages/')[-1].split('glue-solar-main/')[-1]}:{f.lineno}:{f.name}"
                      for f in reversed(keep[-8:]))


_orig_draw_idle = FigureCanvasQTAgg.draw_idle


def draw_idle(self):
    EVENTS.append(("request", getattr(self, "_perf_label", "?"), short_stack()))
    return _orig_draw_idle(self)


FigureCanvasQTAgg.draw_idle = draw_idle  # glue's defer_draw wraps and restores this class attribute

from glue.utils.misc import DeferredMethod  # noqa: E402

_orig_deferred_call = DeferredMethod.__call__


def deferred_call(self, instance, *a, **k):
    EVENTS.append(("deferred", getattr(instance, "_perf_label", "?"), short_stack()))
    return _orig_deferred_call(self, instance, *a, **k)


DeferredMethod.__call__ = deferred_call

from glue_qt.viewers.matplotlib.widget import MplCanvas  # noqa: E402

_wrapped_draw = MplCanvas.draw


def draw(self, *a, **k):
    EVENTS.append(("DRAW", getattr(self, "_perf_label", "?"), ""))
    return _wrapped_draw(self, *a, **k)


MplCanvas.draw = draw

actions = {
    "A": [("spectrogram exposure step", c.slider(panels["spectrogram"], 0)),
          ("sji frame step", c.slider(panels["sji"], 0)),
          ("spectrogram pan", c.pan(panels["spectrogram"])),
          ("map contrast", c.contrast(panels["map"]))],
    "B": [("spectrogram raster step", c.slider(panels["spectrogram"], 1)),
          ("sji frame step", c.slider(panels["sji"], 0))],
}[case]

for name, setter in actions:
    for i in range(3):  # warm
        setter(i)
        c.settle()
    for rep in range(3):
        EVENTS.clear()
        setter(rep)
        c.settle()
        draws = Counter(label for kind, label, _ in EVENTS if kind == "DRAW")
        print(f"\n######## {name} (rep {rep}) draws:", dict(draws))
        if rep == 2:
            for kind, label, stack in EVENTS:
                print(f"   {kind:8s} {label:12s} {stack}")
    path = f"draw/profile_{case}_{name.replace(' ', '_')}"
    setter(10)
    c.settle()
    with c.profiled(path, limit=80):
        for rep in range(5):
            setter(11 + rep)
            c.settle()
    print("profile written to", path)
