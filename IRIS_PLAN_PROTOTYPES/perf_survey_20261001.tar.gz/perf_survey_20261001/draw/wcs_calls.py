"""
Per-call cost of the WCS layers WCSAxes goes through on every tick update, by number of points.

WCSAxes (sliced) -> glue_solar _GlueWCS -> irispy's WCS (astropy FITS WCS for rasters, gWCS for SJI).
"""

import sys
import time

import numpy as np

import common as c
from common import med

from astropy.wcs.wcsapi import SlicedLowLevelWCS  # noqa: E402

raster = c.load_raster("*4000255147_raster/*_r00000.fits", "Si IV 1403")[0]
sji = c.load_sji("*4000255147_SJI_1400_t000.fits.gz")
print(type(raster.coords._wcs), type(sji.coords._wcs))
print("raster inner:", type(raster.coords._wcs).__mro__[:3])
print("sji inner:", type(sji.coords._wcs).__mro__[:3])


def bench(f, args, n=200):
    f(*args)
    ts = []
    for _ in range(n):
        t = time.perf_counter()
        f(*args)
        ts.append(time.perf_counter() - t)
    return med(ts) * 1e3


for name, data, wcsaxes_slice in (("raster spectrogram (x=λ, y=slit, exposure 800)", raster, ["x", "y", 800]),
                                   ("raster slit-vs-time (x=exposure, y=slit, λ 134)", raster, [134, "y", "x"]),
                                   ("SJI frame (x, y, frame 200)", sji, ["x", "y", 200])):
    glue_wcs = data.coords
    inner = glue_wcs._wcs
    # glue passes slices in WCS (x first) order to WCSAxes, which keeps the pixel axes marked x/y
    keep = [i for i, s in enumerate(wcsaxes_slice) if s in ("x", "y")]
    sl = [slice(None) if s in ("x", "y") else s for s in wcsaxes_slice]
    sliced = SlicedLowLevelWCS(glue_wcs, sl[::-1])  # numpy order
    print(f"\n{name}: world types {glue_wcs.world_axis_physical_types}")
    for npts in (2, 50, 2601):
        px = [np.linspace(0, 100, npts) if s in ("x", "y") else np.full(npts, s) for s in wcsaxes_slice]
        pxs = [np.linspace(0, 100, npts) for _ in range(sliced.pixel_n_dim)]
        t_inner = bench(inner.pixel_to_world_values, px)
        t_glue = bench(glue_wcs.pixel_to_world_values, px)
        t_sliced = bench(sliced.pixel_to_world_values, pxs)
        print(f"  {npts:5d} points: inner irispy WCS {t_inner:6.3f} ms | glue-solar _GlueWCS {t_glue:6.3f} ms "
              f"(+{t_glue - t_inner:5.3f}) | WCSAxes sliced view {t_sliced:6.3f} ms")
    t_units = bench(lambda: inner.world_axis_units, [])
    print(f"  inner.world_axis_units property: {t_units:.3f} ms per access")
