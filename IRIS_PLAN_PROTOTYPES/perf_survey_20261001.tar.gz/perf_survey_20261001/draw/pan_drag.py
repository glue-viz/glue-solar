"""
A mouse-drag pan with glue-qt's Pan tool, as matplotlib events: cost per motion event and on release.

usage: python pan_drag.py A|B [moves]
"""

import sys
import time

from matplotlib.backend_bases import MouseButton, MouseEvent

import common as c
from common import med

case = sys.argv[1]
N = int(sys.argv[2]) if len(sys.argv) > 2 else 30
app, viewers, panels = c.open_quicklook(case)


def send(viewer, name, px, py, button=1):
    canvas = viewer.figure.canvas
    extra = {"buttons": {MouseButton(button)}} if name == "motion_notify_event" else {}  # the button is held
    canvas.callbacks.process(name, MouseEvent(name, canvas, px, py, button=button, **extra))


for role in ("spectrogram", "sji", "map"):
    viewer = panels[role]
    viewer.toolbar.active_tool = "mpl:pan"
    c.settle()
    bbox = viewer.axes.bbox
    x0, y0 = bbox.x0 + bbox.width / 2, bbox.y0 + bbox.height / 2
    send(viewer, "button_press_event", x0, y0)
    c.settle()
    rows = []
    for i in range(N):
        c.reset_counters()
        t = time.perf_counter()
        send(viewer, "motion_notify_event", x0 + 2 * (i + 1), y0 + (i + 1))  # 2 px right, 1 px up per event
        t1 = time.perf_counter()
        c.settle()
        times, calls, draws, _ = c.snapshot()
        rows.append((time.perf_counter() - t, t1 - t, times, calls, draws))
    c.reset_counters()
    t = time.perf_counter()
    send(viewer, "button_release_event", x0 + 2 * N, y0 + N)
    c.settle()
    release = time.perf_counter() - t
    rtimes, rcalls, rdraws, _ = c.snapshot()
    keys = ("canvas.draw", "image.make_image", "composite", "frb", "subset_mask", "mpl.AxesImage.make_image",
            "wcsaxes.draw_wcsaxes", "wcs.pixel_to_world_values", "mpl.Text.draw")
    print(f"\n== {role}: pan drag, {N} motion events: median {1e3 * med([r[0] for r in rows]):.1f} ms per event "
          f"(handler {1e3 * med([r[1] for r in rows]):.1f} ms), draws per event "
          f"{ {k: med([r[4].get(k, 0) for r in rows]) for k in sorted({k for r in rows for k in r[4]})} }")
    for k in keys:
        print(f"   {k:30s} {1e3 * med([r[2].get(k, 0) for r in rows]):6.2f} ms  calls {med([r[3].get(k, 0) for r in rows])}")
    print(f"   release: {release * 1e3:.1f} ms, draws {dict(rdraws)}, frb {rcalls.get('frb', 0)} calls "
          f"{rtimes.get('frb', 0) * 1e3:.1f} ms, composite {rtimes.get('composite', 0) * 1e3:.1f} ms")
    viewer.toolbar.active_tool = None
    c.settle()
