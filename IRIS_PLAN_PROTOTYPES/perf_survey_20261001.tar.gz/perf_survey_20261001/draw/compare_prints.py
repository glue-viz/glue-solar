"""Compare the tick-label fingerprints (texts, data positions, axis labels) of a what-if run with the baseline."""
import json
import sys

case, variant, dpr = sys.argv[1], sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else "dpr1"
a = json.load(open(f"whatif_{case}_base_{dpr}.json"))
b = json.load(open(f"whatif_{case}_{variant}_{dpr}.json"))
for k in a:
    pa, pb = a[k][1], b[k][1]
    diffs = [(i, role) for i, (x, y) in enumerate(zip(pa, pb)) for role in x if x[role] != y[role]]
    print(f"{variant:9s} {k:34s} identical ticks/labels/positions in {len(pa) - len({i for i, _ in diffs})}/{len(pa)} steps"
          + (f"; differs at {diffs[:4]}" if diffs else ""))
