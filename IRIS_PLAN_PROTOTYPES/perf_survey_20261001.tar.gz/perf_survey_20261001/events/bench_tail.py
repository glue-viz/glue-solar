"""
G. How long after the image panels finish does the spectrum panel finish? (n=9 per action)
'images done' = end of the last draw of map/spectrogram/wavelength/sji; 'spectrum done' = end of the last
spectrum draw; worker runs = glue-qt ComputeWorker runs of the point's profile per action.
"""
import os
import statistics
import time

import harness as H

HERE = os.path.dirname(os.path.abspath(__file__))
H.install()
datasets, _ = H.load()
raster, sji = datasets
app, V = H.build(datasets)

from qtpy import QtCore, QtWidgets  # noqa: E402
from qtpy.QtTest import QTest  # noqa: E402

sp, mp = V["spectrogram"], V["map"]
qs = sp.options_widget().slice_helper._sliders[0].findChild(QtWidgets.QSlider, "value_slice_center")
k = {"n": 0}


def exposure_step():
    k["n"] += 1
    qs.triggerAction(QtWidgets.QAbstractSlider.SliderSingleStepAdd if k["n"] % 2 else QtWidgets.QAbstractSlider.SliderSingleStepSub)


ny, nx = raster.shape[1], raster.shape[0]
pts = [(nx // 2 + 40, ny // 2 + 20), (nx // 2 - 40, ny // 2 - 20)]


def click():
    k["n"] += 1
    xd, yd = pts[k["n"] % 2]
    canvas = mp.figure.canvas
    xs, ys = mp.axes.transData.transform((xd, yd))
    pos = QtCore.QPoint(int(xs), int(canvas.height() - ys))
    QTest.mousePress(canvas, QtCore.Qt.LeftButton, QtCore.Qt.NoModifier, pos)
    QTest.mouseRelease(canvas, QtCore.Qt.LeftButton, QtCore.Qt.NoModifier, pos)


out = open(os.path.join(HERE, "bench_tail.log"), "w")
for label, act in (("exposure step", exposure_step), ("pixel click", click)):
    act(); H.settle(app)
    rows = []
    for _ in range(9):
        H.R.reset(); H.R.on = True; H.R.trace = True
        H.R.t0 = time.perf_counter()
        act()
        H.settle(app)
        H.R.on = H.R.trace = False
        ends = [(t, d.split()[0]) for t, th, ev, d in H.R.timeline if ev == "draw end"]
        img = max(t for t, c in ends if c != "spectrum")
        spec = max(t for t, c in ends if c == "spectrum")
        runs = sum(1 for t, th, ev, d in H.R.timeline if th == "worker" and ev == "begin")
        rows.append((img, spec, runs))
    med = lambda i: statistics.median(r[i] for r in rows) * 1e3  # noqa: E731
    line = (f"{label:14s} images done {med(0):6.1f} ms | spectrum done {med(1):6.1f} ms | spectrum after images "
            f"{statistics.median(r[1] - r[0] for r in rows) * 1e3:6.1f} ms (min {min(r[1] - r[0] for r in rows) * 1e3:.0f}, "
            f"max {max(r[1] - r[0] for r in rows) * 1e3:.0f}) | worker runs {[r[2] for r in rows]}")
    print(line, flush=True)
    out.write(line + "\n")
out.close()
app.close()
