"""
Micro-benchmarks behind the candidate fixes (nothing in glue/glue-qt/glue-solar is changed; this only
calls their public pieces in a built quicklook and times them).

A. MatplotlibImageMixin._set_wcs split into its parts, against a lean slice-change path.
B. The Point layer glue-solar hides on the slit-jaw viewer: a time step and a click with it hidden
   (as the quicklook leaves it) and with it removed from that viewer.
C. glue-qt's ComputeWorker latency for one spectrum recompute in an idle quicklook.
D. glue-solar's Coordinator._update when nothing moved (what a wavelength step triggers).
E. Opening the quicklook: QColormapCombo icon rendering and _set_wcs counts.
"""

import cProfile
import io
import os
import pstats
import statistics
import time

import harness as H

HERE = os.path.dirname(os.path.abspath(__file__))
out = open(os.path.join(HERE, "bench_fixes.log"), "w")


def say(*a):
    text = " ".join(str(x) for x in a)
    print(text, flush=True)
    out.write(text + "\n")


H.install()
datasets, _ = H.load()
raster, sji = datasets

from glue.config import colormaps as _cm  # noqa: E402

N_GLUE_CMAPS = len(_cm.members)
H.R.reset()
H.R.on = True
t0 = time.perf_counter()
app, V = H.build(datasets)
H.R.on = False
say(f"E. build (quicklook + 1.5 s idle) {time.perf_counter() - t0:.2f} s; recorded during build:")
for k, v in sorted(H.R.timed.items()):
    say(f"   {k}: {v} calls, {H.R.timed_t[k] * 1e3:.1f} ms")
say(f"   draws {dict(H.R.draws)} Agg {sum(H.R.draw_t.values()) * 1e3:.0f} ms")

from glue.config import colormaps  # noqa: E402
from glue_qt.utils.colors import QColormapCombo  # noqa: E402
from qtpy import QtWidgets  # noqa: E402

say(f"   colormaps registered: {len(colormaps.members)} (glue alone: {N_GLUE_CMAPS})")
ts = []
for _ in range(5):
    t = time.perf_counter()
    combo = QColormapCombo()
    ts.append(time.perf_counter() - t)
    combo.deleteLater()
say(f"   QColormapCombo() construction median {statistics.median(ts) * 1e3:.1f} ms (n=5) for {len(colormaps.members)} colormaps")
combo = QColormapCombo()
combo.resize(300, 30)
ts = []
for w in range(5):
    t = time.perf_counter()
    combo.resize(300 + 10 * (w + 1), 30)  # resizeEvent re-renders every icon
    H.settle(app, 2)
    ts.append(time.perf_counter() - t)
say(f"   QColormapCombo resize (re-renders icons) median {statistics.median(ts) * 1e3:.1f} ms (n=5, incl. settle polling)")


def med(f, n=9, between=None):
    ts = []
    for _ in range(n):
        t = time.perf_counter()
        f()
        ts.append(time.perf_counter() - t)
        if between:
            between()
    return statistics.median(ts) * 1e3


settle = lambda: H.settle(app, 5)  # noqa: E731

say("\nA. _set_wcs parts (median of 9, ms; draws they schedule are excluded)")
for name in ("sji", "spectrogram", "map"):
    v = V[name]
    s = v.state
    ax = v.axes
    ix = s.reference_data.ndim - 1 - s.x_att.axis
    iy = s.reference_data.ndim - 1 - s.y_att.axis
    xl, yl = s.x_axislabel, s.y_axislabel
    full = med(lambda: v._set_wcs(relim=False), between=settle)
    reset = med(lambda: ax.reset_wcs(slices=s.wcsaxes_slice, wcs=s.reference_data.coords), between=settle)
    v._set_wcs(relim=False)
    settle()
    ticks = med(lambda: ax._update_tick_and_label_positions(), between=settle)
    setx = med(lambda: ax.set_xlabel(xl), between=settle)
    direct = med(lambda: (ax.coords[ix].set_axislabel(xl), ax.coords[iy].set_axislabel(yl)), between=settle)
    appearance = med(lambda: v._update_appearance_from_settings(), between=settle)
    ticklabels = med(lambda: (v.update_x_ticklabel(), v.update_y_ticklabel()), between=settle)

    def lean():
        ax.reset_wcs(slices=s.wcsaxes_slice, wcs=s.reference_data.coords)
        ax.coords[ix].set_axislabel(xl)
        ax.coords[iy].set_axislabel(yl)
        v.update_x_ticklabel()
        v.update_y_ticklabel()

    lean_t = med(lean, between=settle)
    v._set_wcs(relim=False)  # leave the viewer as glue set it
    settle()
    say(f"  {name:12s} full _set_wcs {full:6.1f} | reset_wcs {reset:5.1f} | one _update_tick_and_label_positions {ticks:5.1f} "
        f"| axes.set_xlabel {setx:5.1f} | coords[i].set_axislabel x2 {direct:5.2f} | appearance {appearance:4.1f} "
        f"| tick label sizes x2 {ticklabels:4.1f} || lean path (reset + direct labels + sizes) {lean_t:5.1f}")


from qtpy import QtCore  # noqa: E402
from qtpy.QtTest import QTest  # noqa: E402


def slider(viewer, axis):
    return viewer.options_widget().slice_helper._sliders[axis].findChild(QtWidgets.QSlider, "value_slice_center")


def time_action(act, n=7):
    walls, sji_draws = [], []
    act(); settle()
    for _ in range(n):
        H.R.reset(); H.R.on = True
        t = time.perf_counter()
        act()
        walls.append(time.perf_counter() - t + H.settle(app))
        H.R.on = False
        sji_draws.append(H.R.draws.get("sji", 0))
    return statistics.median(walls) * 1e3, statistics.median(sji_draws), min(walls) * 1e3, max(walls) * 1e3


sp, mp, sj = V["spectrogram"], V["map"], V["sji"]
qs = slider(sp, 0)
k = {"n": 0}


def exposure_step():
    k["n"] += 1
    qs.triggerAction(QtWidgets.QAbstractSlider.SliderSingleStepAdd if k["n"] % 2 else QtWidgets.QAbstractSlider.SliderSingleStepSub)


ny, nx = raster.shape[1], raster.shape[0]
pts = [(nx // 2 + 40, ny // 2 + 20), (nx // 2 - 40, ny // 2 - 20)]


def click():
    k["n"] += 1
    xd, yd = pts[k["n"] % 2]
    canvas = mp.figure.canvas
    xs, ys = mp.axes.transData.transform((xd, yd))
    pos = QtCore.QPoint(int(xs), int(canvas.height() - ys))
    QTest.mousePress(canvas, QtCore.Qt.LeftButton, QtCore.Qt.NoModifier, pos)
    QTest.mouseRelease(canvas, QtCore.Qt.LeftButton, QtCore.Qt.NoModifier, pos)


say("\nB. hidden Point layer on the slit-jaw viewer (wall to idle median ms, SJI draws per action, min-max; n=7)")
hidden = [la for la in sj.layers if getattr(la.layer, "group", None) is not None]
say(f"   SJI viewer subset layers: {[(la.layer.label, la.layer.data.label[:12], la.state.visible) for la in hidden]}")
for label, act in (("exposure step", exposure_step), ("pixel click", click)):
    a = time_action(act)
    say(f"   {label:14s} Point layer hidden (as quicklook leaves it): {a[0]:6.1f} ms, SJI draws {a[1]}, range {a[2]:.0f}-{a[3]:.0f}")
for la in hidden:
    sj.remove_subset(la.layer)
settle()
for label, act in (("exposure step", exposure_step), ("pixel click", click)):
    a = time_action(act)
    say(f"   {label:14s} Point layer removed from SJI viewer:       {a[0]:6.1f} ms, SJI draws {a[1]}, range {a[2]:.0f}-{a[3]:.0f}")

say("\nC. spectrum recompute latency in an idle quicklook (glue-qt ComputeWorker), n=15")
spec = V["spectrum"]
la = next(la for la in spec.layers if getattr(la.layer, "group", None) is not None)
rows = []
for _ in range(15):
    H.R.reset(); H.R.on = True; H.R.trace = True
    H.R.t0 = time.perf_counter()
    la._calculate_profile(reset=True)
    wall = H.settle(app)
    H.R.on = H.R.trace = False
    tl = H.R.timeline
    wb = [t for t, th, ev, d in tl if th == "worker" and ev == "begin"]
    we = [t for t, th, ev, d in tl if th == "worker" and ev == "end"]
    pb = [t for t, th, ev, d in tl if th == "main" and ev == "begin" and "postthread" in d]
    if wb and we and pb:
        rows.append((wb[0], we[0] - wb[0], pb[-1] - we[0], wall, len(wb)))
say(f"   request -> worker starts: median {statistics.median(r[0] for r in rows) * 1e3:.1f} ms (min {min(r[0] for r in rows) * 1e3:.1f}, max {max(r[0] for r in rows) * 1e3:.1f})")
say(f"   compute itself:           median {statistics.median(r[1] for r in rows) * 1e3:.2f} ms")
say(f"   compute end -> postthread on main: median {statistics.median(r[2] for r in rows) * 1e3:.1f} ms (min {min(r[2] for r in rows) * 1e3:.1f}, max {max(r[2] for r in rows) * 1e3:.1f})")
say(f"   request -> idle:          median {statistics.median(r[3] for r in rows) * 1e3:.1f} ms; worker runs per request {[r[4] for r in rows]}")

say("\nD. glue-solar Coordinator._update with nothing moved (n=15)")
coord = app.data_collection._solar_coordinator
t = med(lambda: coord._update(), n=15, between=settle)
say(f"   median {t:.1f} ms")
prof = cProfile.Profile()
for _ in range(5):
    prof.enable(); coord._update(); prof.disable(); settle()
s = io.StringIO()
st = pstats.Stats(prof, stream=s)
st.sort_stats("cumulative").print_stats("glue_solar", 25)
say(s.getvalue())
out.close()
app.close()
