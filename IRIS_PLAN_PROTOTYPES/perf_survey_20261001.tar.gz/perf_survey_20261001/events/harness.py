"""
Event/callback instrumentation for a glue-solar quicklook (measurement only, nothing is patched on disk).

Runtime wrappers count and time: echo CallbackProperty notifications (per property and per callback),
echo global callbacks, glue hub broadcasts and each subscriber handler, canvas draw_idle requests
(raw, deferred and coalesced), real Agg draws and paint events, FRB/statistic computations, and
glue-solar's QTimer-driven Coordinator._update.
"""

import glob
import os
import resource
import sys
import threading
import time
from collections import Counter, defaultdict

sys.path.insert(0, os.environ.get("GS_PATH", "/Users/nabil/Git/glue-solar-main"))

DATA = "/Users/nabil/DATA/IRIS"
RASTER = glob.glob(f"{DATA}/*4000255147_raster/*_r00000.fits")
SJI = glob.glob(f"{DATA}/*4000255147_SJI_1400_t000.fits.gz")[0]
MAIN = threading.get_ident()


def rss_mb():
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1e6  # macOS: bytes


def origin(func):
    """'glue_solar', 'glue_qt', 'glue', 'echo', ... from a callable's module."""
    f = getattr(func, "func", func)  # functools.partial from echo's CallbackContainer
    f = getattr(f, "__func__", f)
    mod = getattr(f, "__module__", None) or ""
    return mod.split(".")[0], f"{mod}.{getattr(f, '__qualname__', repr(f))}"


class Rec:
    """Per-action counters. ``on`` gates recording; ``stack`` tracks nesting of timed frames."""

    def __init__(self):
        self.on = False
        self.reset()

    def reset(self):
        self.echo = Counter()  # (owner class, prop) -> notifications
        self.echo_cbs = Counter()  # (owner, prop, callback) -> calls
        self.echo_cb_t = defaultdict(float)
        self.glob = Counter()  # (owner, callback) -> global callback calls
        self.glob_t = defaultdict(float)
        self.glob_props = defaultdict(Counter)  # (owner, callback) -> props that triggered it
        self.aliases_t = 0.0
        self.aliases_n = 0
        self.msg = Counter()  # (message type, sender type) -> broadcasts
        self.msg_t = defaultdict(float)
        self.find_t = 0.0  # time inside Hub._find_handlers (subscriber filtering)
        self.find_subs = 0  # subscribers scanned
        self.handlers = Counter()  # (message type, handler) -> calls
        self.handler_t = defaultdict(float)
        self.draw_idle = Counter()  # canvas name -> draw_idle requests reaching the Qt canvas
        self.draw_idle_new = Counter()  # ... that actually scheduled a draw (not already pending)
        self.deferred = Counter()  # canvas -> requests made under defer_draw
        self.draws = Counter()  # canvas -> Agg draws
        self.draw_t = defaultdict(float)
        self.paints = Counter()
        self.paint_t = defaultdict(float)
        self.frb = Counter()  # (data label, subset?) -> compute_fixed_resolution_buffer calls (main thread)
        self.frb_t = defaultdict(float)
        self.stat = Counter()  # (thread, statistic) -> compute_statistic calls
        self.stat_t = defaultdict(float)
        self.timed = Counter()  # explicitly wrapped functions
        self.timed_t = defaultdict(float)
        self.solar_outer_t = 0.0  # time inside outermost glue_solar frames (incl. glue work they trigger)
        self.solar_outer_n = 0
        self.stack = []  # origins of active timed frames
        self.names = []  # names of active timed frames
        self.requesters = Counter()  # (canvas, innermost frame) -> draw_idle calls that scheduled a draw
        self.timeline = []  # (t, thread, event, detail) when trace is on
        self.trace = False
        self.t0 = time.perf_counter()


R = Rec()
CANVAS_NAMES = {}


def _cname(canvas):
    return CANVAS_NAMES.get(id(canvas), "other")


def mark(event, detail=""):
    if R.trace:
        thread = "main" if threading.get_ident() == MAIN else "worker"
        R.timeline.append((time.perf_counter() - R.t0, thread, event, detail))


def _enter(org, name=""):
    outer_solar = org == "glue_solar" and "glue_solar" not in R.stack
    R.stack.append(org)
    R.names.append(name)
    return outer_solar


def _leave(outer_solar, dt):
    R.stack.pop()
    R.names.pop()
    if outer_solar:
        R.solar_outer_t += dt
        R.solar_outer_n += 1


def install():
    from itertools import chain

    import echo.core as ec
    from glue.core import hub as ghub
    from glue.core.data import Data
    from glue.utils.misc import DeferredMethod
    from glue_qt.viewers.matplotlib.widget import MplCanvas
    from matplotlib.backends import backend_qt

    names = {}

    def prop_name(instance, prop):
        key = (type(instance), id(prop))
        if key not in names:
            names[key] = next(
                (n for k in type(instance).__mro__ for n, v in vars(k).items() if v is prop), "?"
            )
        return names[key]

    def notify(self, instance, old, new):
        if not self.enabled(instance):
            return
        iterators = []
        if container := self._callbacks.get(instance, None):
            iterators.append((cb, priority, 1) for cb, priority in container.iterator(priority=True, sort=False))
        if container := self._2arg_callbacks.get(instance, None):
            iterators.append((cb, priority, 2) for cb, priority in container.iterator(priority=True, sort=False))
        rec = R.on and threading.get_ident() == MAIN
        if rec:
            owner, pname = type(instance).__name__, prop_name(instance, self)
            R.echo[owner, pname] += 1
        for callback, _priority, args in sorted(chain(*iterators), key=lambda x: x[1], reverse=True):
            if not rec:
                callback(new) if args == 1 else callback(old, new)
                continue
            org, name = origin(callback)
            outer = _enter(org, f"{owner}.{pname}->{name}")
            t0 = time.perf_counter()
            try:
                callback(new) if args == 1 else callback(old, new)
            finally:
                dt = time.perf_counter() - t0
                _leave(outer, dt)
                R.echo_cbs[owner, pname, name] += 1
                R.echo_cb_t[owner, pname, name] += dt

    ec.CallbackProperty.notify = notify

    orig_aliases = ec.HasCallbackProperties._get_aliases_for

    def _get_aliases_for(self, name):
        if not (R.on and threading.get_ident() == MAIN):
            return orig_aliases(self, name)
        t0 = time.perf_counter()
        try:
            return orig_aliases(self, name)
        finally:
            R.aliases_t += time.perf_counter() - t0
            R.aliases_n += 1

    ec.HasCallbackProperties._get_aliases_for = _get_aliases_for

    def _notify_global(self, **kwargs):
        kwargs.update(
            {alias: value for prop_name_, value in kwargs.items() for alias in self._get_aliases_for(prop_name_)}
        )
        for prop in set(self._delayed_properties) | set(self._ignored_properties):
            if prop in kwargs:
                kwargs.pop(prop)
        if len(kwargs) > 0:
            rec = R.on and threading.get_ident() == MAIN
            for callback in self._global_callbacks:
                if not rec:
                    callback(**kwargs)
                    continue
                org, name = origin(callback)
                key = (type(self).__name__, name)
                outer = _enter(org, f"global {key[0]}->{name}")
                t0 = time.perf_counter()
                try:
                    callback(**kwargs)
                finally:
                    dt = time.perf_counter() - t0
                    _leave(outer, dt)
                    R.glob[key] += 1
                    R.glob_t[key] += dt
                    R.glob_props[key][",".join(sorted(kwargs))] += 1

    ec.HasCallbackProperties._notify_global = _notify_global

    orig_find = ghub.Hub._find_handlers

    def broadcast(self, message):
        if self._ignore.get(type(message), 0) > 0:
            return
        elif self._paused:
            self._queue.append(message)
            return
        rec = R.on and threading.get_ident() == MAIN
        if not rec:
            for subscriber, handler in orig_find(self, message):
                handler(message)
            return
        mkey = (type(message).__name__, type(message.sender).__name__)
        t0 = time.perf_counter()
        pairs = list(orig_find(self, message))
        R.find_t += time.perf_counter() - t0
        R.find_subs += len(self._subscriptions)
        mark("broadcast", mkey[0])
        for subscriber, handler in pairs:
            org, name = origin(handler)
            outer = _enter(org, f"{mkey[0]}->{name}")
            t1 = time.perf_counter()
            try:
                handler(message)
            finally:
                dt = time.perf_counter() - t1
                _leave(outer, dt)
                R.handlers[type(message).__name__, name] += 1
                R.handler_t[type(message).__name__, name] += dt
        R.msg[mkey] += 1
        R.msg_t[mkey] += time.perf_counter() - t0

    ghub.Hub.broadcast = broadcast

    orig_draw_idle = backend_qt.FigureCanvasQT.draw_idle

    def draw_idle(self):
        if R.on:
            R.draw_idle[_cname(self)] += 1
            if not (getattr(self, "_draw_pending", False) or getattr(self, "_is_drawing", False)):
                R.draw_idle_new[_cname(self)] += 1
                who = R.names[-1] if R.names else "(event loop)"
                R.requesters[_cname(self), who] += 1
                mark("schedule draw", f"{_cname(self)} by {who}")
        return orig_draw_idle(self)

    backend_qt.FigureCanvasQT.draw_idle = draw_idle

    orig_deferred_call = DeferredMethod.__call__

    def deferred_call(self, instance, *a, **k):
        if R.on and getattr(self.method, "__name__", "") == "draw_idle":
            R.deferred[_cname(instance)] += 1
        return orig_deferred_call(self, instance, *a, **k)

    DeferredMethod.__call__ = deferred_call

    orig_draw = MplCanvas.draw

    def draw(self, *a, **k):
        if not R.on:
            return orig_draw(self, *a, **k)
        outer = _enter("matplotlib-draw", f"draw {_cname(self)}")
        mark("draw begin", _cname(self))
        t0 = time.perf_counter()
        try:
            return orig_draw(self, *a, **k)
        finally:
            dt = time.perf_counter() - t0
            mark("draw end", f"{_cname(self)} {dt * 1e3:.1f} ms")
            _leave(outer, dt)
            R.draws[_cname(self)] += 1
            R.draw_t[_cname(self)] += dt

    MplCanvas.draw = draw

    orig_paint = MplCanvas.paintEvent

    def paintEvent(self, event):
        if not R.on:
            return orig_paint(self, event)
        t0 = time.perf_counter()
        try:
            return orig_paint(self, event)
        finally:
            R.paints[_cname(self)] += 1
            R.paint_t[_cname(self)] += time.perf_counter() - t0

    MplCanvas.paintEvent = paintEvent

    orig_frb = Data.compute_fixed_resolution_buffer

    def compute_fixed_resolution_buffer(self, *a, **k):
        if not (R.on and threading.get_ident() == MAIN):
            return orig_frb(self, *a, **k)
        t0 = time.perf_counter()
        try:
            return orig_frb(self, *a, **k)
        finally:
            key = (self.label[:24], "subset" if k.get("subset_state") is not None else "data")
            R.frb[key] += 1
            R.frb_t[key] += time.perf_counter() - t0

    Data.compute_fixed_resolution_buffer = compute_fixed_resolution_buffer

    orig_stat = Data.compute_statistic

    def compute_statistic(self, statistic, *a, **k):
        if not R.on:
            return orig_stat(self, statistic, *a, **k)
        t0 = time.perf_counter()
        try:
            return orig_stat(self, statistic, *a, **k)
        finally:
            thread = "main" if threading.get_ident() == MAIN else "worker"
            key = (thread, statistic, "subset" if k.get("subset_state") is not None else "data")
            R.stat[key] += 1
            R.stat_t[key] += time.perf_counter() - t0

    Data.compute_statistic = compute_statistic

    from astropy.visualization.wcsaxes.core import WCSAxes
    from glue.viewers.image.viewer import MatplotlibImageMixin
    from glue.viewers.profile.layer_artist import ProfileLayerArtist
    from glue_qt.utils.colors import QColormapCombo

    timed(WCSAxes, "_update_tick_and_label_positions", "astropy")
    timed(WCSAxes, "reset_wcs", "astropy")
    timed(MatplotlibImageMixin, "_set_wcs", "glue")
    timed(QColormapCombo, "_update_icons", "glue_qt")
    timed(ProfileLayerArtist, "_calculate_profile_thread", "glue", worker=True)
    timed(ProfileLayerArtist, "_calculate_profile_postthread", "glue")


def timed(cls, attr, org, worker=False):
    """Wrap ``cls.attr`` (a method run outside echo and the hub, e.g. by a QTimer) to count and time it."""
    import functools

    orig = getattr(cls, attr)

    @functools.wraps(orig)
    def wrapper(*a, **k):
        if worker and R.on and threading.get_ident() != MAIN:
            mark("begin", attr)
            t0 = time.perf_counter()
            try:
                return orig(*a, **k)
            finally:
                R.timed[f"worker {cls.__name__}.{attr}"] += 1
                R.timed_t[f"worker {cls.__name__}.{attr}"] += time.perf_counter() - t0
                mark("end", attr)
        if not (R.on and threading.get_ident() == MAIN):
            return orig(*a, **k)
        outer = _enter(org, f"{cls.__name__}.{attr}")
        mark("begin", f"{cls.__name__}.{attr}")
        t0 = time.perf_counter()
        try:
            return orig(*a, **k)
        finally:
            dt = time.perf_counter() - t0
            mark("end", f"{cls.__name__}.{attr} {dt * 1e3:.1f} ms")
            _leave(outer, dt)
            R.timed[f"{cls.__name__}.{attr}"] += 1
            R.timed_t[f"{cls.__name__}.{attr}"] += dt

    setattr(cls, attr, wrapper)


def load():
    from glue_solar.sources.loaders.iris import image_data, raster_data

    t0 = time.perf_counter()
    [raster] = raster_data(RASTER, windows=["Si IV 1403"])
    sji = image_data(SJI)
    return [raster, sji], time.perf_counter() - t0


def build(datasets):
    """A GlueApplication at 1600x1000 with the quicklook of ``datasets``; returns (app, viewers)."""
    import glue_solar
    from glue_qt.app import GlueApplication
    from glue_qt.utils import get_qapp

    import glue_solar.quicklook as ql

    print("glue_solar from", glue_solar.__file__, flush=True)
    get_qapp()
    glue_solar.setup()
    timed(ql.Coordinator, "_update", "glue_solar")
    app = GlueApplication()
    app.resize(1600, 1000)
    app.show()
    settle(app)
    t0 = time.perf_counter()
    viewers = ql.quicklook(app, datasets)
    settle(app, 5.0)
    print(f"quicklook() + settle: {time.perf_counter() - t0:.2f} s", flush=True)
    # canvases' 250 ms resize timers and similar fire later: let them pass before measuring
    from glue_qt.utils import get_qapp as _q
    t1 = time.perf_counter()
    while time.perf_counter() - t1 < 1.5:
        _q().processEvents()
        time.sleep(0.005)
    settle(app, 5.0)
    names = {"map": viewers["map"], "spectrogram": viewers["spectrogram"], "wavelength": viewers["wavelength"],
             "spectrum": viewers["spectrum"], "sji": viewers["sji"][0]}
    for name, viewer in names.items():
        CANVAS_NAMES[id(viewer.figure.canvas)] = name
    return app, names


def busy(app):
    """Whether anything is still pending: canvas draws, the coordinator's timer, a profile worker."""
    import glue_solar.quicklook as ql
    from glue_qt.utils import get_qapp

    for tab in app.viewers:
        for viewer in tab:
            canvas = viewer.figure.canvas
            if getattr(canvas, "_draw_pending", False):
                return True
            for layer in viewer.layers:
                if getattr(layer, "is_computing", False):
                    return True
                worker = getattr(layer, "_worker", None)
                if worker is not None and not worker.work_queue.empty():
                    return True
    coord = getattr(app.data_collection, "_solar_coordinator", None)
    return coord is not None and coord._timer.isActive()


def settle(app, timeout=30.0):
    """Process events until nothing is pending for 0.1 s (the profile worker polls at 25 Hz)."""
    from glue_qt.utils import get_qapp

    qapp = get_qapp()
    t0 = time.perf_counter()
    quiet_since = None
    while time.perf_counter() - t0 < timeout:
        qapp.processEvents()
        if busy(app):
            quiet_since = None
        else:
            quiet_since = quiet_since or time.perf_counter()
            if time.perf_counter() - quiet_since > 0.1:
                return quiet_since - t0
        time.sleep(0.001)
    return time.perf_counter() - t0


def report(label, n=1, file=None, top=25):
    """Print the counters of one recorded action (divided by ``n`` repeats)."""
    out = []
    p = out.append

    def per(c):
        return c / n

    p(f"=== {label} (per action, mean of {n})")
    p(f"draws by canvas      : {dict((k, per(v)) for k, v in R.draws.items())}  Agg time {sum(R.draw_t.values()) / n * 1e3:.1f} ms")
    p(f"draw_idle requests   : {dict((k, per(v)) for k, v in R.draw_idle.items())}")
    p(f"  ...newly scheduling: {dict((k, per(v)) for k, v in R.draw_idle_new.items())}")
    p(f"deferred draw_idle   : {dict((k, per(v)) for k, v in R.deferred.items())}")
    p(f"paints               : {dict((k, per(v)) for k, v in R.paints.items())}  time {sum(R.paint_t.values()) / n * 1e3:.1f} ms")
    p(f"echo notifications   : {per(sum(R.echo.values()))}  callbacks run {per(sum(R.echo_cbs.values()))}")
    p(f"echo global callbacks: {per(sum(R.glob.values()))}   _get_aliases_for calls {per(R.aliases_n)} {R.aliases_t / n * 1e3:.2f} ms")
    p(f"hub broadcasts       : {per(sum(R.msg.values()))}  handlers run {per(sum(R.handlers.values()))}  "
      f"filtering {R.find_t / n * 1e3:.2f} ms over {per(R.find_subs)} subscriber scans")
    p(f"glue_solar outer time: {R.solar_outer_t / n * 1e3:.1f} ms in {per(R.solar_outer_n)} entries")
    p(f"FRB (main thread)    : {dict((k, per(v)) for k, v in R.frb.items())} {sum(R.frb_t.values()) / n * 1e3:.1f} ms")
    p(f"statistics           : {dict((k, per(v)) for k, v in R.stat.items())} " +
      str({k: round(v / n * 1e3, 1) for k, v in R.stat_t.items()}) + " ms")
    p(f"timed (count, ms)    : {dict((k, (per(v), round(R.timed_t[k] / n * 1e3, 2))) for k, v in R.timed.items())}")
    p(f"draw requesters      : {dict((f'{k[0]} <- {k[1]}', per(v)) for k, v in R.requesters.most_common(12))}")
    p("-- echo notifications (owner.prop: count)")
    for k, v in R.echo.most_common(top):
        p(f"   {per(v):6.1f}  {k[0]}.{k[1]}")
    p("-- echo callbacks (count, inclusive ms)")
    for k, v in sorted(R.echo_cbs.items(), key=lambda kv: -R.echo_cb_t[kv[0]])[:top]:
        p(f"   {per(v):6.1f}  {R.echo_cb_t[k] / n * 1e3:8.2f}  {k[0]}.{k[1]} -> {k[2]}")
    p("-- echo global callbacks (count, inclusive ms, triggering props)")
    for k, v in sorted(R.glob.items(), key=lambda kv: -R.glob_t[kv[0]])[:top]:
        props = dict(R.glob_props[k].most_common(4))
        p(f"   {per(v):6.1f}  {R.glob_t[k] / n * 1e3:8.2f}  {k[0]} -> {k[1]}  {props}")
    p("-- hub messages (count, inclusive ms)")
    for k, v in sorted(R.msg.items(), key=lambda kv: -R.msg_t[kv[0]])[:top]:
        p(f"   {per(v):6.1f}  {R.msg_t[k] / n * 1e3:8.2f}  {k[0]} from {k[1]}")
    p("-- hub handlers (count, inclusive ms)")
    for k, v in sorted(R.handlers.items(), key=lambda kv: -R.handler_t[kv[0]])[:top]:
        p(f"   {per(v):6.1f}  {R.handler_t[k] / n * 1e3:8.2f}  {k[0]} -> {k[1]}")
    text = "\n".join(out)
    print(text, flush=True)
    if file:
        file.write(text + "\n")
