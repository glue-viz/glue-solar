"""
F. What if glue-solar's Coordinator applied the point before the event loop runs the draws?

The harness calls the coordinator's own _update() right after the click / slider step returns (the
draws glue scheduled are still pending) and stops its 0 ms timer, which is what a synchronous apply
in Coordinator._subset_changed / slices_changed would do. No code is changed. n=9 each, alternating
baseline and variant so drift hits both.
"""

import os
import statistics
import time

import harness as H

HERE = os.path.dirname(os.path.abspath(__file__))
H.install()
datasets, _ = H.load()
raster, sji = datasets
app, V = H.build(datasets)
coord = app.data_collection._solar_coordinator

from qtpy import QtCore, QtWidgets  # noqa: E402
from qtpy.QtTest import QTest  # noqa: E402

sp, mp = V["spectrogram"], V["map"]
qs = sp.options_widget().slice_helper._sliders[0].findChild(QtWidgets.QSlider, "value_slice_center")
k = {"n": 0}


def exposure_step():
    k["n"] += 1
    qs.triggerAction(QtWidgets.QAbstractSlider.SliderSingleStepAdd if k["n"] % 2 else QtWidgets.QAbstractSlider.SliderSingleStepSub)


ny, nx = raster.shape[1], raster.shape[0]
pts = [(nx // 2 + 40, ny // 2 + 20), (nx // 2 - 40, ny // 2 - 20)]


def click():
    k["n"] += 1
    xd, yd = pts[k["n"] % 2]
    canvas = mp.figure.canvas
    xs, ys = mp.axes.transData.transform((xd, yd))
    pos = QtCore.QPoint(int(xs), int(canvas.height() - ys))
    QTest.mousePress(canvas, QtCore.Qt.LeftButton, QtCore.Qt.NoModifier, pos)
    QTest.mouseRelease(canvas, QtCore.Qt.LeftButton, QtCore.Qt.NoModifier, pos)


def synced(act):
    def run():
        act()
        coord._update()
        coord._timer.stop()
    return run


def one(act):
    H.R.reset(); H.R.on = True
    t = time.perf_counter()
    act()
    wall = time.perf_counter() - t + H.settle(app)
    H.R.on = False
    return wall, dict(H.R.draws)


out = open(os.path.join(HERE, "bench_sync.log"), "w")
for label, act in (("exposure step", exposure_step), ("pixel click", click)):
    one(act); one(synced(act))
    base, var, bd, vd = [], [], None, None
    for _ in range(9):
        w, bd = one(act); base.append(w)
        w, vd = one(synced(act)); var.append(w)
    line = (f"{label:14s} as is: {statistics.median(base) * 1e3:6.1f} ms (draws {bd}) | point applied before draws: "
            f"{statistics.median(var) * 1e3:6.1f} ms (draws {vd}); n=9 each")
    print(line, flush=True)
    out.write(line + "\n")
out.close()
app.close()
