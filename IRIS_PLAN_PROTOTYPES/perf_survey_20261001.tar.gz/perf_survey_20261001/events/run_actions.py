"""
Time, count and profile user actions in the 4000255147 Si IV 1403 + SJI 1400 quicklook.

usage: python run_actions.py [N] [action ...]
Each action: 1 warm-up, N timed repeats (recording off), N recorded repeats (counters), 3 cProfiled repeats.
"""

import cProfile
import io
import json
import os
import pstats
import statistics
import sys
import time
from collections import defaultdict

import harness as H

HERE = os.path.dirname(os.path.abspath(__file__))
N = int(sys.argv[1]) if len(sys.argv) > 1 else 7
WANTED = sys.argv[2:]

H.install()
datasets, t_load = H.load()
raster, sji = datasets
print(f"loaded in {t_load:.1f} s; raster {raster.shape} {raster.size:.3g}, sji {sji.shape}; maxrss {H.rss_mb():.0f} MB", flush=True)
app, V = H.build(datasets)
print(f"quicklook built; maxrss {H.rss_mb():.0f} MB", flush=True)

from glue.config import colormaps  # noqa: E402
from qtpy import QtCore, QtWidgets  # noqa: E402
from qtpy.QtTest import QTest  # noqa: E402

for name, v in V.items():
    s = v.state
    extra = f"x={s.x_att} y={s.y_att} slices={getattr(s, 'slices', None)}" if hasattr(s, "slices") else ""
    print(f"{name}: canvas {v.figure.canvas.width()}x{v.figure.canvas.height()} dpr {v.figure.canvas.device_pixel_ratio} "
          f"layers {[(type(l).__name__, l.layer.label[:20], l.state.visible) for l in v.layers]} {extra}", flush=True)


def slider(viewer, axis):
    helper = viewer.options_widget().slice_helper
    return helper._sliders[axis].findChild(QtWidgets.QSlider, "value_slice_center")


def step(viewer, axis):
    qs = slider(viewer, axis)
    sign = {"n": 0}

    def act():
        # alternate +1/-1 so the view stays put; each is one keyboard/arrow step
        sign["n"] += 1
        qs.triggerAction(QtWidgets.QAbstractSlider.SliderSingleStepAdd if sign["n"] % 2 else
                         QtWidgets.QAbstractSlider.SliderSingleStepSub)
    return act


def click(viewer, points):
    canvas = viewer.figure.canvas
    k = {"n": 0}

    def act():
        k["n"] += 1
        xd, yd = points[k["n"] % len(points)]
        xs, ys = viewer.axes.transData.transform((xd, yd))
        dpr = canvas.device_pixel_ratio
        pos = QtCore.QPoint(int(xs / dpr), int(canvas.height() - ys / dpr))
        QTest.mousePress(canvas, QtCore.Qt.LeftButton, QtCore.Qt.NoModifier, pos)
        QTest.mouseRelease(canvas, QtCore.Qt.LeftButton, QtCore.Qt.NoModifier, pos)
    return act


def swap(viewer):
    def act():
        viewer.state.x_att = viewer.state.y_att  # what picking y's axis in the x combo does; glue swaps y
    return act


def cmap(viewer, names):
    k = {"n": 0}
    cmaps = dict((n, c) for n, c in colormaps.members)

    def act():
        k["n"] += 1
        viewer.state.layers[0].cmap = cmaps[names[k["n"] % len(names)]]
    return act


# a copy of the SJI sharing its array, coords and meta: stands in for 'drag the deconvolved SJI onto
# the slit-jaw viewer' (the quicklook's own hint), since 4000255147 has a single SJI channel. Its pixel
# axes are linked to the SJI's so the layer is shown (with lon/lat links only glue disables it).
# Made only for the add-layer action, so the other actions see the quicklook's own collection.
from glue.core import Data  # noqa: E402
from glue.core.link_helpers import LinkSame  # noqa: E402

copy = None


def make_copy():
    global copy
    copy = Data(label="SJI 1400 copy", coords=sji.coords)
    copy.meta.update(sji.meta)
    copy.add_component(sji.get_component(sji.main_components[0]), "SJI copy")
    app.data_collection.append(copy)
    app.data_collection.add_link([LinkSame(a, b) for a, b in zip(sji.pixel_component_ids, copy.pixel_component_ids)])
    H.settle(app)


def add_layer(viewer):
    def act():
        viewer.add_data(copy)
    return act


def undo_add_layer(viewer):
    def act():
        viewer.remove_data(copy)
    return act


mp, sp, wl, sj = V["map"], V["spectrogram"], V["wavelength"], V["sji"]
ny, nx = raster.shape[1], raster.shape[0]
ACTIONS = {
    # map shows slit (y) vs exposure (x); its slider is wavelength, which never moves the point
    "map_wavelength_step": (step(mp, 2), None),
    # spectrogram shows wavelength vs slit; its exposure slider moves the point and the SJI follows
    "spectrogram_exposure_step": (step(sp, 0), None),
    # the SJI's frame slider; the SJI is not the time master
    "sji_frame_step": (step(sj, 0), None),
    "pixel_click_map": (click(mp, [(nx // 2 + 40, ny // 2 + 20), (nx // 2 - 40, ny // 2 - 20)]), None),
    "axis_swap_map": (swap(mp), None),
    "cmap_sji": (cmap(sj, ["Gray", "Viridis"]), None),
    "cmap_map": (cmap(mp, ["Gray", "Viridis"]), None),
    "add_layer_sji": (add_layer(sj), undo_add_layer(sj)),
}
results = {}
log = open(os.path.join(HERE, f"{'trace' if os.environ.get('TRACE') else 'actions'}_{'_'.join(WANTED) or 'all'}.log"), "w")
for name, (act, undo) in ACTIONS.items():
    if WANTED and name not in WANTED:
        continue
    if name == "add_layer_sji":
        make_copy()
    print(f"\n##### {name}", flush=True)

    def once():
        t0 = time.perf_counter()
        c0 = time.thread_time()
        act()
        t_act = time.perf_counter() - t0
        # time until nothing was pending any more (settle then waits 0.1 s of quiet)
        wall = t_act + H.settle(app)
        return t_act, wall, time.thread_time() - c0

    def undo_quiet():
        if undo:
            undo()
            H.settle(app)

    once(); undo_quiet()  # warm-up
    if os.environ.get("TRACE"):
        for k in range(2):
            H.R.reset(); H.R.on = True; H.R.trace = True
            H.R.t0 = time.perf_counter()
            t_act, wall, _ = once()
            H.R.on = H.R.trace = False
            lines = [f"--- trace {name} #{k}: wall to idle {wall * 1e3:.1f} ms"]
            lines += [f"  {t * 1e3:8.1f} ms  {th:6s}  {ev:14s} {d}" for t, th, ev, d in H.R.timeline]
            print("\n".join(lines), flush=True)
            log.write("\n".join(lines) + "\n")
            undo_quiet()
        continue
    walls, cpus, syncs = [], [], []
    for _ in range(N):
        t_act, wall, cpu = once()
        syncs.append(t_act); walls.append(wall); cpus.append(cpu)
        undo_quiet()
    H.R.reset(); H.R.on = True
    for _ in range(N):
        once()
        H.R.on = False; undo_quiet(); H.R.on = True
    H.R.on = False
    timing = (f"wall to idle median {statistics.median(walls) * 1e3:.1f} ms (min {min(walls) * 1e3:.1f}, max {max(walls) * 1e3:.1f}); "
              f"synchronous part median {statistics.median(syncs) * 1e3:.1f} ms; n={N}")
    print(timing, flush=True)
    log.write(f"\n##### {name}\n{timing}\n")
    H.report(name, N, log)
    prof = cProfile.Profile()
    for _ in range(3):
        prof.enable(); once(); prof.disable(); undo_quiet()
    s = io.StringIO()
    st = pstats.Stats(prof, stream=s)
    st.sort_stats("cumulative").print_stats(45)
    st.sort_stats("tottime").print_stats(30)
    # tottime by package
    buckets = defaultdict(float)
    for (fn, line, func), (cc, nc, tt, ct, callers) in st.stats.items():
        if "site-packages/" in fn:
            pkg = fn.split("site-packages/")[1].split("/")[0]
            pkg = {"glue": "glue/" + fn.split("site-packages/glue/")[1].split("/")[0]}.get(pkg, pkg) if pkg == "glue" else pkg
        elif "glue-solar-main" in fn:
            pkg = "glue_solar"
        elif fn.startswith("~") or fn.startswith("<"):
            pkg = "builtin:" + func[:40] if tt > 0.01 else "builtin(other)"
        else:
            pkg = "stdlib/" + os.path.basename(fn)
        if "time.sleep" not in pkg and "processEvents" not in pkg:  # the settle loop's polling
            buckets[pkg] += tt
    total = sum(buckets.values())
    s.write(f"\n-- tottime by package over 3 repeats, settle-loop sleeps excluded (total {total:.3f} s)\n")
    for k, v in sorted(buckets.items(), key=lambda kv: -kv[1])[:25]:
        s.write(f"   {v / 3 * 1e3:8.2f} ms/action  {100 * v / total:5.1f}%  {k}\n")
    with open(os.path.join(HERE, f"prof_{name}.txt"), "w") as f:
        f.write(s.getvalue())
    prof.dump_stats(os.path.join(HERE, f"prof_{name}.pstats"))
    results[name] = dict(wall=walls, sync=syncs, cpu=cpus)
    print(f"maxrss {H.rss_mb():.0f} MB", flush=True)

json.dump(results, open(os.path.join(HERE, f"timings_{'_'.join(WANTED) or 'all'}.json"), "w"), indent=1)
log.close()
app.close()
