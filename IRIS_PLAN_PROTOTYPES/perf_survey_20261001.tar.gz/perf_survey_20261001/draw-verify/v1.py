"""Findings 1-3 and 5: slider steps, contrast events, per-draw WCS evaluations, who requests the SJI draws.

usage: python v1.py A|B
"""

import hashlib
import sys
import time
import traceback

import numpy as np

import h

case = sys.argv[1]
app, viewers, panels = h.open_case(case)

from astropy.visualization.wcsaxes.frame import BaseFrame  # noqa: E402

h.wrap(BaseFrame, "_update_patch_path", "patch_path")

if case == "A":
    actions = [("sji: frame step", "sji", h.stepper(panels["sji"], 0)),
               ("spectrogram: exposure step", "spectrogram", h.stepper(panels["spectrogram"], 0)),
               ("λ-time: slit step", "wavelength", h.stepper(panels["wavelength"], 1)),
               ("map: wavelength step", "map", h.stepper(panels["map"], 2))]
else:
    actions = [("sji: frame step", "sji", h.stepper(panels["sji"], 0)),
               ("spectrogram: raster step", "spectrogram", h.stepper(panels["spectrogram"], 1)),
               ("λ-scan: slit step", "wavelength", h.stepper(panels["wavelength"], 2))]
actions += [("map: contrast event", "map", h.contrast(panels["map"])),
            ("sji: contrast event", "sji", h.contrast(panels["sji"]))]

print("\n### actions (n=15 after 2 warm-ups, medians)")
for name, role, act in actions:
    rows = h.run(name, act)
    sw = h.mrow(rows, "_set_wcs")
    print(f"   _set_wcs {sw}  reset_wcs {h.mrow(rows, 'reset_wcs')}  set_xlabel(in _set_wcs) {h.mrow(rows, 'set_xlabel', '_set_wcs')}"
          f"  set_ylabel(in _set_wcs) {h.mrow(rows, 'set_ylabel', '_set_wcs')}  set_xlabel(all) {h.mrow(rows, 'set_xlabel')}"
          f"  set_ylabel(all) {h.mrow(rows, 'set_ylabel')}")
    print(f"   tick_update in set_xlabel {h.mrow(rows, 'tick_update', 'set_xlabel')} in set_ylabel {h.mrow(rows, 'tick_update', 'set_ylabel')}"
          f" in draw {h.mrow(rows, 'tick_update', 'draw')}  | p2w all {h.mrow(rows, 'p2w')} in set_xlabel {h.mrow(rows, 'p2w', 'set_xlabel')}"
          f" in set_ylabel {h.mrow(rows, 'p2w', 'set_ylabel')} in _set_wcs-direct {h.mrow(rows, 'p2w', '_set_wcs')} in draw {h.mrow(rows, 'p2w', 'draw')}")
    print(f"   draw_wcsaxes(in draw) {h.mrow(rows, 'draw_wcsaxes', 'draw')} patch_path(in draw) {h.mrow(rows, 'patch_path', 'draw')}", flush=True)

# --- who requests each draw during a raster step ----------------------------------------------------
from glue.utils.misc import DeferredMethod  # noqa: E402
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg  # noqa: E402
from glue_qt.viewers.matplotlib.widget import MplCanvas  # noqa: E402

EV = []


def where():
    fr = [f for f in traceback.extract_stack()[:-2] if ("glue" in f.filename or "echo" in f.filename) and "draw-verify" not in f.filename]
    return " < ".join(f"{f.filename.split('site-packages/')[-1].split('glue-solar-main/')[-1]}:{f.lineno}" for f in reversed(fr[-7:]))


_di = FigureCanvasQTAgg.draw_idle


def draw_idle(self, *a, **k):
    EV.append(("req", h.CANVAS.get(self, "?"), where()))
    return _di(self, *a, **k)


FigureCanvasQTAgg.draw_idle = draw_idle
_dc = DeferredMethod.__call__


def dcall(self, instance, *a, **k):
    EV.append(("defer", h.CANVAS.get(instance, "?"), where()))
    return _dc(self, instance, *a, **k)


DeferredMethod.__call__ = dcall
_mdraw = MplCanvas.draw


def mdraw(self, *a, **k):
    EV.append(("DRAW", h.CANVAS.get(self, "?"), ""))
    return _mdraw(self, *a, **k)


MplCanvas.draw = mdraw
step = actions[1][2]
for rep in range(3):
    EV.clear()
    step()
    h.settle()
print(f"\n### draw requests on the sji canvas during one {actions[1][0]} (rep 3), in order")
for kind, lab, st in EV:
    if lab == "sji":
        print(f"  {kind:6s} {st}")
print("  all draws in order:", [lab for kind, lab, _ in EV if kind == "DRAW"])
FigureCanvasQTAgg.draw_idle = _di
DeferredMethod.__call__ = _dc
MplCanvas.draw = _mdraw

# --- per-draw WCS evaluations ---------------------------------------------------------------------------
from glue_solar.sources.loaders.iris import _GlueWCS  # noqa: E402

CALLS = []
_p2w = _GlueWCS.pixel_to_world_values  # already the h wrapper


def p2w(self, *arrays):
    t = time.perf_counter()
    out = _p2w(self, *arrays)
    dt = time.perf_counter() - t
    key = hashlib.md5(b"".join(np.ascontiguousarray(np.asarray(a, dtype=float)).tobytes() for a in arrays)
                      + repr([np.shape(a) for a in arrays]).encode() + str(id(self)).encode()).hexdigest()
    CALLS.append((key, dt, int(np.size(arrays[0]))))
    return out


_GlueWCS.pixel_to_world_values = p2w
print("\n### forced redraws, 30 per panel after 3 warm-ups (medians); repeated = identical inputs within the same draw")
for role, v in panels.items():
    cv = v.figure.canvas
    rows = []
    for i in range(33):
        CALLS.clear()
        h.reset()
        t = time.perf_counter()
        cv.draw()
        dt = time.perf_counter() - t
        if i < 3:
            continue
        seen, rep_t = set(), 0.0
        for key, d, _ in CALLS:
            if key in seen:
                rep_t += d
            seen.add(key)
        rows.append((dt, len(CALLS), len(seen), sum(d for _, d, _ in CALLS), rep_t,
                     h.tot("draw_wcsaxes")[0] + h.tot("patch_path")[0], h.med([d for _, d, _ in CALLS]) if CALLS else 0,
                     h.med([n for *_, n in CALLS]) if CALLS else 0))
    m = [h.med([r[j] for r in rows]) for j in range(8)]
    print(f"  {role:12s} draw {m[0]*1e3:5.1f} ms  WCSAxes(draw_wcsaxes+patch) {m[5]*1e3:5.1f} ms ({100*m[5]/m[0]:.0f}%)  p2w calls {m[1]:.0f}"
          f" distinct {m[2]:.0f}  p2w time {m[3]*1e3:5.1f} ms ({100*m[3]/m[0]:.0f}%)  repeated-input time {m[4]*1e3:5.1f} ms"
          f"  per call {m[6]*1e3:.3f} ms  points/call {m[7]:.0f}", flush=True)
_GlueWCS.pixel_to_world_values = _p2w

# per-call cost vs point count for each panel's WCS, outside any draw
print("\n### p2w cost per call vs points (n=200 each, median)")
for role, v in panels.items():
    w = v.state.reference_data.coords
    if not isinstance(w, _GlueWCS):
        print("  ", role, type(w))
        continue
    for npts in (1, 50, 1000):
        args = [np.full(npts, s / 2.0) for s in v.state.reference_data.shape[::-1]]
        ts = []
        for _ in range(200):
            t = time.perf_counter()
            _p2w.__wrapped__(w, *args)
            ts.append(time.perf_counter() - t)
        inner = w._wcs
        ts2 = []
        for _ in range(200):
            t = time.perf_counter()
            inner.pixel_to_world_values(*args)
            ts2.append(time.perf_counter() - t)
        print(f"  {role:12s} {type(inner).__name__:12s} npts {npts:5d}: _GlueWCS {h.med(ts)*1e3:.3f} ms, inner {h.med(ts2)*1e3:.3f} ms")
print(f"maxrss {h.rss():.2f} GB")
