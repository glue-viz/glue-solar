"""Compare per-step fingerprints of two v1what runs. usage: python cmp.py a.json b.json"""
import json, sys
a, b = (json.load(open(p)) for p in sys.argv[1:3])
for name in a:
    fa, fb = a[name]["fp"], b[name]["fp"]
    same = sum(x == y for x, y in zip(fa, fb))
    changes = sum(fa[i] != fa[i - 1] for i in range(1, len(fa)))
    print(f"{name:30s} identical {same}/{len(fa)}; baseline fingerprint changes between consecutive steps: {changes}/{len(fa)-1}")
    for i, (x, y) in enumerate(zip(fa, fb)):
        if x != y:
            for role in x:
                if x[role] != y[role]:
                    print("   step", i, role, "\n     base", x[role], "\n     var ", y[role])
            break
