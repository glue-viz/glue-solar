"""Finding 3: per-step SJI draws during raster steps, and a what-if that skips redraw requests from hidden subset layers.

usage: python v3.py A|B base|nohidden [n]
"""

import sys
from collections import Counter

import h

case, variant = sys.argv[1], sys.argv[2]
n = int(sys.argv[3]) if len(sys.argv) > 3 else 40
if variant == "nohidden":
    # my own variant: the layer artist's redraw does nothing while the subset layer is hidden
    from glue.viewers.image.layer_artist import ImageSubsetLayerArtist

    def redraw(self):
        if self.state.visible:
            self.axes.figure.canvas.draw_idle()

    ImageSubsetLayerArtist.redraw = redraw

app, viewers, panels = h.open_case(case)
sji = panels["sji"]
step = h.stepper(panels["spectrogram"], 0 if case == "A" else 1)
if case == "B":
    h.run(f"{variant}: λ-scan slit step", h.stepper(panels["wavelength"], 2), n=15)
rows = h.run(f"{variant}: raster step", step, n=n, extra=lambda: {"sji_slice": sji.state.slices[0]})
groups = Counter()
for i, r in enumerate(rows):
    key = (r["draws"].get("sji", (0, 0))[0], h.mrow([r], "_set_wcs")[1])
    groups[key] += 1
print("(sji draws, _set_wcs calls) -> steps:", dict(groups))
for key in sorted(groups):
    sel = [r for r in rows if (r["draws"].get("sji", (0, 0))[0], h.mrow([r], "_set_wcs")[1]) == key]
    print(f"  {key}: total {h.med([r['total'] for r in sel])*1e3:.1f} ms, sji draw ms {h.med([r['draws'].get('sji', (0, 0))[1] for r in sel])*1e3:.1f}")
print("sji frame per step:", [r["sji_slice"] for r in rows])
print(f"all steps: mean total {sum(r['total'] for r in rows) / len(rows) * 1e3:.1f} ms, median {h.med([r['total'] for r in rows])*1e3:.1f} ms")
