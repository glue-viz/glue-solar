"""Findings 4 and 6: maximized raster/SJI panels, the Point's RGBA image and mask, the float64 composite.

usage: python v4.py A [n]   (QT_SCALE_FACTOR=2 for DPR2)
Variants are toggled A/B/A/B in one process on the same state: Point image hidden or shown (spectrogram),
composite returned as float32 or float64 (sji, spectrogram).
"""

import cProfile
import io
import pstats
import resource
import sys
import time
import tracemalloc

import numpy as np

import h

case = sys.argv[1]
N = int(sys.argv[2]) if len(sys.argv) > 2 else 20

import matplotlib.image as mimage  # noqa: E402
from glue.core.fixed_resolution_buffer import ARRAY_CACHE  # noqa: E402
from glue.core.subset import SliceSubsetState  # noqa: E402
from glue.viewers.image.composite_array import CompositeArray  # noqa: E402
from glue.viewers.image.layer_artist import ImageLayerArtist, ImageSubsetArray, ImageSubsetLayerArtist  # noqa: E402

h.wrap(SliceSubsetState, "to_mask", "to_mask")
h.wrap(ImageSubsetArray, "__call__", "subset_array")
F32 = [False]
_comp = CompositeArray.__call__


def comp(self, *a, **k):
    t = time.perf_counter()
    img = _comp(self, *a, **k)
    h.T[("-", "composite")] += time.perf_counter() - t
    return img.astype(np.float32) if (F32[0] and img is not None) else img


CompositeArray.__call__ = comp
SUBSET_ARTISTS = set()
_mk = mimage._ImageBase._make_image


def make(self, *a, **k):
    t = time.perf_counter()
    try:
        return _mk(self, *a, **k)
    finally:
        h.T[("-", "mpl_resample_subset" if self in SUBSET_ARTISTS else "mpl_resample_main")] += time.perf_counter() - t


mimage._ImageBase._make_image = make

app, viewers, panels = h.open_case(case)
for v in panels.values():
    for la in v.layers:
        if isinstance(la, ImageSubsetLayerArtist):
            SUBSET_ARTISTS.add(la.image_artist)


def ms(key):
    return h.tot(key)[0] * 1e3


def bench(role, label, setup, teardown, new_data):
    """Per draw: forced canvas.draw + repaint; returns medians of total and parts."""
    v = panels[role]
    cv = v.figure.canvas
    layers = [la for la in v.layers if isinstance(la, (ImageLayerArtist, ImageSubsetLayerArtist))]
    rows = []
    for i in range(N + 3):
        setup()
        if new_data:
            for la in layers:
                ARRAY_CACHE.pop(la.state.uuid, None)
        h.reset()
        t = time.perf_counter()
        cv.draw()
        t1 = time.perf_counter()
        cv.repaint()
        t2 = time.perf_counter()
        teardown()
        if i >= 3:
            rows.append(dict(draw=(t1 - t) * 1e3, paint=(t2 - t1) * 1e3, wcs=ms("draw_wcsaxes"), comp=ms("composite"),
                             sub=ms("subset_array"), mask=ms("to_mask"), rs_main=ms("mpl_resample_main"),
                             rs_sub=ms("mpl_resample_subset")))
    m = {k: round(h.med([r[k] for r in rows]), 2) for k in rows[0]}
    print(f"  {role:11s} {label:34s} {'new data' if new_data else 'colour only':11s} {m}", flush=True)
    return m


print(f"\n### quicklook-size raster panels: Point image shown vs hidden, n={N} per variant (alternating)")
for role in ("map", "spectrogram", "wavelength"):
    subs = [la for la in panels[role].layers if isinstance(la, ImageSubsetLayerArtist) and la.image_artist.get_visible()]

    def hide(subs=subs):
        for la in subs:
            la.image_artist.set_visible(False)

    def show(subs=subs):
        for la in subs:
            la.image_artist.set_visible(True)

    for new_data in (True, False):
        for rep in range(2):
            bench(role, "Point image shown", show, lambda: None, new_data)
            bench(role, "Point image hidden (crosshair kept)", hide, show, new_data)

print(f"\n### maximized panels, n={N} per variant (alternating), medians in ms; draw = canvas.draw, paint = repaint")
for role in ("spectrogram", "sji"):
    v = panels[role]
    v.parent().showMaximized()
    h.settle()
    h.wait(1.0)
    h.settle()
    cv = v.figure.canvas
    print(f" {role}: canvas {cv.width()}x{cv.height()} dpr {cv.device_pixel_ratio}")
    subs = [la for la in v.layers if isinstance(la, ImageSubsetLayerArtist) and la.image_artist.get_visible()]
    for new_data in (True, False):
        if subs:
            def hide():
                for la in subs:
                    la.image_artist.set_visible(False)

            def show():
                for la in subs:
                    la.image_artist.set_visible(True)

            res = {}
            for rep in range(2):  # A/B/A/B
                res.setdefault("shown", []).append(bench(role, "Point image shown", show, lambda: None, new_data))
                res.setdefault("hidden", []).append(bench(role, "Point image hidden (crosshair kept)", hide, show, new_data))
        for rep in range(2):
            bench(role, "composite float64", lambda: None, lambda: None, new_data)
            bench(role, "composite float32", lambda: F32.__setitem__(0, True), lambda: F32.__setitem__(0, False), new_data)
    # pixel comparison float32 vs float64
    imgs = []
    for flag in (False, True):
        F32[0] = flag
        cv.draw()
        imgs.append(np.asarray(cv.buffer_rgba()).astype(int))
    F32[0] = False
    d = np.abs(imgs[0] - imgs[1])
    print(f"  {role}: float32 vs float64 canvas pixels: max diff {d.max()}, share of pixels differing {np.mean(d.max(axis=2) > 0)*100:.1f}%")
    if role == "sji":
        comp_obj = v.axes._composite
        bounds = []
        orig = CompositeArray.__call__

        def capture(self, bounds_=None, **k):
            bounds.append(bounds_)
            return orig(self, bounds_, **k)

        CompositeArray.__call__ = capture
        cv.draw()
        CompositeArray.__call__ = orig
        b = bounds[0]
        print("  composite bounds", b)
        pr = cProfile.Profile()
        pr.enable()
        for _ in range(20):
            _comp(comp_obj, bounds=b)
        pr.disable()
        s = io.StringIO()
        pstats.Stats(pr, stream=s).sort_stats("tottime").print_stats(12)
        print("\n".join(s.getvalue().splitlines()[:40]))
    v.parent().showNormal()
    h.settle()
    h.wait(1.0)

# --- the Point's mask: SliceSubsetState.to_mask with index-array views ------------------------------------
print("\n### SliceSubsetState.to_mask on the Point (index-array view), and a mask built from the index arrays")
CAP = []
_tm = SliceSubsetState.to_mask


def cap(self, data, view=None):
    CAP.append((self, data, view))
    return _tm(self, data, view)


SliceSubsetState.to_mask = cap
for role in ("map", "spectrogram", "wavelength"):
    CAP.clear()
    for la in panels[role].layers:
        ARRAY_CACHE.pop(la.state.uuid, None)
    panels[role].figure.canvas.draw()
    if not CAP:
        print("  ", role, "no to_mask call")
        continue
    state, data, view = CAP[0]
    print(f"  {role}: data {data.shape}, view {[type(x).__name__ + str(np.shape(x)) for x in view]}, slices {state.slices}")

    def alt():
        shape = np.broadcast_shapes(*[np.shape(x) for x in view])
        out = np.ones(shape, bool)
        for ax, s in enumerate(state.slices):
            start, stop, step = s.indices(data.shape[ax])
            if (start, stop, step) == (0, data.shape[ax], 1):
                continue
            x = np.asarray(view[ax])
            m = (x >= start) & (x < stop)
            if step != 1:
                m &= (x - start) % step == 0
            out &= m
        return out

    for name, f in (("glue to_mask", lambda: _tm(state, data, view)), ("from index arrays", alt)):
        ts = []
        f0 = resource.getrusage(resource.RUSAGE_SELF).ru_minflt
        for _ in range(30):
            t = time.perf_counter()
            r = f()
            ts.append(time.perf_counter() - t)
        faults = (resource.getrusage(resource.RUSAGE_SELF).ru_minflt - f0) / 30
        tracemalloc.start()
        f()
        peak = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
        print(f"     {name:18s} median {h.med(ts)*1e3:.2f} ms, tracemalloc peak {peak/1e6:.1f} MB, minor faults/call {faults:.0f}")
    print("     equal:", np.array_equal(_tm(state, data, view), alt()))
SliceSubsetState.to_mask = _tm
print(f"maxrss {h.rss():.2f} GB")
