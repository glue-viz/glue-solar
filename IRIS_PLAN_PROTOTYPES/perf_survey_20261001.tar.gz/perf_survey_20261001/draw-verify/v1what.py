"""Finding 1 what-if, my own variant: on a slice change, reset_wcs and copy the axis labels onto the new coords
directly (no state round-trip, no WCSAxes.set_xlabel/set_ylabel), then request one draw.

usage: python v1what.py A|B base|relabel
Writes v1what_<case>_<variant>.json with per-step fingerprints for a base/variant comparison.
"""

import json
import sys

import h

case, variant = sys.argv[1], sys.argv[2]

if variant == "relabel":
    from glue_qt.viewers.image.data_viewer import ImageViewer

    def _on_slice_change(self, event=None):
        if not self._changing_slice_requires_wcs_update:
            return
        old = [(c.get_axislabel(), c._axislabels.get_size(), c._axislabels.get_weight(), c._axislabels._minpad)
               for c in self.axes.coords]
        self.axes.reset_wcs(slices=self.state.wcsaxes_slice, wcs=self.state.reference_data.coords)
        for c, (text, size, weight, minpad) in zip(self.axes.coords, old):
            c.set_axislabel(text, minpad=minpad, size=size, weight=weight)
        self._update_appearance_from_settings()
        self.update_x_ticklabel()
        self.update_y_ticklabel()
        self.axes.figure.canvas.draw_idle()

    ImageViewer._on_slice_change = _on_slice_change  # before the viewers register it as a callback

app, viewers, panels = h.open_case(case)


def fingerprint():
    out = {}
    for role, v in panels.items():
        out[role] = [(c.coord_index, c.get_axislabel(), sorted(c._axislabels.get_visible_axes()), float(c._axislabels.get_size()),
                      str(c._axislabels.get_weight()), {k: list(t) for k, t in c._ticklabels.text.items()},
                      {k: [[round(float(x), 2) for x in xy] for xy in d] for k, d in c._ticklabels.data.items()},
                      float(c._ticklabels.get_size()))
                     for c in v.axes.coords]
    return out


if case == "A":
    actions = [("sji: frame step", h.stepper(panels["sji"], 0)),
               ("spectrogram: exposure step", h.stepper(panels["spectrogram"], 0)),
               ("λ-time: slit step", h.stepper(panels["wavelength"], 1))]
else:
    actions = [("sji: frame step", h.stepper(panels["sji"], 0)),
               ("spectrogram: raster step", h.stepper(panels["spectrogram"], 1))]
result = {}
for name, act in actions:
    prints = []
    rows = h.run(f"{variant} {name}", act, n=15, extra=lambda: {"fp": fingerprint()})
    print(f"   _set_wcs {h.mrow(rows, '_set_wcs')} set_xlabel {h.mrow(rows, 'set_xlabel')} set_ylabel {h.mrow(rows, 'set_ylabel')} "
          f"reset_wcs {h.mrow(rows, 'reset_wcs')} p2w {h.mrow(rows, 'p2w')}", flush=True)
    result[name] = dict(total=h.med([r["total"] for r in rows]), set=h.med([r["set"] for r in rows]), fp=[r["fp"] for r in rows])
with open(f"draw-verify/v1what_{case}_{variant}.json", "w") as fh:
    json.dump(result, fh)
