"""Independent harness for re-measuring the draw findings (runtime wrappers only; nothing on disk is patched)."""

import glob
import os
import resource
import statistics
import sys
import time
from collections import defaultdict

sys.path.insert(0, os.environ.get("GS", "/Users/nabil/Git/glue-solar-main"))
assert os.environ.get("QT_QPA_PLATFORM") == "offscreen" and not os.environ["HOME"].startswith("/Users/")
import glue_solar  # noqa: E402

print("glue_solar:", glue_solar.__file__, "QT_SCALE_FACTOR", os.environ.get("QT_SCALE_FACTOR"), flush=True)
IRIS = "/Users/nabil/DATA/IRIS"
med = statistics.median
T = defaultdict(float)  # (ctx, key) -> seconds
N = defaultdict(int)  # (ctx, key) -> calls
CTX = []  # stack of context keys
CTX_KEYS = set()


def rss():
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1e9


def wrap(owner, name, key, ctx=False):
    orig = getattr(owner, name)
    if ctx:
        CTX_KEYS.add(key)

    def w(*a, **k):
        where = CTX[-1] if CTX else "-"
        if ctx:
            CTX.append(key)
        t = time.perf_counter()
        try:
            return orig(*a, **k)
        finally:
            dt = time.perf_counter() - t
            if ctx:
                CTX.pop()
            T[(where, key)] += dt
            N[(where, key)] += 1

    w.__wrapped__ = orig
    setattr(owner, name, w)
    return orig


def tot(key, ctx=None):
    """Inclusive seconds and calls of key, optionally only inside context ctx."""
    s = sum(v for (c, k), v in T.items() if k == key and (ctx is None or c == ctx))
    n = sum(v for (c, k), v in N.items() if k == key and (ctx is None or c == ctx))
    return s, n


def reset():
    T.clear()
    N.clear()


CANVAS = {}  # canvas -> label
DRAWS = defaultdict(list)


def instrument():
    from astropy.visualization.wcsaxes import WCSAxes
    from glue_qt.viewers.image.data_viewer import ImageViewer
    from glue_qt.viewers.matplotlib.widget import MplCanvas

    from glue_solar.sources.loaders.iris import _GlueWCS

    orig_draw = MplCanvas.draw

    def draw(self, *a, **k):
        CTX.append("draw")
        t = time.perf_counter()
        try:
            return orig_draw(self, *a, **k)
        finally:
            CTX.pop()
            DRAWS[CANVAS.get(self, "?")].append(time.perf_counter() - t)

    MplCanvas.draw = draw
    owner = ImageViewer if "_set_wcs" in ImageViewer.__dict__ else ImageViewer.__mro__[1]
    print("_set_wcs owner:", owner, flush=True)
    wrap(owner, "_set_wcs", "_set_wcs", ctx=True)
    wrap(WCSAxes, "reset_wcs", "reset_wcs")
    wrap(WCSAxes, "set_xlabel", "set_xlabel", ctx=True)
    wrap(WCSAxes, "set_ylabel", "set_ylabel", ctx=True)
    wrap(WCSAxes, "_update_tick_and_label_positions", "tick_update")
    wrap(WCSAxes, "draw_wcsaxes", "draw_wcsaxes")
    wrap(_GlueWCS, "pixel_to_world_values", "p2w")


def settle():
    from qtpy.QtWidgets import QApplication

    q = QApplication.instance()
    idle = 0
    for _ in range(300):
        q.processEvents()
        if any(getattr(c, "_draw_pending", False) for c in CANVAS):
            idle = 0
        else:
            idle += 1
            if idle >= 6:
                return


def wait(sec):
    from qtpy.QtWidgets import QApplication

    end = time.perf_counter() + sec
    while time.perf_counter() < end:
        QApplication.instance().processEvents()
        time.sleep(0.005)


def files(p):
    f = sorted(glob.glob(os.path.join(IRIS, p)))
    assert f, p
    return f


def open_case(case):
    from glue_qt.app.application import GlueApplication
    from glue_qt.utils import get_qapp

    from glue_solar.quicklook import quicklook
    from glue_solar.sources.loaders.iris import image_data, raster_data

    instrument()
    get_qapp()
    glue_solar.setup()
    app = GlueApplication()
    app.resize(1600, 1000)
    app.show()
    if case == "A":
        ds = raster_data(files("*4000255147_raster/*_r00000.fits"), windows=["Si IV 1403"])
        ds.append(image_data(files("*4000255147_SJI_1400_t000.fits.gz")[0]))
    else:
        ds = raster_data(files("*4000005156_raster/*.fits"), windows=["Si IV 1403"], stack=True)
        ds.append(image_data(files("*4000005156_SJI_2796_t000_deconvolved.fits.gz")[0]))
    print("loaded", [(d.label, d.shape) for d in ds], f"maxrss {rss():.2f} GB", flush=True)
    viewers = quicklook(app, ds, window="Si IV 1403")
    panels = {r: viewers[r] for r in ("map", "spectrogram", "wavelength")}
    panels["sji"] = viewers["sji"][0]
    for r, v in panels.items():
        CANVAS[v.figure.canvas] = r
    CANVAS[viewers["spectrum"].figure.canvas] = "spectrum"
    settle()
    wait(1.0)
    settle()
    for r, v in panels.items():
        cv = v.figure.canvas
        print(f"{r:12s} {cv.width()}x{cv.height()} dpr {cv.device_pixel_ratio} slices {v.state.slices} "
              f"wcs_update {v._changing_slice_requires_wcs_update}", flush=True)
    return app, viewers, panels


def stepper(viewer, axis):
    o = viewer.state.slices[axis]
    n = [0]

    def f():
        n[0] += 1
        s = list(viewer.state.slices)
        s[axis] = o + n[0]
        viewer.state.slices = tuple(s)

    return f


def contrast(viewer):
    from echo import delay_callback

    layer = viewer.state.layers[0]
    n = [0]

    def f():
        n[0] += 1
        with delay_callback(layer, "bias", "contrast"):
            layer.bias = 0.4 + 0.01 * (n[0] % 10)
            layer.contrast = 1.0 + 0.02 * (n[0] % 10)

    return f


def run(name, action, n=15, warm=2, extra=None):
    """Time action (synchronous part) + settle; returns per-rep rows."""
    for _ in range(warm):
        action()
        settle()
    rows = []
    for _ in range(n):
        reset()
        DRAWS.clear()
        t0 = time.perf_counter()
        action()
        t1 = time.perf_counter()
        settle()
        t2 = time.perf_counter()
        row = dict(set=t1 - t0, total=t2 - t0, draws={k: (len(v), sum(v)) for k, v in DRAWS.items()},
                   T=dict(T), N=dict(N))
        if extra:
            row.update(extra())
        rows.append(row)
    s = med([r["set"] for r in rows]) * 1e3
    t = med([r["total"] for r in rows]) * 1e3
    labels = sorted({k for r in rows for k in r["draws"]})
    d = {k: (med([r["draws"].get(k, (0, 0))[0] for r in rows]), round(1e3 * med([r["draws"].get(k, (0, 0))[1] for r in rows]), 1))
         for k in labels}
    print(f"== {name:32s} n={n} set {s:6.1f} ms total {t:6.1f} ms draws(count, ms) {d}", flush=True)
    return rows


def mrow(rows, key, ctx=None):
    """Median over rows of (ms, calls) for key in ctx."""
    vals = []
    for r in rows:
        s = sum(v for (c, k), v in r["T"].items() if k == key and (ctx is None or c == ctx))
        n = sum(v for (c, k), v in r["N"].items() if k == key and (ctx is None or c == ctx))
        vals.append((s, n))
    return round(1e3 * med([v[0] for v in vals]), 2), med([v[1] for v in vals])
