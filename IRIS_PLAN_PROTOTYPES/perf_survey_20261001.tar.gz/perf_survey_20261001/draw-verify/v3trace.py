"""Who requests each SJI draw in 4 consecutive raster steps (base). usage: python v3trace.py A|B"""

import sys
import traceback

import h

case = sys.argv[1]
app, viewers, panels = h.open_case(case)
from glue.utils.misc import DeferredMethod  # noqa: E402
from glue_qt.viewers.matplotlib.widget import MplCanvas  # noqa: E402
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg  # noqa: E402

EV = []


def where():
    fr = [f for f in traceback.extract_stack()[:-2] if ("glue" in f.filename) and "draw-verify" not in f.filename
          and "utils/matplotlib.py" not in f.filename and "utils/misc.py" not in f.filename]
    return " < ".join(f"{f.filename.split('site-packages/')[-1].split('glue-solar-main/')[-1]}:{f.lineno}:{f.name}" for f in reversed(fr[-6:]))


_di, _dc, _md = FigureCanvasQTAgg.draw_idle, DeferredMethod.__call__, MplCanvas.draw


def draw_idle(self, *a, **k):
    EV.append(("req", h.CANVAS.get(self, "?"), where()))
    return _di(self, *a, **k)


def dcall(self, instance, *a, **k):
    EV.append(("defer", h.CANVAS.get(instance, "?"), where()))
    return _dc(self, instance, *a, **k)


def mdraw(self, *a, **k):
    EV.append(("DRAW", h.CANVAS.get(self, "?"), ""))
    return _md(self, *a, **k)


FigureCanvasQTAgg.draw_idle, DeferredMethod.__call__, MplCanvas.draw = draw_idle, dcall, mdraw
step = h.stepper(panels["spectrogram"], 0 if case == "A" else 1)
for rep in range(5):
    EV.clear()
    step()
    h.settle()
    print(f"\n## step {rep}: sji frame {panels['sji'].state.slices[0]}; draws {[lab for k, lab, _ in EV if k == 'DRAW']}")
    for kind, lab, st in EV:
        if lab == "sji":
            print(f"  {kind:6s} {st}")
