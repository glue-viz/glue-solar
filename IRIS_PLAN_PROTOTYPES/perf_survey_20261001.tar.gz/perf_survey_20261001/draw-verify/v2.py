"""Finding 2: which WCSAxes paths call pixel_to_world_values per draw, a memo what-if, and pan-drag events.

usage: python v2.py A|B base|memo
memo (my own variant): _GlueWCS.pixel_to_world_values returns a cached copy for identical inputs within one
WCSAxes.draw or one _update_tick_and_label_positions (cache cleared at both boundaries).
"""

import json
import sys
import time
import traceback
from collections import Counter

import numpy as np

import h

case, variant = sys.argv[1], sys.argv[2]
from astropy.visualization.wcsaxes import WCSAxes  # noqa: E402

from glue_solar.sources.loaders.iris import _GlueWCS  # noqa: E402

if variant == "memo":
    CACHE = {}
    _orig = _GlueWCS.pixel_to_world_values

    def p2w(self, *arrays):
        key = (id(self),) + tuple((np.shape(a), np.asarray(a, dtype=float).tobytes()) for a in arrays)
        if key not in CACHE:
            CACHE[key] = _orig(self, *arrays)
        return tuple(np.array(v, copy=True) for v in CACHE[key])

    _GlueWCS.pixel_to_world_values = p2w
    for name in ("draw", "_update_tick_and_label_positions"):
        m = getattr(WCSAxes, name)

        def cleared(self, *a, _m=m, **k):
            CACHE.clear()
            try:
                return _m(self, *a, **k)
            finally:
                CACHE.clear()

        setattr(WCSAxes, name, cleared)

app, viewers, panels = h.open_case(case)


def fingerprint():
    return {role: [(c.get_axislabel(), {k: list(t) for k, t in c._ticklabels.text.items()},
                    {k: [[round(float(x), 2) for x in xy] for xy in d] for k, d in c._ticklabels.data.items()})
                   for c in v.axes.coords] for role, v in panels.items()}


def pan(viewer, pressed):
    from echo import delay_callback

    st = viewer.state
    n = [0]

    def f():
        n[0] += 1
        for im in viewer.axes.images:
            if hasattr(im, "_pressed"):
                im._pressed = pressed  # as between mpl-scatter-density's button press and release
        dx = (st.x_max - st.x_min) * 0.02 * (1 if n[0] % 2 else -1)
        with delay_callback(st, "x_min", "x_max"):
            st.x_min += dx
            st.x_max += dx

    return f


raster_step = ("spectrogram: exposure step", h.stepper(panels["spectrogram"], 0)) if case == "A" else \
    ("spectrogram: raster step", h.stepper(panels["spectrogram"], 1))
actions = [("sji: frame step", h.stepper(panels["sji"], 0)), raster_step,
           ("sji: contrast event", h.contrast(panels["sji"])),
           ("spectrogram: pan event (pressed)", pan(panels["spectrogram"], True)),
           ("sji: pan event (pressed)", pan(panels["sji"], True))]
out = {}
for name, act in actions:
    rows = h.run(f"{variant} {name}", act, n=15, extra=lambda: {"fp": fingerprint()})
    print(f"   draw_wcsaxes {h.mrow(rows, 'draw_wcsaxes')} p2w {h.mrow(rows, 'p2w')}", flush=True)
    out[name] = [r["fp"] for r in rows]
for role in ("spectrogram", "sji"):
    for im in panels[role].axes.images:
        if hasattr(im, "_pressed"):
            im._pressed = False

print("\n### forced redraws, n=30 after 3 warm-ups")
for role, v in panels.items():
    ts = []
    for i in range(33):
        h.reset()
        t = time.perf_counter()
        v.figure.canvas.draw()
        if i >= 3:
            ts.append((time.perf_counter() - t, h.tot("p2w")))
    print(f"  {role:12s} draw {h.med([x[0] for x in ts])*1e3:5.1f} ms  p2w {h.med([x[1][0] for x in ts])*1e3:5.1f} ms in {h.med([x[1][1] for x in ts])} calls")

if variant == "base":
    print("\n### which astropy call sites evaluate the WCS in one sji draw")
    sites = Counter()
    _w = _GlueWCS.pixel_to_world_values

    def p2w_site(self, *a):
        st = [f"{f.name}:{f.lineno}" for f in traceback.extract_stack()[:-1] if "wcsaxes" in f.filename]
        sites[" < ".join(reversed(st[-4:]))] += 1
        return _w(self, *a)

    _GlueWCS.pixel_to_world_values = p2w_site
    panels["sji"].figure.canvas.draw()
    for k, n in sites.most_common():
        print(f"  {n:3d}  {k}")
    _GlueWCS.pixel_to_world_values = _w
with open(f"draw-verify/v2_{case}_{variant}.json", "w") as fh:
    json.dump(out, fh)
