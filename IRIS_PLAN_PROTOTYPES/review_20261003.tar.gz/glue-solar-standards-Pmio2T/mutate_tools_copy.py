from pathlib import Path
import sys

original = Path('/private/tmp/glue-solar-review-CgMVf5/main/glue_solar/tools.py').read_text()
path = Path('/private/tmp/glue-solar-standards-Pmio2T/tools-copy/glue_solar/tools.py')
case = sys.argv[1]
if case == 'mode':
    old, new = '    if mode is not None:\n        viewer.toolbar.active_tool = mode', '    if False:\n        viewer.toolbar.active_tool = mode'
elif case == 'limits':
    old, new = '            layer.stretch_global = not per_frame', '            layer.stretch_global = True'
elif case == 'aspect':
    old, new = '_arcsec_ratio(self.viewer) or 1.0', '1.0'
else:
    raise ValueError(case)
assert old in original
path.write_text(original.replace(old, new))
print(case)
