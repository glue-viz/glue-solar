import os
import tempfile
from pathlib import Path

import numpy as np
from astropy.io import fits
from glue.core import Data
from glue.viewers.image.pixel_selection_subset_state import PixelSubsetState
from glue_solar import glue_patches

data = Data(values=np.arange(4, dtype=np.float32).reshape(2, 2), mask=np.array([[0, 1], [0, 0]], dtype=np.uint8))
subset = data.new_subset(PixelSubsetState(data, [slice(0, 1), slice(None)]))
with tempfile.TemporaryDirectory() as directory:
    filename = Path(directory) / 'subset.fits'
    glue_patches.export_fits(filename, subset)
    with fits.open(filename) as hdus:
        print('exported component names:', [hdu.name for hdu in hdus])
        print('expected uint8 mask included:', 'MASK' in hdus)
        print('exported flux:', hdus['VALUES'].data.tolist())
        if 'MASK' in hdus:
            print('mask dtype and values:', hdus['MASK'].data.dtype, hdus['MASK'].data.tolist())

    def float_only_fix(filename, subset):
        array = np.asarray(subset.data['values']).copy()
        array[~subset.to_mask()] = np.nan
        fits.HDUList([fits.PrimaryHDU(), fits.ImageHDU(array)]).writeto(filename)

    print('probe enables workaround for float-only exporter:', glue_patches.needs_fits_export_dask_workaround(float_only_fix))
    try:
        float_only_fix(Path(directory) / 'probe.fits', subset)
    except Exception as error:
        print(type(error).__name__, str(error))
