from pathlib import Path

path = Path('/private/tmp/glue-solar-standards-Pmio2T/point-copy/glue_solar/quicklook.py')
old = '        self.destroyed.connect(partial(coordinator.remove_listener, self._schedule))'
source = path.read_text()
assert source.count(old) == 1
path.write_text(source.replace(old, '        # MUTATION: omit coordinator listener cleanup'))
