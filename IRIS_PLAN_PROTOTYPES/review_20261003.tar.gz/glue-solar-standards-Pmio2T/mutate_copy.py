from pathlib import Path

copy = Path('/private/tmp/glue-solar-standards-Pmio2T/export-copy')
path = copy / 'glue_solar/glue_patches.py'
old = '        values = np.asarray(data[cid])\n        blank = None'
new = '        values = np.asarray(data[cid])\n        if values.dtype.kind == "u":\n            continue  # MUTATION: silently omit unsigned mask components\n        blank = None'
source = path.read_text()
assert source.count(old) == 1
path.write_text(source.replace(old, new))
