import os
import tempfile
os.environ['GLUE_TESTING'] = 'True'
from qtpy import QtWidgets
from qtpy.QtCore import Qt
from qtpy.QtTest import QTest
from glue import config
config.CFG_DIR = tempfile.mkdtemp()
config.settings._save_to_disk = False
import glue_solar
from glue_qt.app import GlueApplication
from glue_solar.sources.loaders.iris import raster_data
from glue_solar.quicklook import quicklook, coordinator, observation_key
from glue_solar.tests.helpers import select_point, press

qapp = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
glue_solar.setup()
app = GlueApplication()
path = '/Users/nabil/DATA/IRIS/2dd2d12db374b3466aa27a65bec235d3-iris_l2_20130902_163935_4000255147_raster/iris_l2_20130902_163935_4000255147_raster_t000_r00000.fits'
c2, mg = raster_data([path], ['C II 1336', 'Mg II k 2796'])
viewers = quicklook(app, [c2, mg], window=['C II 1336', 'Mg II k 2796'])
coord = coordinator(app.data_collection)
panel = viewers['windows'][0]['wavelength']

def settle():
    QTest.qWait(200)

def exposure():
    return coord.point.slices[0].start

def menu(viewer, text):
    button = viewer.toolbar.widgetForAction(viewer.toolbar.actions['solar:coordinate'])
    return next(action for action in button.menu().actions() if action.text() == text)

menu(viewers['map'], 'Time master').trigger()
select_point(panel, 3, 50)
settle()
print('after click:', coord.point.reference_data.meta['TDESC1'], 'exposure', exposure(), flush=True)
print('master is Mg:', coord._master(observation_key(mg)) is mg, flush=True)
press(panel, Qt.Key_F)
settle()
print('F: expected exposure 51; actual', exposure(), flush=True)
target = mg[mg.id['Time'], (100, 0, 0)]
QtWidgets.QInputDialog.getText = staticmethod(lambda *args, **kwargs: (str(target), True))
menu(panel, 'Go to UTC…').trigger()
settle()
print('Go to UTC exposure 100: actual', exposure(), flush=True)
print('shown-window exposure slider:', viewers['spectrogram'].state.slices[0], flush=True)
coord.masters.clear()
expected = exposure() + 1
press(panel, Qt.Key_F)
settle()
print('control, automatic time master, F: expected', expected, '; actual', exposure(), flush=True)
panel.close(warn=False)
settle()
expected = exposure() + 1
press(viewers['map'], Qt.Key_F)
settle()
print('after closing extra wavelength panel, F: expected', expected, '; actual', exposure(), flush=True)
app.close()
