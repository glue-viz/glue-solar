import os
import tempfile
from pathlib import Path
import numpy as np
os.environ['GLUE_TESTING']='True'
from qtpy import QtWidgets
from qtpy.QtTest import QTest
from glue import config
config.CFG_DIR=tempfile.mkdtemp()
config.settings._save_to_disk=False
import glue_solar
from glue_qt.app import GlueApplication
from glue_solar.sources.loaders.iris import raster_data
from glue_solar.quicklook import quicklook, coordinator, _pick_windows, _same_file, _times
from glue_solar.tests.helpers import select_point

files=sorted(Path('/Users/nabil/DATA/IRIS').glob('*3602506433_raster/*fits'))
assert len(files)==99
[c2]=raster_data(files[:2],['C II 1336'],stack=True)
[si]=raster_data([files[0],files[-1]],['Si IV 1403'],stack=True)
[si_scan1]=raster_data([files[1]],['Si IV 1403'])
qapp=QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
glue_solar.setup()
app=GlueApplication()
viewers=quicklook(app,[c2,si],window=['C II 1336','Si IV 1403'])
map_viewer=viewers['map']
map_viewer.state.slices=(1,*map_viewer.state.slices[1:])
select_point(map_viewer,4,100)
QTest.qWait(200)
coord=coordinator(app.data_collection)
point=tuple(s.start for s in coord.point.slices)
spectrum=viewers['windows'][0]['spectrum']
[layer]=[layer for layer in spectrum.state.layers if layer.visible]
actual=layer.profile[1]
scan98=si[si.main_components[0],(1,4,100,slice(None))]
scan1=si_scan1[si_scan1.main_components[0],(4,100,slice(None))]
print('same_file:',_same_file(c2,si),'shown extra windows:',len(viewers['windows']),'point:',point)
print('primary/extra point UTC:',_times(c2,4)[1],_times(si,4)[1])
np.testing.assert_array_equal(actual,scan98)
print('extra spectrum matches raster98:',True,'matches raster1:',np.array_equal(actual,scan1,equal_nan=True),
      'max difference DN:',float(np.nanmax(np.abs(actual-scan1))))
[different]=raster_data([files[1],files[-1]],['Si IV 1403'],stack=True)
print('different first file control same_file:',_same_file(c2,different),
      'extra windows:',len(_pick_windows([c2,different],['C II 1336','Si IV 1403'])[1]))
app.close()
