#!/bin/sh
set -eu
cd /private/tmp/glue-solar-review-125-K0KCh8
python_env=${1:-iris-plan}
case "$python_env" in iris-plan|iris-plan-floor) ;; *) exit 2 ;; esac
source_root=${REVIEW_SOURCE_ROOT:-/private/tmp/glue-solar-review-125-K0KCh8/main}
env HOME="$(mktemp -d)" QT_QPA_PLATFORM=offscreen MPLBACKEND=agg \
    PYTHONPATH="$source_root:/Users/nabil/Git/glue-solar/IRIS_PLAN_PROTOTYPES" \
    "/Users/nabil/mamba/envs/$python_env/bin/python" -B "$2"
