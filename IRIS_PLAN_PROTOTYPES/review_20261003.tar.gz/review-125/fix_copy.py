from pathlib import Path
import shutil
root = Path('/private/tmp/glue-solar-review-125-K0KCh8')
copy = root / 'fixed-copy'
shutil.copytree(root / 'main', copy)
path = copy / 'glue_solar/quicklook.py'
text = path.read_text()
start = text.index('    def _move_in_time(')
end = text.index('\n    def _move_point(', start)
part = text[start:end]
part = part.replace('point.reference_data is data', '_same_file(point.reference_data, data)')
part = part.replace('PixelSubsetState(data, slices)', 'PixelSubsetState(point.reference_data, slices)')
path.write_text(text[:start] + part + text[end:])
print('Changed only scratch fixed-copy/glue_solar/quicklook.py: _move_in_time same-file point and reference preservation')
