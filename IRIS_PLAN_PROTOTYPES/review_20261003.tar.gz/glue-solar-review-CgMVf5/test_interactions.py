import numpy as np
import pytest
from glue_solar.tests.test_quicklook import bare_app, scans, quicklook, coordinator, follow, mouse, point_window, rows, select_point, slide, settle, sit_and_stare, menu_action, click
pytest_plugins = ['glue_solar.conftest']


def test_close_point_window_then_step(bare_app, qtbot, scans):
    viewers = quicklook(bare_app, [scans[0]])
    window = point_window(bare_app)
    settle(qtbot, window)
    with qtbot.waitSignal(window.destroyed):
        window.parentWidget().close()
    print('Point window closed')
    select_point(viewers['map'], 3, 40)
    qtbot.wait(50)
    print('Point changed after window close')


def test_close_viewer_with_pending_hover(bare_app, qtbot, scans):
    viewers = quicklook(bare_app, [scans[0]])
    viewer = viewers['map']
    sync = coordinator(bare_app.data_collection)
    before = sync.point.slices.copy()
    follow(viewer)
    mouse(viewer, 'motion_notify_event', 1, 20, button=None)
    timer = viewer.toolbar.tools['solar:follow_lock']._timer
    print('pending hover before close:', timer.isActive())
    viewer.close(warn=False)
    print('pending hover after close:', timer.isActive())
    qtbot.wait(100)
    print('point before/after close:', before, sync.point.slices)
    assert sync.point.slices == before


def test_clear_sji_click_undo_retains_frame(bare_app, qtbot, irispy_test_files):
    raster, sji = sit_and_stare(irispy_test_files)
    viewers = quicklook(bare_app, [raster, sji])
    s = viewers['sji'][0]
    select_point(viewers['map'], 78, 10)
    qtbot.wait(20)
    before = coordinator(bare_app.data_collection).point.slices.copy()
    bare_app._actions['undo'].trigger()
    qtbot.wait(20)
    print('raster undo point:', before, coordinator(bare_app.data_collection).point.slices)


def test_second_tab_clear_keeps_stack_master(bare_app, qtbot, scans):
    scan, stack = scans
    first = quicklook(bare_app, [scan])
    second = quicklook(bare_app, [stack])
    sync = coordinator(bare_app.data_collection)
    key = __import__('glue_solar.quicklook', fromlist=['observation_key']).observation_key(stack)
    qtbot.wait(20)
    print('master before clear:', sync._master(key).label)
    menu_action(second['map'], 'Clear point').trigger()
    qtbot.wait(20)
    print('master after clear:', sync._master(key).label)
    slide(second['map'], 0, 4)
    qtbot.wait(20)
    print('scan after trying to move to 4:', second['map'].state.slices[0])
    print('master time:', sync.master_time(key))
    print('current stack time:', stack[stack.id['Time'], (4, stack.shape[1]//2, 0, 0)])
    assert sync._master(key) is stack
    assert second['map'].state.slices[0] == 4


def test_clear_second_tab_stops_sji_following_scan(bare_app, qtbot, scans):
    from glue_solar.tests.test_quicklook import slit_jaw, readout
    scan, stack = scans
    quicklook(bare_app, [scan])
    times = stack[stack.id['Time']][:, :, 0, 0]
    sji = slit_jaw(np.sort(times, axis=None), stack)
    panels = quicklook(bare_app, [stack, sji])
    sjiv = panels['sji'][0]
    qtbot.wait(20)
    menu_action(panels['map'], 'Clear point').trigger()
    qtbot.wait(20)
    old_frame = sjiv.state.slices[0]
    slide(panels['map'], 0, 4)
    qtbot.wait(20)
    frame = sjiv.state.slices[0]
    print('stack scan:', panels['map'].state.slices[0])
    print('SJI frame before/after stack scan step:', old_frame, frame)
    print('stack readout:', readout(panels['map']))
    print('SJI readout:', readout(sjiv))
    print('expected SJI frame:', int(np.flatnonzero(np.sort(times, axis=None)==times[4,stack.shape[1]//2])[0]))
    assert frame != old_frame


def test_undo_sji_click_restores_handpicked_frame(bare_app, qtbot, irispy_test_files):
    from glue_solar.tests.test_quicklook import clicked, sliders
    raster, sji = sit_and_stare(irispy_test_files)
    panels = quicklook(bare_app, [raster, sji])
    sjiv = panels['sji'][0]
    select_point(panels['map'], 78, 10)
    qtbot.wait(20)
    slide(sjiv, 0, 20)
    qtbot.wait(20)
    before = sliders(bare_app, panels)
    (x,y), index = clicked(sjiv, raster, 78, 30)
    select_point(sjiv,x,y)
    qtbot.wait(20)
    print('before click:', before)
    print('after click:', sliders(bare_app, panels))
    bare_app._actions['undo'].trigger()
    qtbot.wait(20)
    after = sliders(bare_app,panels)
    print('after undo:', after)
    assert after == before
