import numpy as np
from astropy.wcs import WCS
from glue.core.data import Data
from glue.core.data_collection import DataCollection
from glue.core.roi import PolygonalROI
from glue.core.subset import RoiSubsetState
from glue_solar.sources.loaders.iris import _GlueWCS, link_hpc
from glue_solar.quicklook import _outline_region, _RasterRoiSubsetState
from matplotlib.path import Path
from matplotlib.transforms import Bbox

wcs = WCS(naxis=3)
wcs.wcs.ctype = ['WAVE', 'HPLT-TAN', 'HPLN-TAN']
wcs.wcs.cunit = ['Angstrom', 'arcsec', 'arcsec']
wcs.wcs.crval = [1400, 0, 0]
wcs.wcs.cdelt = [.1, 1, 1]
wcs.wcs.crpix = [1, 1, 1]
source = Data(label='source', values=np.zeros((20, 20, 3)), coords=_GlueWCS(wcs))
target = Data(label='target', values=np.zeros((20, 20, 3)), coords=_GlueWCS(wcs.deepcopy()))
source.meta = target.meta = {'INSTRUME': 'SPEC'}
collection = DataCollection([source, target])
collection.add_link(link_hpc(collection))
roi = PolygonalROI([2.3, 17.3, 2.3, 17.3], [2.3, 17.3, 17.3, 2.3])
vertices = np.column_stack(roi.to_polygon())
parts = Path(np.vstack([vertices, vertices[:1]]), closed=True).clip_to_bbox(Bbox([[-1e-6, -1e-6], [19+1e-6, 19+1e-6]])).to_polygons()
world = _outline_region(source, roi, 0, 1, (0, 0, 1))
region = _RasterRoiSubsetState(source.pixel_component_ids[0], source.pixel_component_ids[1], roi, world)
expected = source.get_mask(RoiSubsetState(source.pixel_component_ids[0], source.pixel_component_ids[1], roi))
actual = target.get_mask(region)
print('clipped polygons:', len(parts))
print('expected selected pixels:', expected.sum(), 'actual:', actual.sum())
print('left leg expected/actual:', expected[4, 10, 1], actual[4, 10, 1])
print('right leg expected/actual:', expected[16, 10, 1], actual[16, 10, 1])
print('mismatches:', np.count_nonzero(expected != actual))
print('mismatch locations:', np.argwhere(expected[..., 1] != actual[..., 1]).tolist())
