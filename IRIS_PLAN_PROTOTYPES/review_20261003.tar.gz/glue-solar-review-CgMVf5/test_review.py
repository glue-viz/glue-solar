import numpy as np
import pytest
from glue_solar.tests.test_quicklook import bare_app, scans, quicklook, coordinator, point_window, select_point, slide, settle, menu_action
pytest_plugins = ["glue_solar.conftest"]


def test_close_point_window_then_step(bare_app, qtbot, scans):
    viewers = quicklook(bare_app, [scans[0]])
    window = point_window(bare_app)
    settle(qtbot, window)
    with qtbot.waitSignal(window.destroyed):
        window.parentWidget().close()
    print('Point window closed')
    select_point(viewers['map'], 3, 40)
    qtbot.wait(50)
    print('Point changed after window close')

def test_clear_second_tab_stops_sji_following_scan(bare_app, qtbot, scans):
    from glue_solar.tests.test_quicklook import slit_jaw, readout
    scan, stack = scans
    quicklook(bare_app, [scan])
    times = stack[stack.id['Time']][:, :, 0, 0]
    sji = slit_jaw(np.sort(times, axis=None), stack)
    panels = quicklook(bare_app, [stack, sji])
    sjiv = panels['sji'][0]
    qtbot.wait(20)
    menu_action(panels['map'], 'Clear point').trigger()
    qtbot.wait(20)
    old_frame = sjiv.state.slices[0]
    slide(panels['map'], 0, 4)
    qtbot.wait(20)
    frame = sjiv.state.slices[0]
    print('stack scan:', panels['map'].state.slices[0])
    print('SJI frame before/after stack scan step:', old_frame, frame)
    print('stack readout:', readout(panels['map']))
    print('SJI readout:', readout(sjiv))
    print('expected SJI frame:', int(np.flatnonzero(np.sort(times, axis=None)==times[4,stack.shape[1]//2])[0]))
    assert frame != old_frame

import numpy as np
import pytest
from glue.core import Data
from glue_qt.app import GlueApplication
from glue_qt.viewers.image import ImageViewer
from qtpy.QtGui import QCloseEvent

import glue_solar

pytest_plugins = ['glue_solar.conftest']


@pytest.mark.parametrize('patched', [False, True])
def test_cancel_close_preserves_playback(qtbot, monkeypatch, patched):
    glue_solar.setup()
    if not patched:
        monkeypatch.setattr(ImageViewer, 'closeEvent', glue_solar.glue_patches._original_close_event)
    print('glue-solar close patch enabled:', patched)
    cube = Data(flux=np.zeros((3, 4, 5)))
    app = GlueApplication()
    qtbot.addWidget(app)
    app.data_collection.append(cube)
    viewer = app.new_data_viewer(ImageViewer, data=cube)
    slider = viewer.options_widget().slice_helper._sliders[0]
    slider.button_forw.click()
    print('playing before canceled close:', slider._play_timer.isActive())
    viewer._warn_close = True
    monkeypatch.setattr(viewer, '_confirm_close', lambda: False)
    event = QCloseEvent()
    close_result = viewer._mdi_wrapper.close()
    print('native MDI close returned:', close_result)
    print('viewer wrapper remains:', viewer._mdi_wrapper is not None)
    print('playing after canceled close:', slider._play_timer.isActive())
    assert close_result is False
    assert slider._play_timer.isActive()
