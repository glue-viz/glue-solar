import mmap
from pathlib import Path
import numpy as np
from astropy.io import fits
from glue_solar.sources.loaders.iris import raster_data, image_data
from glue_solar.sources.loaders.lazy import RawComponent, RawStack
from glue_solar.quicklook import _times, _cadence, sji_to_raster
from glue_solar.tests.helpers import raster_point_on_sji
from glue_solar.regrid import regrid_on_time

root = Path('/Users/nabil/DATA/IRIS')
def paths(obs):
    return sorted(root.glob(f'*{obs}_raster/*fits'))
def mapped(a):
    seen = set()
    while a is not None and id(a) not in seen:
        if isinstance(a, mmap.mmap):
            return True
        seen.add(id(a))
        a = getattr(a, 'base', None)
    return False

for obs, window, stack in [
    ('4000005156', 'Si IV 1403', False),
    ('4000255147', 'Si IV 1403', False),
    ('3824262996', 'Mg II k 2796', False),
    ('3400109360', 'Mg II k 2796', False),
    ('3602506433', 'Si IV 1403', True),
]:
    datasets = raster_data(paths(obs), [window], stack=stack)
    data = datasets[0]
    cid = data.main_components[0]
    source = data.get_component(cid)._source
    raw = source.raw.scans[0] if isinstance(source.raw, RawStack) else source.raw
    first, last = data[cid, (0,) * (data.ndim-2)], data[cid, (*([data.shape[0]-1] + [0]*(data.ndim-3)),)]
    print(obs, 'datasets', len(datasets), 'shape', data.shape, 'raw', raw.dtype, 'mapped', mapped(raw),
          'mask', data[data.derived_components[0], (0,) * (data.ndim-2)].dtype)
    assert raw.dtype == np.dtype('>i2') and mapped(raw)
    assert np.isfinite(first).any()
    if obs == '4000255147':
        raster = data
    if stack:
        times = _times(data, data.shape[1] // 2)
        assert np.all(np.diff(times) > np.timedelta64(0, 'ns'))

sji = image_data(next(root.glob('*4000255147_SJI_1400_t000.fits.gz')))
source = sji.get_component(sji.main_components[0])._source
assert source.raw.dtype == np.dtype('>i2')
count = sum(np.count_nonzero(source.raw[i] == -32764) for i in range(sji.shape[0]))
missing = sum(np.count_nonzero(np.isnan(sji[sji.main_components[0], (i,)])) for i in range(sji.shape[0]))
print('SJI 4000255147', sji.shape, 'raw -32764 codes', count, 'NaNs', missing)
times, frames = _times(raster, None), _times(sji, None)
print('SNS range', times[0], times[-1], 'cadence', _cadence(times), 'SJI range', frames[0], frames[-1])
for frame in [0, sji.shape[0]-1]:
    x,y = raster_point_on_sji(raster, sji, 0 if frame == 0 else raster.shape[0]-1, 100, frame)
    print('actual SJI', frame, 'click mapping', sji_to_raster(sji,frame,x,y,raster))
for label, when, exposure in [('before', times[0] - _cadence(times)//4, 0),
                              ('after', times[-1] + _cadence(times)//4, raster.shape[0]-1)]:
    altered = np.broadcast_to(np.full((sji.shape[0],1,1),when), sji.shape)
    sji.update_components({sji.id['Time']: altered})
    x,y = raster_point_on_sji(raster,sji,exposure,100,0)
    print('outside coverage', label, when, 'click mapping', sji_to_raster(sji,0,x,y,raster))
grid = regrid_on_time(raster)
try:
    again = regrid_on_time(grid)
    print('SNS repeated regrid', raster.shape, grid.shape, again.shape)
except Exception as e:
    print('SNS repeated regrid ERROR:', type(e).__name__, str(e))
