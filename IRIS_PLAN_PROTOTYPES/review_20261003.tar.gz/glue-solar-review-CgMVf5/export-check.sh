#!/bin/zsh
set -eu
review_root=/private/tmp/glue-solar-review-CgMVf5
review_mutant=/private/tmp/glue-solar-standards-Pmio2T/export-copy
review_prototypes=/Users/nabil/Git/glue-solar/IRIS_PLAN_PROTOTYPES
cd "$review_root"
env HOME="$(mktemp -d)" QT_QPA_PLATFORM=offscreen MPLBACKEND=agg PYTHONPATH="$review_prototypes" \
  /Users/nabil/mamba/envs/iris-plan/bin/python -B "$review_prototypes/run_checks.py" \
  "$review_mutant:$review_prototypes" "$review_mutant/glue_solar" "$@"
