#!/bin/zsh
set -eu
review_root=/private/tmp/glue-solar-review-CgMVf5
cd "$review_root"
env HOME="$(mktemp -d)" QT_QPA_PLATFORM=offscreen MPLBACKEND=agg PYTHONPATH="$review_root/snapshot" \
  /Users/nabil/mamba/envs/iris-plan/bin/python -B "$@"
