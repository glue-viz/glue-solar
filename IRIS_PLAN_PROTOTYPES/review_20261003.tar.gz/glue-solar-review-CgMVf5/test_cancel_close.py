import numpy as np
import pytest
from glue.core import Data
from glue_qt.app import GlueApplication
from glue_qt.viewers.image import ImageViewer
from qtpy.QtGui import QCloseEvent

import glue_solar

pytest_plugins = ['glue_solar.conftest']


@pytest.mark.parametrize('patched', [False, True])
def test_cancel_close_preserves_playback(qtbot, monkeypatch, patched):
    glue_solar.setup()
    if not patched:
        monkeypatch.setattr(ImageViewer, 'closeEvent', glue_solar.glue_patches._original_close_event)
    print('glue-solar close patch enabled:', patched)
    cube = Data(flux=np.zeros((3, 4, 5)))
    app = GlueApplication()
    qtbot.addWidget(app)
    app.data_collection.append(cube)
    viewer = app.new_data_viewer(ImageViewer, data=cube)
    slider = viewer.options_widget().slice_helper._sliders[0]
    slider.button_forw.click()
    print('playing before canceled close:', slider._play_timer.isActive())
    viewer._warn_close = True
    monkeypatch.setattr(viewer, '_confirm_close', lambda: False)
    event = QCloseEvent()
    close_result = viewer._mdi_wrapper.close()
    print('native MDI close returned:', close_result)
    print('viewer wrapper remains:', viewer._mdi_wrapper is not None)
    print('playing after canceled close:', slider._play_timer.isActive())
    assert close_result is False
    assert slider._play_timer.isActive()
