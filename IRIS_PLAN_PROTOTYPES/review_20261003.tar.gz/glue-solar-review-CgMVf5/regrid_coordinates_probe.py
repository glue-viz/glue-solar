from pathlib import Path
import numpy as np
from glue_solar.sources.loaders.iris import raster_data, image_data
from glue_solar.quicklook import _times, _lon_lat, nearest
from glue_solar.regrid import regrid_on_time

root=Path('/Users/nabil/DATA/IRIS')
raster=raster_data(sorted(root.glob('*4000255147_raster/*fits')),['Si IV 1403'])[0]
sji=image_data(next(root.glob('*4000255147_SJI_1400_t000.fits.gz')))
for source in [raster,sji]:
    result=regrid_on_time(source)
    times=_times(source,None)
    step=np.timedelta64(round(result.meta['time_step']*1e9),'ns')
    grid=times.min()+np.arange(result.shape[0])*step
    index,offset=nearest(grid,times)
    others=[np.full(len(index),n//2) for n in source.shape[1:]]
    before=np.array(_lon_lat(source,[index,*others]))
    after=np.array(_lon_lat(result,[np.arange(len(index)),*others]))
    distance=np.linalg.norm(after-before,axis=0)
    bad=int(np.argmax(distance))
    cid=result.main_components[0]
    sample=result[cid,(bad,*[n//2 for n in source.shape[1:]])]
    original=source[source.main_components[0],(int(index[bad]),*[n//2 for n in source.shape[1:]])]
    print(source.label,'max pointing error arcsec',distance[bad],'target/source index',bad,index[bad],
          'Time offset s',offset[bad]/np.timedelta64(1,'s'),'values',sample,original)
    print('source/result lonlat',before[:,bad].tolist(),after[:,bad].tolist())
