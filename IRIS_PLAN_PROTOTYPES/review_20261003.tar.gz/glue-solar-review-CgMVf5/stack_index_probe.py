from pathlib import Path
import numpy as np
from glue.core import Data
from glue_solar.sources.loaders.iris import raster_data

files=sorted(Path('/Users/nabil/DATA/IRIS').glob('*3602506433_raster/*fits'))
assert len(files)==99
[stack]=raster_data(files,['Si IV 1403'],stack=True)
cid=stack.main_components[0]
view=(np.array([0,98]),0,100,slice(None))
oracle=np.stack([stack[cid,(scan,0,100,slice(None))] for scan in [0,98]])
print('expected shape',oracle.shape,'first finite values',oracle[:,20].tolist())
via_dask=stack.get_component(cid).data[view].compute()
np.testing.assert_array_equal(via_dask,oracle)
print('dask same-component view:',via_dask.shape,'matches expected')
control=Data(values=np.broadcast_to(np.arange(99,dtype=np.float32)[:,None,None,None],stack.shape))
control_values=control[control.id['values'],view]
assert control_values.shape==oracle.shape
print('ordinary Data control:',control_values.shape,'scan labels',control_values[:,20].tolist())
try:
    actual=stack[cid,view]
    print('actual shape',actual.shape)
    np.testing.assert_array_equal(actual,oracle)
except Exception as exc:
    print('actual ERROR:',type(exc).__name__,str(exc))
