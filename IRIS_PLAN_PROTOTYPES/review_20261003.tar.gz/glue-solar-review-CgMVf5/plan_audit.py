from pathlib import Path
import json
plan = Path('/Users/nabil/Git/glue-solar/IRIS_GLUE_GAP_PLAN.md').read_text().splitlines()
assert '#current-state-2026-10-01' in plan[6] and plan[28] == '## Current state, 2026-10-02'
print('7: Current-state link targets 2026-10-01; heading is 2026-10-02')
pr = json.loads(Path('/private/tmp/glue-solar-review-CgMVf5/prs/124.json').read_text())
assert 'No PR is open' in plan[30] and pr['state'] == 'OPEN'
print('31: Resume says No PR is open; reviewed PR 124 snapshot is OPEN')
assert 'wp4-empty-collapse-draw' not in plan[120] and 'wp4-empty-collapse-draw' in plan[287]
print('121: Later WP4 checklist omits open wp4-empty-collapse-draw at 288')
assert 'both reproducers' in plan[157] and 'needs_reference_crosshair_workaround' in plan[481]
print('158: Owner promises two reproducers; row 482 also assigns the linked-reference crosshair')
for line in (282, 429):
 assert 'Depends: wp4-time-controls' in plan[line-1]
print('282,429: Depend on completed wp4-time-controls (merged PR 115)')
