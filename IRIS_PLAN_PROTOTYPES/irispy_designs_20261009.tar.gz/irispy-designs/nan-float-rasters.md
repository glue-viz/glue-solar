The proposal is mostly moot. glue-solar needs none of it. irispy users get one small gain: eager raster reads leave the fill codes in the data, while every other irispy reader replaces them with NaN. I recommend dropping the "float32 NaN-filled option" (a `read_files` argument or a float memmap mode) and keeping only Option A below, a few-line irispy consistency fix, if the user wants to file anything.

## What irispy main does now (3352413, measured)

Data: 4000255147 Si IV 1403 (1600×417×262 = 174.8 M samples) and its SJI 1400 (400×417×388). Warm page cache, Apple M4 Pro.

| Read | dtype | -200 / -199 fill | Saturation | Memory |
|---|---|---|---|---|
| Raster, eager | float32 (BSCALE 0.25, BZERO 7992) | Kept as **-200.0 (27,614,960) and -199.0 (72)** in the data, plus a bool mask (15.8% of samples) | 16182.0, unmasked, no +Inf | Opens in 0.30 s; peak 1003 MiB, keeps 834 MiB (667 data + 167 mask), about 5 B per sample |
| Raster, `memmap=True` | big-endian int16, raw codes | -32768 and -32764 in the data, lazy Dask bool mask | 32760, unmasked | Opens in 0.065 s, 2 MiB traced; one step (values + mask) 0.78 ms; full mask 0.2–0.8 s and 167 MiB |
| SJI, eager | float32 | **NaN** under the mask (13,928,370 samples, 21.5%, including 1905 raw -32764) | 16182.0 | Opens in 0.48 s; peak 495 MiB |
| SJI, `memmap=True` | int16, raw codes | Lazy Dask mask; unit `DN_IRIS_SJI_UNSCALED`; `meta["scaled"]` False | 32760 | The .gz is decompressed into memory |

- **SJIs really are NaN-filled float32** in eager reads. Integer AIA cutouts get -200 written in instead. The mosaic reader also uses NaN (`io/mosaic.py:80`). The eager raster reader is the only eager reader that keeps the codes.
- **Saturation** is the same in every mode. In the saturated flare 3860258481 r00172, C II has 1407 samples at the ceiling and Si IV 2327. None is masked, none is +Inf and none is above the ceiling, which matches D49. NaN-filling does not touch saturation, and it shouldn't.
- **irispy's own docs work around the codes:** `examples/how_to/03_work_with_rasters.py:100` says "The array still holds the fill values (-200) that the cube masks, so we hide them as well".
- **The hazard for plain-numpy users is real.** `data.mean()` gives -31.95 DN with the fill and -0.43 DN without it. The mean spectrum at slit row 200 bottoms out at -200.
- **glue-solar main ignores this choice.** With `LAZY=True` it reads `memmap=True`, keeps its own `RawComponent` over the raw int16 (scaled on read, colour limits from a raw-code histogram) and derives the mask from NaN. On its eager path, `_dataset` and `stack_spectrograms.py:55` fill NaN themselves with `np.isin`. D17 is already met in both paths. A NaN-filled irispy raster would save glue-solar nothing.

## Options

**A. Eager raster reads put NaN at the mask, as SJIs and mosaics do (recommended if anything is filed).**
- **API:** none.
- **Behaviour change:** `memmap=False` raster data are NaN where `cube.mask` is True. The mask stays. Uncertainty becomes NaN at fill, as for SJIs; it is readout noise today. `memmap=True` is unchanged.
- **Cost:** +0.03 s on a 0.30 s read of a 667 MiB window (in place), 0 extra bytes.
- **Results:** irispy's offline suite went from 526 passing to 522 passing with 4 failures. All 4 are tests that compare data to -200 or to raw FITS values. `calculate_mg_features` (k, h), `calculate_moments` and `calculate_red_blue_asymmetry` on Si IV steps 0–199 give **bit-identical** results.
- **What breaks:** user code that finds fill with `data == -200` or `np.isin(data, (-200, -199))` now finds nothing, and should use `cube.mask`. Unmasked `sum`/`mean` now returns NaN instead of a silently biased number.
- **Deprecation:** recommended none. irispy is pre-1.0 and #206 changed the SJI memmap values the same way. A `FutureWarning` would fire on every eager raster read and fail test suites that turn warnings into errors.

**B. An opt-in keyword, such as `read_files(..., fill_value=np.nan)`.**
- Nothing breaks, but it adds permanent API for something users can already do in one line: `cube.data[cube.mask] = np.nan`.
- It would apply only to rasters, since SJIs already fill unconditionally, or it would need per-reader defaults.
- glue-solar wouldn't use it. Not worth it.

**C. `memmap=True` returning lazily scaled, NaN-filled float32 Dask data** (the old "memmap returning scaled, masked data" item; already tracked as irispy #14).
- Prototype result: opens in 0.068 s, one step reads in 0.89 ms (against 0.78 ms for raw int16 plus mask).
- A whole-window read takes 0.98 s and peaks at 1341 MiB, against 0.30 s and 1003 MiB eager. Analysis helpers convert the whole array anyway, so they would get slower.
- As a new default it would break glue-solar, whose `RawComponent` needs the raw int16. As an opt-in, glue-solar would not use it.
- This is #14's design question, not this item's. Leave it out.

## Recommendation

Drop the glue-solar-motivated proposal: no float32 option and no `read_files` argument. If the user wants the irispy fix, it is Option A on an irispy branch in a fork worktree, standing on its own as "rasters behave like SJIs and mosaics".

Change in `irispy/io/spectrograph.py`, in the eager branch of `read_spectrograph_lvl2` (line 259):
```python
                else:
                    data_mask = np.isin(data, BAD_PIXEL_VALUES_SCALED)
                    # Missing samples are NaN, as in slit-jaw images and mosaics
                    if np.issubdtype(data.dtype, np.floating):  # unscaled integer files keep their codes
                        data[data_mask] = np.nan
```
Then:
- **Docstrings:** in `read_spectrograph_lvl2`'s `memmap` entry, say that with `memmap=False` missing samples are NaN and masked (wording as in `read_sji_lvl2`). Optionally add one line to `read_files` in `irispy/io/utils.py`.
- **Example:** in `examples/how_to/03_work_with_rasters.py:100-101`, remove the comment and the `np.where`.
- **Docs:** optionally note the NaN at `docs/known_issues.rst:70`.
- **Changelog:** `changelog/<PR>.breaking.rst`. Eager raster reads now hold NaN at -200 and -199, as slit-jaw images do. Find fill with `cube.mask`.

Tests to update or add:
- `irispy/io/tests/test_spectrograph.py::test_read_spectrograph_masks_both_fill_values`: add the `memmap=False` branch. NaN exactly at the mask; -198 and 7 kept; NaN uncertainty at the mask when `uncertainty=True`.
- `::test_read_spectrograph_flips_v34_mask_uncertainty_and_meta` (line 274): compare the mask with `np.isnan(cube.data)`.
- `irispy/tests/test_spectrograph.py::test_fits_data_comparison`: compare against the FITS data with NaN at the mask, or only unmasked samples.
- `irispy/utils/tests/test_mg_features.py:47`: `missing = cube.mask.any(axis=-1)`. This is equivalent on that file, which has no -199.

For glue-solar: no change and no dependency. Close `wp0-optional-proposals`' "irispy NaN float rasters" as "not needed by glue-solar; Option A left to the user as an irispy-only fix". Even after A lands, the eager fill in `_dataset` must stay for integer AIA cutouts.

Unrelated, seen while measuring: raster `memmap=True` cubes carry the unit `DN_IRIS_FUV`/`NUV` although the data are raw codes, while SJI memmap reads say `DN_IRIS_SJI_UNSCALED`.

## Open questions for the user

1. Should Option A be filed at all, as an irispy-only fix, or dropped entirely now that glue-solar doesn't need it?
2. Ship it as a breaking change with no deprecation (recommended), or with one release of `FutureWarning`?
3. Should uncertainty at fill become NaN, as for SJIs (recommended), or stay as readout noise (computed before the fill)?
4. Confirm that the lazy scaled `memmap` read (Option C) stays with irispy #14 and out of this item.

Probes are in `/private/tmp/claude-501/-Users-nabil-Git-glue-solar/07d33ef8-b8df-4ddb-b55c-24b6271a724b/scratchpad/irispy-designs/nan-float-rasters/`. No checkout was edited.
- `state.py`: what main returns in each mode
- `bench.py`: memory and time for raw, eager, eager-nan and lazy-nan
- `proto_spectrograph.py`: Option A
- `nanfill_plugin.py`, `preimport_plugin.py`: run irispy's suite against Option A
- `same_results.py`: analysis results compared
- `numpy_user.py`: the plain-numpy hazard
- `saturated.py`: saturation in the flare files