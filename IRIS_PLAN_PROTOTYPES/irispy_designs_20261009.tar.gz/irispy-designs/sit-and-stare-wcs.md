# R8 design: the -TAB raster WCS inverse in irispy (main 3352413)

R8 is not fixed on irispy main. I recommend option A: keep the -TAB WCS and its header as they are, and replace only `world_to_pixel_values` with an exact numpy inverse. In the prototype this is 7× to about 3900× faster, depending on the raster and the points. It returns the same cells as wcslib and breaks no API. It does not resolve the sit-and-stare ambiguity, so that gets a docs note. The worktree is untouched (`git status` is clean).

## 1. Problem on current main

The irispy-ports env has astropy 8.0.1 (WCSLIB 8.6), ndcube 2.4.2 and numpy 2.5.3. All runs use the Si IV 1403 window.

| Raster | Forward | Inverse, random raster pixels | Inverse, 0.166″ grid over footprint + 2″ | Pixel → world → pixel round trip |
|---|---|---|---|---|
| 4000255147 sit-and-stare (1600, 417, 262) | 0.12–0.19 µs/pt | 7.0–11.7 ms/pt | 169–178 µs/pt (48,492 pts: 8.2–8.6 s) | step off by up to 5.95 exposures; 55–59 % off by more than 0.01 px; slit off by up to 0.18 px |
| 4000005156 scan 0 (64 steps) | 0.09 µs | 7.2–8.2 µs | 7.4 µs | 1.8e-7 px |
| 3824262996 (400 steps) | 0.09 µs | 28.7–32.3 µs | 29.5 µs | 1.2e-6 px |

- **Glue's linked-mask path:** this inverts the raster at every screen pixel of a quicklook SJI panel. For one SJI 1400 frame of 4000255147 (484×252 = 121,968 pixels, 24,257 inside the raster), one inversion takes 13.2 s.
- **Commit 5b57a18 ("Drop the step index") fixed only the forward direction.**
- **Cause:** wcslib's `tabs2x` (cextern/wcslib/C/tab.c:1356-1417) walks the cells in step order. It runs a recursive `tabvox` on every cell whose bounding box holds the point and returns the first match. The slit is tilted by about 0.78″ in longitude along its length, so on a sit-and-stare about 100 cells' boxes hold each point.
- **Correction to R8's wording:** not all 1600 entries overlap.
  - XCEN goes from 99.19″ to 112.21″ over 4750 s (9.9″/h, solar-rotation tracking), in about 270 jumps of 0.05″ roughly every 6 exposures.
  - Between jumps it jitters by ±0.0016″, and 706 of 1599 steps go backwards.
  - YCEN wobbles between 63.36″ and 64.67″ (0.21″ rms about a line).
  - So the inverse means "the first exposure whose slit passed this place". It is ambiguous only within a plateau of about 6 exposures (about 17 s, at most about 0.05″, a third of an SJI pixel). That is exactly the "off by up to 6 exposures".
- **No packaged test file shows the ambiguity.** The packaged sns file is decimated (187 exposures, 0.23″ steps), so its round trips are exact.

## 2. Options

### A. Exact numpy inverse in an astropy `WCS` subclass (recommended)

- **API:** none changes.
  - `cube.wcs` becomes `_RasterWCS(WCS)`, so `isinstance(..., WCS)` still holds.
  - The header, `to_header`, the forward direction and `all_world2pix` stay wcslib's.
  - The class handles only irispy's table layout: WAVE, HPLT-TAB, HPLN-TAB; one table of 2 slit ends × N ≥ 2 steps; identity PC. Anything else, such as `.sub()` or `.celestial`, falls back to `super()`.
- **Algorithm:**
  - Each step's slit is a straight segment, and each cell is a bilinear patch.
  - The search starts with an O(log N) lookup: a cumulative max/min of each slit's offset along the mean normal, with a proven error bound.
  - It then tests the next 8 cells exactly, and scans every cell only for the few points still unresolved.
  - Each cell is solved exactly as a quadratic.
  - It returns the lowest step cell that holds the point, as wcslib does, and NaN outside the table.
- **Behaviour:**
  - On every grid, the NaN pattern and the cells match wcslib's.
  - On scans, values agree with wcslib to within 2.6e-6 px.
  - On the sit-and-stare, values within a cell differ by up to 0.065 step px. That comes from wcslib's 1e-10° tolerance where slits are about 1e-5″ apart: wcslib's world round trip is off by 3.8e-7″, the prototype's by about 4e-12″.
  - The pixel round trip on a sit-and-stare is still off by up to 5.9 exposures, in the same cells as wcslib.
- **Measured gains** (wcslib → prototype):

  | Raster | Random raster pixels | Grid | Whole grid |
  |---|---|---|---|
  | Sit-and-stare | 7.1 ms → 1.8 µs (about 3900×) | 177 → 1.37 µs (130×) | 8.6 s → 0.067 s |
  | 4000005156 | 8.0 → 1.1 µs | 7.4 → 0.43 µs | 634k pts: 4.7 → 0.28 s |
  | 3824262996 | 31 → 1.1 µs | 29.5 → 0.57 µs | 986k pts: 29 → 0.56 s |

  - SJI screen inversion: 13.2 s → 20 ms.
  - ndcube crop by SkyCoord: 18 → 4 ms, same result.
- **Checks that passed:**
  - The full offline irispy suite passes with the reader patched: 526 passed, 5 skipped.
  - deepcopy and copy keep the class.
  - astropy `WCS.slice` with moved CRPIX matches wcslib, because the slit mapping is calibrated from wcslib's own forward.
  - ndcube's `SlicedLowLevelWCS` uses the override.
  - Pickling fails before and after (astropy cannot write -TAB), so nothing new breaks there.
- **Costs:**
  - About 100 lines, including docstrings.
  - A single-point call now takes 110–200 µs. wcslib takes 17–39 µs on scans and 0.13–7 ms on the sit-and-stare.

### B. Separable sit-and-stare WCS (step drives time, not lon/lat)

- **API:**
  - A 4-D FITS WCS (WAVE, HPLT-TAN, TIME-TAB, HPLN-TAN across the slit), sliced to 3 pixel and 4 world axes.
  - The world signature grows from 3 to 4 axes. Every `world_to_pixel(sky, wavelength)` call and crop on a sit-and-stare then needs a `Time` or a `None`.
  - Time would duplicate `extra_coords["time"]`.
  - Sit-and-stare and scanning rasters would get different WCS shapes.
- **Behaviour:**
  - Well-posed: the round trip is exact to 2e-13 px.
  - Pointing is fixed at the middle exposure, so the slit is off by up to 6.53″ in longitude and 0.76″ in latitude against the per-exposure truth (1.9″ rms).
  - The drift would survive only in the existing meta "exposure FOV center".
  - Points beside the slit map onto it, because the across-slit axis is dropped. A raster ROI would then show on the SJI as a full-width band.
- **Cost:** forward 0.07 µs/pt, inverse 3.1 µs/pt (wcslib's 1-D TIME-TAB inverse).
- **Risk:**
  - This is a real accuracy regression. It breaks `test_read_spectrograph_lvl2_uses_auxiliary_pointing` for sit-and-stare input.
  - It breaks glue-solar's world naming (a second "Time"), `link_hpc` (step pixels would need time), and `sji_to_raster`'s forward lookups at each exposure's own pointing.
  - It would need an opt-in keyword and a deprecation cycle.
  - It overlaps heavily with #182.

### C. Leave as is and document

- **Cost:** none, and nothing breaks.
- **Downside:** nothing gets faster. The per-pixel mask path stays at 13.2 s per SJI screen inversion (0.21 s per frame after glue's R2 fix, by R8's estimate).

## 3. Recommendation

Do A, plus C's docs note. A changes no API and keeps wcslib's cells and NaNs. It speeds up every raster. Fixing the sit-and-stare ambiguity needs time as a world coordinate (B or #182), and that is a separate, breaking decision.

## 4. Exact changes

- **`irispy/_wcs.py`:**
  - Add `class _RasterWCS(WCS)` with `_raster_layout()` and a `world_to_pixel_values` override.
  - Add module helpers `_invert`, `_scan`, `_solve_cell` and `_cross`. They are a port of the prototype's `fast_inverse.py`.
- **`irispy/io/spectrograph.py::_create_tabular_wcs`:** `return _RasterWCS(header, fits.HDUList([...]))` instead of `WCS(...)`.
- **Docs:** add Notes to the `read_spectrograph_lvl2` docstring or to `SpectrogramCube`. On a sit-and-stare, `world_to_pixel` gives the first exposure whose slit passes through the point; use the cube's time coordinate to choose an exposure.
- **Changelog:** `changelog/<PR>.feature.rst` (or bugfix, see question 5).

## 5. Tests (in `irispy/io/tests/test_spectrograph.py`, no remote data)

1. **Plateau sit-and-stare against wcslib.** Build a table from the sns file through `_create_tabular_wcs`, with XCEN replaced by 0.05″ jumps every 6 exposures plus ±1 mas jitter. Compare against `WCS.world_to_pixel_values(wcs, ...)`, using points a little past the table's ends and off the slit. Expect the same NaNs, the same cell (`floor`), and a world round trip within 1e-12°.
2. **Fallback.** `wcs.sub([2, 3])` must equal wcslib's result exactly.
3. **astropy `WCS.slice` with moved CRPIX** must match wcslib.

The existing `test_raster_wcs_steps_have_no_index_vector` already covers points on the first and last step; it caught an edge bug in the prototype. Tests 1 and 2 are in `test_proto.py` and pass.

## 6. What breaks, and deprecation

- `type(wcs) is WCS` becomes False.
- Values change only within wcslib's tolerance.
- Single-point calls are slower, by about 0.1–0.2 ms.
- No deprecation is needed. Rolling back means returning a plain `WCS` again.

## 7. Consumer effects (glue-solar `origin/main`)

- **No code change is needed.** `_GlueWCS` forwards to the override, and `_PerScanWCS` makes stacks faster too.
- **`sji_to_raster`'s sit-and-stare bypass by time is still needed,** because the inverse's meaning is unchanged.
- **Sessions:** `_wcs_from_state` rebuilds a plain `WCS(header, table)`, so a restored raster is back on wcslib's inverse (still correct). That changes only if the class is made public and glue-solar builds it on restore.
- **Envs** are still on irispy d0e7764 and would need a bump.
- **GLUE_SPEED R8:** the speed part would be closed. The "wrong masks" part becomes a matter of meaning: the mask shows the area the slit swept.

## 8. Overlap with #182

#182 replaces raster WCSes with a gWCS that carries step and time world coordinates, and keeps `fits_wcs` as main's -TAB WCS built per file. A touches only `_create_tabular_wcs`'s return value and `_wcs.py`, so under #182 it would only speed up `fits_wcs` users. I did not design for or against it.

## 9. Open questions for you

1. Is an astropy `WCS` subclass acceptable for irispy's raster WCS, or do you prefer docs only (C)?
2. Should the class be private (the default) or public, so that glue-solar's session restore can rebuild it?
3. On a sit-and-stare, keep wcslib's "first exposure whose slit passes the point", or make the inverse time-based? A time-based inverse needs B or #182.
4. Is 0.1–0.2 ms per single-point call on scanning rasters acceptable, or should small inputs fall back to wcslib?
5. Should the changelog fragment be a feature or a bugfix?

## Files

Everything is in `/private/tmp/claude-501/-Users-nabil-Git-glue-solar/07d33ef8-b8df-4ddb-b55c-24b6271a724b/scratchpad/irispy-designs/r8-tab-wcs/`:
- `verify.py`: the measurements on main.
- `fast_inverse.py`: option A.
- `compare_a.py`: option A against wcslib.
- `sji_grid.py`: the SJI screen inversion.
- `sliced_check.py`: astropy and ndcube slicing.
- `subclass_checks.py`: copy, pickle, crop.
- `single_point.py`: single-point timings.
- `window_sweep.py`: the search-window size sweep.
- `option_b.py`: option B.
- `test_proto.py`: the proposed tests.
- `patchwcs.py` and `testcopy/`: the irispy suite run with the patched reader.