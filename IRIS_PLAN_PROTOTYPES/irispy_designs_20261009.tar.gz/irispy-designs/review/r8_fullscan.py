"""Is the windowed O(log N) search in fast_inverse needed, or does the plain vectorised scan of every cell do?"""

import sys
import time
import warnings

import numpy as np

sys.path.insert(0, "/private/tmp/claude-501/-Users-nabil-Git-glue-solar/07d33ef8-b8df-4ddb-b55c-24b6271a724b/scratchpad/irispy-designs/r8-tab-wcs")
from fast_inverse import _invert, _scan  # NOQA: E402
from verify import FILES, si_iv  # NOQA: E402

from irispy.io.spectrograph import read_spectrograph_lvl2  # NOQA: E402

warnings.simplefilter("ignore")
rng = np.random.default_rng(3)
for name, f in FILES.items():
    key, cube = si_iv(read_spectrograph_lvl2(f, memmap=True))
    coord = np.asarray(cube.wcs.wcs.tab[0].coord)
    a, b = coord[:, 0], coord[:, 1]
    lat0, lat1 = coord[..., 0].min() - 2 / 3600, coord[..., 0].max() + 2 / 3600
    lon0, lon1 = coord[..., 1].min() - 2 / 3600, coord[..., 1].max() + 2 / 3600
    step = 0.1663 / 3600
    lat, lon = np.meshgrid(np.arange(lat0, lat1, step), np.arange(lon0, lon1, step), indexing="ij")
    lat, lon = lat.ravel(), lon.ravel()
    x = np.stack((lat, lon), axis=-1)
    t = time.perf_counter()
    s1, u1 = _invert(a, b, lat, lon)
    t1 = time.perf_counter() - t
    t = time.perf_counter()
    s2, u2 = _scan(a, b, x, None)
    t2 = time.perf_counter() - t
    same = np.array_equal(np.isnan(s1), np.isnan(s2)) and np.allclose(s1, s2, equal_nan=True, atol=1e-9) and np.allclose(u1, u2, equal_nan=True, atol=1e-9)
    print(f"{name}: {len(a)} steps, {lat.size} grid pts: windowed {t1:.3f} s, full scan {t2:.3f} s ({t2 / t1:.1f}x), same {same}")
    # single point
    t = time.perf_counter()
    for _ in range(20):
        _invert(a, b, lat[:1], lon[:1])
    t1 = (time.perf_counter() - t) / 20
    t = time.perf_counter()
    for _ in range(20):
        _scan(a, b, x[:1], None)
    t2 = (time.perf_counter() - t) / 20
    print(f"   one point: windowed {t1 * 1e6:.0f} us, full scan {t2 * 1e6:.0f} us")
