**Review of the three irispy design proposals (re-verified on irispy main 3352413, worktree untouched; probes in `/private/tmp/claude-501/-Users-nabil-Git-glue-solar/07d33ef8-b8df-4ddb-b55c-24b6271a724b/scratchpad/irispy-designs/review/`)**

---

## 1. moments-continuum — AGREE with A, with changes

**Re-verified (my runs, `trap.out`, `bench.out`, `einsum.out`, `test_mb_on_main.py`):**
- Trap is real: flare r00172-174 give 839 saturated pixels raw, 0 after `subtract_background`, for degree 0 and 1.
- 4000255147, 1 repeat: today 1.98 s (first call 0.44, `subtract_background` 1.15, second 0.39) vs A 1.37 s; degree 0: 1.02 vs 0.65 s. A's maps are `array_equal` to today's in all four configs. Peak per slab 55 → 29 MiB.
- Wings-mask claim holds on main: the proposed test fails on `intensity` only (centroid/width are NaN so already masked). Only `intensity` and `saturated` are affected.
- `einsum(..., optimize=True)`: degree-1 fit 0.865 → 0.319 s, max diff 2.1e-10 DN/s; degree 0 unchanged (0.29 s).

**Corrections and what the proposal misses:**
1. The speed argument is weaker than presented. The `optimize=True` two-word change inside `subtract_background` saves 0.55 s on degree 1, about the same as all of option A (0.60 s), with no new API. A's standalone justification for irispy users is the saturation trap and the memory, not speed. Say so in the PR.
2. Naming: `background=<windows>` collides with `profiles_on_background(background="constant"|"linear")`, where `background` is a model name. Use `background_windows` and `background_degree`, mirroring `subtract_background(cube, windows, degree=)`.
3. Put `_fit_background` in `irispy/utils/_spectral.py` (the shared-helper module both already import) rather than importing a private name from one public module into another. Same code, no cross-import.
4. The mask fix is separable, and glue-solar does not need it: after the one-call change, `np.isnan(values[..., inside]).all(-1)` is one line on glue-solar's side. Ship it in irispy on its own merits (consistency with `average_window`'s "no sample left → NaN and masked"), as its own bugfix fragment, in the same PR or a separate one. Note it changes only `.mask`, not values; `saturated` should get the same `mask=` for consistency (the diff leaves it out).
5. Small optional saving: `_fit_background` evaluates `coefficients @ vander.T` over the whole spectrum and then crops. Evaluating only at the wings' indices cuts a full-cube float64 temporary for whole-cube callers. Not needed for the PR.
6. Nothing breaks: both arguments are keyword-only and default off. The pkg's 95 tests passing is credible.

**Smaller option?** Docs-only (a Notes line in `subtract_background` and `calculate_moments`) is the minimum, but it leaves irispy users with the silent 0-saturated result and a needless full-cube copy. A at 25 lines is the right size. C (+Inf writing) is rejected correctly: it leaks a sentinel into a public result.

**Final recommendation:** A as proposed, renamed `background_windows`/`background_degree`, helper in `_spectral.py`, mask fix included for `intensity` and `saturated`, einsum `optimize=True` as a separate trivial commit (results differ at 1e-12 relative; no changelog). Tests 1-4 as drafted. `calculate_mg_features` left alone until asked.

**Open questions for the user:** (a) `background_windows` vs `background`? (b) Mask fix in the same PR (as a separate commit + bugfix fragment) or its own PR? (c) For "masked at every wavelength within the wings", mask only (proposal, smaller) or NaN + mask like `average_window`? (d) einsum optimize: same PR as a separate commit, or skip?

---

## 2. sit-and-stare-wcs (R8) — AGREE with A, with one scope question

**Re-verified (`r8_verify.out`, `r8_compare.out`, `r8_fullscan.py`):**
- On main: sit-and-stare inverse 13.1 ms/pt (random raster pixels), 7.2 ms/pt in the second run; scans 8.6 and 32.9 µs/pt. Round trip off by up to 5.95 steps on the sit-and-stare, 55-59 % of points > 0.01 px; scans exact to 1e-6 px. Problem is real and not fixed by 5b57a18.
- Prototype: same NaN pattern and cells as wcslib on all three grids; 1.4-1.9 µs/pt on the sit-and-stare (vs 195 µs grid / 7.2 ms random), 0.44-0.57 µs/pt on scans; grid 48k points 0.067 s vs 9.5 s. `test_proto.py` passes (2 tests).
- astropy 8.0.1 `WCS.slice`, `sub`, `__copy__`, `__deepcopy__` and `__reduce__` all go through `self.deepcopy()`/`self.__class__`, so the subclass survives them (checked in `astropy/wcs/wcs.py`).
- glue-solar origin/main's `_GlueWCS.world_to_pixel_values` forwards to `self._wcs.world_to_pixel_values` (`loaders/iris.py:198-208`), so it picks up the override; `_wcs_from_state` rebuilds a plain `WCS` (`iris.py:325`), so restored sessions stay on wcslib, as stated.

**Corrections and what it misses:**
1. Is the windowed O(log N) search worth its ~25 lines and the error-bound argument? I timed the prototype's plain full scan (`_scan(cells=None)`) alone: sit-and-stare grid 0.88 s (13.5× slower than windowed, still 11× faster than wcslib), 64-step scan 0.56 s (2×), 400-step scan 4.9 s (8.9×, only 5.8× faster than wcslib). Single points are faster with the full scan (50 vs 93 µs; 13 vs 34 µs). So the full scan alone (about 60 lines: class, `_scan`, `_solve_cell`, `_cross`) fixes the sit-and-stare pathology that R8 is about; the windowed search buys the extra 2-14× on long scanning rasters' SJI-screen grids. Keep it only if glue's per-frame mask on scanning rasters needs it; otherwise ship the smaller version.
2. Single-point regression on scans (17-39 µs → 110-200 µs, or ~50 µs with the full scan) is the only user-visible cost; it is the common irispy call pattern (`cube.crop`, one `world_to_pixel`). Acceptable in absolute terms, but say it in the changelog.
3. Values within a cell differ from wcslib by up to 0.065 step px on the sit-and-stare; the prototype's world round trip (4e-12″) is better than wcslib's (3.8e-7″), so this is wcslib's tolerance, not a prototype error. Fine, but any irispy test that compares `world_to_pixel` against hard-coded wcslib numbers on a sit-and-stare would need `atol`.
4. B is correctly rejected: it is an accuracy regression (slit off by up to 6.5″) and a world-signature change. C costs nothing but closes nothing.
5. `type(wcs) is WCS` becoming False is the only break; no deprecation needed.

**Final recommendation:** A, private class `_RasterWCS` in `irispy/_wcs.py`, built by `_create_tabular_wcs`; docs note that on a sit-and-stare the inverse gives the first exposure whose slit passed the point. Changelog: feature (no behaviour change). Tests 1-3 as drafted; add an `atol` on sit-and-stare step comparisons.

**Open questions for the user:** (a) Full scan only (~60 lines) or with the windowed search (~100 lines)? The decider is whether glue needs < 1 s per SJI-screen inversion on 400-step scanning rasters. (b) Private or public class (public only if glue-solar should rebuild it on session restore)? (c) Accept the 0.1-0.2 ms single-point cost on scans, or fall back to wcslib below some point count?

---

## 3. nan-float-rasters — AGREE: moot for glue-solar; Option A is a small irispy-only consistency fix

**Re-verified (`nan_state.out`, test run with the NaN prototype):**
- Eager raster: float32, 27,614,960 × -200.0 and 72 × -199.0 kept in the data under a bool mask (15.8 %), max 16182, no NaN/Inf. Eager SJI: 13,928,370 NaN under the mask, no codes. `io/sji.py:273-277` and `io/mosaic.py:79-80` fill NaN; the raster reader does not. The inconsistency is real.
- Prototype against main's tests: exactly 4 failures, as stated: `test_read_spectrograph_flips_v34_mask_uncertainty_and_meta` (asserts `mask == data == -200`), `test_fits_data_comparison`, `test_matches_idl[k]` and `[h]` (`cube.data == -200` at `test_mg_features.py:45`). All compare to the code, none to behaviour.
- glue-solar origin/main: `LAZY = True`, fills NaN itself at `loaders/lazy.py:67`, `loaders/iris.py:391` and `stack_spectrograms.py:55`. No dependency on irispy here.
- Uncertainty: `calculate_uncertainty` clips photons at 0, so -200 gives readout noise today; after the fill it is NaN (as SJI, whose fill also precedes `calculate_uncertainty`, `sji.py:277-282`).

**Corrections and what it misses:**
1. The proposal's own line "Unmasked `sum`/`mean` now returns NaN instead of a silently biased number" is the strongest argument for A, stronger than consistency; the `03_work_with_rasters.py:100` example shows irispy's docs already fight the codes.
2. Mirror `sji.py:275-276`'s non-writeable guard (`if not data.flags["W"]: data = data.copy()`) in the raster branch; astropy's scaled array is writeable today, but the guard is one line and already irispy's pattern.
3. The side note is right: memmap rasters carry `DN_IRIS_FUV`/`NUV` on raw codes while SJI memmap says `DN_IRIS_SJI_UNSCALED` (`constants.py:33-38` has no FUV/NUV unscaled unit). Separate item; `check_scaled` already catches misuse through `meta["scaled"]`/dtype.
4. No deprecation path is practical (a `FutureWarning` on every eager read, warnings-as-errors in the suite); #206 is the precedent.

**Smaller option?** Docs-only (one sentence in `read_spectrograph_lvl2`'s `memmap` entry that eager rasters keep the codes under the mask) is zero-risk. A is 3 lines plus 4 test updates. Either is small; the question is only whether LM-SAL wants to break `data == -200`.

**Final recommendation:** Close the glue-solar item as not needed. If the user wants an irispy fix, Option A as drafted (3-line reader change, `breaking` fragment, 4 test updates, example comment removed, docstring line); no `read_files` argument, no float memmap mode; Option C stays with #14.

**Open questions for the user:** (a) File A at all? (b) Breaking with no deprecation (recommended)? (c) Uncertainty NaN at fill (recommended, matches SJI) or keep readout noise? (d) File the memmap unit inconsistency as its own item?