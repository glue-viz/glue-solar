"""pytest plugin: run irispy's suite with option A (eager raster fill as NaN) in place of main's reader."""
import irispy.io
import irispy.io.spectrograph
import irispy.io.utils
import proto_spectrograph

for module in (irispy.io, irispy.io.spectrograph, irispy.io.utils):
    module.read_spectrograph_lvl2 = proto_spectrograph.read_spectrograph_lvl2
