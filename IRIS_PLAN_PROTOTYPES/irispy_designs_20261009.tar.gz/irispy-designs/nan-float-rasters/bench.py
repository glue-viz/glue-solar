"""Read time and memory of 4000255147 Si IV 1403: int16 memmap + lazy mask against float32 NaN-filled (eager, lazy).

Usage: bench.py {raw,eager,eager-nan,lazy-nan}. Warm page cache; one variant per process.
"""

import sys
import time
import resource
import tracemalloc
import warnings

import numpy as np

warnings.simplefilter("ignore")
RASTER = "/Users/nabil/DATA/IRIS/2dd2d12db374b3466aa27a65bec235d3-iris_l2_20130902_163935_4000255147_raster/iris_l2_20130902_163935_4000255147_raster_t000_r00000.fits"
variant = sys.argv[1]
from irispy.io import read_files  # NOQA: E402
from irispy.io._mask import _MappedArray  # NOQA: E402


def rss():
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 2**20


def lazy_nan(cube):
    """Option C prototype: memmap's raw int16 as lazy float32 DN with fill as NaN (dask), as astropy scales."""
    import dask.array as da

    raw = cube.data
    bscale, bzero = np.float32(cube.meta["BSCALE"]), np.float32(cube.meta["BZERO"])
    fill = np.array([-32768, -32764], np.int16)  # raw -200, -199 for BSCALE 0.25, BZERO 7992

    def scale(block):
        values = block.astype(np.float32)
        values *= bscale
        values += bzero
        values[np.isin(block, fill)] = np.nan
        return values

    mapped = da.from_array(_MappedArray(raw), chunks=(1, *raw.shape[1:]), name=False, meta=np.empty((0, 0, 0), raw.dtype))
    return mapped.map_blocks(scale, dtype=np.float32, meta=np.empty((0, 0, 0), np.float32))


rss0 = rss()
tracemalloc.start()
t = time.perf_counter()
cube = read_files(RASTER, spectral_windows="Si IV 1403", memmap=variant in ("raw", "lazy-nan"))["Si IV 1403"][0]
if variant == "eager-nan":
    cube.data[cube.mask] = np.nan
data = lazy_nan(cube) if variant == "lazy-nan" else cube.data
t_open = time.perf_counter() - t
open_peak = tracemalloc.get_traced_memory()[1]
tracemalloc.stop()
rss_open = rss()


def step(i):
    """One raster step, as a viewer reads it: values and missing flags."""
    if variant == "raw":
        return np.asarray(data[i]), np.asarray(cube.mask[i])
    if variant == "lazy-nan":
        values = np.asarray(data[i])
        return values, np.isnan(values)
    return data[i], cube.mask[i]


steps = np.linspace(0, data.shape[0] - 1, 50).astype(int)
t = time.perf_counter()
for i in steps:
    step(i)
t_step = (time.perf_counter() - t) / len(steps)
tracemalloc.start()
t = time.perf_counter()
if variant == "raw":  # what a user does to get DN from it: scale, then NaN where the lazy mask says
    whole = np.asarray(data).astype(np.float32) * np.float32(cube.meta["BSCALE"]) + np.float32(cube.meta["BZERO"])
    whole[np.asarray(cube.mask)] = np.nan
else:
    whole = np.asarray(data)
t_whole = time.perf_counter() - t
whole_peak = tracemalloc.get_traced_memory()[1]
tracemalloc.stop()
retained = (whole.nbytes if variant in ("raw", "lazy-nan") else 0)
print(
    f"{variant:9s} open {t_open:.3f} s (peak {open_peak / 2**20:.0f} MiB, maxrss +{rss_open - rss0:.0f} MiB) | "
    f"step {t_step * 1e3:.2f} ms | whole window {t_whole:.2f} s, peak {whole_peak / 2**20:.0f} MiB, "
    f"{whole.dtype} {whole.nbytes / 2**20:.0f} MiB"
)
