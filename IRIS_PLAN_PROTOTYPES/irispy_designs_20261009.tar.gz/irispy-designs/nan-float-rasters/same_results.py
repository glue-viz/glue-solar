"""Do irispy's analysis helpers give the same results on NaN-filled raster data (option A) as on main's -200?"""

import warnings

import numpy as np

import astropy.units as u

warnings.simplefilter("ignore")
from irispy.data.test import get_test_filepath  # NOQA: E402
from irispy.io.spectrograph import read_spectrograph_lvl2 as main_read  # NOQA: E402
from irispy.utils.mg_features import calculate_mg_features  # NOQA: E402
from irispy.utils.moments import calculate_moments  # NOQA: E402
from irispy.utils.red_blue import calculate_red_blue_asymmetry  # NOQA: E402
from proto_spectrograph import read_spectrograph_lvl2 as nan_read  # NOQA: E402


def same(a, b, what):
    for key in a:
        np.testing.assert_array_equal(np.asarray(a[key].data), np.asarray(b[key].data), err_msg=f"{what} {key}")
    print(f"{what}: identical ({len(a)} maps)")


mg = get_test_filepath("mg_features/iris_l2_20130902_182935_4000005156_raster_t000_r00000_mg_features_test.fits")
ra, rb = main_read(mg), nan_read(mg)
for window, line in (("Mg II k 2796", "k"), ("Mg II h 2803", "h")):
    a, b = ra[window][0], rb[window][0]
    assert np.isnan(b.data[b.mask]).all() and (a.data[a.mask] == -200).all()
    same(calculate_mg_features(a, lines=(line,)), calculate_mg_features(b, lines=(line,)), f"mg_features {line}")

RASTER = "/Users/nabil/DATA/IRIS/2dd2d12db374b3466aa27a65bec235d3-iris_l2_20130902_163935_4000255147_raster/iris_l2_20130902_163935_4000255147_raster_t000_r00000.fits"
a = main_read(RASTER, spectral_windows="Si IV 1403")["Si IV 1403"][0][:200]
b = nan_read(RASTER, spectral_windows="Si IV 1403")["Si IV 1403"][0][:200]
print("Si IV steps 0-199 masked:", int(np.asarray(b.mask).sum()))
same(calculate_moments(a, rest_wavelength=1402.77 * u.AA, wings=0.5 * u.AA), calculate_moments(b, rest_wavelength=1402.77 * u.AA, wings=0.5 * u.AA), "moments")
same(
    calculate_red_blue_asymmetry(a, rest_wavelength=1402.77 * u.AA, velocity_range=[20, 60] * u.km / u.s, return_profiles=False),
    calculate_red_blue_asymmetry(b, rest_wavelength=1402.77 * u.AA, velocity_range=[20, 60] * u.km / u.s, return_profiles=False),
    "red_blue",
)
