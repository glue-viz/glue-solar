"""pytest plugin: import irispy before warnings become errors (the detached worktree has no _version.py)."""
import irispy  # NOQA: F401
