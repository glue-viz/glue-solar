"""How saturation shows in main's raster reads: the 16182 DN ceiling, unmasked, no +Inf."""
import warnings

import numpy as np

warnings.simplefilter("ignore")
from irispy.io import read_files  # NOQA: E402

F = "/Users/nabil/DATA/IRIS/saturated/iris_l2_20140329_140938_3860258481_raster_t000_r00172.fits.gz"
for memmap in (False, True):
    collection = read_files(F, memmap=memmap)
    for window in collection.keys():
        cube = collection[window][0]
        d, m = np.asarray(cube.data), np.asarray(cube.mask)
        top = 16182.0 if not memmap else 32760
        print(f"memmap={memmap} {window}: {d.dtype}, at ceiling {int((d == top).sum())} (masked {int((m & (d == top)).sum())}), "
              f"+Inf {int(np.isposinf(d).sum()) if d.dtype.kind == 'f' else 0}, above ceiling {int((d > top).sum())}")
