"""What irispy main returns now: dtype, fill, mask, memory, time. Usage: state.py MODE [trace]."""

import sys
import time
import resource
import tracemalloc
import warnings

import numpy as np

warnings.simplefilter("ignore")
D = "/Users/nabil/DATA/IRIS/"
RASTER = D + "2dd2d12db374b3466aa27a65bec235d3-iris_l2_20130902_163935_4000255147_raster/iris_l2_20130902_163935_4000255147_raster_t000_r00000.fits"
SJI = D + "534d789bb0a2821fb2b78eb36d1d6753-iris_l2_20130902_163935_4000255147_SJI_1400_t000.fits.gz"
mode = sys.argv[1]
trace = "trace" in sys.argv
memmap = mode.endswith("memmap")
nanfill = "nanfill" in sys.argv  # prototype: option A, eager raster data[mask] = NaN in place

import irispy.io  # NOQA: E402
from irispy.io import read_files  # NOQA: E402

if trace:
    tracemalloc.start()
rss0 = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
t = time.perf_counter()
if mode.startswith("raster"):
    cube = read_files(RASTER, spectral_windows="Si IV 1403", memmap=memmap)["Si IV 1403"][0]
else:
    cube = read_files(SJI, memmap=memmap)
t_open = time.perf_counter() - t
t_fill = 0.0
if nanfill:
    t = time.perf_counter()
    cube.data[cube.mask] = np.nan
    t_fill = time.perf_counter() - t
peak = tracemalloc.get_traced_memory()[1] if trace else None
rss_open = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
data = cube.data
mask = cube.mask
t = time.perf_counter()
mask_np = np.asarray(mask)
t_mask = time.perf_counter() - t
print(f"{mode}: open {t_open:.2f} s" + (f", NaN fill {t_fill:.3f} s" if nanfill else "") + f", mask compute {t_mask:.2f} s")
print(f"  data {type(data).__name__} {data.dtype} {data.shape} {data.nbytes / 2**20:.0f} MiB, writeable {data.flags['W'] if hasattr(data, 'flags') else None}")
print(f"  mask {type(mask).__name__} {mask.dtype}, {mask_np.nbytes / 2**20:.0f} MiB, {int(mask_np.sum())} masked ({mask_np.mean():.2%})")
vals = np.asarray(data[mask_np]) if mask_np.any() else np.array([])
codes, counts = np.unique(vals[~np.isnan(vals)] if vals.dtype.kind == "f" else vals, return_counts=True)
print(f"  values under mask: NaN {int(np.isnan(vals).sum()) if vals.dtype.kind == 'f' else 0}, codes {dict(zip(codes.tolist(), counts.tolist()))}")
full = np.asarray(data)
print(f"  max {np.nanmax(full)}, NaN total {int(np.isnan(full).sum()) if full.dtype.kind == 'f' else 0}, +Inf {int(np.isposinf(full).sum()) if full.dtype.kind == 'f' else 0}")
print(f"  unit {cube.unit}, meta scaled {cube.meta.get('scaled')}, BSCALE {cube.meta.get('BSCALE')}, BZERO {cube.meta.get('BZERO')}")
rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
print(f"  maxrss after open {rss_open / 2**20:.0f} MiB, at end {rss / 2**20:.0f} MiB (before read {rss0 / 2**20:.0f} MiB)" + (f", tracemalloc peak during read {peak / 2**20:.0f} MiB" if trace else ""))
