"""What a plain-numpy user sees from main's eager Si IV 1403 window: fill counted as data."""
import warnings

import numpy as np

warnings.simplefilter("ignore")
from irispy.io import read_files  # NOQA: E402

R = "/Users/nabil/DATA/IRIS/2dd2d12db374b3466aa27a65bec235d3-iris_l2_20130902_163935_4000255147_raster/iris_l2_20130902_163935_4000255147_raster_t000_r00000.fits"
cube = read_files(R, spectral_windows="Si IV 1403")["Si IV 1403"][0]
d, m = cube.data, cube.mask
print(f"mean with fill {d.mean(dtype=float):.2f} DN, without {d[~m].mean(dtype=float):.2f} DN; min {d.min()} vs {d[~m].min()}")
spectrum = d[:, 200, :].mean(axis=0)  # mean spectrum at one slit row
good = np.where(m[:, 200, :], np.nan, d[:, 200, :])
print(f"row 200 mean spectrum: min {spectrum.min():.2f} vs nanmean {np.nanmin(np.nanmean(good, axis=0)):.2f}; rows with any fill: {int(m.any(axis=(0, 2)).sum())}/{d.shape[1]}")
print("fill rows along slit:", np.flatnonzero(m.all(axis=(0, 2)))[[0, -1]] if m.all(axis=(0, 2)).any() else None, "fill fraction per step min/max:", m.mean(axis=(1, 2)).min().round(3), m.mean(axis=(1, 2)).max().round(3))
