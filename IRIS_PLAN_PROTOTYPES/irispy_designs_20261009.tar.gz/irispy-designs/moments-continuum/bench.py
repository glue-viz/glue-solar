"""
glue-solar origin/main's _moments with a continuum (two irispy calls per slab) against one call of option A's
calculate_moments(background=...), and option C (subtract_background marking raw saturation +Inf), on full-size data.

python bench.py <name> <repeats>
"""

import gc
import itertools
import sys
import time
import tracemalloc
import warnings

import numpy as np

import astropy.units as u
from astropy.nddata import StdDevUncertainty
from astropy.wcs.wcsapi.wrappers import SlicedLowLevelWCS
from ndcube.meta import NDMeta

from irispy.io import read_files
from irispy.spectrograph import SpectrogramCube
from irispy.utils import calculate_uncertainty
from irispy.utils.constants import BAD_PIXEL_VALUES_SCALED, DN_UNIT, READOUT_NOISE, SATURATION_LIMIT
from irispy.utils.moments import calculate_moments
from irispy.utils.spectrograph import subtract_background

import option_a

warnings.simplefilter("ignore")
SLAB = 2**21
_HAIR = 1e-6
CENTRE, WINGS = 1402.77, (0.5, 0.5)
CONTINUA = {1: [(1401.6, 1402.1), (1403.5, 1404.3)], 0: [(1403.5, 1404.3)]}  # degree: windows
DATA = {
    "4000255147": [
        "/Users/nabil/DATA/IRIS/2dd2d12db374b3466aa27a65bec235d3-iris_l2_20130902_163935_4000255147_raster/"
        "iris_l2_20130902_163935_4000255147_raster_t000_r00000.fits"
    ],
    "3860258481": [
        f"/Users/nabil/DATA/IRIS/saturated/iris_l2_20140329_140938_3860258481_raster_t000_r{r:05d}.fits.gz"
        for r in (172, 173, 174)
    ],
}


class Window:
    """What glue-solar's dataset gives _moments: scaled float32 with the missing codes NaN, exposure times, WCS."""

    def __init__(self, filename):
        cube = read_files(filename, spectral_windows="Si IV 1403")["Si IV 1403"][0]
        self.values = np.array(cube.data, dtype=np.float32)
        self.values[np.isin(self.values, BAD_PIXEL_VALUES_SCALED)] = np.nan
        self.seconds = cube.meta["exposure time"].to_value(u.s).astype(np.float32)
        self.wcs = cube.wcs.low_level_wcs
        self.wavelengths = cube.axis_world_coords(2)[0].to_value(u.AA)
        self.unit = DN_UNIT["FUV"] / u.s
        self.shape = self.values.shape


def window(w, continuum):
    def within(low, high):
        return np.flatnonzero((w.wavelengths >= low - _HAIR) & (w.wavelengths <= high + _HAIR))

    inside = within(CENTRE - WINGS[0], CENTRE + WINGS[1])
    ends = [inside[0], inside[-1]]
    for low, high in continuum or ():
        win = within(low, high)
        ends += [win[0], win[-1]]
    return slice(min(ends), max(ends) + 1), slice(inside[0], inside[-1] + 1)


def read(w, rows, wavelengths):
    values = w.values[(*rows, wavelengths)]
    seconds = w.seconds[rows[0]].reshape(-1, 1, 1)
    return values.astype(float) / np.where(seconds > 0, seconds, np.nan).astype(np.float32), seconds


def sigma_of(values, unit, seconds):
    return calculate_uncertainty(values * seconds, READOUT_NOISE["FUV"], DN_UNIT["FUV"]) / np.where(
        seconds > 0, seconds, np.nan
    ).astype(np.float32)


def make_cube(w, values, rows, wavelengths, unit, seconds=None, sigma=None):
    meta = None
    if seconds is not None:
        meta = NDMeta()
        meta.add("exposure time", seconds.ravel() * u.s, None, 0)
    view = SlicedLowLevelWCS(w.wcs, (*rows, wavelengths))
    uncertainty = None if sigma is None else StdDevUncertainty(sigma)
    return SpectrogramCube(values, view, uncertainty, unit, mask=np.isnan(values) | np.isneginf(values), meta=meta)


def collect(maps, slab, reached, errors):
    for name, moment in slab.items():
        blank = moment.mask | reached
        maps.setdefault(name, []).append(np.where(blank, np.nan, moment.data))
        if errors:
            maps.setdefault(f"{name} error", []).append(np.where(blank, np.nan, moment.uncertainty.array))


def today(w, continuum, degree, errors, crop, inner, timer):
    """glue-solar origin/main's _moments loop body, verbatim but for glue's reads."""
    maps, saturated = {}, 0
    steps = max(1, SLAB // (w.shape[-2] * (crop.stop - crop.start) * (2 if continuum or errors else 1)))
    inside = slice(inner.start - crop.start, inner.stop - crop.start)
    for start in range(0, w.shape[0], steps):
        rows = (slice(start, start + steps), slice(None))
        values, seconds = read(w, rows, crop)
        sigma = sigma_of(values[..., inside], w.unit, seconds) if errors else None
        t0 = time.perf_counter()
        slab = calculate_moments(
            make_cube(w, values[..., inside], rows, inner, w.unit, seconds, None if continuum else sigma),
            rest_wavelength=CENTRE * u.AA,
            wings=WINGS * u.AA,
            saturation_limit=SATURATION_LIMIT,
        )
        reached = slab.pop("saturated").data
        t1 = time.perf_counter()
        timer["first call"] += t1 - t0
        if continuum:
            values = subtract_background(make_cube(w, values, rows, crop, w.unit), continuum * u.AA, degree=degree).data
            t2 = time.perf_counter()
            timer["subtract_background"] += t2 - t1
            slab = calculate_moments(
                make_cube(w, values[..., inside], rows, inner, w.unit, sigma=sigma),
                rest_wavelength=CENTRE * u.AA,
                wings=WINGS * u.AA,
            )
            timer["second call"] += time.perf_counter() - t2
        saturated += int(reached.sum())
        collect(maps, slab, reached, errors)
        gc.collect(0)
    return {k: np.concatenate(v) for k, v in maps.items()}, saturated


def one_call(w, continuum, degree, errors, crop, inner, timer, module=option_a.moments):
    """Option A: one call on the crop, irispy picking the wings, fitting the background and checking saturation."""
    maps, saturated = {}, 0
    steps = max(1, SLAB // (w.shape[-2] * (crop.stop - crop.start) * (2 if continuum or errors else 1)))
    for start in range(0, w.shape[0], steps):
        rows = (slice(start, start + steps), slice(None))
        values, seconds = read(w, rows, crop)
        sigma = sigma_of(values, w.unit, seconds) if errors else None
        t0 = time.perf_counter()
        slab = module.calculate_moments(
            make_cube(w, values, rows, crop, w.unit, seconds, sigma),
            rest_wavelength=CENTRE * u.AA,
            wings=WINGS * u.AA,
            saturation_limit=SATURATION_LIMIT,
            background=continuum * u.AA,
            background_degree=degree,
        )
        reached = slab.pop("saturated").data
        timer["one call"] += time.perf_counter() - t0
        saturated += int(reached.sum())
        collect(maps, slab, reached, errors)
        gc.collect(0)
    return {k: np.concatenate(v) for k, v in maps.items()}, saturated


def option_c(w, continuum, degree, errors, crop, inner, timer):
    """
    Option C: subtract_background(..., saturation_limit=) leaves raw samples at or above the limit +Inf, which
    calculate_moments(saturation_limit=inf) then finds; emulated here by setting them in glue-solar's slab.
    """
    from irispy.utils.moments import _saturation_limit

    maps, saturated = {}, 0
    steps = max(1, SLAB // (w.shape[-2] * (crop.stop - crop.start) * (2 if continuum or errors else 1)))
    inside = slice(inner.start - crop.start, inner.stop - crop.start)
    for start in range(0, w.shape[0], steps):
        rows = (slice(start, start + steps), slice(None))
        values, seconds = read(w, rows, crop)
        sigma = sigma_of(values[..., inside], w.unit, seconds) if errors else None
        t0 = time.perf_counter()
        cube = make_cube(w, values, rows, crop, w.unit, seconds)
        result = subtract_background(cube, continuum * u.AA, degree=degree)
        out = result.data  # in subtract_background: np.where(raw >= limit, inf, cube - background)
        out[values >= _saturation_limit(cube, SATURATION_LIMIT)] = np.inf
        slab = calculate_moments(
            make_cube(w, out[..., inside], rows, inner, w.unit, seconds, sigma),
            rest_wavelength=CENTRE * u.AA,
            wings=WINGS * u.AA,
            saturation_limit=np.inf,
        )
        reached = slab.pop("saturated").data
        timer["option C"] += time.perf_counter() - t0
        saturated += int(reached.sum())
        collect(maps, slab, reached, errors)
        gc.collect(0)
    return {k: np.concatenate(v) for k, v in maps.items()}, saturated


def same(a, b):
    assert a.keys() == b.keys(), (a.keys(), b.keys())
    bad = {}
    for k in a:
        if not np.array_equal(a[k], b[k], equal_nan=True):
            diff = ~((a[k] == b[k]) | (np.isnan(a[k]) & np.isnan(b[k])))
            bad[k] = (int(diff.sum()), float(np.nanmax(np.abs(a[k] - b[k]))))
    return bad or "equal"


def peak(fn, *args):
    tracemalloc.start()
    fn(*args)
    p = tracemalloc.get_traced_memory()[1]
    tracemalloc.stop()
    return p / 2**20


if __name__ == "__main__":
    name, repeats = sys.argv[1], int(sys.argv[2])
    windows = [Window(f) for f in DATA[name]]
    print(name, [w.shape for w in windows], "exposures", np.unique(np.concatenate([w.seconds for w in windows]).round(3)))
    for degree, errors in itertools.product((1, 0), (False, True)):
        continuum = CONTINUA[degree]
        runs = {"today": [], "A": [], "C": []}
        for _ in range(repeats):
            for label, fn in (("today", today), ("A", one_call), ("C", option_c)):
                timer = dict.fromkeys(("first call", "subtract_background", "second call", "one call", "option C"), 0.0)
                results = []
                for w in windows:
                    crop, inner = window(w, continuum)
                    results.append(fn(w, continuum, degree, errors, crop, inner, timer))
                runs[label].append(timer)
                result = (
                    {k: np.concatenate([r[0][k] for r in results]) for k in results[0][0]},
                    sum(r[1] for r in results),
                )
                if label == "today":
                    base = result
                else:
                    check = same(base[0], result[0]), base[1], result[1]
                    runs[label + " check"] = check
        med = lambda label, key: np.median([r[key] for r in runs[label]])
        t = {k: med("today", k) for k in ("first call", "subtract_background", "second call")}
        a, c = med("A", "one call"), med("C", "option C")
        print(
            f"degree {degree} errors {errors}: today {sum(t.values()):.3f} s "
            f"(first {t['first call']:.3f}, subtract_background {t['subtract_background']:.3f}, second {t['second call']:.3f}); "
            f"A {a:.3f} s ({sum(t.values()) - a:+.3f}); C {c:.3f} s ({sum(t.values()) - c:+.3f})"
        )
        print("   A vs today:", runs["A check"], " C vs today:", runs["C check"])
    w = windows[0]
    crop, inner = window(w, CONTINUA[1])
    steps = max(1, SLAB // (w.shape[-2] * (crop.stop - crop.start) * 2))
    sub = Window.__new__(Window)
    sub.__dict__.update(w.__dict__, values=w.values[:steps], seconds=w.seconds[:steps], shape=w.values[:steps].shape)
    for errors in (False, True):
        timer = dict.fromkeys(("first call", "subtract_background", "second call", "one call", "option C"), 0.0)
        print(
            f"peak MiB of one slab ({steps} steps), errors {errors}: today {peak(today, sub, CONTINUA[1], 1, errors, crop, inner, timer):.0f}, "
            f"A {peak(one_call, sub, CONTINUA[1], 1, errors, crop, inner, timer):.0f}, "
            f"C {peak(option_c, sub, CONTINUA[1], 1, errors, crop, inner, timer):.0f}"
        )
