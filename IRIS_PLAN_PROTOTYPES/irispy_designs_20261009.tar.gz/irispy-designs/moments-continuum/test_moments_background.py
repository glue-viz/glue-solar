import numpy as np
import pytest

import astropy.units as u
from astropy.modeling.models import Gaussian1D
from astropy.nddata import StdDevUncertainty

from irispy.tests.helpers import make_test_spectrogram_cube
from irispy.utils.constants import SATURATION_LIMIT
from irispy.utils.moments import calculate_moments
from irispy.utils.spectrograph import subtract_background

WAVELENGTHS = np.linspace(1401, 1405, 161) * u.AA
WINDOWS = [[1401, 1401.8], [1404, 1405]] * u.AA
WINGS = 0.5 * u.AA


def _line_on_background(degree):
    x = WAVELENGTHS.to_value(u.AA) - 1403
    line = Gaussian1D(amplitude=500, mean=1402.8, stddev=0.08)(WAVELENGTHS.to_value(u.AA))
    return np.tile(line + np.polynomial.polynomial.polyval(x, [30, 4][: degree + 1]), (2, 3, 1))


@pytest.mark.parametrize("degree", [0, 1])
def test_calculate_moments_background_is_subtract_background(degree):
    data = _line_on_background(degree)
    cube = make_test_spectrogram_cube(data, WAVELENGTHS, uncertainty=StdDevUncertainty(np.sqrt(data)))
    kwargs = {"rest_wavelength": 1402.77 * u.AA, "wings": WINGS}
    one = calculate_moments(cube, background=WINDOWS, background_degree=degree, **kwargs)
    two = calculate_moments(subtract_background(cube, WINDOWS, degree=degree), **kwargs)
    for name in two:
        np.testing.assert_allclose(one[name].data, two[name].data, rtol=1e-12, err_msg=name)
        np.testing.assert_allclose(one[name].uncertainty.array, two[name].uncertainty.array, rtol=1e-12, err_msg=name)


def test_calculate_moments_background_keeps_saturation():
    # A line core clipped at the limit, on a background: subtracting it first hides the plateau
    data = np.minimum(_line_on_background(1) * 40, SATURATION_LIMIT.value)
    data[0, 0] /= 40  # unsaturated
    cube = make_test_spectrogram_cube(data, WAVELENGTHS)
    kwargs = {"rest_wavelength": 1402.77 * u.AA, "wings": WINGS, "saturation_limit": SATURATION_LIMIT}
    moments = calculate_moments(cube, background=WINDOWS, **kwargs)
    expected = np.ones((2, 3), dtype=bool)
    expected[0, 0] = False
    np.testing.assert_array_equal(moments["saturated"].data, expected)
    assert np.isnan(moments["intensity"].data[expected]).all()
    assert np.isfinite(moments["intensity"].data[0, 0])
    assert not calculate_moments(subtract_background(cube, WINDOWS), **kwargs)["saturated"].data.any()


def test_calculate_moments_background_too_few_samples_is_nan():
    data = _line_on_background(1)
    mask = np.zeros(data.shape, dtype=bool)
    in_windows = (WAVELENGTHS <= 1401.8 * u.AA) | (WAVELENGTHS >= 1404 * u.AA)
    mask[1, 2, np.flatnonzero(in_windows)[1:]] = True  # one sample left for a straight line
    cube = make_test_spectrogram_cube(data, WAVELENGTHS, mask=mask)
    moments = calculate_moments(cube, rest_wavelength=1402.77 * u.AA, wings=WINGS, background=WINDOWS)
    for name, moment in moments.items():
        assert np.isnan(moment.data[1, 2]), name
        assert moment.mask[1, 2], name
        assert np.isfinite(moment.data[0, 0]), name


def test_calculate_moments_masked_within_wings_is_masked():
    data = _line_on_background(0)
    mask = np.zeros(data.shape, dtype=bool)
    mask[0, 1, (WAVELENGTHS >= 1402.2 * u.AA) & (WAVELENGTHS <= 1403.4 * u.AA)] = True
    cube = make_test_spectrogram_cube(data, WAVELENGTHS, mask=mask)
    moments = calculate_moments(cube, rest_wavelength=1402.77 * u.AA, wings=WINGS)
    for name, moment in moments.items():
        assert moment.mask[0, 1], name
        assert not moment.mask[0, 0], name
