import warnings, numpy as np, astropy.units as u
warnings.simplefilter("ignore")
from bench import Window, DATA, window, CONTINUA, _HAIR
for name in DATA:
    for f in DATA[name]:
        w = Window(f)
        for degree in (1, 0):
            crop, inner = window(w, CONTINUA[degree])
            nan = np.isnan(w.values)
            win = np.zeros(w.shape[-1], bool)
            for lo, hi in CONTINUA[degree]:
                win |= (w.wavelengths >= lo - _HAIR) & (w.wavelengths <= hi + _HAIR)
            in_all = nan[..., inner].all(-1); crop_all = nan[..., crop].all(-1)
            too_few = (~nan[..., win]).sum(-1) <= degree
            print(name, f[-14:-8], degree, "inner all missing", int(in_all.sum()), "of which crop not all missing", int((in_all & ~crop_all).sum()),
                  "too few continuum", int(too_few.sum()), "too few but some inner", int((too_few & ~in_all).sum()), "pixels", in_all.size)
