"""Whole-loop wall time (reads from RAM, sigma, irispy, glue-solar's map assembly, gc) per window, median of 3."""
import sys, time, warnings, numpy as np
warnings.simplefilter("ignore")
from bench import Window, DATA, window, CONTINUA, today, one_call
for name in sys.argv[1:]:
    ws = [Window(f) for f in DATA[name]]
    for degree in (1, 0):
        for errors in (False, True):
            res = {}
            for label, fn in (("today", today), ("A", one_call)):
                ts = []
                for _ in range(3):
                    t0 = time.perf_counter()
                    for w in ws:
                        crop, inner = window(w, CONTINUA[degree])
                        fn(w, CONTINUA[degree], degree, errors, crop, inner, dict.fromkeys(("first call", "subtract_background", "second call", "one call"), 0.0))
                    ts.append(time.perf_counter() - t0)
                res[label] = np.median(ts)
            print(name, "degree", degree, "errors", errors, f"today {res['today']:.3f} s, A {res['A']:.3f} s, saves {res['today'] - res['A']:.3f} s ({1 - res['A'] / res['today']:.0%})")
