import timeit, numpy as np
rng = np.random.default_rng(0)
kept = rng.random((23, 417, 31)) > 0.01
vander = np.polynomial.polynomial.polyvander(np.linspace(-1, 1, 31), 1)
a = lambda: np.einsum("...k,ki,kj->...ij", kept, vander, vander)
b = lambda: np.einsum("...k,ki,kj->...ij", kept, vander, vander, optimize=True)
c = lambda: (kept @ (vander[:, :, None] * vander[:, None, :]).reshape(len(vander), -1)).reshape(*kept.shape[:-1], 2, 2)
assert np.allclose(a(), b()) and np.allclose(a(), c())
for f in (a, b, c): print(min(timeit.repeat(f, number=10, repeat=5)) / 10 * 1e3, "ms per slab")
