import cProfile, pstats, sys, warnings
import numpy as np, astropy.units as u
warnings.simplefilter("ignore")
from bench import Window, DATA, window, read, make_cube, CONTINUA, SLAB
from irispy.utils.spectrograph import subtract_background
w = Window(DATA["4000255147"][0])
crop, inner = window(w, CONTINUA[1])
steps = max(1, SLAB // (w.shape[-2] * (crop.stop - crop.start) * 2))
print("crop", crop, "inner", inner, "steps", steps, "slabs", -(-w.shape[0] // steps))
cubes = []
for start in range(0, w.shape[0], steps):
    rows = (slice(start, start + steps), slice(None))
    values, seconds = read(w, rows, crop)
    cubes.append(make_cube(w, values, rows, crop, w.unit))
for degree in (1, 0):
    pr = cProfile.Profile(); pr.enable()
    for c in cubes: subtract_background(c, CONTINUA[degree] * u.AA, degree=degree)
    pr.disable()
    print("degree", degree); pstats.Stats(pr).sort_stats("tottime").print_stats(8)
