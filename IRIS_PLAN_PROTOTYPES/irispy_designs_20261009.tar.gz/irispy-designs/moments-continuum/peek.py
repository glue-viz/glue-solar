import glob, numpy as np
from irispy.io import read_files
import warnings; warnings.simplefilter("ignore")
for f in sorted(glob.glob("/Users/nabil/DATA/IRIS/2dd2d12db374b3466aa27a65bec235d3-iris_l2_20130902_163935_4000255147_raster/*.fits"))[:1] + sorted(glob.glob("/Users/nabil/DATA/IRIS/saturated/iris_l2_20140329*r0017[2-4]*.fits.gz"))[:1]:
    rc = read_files(f)
    for k in rc.keys():
        c = rc[k][0]
        w = c.axis_world_coords(c.wavelength_axis)[0].to("AA")
        print(f.split('/')[-1][:40], k, c.data.shape, len(rc[k]), c.data.dtype, f"{w[0]:.2f} {w[-1]:.2f}", int((c.data>=16182).sum()), c.meta.get("exposure time")[:3], c.unit)
