"""Option B: a public saturation check on the raw slab (emulated with irispy's _saturation_limit), then
subtract_background and one calculate_moments, as today's second call. Wall time of the irispy part, median of 3."""
import gc, sys, time, warnings, numpy as np, astropy.units as u
warnings.simplefilter("ignore")
from irispy.utils.constants import SATURATION_LIMIT
from irispy.utils.moments import calculate_moments, _saturation_limit
from irispy.utils.spectrograph import subtract_background
from bench import Window, DATA, window, CONTINUA, SLAB, CENTRE, WINGS, read, sigma_of, make_cube, collect, today, same

def option_b(w, continuum, degree, errors, crop, inner, timer):
    maps, saturated = {}, 0
    steps = max(1, SLAB // (w.shape[-2] * (crop.stop - crop.start) * 2))
    inside = slice(inner.start - crop.start, inner.stop - crop.start)
    for start in range(0, w.shape[0], steps):
        rows = (slice(start, start + steps), slice(None))
        values, seconds = read(w, rows, crop)
        sigma = sigma_of(values[..., inside], w.unit, seconds) if errors else None
        t0 = time.perf_counter()
        cube = make_cube(w, values, rows, crop, w.unit, seconds)
        raw = values[..., inside]  # what a public find_saturated(cube, limit, wings=) would do
        reached = np.any((raw >= _saturation_limit(cube, SATURATION_LIMIT)) & ~cube.mask[..., inside], axis=-1)
        values = subtract_background(cube, continuum * u.AA, degree=degree).data
        slab = calculate_moments(make_cube(w, values[..., inside], rows, inner, w.unit, sigma=sigma),
                                 rest_wavelength=CENTRE * u.AA, wings=WINGS * u.AA)
        timer["B"] += time.perf_counter() - t0
        saturated += int(reached.sum())
        collect(maps, slab, reached, errors)
        gc.collect(0)
    return {k: np.concatenate(v) for k, v in maps.items()}, saturated

for name in sys.argv[1:]:
    ws = [Window(f) for f in DATA[name]]
    for degree in (1, 0):
        ts = []
        for _ in range(3):
            timer = {"B": 0.0}
            out = [option_b(w, CONTINUA[degree], degree, False, *window(w, CONTINUA[degree]), timer) for w in ws]
            ts.append(timer["B"])
        t = dict.fromkeys(("first call", "subtract_background", "second call"), 0.0)
        base = [today(w, CONTINUA[degree], degree, False, *window(w, CONTINUA[degree]), t) for w in ws]
        eq = [same(a[0], b[0]) for a, b in zip(base, out)], [(a[1], b[1]) for a, b in zip(base, out)]
        print(name, "degree", degree, f"B {np.median(ts):.3f} s", eq)
