import difflib, option_a
for path, new in (("irispy/utils/spectrograph.py", option_a.SPECTROGRAPH), ("irispy/utils/moments.py", option_a.moments_text().replace("from option_a import spectrograph as _sg\n_fit_background = _sg._fit_background\n", "from irispy.utils.spectrograph import _fit_background\n"))):
    old = (option_a.ROOT.parent.parent / path).read_text()
    print("".join(difflib.unified_diff(old.splitlines(True), new.splitlines(True), "a/" + path, "b/" + path, n=1)))
