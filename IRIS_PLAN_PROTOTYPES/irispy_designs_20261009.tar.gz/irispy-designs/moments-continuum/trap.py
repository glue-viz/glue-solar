"""How many saturated pixels the naive one-line path finds: calculate_moments(subtract_background(cube), saturation_limit=)."""
import warnings, numpy as np, astropy.units as u
warnings.simplefilter("ignore")
from irispy.utils.constants import SATURATION_LIMIT
from irispy.utils.moments import calculate_moments
from irispy.utils.spectrograph import subtract_background
from bench import Window, DATA, window, CONTINUA, CENTRE, WINGS, read, make_cube
for degree in (1, 0):
    raw = naive = 0
    for f in DATA["3860258481"]:
        w = Window(f); crop, inner = window(w, CONTINUA[degree])
        rows = (slice(None), slice(None)); values, seconds = read(w, rows, crop)
        cube = make_cube(w, values, rows, crop, w.unit, seconds)
        kw = dict(rest_wavelength=CENTRE * u.AA, wings=WINGS * u.AA, saturation_limit=SATURATION_LIMIT)
        raw += int(calculate_moments(cube, **kw)["saturated"].data.sum())
        naive += int(calculate_moments(subtract_background(cube, CONTINUA[degree] * u.AA, degree=degree), **kw)["saturated"].data.sum())
    print("degree", degree, "raw", raw, "after subtract_background", naive)
