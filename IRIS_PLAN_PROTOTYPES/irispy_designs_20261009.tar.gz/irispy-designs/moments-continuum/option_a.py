"""
Option A prototype: irispy main's moments.py and utils/spectrograph.py, patched by text so the diff is exact.

calculate_moments(..., background=None, background_degree=1): fits subtract_background's polynomial to the windows of
each spectrum, checks saturation on the raw samples within the wings, then takes the moments of the samples less the
background; pixels with no background are NaN in every map, as saturated ones are.
"""

import types
from pathlib import Path

ROOT = Path("/Users/nabil/Git/irispy-designs/irispy/utils")


def _patch(text, pairs):
    for old, new in pairs:
        assert text.count(old) == 1, old
        text = text.replace(old, new)
    return text


def _module(name, text):
    module = types.ModuleType(name)
    module.__file__ = name + ".py"
    exec(compile(text, module.__file__, "exec"), module.__dict__)
    return module


SPECTROGRAPH = _patch(
    (ROOT / "spectrograph.py").read_text(),
    [
        (
            """    check_scaled(cube)
    wavelength_axis = cube.wavelength_axis
    wavelengths = cube.axis_world_coords(wavelength_axis)[0]
    index = np.flatnonzero(in_windows(wavelengths, windows))""",
            """    check_scaled(cube)
    background = _fit_background(cube, windows, degree)
    return cube - u.Quantity(background, cube.unit)


def _fit_background(cube, windows, degree):
    \"\"\"
    `subtract_background`'s background of ``cube``, an array of its shape, NaN for spectra with too few samples.
    \"\"\"
    wavelength_axis = cube.wavelength_axis
    wavelengths = cube.axis_world_coords(wavelength_axis)[0]
    index = np.flatnonzero(in_windows(wavelengths, windows))""",
        ),
        (
            "    return cube - u.Quantity(np.moveaxis(background, -1, wavelength_axis), cube.unit)",
            "    return np.moveaxis(background, -1, wavelength_axis)",
        ),
    ],
)

spectrograph = _module("option_a_spectrograph", SPECTROGRAPH)


def moments_text(crop_mask=True):
    pairs = [
        (
            "from irispy.utils.constants import DN_UNIT\n",
            "from irispy.utils.constants import DN_UNIT\nfrom option_a import spectrograph as _sg\n_fit_background = _sg._fit_background\n",
        ),
        (
            "    cube, *, rest_wavelength=None, wings=None, integrated=False, min_intensity=None, saturation_limit=None\n):",
            "    cube,\n    *,\n    rest_wavelength=None,\n    wings=None,\n    integrated=False,\n    min_intensity=None,\n"
            "    saturation_limit=None,\n    background=None,\n    background_degree=1,\n):",
        ),
        (
            "    sigma = standard_deviation(cube)\n    if wings is not None:",
            "    sigma = standard_deviation(cube)\n"
            "    # Fitted to the whole spectrum, as its windows may lie outside the wings\n"
            "    fitted = None if background is None else _fit_background(cube, background, background_degree)\n"
            "    if wings is not None:",
        ),
        (
            "        if sigma is not None:\n            sigma = sigma[tuple(slicer)]\n",
            "        if sigma is not None:\n            sigma = sigma[tuple(slicer)]\n"
            "        if fitted is not None:\n            fitted = fitted[tuple(slicer)]\n",
        ),
        (
            "        saturated = np.any(reached, axis=wavelength_axis)\n",
            "        saturated = np.any(reached, axis=wavelength_axis)\n"
            "    blank = np.zeros(np.delete(data.shape, wavelength_axis), dtype=bool)\n"
            "    if saturation_limit is not None:\n        blank |= saturated\n"
            "    if fitted is not None:  # after the saturation check, on the samples as observed\n"
            "        data -= fitted\n"
            "        blank |= np.isnan(fitted).any(axis=wavelength_axis)\n",
        ),
        (
            "    if saturation_limit is not None:\n        intensity_value = np.where(saturated, np.nan, intensity_value)\n"
            "        centroid_value = np.where(saturated, np.nan, centroid_value)\n"
            "        stddev_value = np.where(saturated, np.nan, stddev_value)\n",
            "    if blank.any():\n        intensity_value = np.where(blank, np.nan, intensity_value)\n"
            "        centroid_value = np.where(blank, np.nan, centroid_value)\n"
            "        stddev_value = np.where(blank, np.nan, stddev_value)\n",
        ),
    ]
    if crop_mask:  # the maps masked where every sample within the wings is, not every sample of the cube
        pairs.append(
            (
                "        return make_map_cube(template, values, unit, mask_invalid=True, uncertainty=uncertainty)\n\n    cubes",
                "        return make_map_cube(template, values, unit, mask=all_masked, mask_invalid=True, uncertainty=uncertainty)\n\n"
                "    all_masked = None if mask is None else np.broadcast_to(mask, data.shape).all(axis=wavelength_axis)\n    cubes",
            )
        )
    return _patch((ROOT / "moments.py").read_text(), pairs)


moments = _module("option_a_moments", moments_text())
moments_no_crop_mask = _module("option_a_moments_ncm", moments_text(crop_mask=False))
calculate_moments = moments.calculate_moments
subtract_background = spectrograph.subtract_background
