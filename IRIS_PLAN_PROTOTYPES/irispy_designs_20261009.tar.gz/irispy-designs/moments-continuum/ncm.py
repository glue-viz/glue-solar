import warnings, numpy as np
warnings.simplefilter("ignore")
import option_a
from bench import Window, DATA, window, CONTINUA, today, one_call, same
for name in DATA:
    w = Window(DATA[name][0])
    crop, inner = window(w, CONTINUA[1])
    t = dict.fromkeys(("first call", "subtract_background", "second call", "one call"), 0.0)
    base = today(w, CONTINUA[1], 1, True, crop, inner, t)
    for mod in (option_a.moments_no_crop_mask, option_a.moments):
        print(name, mod.__name__, same(base[0], one_call(w, CONTINUA[1], 1, True, crop, inner, t, module=mod)[0]))
