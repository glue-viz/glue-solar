import time, warnings, numpy as np, astropy.units as u
warnings.simplefilter("ignore")
from bench import Window, DATA, window, read, make_cube, CONTINUA, SLAB
import option_a
w = Window(DATA["4000255147"][0])
crop, inner = window(w, CONTINUA[1])
steps = max(1, SLAB // (w.shape[-2] * (crop.stop - crop.start) * 2))
cubes = [make_cube(w, read(w, (slice(s, s + steps), slice(None)), crop)[0], (slice(s, s + steps), slice(None)), crop, w.unit) for s in range(0, w.shape[0], steps)]
fit = option_a.spectrograph._fit_background
src = option_a.SPECTROGRAPH.replace('vander[index])\n', 'vander[index], optimize=True)\n')
assert src.count("optimize=True") == 2
opt = option_a._module("opt", src)._fit_background
for degree in (1, 0):
    for label, f in (("main", fit), ("optimize=True", opt)):
        ts = []
        for _ in range(3):
            t = time.perf_counter(); out = [f(c, CONTINUA[degree] * u.AA, degree) for c in cubes]; ts.append(time.perf_counter() - t)
        print(degree, label, f"{min(ts):.3f} s")
    a = [fit(c, CONTINUA[degree] * u.AA, degree) for c in cubes]; b = [opt(c, CONTINUA[degree] * u.AA, degree) for c in cubes]
    print("   max |diff| DN/s", max(float(np.nanmax(np.abs(x - y))) for x, y in zip(a, b)), "equal", all(np.array_equal(x, y, equal_nan=True) for x, y in zip(a, b)))
