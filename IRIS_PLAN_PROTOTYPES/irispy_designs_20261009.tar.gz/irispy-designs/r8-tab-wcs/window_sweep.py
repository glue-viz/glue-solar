import time, warnings
import numpy as np
import fast_inverse as fi
from verify import FILES, si_iv
from irispy.io.spectrograph import read_spectrograph_lvl2
warnings.simplefilter("ignore")
for name, f in FILES.items():
    key, cube = si_iv(read_spectrograph_lvl2(f, memmap=True))
    coord = np.asarray(cube.wcs.wcs.tab[0].coord); a, b = coord[:, 0], coord[:, 1]
    lat0, lat1 = coord[..., 0].min() - 2 / 3600, coord[..., 0].max() + 2 / 3600
    lon0, lon1 = coord[..., 1].min() - 2 / 3600, coord[..., 1].max() + 2 / 3600
    lat, lon = np.meshgrid(np.arange(lat0, lat1, 0.1663 / 3600), np.arange(lon0, lon1, 0.1663 / 3600), indexing="ij")
    lat, lon = lat.ravel()[:200000], lon.ravel()[:200000]
    ref = None
    for w in (4, 8, 16, 64):
        orig = fi._scan; calls = []
        def counting(a_, b_, x_, cells, _o=orig):
            calls.append(0 if cells is not None else len(x_)); return _o(a_, b_, x_, cells)
        fi._scan = counting
        t = time.perf_counter(); st, u = fi._invert(a, b, lat, lon, window=w); dt = time.perf_counter() - t
        fi._scan = orig
        ref = st if ref is None else ref
        print(f"{name:26s} W={w:3d}: {dt / lat.size * 1e6:.2f} us/pt, fallback pts {sum(calls)}, same as W=4: {np.array_equal(np.isnan(st), np.isnan(ref)) and np.nanmax(np.abs(st - ref)) < 1e-9}")
