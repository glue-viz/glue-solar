"""Option A: does the WCS subclass survive what irispy, ndcube and glue-solar do with a raster WCS?"""
import copy, pickle, time, warnings
import numpy as np
import astropy.units as u
from astropy.coordinates import SkyCoord
from astropy.wcs import WCS
import fast_inverse
import irispy.io.spectrograph as sg
from verify import FILES
warnings.simplefilter("ignore")

sg.WCS = fast_inverse.RasterWCS  # what irispy's _create_tabular_wcs would construct
f = FILES["4000255147 sit-and-stare"]
cube = sg.read_spectrograph_lvl2(f, spectral_windows="Si IV 1403", memmap=True)["Si IV 1403"][0]
w = cube.wcs
print("type", type(w).__name__, "isinstance WCS", isinstance(w, WCS))
print("deepcopy", type(copy.deepcopy(w)).__name__, "copy", type(copy.copy(w)).__name__)
try:
    print("pickle", type(pickle.loads(pickle.dumps(w))).__name__)
except Exception as e:
    print("pickle fails:", type(e).__name__, str(e)[:100])
print("celestial", type(w.celestial).__name__, "layout", w.celestial._raster_layout())
print("to_header same as plain", w.to_header() == WCS.to_header(w))

# ndcube slicing: SlicedLowLevelWCS forwards to the subclass
sub = cube[100:300, 50:350]
p = (np.array([3.0, 10.0]), np.array([20.0, 100.0]), np.array([5.0, 150.2]))
world = sub.wcs.low_level_wcs.pixel_to_world_values(*p)
t = time.perf_counter(); back = sub.wcs.low_level_wcs.world_to_pixel_values(*world); dt = time.perf_counter() - t
print("sliced round trip", np.round(np.asarray(back), 6).tolist(), f"{dt * 1e3:.2f} ms")

# ndcube crop by sky on the sit-and-stare: which exposures does it keep?
lo = cube.wcs.pixel_to_world(0, 150, 700); hi = cube.wcs.pixel_to_world(0, 250, 900)
for label, wcs in (("numpy", cube.wcs), ("wcslib", WCS.__new__(WCS))):
    pass
t = time.perf_counter(); cropped = cube.crop(lo, hi); dt = time.perf_counter() - t
print("crop", cube.shape, "->", cropped.shape, f"{dt:.3f} s")
plain = cube.wcs.deepcopy(); plain.__class__ = WCS
from irispy.spectrograph import SpectrogramCube
c2 = SpectrogramCube(cube.data, plain, meta=cube.meta)
t = time.perf_counter(); cropped2 = c2.crop(lo, hi); dt = time.perf_counter() - t
print("crop wcslib", c2.shape, "->", cropped2.shape, f"{dt:.3f} s")
