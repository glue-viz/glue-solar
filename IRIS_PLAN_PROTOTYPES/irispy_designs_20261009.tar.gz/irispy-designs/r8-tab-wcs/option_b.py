"""
Option B prototype: a separable sit-and-stare WCS. The slit sits at one pointing (the
middle exposure's), the exposure axis is time only (a 1-D TIME-TAB), and the across-slit
direction is a dropped length-1 pixel axis, so the cube has 3 pixel and 4 world axes.
"""
import time
import warnings

import numpy as np

from astropy.io import fits
from astropy.wcs import WCS
from astropy.wcs.wcsapi import SlicedLowLevelWCS

from irispy.io.spectrograph import read_spectrograph_lvl2
from verify import FILES

warnings.simplefilter("ignore")
f = FILES["4000255147 sit-and-stare"]
cube = read_spectrograph_lvl2(f, spectral_windows="Si IV 1403", memmap=True)["Si IV 1403"][0]
tabwcs = cube.wcs
with fits.open(f) as h:
    win = next(i for i in range(1, len(h) - 2) if h[0].header[f"TDESC{i}"] == "Si IV 1403")
    hdr = h[win].header.copy()
    aux, auxh = h[-2].data.copy(), h[-2].header
    seconds = aux[:, auxh["TIME"]] + aux[:, auxh["EXPTIMEF"]] / 2
n = hdr["NAXIS3"]
mid = n // 2
xcen = aux[mid, auxh["XCENIX"]]
ycen = aux[mid, auxh["YCENIX"]]

h4 = fits.Header()
h4["WCSAXES"] = 4
for k in ("CTYPE1", "CUNIT1", "CRPIX1", "CRVAL1", "CDELT1"):
    h4[k] = hdr[k]
h4.update(CTYPE2="HPLT-TAN", CUNIT2="arcsec", CRPIX2=hdr["CRPIX2"], CRVAL2=ycen, CDELT2=hdr["CDELT2"])
h4.update(CTYPE4="HPLN-TAN", CUNIT4="arcsec", CRPIX4=1, CRVAL4=xcen, CDELT4=hdr["CDELT2"])
h4.update(PC2_2=hdr["PC2_2"], PC2_4=hdr["PC2_3"], PC4_2=hdr["PC3_2"], PC4_4=hdr["PC3_3"])
h4.update(CTYPE3="TIME-TAB", CUNIT3="s", CRPIX3=1, CRVAL3=1, CDELT3=1, PS3_0="WCS-TIME", PS3_1="TIME")
h4.update(DATEREF=hdr.get("DATE_OBS", cube.meta["STARTOBS"]), TIMESYS="UTC", MJDREF=0.0)
h4["DATE-OBS"] = hdr.get("DATE_OBS")
h4["DATEREF"] = cube.meta["STARTOBS"]
table = fits.BinTableHDU(np.array([(seconds[:, None],)], dtype=[("TIME", float, (n, 1))]), name="WCS-TIME")
w4 = WCS(h4, fits.HDUList([fits.PrimaryHDU(), table]))
w4.pixel_shape = (hdr["NAXIS1"], hdr["NAXIS2"], n, 1)
sep = SlicedLowLevelWCS(w4, [0, slice(None), slice(None), slice(None)])  # numpy order: drop the across axis
print("world axes", sep.world_axis_physical_types, "pixel", sep.pixel_n_dim)

rng = np.random.default_rng(0)
m = 2000
p = [rng.uniform(0, hdr["NAXIS1"] - 1, m), rng.uniform(0, hdr["NAXIS2"] - 1, m), rng.uniform(0, n - 1, m)]
t = time.perf_counter(); w = sep.pixel_to_world_values(*p); tf = (time.perf_counter() - t) / m
t = time.perf_counter(); q = sep.world_to_pixel_values(*w); ti = (time.perf_counter() - t) / m
err = np.abs(np.asarray(q) - np.asarray(p))
print(f"forward {tf * 1e6:.2f} us/pt, inverse {ti * 1e6:.2f} us/pt, round trip max step {err[2].max():.2g} px, slit {err[1].max():.2g} px")
# pointing lost against the -TAB WCS (the per-exposure truth)
truth = tabwcs.pixel_to_world_values(*p)
order = list(sep.world_axis_physical_types)
lat = w[order.index("custom:pos.helioprojective.lat")]
lon = w[order.index("custom:pos.helioprojective.lon")]
dlon, dlat = (lon - truth[2]) * 3600, (lat - truth[1]) * 3600
print(f"pointing vs -TAB: |dlon| max {np.abs(dlon).max():.2f} arcsec, |dlat| max {np.abs(dlat).max():.2f} arcsec, rms {np.hypot(dlon, dlat).std():.2f}")
