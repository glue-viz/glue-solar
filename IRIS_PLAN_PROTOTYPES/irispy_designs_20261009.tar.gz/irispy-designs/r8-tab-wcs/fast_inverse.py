"""
Option A prototype: irispy's raster -TAB WCS with an exact numpy inverse.

The forward transform and the header stay wcslib's. Only world_to_pixel_values is
replaced, for irispy's own table layout (WAVE, HPLT-TAB, HPLN-TAB; one table of
2 slit ends x N steps, identity PC). Like wcslib's tabs2x it returns the first
step cell (lowest step) whose bilinear patch contains the point, NaN outside.
"""

import numpy as np

from astropy.wcs import WCS

_TOL = 1e-9  # cell edges, in cell fractions
_CHUNK = 2_000_000  # points x steps per pass, about 16 MB per float64 temporary


class RasterWCS(WCS):
    def _raster_layout(self):
        w = self.wcs
        if (
            self.naxis != 3
            or list(w.ctype) != ["WAVE", "HPLT-TAB", "HPLN-TAB"]
            or len(w.tab) != 1
            or list(w.tab[0].K)[0] != 2
            or list(w.tab[0].K)[1] < 2  # one exposure: no cells, wcslib's degenerate table
            or list(w.tab[0].map) != [1, 2]
            or not np.array_equal(w.get_pc(), np.eye(3))
        ):
            return None
        coord = np.asarray(w.tab[0].coord)  # (step, slit end, (lat, lon)) in deg
        return coord[:, 0], coord[:, 1]

    def world_to_pixel_values(self, *world_arrays):
        layout = self._raster_layout()
        if layout is None:
            return super().world_to_pixel_values(*world_arrays)
        a, b = layout
        wave, lat, lon = np.broadcast_arrays(*(np.asarray(x, float) for x in world_arrays))
        w = self.wcs
        spectral = (wave - w.crval[0]) / w.cdelt[0] + w.crpix[0] - 1
        step, u = _invert(a, b, lat.ravel(), lon.ravel())
        # table step k + f is the FITS index k + f + 1 = CRVAL3 + CDELT3 (p + 1 - CRPIX3), as the step has no index vector
        step = (step + 1 - w.crval[2]) / w.cdelt[2] + w.crpix[2] - 1
        # the slit's index vector is not exposed: the slit pixel is affine in u, so take two from wcslib's forward
        p0 = (w.crval[2] - 1) / w.cdelt[2] + w.crpix[2] - 1  # pixel of the first table step
        ends = np.asarray(super().pixel_to_world_values([0, 0], [0, 1], [p0, p0]))[1:].T
        u01 = (ends - a[0]) @ (b[0] - a[0]) / np.dot(b[0] - a[0], b[0] - a[0])
        slit = (u - u01[0]) / (u01[1] - u01[0])
        return spectral, slit.reshape(lat.shape), step.reshape(lat.shape)


def _cross(d, x):
    return d[..., 0] * x[..., 1] - d[..., 1] * x[..., 0]


def _invert(a, b, lat, lon, window=8):
    """
    Fractional step and slit fraction u of each point, NaN where no cell holds it.

    Each step's slit is nearly parallel to the mean slit, so the offset s_k of step k's
    slit along the mean normal tells, outside a band of half-width eps, which side of
    that slit a point lies on. Before the first step whose offset comes within eps of
    the point's, every exact side is the same, so no cell there can hold it: the exact
    search starts there (O(log N)) and looks at `window` cells, then at every cell for
    the few points left.
    """
    n = len(a)
    d = b - a
    normal = np.stack((-d[:, 1], d[:, 0]), axis=-1) / np.hypot(d[:, 0], d[:, 1])[:, None]
    mean = normal.mean(axis=0)
    mean /= np.hypot(*mean)
    s = a @ mean
    x = np.stack((lat, lon), axis=-1)
    h = x @ mean
    # |(normal_k - mean) . (x - a_k)| <= max|normal_k - mean| * (|x - a_0| + max|a_k - a_0|)
    reach = np.hypot(*(x - a[0]).T) + np.hypot(*(a - a[0]).T).max()
    eps = 2 * np.hypot(*(normal - mean).T).max() * reach + 1e-15
    up = np.searchsorted(np.maximum.accumulate(s), h - eps)
    down = np.searchsorted(-np.minimum.accumulate(s), -(h + eps))
    k0 = np.where(s[0] < h - eps, up, np.where(s[0] > h + eps, down, 0))
    step = np.full(len(x), np.nan)
    u = np.full(len(x), np.nan)
    live = np.flatnonzero(k0 < n)
    first = np.minimum(np.maximum(k0[live] - 1, 0), max(n - 1 - window, 0))
    cells = first[:, None] + np.arange(min(window, n - 1))  # (P, W)
    step[live], u[live] = _scan(a, b, x[live], cells)
    left = live[np.isnan(step[live]) & (first + window < n - 1)]
    if left.size:
        step[left], u[left] = _scan(a, b, x[left], None)
    return step, u


def _scan(a, b, x, cells):
    """First cell of `cells` (P, W), or of all cells, holding each point."""
    step = np.full(len(x), np.nan)
    u_out = np.full(len(x), np.nan)
    width = len(a) - 1 if cells is None else cells.shape[1]
    chunk = max(1, _CHUNK // (width + 1))
    for start in range(0, len(x), chunk):
        xs = x[start : start + chunk, None, :]
        if cells is None:
            k_all = np.arange(width + 1)
        else:
            k_all = np.concatenate((cells, cells[:, -1:] + 1), axis=1)[start : start + chunk]
        d, r = b[k_all] - a[k_all], xs - a[k_all]
        g = _cross(d, r)  # which side of each step's slit line
        # on the line, to rounding: wcslib finds points on the first and last step too
        on = np.abs(g) <= 1e-12 * np.hypot(d[..., 0], d[..., 1]) * (np.hypot(r[..., 0], r[..., 1]) + 1e-300)
        sides = np.signbit(g)
        candidates = (sides[:, :-1] != sides[:, 1:]) | on[:, :-1] | on[:, 1:]
        found = np.full(len(xs), np.nan)
        found_u = np.full(len(xs), np.nan)
        todo = candidates.any(axis=1)
        while todo.any():
            p = np.flatnonzero(todo)
            j = candidates[p].argmax(axis=1)  # first candidate cell
            k = j if cells is None else cells[start + p, j]
            f, uu = _solve_cell(a[k], b[k], a[k + 1], b[k + 1], xs[p, 0])
            ok = (f >= -_TOL) & (f <= 1 + _TOL) & (uu >= -_TOL) & (uu <= 1 + _TOL)
            found[p[ok]], found_u[p[ok]] = k[ok] + np.clip(f[ok], 0, 1), np.clip(uu[ok], 0, 1)
            candidates[p[~ok], j[~ok]] = False
            todo[p[ok]] = False
            todo[p[~ok]] = candidates[p[~ok]].any(axis=1)
        step[start : start + chunk], u_out[start : start + chunk] = found, found_u
    return step, u_out


def _solve_cell(a0, b0, a1, b1, x):
    """Exact inverse of the bilinear patch (1-f)[(1-u)a0 + u b0] + f[(1-u)a1 + u b1] = x."""
    # cross(D(f), x - A(f)) = 0 is quadratic in f, with D(f) = d0 + f dd and A(f) = a0 + f da
    d0, dd, da = b0 - a0, (b1 - a1) - (b0 - a0), a1 - a0
    r0 = x - a0
    qa = -_cross(dd, da)
    qb = _cross(dd, r0) - _cross(d0, da)
    qc = _cross(d0, r0)
    with np.errstate(divide="ignore", invalid="ignore"):
        disc = np.sqrt(np.maximum(qb * qb - 4 * qa * qc, 0))
        # the stable root nearest the linear solution -qc/qb
        q = -0.5 * (qb + np.copysign(disc, qb))
        f1, f2 = q / qa, qc / q
        linear = np.abs(qa) <= 1e-12 * np.abs(qb)
        f = np.where(linear, -qc / qb, np.where((f2 >= -1e-9) & (f2 <= 1 + 1e-9), f2, f1))
        dirn = d0 + f[:, None] * dd
        u = np.einsum("ij,ij->i", x - (a0 + f[:, None] * da), dirn) / np.einsum("ij,ij->i", dirn, dirn)
    return f, u
