"""Inverting the raster WCS at every screen pixel of a quicklook SJI panel (484 x 252), as glue's linked ROI mask does."""
import time, warnings
import numpy as np
from fast_inverse import RasterWCS
from verify import FILES, si_iv
from irispy.io.spectrograph import read_spectrograph_lvl2
from irispy.io.sji import read_sji_lvl2
warnings.simplefilter("ignore")
sji = read_sji_lvl2("/Users/nabil/DATA/IRIS/534d789bb0a2821fb2b78eb36d1d6753-iris_l2_20130902_163935_4000255147_SJI_1400_t000.fits.gz")
key, cube = si_iv(read_spectrograph_lvl2(FILES["4000255147 sit-and-stare"], memmap=True))
frame = sji.shape[0] // 2
ny, nx = sji.shape[1:]
y, x = np.meshgrid(np.linspace(0, ny - 1, 252), np.linspace(0, nx - 1, 484), indexing="ij")
world = sji.wcs.low_level_wcs.pixel_to_world_values(x.ravel(), y.ravel(), np.full(x.size, frame))
types = list(sji.wcs.low_level_wcs.world_axis_physical_types)
lon = world[types.index("custom:pos.helioprojective.lon")]
lat = world[types.index("custom:pos.helioprojective.lat")]
print("sji", sji.shape, "world units", sji.wcs.low_level_wcs.world_axis_units)
scale = 1 / 3600 if sji.wcs.low_level_wcs.world_axis_units[types.index("custom:pos.helioprojective.lon")] == "arcsec" else 1
lon, lat = lon * scale, lat * scale
wave = np.full(lon.shape, cube.wcs.pixel_to_world_values(0, 0, 0)[0])
new = cube.wcs.deepcopy(); new.__class__ = RasterWCS
t = time.perf_counter(); qn = new.world_to_pixel_values(wave, lat, lon); tn = time.perf_counter() - t
t = time.perf_counter(); qo = cube.wcs.world_to_pixel_values(wave, lat, lon); to = time.perf_counter() - t
inside = np.isfinite(qo[2])
print(f"{lon.size} screen pixels, {inside.sum()} inside the raster: wcslib {to:.2f} s, numpy {tn * 1e3:.1f} ms;"
      f" same NaN {np.array_equal(np.isnan(qo[2]), np.isnan(qn[2]))}, step max diff {np.nanmax(np.abs(qn[2] - qo[2])):.3g}")
