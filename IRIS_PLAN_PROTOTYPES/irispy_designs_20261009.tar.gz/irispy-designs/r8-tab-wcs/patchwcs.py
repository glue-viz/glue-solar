"""pytest plugin: irispy's raster reader builds the Option A RasterWCS."""
import fast_inverse
import irispy.io.spectrograph as sg

sg.WCS = fast_inverse.RasterWCS
