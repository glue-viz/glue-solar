"""Option A on irispy main: cost and agreement of the numpy inverse with wcslib's."""

import sys
import time
import warnings

import numpy as np

from fast_inverse import RasterWCS
from verify import FILES, si_iv

from irispy.io.spectrograph import read_spectrograph_lvl2

warnings.simplefilter("ignore")


def timed(fn, *args):
    t = time.perf_counter()
    out = fn(*args)
    return out, time.perf_counter() - t


def main(n_random=300, n_grid_wcslib=3000):
    rng = np.random.default_rng(1)
    for name, f in FILES.items():
        key, cube = si_iv(read_spectrograph_lvl2(f, memmap=True))
        old = cube.wcs
        new = old.deepcopy()
        new.__class__ = RasterWCS  # prototype: irispy would construct RasterWCS directly
        shape = cube.data.shape
        print(f"\n== {name} [{key}] {shape}")

        # 1. random raster pixels: pixel -> world -> pixel
        p = [rng.uniform(0, shape[2] - 1, n_random), rng.uniform(0, shape[1] - 1, n_random),
             rng.uniform(0, shape[0] - 1, n_random)]
        w, tf = timed(old.pixel_to_world_values, *p)
        q_old, t_old = timed(old.world_to_pixel_values, *w)
        q_new, t_new = timed(new.world_to_pixel_values, *w)
        for label, q, t in (("wcslib", q_old, t_old), ("numpy ", q_new, t_new)):
            e = np.abs(np.asarray(q) - np.asarray(p))
            back = np.asarray(old.pixel_to_world_values(*q))
            werr = np.nanmax(np.abs(back[1:] - np.asarray(w)[1:])) * 3600
            print(f"   random {label}: {t / n_random * 1e6:9.2f} us/pt  step err max {np.nanmax(e[2]):.3g} px"
                  f" >0.01px {np.mean(e[2] > 0.01) * 100:.0f}%  slit err max {np.nanmax(e[1]):.2g}"
                  f"  world round trip max {werr:.2g} arcsec  NaN {np.isnan(q[2]).sum()}")
        dq = np.abs(np.asarray(q_new) - np.asarray(q_old))
        print(f"   numpy vs wcslib: step max {np.nanmax(dq[2]):.3g}, slit max {np.nanmax(dq[1]):.3g}")
        print(f"   forward {tf / n_random * 1e6:.2f} us/pt")

        # 2. an SJI-like grid (0.1663 arcsec) over the footprint's bounding box plus 2 arcsec
        coord = np.asarray(old.wcs.tab[0].coord)
        lat0, lat1 = coord[..., 0].min() - 2 / 3600, coord[..., 0].max() + 2 / 3600
        lon0, lon1 = coord[..., 1].min() - 2 / 3600, coord[..., 1].max() + 2 / 3600
        step = 0.1663 / 3600
        lat, lon = np.meshgrid(np.arange(lat0, lat1, step), np.arange(lon0, lon1, step), indexing="ij")
        lat, lon = lat.ravel(), lon.ravel()
        wave = np.full(lat.shape, w[0][0])
        q_new, t_new = timed(new.world_to_pixel_values, wave, lat, lon)
        inside = np.isfinite(q_new[2])
        sub = rng.choice(lat.size, min(n_grid_wcslib, lat.size), replace=False)
        q_old, t_old = timed(old.world_to_pixel_values, wave[sub], lat[sub], lon[sub])
        same_nan = np.array_equal(np.isnan(q_old[2]), np.isnan(q_new[2][sub]))
        dq = np.abs(np.asarray(q_new)[:, sub] - np.asarray(q_old))
        print(f"   grid {lat.size} pts ({inside.mean() * 100:.0f}% inside): numpy {t_new:.3f} s = "
              f"{t_new / lat.size * 1e6:.2f} us/pt; wcslib on {len(sub)}: {t_old / len(sub) * 1e6:.1f} us/pt"
              f" -> {t_old / len(sub) * lat.size:.1f} s for the grid")
        print(f"   grid numpy vs wcslib: same NaN {same_nan}, step max {np.nanmax(dq[2]):.3g},"
              f" slit max {np.nanmax(dq[1]):.3g}, step >0.01px {np.nanmean(dq[2] > 0.01) * 100:.2f}%")


if __name__ == "__main__":
    main(*(int(a) for a in sys.argv[1:]))
