"""The regression tests Option A's irispy PR would add, run against the prototype."""
import numpy as np
import pytest

from astropy.io import fits
from astropy.wcs import WCS

import fast_inverse
import irispy.io.spectrograph as sg

SNS = "/Users/nabil/Git/irispy-designs/irispy/data/test/sns/iris_l2_20210905_001833_3620258102_raster_t000_r00000_test.fits"


@pytest.fixture(autouse=True)
def raster_wcs(monkeypatch):
    monkeypatch.setattr(sg, "WCS", fast_inverse.RasterWCS)


def _sit_and_stare_wcs():
    """The sns file's first window with a real sit-and-stare's pointing: 0.05 arcsec jumps every 6 exposures, 1 mas jitter."""
    with fits.open(SNS) as hdulist:
        header, aux = hdulist[1].header.copy(), hdulist[-2].copy()
    n = len(aux.data)
    rng = np.random.default_rng(0)
    x = aux.data[:, aux.header["XCENIX"]]
    aux.data[:, aux.header["XCENIX"]] = x[0] + 0.05 * (np.arange(n) // 6) + rng.uniform(-1e-3, 1e-3, n)
    return sg._create_tabular_wcs(header, aux, date_obs="2021-09-05T00:18:33")


def test_raster_inverse_matches_wcslib():
    wcs = _sit_and_stare_wcs()
    assert type(wcs) is fast_inverse.RasterWCS
    rng = np.random.default_rng(1)
    shape = wcs.pixel_shape
    pixel = [rng.uniform(-0.2, n - 0.8, 500) for n in shape]  # a few past the table's ends
    world = wcs.pixel_to_world_values(*pixel)
    world = (world[0], world[1] + rng.normal(0, 2e-6, 500), world[2] + rng.normal(0, 2e-6, 500))  # some off the slit
    fast = np.asarray(wcs.world_to_pixel_values(*world))
    slow = np.asarray(WCS.world_to_pixel_values(wcs, *world))
    np.testing.assert_array_equal(np.isnan(fast), np.isnan(slow))
    assert np.isnan(fast[2]).any() and not np.isnan(fast[2]).all()
    # the first exposure whose slit passes through the point, as wcslib: the same cell
    np.testing.assert_array_equal(np.floor(fast[2] + 1e-6), np.floor(slow[2] + 1e-6), err_msg="cell")
    np.testing.assert_allclose(fast[:2], slow[:2], atol=1e-3)
    back = np.asarray(wcs.pixel_to_world_values(*fast))
    finite = np.isfinite(fast[2])
    np.testing.assert_allclose(back[1:, finite], np.asarray(world)[1:, finite], rtol=0, atol=1e-12)  # deg


def test_raster_inverse_falls_back_to_wcslib():
    wcs = _sit_and_stare_wcs()
    sub = wcs.sub([2, 3])  # a WCS of another layout
    assert sub._raster_layout() is None
    world = sub.pixel_to_world_values([3.0], [4.0])
    np.testing.assert_array_equal(sub.world_to_pixel_values(*world), WCS.world_to_pixel_values(sub, *world))
