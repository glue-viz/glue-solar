"""R8 on irispy main: -TAB raster WCS forward/inverse cost and round trips."""

import sys
import time
import warnings

import numpy as np

from irispy.io.spectrograph import read_spectrograph_lvl2

warnings.simplefilter("ignore")
D = "/Users/nabil/DATA/IRIS/"
FILES = {
    "4000255147 sit-and-stare": D
    + "2dd2d12db374b3466aa27a65bec235d3-iris_l2_20130902_163935_4000255147_raster/iris_l2_20130902_163935_4000255147_raster_t000_r00000.fits",
    "4000005156 scan 0": D
    + "0598beef2a051b4f371a4b09e439c4e4-iris_l2_20130902_182935_4000005156_raster/iris_l2_20130902_182935_4000005156_raster_t000_r00000.fits",
    "3824262996 scanning": D
    + "c7600db2087c0f285587e416a9e55e3d-iris_l2_20140708_114109_3824262996_raster/iris_l2_20140708_114109_3824262996_raster_t000_r00000.fits",
}


def si_iv(rc):
    key = next(k for k in rc.keys() if "1403" in k) if any("1403" in k for k in rc.keys()) else list(rc.keys())[0]
    return key, rc[key][0]


def main(n=200):
    rng = np.random.default_rng(0)
    for name, f in FILES.items():
        rc = read_spectrograph_lvl2(f, memmap=True)
        key, cube = si_iv(rc)
        wcs = cube.wcs.low_level_wcs
        shape = cube.data.shape  # (step, slit, wave)
        tab = wcs.wcs.tab[0]
        coord = np.asarray(tab.coord)  # (step, slit, 2) in deg
        lon = coord[..., 1] * 3600
        lat = coord[..., 0] * 3600
        steps = np.diff(lon[:, 0])
        print(f"\n== {name} [{key}] shape {shape} ctype {list(wcs.wcs.ctype)}")
        print(f"   table K {list(tab.K)}  lon span {np.ptp(lon[:, 0]):.2f}\"  median |dlon| {np.median(np.abs(steps)):.4f}\"")
        # random pixel points (x=wave, y=slit, z=step in WCS order)
        p = [rng.uniform(0, shape[2] - 1, n), rng.uniform(0, shape[1] - 1, n), rng.uniform(0, shape[0] - 1, n)]
        t = time.perf_counter()
        w = wcs.pixel_to_world_values(*p)
        tf = (time.perf_counter() - t) / n * 1e6
        t = time.perf_counter()
        q = wcs.world_to_pixel_values(*w)
        ti = (time.perf_counter() - t) / n * 1e6
        err = np.abs(np.asarray(q) - np.asarray(p))
        print(f"   forward {tf:.2f} us/pt  inverse {ti:.1f} us/pt")
        print(
            f"   round trip: max |dstep| {np.nanmax(err[2]):.3g} px, >0.01 px {np.mean(err[2] > 0.01) * 100:.0f}%,"
            f" max |dslit| {np.nanmax(err[1]):.3g}, NaN {np.isnan(q[2]).sum()}"
        )


if __name__ == "__main__":
    main(int(sys.argv[1]) if len(sys.argv) > 1 else 200)
