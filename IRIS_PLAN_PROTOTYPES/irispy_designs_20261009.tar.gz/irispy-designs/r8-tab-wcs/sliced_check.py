"""Option A after astropy WCS.slice (crpix moved), and ndcube's own slicing."""
import warnings
import numpy as np
from astropy.wcs import WCS
from fast_inverse import RasterWCS
from verify import FILES, si_iv
from irispy.io.spectrograph import read_spectrograph_lvl2
warnings.simplefilter("ignore")
rng = np.random.default_rng(3)
for name in ("3824262996 scanning", "4000255147 sit-and-stare"):
    key, cube = si_iv(read_spectrograph_lvl2(FILES[name], memmap=True))
    for item in ((slice(None),) * 3, (slice(100, 300), slice(50, 350), slice(None)), (slice(7, 9), slice(10, 400), slice(5, 60))):
        old = cube.wcs.slice(item)  # astropy's, numpy order
        new = old.deepcopy(); new.__class__ = RasterWCS
        shape = old.array_shape
        p = [rng.uniform(0, shape[2] - 1, 300), rng.uniform(0, shape[1] - 1, 300), rng.uniform(0, shape[0] - 1, 300)]
        world = old.pixel_to_world_values(*p)
        qo, qn = np.asarray(old.world_to_pixel_values(*world)), np.asarray(new.world_to_pixel_values(*world))
        print(f"{name:26s} slice {[(s.start, s.stop) for s in item]}: max |numpy - wcslib| wave {np.nanmax(abs(qn[0]-qo[0])):.2g}"
              f" slit {np.nanmax(abs(qn[1]-qo[1])):.2g} step {np.nanmax(abs(qn[2]-qo[2])):.2g}, same NaN {np.array_equal(np.isnan(qo), np.isnan(qn))}")
    sub = cube[100:300, 50:350]
    print("   ndcube slice wraps", type(sub.wcs.low_level_wcs).__name__, "of", type(sub.wcs.low_level_wcs._wcs).__name__)
