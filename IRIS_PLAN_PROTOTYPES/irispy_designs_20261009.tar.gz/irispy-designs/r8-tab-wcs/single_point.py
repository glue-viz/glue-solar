import timeit, warnings
import numpy as np
from fast_inverse import RasterWCS
from verify import FILES, si_iv
from irispy.io.spectrograph import read_spectrograph_lvl2
warnings.simplefilter("ignore")
for name, f in FILES.items():
    key, cube = si_iv(read_spectrograph_lvl2(f, memmap=True))
    old = cube.wcs; new = old.deepcopy(); new.__class__ = RasterWCS
    w = old.pixel_to_world_values(10.0, 100.0, cube.data.shape[0] / 2 + 0.3)
    n = 20
    t_old = timeit.timeit(lambda: old.world_to_pixel_values(*w), number=n) / n
    t_new = timeit.timeit(lambda: new.world_to_pixel_values(*w), number=n) / n
    t_lay = timeit.timeit(lambda: new._raster_layout(), number=n) / n
    print(f"{name:26s} one point: wcslib {t_old * 1e6:8.1f} us  numpy {t_new * 1e6:6.1f} us (layout read {t_lay * 1e6:.1f} us)",
          [float(v) for v in old.world_to_pixel_values(*w)], [float(v) for v in new.world_to_pixel_values(*w)])
