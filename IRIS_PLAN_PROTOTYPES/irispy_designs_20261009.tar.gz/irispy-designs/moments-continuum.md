**Design proposal: line moments over a continuum in one irispy call**

**Problem, checked on irispy main 3352413**

The problem still exists and is not fixed. It is also more than a speed issue for glue-solar. Any irispy user who writes `calculate_moments(subtract_background(cube, w), saturation_limit=SATURATION_LIMIT)` gets no saturation flags at all. On the 3860258481 flare, scans r00172-r00174, Si IV 1402.77 ±0.5 Å with continuum windows 1401.6-1402.1 and 1403.5-1404.3 Å, the raw samples have 839 saturated pixels (123, 428 and 288 per scan). After `subtract_background` the same call finds 0, for degree 0 and degree 1.

Today's glue-solar path (origin/main `_moments`, copied here without glue) costs this on 4000255147 Si IV 1403, which has 1600 steps, a 106-pixel crop and 70 slabs. Times are irispy time only, median of 3:

| Background | Errors | Total | First call (only there to find saturation) | `subtract_background` | Second call |
|---|---|---|---|---|---|
| Straight line (degree 1) | off | 1.84 s | 0.41 s | 1.04 s | 0.39 s |
| Straight line (degree 1) | on | 2.23 s | 0.48 s | 1.15 s | 0.60 s |
| Constant (degree 0) | off | 1.11 s | 0.38 s | 0.39 s | 0.34 s |

Measured over the whole loop, the first call adds 0.42-0.60 s, a little under D49's "about 0.7 s".

On this observation, 4000255147 has no saturated pixel within the wings: its 4 samples at or above 16182 DN lie elsewhere in the window. So the saturation equality checks below rest on the flare.

**Options**

All three options produced maps identical to today's (`array_equal`, NaN equal to NaN) on both datasets, for degree 0 and 1, with and without error maps. Saturated counts matched (0 and 839).

**A. `calculate_moments(..., background=None, background_degree=1)` (recommended)**
- **API:** the windows and degree that `subtract_background` already takes.
- **What it does:** irispy fits the background on the whole spectrum, then checks saturation on the raw samples within the wings, then subtracts the background. Pixels with too few window samples to fit become NaN and masked in every map, as saturated pixels already are (the D48 behaviour).
- **Change for existing users:** none, since both arguments are keyword-only and default to off.
- **Cost:** about 25 lines. The fitting code moves out of `subtract_background` into `_fit_background`, whose output is unchanged (its existing tests pass).
- **Gains on 4000255147:**
  - degree 1: 1.84 → 1.38 s without errors, 2.23 → 1.60 s with errors
  - degree 0: 1.11 → 0.66 s without errors, 1.21 → 0.81 s with errors
  - whole loop: 0.42-0.60 s saved (21-38 %)
  - flare: about 0.02 s saved of 0.06-0.10 s (17-39 %)
- **Memory:** peak per slab drops from 55 to 29 MiB (58 to 49 MiB with errors), because the background-subtracted cube is never built.
- **Risk:** it needs a fix to the maps' mask (below).

**B. A public saturation check plus `subtract_background` and one `calculate_moments`**
- **API:** a new function, for example `find_saturated(cube, saturation_limit)`.
- **Gain:** degree 1 takes 1.52 s, degree 0 takes 0.74 s.
- **Drawbacks:** it adds a public function, the caller still makes three calls, and a user who doesn't know about the trap still falls into it.

**C. `subtract_background(..., saturation_limit=None)` writes raw samples at or above the limit as +Inf**
- This follows D12's convention that +Inf means saturated. `calculate_moments` then catches the +Inf samples.
- **Gain:** about 0.27-0.30 s saved (degree 1: 1.55 s). This is the smallest code change.
- **Drawbacks:** other consumers of the result see +Inf. If the caller passes a finite limit afterwards, a negative fitted background could lift an unsaturated sample over it and flag it wrongly. To be safe the caller has to pass `saturation_limit=np.inf`, which is awkward.

**Recommendation: A, plus a mask fix**

The mask fix is needed whatever happens. Today the template mask comes from the whole cube, not from the samples within the wings. A pixel masked at every wavelength within the wings but not outside them gets intensity 0, unmasked. Once glue-solar passes the whole crop including the continuum, that gives 1505 intensity pixels on 4000255147 (5 on flare scan r00172) that are 0 instead of today's NaN. Masking from the samples actually used fixes it. On current main the new test for this fails on `intensity`.

Exact diff: `/private/tmp/claude-501/-Users-nabil-Git-glue-solar/07d33ef8-b8df-4ddb-b55c-24b6271a724b/scratchpad/irispy-designs/moments-continuum/option_a.diff`

**Files and functions to change**
- `irispy/utils/spectrograph.py`:
  - Split `_fit_background(cube, windows, degree)` out of `subtract_background`. It returns the background array, NaN where there are too few samples, and `subtract_background` becomes `cube - Quantity(_fit_background(...))`.
  - Add one Notes line: subtracting the background lowers a saturation plateau, so pass the windows to `calculate_moments`' `background` instead.
- `irispy/utils/moments.py`, `calculate_moments`:
  - add the two keyword arguments;
  - fit the background before the wings crop and crop it with the same slicer;
  - after the saturation check, `data -= fitted`;
  - replace the saturated-only NaN block with `blank = saturated | NaN background`;
  - pass `mask=all_masked` (masked at every wavelength used) to `make_map_cube`;
  - in the docstring, say that saturation is checked before the subtraction and that the background's error is left out (see `subtract_background` Notes).
- `docs/tutorial/data_idiosyncrasies.rst`: one sentence.
- Changelog: `<PR>.feature.rst` for the arguments and `<PR>.bugfix.rst` for the wings mask.

**Tests**

These are prototyped in `pkg/irispy/utils/tests/test_moments_background.py`. On the patched copy they pass together with the existing `test_moments`, `test_spectrograph` and `test_mg_features` (95 passed, offline).
1. `background` gives the same results as `subtract_background` followed by `calculate_moments`, maps and errors, for degree 0 and 1.
2. A plateau clipped at `SATURATION_LIMIT` on a background is flagged and NaN with `background`, and is missed by the two-call path.
3. A spectrum with too few samples in the windows is NaN and masked in every map.
4. A pixel masked at every wavelength within the wings is masked in every map. This one fails on main.

**What glue-solar does afterwards (a later PR)**

`_moments` makes one call on the whole crop, passing `background=continuum * u.AA` (or None) and `background_degree=degree`, with sigma computed over the crop. The `subtract_background` import, the inner slice and the second cube go away. Without a continuum the crop equals the wings, so both cases take the same path. The `iris-plan-main` and `iris-plan-floor-main` envs need irispy main reinstalled.

**Questions for you**
1. Are the names `background` and `background_degree` right, matching `subtract_background` and `profiles_on_background`? The alternative is `continuum`.
2. Should the wings-mask fix go in the same irispy PR or its own? It changes masks for existing users: values stay the same, those pixels just become masked.
3. Is it right for irispy to make pixels without a fitted background NaN and masked in every map, rather than giving intensity 0?
4. Should `_fit_background` also get `optimize=True` in its two `einsum` calls? That cuts the degree-1 fit on 4000255147 from 0.87 to 0.33 s. The maps then differ from today's by up to 2e-10 DN/s from rounding, so they are no longer bit-for-bit equal. Same PR, separate, or skip?
5. Should `calculate_mg_features` get the same argument? It has the same trap, but I'd leave it until someone asks.

Everything is in `/private/tmp/claude-501/-Users-nabil-Git-glue-solar/07d33ef8-b8df-4ddb-b55c-24b6271a724b/scratchpad/irispy-designs/moments-continuum/`:
- `option_a.py`, `option_a.diff`
- `bench.py`, `wall.py`, `option_b.py` (timings)
- `trap.py`, `edge.py`, `ncm.py`, `einsum_real.py` (checks)
- `pkg/` (patched copy of irispy main with the new tests)