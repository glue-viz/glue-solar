"""Interleaved A/B of pan (cache miss every draw) in one process: install/uninstall in alternating blocks."""
import glob
import statistics as st
import sys
from time import perf_counter

sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
sys.path.insert(0, "/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes/cache")
import numpy as np
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure

import wcsaxes_cache as P
from glue_solar.sources.loaders.iris import image_data

d = image_data(glob.glob("/Users/nabil/DATA/IRIS/*4000255147_SJI_1400_t000.fits.gz")[0])
a = d[d.main_components[0]]
i0 = a.shape[0] // 2
fig = Figure(figsize=(4, 3.3), dpi=100)
FigureCanvasAgg(fig)
ax = fig.add_subplot(projection=d.coords, slices=("x", "y", i0))
ax.imshow(np.asarray(a[i0]), origin="lower", interpolation="nearest")
ax.set_xlabel("x")
ax.set_ylabel("y")
x0, x1 = ax.get_xlim()
res = {"base": [], "cache": []}
k = 0
for rnd in range(20):
    for mode in ("base", "cache") if rnd % 2 else ("cache", "base"):
        P.install() if mode == "cache" else P.uninstall()
        for j in range(12):
            k += 1
            ax.set_xlim(x0 + k * 0.37, x1 + k * 0.37)  # new limits every draw: always a miss
            t = perf_counter()
            fig.canvas.draw()
            if j >= 2:
                res[mode].append((perf_counter() - t) * 1e3)
P.uninstall()
for m, v in res.items():
    print(m, "pan median", round(st.median(v), 2), "ms, mean", round(st.mean(v), 2), "n", len(v))
print("stats", P.STATS)
