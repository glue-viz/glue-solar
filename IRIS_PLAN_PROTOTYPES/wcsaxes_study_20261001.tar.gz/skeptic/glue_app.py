"""In-app check through glue's Qt ImageViewer (offscreen). usage: glue_app.py <base|cache>

SJI 1400: static redraws (canvas.draw) and slice steps (state.slices change, which runs
_set_wcs, then canvas.draw). Medians; viewer widget resized so the canvas is about 400x330.
"""
import glob
import statistics as st
import sys
from time import perf_counter

sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
sys.path.insert(0, "/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes/cache")
import wcsaxes_cache as P

MODE = sys.argv[1]
if MODE == "cache":
    P.install()

from glue.core import DataCollection
from glue.core.session import Session
from glue_qt.utils import get_qapp
from glue_qt.viewers.image import ImageViewer

import glue_solar
from glue_solar.sources.loaders.iris import image_data

print("glue_solar", glue_solar.__file__, file=sys.stderr)
app = get_qapp()
d = image_data(glob.glob("/Users/nabil/DATA/IRIS/*4000255147_SJI_1400_t000.fits.gz")[0])
dc = DataCollection([d])
v = ImageViewer(Session(data_collection=dc, hub=dc.hub))
v.add_data(d)
v.show()
v.resize(400 + (v.width() - v.figure.canvas.width()), 330 + (v.height() - v.figure.canvas.height()))
app.processEvents()
canvas = v.figure.canvas
print("canvas", canvas.width(), canvas.height(), "dpr", canvas.device_pixel_ratio, file=sys.stderr)
n = d.shape[0]


def med(f, k, warm=3):
    for _ in range(warm):
        f()
    ts = []
    for _ in range(k):
        t = perf_counter()
        f()
        ts.append((perf_counter() - t) * 1e3)
    return round(st.median(ts), 2)


static = med(canvas.draw, 30)
it = iter(range(n // 2, n))


def step():
    v.state.slices = (next(it), 0, 0)
    canvas.draw()


s = med(step, 15)
print(f"glue ImageViewer sji1400 {MODE}: static {static} ms, slice step {s} ms, stats {P.STATS}")
