"""What ax.cla() does to WCSAxes, base vs lazy: usage cla_probe.py <base|lazy>."""
import hashlib
import sys

sys.path.insert(0, "/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes/cache")
import numpy as np
from astropy.wcs import WCS
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure

import wcsaxes_cache as P

if sys.argv[1] == "lazy":
    P.install(lazy=True)

w = WCS(naxis=2)
w.wcs.ctype = ["HPLN-TAN", "HPLT-TAN"]
w.wcs.cunit = ["arcsec", "arcsec"]
w.wcs.cdelt = [0.6, 0.6]
w.wcs.crpix = [100.5, 80.5]
w.wcs.crval = [-300.0, 200.0]
r = np.radians(80)
w.wcs.pc = [[np.cos(r), -np.sin(r)], [np.sin(r), np.cos(r)]]
fig = Figure(figsize=(4, 3.3), dpi=100)
FigureCanvasAgg(fig)
ax = fig.add_subplot(projection=w)
ax.imshow(np.random.default_rng(0).random((160, 200)), origin="lower")
ax.set_xlabel("X label")
fig.canvas.draw()
ax.set_xlabel("CLA")
ax.cla()
print("pending after cla:", ax.__dict__.get("_pending_labels"), "| coords id same:", id(ax.coords))
fig.canvas.draw()
print("img", hashlib.sha256(np.asarray(fig.canvas.buffer_rgba()).tobytes()).hexdigest()[:12],
      "| labels", [c._axislabels.get_text() for c in ax.coords], "| xlim", ax.get_xlim(), "| axison", ax.axison,
      "| _drawn", getattr(ax, "_drawn", None), "| ticks", [dict(c._ticklabels.text) for c in ax.coords])
ax.set(xlabel="SETX")
ax.set_xlim(-2000, 2000)
fig.canvas.draw()
print("after set(xlabel), set_xlim:", [c._axislabels.get_text() for c in ax.coords], "| xlim", ax.get_xlim())
