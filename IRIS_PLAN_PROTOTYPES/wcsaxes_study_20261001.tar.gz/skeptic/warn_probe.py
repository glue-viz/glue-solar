"""Warnings shown per draw with a transform that warns, default filters. usage: warn_probe.py <base|cache>"""
import sys
import warnings

sys.path.insert(0, "/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes/cache")
import numpy as np
from astropy import units as u
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure

import wcsaxes_cache as P
from astropy.visualization.wcsaxes import WCSAxes
from astropy.visualization.wcsaxes.transforms import CurvedTransform

if sys.argv[1] == "cache":
    P.install()
SHOWN = []
warnings.showwarning = lambda m, c, f, l, file=None, line=None: SHOWN.append(str(m))


class Warny(CurvedTransform):
    has_inverse = False

    def transform(self, pixel):
        warnings.warn("transform noticed something", RuntimeWarning)
        return np.column_stack([pixel[:, 0] * 0.01, pixel[:, 1] * 0.02])

    transform_non_affine = transform

    def inverted(self):
        raise NotImplementedError


fig = Figure(figsize=(4, 3.3), dpi=100)
FigureCanvasAgg(fig)
meta = {"type": ("scalar", "scalar"), "wrap": (None, None), "unit": (u.one, u.one), "name": ("a", "b")}
ax = fig.add_axes([0.15, 0.15, 0.75, 0.75], axes_class=WCSAxes, transform=Warny(), coord_meta=meta)
ax.set_xlim(0, 200)
ax.set_ylim(0, 160)
counts = []
for i in range(6):
    if i in (3, 4):
        ax.set_xlim(i, 200 + i)  # pan: cache miss
    SHOWN.clear()
    fig.canvas.draw()
    counts.append(len(SHOWN))
print(sys.argv[1], "warnings shown per draw [static, static, static, pan, pan, static]:", counts)
