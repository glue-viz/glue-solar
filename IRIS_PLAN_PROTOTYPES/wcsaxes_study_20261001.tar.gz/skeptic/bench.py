"""Independent re-measure. usage: python skeptic/bench.py <case> <base|cache>

Plain matplotlib: Figure + FigureCanvasAgg, ax = fig.add_subplot(projection=wcs, slices=...)
(not glue's init_mpl), default margins, imshow nearest. Medians after warm-up.
"""
import glob
import json
import statistics as st
import sys
from time import perf_counter

sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
sys.path.insert(0, "/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes/cache")
import numpy as np
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure

import wcsaxes_cache as P

CASE, MODE = sys.argv[1], sys.argv[2]
if MODE == "cache":
    P.install()
R = "/Users/nabil/DATA/IRIS"


def load():
    import glue_solar
    from glue_solar.sources.loaders.iris import image_data, raster_data
    print("glue_solar", glue_solar.__file__, file=sys.stderr)
    if CASE == "sji1400":
        d = image_data(glob.glob(f"{R}/*4000255147_SJI_1400_t000.fits.gz")[0])
        a = d[d.main_components[0]]
        return d.coords, a, lambda i: ("x", "y", i), lambda i: a[i], a.shape[0]
    d = raster_data(sorted(glob.glob(f"{R}/*4000255147_raster/*_r00000.fits")), windows=["Si IV 1403"])[0]
    a = d[d.main_components[0]]
    if CASE == "siiv_spec":  # x wavelength, y slit, exposure sliced
        return d.coords, a, lambda i: ("x", "y", i), lambda i: a[i], a.shape[0]
    # siiv_lt: x wavelength, y exposure, slit sliced
    return d.coords, a, lambda i: ("x", i, "y"), lambda i: a[:, i, :], a.shape[1]


def labels(ax):  # glue's _set_wcs: '' then the real labels
    ax.set_xlabel("")
    ax.set_ylabel("")
    ax.set_xlabel("X world", size=10)
    ax.set_ylabel("Y world", size=10)


def med(f, n, warm=3):
    for _ in range(warm):
        f()
    ts = []
    for _ in range(n):
        t = perf_counter()
        f()
        ts.append((perf_counter() - t) * 1e3)
    return round(st.median(ts), 2)


wcs, arr, sl, img, n = load()
out = {}
for w, h in ((400, 330), (1258, 810)):
    fig = Figure(figsize=(w / 100, h / 100), dpi=100)
    FigureCanvasAgg(fig)
    i0 = n // 2
    ax = fig.add_subplot(projection=wcs, slices=sl(i0))
    im = ax.imshow(np.asarray(img(i0)), origin="lower", cmap="gray", interpolation="nearest", aspect="auto")
    labels(ax)
    draw = fig.canvas.draw
    r = {"static": med(draw, 30)}
    lo, hi = np.nanpercentile(np.asarray(img(i0)), [1, 99])
    k = [0]

    def contrast():
        k[0] += 1
        im.set_clim(lo, hi + k[0] % 3)
        draw()

    r["contrast"] = med(contrast, 30)
    x0, x1 = ax.get_xlim()

    def pan():
        k[0] += 1
        ax.set_xlim(x0 + k[0] % 2 * 0.7, x1 + k[0] % 2 * 0.7)
        draw()

    r["pan"] = med(pan, 30)
    ax.set_xlim(x0, x1)
    idx = iter(list(range(i0 + 1, min(n, i0 + 40))) * 3)

    def step():  # glue slice change: reset_wcs + label round trip + draw
        i = next(idx)
        ax.reset_wcs(wcs=wcs, slices=sl(i))
        labels(ax)
        im.set_data(np.asarray(img(i)))
        draw()

    r["slice_step"] = med(step, 15)
    r["set_xlabel_once"] = med(lambda: ax.set_xlabel("X world", size=10), 30)
    out[f"{w}x{h}"] = r
out["stats"] = dict(P.STATS)
print(json.dumps(dict(case=CASE, mode=MODE, **out)))
