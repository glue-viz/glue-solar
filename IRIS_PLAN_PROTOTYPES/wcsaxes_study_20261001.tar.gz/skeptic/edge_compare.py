import json
import sys

OUT = "/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes/skeptic/out"
for g in sys.argv[1:]:
    base = json.load(open(f"{OUT}/edge_{g}_base.json"))["res"]
    for m in ("cache", "lazy"):
        other = json.load(open(f"{OUT}/edge_{g}_{m}.json"))["res"]
        for name, rows in base.items():
            if name.startswith("_"):
                continue
            bad = []
            for b, o in zip(rows, other[name], strict=True):
                keys = [k for k in b if b[k] != o.get(k)]
                if keys:
                    bad.append(f"{b['step']}:{','.join(keys)}")
            print(f"{g:9s} {m:5s} {name:32s} steps={len(rows):2d} {'SAME' if not bad else 'DIFF ' + ' '.join(bad)}")
