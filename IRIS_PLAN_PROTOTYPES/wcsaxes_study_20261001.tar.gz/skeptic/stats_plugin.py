def pytest_sessionfinish(session):
    import wcsaxes_cache
    print("\nCACHE STATS", wcsaxes_cache.STATS, "installed:", bool(wcsaxes_cache._ORIG))
