"""Edge-case fingerprints. usage: edge.py <base|cache|lazy> <synthetic|sji|siiv>  -> out/edge_<group>_<mode>.json

After each step: canvas RGBA sha, per coordinate (all maps) tick world/pixel/angle + minor, tick
label text, axis label text/visibility, warnings shown during the step, or the exception raised.
"""
import glob
import hashlib
import io
import json
import pickle
import sys
import warnings

sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
sys.path.insert(0, "/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes/cache")
import numpy as np
from astropy import units as u
from astropy.wcs import WCS
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure
from matplotlib.transforms import Affine2D

import wcsaxes_cache as P
from astropy.visualization.wcsaxes import WCSAxes
from astropy.visualization.wcsaxes.frame import EllipticalFrame
from astropy.visualization.wcsaxes.transforms import CurvedTransform

MODE, GROUP = sys.argv[1], sys.argv[2]
if MODE != "base":
    P.install(lazy=MODE == "lazy")
OUT = "/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes/skeptic/out"

SHOWN = []
warnings.showwarning = lambda m, c, f, l, file=None, line=None: SHOWN.append(f"{c.__name__}:{str(m)[:60]}")


def sha(b):
    return hashlib.sha256(b).hexdigest()[:12]


def arr(d):
    return sha(pickle.dumps({a: np.asarray(v, dtype=float).tobytes() for a, v in sorted(d.items()) if len(v)}))


def fp(fig):
    out = dict(img=sha(np.asarray(fig.canvas.buffer_rgba()).tobytes()), coords=[])
    for ax in fig.axes:
        for m, coords in enumerate(getattr(ax, "_all_coords", [])):
            for c in coords:
                t, tl, al = c._ticks, c._ticklabels, c._axislabels
                out["coords"].append([m, c.coord_index, arr(t.world), arr(t.pixel), arr(t.angle), arr(t.minor_world),
                                      arr(t.minor_pixel), {a: list(v) for a, v in sorted(tl.text.items()) if v},
                                      al.get_text(), al.get_visible(), c.get_ticklabel_position(),
                                      c.get_axislabel_position()])
    return out


RES = {}


def run(name, fig, steps):
    """steps: list of (label, callable or None); a draw follows each step."""
    rows = []
    for label, f in steps:
        SHOWN.clear()
        try:
            if f is not None:
                f()
            fig.canvas.draw()
            r = fp(fig)
        except Exception as e:  # noqa: BLE001
            r = dict(exc=f"{type(e).__name__}: {str(e)[:80]}")
        r["step"], r["warn"] = label, sorted(set(SHOWN)) and len(SHOWN)
        rows.append(r)
    RES[name] = rows


def new_fig(w=4.0, h=3.3, **kw):
    fig = Figure(figsize=(w, h), dpi=100, **kw)
    FigureCanvasAgg(fig)
    return fig


def tan(roll=0.0, celestial=False, cdelt=0.6):
    w = WCS(naxis=2)
    w.wcs.ctype = ["RA---TAN", "DEC--TAN"] if celestial else ["HPLN-TAN", "HPLT-TAN"]
    w.wcs.cunit = ["deg", "deg"] if celestial else ["arcsec", "arcsec"]
    w.wcs.cdelt = [-cdelt, cdelt] if celestial else [cdelt, cdelt]
    w.wcs.crpix = [100.5, 80.5]
    w.wcs.crval = [30.0, 40.0] if celestial else [-300.0, 200.0]
    if not celestial:
        w.wcs.dateobs = "2013-09-02T16:39:35"
    if roll:
        r = np.radians(roll)
        w.wcs.pc = [[np.cos(r), -np.sin(r)], [np.sin(r), np.cos(r)]]
    return w


def allsky():
    w = WCS(naxis=2)
    w.wcs.ctype = ["GLON-AIT", "GLAT-AIT"]
    w.wcs.crval = [0.0, 0.0]
    w.wcs.cdelt = [-1.0, 1.0]
    w.wcs.crpix = [180.5, 90.5]
    return w


def spec2d():
    w = WCS(naxis=2)
    w.wcs.ctype = ["WAVE", "OFFSET"]
    w.wcs.cunit = ["Angstrom", "arcsec"]
    w.wcs.crval = [1402.77, 0.0]
    w.wcs.cdelt = [0.0254, 0.1663]
    w.wcs.crpix = [1.0, 1.0]
    return w


IMG = np.random.default_rng(0).random((160, 200), dtype=np.float32)


def basic(wcs=None, img=IMG, fig=None, **kw):
    fig = fig or new_fig()
    ax = fig.add_subplot(projection=wcs if wcs is not None else tan(), **kw)
    im = ax.imshow(img, origin="lower", interpolation="nearest")
    ax.set_xlabel("X label")
    ax.set_ylabel("Y label")
    return fig, ax, im


def pan(ax, dx=7.3):
    return lambda: ax.set_xlim(*(np.array(ax.get_xlim()) + dx))


def synthetic():
    # 1. tick spacings, values, number, formats on angles
    fig, ax, _ = basic()
    c0, c1 = ax.coords[0], ax.coords[1]
    run("spacings_angle", fig, [
        ("init", None), ("static", None),
        ("sp30as", lambda: c0.set_ticks(spacing=30 * u.arcsec)), ("static", None),
        ("sp2am", lambda: c0.set_ticks(spacing=2 * u.arcmin)),
        ("values", lambda: c1.set_ticks(values=[150, 200, 230] * u.arcsec)),
        ("number3", lambda: c1.set_ticks(number=3)),
        ("sp30as_again", lambda: c0.set_ticks(spacing=30 * u.arcsec)),
        ("fmt_s.s", lambda: c0.set_major_formatter("s.s")),
        ("sep", lambda: c0.set_separator(":")),
        ("format_unit", lambda: c0.set_format_unit(u.arcmin, decimal=True)),
        ("no_decimal_unit", lambda: c0.set_major_formatter("d.dd", show_decimal_unit=False)),
        ("exclude_overlap", lambda: c0.set_ticklabel(exclude_overlapping=True)),
        ("minor", lambda: c1.display_minor_ticks(True)), ("minor_freq", lambda: c1.set_minor_frequency(7)),
        ("coord_type_scalar", lambda: c0.set_coord_type("scalar")),
        ("coord_type_lon_wrap", lambda: c0.set_coord_type("longitude", coord_wrap=180 * u.deg)),
        ("static", None),
    ])
    # 2. scalar spacings (spectral x offset)
    fig, ax, _ = basic(spec2d())
    c0, c1 = ax.coords[0], ax.coords[1]
    run("spacings_scalar", fig, [
        ("init", None), ("static", None),
        ("sp0.5A", lambda: c0.set_ticks(spacing=0.5 * u.AA)), ("static", None),
        ("unit_nm", lambda: c0.set_format_unit(u.nm)),
        ("fmt", lambda: c0.set_major_formatter("x.xxx")),
        ("sp10as", lambda: c1.set_ticks(spacing=10 * u.arcsec)),
        ("number12", lambda: c1.set_ticks(number=12)),
        ("pan", pan(ax)), ("static", None),
    ])
    # 3. hidden coordinates and visibility toggles
    fig, ax, _ = basic(tan(roll=30))
    c0, c1 = ax.coords[0], ax.coords[1]
    run("hidden", fig, [
        ("init", None), ("static", None),
        ("c0_invisible", lambda: c0.set_visible(False)), ("static", None),
        ("c0_visible", lambda: c0.set_visible(True)),
        ("c0_ticks_off", lambda: c0.set_ticks_visible(False)),
        ("c0_labels_off", lambda: c0.set_ticklabel_visible(False)), ("static", None),
        ("c0_back", lambda: (c0.set_ticks_visible(True), c0.set_ticklabel_visible(True))),
        ("c1_axislabel_rule", lambda: c1.set_axislabel_visibility_rule("ticks")),
        ("c1_axislabel_rule_always", lambda: c1.set_axislabel_visibility_rule("always")),
        ("static", None),
    ])
    # 4. right / top spines
    fig, ax, _ = basic(tan(roll=15))
    c0, c1 = ax.coords[0], ax.coords[1]
    run("spines", fig, [
        ("init", None),
        ("c0_ticks_t", lambda: c0.set_ticks_position("t")),
        ("c0_ticklabels_t", lambda: c0.set_ticklabel_position("t")),
        ("c0_axislabel_t", lambda: c0.set_axislabel_position("t")),
        ("c1_r", lambda: (c1.set_ticks_position("r"), c1.set_ticklabel_position("r"), c1.set_axislabel_position("r"))),
        ("static", None),
        ("c0_bt", lambda: c0.set_ticklabel_position("bt")),
        ("tick_params_x", lambda: ax.tick_params(axis="x", direction="in", labelsize=6)),
        ("c1_minor", lambda: (c1.display_minor_ticks(True), c1.tick_params(which="minor", length=3))),
        ("auto", lambda: (c0.set_ticklabel_position("#"), c1.set_ticklabel_position("#"))),
        ("relabel", lambda: (ax.set_xlabel("X2"), ax.set_ylabel("Y2"))),
        ("pan", pan(ax)), ("static", None),
    ])
    # 5. overlays added after the first draw
    fig, ax, _ = basic(allsky(), np.random.default_rng(1).random((180, 360)))
    ov = {}
    run("overlay", fig, [
        ("init", None), ("static", None),
        ("add_fk5", lambda: ov.setdefault("a", ax.get_coords_overlay("fk5"))),
        ("static", None),
        ("ov_grid", lambda: ov["a"].grid(color="white", alpha=0.5)),
        ("ov_pos", lambda: (ov["a"][0].set_ticklabel_position("t"), ov["a"][1].set_ticklabel_position("r"))),
        ("ov_spacing", lambda: ov["a"][0].set_ticks(spacing=45 * u.deg)),
        ("pan", pan(ax, 11.0)),
        ("add_icrs", lambda: ov.setdefault("b", ax.get_coords_overlay("icrs"))),
        ("static", None),
        ("zoom", lambda: (ax.set_xlim(90, 270), ax.set_ylim(45, 135))), ("static", None),
    ])
    # 6. colorbar
    fig, ax, im = basic()
    cb = {}
    run("colorbar", fig, [
        ("init", None), ("static", None),
        ("add_cb", lambda: cb.setdefault("c", fig.colorbar(im, ax=ax))), ("static", None),
        ("cb_label", lambda: cb["c"].set_label("DN")), ("static", None),
        ("rm_cb", lambda: cb["c"].remove()), ("static", None),
    ])
    # 7. tiny and zero-size axes
    fig, ax, _ = basic(fig=new_fig(0.4, 0.33))
    run("tiny_zero", fig, [
        ("init", None), ("static", None),
        ("pos_1e-4", lambda: ax.set_position([0.5, 0.5, 1e-4, 1e-4])), ("static", None),
        ("pos_zero", lambda: ax.set_position([0.5, 0.5, 0.0, 0.0])), ("static", None),
        ("pos_zero_w", lambda: ax.set_position([0.1, 0.1, 0.0, 0.8])), ("static", None),
        ("fig_big", lambda: (fig.set_size_inches(4, 3.3), ax.set_position([0.15, 0.15, 0.75, 0.75]))),
        ("static", None),
    ])
    # 8. NaN regions: TAN beyond the horizon, all-sky zoomed out
    fig, ax, _ = basic(tan(celestial=True, cdelt=0.5))
    run("nan_tan", fig, [
        ("init", None), ("zoomout", lambda: (ax.set_xlim(-400, 600), ax.set_ylim(-400, 560))),
        ("static", None), ("pan", pan(ax, 13.0)), ("static", None),
        ("spacing", lambda: ax.coords[0].set_ticks(spacing=15 * u.deg)), ("static", None),
    ])
    fig, ax, _ = basic(allsky(), np.random.default_rng(1).random((180, 360)))
    run("nan_allsky", fig, [
        ("init", None), ("zoomout", lambda: (ax.set_xlim(-200, 560), ax.set_ylim(-100, 280))),
        ("static", None), ("pan", pan(ax, 9.0)), ("static", None),
    ])
    # 9. transform that starts failing, and an in-place WCS edit that breaks the WCS
    flag = {"fail": False}

    class Flaky(CurvedTransform):
        has_inverse = False

        def transform(self, pixel):
            if flag["fail"]:
                raise ValueError("world transform failed")
            return np.column_stack([pixel[:, 0] * 0.01 + 10.0, pixel[:, 1] * 0.02 - 5.0])

        transform_non_affine = transform

        def inverted(self):
            raise NotImplementedError

    fig = new_fig()
    meta = {"type": ("scalar", "scalar"), "wrap": (None, None), "unit": (u.one, u.one), "name": ("a", "b")}
    ax = fig.add_axes([0.15, 0.15, 0.75, 0.75], axes_class=WCSAxes, transform=Flaky(), coord_meta=meta)
    ax.imshow(IMG, origin="lower")
    ax.set_xlim(-0.5, 199.5)
    ax.set_ylim(-0.5, 159.5)
    run("failing_transform", fig, [
        ("init", None), ("static", None),
        ("fail", lambda: flag.update(fail=True)), ("static_fail", None),
        ("recover", lambda: flag.update(fail=False)), ("static", None),
    ])
    w = tan(celestial=True)
    fig, ax, _ = basic(w)
    run("broken_wcs_inplace", fig, [
        ("init", None), ("static", None),
        ("break", lambda: (setattr(w.wcs, "crval", [30.0, 140.0]), w.wcs.set())), ("static_broken", None),
        ("fix", lambda: (setattr(w.wcs, "crval", [30.0, 40.0]), w.wcs.set())), ("static", None),
    ])
    # 10. warnings shown per draw (default filters; only the showwarning hook)
    fig, ax, _ = basic(allsky(), np.random.default_rng(1).random((180, 360)))
    ax.set_xlim(-200, 560)
    ax.set_ylim(-100, 280)
    run("warnings_allsky", fig, [("d1", None), ("d2", None), ("d3", None), ("pan", pan(ax, 3.0)), ("pan2", pan(ax, 3.0)), ("d4", None)])
    # 11. savefig at another dpi and bbox_inches='tight'
    fig, ax, _ = basic(tan(roll=20))
    png = {}

    def save(key, **kw):
        def f():
            b = io.BytesIO()
            fig.savefig(b, format="png", **kw)
            png[key] = sha(b.getvalue())
        return f

    run("savefig", fig, [
        ("init", None), ("dpi200", save("dpi200", dpi=200)), ("tight", save("tight", bbox_inches="tight")),
        ("dpi200_again", save("dpi200b", dpi=200)), ("static", None),
    ])
    RES["savefig"].append(dict(step="png", png=png))
    # 12. constrained layout
    fig, ax, _ = basic(tan(), fig=new_fig(layout="constrained"))
    run("constrained", fig, [("init", None), ("static", None), ("relabel", lambda: ax.set_xlabel("Much longer X label " * 2)),
                             ("resize", lambda: fig.set_size_inches(6, 4)), ("static", None)])
    # 13. elliptical frame
    fig, ax, _ = basic(allsky(), np.random.default_rng(1).random((180, 360)), frame_class=EllipticalFrame)
    run("elliptical", fig, [("init", None), ("static", None), ("pan", pan(ax, 5.0)), ("static", None),
                            ("resize", lambda: fig.set_size_inches(5, 3)), ("static", None),
                            ("grid", lambda: ax.coords.grid(color="w")), ("static", None)])
    # 14. inverted y, 15. log scale
    fig, ax, _ = basic(tan(roll=10))
    run("invert", fig, [("init", None), ("inv_y", lambda: ax.invert_yaxis()), ("static", None),
                        ("inv_x", lambda: ax.invert_xaxis()), ("static", None)])
    fig, ax, _ = basic(tan())
    run("logscale", fig, [("init", None), ("lims", lambda: (ax.set_xlim(1, 199), ax.set_ylim(1, 159))),
                          ("logx", lambda: ax.set_xscale("log")), ("static", None),
                          ("logx_base2", lambda: ax.set_xscale("log", base=2)), ("static", None),
                          ("linear", lambda: ax.set_xscale("linear")), ("static", None)])
    # 18. pickle round trip after a cached draw
    fig, ax, _ = basic(tan(roll=5))
    fig.canvas.draw()
    fig.canvas.draw()
    try:  # astropy 8.0.1 itself cannot unpickle a WCSAxes figure (BaseFrame.__init__ args)
        pickle.loads(pickle.dumps(fig))
        RES["pickle"] = [dict(step="roundtrip", ok=True)]
    except Exception as e:  # noqa: BLE001
        RES["pickle"] = [dict(step="roundtrip", exc=f"{type(e).__name__}: {str(e)[:80]}")]
    # 19. label ordering against layout calls (matters for lazy)
    fig, ax, _ = basic(tan(roll=80))
    run("label_layout", fig, [
        ("init", None),
        ("xlabel_then_tight", lambda: (ax.set_xlabel("TL"), fig.tight_layout())),
        ("xlabel_then_savefig_tight", lambda: (ax.set_xlabel("ST"), save("t2", bbox_inches="tight")())),
        ("xlabel_then_tightbbox", lambda: (ax.set_xlabel("TB"), ax.get_tightbbox(fig.canvas.get_renderer()))),
        ("set_kw", lambda: ax.set(xlabel="SETX", ylabel="SETY")),
        ("xlabel_then_lim_change", lambda: (ax.set_xlabel("LIM"), ax.set_xlim(-2000, 2000), ax.set_ylim(-2000, 2000))),
        ("static", None),
        ("get_xlabel", lambda: RES.setdefault("_gx", []).append(ax.get_xlabel())),
        ("xlabel_then_cla", lambda: (ax.set_xlabel("CLA"), ax.cla())),
        ("static_after_cla", None),
    ])
    RES["label_layout"].append(dict(step="png", png=png.get("t2")))


def documented():
    """Known ceilings named in the report: show they do change output."""
    g = {"suffix": ""}
    fig, ax, _ = basic()
    ax.coords[0].set_major_formatter(lambda vals, spacing=None: [f"{v.value:.0f}{g['suffix']}" for v in vals])
    run("doc_custom_formatter_global", fig, [("init", None), ("suffix", lambda: g.update(suffix="!")), ("static", None)])

    bump = {"a": 0.0}

    class Bumpy(CurvedTransform):
        has_inverse = False

        def transform(self, pixel):
            x, y = pixel[:, 0], pixel[:, 1]
            # zero at the 3x3 probe columns x = -0.5, 99.5, 199.5
            return np.column_stack([x * 0.01 + bump["a"] * np.sin(np.pi * (x + 0.5) / 100.0) ** 2, y * 0.02])

        transform_non_affine = transform

        def inverted(self):
            raise NotImplementedError

    fig = new_fig()
    meta = {"type": ("scalar", "scalar"), "wrap": (None, None), "unit": (u.one, u.one), "name": ("a", "b")}
    ax = fig.add_axes([0.15, 0.15, 0.75, 0.75], axes_class=WCSAxes, transform=Bumpy(), coord_meta=meta)
    ax.imshow(IMG, origin="lower")
    ax.set_xlim(-0.5, 199.5)
    ax.set_ylim(-0.5, 159.5)
    run("doc_inplace_invisible_to_probe", fig, [("init", None), ("bump", lambda: bump.update(a=0.3)), ("static", None)])


def iris(kind):
    from glue_solar.sources.loaders.iris import image_data, raster_data
    R = "/Users/nabil/DATA/IRIS"
    if kind == "sji":
        d = image_data(glob.glob(f"{R}/*4000255147_SJI_1400_t000.fits.gz")[0])
        a = d[d.main_components[0]]
        i0 = a.shape[0] // 2
        fig = new_fig()
        ax = fig.add_subplot(projection=d.coords, slices=("x", "y", i0))
        ax.imshow(np.asarray(a[i0]), origin="lower", interpolation="nearest")
        ax.set_xlabel("Solar X")
        ax.set_ylabel("Solar Y")
        c0, c1 = ax.coords[0], ax.coords[1]
        run("sji_spacings_hidden", fig, [
            ("init", None), ("static", None),
            ("sp10as", lambda: c0.set_ticks(spacing=10 * u.arcsec)), ("static", None),
            ("sp1am", lambda: c1.set_ticks(spacing=1 * u.arcmin)),
            ("values", lambda: c0.set_ticks(values=[-420, -400, -380] * u.arcsec)),
            ("number", lambda: c1.set_ticks(number=9)),
            ("hide_c0", lambda: c0.set_visible(False)), ("static", None), ("show_c0", lambda: c0.set_visible(True)),
            ("top_right", lambda: (c0.set_ticklabel_position("t"), c1.set_ticklabel_position("r"),
                                   c0.set_axislabel_position("t"), c1.set_axislabel_position("r"))),
            ("pan", pan(ax, 3.3)), ("slice", lambda: ax.reset_wcs(wcs=d.coords, slices=("x", "y", i0 + 1))),
            ("relabel", lambda: (ax.set_xlabel("Solar X"), ax.set_ylabel("Solar Y"))), ("static", None),
            ("dpi2", lambda: fig.set_dpi(200)), ("static", None),
        ])
    else:
        d = raster_data(sorted(glob.glob(f"{R}/*4000255147_raster/*_r00000.fits")), windows=["Si IV 1403"])[0]
        a = d[d.main_components[0]]
        j0 = a.shape[1] // 2
        fig = new_fig()
        ax = fig.add_subplot(projection=d.coords, slices=("x", j0, "y"))
        ax.imshow(np.asarray(a[:, j0, :]), origin="lower", interpolation="nearest", aspect="auto")
        ax.set_xlabel("Wavelength")
        ax.set_ylabel("Time")
        vis = [c for c in ax.coords if c.coord_index is not None]
        run("siiv_lt_hidden_spacings", fig, [
            ("init", None), ("static", None),
            ("hide_third", lambda: (vis[-1].set_ticks_visible(False), vis[-1].set_ticklabel_visible(False))),
            ("static", None),
            ("show_third", lambda: (vis[-1].set_ticks_visible(True), vis[-1].set_ticklabel_visible(True))),
            ("invisible_first", lambda: vis[0].set_visible(False)), ("static", None),
            ("visible_first", lambda: vis[0].set_visible(True)),
            ("wl_spacing", lambda: vis[0].set_ticks(spacing=0.1 * u.AA)), ("static", None),
            ("wl_unit_nm", lambda: vis[0].set_format_unit(u.nm)),
            ("top_right", lambda: (vis[0].set_ticklabel_position("t"), vis[1].set_ticklabel_position("r"))),
            ("contour_grid", lambda: ax.coords.grid(grid_type="contours", color="y")), ("static", None),
            ("pan", pan(ax, 2.1)), ("static", None),
        ])


if GROUP == "synthetic":
    synthetic()
    documented()
else:
    iris(GROUP)
json.dump(dict(mode=MODE, stats=dict(P.STATS), res=RES), open(f"{OUT}/edge_{GROUP}_{MODE}.json", "w"), indent=0)
print(GROUP, MODE, P.STATS)
