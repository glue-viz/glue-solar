# How WCSAxes draws ticks, tick labels, grid lines and axis labels

Code: astropy main 1f930be7c4 (the #20499 merge), `astropy/visualization/wcsaxes/`. Line numbers are on main; "8.0.1:" gives the installed line where it differs. Measurements: plain matplotlib + WCSAxes (`fig.add_subplot(projection=wcs, slices=('x','y',0))`), Agg, 400x300 px, zero image, installed astropy 8.0.1, medians of 15 draws after a warm-up. The IRIS WCSes come from the glue-solar-main loaders (glue_solar.__file__ = /Users/nabil/Git/glue-solar-main/glue_solar/__init__.py). Scripts are in /private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes/explain/ (calls.py, phases.py, grid_probe.py, reset_probe.py; outputs in out_*.txt and phases_*.txt).

## 1. Objects

- **WCSAxes** (core.py:51) is an ordinary Axes with its own spines and x/y axes hidden (195-202). `transData` is still the affine data-to-display transform, and data coordinates are pixel coordinates. World coordinates never enter `transData`.
- **CoordinatesMap.** `ax.coords` is one (coordinates_map.py:11). `ax._all_coords` holds it plus any overlays (core.py:528, 794).
  - Each map owns a frame (coordinates_map.py:57) and one `CoordinateHelper` per world axis of the **unsliced** WCS (65-102).
  - A world axis the slice drops gets `coord_index=None` (84-87). It never gets ticks, a grid or a mouse-over value.
- **CoordinateHelper** (coordinate_helpers.py:49) owns a formatter_locator (411-426), one `Ticks` Line2D (117), one `TickLabels` Text (120-124) and one `AxisLabels` Text (129-133). Each Text artist is moved and drawn once per label.
- **Frames** are OrderedDicts of `Spine`s:
  - Rectangular: `brtl`, with auto order `bltr` (frame.py:378-395).
  - 1-D: `bt` with `SpineXAligned` (326-375).
  - Elliptical: `chv` (398-462).
- **Spines.** Setting `Spine.data` (pixel coordinates) transforms it to world immediately and stores the inward normal angle in display space (57-65, 104-109).
- **Tickable gridlines.** `add_tickable_gridline` (coordinate_helpers.py:1341-1455) adds spines whose `data_func` is re-run by `update_spines` (frame.py:279-282).
- **Draw hook.** `_WCSAxesArtist` (core.py:32-48) calls `draw_wcsaxes` from inside matplotlib's zorder pass. Its zorder follows `axisbelow` (654-660).

## 2. Transforms and slices

- **Metadata.** `reset_wcs` → `transform_coord_meta_from_wcs` (wcsapi.py:135-293) builds the type, wrap, unit, format unit and names from the physical types and the UCD maps (29-58). For example, helioprojective longitude wraps at 180° and formats in arcsec.
- **Slicing.** `apply_slices` (296-329):
  - turns 'x' and 'y' into `slice(None)` and keeps integers;
  - sets `invert_xy` when 'x' comes after 'y';
  - returns `SlicedLowLevelWCS(wcs, wcs_slice[::-1])`.
  A coordinate is visible if its world axis survives the slice (251-252). The slice index is frozen into the transform, so a new slice needs a new `reset_wcs`.
- **WCSPixel2WorldTransform** (wcsapi.py:419-491) is a `CurvedTransform` (transforms.py:31-62), a non-affine matplotlib Transform.
  - Its `transform_path` maps vertices without subdividing, so everything is sampled densely.
  - `.transform(N×2)` (460-485) makes one `pixel_to_world_values` call. It returns every kept world axis (N × world_n_dim), and callers keep one column, `[:, coord_index]`.
  - The inverse (340-416) accepts exactly two world inputs (387-388).
- **Overlays** (core.py:755-815) use `pixel2world + CoordinateTransform` (852-911). That runs `SkyCoord.transform_to` on every call (transforms.py:118-154).
- **No memo** exists anywhere on this path.

Cost per call:

| WCS | 2 points | 1000 points |
|---|---|---|
| TAN FITS WCS | 0.004 ms | 0.033 ms |
| SJI 1400 gWCS | 0.349 ms | 0.415 ms |
| Si IV -TAB | 0.064 ms | 0.112 ms |

For the gWCS, the number of calls is the cost, not the number of points.

## 3. Draw sequence

`WCSAxes.draw` (core.py:628-667):

1. Removes the previous draw's contour grids (640-642), then runs `apply_aspect` (647-652).
2. Runs `frame._update_patch_path()` (663). Its `update_spines` makes 4 two-point WCS calls whose world values go unused. The vertices of the same Path object are updated in place (frame.py:200-211).
3. Runs `Axes.draw`, which reaches `draw_wcsaxes` (585-626):
   - places the ticks, with `_update_tick_and_label_positions(keep_coord_range=True)`;
   - runs `_draw_grid` for every coordinate of every map, then deletes `_coord_range`;
   - runs `_draw_ticks` for each coordinate, collecting tick-label bboxes into `self._bboxes`;
   - runs `_draw_axislabels`;
   - draws the main frame (frame.py:223-230, Line2Ds, no WCS).
4. Sets `_drawn = True` (667), which turns on `format_coord`.

`_update_tick_and_label_positions` (core.py:556-583) works per map:

1. `coords.frame.update()` (571). BaseFrame defines no `update`, so this is a no-op `OrderedDict.update()`.
2. Sets `_coord_range`.
3. Runs `_update_ticks()` for every coordinate.
4. Runs `auto_assign_coord_positions` once.
5. Deletes `_coord_range`, "to protect from accidental use of a stale range" (581-583).

### 3.1 Coordinate range

`find_coordinate_range` (coordinate_range.py:23-147) makes one transform call on a 51×51 grid over the current limits (`coordinate_range_samples=50`). Then:

- longitudes are unwrapped by row, then by column (65-85), and 0-360 and ±180 normalizations are compared;
- lon/lat get 10% padding;
- a longitude span over 300° becomes a full circle at the wrap angle (119-139).

The list covers visible coordinates only and is indexed by `coord_index`.

### 3.2 `_update_ticks` (coordinate_helpers.py:984-1139; 8.0.1: 966)

1. **Skip.** Returns when `coord_index is None` (985-986).
2. **Values.** `self.locator(*range)` (998-1000) returns `(values, spacing)`.
   - The values are integer multiples of the spacing inside the range (formatter_locator.py:171-175).
   - The spacing comes from one of:
     - explicit `values`, in which case the spacing is reported as 1.1 arcsec or 1.1 unit (386-388, 651-653);
     - an explicit `spacing`;
     - `number` (default 5, 110-111), via `select_step_*`. A fixed format floors it at the format's precision (414-417, 678-685).
   - A degenerate range gives no ticks and a sentinel spacing (396-397, 660-661).
   - The spacing is kept in `self._fl_spacing`. Minor values come from `minor_locator` (152-161).
3. **Frame sampling.** `frame.sample(1000)` (1013) calls `update_spines()` (frame.py:233), which makes 4 two-point calls. It then builds new Spines resampled linearly to `frame_boundary_samples=1000` points, with one WCS call per spine that returns every world column.
4. **Direction, per spine.**
   - Skips spines that are empty or all-NaN for this coordinate (1026-1037).
   - Transforms the spine to display coordinates, shifts it +2 px in x and calls the WCS again (`shifted_pixel_to_world`, 1041-1056).
   - Does the same with ±2 px in y, with the sign taken from `frame.origin` (1059-1067). Where a shift lands on NaN, it goes the other way.
   - Rotates the display-space gradient (dx, dy) by 90° to get the gridline direction (1070). Longitudes are scaled to degrees and wrapped at ±180° (1072-1080).
   - Sets `tick_angle = atan2` (1082) and flips it by 180° when it points more than 90° away from the inward normal (1084-1091). 1-D frames use ±90° (1093-1095).
   - Cost: 2 WCS calls per spine per coordinate (4 with the NaN fallback), and the result depends on axes size and DPI through `transData`.
5. **Endpoints.** w1 and w2 along each spine (1100-1116). Longitudes are unit-scaled, wrapped at `coord_wrap` and unwrapped across 360°.
6. **`_compute_ticks`** (1141-1241).
   - Longitudes test both t and t+360 (1144-1149).
   - A tick sits on every segment where t == w1 or (t−w1)(t−w2) < 0, plus the last endpoint (1160-1170).
   - Position and angle are interpolated linearly inside the segment (1174-1192), and the world value is wrapped back (1194-1206).
   - Major ticks also store label info: pad angle = spine normal, plus the tick angle (1208-1232).
   - One value can give several ticks on a spine. Ticks are found on **every** spine, visible or not.
7. **Labels.** All of a coordinate's labels are formatted in one call (1136-1139): `AngleFormatterLocator.formatter` (441-547, `Angle.to_string`, precision from the spacing unless a format is fixed), `ScalarFormatterLocator.formatter` (699-721), or a callable from `set_major_formatter` (917).

### 3.3 Automatic spine assignment (_auto.py:8-139)

**Defaults** (core.py:537-551, wcsapi.py:254-267). Every visible coordinate gets '#' (automatic) for ticks, tick labels and axis label. When a rectangular frame has exactly two visible coordinates, both also get ticks on all of `brtl`. That gives ticks on four spines and labels on b and l.

**Assignment.**

1. A coordinate with fixed tick-label positions pulls its automatic ticks and axis label onto those spines and reserves them (40-67).
2. The remaining '#' coordinates try every permutation of the free spines in `bltr` order, padded with " " (74-84).
3. Options that clash with fixed tick positions are skipped (92-102).
4. Each option scores the ticks it would show, `len(_ticks.world[s])`, which uses step 6 on every spine. It loses 1 point for each empty spine before the last used one (104-118).
5. The winning positions become `[spine, '#']`, so they stay automatic (132-139).

On main, a coordinate whose ticks and tick labels are both hidden is left out (57-65, #20499). If no option fits, every coordinate falls back to " " (128-129).

### 3.4 Drawing

- **Ticks** (ticks.py:174-249). One `draw_markers` call per tick on each visible spine, skipping '#'. The marker is a unit path scaled to the tick size and rotated by the tick angle, plus 180° for ticks pointing out. It records `ticks_locs`.
- **Tick label positions** (ticklabels.py:349-376). `_set_xy_alignments` (222-309) runs on every draw, because `add` marks the labels stale (137). It:
  - calls `simplify_labels` (153-197), which drops repeated leading sexagesimal fields in order along the spine;
  - measures each label (251-257);
  - anchors each label where the pad direction leaves its box (277-283);
  - offsets it along the pad direction, tilted toward the tick by at most 60° (285-303).
- **Tick label drawing.** The draw pass measures each label again (311-332). With `exclude_overlapping` on, it skips labels that overlap earlier ones, including those of coordinates drawn before (core.py:609-614). It then draws and records the bboxes.
- **Axis labels.** `_draw_axislabels` (coordinate_helpers.py:966-982) writes the default text if none is set. `AxisLabels.draw` (axislabels.py:61-151) then, for each visible spine:
  - checks the visibility rule; the default 'labels' rule needs this coordinate to have drawn tick labels (87-89);
  - places the label at the spine midpoint (frame.py:111-129), rotated along the spine and kept upright;
  - on rectangular frames, moves it outside the union of **all** coordinates' tick-label bboxes by minpad × font size (108-141).
- **Tight bbox.** `get_tightbbox` (core.py:913-926) runs a whole `draw_wcsaxes` to fill `_bboxes`.

### 3.5 Grid

`_draw_grid` (coordinate_helpers.py:919-942) runs only after `grid()`.

- **'lines'** is the default whenever the transform has an inverse (365-366), and `WCSPixel2WorldTransform` always reports one.
  - `_update_grid_lines` (1281-1339) calls the locator again on the same `_coord_range`.
  - It builds n_ticks × 1000 points and assumes two world columns (1312-1321).
  - It makes one inverse call and one forward round-trip call (1328-1331).
  - `get_lon_lat_path` (grid_paths.py:16-88) splits lines where the round trip disagrees, at NaNs and at jumps of more than 10× the previous step.
  - Each path is clipped to `frame.patch` (931-936). That runs `update_spines` again: 4 calls per coordinate, sliced-out ones included.
  - With three visible coordinates (the Si IV raster), 'lines' raises `IndexError` in `SlicedLowLevelWCS.world_to_pixel_values`, so only 'contours' works there.
- **'contours'** (1467-1525) makes one 200×200 forward call and runs `ax.contour` on every draw.

## 4. Measured calls and phases

With n visible coordinates on a rectangular frame and no grid, one draw makes **5 + 16n** `pixel_to_world_values` calls:
- 1 for the range;
- per coordinate: 4 corner, 4 sampled and 8 shifted;
- 4 for the patch path.

| Data | Calls (n) | Distinct inputs |
|---|---|---|
| TAN map | 37 (n=2) | 17 |
| SJI | 37 (n=2) | 17 |
| Si IV | 53 (n=3) | 17 |

On Si IV, wavelength is placed on b, latitude on l and longitude on r. Each coordinate repeats the inputs of the coordinate before it, and the 12 corner calls have only 4 distinct inputs. Grid lines add 4 calls per coordinate and 1 forward call per visible coordinate (SJI: 51 calls, 19 distinct).

| ms | draw | draw_wcsaxes | placement | ticks + labels | axis labels | patch path |
|---|---|---|---|---|---|---|
| TAN | 16.9 | 5.6 | 2.9 | 2.1 | 0.4 | 0.1 |
| SJI 1400 | 23.0 | 18.6 | 15.7 | 2.2 | 0.5 | 1.6 |
| Si IV | 18.4 | 15.9 | 7.5 | 6.5 | 1.6 | 0.4 |

WCS evaluation is about 15.8 ms of the SJI draw. With grid lines on, the SJI draw takes 34.9 ms, 11.6 ms of it in the grid.

## 5. Eager placement in set_xlabel/set_ylabel

`set_xlabel` (core.py:670-698; 8.0.1: 596) runs a full `_update_tick_and_label_positions()` (685). It then gives the text to the first coordinate in the main map whose axis-label positions contain 'b' or 'h' (692-698).

`set_ylabel` does the same with 'l' or 'c' (700-732; eager call at 715, 8.0.1: 615). `get_xlabel`, `get_ylabel` (734-753) and `tick_params(axis='x'|'y')` (1046) also place eagerly.

**Why.** With '#' positions, the coordinate on b is known only after auto-assignment. That needs every spine's tick count from `_update_ticks`. Before the first draw no coordinate has 'b', so the label would be lost. This came with the auto-placement rework (#17243, astropy 7.0).

The ticks are discarded and the next draw recomputes them. Only the `[spine,'#']` assignment it writes is kept.

| | Per call | WCS calls |
|---|---|---|
| SJI | 15.3 ms | 33 |
| Si IV | 7.2 ms | 49 |

glue's `_set_wcs` makes four of these calls (glue/viewers/image/viewer.py:119-124 via glue/viewers/matplotlib/viewer.py:152-162).

## 6. reset_wcs and format_coord

**`reset_wcs`** (core.py:455-554):
- calls `wcs.wcs.set()` on FITS WCSes;
- keeps the frame's Path object, color and linewidth, so artists clipped to the frame stay valid (496-526);
- builds a new transform and a new CoordinatesMap: new frame, helpers, Ticks, labels and formatter_locators. Every `set_ticks`, `set_major_formatter`, `set_ticklabel` and `grid` customization is lost;
- drops overlays (528) and clamps the cursor's overlay index (534-535, main only);
- re-applies the default positions.

It makes no WCS calls: 0.40 ms (SJI) and 0.56 ms (Si IV).

**`format_coord`** is `_display_world_coords` (core.py:153, 160-187).
- It returns "" until the first draw. The 'w' key cycles through world, the overlays and pixel.
- It makes one transform call (171; about 0.6 ms on SJI), then calls `CoordinateHelper.format_coord` for each visible coordinate (458-492).
- That uses `_fl_spacing` from the last `_update_ticks` for its precision, and returns "" if ticks were never placed (472-473). Mouse-over precision therefore follows the tick spacing.

## 7. What is cached

Nothing on the placement path survives from one draw to the next:
- `_coord_range` is deleted on purpose;
- `sample` builds new spines every time;
- the `_stale` flag in TickLabels (ticklabels.py:57-59, 232-233, 309) only saves work within one draw, because every `add` marks it stale;
- the transforms have no memo.

The only working caches are matplotlib's (text metrics, the reused Path). Nothing tracks invalidation.

A placement cache would need to key on:
- the transform, which is new after each `reset_wcs`;
- xlim and ylim;
- `transData` (axes size and DPI);
- `frame.origin`;
- the frame class and custom spines;
- each coordinate's locator and format state, type, wrap and unit;
- the minor-tick settings;
- the `conf` sample counts;
- position and visibility settings, and `_all_coords`;
- for the label text, `text.usetex`, `axes.unicode_minus` and any custom formatter, which is opaque.

## 8. Invariants a change must keep

1. **All spines.** Ticks are computed on every spine, because auto-assignment scores spines by tick count. The default 2-D view has ticks on all four spines and labels on b and l. Right and top ticks have no labels and point inward, or outward with `direction='out'`.
2. **Rotated, curved and wrapping grids.** Keep multiple crossings per spine, the t+360 test, `coord_wrap`, and `_coord_scale_to_deg` for arcsec longitudes (IRIS).
3. **NaN.** An all-NaN spine is skipped, a NaN shift goes the other way, and a NaN segment gives no tick (off-limb and off-footprint views).
4. **Hidden coordinates.** A coordinate with `coord_index None` gets no ticks, grid, range entry or mouse-over value. One with ticks and labels hidden is left out of auto-assignment (#20499) but still runs `_update_ticks`, which sets `_fl_spacing`.
5. **Overlays.** Each map has its own frame and transform. Overlays sit at fixed 't' and 'r' (core.py:802-806), which takes those spines out of the main assignment.
6. **Other frames.** 1-D frames, elliptical frames and `data_func` spines must keep working.
7. **Labels.** Simplification and overlap exclusion depend on the order along the spine and on the draw order of coordinates. Axis labels need every coordinate's tick-label bboxes.
8. **Agreement.** Grid lines and ticks share the locator values, and `format_coord` needs `_fl_spacing`.
9. **Frame path.** The frame's Path object keeps its identity across `reset_wcs`.
10. **Eager labels.** `set_xlabel` must attach to the coordinate that ends up on b or l, even before the first draw.

## 9. Installed 8.0.1 against main

- **#20499** (main only, `_auto.py:57-65`). 8.0.1 (`_auto.py:55`) lets hidden coordinates compete for spines.
- **#20221**, "wcsaxes-review-fixes", main only:
  - fixes the stale `coords.frame` in `_auto` (8.0.1:64) and a `TypeError` when no assignment fits;
  - fixes `t *= _coord_scale_to_deg`, which mutated the loop variable, so a second crossing of an arcsec longitude on one spine got a wrong value (8.0.1 coordinate_helpers.py:1178);
  - removes an identity offset transform from `Ticks` (8.0.1:118-122);
  - fixes contour grids with fewer than 2 ticks or a sliced-out coordinate;
  - fixes a `simplify_labels` crash when one label is a prefix of the next;
  - adds sentinel spacings in the locators and guards on the grid paths;
  - clamps the cursor overlay index;
  - honors the overlay's `coord_meta`.
- **#20434** changes docstrings only, but it shifts line numbers.
- **#19057 and #19801** are backported into 8.0.1.
- **Unchanged:** the placement algorithm, the call counts and the eager `set_xlabel`. Searches for "wcsaxes performance", "wcsaxes slow" and "WCSAxes speed" found no astropy issue on draw cost.

Key numbers: Setup: plain matplotlib + WCSAxes, Agg, 400x300 px, astropy 8.0.1, medians n=15 after warm-up.

pixel_to_world_values calls per draw (grid off) = 5 + 16n, with n = number of visible coordinates:
- TAN map: 37 calls, 17 distinct.
- SJI 1400 gWCS: 37 calls, 17 distinct.
- Si IV -TAB raster: 53 calls, 17 distinct. It has 3 visible coordinates, placed on b, l and r.
- Breakdown per draw: 1 range call (51x51 grid); per coordinate 4 corner + 4 sampled-spine + 8 shifted-spine calls; 4 patch-path calls.
- With grid lines on, the SJI draw makes 51 calls (19 distinct). Grid lines fail with IndexError on the 3-coordinate Si IV raster.

Cost per call (2 points / 1000 points):
- TAN: 0.004 / 0.033 ms.
- SJI gWCS: 0.349 / 0.415 ms.
- Si IV: 0.064 / 0.112 ms.

Draw medians:
- SJI: 23.0 ms per draw. draw_wcsaxes takes 18.6 ms (81%) and tick placement 15.7 ms (68%). WCS evaluation is about 15.8 ms. Ticks and labels take 2.2 ms, the patch path 1.6 ms.
- Si IV: 18.4 ms per draw, draw_wcsaxes 15.9, placement 7.5, ticks and labels 6.5.
- TAN: 16.9 ms per draw, draw_wcsaxes 5.6, placement 2.9.
- SJI with grid lines: 34.9 ms per draw, 11.6 of it in the grid.

Other calls:
- set_xlabel or set_ylabel: SJI 15.3 ms and 33 calls each; Si IV 7.2 ms and 49 calls each. glue's _set_wcs makes 4 of these.
- reset_wcs: 0.40 ms on SJI, 0.56 ms on Si IV, with 0 WCS calls.
- format_coord: 1 call, about 0.6 ms on SJI.

Key lines on astropy main 1f930be7c4:
- core.py:556-583 placement; 571 frame.update() no-op; 585-626 draw_wcsaxes; 663 patch path; 685/715 eager set_xlabel/set_ylabel; 913-926 tightbbox.
- coordinate_helpers.py:984-1139 _update_ticks; 1013 sample; 1041-1067 shifted; 1141-1241 _compute_ticks; 932 frame.patch in the grid.
- _auto.py:57-65 (#20499).
- wcsapi.py:460-485 transform.

In 8.0.1: set_xlabel at core.py:596/598, _update_ticks at coordinate_helpers.py:966, longitude t mutation bug at coordinate_helpers.py:1178, and _auto.py:55/64.
