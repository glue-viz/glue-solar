"""λ-time / spectrogram tick-label detail, per-coordinate TickLabels.draw time, and Si IV world->pixel per-call cost."""
import glob, sys, statistics as st
from time import perf_counter
sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
import numpy as np
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure
from astropy.visualization.wcsaxes import ticklabels
from glue.viewers.matplotlib.mpl_axes import init_mpl
from glue_solar.sources.loaders.iris import raster_data

d = raster_data(sorted(glob.glob("/Users/nabil/DATA/IRIS/*4000255147_raster/*_r00000.fits")), windows=["Si IV 1403"])[0]
arr = d[d.main_components[0]]
TL = {}
orig = ticklabels.TickLabels.draw
def draw(self, renderer, *a, **k):
    t = perf_counter(); r = orig(self, renderer, *a, **k); TL.setdefault(id(self), []).append(perf_counter() - t); return r
ticklabels.TickLabels.draw = draw
import matplotlib.text as mtext
DRAWN = {}
_td = mtext.Text.draw
def tdraw(self, renderer):
    if isinstance(self, ticklabels.TickLabels): DRAWN[id(self)] = DRAWN.get(id(self), 0) + 1
    return _td(self, renderer)
mtext.Text.draw = tdraw
for name, slices, img in (("spec", ["x", "y", 200], arr[200]), ("lt", ["x", 208, "y"], arr[:, 208, :])):
    for w, h in ((400, 330), (1258, 810)):
        fig = Figure(figsize=(w / 100, h / 100), dpi=100); FigureCanvasAgg(fig)
        _, ax = init_mpl(figure=fig, wcs=True)
        ax.set_position([1 / (w / 100), 0.5 / (h / 100), 1 - 1.25 / (w / 100), 1 - 0.75 / (h / 100)])
        ax.reset_wcs(slices=slices, wcs=d.coords)
        for c in ax.coords: c.set_ticklabel(size=8)
        ax.imshow(np.asarray(img), origin="lower", aspect="auto", interpolation="nearest")
        TL.clear(); DRAWN.clear()
        for _ in range(23): fig.canvas.draw()
        fig.savefig(f"{sys.path[1]}/{name}_{w}x{h}.png")
        for c in ax.coords:
            tl = c._ticklabels
            n = sum(len(v) for v in tl.text.values()); drawn = DRAWN.get(id(tl), 0) / 23
            print(name, f"{w}x{h}", "coord", c.coord_index, c.coord_type, "labels", n, "drawn", drawn,
                  "axes", {a: len(v) for a, v in tl.text.items()}, "TickLabels.draw ms", round(st.median(TL[id(tl)][3:]) * 1e3, 2),
                  "sample texts", [t for v in tl.text.values() for t in v][:6])
        # world->pixel on the 3-world/2-pixel sliced WCS WCSAxes holds, and on the full _GlueWCS
        low = ax.coords._transform.wcs
        x0, x1 = ax.get_xlim(); y0, y1 = ax.get_ylim()
        if False:
            for n in (1, 10, 1000):
                p = np.column_stack([np.random.uniform(x0, x1, n), np.random.uniform(y0, y1, n)])
                world = low.pixel_to_world_values(*p.T)
                ts = []
                for _ in range(20):
                    t = perf_counter(); low.world_to_pixel_values(*world); ts.append(perf_counter() - t)
                print(name, "SlicedLowLevelWCS.world_to_pixel_values n", n, "ms", round(st.median(ts) * 1e3, 3))
