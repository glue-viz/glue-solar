| case | size | draw | WCSAxes | share | image | placement | coord_range | _update_ticks (per coord) | of which sample | auto | grid | Ticks.draw | TickLabels.draw | AxisLabels.draw | frame.draw | patch_path | p2w calls (distinct) | p2w ms (dup ms) | pan draw | pan WCSAxes |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| sji1400 | 400x330 | 26.6 | 22.3 | 84% | 4.0 | 15.9 | 0.87 | 7.7 / 7.3 / 0.0 | 6.7 | 0.04 | 0.00 | 0.24 | 2.0 | 2.2 | 0.24 | 1.63 | 37 (17) | 15.4 (8.0) | 27.1 | 22.6 |
| sji1400 | 1258x810 | 34.4 | 23.8 | 69% | 10.1 | 17.0 | 1.10 | 8.1 / 7.8 / 0.0 | 6.9 | 0.05 | 0.00 | 0.26 | 2.1 | 2.3 | 0.33 | 1.67 | 37 (17) | 16.2 (8.3) | 33.4 | 22.9 |
| siiv_spec | 400x330 | 21.7 | 18.4 | 85% | 3.1 | 7.9 | 0.40 | 2.6 / 2.3 / 2.6 | 2.8 | 0.07 | 0.00 | 0.27 | 6.7 | 2.8 | 0.24 | 0.41 | 53 (17) | 5.3 (3.4) | 21.7 | 18.4 |
| siiv_spec | 1258x810 | 37.0 | 20.8 | 56% | 15.8 | 9.1 | 0.77 | 2.9 / 2.6 / 2.7 | 3.1 | 0.07 | 0.00 | 0.33 | 7.4 | 3.0 | 0.33 | 0.46 | 53 (17) | 6.0 (3.8) | 35.3 | 19.9 |
| siiv_lt | 400x330 | 37.2 | 29.1 | 78% | 7.8 | 10.0 | 0.47 | 2.7 / 3.5 / 3.3 | 2.8 | 0.07 | 0.00 | 0.59 | 14.8 | 3.0 | 0.25 | 0.43 | 59 (20) | 6.3 (3.9) | 40.7 | 31.8 |
| siiv_lt | 1258x810 | 50.0 | 29.8 | 59% | 19.7 | 10.2 | 0.55 | 2.7 / 3.5 / 3.3 | 2.8 | 0.07 | 0.00 | 0.61 | 15.0 | 3.0 | 0.31 | 0.44 | 59 (20) | 6.3 (3.9) | 48.9 | 29.4 |
| sji2796 | 400x330 | 50.6 | 27.6 | 55% | 22.6 | 18.3 | 1.16 | 8.9 / 8.2 / 0.0 | 7.5 | 0.05 | 0.00 | 0.44 | 4.1 | 2.4 | 0.26 | 1.84 | 37 (17) | 17.2 (8.7) | 46.6 | 24.9 |
| sji2796 | 1258x810 | 56.9 | 25.9 | 45% | 30.5 | 17.3 | 1.10 | 8.2 / 7.7 / 0.0 | 7.0 | 0.05 | 0.00 | 0.43 | 3.9 | 2.3 | 0.30 | 1.70 | 37 (17) | 16.3 (8.2) | 62.7 | 28.5 |
| tan | 400x330 | 20.6 | 7.0 | 34% | 13.2 | 3.2 | 0.44 | 1.6 / 1.2 | 0.7 | 0.04 | 0.00 | 0.24 | 2.3 | 0.9 | 0.21 | 0.08 | 37 (17) | 1.3 (0.6) | 20.3 | 6.9 |
| tan | 1258x810 | 28.0 | 7.2 | 26% | 20.3 | 3.3 | 0.51 | 1.6 / 1.2 | 0.8 | 0.04 | 0.00 | 0.24 | 2.3 | 0.9 | 0.25 | 0.08 | 37 (17) | 1.3 (0.6) | 29.2 | 7.4 |

| case | size | set phase (reset_wcs + 4 label sets) | reset_wcs | 4x set_x/ylabel | p2w in set phase | direct set_axislabel phase | step draw | set_xlabel alone (p2w) |
|---|---|---|---|---|---|---|---|---|
| sji1400 | 400x330 | 66.6 | 0.58 | 65.7 | 132 (17) | 0.40 | 27.7 | 16.1 (33) |
| sji1400 | 1258x810 | 64.3 | 0.57 | 63.6 | 132 (17) | 0.40 | 34.0 | 15.6 (33) |
| siiv_spec | 400x330 | 32.1 | 0.73 | 31.0 | 196 (17) | 0.61 | 22.1 | 7.9 (49) |
| siiv_spec | 1258x810 | 32.5 | 0.75 | 31.5 | 196 (17) | 0.58 | 34.6 | 7.9 (49) |
| siiv_lt | 400x330 | 38.6 | 0.71 | 37.4 | 220 (20) | 0.56 | 35.0 | 10.2 (55) |
| siiv_lt | 1258x810 | 38.2 | 0.70 | 37.1 | 220 (20) | 0.58 | 46.5 | 9.5 (55) |
| sji2796 | 400x330 | 65.8 | 0.55 | 64.8 | 132 (17) | 0.40 | 46.1 | 16.1 (33) |
| sji2796 | 1258x810 | 69.3 | 0.56 | 68.6 | 132 (17) | 0.42 | 59.4 | 17.7 (33) |
| tan | 400x330 | - | - | - | - | - | - | 3.0 (33) |
| tan | 1258x810 | - | - | - | - | - | - | 2.9 (33) |

| case | layer | 1 pt | 2 | 10 | 100 | 1000 | 2601 | 5000 | fixed ms | ms per 1000 pts |
|---|---|---|---|---|---|---|---|---|---|---|
| sji1400 | WCSPixel2WorldTransform.transform | 0.361 | 0.364 | 0.354 | 0.366 | 0.427 | 0.527 | 0.684 | 0.3597 | 0.0647 |
| sji1400 | SlicedLowLevelWCS.pixel_to_world_values (2-D, what transform calls) | 0.347 | 0.349 | 0.348 | 0.374 | 0.421 | 0.529 | 0.841 | 0.3419 | 0.0935 |
| sji1400 | _GlueWCS.pixel_to_world_values (3-D) | 0.389 | 0.355 | 0.349 | 0.368 | 0.407 | 0.532 | 0.810 | 0.3515 | 0.0860 |
| sji1400 | inner gwcs.wcs._wcs.WCS.pixel_to_world_values (3-D) | 0.289 | 0.290 | 0.294 | 0.309 | 0.360 | 0.448 | 0.691 | 0.2880 | 0.0764 |
| sji1400 | WCSWorld2PixelTransform.transform | 2.125 | 2.218 | 2.069 | 2.300 | 2.475 | 2.839 | 3.307 | 2.1882 | 0.2314 |
| siiv_spec | WCSPixel2WorldTransform.transform | 0.071 | 0.067 | 0.070 | 0.078 | 0.093 | 0.128 | 0.234 | 0.0674 | 0.0311 |
| siiv_spec | SlicedLowLevelWCS.pixel_to_world_values (2-D, what transform calls) | 0.065 | 0.063 | 0.064 | 0.065 | 0.084 | 0.119 | 0.205 | 0.0612 | 0.0271 |
| siiv_spec | _GlueWCS.pixel_to_world_values (3-D) | 0.061 | 0.060 | 0.060 | 0.063 | 0.102 | 0.131 | 0.212 | 0.0612 | 0.0299 |
| siiv_spec | inner astropy.wcs.wcs.WCS.pixel_to_world_values (3-D) | 0.023 | 0.022 | 0.023 | 0.023 | 0.036 | 0.061 | 0.123 | 0.0202 | 0.0194 |
| siiv_spec | WCSWorld2PixelTransform.transform | ValueError('Expected 2 world coordinates, got 3') |
| siiv_lt | WCSPixel2WorldTransform.transform | 0.067 | 0.064 | 0.065 | 0.067 | 0.091 | 0.132 | 0.256 | 0.0607 | 0.0364 |
| siiv_lt | SlicedLowLevelWCS.pixel_to_world_values (2-D, what transform calls) | 0.061 | 0.060 | 0.061 | 0.063 | 0.091 | 0.120 | 0.180 | 0.0615 | 0.0236 |
| siiv_lt | _GlueWCS.pixel_to_world_values (3-D) | 0.057 | 0.056 | 0.056 | 0.058 | 0.084 | 0.116 | 0.177 | 0.0564 | 0.0240 |
| siiv_lt | inner astropy.wcs.wcs.WCS.pixel_to_world_values (3-D) | 0.019 | 0.018 | 0.018 | 0.019 | 0.044 | 0.068 | 0.113 | 0.0190 | 0.0189 |
| siiv_lt | WCSWorld2PixelTransform.transform | ValueError('Expected 2 world coordinates, got 3') |
| sji2796 | WCSPixel2WorldTransform.transform | 0.352 | 0.349 | 0.348 | 0.358 | 0.422 | 0.518 | 0.861 | 0.3380 | 0.0967 |
| sji2796 | SlicedLowLevelWCS.pixel_to_world_values (2-D, what transform calls) | 0.343 | 0.347 | 0.344 | 0.353 | 0.413 | 0.517 | 0.720 | 0.3421 | 0.0738 |
| sji2796 | _GlueWCS.pixel_to_world_values (3-D) | 0.337 | 0.339 | 0.343 | 0.348 | 0.407 | 0.545 | 0.806 | 0.3325 | 0.0914 |
| sji2796 | inner gwcs.wcs._wcs.WCS.pixel_to_world_values (3-D) | 0.292 | 0.291 | 0.293 | 0.301 | 0.354 | 0.477 | 0.724 | 0.2854 | 0.0842 |
| sji2796 | WCSWorld2PixelTransform.transform | 2.352 | 2.095 | 2.034 | 2.356 | 2.197 | 2.510 | 3.081 | 2.1649 | 0.1686 |
| tan | WCSPixel2WorldTransform.transform | 0.0053 | 0.0054 | 0.0057 | 0.0090 | 0.047 | 0.170 | 0.282 | 0.0040 | 0.0569 |
| tan | WCS.pixel_to_world_values (2-D, what transform calls) | 0.0038 | 0.0039 | 0.0041 | 0.0073 | 0.041 | 0.144 | 0.269 | 0.0012 | 0.0534 |
| tan | WCSWorld2PixelTransform.transform | 0.013 | 0.013 | 0.013 | 0.020 | 0.098 | 0.346 | 0.670 | 0.0035 | 0.1318 |

sji1400 sites [['coord_range', 1], ['patch_path.update_spines', 4], ['sample.resampled_spines', 8], ['sample.update_spines', 8], ['shifted_pixel_to_world', 16]] site_ms {'patch_path.update_spines': 1.57, 'sample.update_spines': 2.91, 'shifted_pixel_to_world': 6.83, 'coord_range': 0.67, 'sample.resampled_spines': 3.45} points [[2, 12], [1000, 24], [2601, 1]]
   coords [(0, 'longitude', ['b', 'r', 't', 'l'], ['b', '#'], 6, 6), (1, 'latitude', ['b', 'r', 't', 'l'], ['l', '#'], 6, 6), (None, 'scalar', [], [], 0, 0)]
   static fingerprint identical True inputs identical True frame.update no-op True rss 1.25
   set-phase sites [['coord_range', 4], ['sample.resampled_spines', 32], ['sample.update_spines', 32], ['shifted_pixel_to_world', 64]]
siiv_spec sites [['coord_range', 1], ['patch_path.update_spines', 4], ['sample.resampled_spines', 12], ['sample.update_spines', 12], ['shifted_pixel_to_world', 24]] site_ms {'shifted_pixel_to_world': 2.5, 'sample.resampled_spines': 1.26, 'coord_range': 0.18, 'patch_path.update_spines': 0.35, 'sample.update_spines': 0.95} points [[2, 16], [1000, 36], [2601, 1]]
   coords [(0, 'scalar', ['b', '#'], ['b', '#'], 14, 14), (1, 'latitude', ['l', '#'], ['l', '#'], 6, 6), (2, 'longitude', ['r', '#'], ['r', '#'], 8, 8)]
   static fingerprint identical True inputs identical True frame.update no-op True rss 1.62
   set-phase sites [['coord_range', 4], ['sample.resampled_spines', 48], ['sample.update_spines', 48], ['shifted_pixel_to_world', 96]]
siiv_lt sites [['coord_range', 1], ['patch_path.update_spines', 4], ['sample.resampled_spines', 12], ['sample.update_spines', 12], ['shifted_pixel_to_world', 30]] site_ms {'shifted_pixel_to_world': 3.44, 'patch_path.update_spines': 0.36, 'coord_range': 0.23, 'sample.resampled_spines': 1.29, 'sample.update_spines': 0.93} points [[2, 16], [1000, 42], [2601, 1]]
   coords [(0, 'scalar', ['b', '#'], ['b', '#'], 14, 14), (1, 'latitude', ['l', '#'], ['l', '#'], 48, 48), (2, 'longitude', ['r', '#'], ['r', '#'], 14, 14)]
   static fingerprint identical True inputs identical True frame.update no-op True rss 1.62
   set-phase sites [['coord_range', 4], ['sample.resampled_spines', 48], ['sample.update_spines', 48], ['shifted_pixel_to_world', 120]]
sji2796 sites [['coord_range', 1], ['patch_path.update_spines', 4], ['sample.resampled_spines', 8], ['sample.update_spines', 8], ['shifted_pixel_to_world', 16]] site_ms {'patch_path.update_spines': 1.77, 'sample.resampled_spines': 3.87, 'sample.update_spines': 3.19, 'coord_range': 0.89, 'shifted_pixel_to_world': 7.4} points [[2, 12], [1000, 24], [2601, 1]]
   coords [(0, 'longitude', ['b', 'r', 't', 'l'], ['b', '#'], 10, 10), (1, 'latitude', ['b', 'r', 't', 'l'], ['l', '#'], 14, 14), (None, 'scalar', [], [], 0, 0)]
   static fingerprint identical True inputs identical True frame.update no-op True rss 1.08
   set-phase sites [['coord_range', 4], ['sample.resampled_spines', 32], ['sample.update_spines', 32], ['shifted_pixel_to_world', 64]]
tan sites [['coord_range', 1], ['patch_path.update_spines', 4], ['sample.resampled_spines', 8], ['sample.update_spines', 8], ['shifted_pixel_to_world', 16]] site_ms {'sample.resampled_spines': 0.35, 'shifted_pixel_to_world': 0.67, 'sample.update_spines': 0.06, 'patch_path.update_spines': 0.03, 'coord_range': 0.18} points [[2, 12], [1000, 24], [2601, 1]]
   coords [(0, 'longitude', ['b', 'r', 't', 'l'], ['b', '#'], 8, 8), (1, 'latitude', ['b', 'r', 't', 'l'], ['l', '#'], 6, 6)]
   static fingerprint identical True inputs identical True frame.update no-op True rss 0.68
