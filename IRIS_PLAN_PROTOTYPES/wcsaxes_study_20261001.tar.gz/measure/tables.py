"""Markdown tables from out_<case>.json."""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
CASES = [c for c in ("sji1400", "siiv_spec", "siiv_lt", "sji2796", "tan") if os.path.exists(f"{HERE}/out_{c}.json")]
R = {c: json.load(open(f"{HERE}/out_{c}.json")) for c in CASES}


def g(d, k):
    return d["stage_ms"].get(k, 0.0)


def ut(d):
    return sum(v for k, v in d["stage_ms"].items() if k.startswith("_update_ticks["))


rows = []
hdr = ("case", "size", "draw", "WCSAxes", "share", "image", "placement", "coord_range", "_update_ticks (per coord)",
       "of which sample", "auto", "grid", "Ticks.draw", "TickLabels.draw", "AxisLabels.draw", "frame.draw",
       "patch_path", "p2w calls (distinct)", "p2w ms (dup ms)", "pan draw", "pan WCSAxes")
print("| " + " | ".join(hdr) + " |")
print("|" + "---|" * len(hdr))
for c in CASES:
    for size in ("400x330", "1258x810"):
        s = R[c][size]["static"]
        p = R[c][size]["pan"]
        wcsax = g(s, "WCSAxes.draw_wcsaxes") + g(s, "frame._update_patch_path")
        pw = g(p, "WCSAxes.draw_wcsaxes") + g(p, "frame._update_patch_path")
        per = " / ".join(f"{v:.1f}" for k, v in sorted(s["stage_ms"].items()) if k.startswith("_update_ticks["))
        print("| " + " | ".join(str(x) for x in (
            c, size, f"{g(s, 'canvas.draw'):.1f}", f"{wcsax:.1f}", f"{100 * wcsax / g(s, 'canvas.draw'):.0f}%",
            f"{g(s, 'image.draw'):.1f}", f"{g(s, 'update_ticks_all'):.1f}", f"{g(s, 'CoordinatesMap.get_coord_range'):.2f}",
            per, f"{g(s, 'frame.sample'):.1f}", f"{g(s, 'auto_assign'):.2f}", f"{g(s, 'CoordinateHelper._draw_grid'):.2f}",
            f"{g(s, 'Ticks.draw'):.2f}", f"{g(s, 'TickLabels.draw'):.1f}", f"{g(s, 'AxisLabels.draw'):.1f}",
            f"{g(s, 'frame.draw'):.2f}", f"{g(s, 'frame._update_patch_path'):.2f}",
            f"{s['p2w']:.0f} ({s['p2w_distinct']:.0f})", f"{s['p2w_ms']:.1f} ({s['p2w_dup_ms']:.1f})",
            f"{g(p, 'canvas.draw'):.1f}", f"{pw:.1f}")) + " |")

print()
hdr = ("case", "size", "set phase (reset_wcs + 4 label sets)", "reset_wcs", "4x set_x/ylabel", "p2w in set phase",
       "direct set_axislabel phase", "step draw", "set_xlabel alone (p2w)")
print("| " + " | ".join(hdr) + " |")
print("|" + "---|" * len(hdr))
for c in CASES:
    for size in ("400x330", "1258x810"):
        r = R[c][size]
        a = r["set_xlabel_alone"]
        if "step_set_phase" not in r:
            print(f"| {c} | {size} | - | - | - | - | - | - | {g(a, 'WCSAxes.set_xlabel'):.1f} ({a['p2w']:.0f}) |")
            continue
        sp, sd, dr = r["step_set_phase"], r["step_draw"], r["step_set_phase_direct"]
        print(f"| {c} | {size} | {g(sp, 'glue_set_phase'):.1f} | {g(sp, 'WCSAxes.reset_wcs'):.2f} | "
              f"{g(sp, 'WCSAxes.set_xlabel') + g(sp, 'WCSAxes.set_ylabel'):.1f} | {sp['p2w']:.0f} ({sp['p2w_distinct']:.0f}) | "
              f"{g(dr, 'direct_set_phase'):.2f} | {g(sd, 'canvas.draw'):.1f} | {g(a, 'WCSAxes.set_xlabel'):.1f} ({a['p2w']:.0f}) |")

print()
print("| case | layer | 1 pt | 2 | 10 | 100 | 1000 | 2601 | 5000 | fixed ms | ms per 1000 pts |")
print("|---|---|---|---|---|---|---|---|---|---|---|")
for c in CASES:
    for name, d in R[c]["per_call"].items():
        if "error" in d:
            print(f"| {c} | {name} | {d['error']} |")
            continue
        ms = " | ".join(f"{v:.4f}" if v < 0.01 else f"{v:.3f}" for v in d["ms"].values())
        print(f"| {c} | {name} | {ms} | {d['fixed_ms']:.4f} | {d['per_1000pts_ms']:.4f} |")

print()
for c in CASES:
    s = R[c]["400x330"]["static"]
    print(c, "sites", s["sites"], "site_ms", {k: round(v, 2) for k, v in s["site_ms"].items()}, "points", s["points"])
    print("   coords", [(x["index"], x["type"], x["ticks_pos"], x["ticklabel_pos"], x["nticks"], x["nlabels"])
                       for x in R[c]["400x330"]["coords"]])
    print("   static fingerprint identical", s["fingerprint_identical"], "inputs identical", s["inputs_identical_to_prev_draw"],
          "frame.update no-op", R[c]["400x330"]["frame_update_is_noop"], "rss", round(R[c]["rss_gb"], 2))
    if "step_set_phase" in R[c]["400x330"]:
        sp = R[c]["400x330"]["step_set_phase"]
        print("   set-phase sites", sp["sites"])
