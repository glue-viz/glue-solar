"""Per-draw WCSAxes stage timing and WCS call accounting.

Plain matplotlib (Agg FigureCanvas) + WCSAxes made by glue's init_mpl (WCSAxesSubplot, glue margins,
tick labels 8 pt, axis labels 10 pt), reset_wcs(slices=<glue's wcsaxes_slice>, wcs=data.coords) as
glue's ImageViewer._set_wcs does; image drawn with imshow (not glue's FRB artist).

usage: python measure.py <case>   case in sji1400 sji2796 siiv_spec siiv_lt tan
"""
import collections
import glob
import json
import resource
import statistics as st
import sys
from time import perf_counter

sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
import numpy as np
import matplotlib

matplotlib.use("agg")
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure
from matplotlib.image import _ImageBase

from astropy.visualization.wcsaxes import core, coordinate_helpers as ch, frame as fr, wcsapi
from astropy.visualization.wcsaxes import coordinates_map as cm, ticklabels, ticks, axislabels
from astropy.visualization.wcsaxes import formatter_locator as fl
from glue.viewers.matplotlib.mpl_axes import init_mpl

CASE = sys.argv[1]
R = "/Users/nabil/DATA/IRIS"
N_STATIC, N_PAN, N_STEP, WARM = 30, 30, 15, 3

# ---------------------------------------------------------------- instrumentation
T = collections.defaultdict(float)
C = collections.Counter()
CALLS = []
STACK = []


def wrap(owner, name, label=None):
    f = owner.__dict__[name]
    lab = label or f"{owner.__name__}.{name}"

    def w(*a, **k):
        lb = lab(a[0]) if callable(lab) else lab
        STACK.append(lb)
        t = perf_counter()
        try:
            return f(*a, **k)
        finally:
            T[lb] += perf_counter() - t
            C[lb] += 1
            STACK.pop()

    setattr(owner, name, w)


def site():
    names = []
    fr_ = sys._getframe(2)
    while fr_ is not None and len(names) < 12:
        names.append(fr_.f_code.co_name)
        fr_ = fr_.f_back
    if "find_coordinate_range" in names:
        return "coord_range"
    if "shifted_pixel_to_world" in names:
        return "shifted_pixel_to_world"
    if "sample" in names:
        return "sample.update_spines" if "update_spines" in names else "sample.resampled_spines"
    if "_update_patch_path" in names:
        return "patch_path.update_spines"
    if "_draw_grid" in names:
        return "grid"
    return "/".join(names[:5])


def wrap_transform(cls, kind):
    f = cls.__dict__["transform"]

    def w(self, arr):
        t = perf_counter()
        try:
            return f(self, arr)
        finally:
            a = np.ascontiguousarray(arr)
            CALLS.append(dict(kind=kind, n=len(a), key=hash((a.shape, a.tobytes())), dt=perf_counter() - t,
                              site=site(), stage=STACK[-1] if STACK else "-", wcs=id(self.wcs)))

    cls.transform = w
    cls.transform_non_affine = w


def instrument():
    wrap(FigureCanvasAgg, "draw", "canvas.draw")
    wrap(core.WCSAxes, "draw", "WCSAxes.draw")
    wrap(core.WCSAxes, "draw_wcsaxes")
    wrap(core.WCSAxes, "_update_tick_and_label_positions", "update_ticks_all")
    wrap(core.WCSAxes, "set_xlabel")
    wrap(core.WCSAxes, "set_ylabel")
    wrap(core.WCSAxes, "reset_wcs")
    wrap(fr.BaseFrame, "_update_patch_path", "frame._update_patch_path")
    wrap(fr.BaseFrame, "sample", "frame.sample")
    wrap(fr.BaseFrame, "draw", "frame.draw")
    wrap(cm.CoordinatesMap, "get_coord_range")
    wrap(ch.CoordinateHelper, "_update_ticks", lambda s: f"_update_ticks[{s.coord_index}]")
    wrap(ch.CoordinateHelper, "_compute_ticks")
    wrap(ch.CoordinateHelper, "_draw_grid")
    wrap(ch.CoordinateHelper, "_draw_ticks")
    wrap(ch.CoordinateHelper, "_draw_axislabels")
    wrap(ticks.Ticks, "draw", "Ticks.draw")
    wrap(ticklabels.TickLabels, "draw", "TickLabels.draw")
    wrap(axislabels.AxisLabels, "draw", "AxisLabels.draw")
    for cls in (fl.AngleFormatterLocator, fl.ScalarFormatterLocator):
        wrap(cls, "locator", "locator")
        wrap(cls, "formatter", "formatter")
    wrap(_ImageBase, "draw", "image.draw")
    core.auto_assign_coord_positions = _timed_fn(core.auto_assign_coord_positions, "auto_assign")
    wrap_transform(wcsapi.WCSPixel2WorldTransform, "p2w")
    wrap_transform(wcsapi.WCSWorld2PixelTransform, "w2p")


def _timed_fn(f, lab):
    def w(*a, **k):
        STACK.append(lab)
        t = perf_counter()
        try:
            return f(*a, **k)
        finally:
            T[lab] += perf_counter() - t
            C[lab] += 1
            STACK.pop()

    return w


def reset():
    T.clear(), C.clear(), CALLS.clear()


def snapshot():
    p2w = [c for c in CALLS if c["kind"] == "p2w"]
    w2p = [c for c in CALLS if c["kind"] == "w2p"]
    keys = [c["key"] for c in p2w]
    return dict(
        T={k: v * 1e3 for k, v in T.items()}, C=dict(C),
        p2w=len(p2w), p2w_distinct=len(set(keys)), w2p=len(w2p),
        p2w_ms=sum(c["dt"] for c in p2w) * 1e3,
        p2w_dup_ms=sum(c["dt"] for i, c in enumerate(p2w) if c["key"] in set(keys[:i])) * 1e3,
        points=sorted(collections.Counter(c["n"] for c in p2w).items()),
        sites=sorted(collections.Counter(c["site"] for c in p2w).items()),
        site_ms={s: sum(c["dt"] for c in p2w if c["site"] == s) * 1e3 for s in {c["site"] for c in p2w}},
        stage_calls=sorted(collections.Counter(c["stage"] for c in p2w).items()),
        keys=keys,
    )


# ---------------------------------------------------------------- cases
def load():
    """Return (wcs, data array accessor, x_axis, y_axis, slices(index)->list, step indices, aspect)."""
    from glue_solar.sources.loaders.iris import image_data, raster_data
    import glue_solar

    print("glue_solar", glue_solar.__file__)
    if CASE in ("sji1400", "sji2796"):
        pat = "4000255147_SJI_1400_t000.fits.gz" if CASE == "sji1400" else "4000005156_SJI_2796_t000_deconvolved.fits.gz"
        d = image_data(glob.glob(f"{R}/*{pat}")[0])
        arr = d[d.main_components[0]]
        nt = arr.shape[0]
        return d, d.coords, (lambda i: arr[i]), 2, 1, list(range(nt // 2, nt // 2 + N_STEP + 1)), "equal"
    if CASE.startswith("siiv"):
        d = raster_data(sorted(glob.glob(f"{R}/*4000255147_raster/*_r00000.fits")), windows=["Si IV 1403"])[0]
        arr = d[d.main_components[0]]
        if CASE == "siiv_spec":  # x=λ (numpy 2), y=slit (1), exposure sliced
            n = arr.shape[0]
            return d, d.coords, (lambda i: arr[i]), 2, 1, list(range(n // 2, n // 2 + N_STEP + 1)), "auto"
        n = arr.shape[1]  # λ-time: x=λ (2), y=exposure (0), slit sliced
        return d, d.coords, (lambda i: arr[:, i, :]), 2, 0, list(range(n // 2, n // 2 + N_STEP + 1)), "auto"
    # plain 2-D helioprojective TAN map, 1024x1024 at 0.6"/px
    from astropy.wcs import WCS

    w = WCS(naxis=2)
    w.wcs.ctype = ["HPLN-TAN", "HPLT-TAN"]
    w.wcs.cunit = ["arcsec", "arcsec"]
    w.wcs.cdelt = [0.6, 0.6]
    w.wcs.crpix = [512.5, 512.5]
    w.wcs.crval = [-300.0, 200.0]
    w.wcs.dateobs = "2013-09-02T16:39:35"
    img = np.random.default_rng(0).random((1024, 1024), dtype=np.float32)
    return None, w, (lambda i: img), 1, 0, [None], "equal"


def glue_slices(ndim, x, y, idx):
    """glue ImageViewerState.wcsaxes_slice for numpy axes x, y and index idx on the other axis."""
    if ndim == 2:
        return None
    s = ["x" if i == x else "y" if i == y else idx for i in range(ndim)]
    return s[::-1]


def fingerprint(ax):
    out = []
    for coord in ax.coords:
        tl = coord._ticklabels
        out.append((coord.coord_index, tuple((a, tuple(tl.text[a])) for a in sorted(tl.text)),
                    tuple((a, tuple(np.round(np.ravel(coord._ticks.pixel[a]), 6))) for a in sorted(coord._ticks.pixel))))
    return out


def coord_info(ax):
    info = []
    for coord in ax.coords:
        info.append(dict(index=coord.coord_index, type=coord.coord_type,
                         ticks_pos=coord.get_ticks_position(), ticklabel_pos=coord.get_ticklabel_position(),
                         axislabel_pos=coord.get_axislabel_position(),
                         nticks=sum(len(v) for v in coord._ticks.world.values()),
                         nlabels=sum(len(v) for v in coord._ticklabels.text.values()),
                         ticks_visible=coord._ticks.get_visible(), labels_visible=coord._ticklabels.get_visible()))
    return info


def med(rows, f):
    return round(st.median(f(r) for r in rows), 3)


def summarize(rows):
    stages = sorted({k for r in rows for k in r["T"]})
    out = dict(n=len(rows))
    out["stage_ms"] = {k: med(rows, lambda r: r["T"].get(k, 0.0)) for k in stages}
    out["stage_calls"] = {k: med(rows, lambda r: r["C"].get(k, 0)) for k in stages}
    for k in ("p2w", "p2w_distinct", "w2p", "p2w_ms", "p2w_dup_ms"):
        out[k] = med(rows, lambda r: r[k])
    out["points"] = rows[-1]["points"]
    out["sites"] = rows[-1]["sites"]
    out["site_ms"] = {k: med(rows, lambda r: r["site_ms"].get(k, 0.0)) for k in rows[-1]["site_ms"]}
    out["stage_of_calls"] = rows[-1]["stage_calls"]
    return out


def make_axes(w, h):
    fig = Figure(figsize=(w / 100, h / 100), dpi=100)
    FigureCanvasAgg(fig)
    _, ax = init_mpl(figure=fig, wcs=True)
    W, H = w / 100, h / 100
    ax.set_position([1 / W, 0.5 / H, 1 - 1.25 / W, 1 - 0.75 / H])  # glue margins [l, r, b, t] = [1, .25, .5, .25] in
    return fig, ax


def setup_wcs(ax, wcs, slices, labels):
    ax.reset_wcs(slices=slices, wcs=wcs)
    for c in ax.coords:
        c.set_ticklabel(size=8)
    # glue's _update_axes puts the world labels on through set_xlabel/set_ylabel
    ax.set_xlabel(labels[0], size=10)
    ax.set_ylabel(labels[1], size=10)


def run_size(data, wcs, img_of, x, y, steps, aspect, w, h):
    ndim = 2 if data is None else data.ndim
    labels = ("x world", "y world") if data is None else (data.world_component_ids[x].label, data.world_component_ids[y].label)
    fig, ax = make_axes(w, h)
    im0 = img_of(steps[0])
    setup_wcs(ax, wcs, glue_slices(ndim, x, y, steps[0]), labels)
    im = ax.imshow(np.asarray(im0), origin="lower", cmap="gray", interpolation="nearest", aspect=aspect)
    ny, nx = np.asarray(im0).shape
    ax.set_xlim(-0.5, nx - 0.5)
    ax.set_ylim(-0.5, ny - 0.5)
    canvas = fig.canvas
    res = dict(size=f"{w}x{h}", frame_update_is_noop=type(ax.coords.frame).update is collections.OrderedDict.update)
    for _ in range(WARM):
        canvas.draw()

    # A. static redraw: nothing changed
    rows, fps, keysets = [], [], []
    for _ in range(N_STATIC):
        reset()
        canvas.draw()
        s = snapshot()
        rows.append(s)
        fps.append(fingerprint(ax))
        keysets.append(s["keys"])
    res["static"] = summarize(rows)
    res["static"]["fingerprint_identical"] = all(f == fps[0] for f in fps)
    res["static"]["inputs_identical_to_prev_draw"] = all(k == keysets[0] for k in keysets)
    res["coords"] = coord_info(ax)
    res["fingerprint"] = repr(fps[0])[:600]

    # B. pan: x limits move by +-1 data pixel each draw, WCS unchanged
    rows = []
    x0, x1 = ax.get_xlim()
    for i in range(N_PAN + WARM):
        d = 1.0 if i % 2 == 0 else 0.0
        ax.set_xlim(x0 + d, x1 + d)
        reset()
        canvas.draw()
        if i >= WARM:
            rows.append(snapshot())
    ax.set_xlim(x0, x1)
    res["pan"] = summarize(rows)

    # C. eager label path: one set_xlabel / set_ylabel with nothing else changed
    rows = []
    for _ in range(N_STATIC):
        reset()
        ax.set_xlabel(labels[0], size=10)
        rows.append(snapshot())
    res["set_xlabel_alone"] = summarize(rows)

    # D. glue slice step: reset_wcs(next slice) + x/y label '' round trip (4 sets), then a draw
    if ndim == 3:
        rows_set, rows_draw, rows_direct = [], [], []
        for k, idx in enumerate(steps[1:] + steps[:1]):
            reset()
            t0 = perf_counter()
            ax.reset_wcs(slices=glue_slices(ndim, x, y, idx), wcs=wcs)
            ax.set_xlabel("", size=10)
            ax.set_ylabel("", size=10)
            ax.set_xlabel(labels[0], size=10)
            ax.set_ylabel(labels[1], size=10)
            for c in ax.coords:
                c.set_ticklabel(size=8)
            s = snapshot()
            s["T"]["glue_set_phase"] = (perf_counter() - t0) * 1e3
            rows_set.append(s)
            im.set_data(np.asarray(img_of(idx)))
            reset()
            canvas.draw()
            rows_draw.append(snapshot())
        res["step_set_phase"] = summarize(rows_set)
        res["step_draw"] = summarize(rows_draw)
        # same step with labels put on the coords directly (no WCSAxes.set_xlabel/set_ylabel)
        for idx in steps[1:] + steps[:1]:
            reset()
            t0 = perf_counter()
            ax.reset_wcs(slices=glue_slices(ndim, x, y, idx), wcs=wcs)
            ax.coords[ndim - 1 - x].set_axislabel(labels[0], size=10)
            ax.coords[ndim - 1 - y].set_axislabel(labels[1], size=10)
            for c in ax.coords:
                c.set_ticklabel(size=8)
            s = snapshot()
            s["T"]["direct_set_phase"] = (perf_counter() - t0) * 1e3
            rows_direct.append(s)
        res["step_set_phase_direct"] = summarize(rows_direct)
    return res, ax


def per_call_cost(data, wcs, ax):
    """Median time per call vs point count, for each layer under WCSAxes' transform."""
    tr = ax.coords._transform
    x0, x1 = ax.get_xlim()
    y0, y1 = ax.get_ylim()
    rng = np.random.default_rng(1)
    layers = {"WCSPixel2WorldTransform.transform": lambda p: tr.transform(p)}
    low = tr.wcs
    layers[f"{type(low).__name__}.pixel_to_world_values (2-D, what transform calls)"] = (
        lambda p: low.pixel_to_world_values(*(p.T[::-1] if tr.invert_xy else p.T)))
    if data is not None:
        glw = data.coords
        fixed = list(low._slices_pixel) if hasattr(low, "_slices_pixel") else None

        def full(p, fn):
            cols = list(p.T[::-1] if tr.invert_xy else p.T)
            it = iter(cols)
            args = [next(it) if isinstance(s, slice) else np.full(len(p), float(s)) for s in fixed]
            return fn(*args)

        layers["_GlueWCS.pixel_to_world_values (3-D)"] = lambda p: full(p, glw.pixel_to_world_values)
        layers[f"inner {type(glw._wcs).__module__}.{type(glw._wcs).__name__}.pixel_to_world_values (3-D)"] = (
            lambda p: full(p, glw._wcs.pixel_to_world_values))
    # world -> pixel too (the inverse WCSAxes uses for grids / plot_coord)
    inv = tr.inverted()
    layers["WCSWorld2PixelTransform.transform"] = lambda p: inv.transform(tr.transform(p))
    out = {}
    for name, fn in layers.items():
        row = {}
        try:
            fn(np.zeros((1, 2)))
        except Exception as e:  # e.g. world->pixel of a 3-world/2-pixel sliced WCS
            out[name] = dict(error=repr(e)[:200])
            continue
        for n in (1, 2, 10, 100, 1000, 2601, 5000):
            p = np.column_stack([rng.uniform(x0, x1, n), rng.uniform(y0, y1, n)])
            fn(p)
            reps = 30 if n <= 1000 else 10
            ts = []
            for _ in range(reps):
                t = perf_counter()
                fn(p)
                ts.append(perf_counter() - t)
            row[n] = st.median(ts) * 1e3
        ns = np.array(list(row))
        a = np.polyfit(ns, np.array(list(row.values())), 1)
        out[name] = dict(ms=row, fixed_ms=round(float(a[1]), 4), per_1000pts_ms=round(float(a[0]) * 1000, 4))
    # the inverse layer above includes a forward call: subtract it
    out["WCSWorld2PixelTransform.transform"]["note"] = "includes one forward transform; subtract the first row"
    return out


def main():
    data, wcs, img_of, x, y, steps, aspect = load()
    instrument()
    result = dict(case=CASE)
    for w, h in ((400, 330), (1258, 810)):
        res, ax = run_size(data, wcs, img_of, x, y, steps, aspect, w, h)
        result[res["size"]] = res
        if (w, h) == (400, 330):
            # reset to the first slice so the cost table uses the static WCS
            ax.reset_wcs(slices=glue_slices(2 if data is None else data.ndim, x, y, steps[0]), wcs=wcs)
            result["per_call"] = per_call_cost(data, wcs, ax)
    result["rss_gb"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1e9
    json.dump(result, open(f"{sys.path[1]}/out_{CASE}.json", "w"), indent=1, default=str)
    print("done", CASE, "rss GB", result["rss_gb"])


main()
