import sys, glob, resource
sys.path.insert(0, '/Users/nabil/Git/glue-solar-main')
import glue_solar; print(glue_solar.__file__)
from glue_solar.sources.loaders.iris import raster_data, image_data
R = '/Users/nabil/DATA/IRIS'
for kind in sys.argv[1:]:
    if kind == 'sji1400':
        d = image_data(glob.glob(f'{R}/*4000255147_SJI_1400_t000.fits.gz')[0])
    elif kind == 'sji2796':
        d = image_data(glob.glob(f'{R}/*4000005156_SJI_2796_t000_deconvolved.fits.gz')[0])
    elif kind == 'siiv':
        d = raster_data(sorted(glob.glob(f'{R}/*4000255147_raster/*_r00000.fits')), windows=['Si IV 1403'])[0]
    w = d.coords
    print(kind, d.label, d.shape, type(w._wcs).__module__, type(w._wcs).__name__, w.pixel_n_dim, w.world_n_dim, w.world_axis_physical_types, w.world_axis_units)
    print(' corr', w.axis_correlation_matrix.astype(int).tolist())
    print(' rss GB', resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1e9)
