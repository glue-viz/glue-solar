"""WCS time of one static draw's p2w inputs: as WCSAxes calls them, distinct only, and one concatenated call."""
import glob, sys, statistics as st
from time import perf_counter
sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
import numpy as np
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure
from astropy.visualization.wcsaxes import wcsapi
from glue.viewers.matplotlib.mpl_axes import init_mpl

case = sys.argv[1]
R = "/Users/nabil/DATA/IRIS"
if case.startswith("sji"):
    from glue_solar.sources.loaders.iris import image_data
    pat = "4000255147_SJI_1400_t000.fits.gz" if case == "sji1400" else "4000005156_SJI_2796_t000_deconvolved.fits.gz"
    d = image_data(glob.glob(f"{R}/*{pat}")[0]); a = d[d.main_components[0]]; t = a.shape[0] // 2
    wcs, slices, img, aspect = d.coords, ["x", "y", t], a[t], "equal"
elif case.startswith("siiv"):
    from glue_solar.sources.loaders.iris import raster_data
    d = raster_data(sorted(glob.glob(f"{R}/*4000255147_raster/*_r00000.fits")), windows=["Si IV 1403"])[0]; a = d[d.main_components[0]]
    if case == "siiv_spec":
        wcs, slices, img = d.coords, ["x", "y", a.shape[0] // 2], a[a.shape[0] // 2]
    else:
        wcs, slices, img = d.coords, ["x", a.shape[1] // 2, "y"], a[:, a.shape[1] // 2, :]
    aspect = "auto"
else:
    from astropy.wcs import WCS
    wcs = WCS(naxis=2); wcs.wcs.ctype = ["HPLN-TAN", "HPLT-TAN"]; wcs.wcs.cunit = ["arcsec"] * 2
    wcs.wcs.cdelt = [0.6, 0.6]; wcs.wcs.crpix = [512.5, 512.5]; wcs.wcs.crval = [-300.0, 200.0]
    slices, img, aspect = None, np.zeros((1024, 1024), np.float32), "equal"

fig = Figure(figsize=(4, 3.3), dpi=100); FigureCanvasAgg(fig)
_, ax = init_mpl(figure=fig, wcs=True)
ax.set_position([1 / 4, 0.5 / 3.3, 1 - 1.25 / 4, 1 - 0.75 / 3.3])
ax.reset_wcs(slices=slices, wcs=wcs)
ax.imshow(np.asarray(img), origin="lower", aspect=aspect)
fig.canvas.draw()
SEEN = []
f = wcsapi.WCSPixel2WorldTransform.transform
def w(self, p):
    SEEN.append(np.array(p, float)); return f(self, p)
wcsapi.WCSPixel2WorldTransform.transform = w
fig.canvas.draw()
wcsapi.WCSPixel2WorldTransform.transform = f
tr = ax.coords._transform
uniq = {}
for p in SEEN:
    uniq.setdefault(p.tobytes(), p)
uniq = list(uniq.values())
cat = np.vstack(uniq)

def timeit(fn, reps=30):
    fn(); ts = []
    for _ in range(reps):
        t = perf_counter(); fn(); ts.append(perf_counter() - t)
    return st.median(ts) * 1e3

all_ms = timeit(lambda: [tr.transform(p) for p in SEEN])
uniq_ms = timeit(lambda: [tr.transform(p) for p in uniq])
cat_ms = timeit(lambda: tr.transform(cat))
same = np.allclose(np.vstack([tr.transform(p) for p in uniq]), tr.transform(cat), equal_nan=True)
print(f"{case}: calls {len(SEEN)} ({sum(len(p) for p in SEEN)} pts) {all_ms:.2f} ms | distinct {len(uniq)} ({len(cat)} pts) {uniq_ms:.2f} ms | one concatenated call {cat_ms:.2f} ms | identical {same}")
