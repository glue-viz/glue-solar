Upstream context: WCSAxes performance. Everything here was read-only: gh api/search and git show/log on ~/Git/astropy. Nothing was edited or posted. The scratch outputs (search*.txt, d*.txt, main_*.py) are in /private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes/upstream/.

1. Earlier WCSAxes speed work in astropy (all merged)
- #7568 (astrofrog, 2018, https://github.com/astropy/astropy/pull/7568): batches every contour path through one transform; 10-1000x faster contours. This is the only earlier "batch the transforms" change and it covers contours only.
- #14164 (ayshih, 2022, https://github.com/astropy/astropy/pull/14164): in `_update_ticks`, reuse the spine world coordinates that were already computed and bail out when a spine is all NaN. Cadair and larrybradley approved it and backported it to 5.2 as a bugfix.
- Issue #16362 and PR #16366 (ayshih, merged 2024-09 by astrofrog; https://github.com/astropy/astropy/issues/16362, https://github.com/astropy/astropy/pull/16366): `find_coordinate_range` (a 50x50 sample) ran 4 times per draw; it now runs once. The result is kept in `coords._coord_range`: set at main core.py:572 (8.0.1 core.py:490-515) and deleted after the draw (main core.py:597-604). The measured gain was only about 8% (66 to 61 ms, 483 to 448 ms with an overlay). The PR does not avoid repeat work across draws.
- #17404 (thuiop, 2024): imshow was slow because of a `minversion(PIL)` call.
- #17243 (astrofrog, merged 2024-10-25, https://github.com/astropy/astropy/pull/17243): automatic ('#') placement of ticks and labels (_auto.py). Its commit 46a541d624 ("Fixed non-image tests", git -C ~/Git/astropy show 46a541d624) added the eager `self._update_tick_and_label_positions()` call to set_xlabel, set_ylabel, get_xlabel, get_ylabel and tick_params(axis='x'/'y'). This is the source of R1 / events#1.
  - Main lines: core.py:685, 715, 735, 744, 1046.
  - 8.0.1 lines: core.py:598, 615, 635, 644, 935.
  - Why it is eager: the coordinate on spine b/l is only known after the ticks are computed and auto_assign_coord_positions has run.
  - A lazy-label fix must keep this behaviour: store the label and resolve it in draw_wcsaxes. get_xlabel still has to work before any draw.
  - Tests that cover it: test_misc.py:155-172, 549-574 and 664-674; test_images.py:602 and 1150.
- The `# TODO: this method should be optimized for speed` comment is still at the top of `_update_ticks` (main coordinate_helpers.py:988).

2. Open items that match ours
- glue#1587 (astrofrog, 2018, open, https://github.com/glue-viz/glue/issues/1587): "slicing is quite slow in the image viewer… requires implementing redraw_in_frame properly for WCSAxes to avoid redrawing the labels/ticks every time". This is the same as our R1/R18.
- glue#1823 (open): the image viewer is slow with overplotted points.
- sunpy#6652 (hayesla, 2022, open, https://github.com/sunpy/sunpy/issues/6652): `draw_grid` takes 0.38 s alone and 1.56 s with the grid. ayshih profiled it: "nearly all of the time is sunk in … `_update_ticks()`". He also notes that pyplot renders more than once. This led to #14164.
- astropy#12446 (open, https://github.com/astropy/astropy/issues/12446): contour gridlines are created as artists during draw. QuLogic warns against changing artists inside draw, so any caching of drawn artists has to respect this.
- sunpy#4971 (merged 2021): the WCS animator updates only when the integer index changes. This is precedent for skipping redundant slice updates.

3. No prior work was found on:
- caching ticks across draws,
- memoising `pixel_to_world_values` within a draw (our 17-20 distinct inputs out of 37-59 calls),
- lazy axis labels,
- blitting / redraw_in_frame in astropy.

The searches that returned nothing were "redraw_in_frame", "wcsaxes blit", "wcsaxes animation" and "coordinate_range_samples". GitHub search then hit its rate limit before ndcube and gwcs could be searched.

4. What reviewers have said about performance changes
- astrofrog on #16362, the key constraint: "hash(wcs) does not change even if some of the transformation parameters change" for FITS WCS. So caching keyed on the WCS is unsafe. He suggested a context scoped to one draw that assumes the WCS and the transform graph do not change, and `_coord_range` is that pattern. A per-draw memo of `pixel_to_world_values` fits it; a cache across draws would need explicit invalidation (reset_wcs, limits, slices).
- astrofrog on #16366 asked for real numbers ("How much is the overall performance improvement … for solar data?") and questioned mixed results.
- pllim: use the `benchmark` label. It runs `asv continuous --factor 1.3` against astropy-benchmarks (.github/workflows/ci_benchmark.yml:18 and 75). She notes the results are flaky. ayshih adds: "benchmarking plotting is a bit maddening".
- neutrinoceros on #17404: follow local idioms; keep costly checks out of loops.
- astrofrog and larrybradley on #10936: the underscore methods are private and can change without deprecation, so `_update_tick_and_label_positions` and `_update_ticks` are free to change.
- Small, measured performance PRs have been merged quickly and even backported (#14164).
- There is a `performance` changelog type (used in #16366, enabled by #16694).

5. Maintainers
- .github/CODEOWNERS: `astropy/visualization @astrofrog @larrybradley`; `astropy/wcs/wcsapi @astrofrog`.
- Commits to wcsaxes since 2023 (no merges): Thomas Robitaille 90, Albert Shih 15, Clément Robert 15, Stuart Mumford 11, Nabil Freij 3.
- Who does what:
  - astrofrog is the original author and main reviewer and merger.
  - ayshih (sunpy) did the performance work and the tick-label placement rewrite (#19057, https://github.com/astropy/astropy/pull/19057).
  - Cadair did APE-14 and sliced-WCS support (#8885, #9392).
  - dstansby did the refactors (#10936, #12630, which moved tick-label pixel coordinates to draw time because computing them before draw "is not a safe thing to do").
  - pllim, neutrinoceros and larrybradley handle CI and merges.
- Recently active: astrofrog's #20221 (merged 2026-09-11) is 18 fixes from an AI-assisted review. They include removing a dead axis_correlation_matrix computation (55f747a129) and an identity dpi transform from ticks (8d3d17c50a). #20434 added numpydoc. #19801 is larrybradley's.
- Six wcsaxes PRs are open. #20480 (astrofrog, frame parsing) and #20018 (minor ticks) are the ones that touch nearby code.
- The #20221 PR body contains an embedded instruction aimed at agents. I ignored it.

6. Your own work (nabobalis)
- #20499 (https://github.com/astropy/astropy/pull/20499): merged 2026-09-28 by astrofrog, milestone v8.1.0. astrofrog's review: "Good catch… I think the test is fine length-wise". It changes only the `_auto.py:64` visibility condition and adds a test in test_coordinate_helpers.py.
- #14251 (merged 2023): `_transform_plot_args` converted to degrees instead of coord_unit.
- Issue #18219 (closed): tick label format for an angular axis with no units.
- crop_gwcs branch: one commit, feec07c4eb (2026-09-08), "Support a single world object in world_to_pixel on 1D sliced FITS WCS". Diff: high_level_api.py +12, wrappers/sliced_wcs.py +56, tests +89, docs/changes/wcs/19930.feature.rst. Its PR #19930 ("Support partial world inputs for 1D slices of linear FITS WCS") was closed without merging. It does not touch wcsaxes and is unrelated to draw speed.

7. Version drift (important for prototypes)
- Installed 8.0.1 (tagged 2026-07-04) has none of #19057, #19801, #20221, #20434 or #20499.
- `git diff --stat v8.0.1 origin/main -- astropy/visualization/wcsaxes` gives 19 files, +1015/-129. core.py, coordinate_helpers.py, coordinates_map.py, _auto.py and ticks.py all differ.
- Monkeypatches written against 8.0.1 need rechecking on main before an upstream PR. Line numbers shift, for example `_update_tick_and_label_positions` is 8.0.1 core.py:490 but main core.py:556.

8. How the tests work
- Non-image tests: test_misc.py, test_coordinate_helpers.py, test_transforms.py, test_wcsapi.py and others under astropy/visualization/wcsaxes/tests/. These are plain pytest runs.
- Figure tests use `@figure_test` (astropy/tests/figures/helpers.py:10). It wraps `pytest.mark.mpl_image_compare` with tolerance 0 and no Software metadata, and marks the test remote_data.
- Figure test counts: test_images.py 48, test_frame.py 5, test_transform_coord_meta.py 4, test_wcsapi.py 3.
- Hashes are kept in astropy/tests/figures/py312-test-image-mpl380-cov.json and py312-test-image-mpldev-cov.json. Run with `tox -e py312-test-image-mpl380-cov` (tox.ini:26 sets the hash-library path and the baseline path, which points at astropy/astropy-figure-tests).
- The hashes are only valid on Linux with the pinned freetype; the testguide advises against running them locally on macOS.
- When a hash changes, you download the JSON from the CI summary page. CircleCI updates the baseline images after merge (docs/development/testguide.rst:669-750).
- A performance change that leaves the pixels unchanged should keep every hash. Any hash change is a red flag reviewers will ask about.
- Benchmarks: astropy-benchmarks benchmarks/visualization/wcsaxes.py has 5 asv benchmarks:
  - time_basic_plot
  - time_basic_plot_with_grid
  - time_basic_plot_with_grid_and_overlay
  - two contour-with-transform benchmarks

  All of them use 2-D FITS celestial WCS (the MSX/2MASS headers). None uses an APE-14, sliced or gWCS WCS, where our cost is. An upstream performance PR would probably need a new benchmark there (for example a sliced 3-D WCS or a slow WCS), because the existing ones barely move. #16366 showed no change on them.

Key numbers: #16366: find_coordinate_range went from 4 runs per draw to 1; measured 66 to 61 ms (no overlay) and 483 to 448 ms (with overlay), about 8%; each find_coordinate_range run costs 3 ms (base) or 13 ms (overlay). sunpy#6652: 0.38 s without the grid, 1.56 s with it, nearly all in _update_ticks. #7568: contours 14.5 s to 198 ms. Eager tick placement comes from #17243, commit 46a541d624 (2024-10-23): main core.py:685/715/735/744/1046, 8.0.1 core.py:598/615/635/644/935. _coord_range precompute: main core.py:556-583 and 597-604, 8.0.1 core.py:490-515 and 529. TODO comment at main coordinate_helpers.py:988. Drift v8.0.1 to main in wcsaxes: 19 files, +1015/-129. Benchmark CI: asv factor 1.3, 5 wcsaxes benchmarks, all 2-D FITS. Figure tests: 48 in test_images.py, tolerance 0, Linux-only hashes. CODEOWNERS: astrofrog, larrybradley. Commits since 2023: astrofrog 90, ayshih 15, nabobalis 3. #20499 merged 2026-09-28 for v8.1.0. The crop_gwcs branch is 1 commit (feec07c4eb, +157/-1 across 4 files, PR #19930 closed unmerged) and does not touch wcsaxes. Open issues that match ours: glue#1587 (2018), glue#1823, sunpy#6652 (2022), astropy#12446 (2021).
