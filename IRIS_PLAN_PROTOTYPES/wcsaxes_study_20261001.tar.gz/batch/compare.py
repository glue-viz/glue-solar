"""Identity and timing of wcsaxes_batch against stock astropy 8.0.1, one case per process.

Plain matplotlib (Agg FigureCanvas). IRIS cases use glue's init_mpl axes, glue margins, 8 pt tick
labels, 10 pt axis labels and reset_wcs(slices=<glue's wcsaxes_slice>) as in ../measure/measure.py.

usage: python compare.py <case>
  IRIS: sji1400 sji2796 siiv_spec siiv_lt tan
  synthetic (identity only): rot allsky allsky_rect spec1d
"""
import collections
import glob
import os
import hashlib
import json
import resource
import statistics as st
import sys
import warnings
from time import perf_counter

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
sys.path.insert(0, HERE)
import numpy as np
import matplotlib

matplotlib.use("agg")
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure

import astropy
from astropy.visualization.wcsaxes import core, wcsapi, frame as fr
from astropy.wcs import WCS

import wcsaxes_batch as B

CASE = sys.argv[1]
R = "/Users/nabil/DATA/IRIS"
IRIS = CASE in ("sji1400", "sji2796", "siiv_spec", "siiv_lt", "tan")
warnings.simplefilter("ignore")

# ---------------------------------------------------------------- WCS call counter + timers
CNT = collections.Counter()


def _count(cls, kind):
    f = cls.__dict__["transform"]

    def w(self, arr):
        CNT[kind] += 1
        CNT[kind + "_pts"] += len(arr)
        return f(self, arr)

    cls.transform = cls.transform_non_affine = w


_count(wcsapi.WCSPixel2WorldTransform, "p2w")
_count(wcsapi.WCSWorld2PixelTransform, "w2p")
TT = collections.defaultdict(float)


def _timed(owner, name):
    f = owner.__dict__[name]

    def w(*a, **k):
        t = perf_counter()
        try:
            return f(*a, **k)
        finally:
            TT[name] += perf_counter() - t

    setattr(owner, name, w)


_timed(core.WCSAxes, "draw_wcsaxes")
_timed(fr.BaseFrame, "_update_patch_path")


def mode(on):
    (B.install if on else B.uninstall)()


# ---------------------------------------------------------------- cases
def glue_slices(ndim, x, y, idx):
    if ndim == 2:
        return None
    s = ["x" if i == x else "y" if i == y else idx for i in range(ndim)]
    return s[::-1]


def load():
    """(ndim, wcs, img_of(i), x, y, steps, aspect, labels)."""
    if CASE in ("sji1400", "sji2796"):
        from glue_solar.sources.loaders.iris import image_data
        import glue_solar

        print("glue_solar", glue_solar.__file__)
        pat = "4000255147_SJI_1400_t000.fits.gz" if CASE == "sji1400" else "4000005156_SJI_2796_t000_deconvolved.fits.gz"
        d = image_data(glob.glob(f"{R}/*{pat}")[0])
        arr = d[d.main_components[0]]
        nt = arr.shape[0]
        labels = (d.world_component_ids[2].label, d.world_component_ids[1].label)
        return 3, d.coords, (lambda i: arr[i]), 2, 1, list(range(nt // 2, nt // 2 + 16)) + [0, nt - 1], "equal", labels
    if CASE.startswith("siiv"):
        from glue_solar.sources.loaders.iris import raster_data
        import glue_solar

        print("glue_solar", glue_solar.__file__)
        d = raster_data(sorted(glob.glob(f"{R}/*4000255147_raster/*_r00000.fits")), windows=["Si IV 1403"])[0]
        arr = d[d.main_components[0]]
        if CASE == "siiv_spec":
            n = arr.shape[0]
            labels = (d.world_component_ids[2].label, d.world_component_ids[1].label)
            return 3, d.coords, (lambda i: arr[i]), 2, 1, list(range(n // 2, n // 2 + 16)) + [0, n - 1], "auto", labels
        n = arr.shape[1]
        labels = (d.world_component_ids[2].label, d.world_component_ids[0].label)
        return 3, d.coords, (lambda i: arr[:, i, :]), 2, 0, list(range(n // 2, n // 2 + 16)) + [0, n - 1], "auto", labels
    w = WCS(naxis=2)
    w.wcs.ctype = ["HPLN-TAN", "HPLT-TAN"]
    w.wcs.cunit = ["arcsec", "arcsec"]
    w.wcs.cdelt = [0.6, 0.6]
    w.wcs.crpix = [512.5, 512.5]
    w.wcs.crval = [-300.0, 200.0]
    w.wcs.dateobs = "2013-09-02T16:39:35"
    img = np.random.default_rng(0).random((1024, 1024), dtype=np.float32)
    return 2, w, (lambda i: img), 1, 0, [None], "equal", ("x world", "y world")


def synthetic():
    """(wcs, image, frame_class, overlay frame or None)."""
    if CASE == "rot":  # rotated TAN near the pole: curved, rotated, RA wraps through 0
        w = WCS(naxis=2)
        w.wcs.ctype = ["RA---TAN", "DEC--TAN"]
        w.wcs.crval = [2.0, 78.0]
        w.wcs.crpix = [200.5, 200.5]
        w.wcs.cdelt = [-0.05, 0.05]
        th = np.radians(30)
        w.wcs.pc = [[np.cos(th), -np.sin(th)], [np.sin(th), np.cos(th)]]
        return w, np.random.default_rng(0).random((400, 400)), fr.RectangularFrame, "galactic"
    if CASE.startswith("allsky"):  # all-sky Aitoff: NaN outside the ellipse, longitude wrap
        w = WCS(naxis=2)
        w.wcs.ctype = ["GLON-AIT", "GLAT-AIT"]
        w.wcs.crval = [0.0, 0.0]
        w.wcs.crpix = [180.5, 90.5]
        w.wcs.cdelt = [-1.0, 1.0]
        fc = fr.EllipticalFrame if CASE == "allsky" else fr.RectangularFrame
        return w, np.random.default_rng(0).random((180, 360)), fc, "fk5"
    if CASE == "spec1d":
        w = WCS(naxis=1)
        w.wcs.ctype = ["WAVE"]
        w.wcs.cunit = ["Angstrom"]
        w.wcs.crval = [1400.0]
        w.wcs.cdelt = [0.025]
        w.wcs.crpix = [1.0]
        return w, None, fr.RectangularFrame1D, None
    raise SystemExit(f"unknown case {CASE}")


GLUE_MARGINS = (1, 0.25, 0.5, 0.25)


def set_size(fig, ax, w, h):
    fig.set_size_inches(w / 100, h / 100)
    W, H = w / 100, h / 100
    l, r, b, t = GLUE_MARGINS
    ax.set_position([l / W, b / H, 1 - (l + r) / W, 1 - (b + t) / H])


class Setup:
    """One figure in one mode."""

    def __init__(self, on, w, h):
        mode(on)
        self.on = on
        if IRIS:
            from glue.viewers.matplotlib.mpl_axes import init_mpl

            self.ndim, self.wcs, self.img_of, self.x, self.y, self.steps, aspect, self.labels = L
            self.fig = Figure(figsize=(w / 100, h / 100), dpi=100)
            FigureCanvasAgg(self.fig)
            _, self.ax = init_mpl(figure=self.fig, wcs=True)
            set_size(self.fig, self.ax, w, h)
            self.set_wcs(self.steps[0])
            im0 = np.asarray(self.img_of(self.steps[0]))
            self.im = self.ax.imshow(im0, origin="lower", cmap="gray", interpolation="nearest", aspect=aspect)
            ny, nx = im0.shape
        else:
            self.ndim, self.steps = 2, [None]
            wcs, img, fc, overlay = L
            self.fig = Figure(figsize=(w / 100, h / 100), dpi=100)
            FigureCanvasAgg(self.fig)
            self.ax = self.fig.add_axes([0.15, 0.15, 0.75, 0.75], projection=wcs, frame_class=fc)
            if img is None:
                self.ax.plot(np.sin(np.arange(200) / 10.0))
                nx, ny = 200, 2
                self.ax.set_ylim(-1.5, 1.5)
            else:
                self.im = self.ax.imshow(img, origin="lower", cmap="gray")
                ny, nx = img.shape
                self.ax.coords.grid(True, color="w", alpha=0.5)
            if overlay:
                ov = self.ax.get_coords_overlay(overlay)
                ov.grid(True, color="c", alpha=0.5)
                for c in ov:
                    c.set_ticks_position("all")
            if CASE == "allsky_rect":  # frame partly off the sky: NaN spines and NaN shift fallback
                nx, ny = nx * 1.3, ny * 1.3
        self.lim0 = ((-0.5, nx - 0.5), (-0.5, ny - 0.5)) if CASE != "spec1d" else ((-0.5, nx - 0.5), (-1.5, 1.5))
        self.ax.set_xlim(*self.lim0[0])
        self.ax.set_ylim(*self.lim0[1])
        self.k = 0

    def set_wcs(self, idx):
        """What glue's ImageViewer._set_wcs + _update_axes do on a slice change."""
        ax = self.ax
        ax.reset_wcs(slices=glue_slices(self.ndim, self.x, self.y, idx), wcs=self.wcs)
        ax.set_xlabel("", size=10)
        ax.set_ylabel("", size=10)
        ax.set_xlabel(self.labels[0], size=10)
        ax.set_ylabel(self.labels[1], size=10)
        for c in ax.coords:
            c.set_ticklabel(size=8)

    def next_slice(self):
        self.k = (self.k + 1) % len(self.steps)
        idx = self.steps[self.k]
        self.set_wcs(idx)
        self.im.set_data(np.asarray(self.img_of(idx)))

    def draw(self):
        mode(self.on)
        self.fig.canvas.draw()


# ---------------------------------------------------------------- fingerprint
def _canon(v):
    if isinstance(v, dict):
        return {str(k): _canon(x) for k, x in sorted(v.items(), key=lambda kv: str(kv[0]))}
    if isinstance(v, str):
        return v
    if isinstance(v, (list, tuple)) and v and all(isinstance(x, str) for x in v):
        return list(v)
    try:
        a = np.asarray(v, dtype=float)
        return hashlib.sha1(a.tobytes()).hexdigest() + f"/{a.shape}"
    except (TypeError, ValueError):
        return repr(v)  # ragged lists: repr of Python floats is exact


def _fc(ax, x, y):
    try:
        return ax.format_coord(x, y)
    except Exception as e:  # stock 8.0.1 and main raise on 1-D WCSAxes (2 pixel values into a 1-D WCS)
        return repr(e)


def fingerprint(s):
    ax = s.ax
    out = {}
    for m, coords in enumerate(ax._all_coords):
        for n, c in enumerate(coords):
            p = f"map{m}.coord{n}"
            out[p + ".positions"] = repr((c.get_ticks_position(), c.get_ticklabel_position(), c.get_axislabel_position()))
            out[p + ".fl_spacing"] = repr(getattr(c, "_fl_spacing", None))
            for f in ("world", "pixel", "angle", "disp", "minor_world", "minor_pixel", "minor_angle", "minor_disp"):
                out[f"{p}.ticks.{f}"] = _canon(dict(getattr(c._ticks, f)))
            out[p + ".ticks_locs"] = _canon(dict(getattr(c._ticks, "ticks_locs", {})))
            tl = c._ticklabels
            for f in ("text", "world", "data", "angle", "tick_angle", "disp", "xy", "ha", "va"):
                if hasattr(tl, f):
                    out[f"{p}.ticklabels.{f}"] = _canon(dict(getattr(tl, f)))
            al = c._axislabels
            out[p + ".axislabel"] = repr((c.get_axislabel(), al.get_text(), al.get_position(), al.get_rotation(),
                                          al.get_visible_axes()))
    (x0, x1), (y0, y1) = ax.get_xlim(), ax.get_ylim()
    out["format_coord"] = [_fc(ax, x0 + (x1 - x0) * f, y0 + (y1 - y0) * g) for f, g in ((.5, .5), (.13, .71), (.9, .2))]
    out["image_sha1"] = hashlib.sha1(np.asarray(s.fig.canvas.buffer_rgba()).tobytes()).hexdigest()
    return out


def scenario(on):
    """Draw a fixed sequence of views and fingerprint each; return [(step, fp, p2w calls)]."""
    s = Setup(on, 400, 330)
    ax = s.ax
    (x0, x1), (y0, y1) = s.lim0
    dx, dy = x1 - x0, y1 - y0
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    seq = [
        ("initial", lambda: None),
        ("static", lambda: None),
        ("pan_x", lambda: ax.set_xlim(x0 + 0.137 * dx, x1 + 0.137 * dx)),
        ("pan_y", lambda: ax.set_ylim(y0 - 0.21 * dy, y1 - 0.21 * dy)),
        ("zoom_in", lambda: (ax.set_xlim(cx - 0.15 * dx, cx + 0.15 * dx), ax.set_ylim(cy - 0.12 * dy, cy + 0.12 * dy))),
        ("zoom_out", lambda: (ax.set_xlim(cx - 1.6 * dx, cx + 1.6 * dx), ax.set_ylim(cy - 1.4 * dy, cy + 1.4 * dy))),
        ("flip_y", lambda: (ax.set_xlim(x0, x1), ax.set_ylim(y1, y0))),
        ("home", lambda: (ax.set_xlim(x0, x1), ax.set_ylim(y0, y1))),
    ]
    if s.ndim == 3:
        seq += [("slice_next", s.next_slice), ("slice_far", lambda: [s.next_slice() for _ in range(16)])]
    seq += [
        ("resize_1258x810", lambda: set_size(s.fig, ax, 1258, 810)),
        ("pan_after_resize", lambda: ax.set_xlim(x0 + 0.05 * dx, x1 + 0.05 * dx)),
        ("minor_ticks", lambda: [c.display_minor_ticks(True) for c in ax.coords]),
    ]
    if IRIS:
        two = sum(c.coord_index is not None for c in ax.coords) == 2
        seq += [("grid", lambda: ax.coords.grid(True, grid_type="lines" if two else "contours"))]
    out = []
    for name, act in seq:
        mode(on)
        act()
        CNT.clear()
        s.draw()
        calls = CNT["p2w"]
        out.append((name, fingerprint(s), calls))
    # eager label path result (what set_xlabel/get_xlabel resolve to)
    mode(on)
    CNT.clear()
    xl = ax.set_xlabel("probe x")
    out.append(("set_xlabel", {"xlabel": repr(ax.get_xlabel()), "ylabel": repr(ax.get_ylabel()),
                               "axislabels": [repr(c.get_axislabel()) for c in ax.coords]}, CNT["p2w"]))
    return out


def identity():
    a, b = scenario(False), scenario(True)
    rows = []
    for (name, fa, ca), (_, fb, cb) in zip(a, b):
        diff = sorted(k for k in set(fa) | set(fb) if fa.get(k) != fb.get(k))
        rows.append(dict(step=name, identical=not diff, diff=diff[:8], keys=len(fa), p2w_base=ca, p2w_batch=cb))
    return rows


# ---------------------------------------------------------------- timing
def timing(w, h, blocks=6, per_block=5):
    S = {on: Setup(on, w, h) for on in (False, True)}
    for on in (False, True):
        for _ in range(3):
            S[on].draw()
    res = {on: collections.defaultdict(list) for on in (False, True)}
    for blk in range(blocks):
        for on in ((False, True) if blk % 2 == 0 else (True, False)):
            for _ in range(per_block):
                CNT.clear(), TT.clear()
                t = perf_counter()
                S[on].draw()
                r = res[on]
                r["draw"].append((perf_counter() - t) * 1e3)
                r["wcsaxes"].append((TT["draw_wcsaxes"] + TT["_update_patch_path"]) * 1e3)
                r["p2w"].append(CNT["p2w"])
                r["p2w_pts"].append(CNT["p2w_pts"])
    # one set_xlabel alone (the eager placement)
    for on in (False, True):
        mode(on)
        for _ in range(15):
            CNT.clear()
            t = perf_counter()
            S[on].ax.set_xlabel(S[on].labels[0] if IRIS else "x", size=10)
            res[on]["set_xlabel"].append((perf_counter() - t) * 1e3)
            res[on]["set_xlabel_p2w"].append(CNT["p2w"])
    # glue slice step: reset_wcs + 4 label sets (set phase), then a draw
    if S[False].ndim == 3:
        for k in range(len(S[False].steps)):
            for on in ((False, True) if k % 2 == 0 else (True, False)):
                mode(on)
                CNT.clear()
                t = perf_counter()
                S[on].next_slice()
                t1 = perf_counter()
                c1 = CNT["p2w"]
                S[on].draw()
                t2 = perf_counter()
                r = res[on]
                r["step_set"].append((t1 - t) * 1e3)
                r["step_set_p2w"].append(c1)
                r["step_draw"].append((t2 - t1) * 1e3)
                r["step_total"].append((t2 - t) * 1e3)
                r["step_p2w"].append(CNT["p2w"])
    out = {}
    for on in (False, True):
        out["batch" if on else "base"] = {k: dict(median=round(st.median(v), 3), n=len(v)) for k, v in res[on].items()}
    return out


def main():
    global L
    L = load() if IRIS else synthetic()
    result = dict(case=CASE, astropy=astropy.__version__, astropy_file=astropy.__file__)
    result["identity"] = identity()
    if IRIS:
        for w, h in ((400, 330), (1258, 810)):
            result[f"timing_{w}x{h}"] = timing(w, h)
    result["rss_gb"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1e9
    json.dump(result, open(f"{HERE}/out_{CASE}.json", "w"), indent=1, default=str)
    bad = [r["step"] for r in result["identity"] if not r["identical"]]
    print(CASE, "identity steps:", len(result["identity"]), "differ:", bad, "rss GB %.2f" % result["rss_gb"])
    for r in result["identity"]:
        print("  ", r["step"], "identical" if r["identical"] else f"DIFF {r['diff']}", "p2w", r["p2w_base"], "->", r["p2w_batch"])
    for k, v in result.items():
        if k.startswith("timing"):
            print(k)
            for m in ("base", "batch"):
                print("  ", m, {kk: vv["median"] for kk, vv in v[m].items()})


main()
