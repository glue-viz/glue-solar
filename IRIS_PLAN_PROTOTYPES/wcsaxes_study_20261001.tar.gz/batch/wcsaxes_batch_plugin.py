"""pytest plugin: run astropy's WCSAxes tests with wcsaxes_batch installed.

  -p wcsaxes_batch_plugin            install the patch (WCSAXES_BATCH=0 leaves stock astropy)
  WCSAXES_FIGDIR=<dir>               also run the @figure_test bodies (normally skipped without
                                     pytest-mpl) and save each returned figure as <dir>/<test>.png,
                                     so a stock run and a patched run can be compared pixel for pixel.
"""
import os
import re

import pytest

FIGDIR = os.environ.get("WCSAXES_FIGDIR")


def pytest_configure(config):
    if os.environ.get("WCSAXES_BATCH", "1") == "1":
        import wcsaxes_batch

        wcsaxes_batch.install()


def pytest_report_header(config):
    from astropy.visualization.wcsaxes import core

    return f"wcsaxes_batch installed: {core.WCSAxes._update_tick_and_label_positions.__module__ == 'wcsaxes_batch'}"


def pytest_collection_modifyitems(items):
    if not FIGDIR:
        return
    for item in items:
        if item.get_closest_marker("mpl_image_compare"):
            item.own_markers[:] = [
                m for m in item.own_markers
                if m.name != "remote_data" and not (m.name == "skipif" and "pytest-mpl" in str(m.kwargs.get("reason")))
            ]


@pytest.hookimpl(tryfirst=True)
def pytest_pyfunc_call(pyfuncitem):
    m = pyfuncitem.get_closest_marker("mpl_image_compare")
    if not (FIGDIR and m):
        return None
    fig = pyfuncitem.obj(**{a: pyfuncitem.funcargs[a] for a in pyfuncitem._fixtureinfo.argnames})
    os.makedirs(FIGDIR, exist_ok=True)
    name = re.sub(r"[^A-Za-z0-9_.-]+", "_", pyfuncitem.nodeid.split("wcsaxes/tests/")[-1])
    fig.savefig(os.path.join(FIGDIR, name + ".png"), **m.kwargs.get("savefig_kwargs", {}))
    return True
