"""Run ../../measure/measure.py with wcsaxes_batch installed; outputs land in this directory."""
import runpy, sys
sys.path.insert(1, "/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes/batch")
import wcsaxes_batch
wcsaxes_batch.install()
runpy.run_path("/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes/measure/measure.py", run_name="__main__")
