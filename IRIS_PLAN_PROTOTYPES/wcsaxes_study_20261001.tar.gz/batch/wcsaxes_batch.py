"""Batch and share the WCS calls of one WCSAxes tick update (runtime monkeypatch, astropy 8.0.1).

install() / uninstall(). Nothing in astropy is edited. Three changes:

1. Spine.world is computed on first read instead of in the Spine.data setter. update_spines()
   (run by _update_patch_path, frame.patch and frame.sample) never reads it, so its 4 two-point
   WCS calls per run go away.
2. BaseFrame.sample transforms every resampled spine in one call instead of one call per spine.
3. _update_tick_and_label_positions gives each CoordinatesMap a cache that lives for that one
   call. _update_ticks takes the sampled frame from it, and the +-2 px shifted samples, which
   are computed for every spine in one call per shift direction and shared by all coordinates.

_update_ticks is the 8.0.1 body (byte-identical to astropy main 1f930be7c4) with only the
`frame = ...` line and `shifted_pixel_to_world` changed.
"""

import hashlib
import inspect
from collections import OrderedDict

import numpy as np

from astropy import units as u
from astropy.visualization.wcsaxes import coordinate_helpers as ch
from astropy.visualization.wcsaxes import core
from astropy.visualization.wcsaxes import frame as fr
from astropy.visualization.wcsaxes.coordinate_helpers import wrap_angle_at
from astropy.visualization.wcsaxes.frame import RectangularFrame1D

_ORIG = {}
# sha1[:12] of inspect.getsource of the functions copied below; same on 8.0.1 and main 1f930be7c4.
_COPIED = {
    "_update_ticks": (lambda: ch.CoordinateHelper._update_ticks, "37a6dd3eac89"),
    "sample": (lambda: fr.BaseFrame.sample, "cf9732b23cbd"),
    "Spine.data setter": (lambda: fr.Spine.data.fset, "5e95a5c93757"),
}


# 1. lazy Spine.world ---------------------------------------------------------------------
def _spine_data_set(self, value):
    self._data = value
    self._world = None
    if value is not None:
        self._update_normal()


def _spine_world_get(self):
    if self._world is None and self._data is not None:
        with np.errstate(invalid="ignore"):
            self._world = self.transform.transform(self._data)
    return self._world


# 2. one transform call per sample ----------------------------------------------------------
def _sample(self, n_samples):
    self.update_spines()

    spines = OrderedDict()

    for axis in self:
        data = self[axis].data
        spines[axis] = self.spine_class(self.parent_axes, self.transform)
        if data.size > 0:
            p = np.linspace(0.0, 1.0, data.shape[0])
            p_new = np.linspace(0.0, 1.0, n_samples)
            data = np.array([np.interp(p_new, p, d) for d in data.T]).transpose()
        spines[axis].data = data

    # Spines whose class sets world eagerly (SpineXAligned) already have it.
    lazy = [s for s in spines.values() if s._world is None and s._data.size > 0]
    if lazy:
        with np.errstate(invalid="ignore"):
            world = self.transform.transform(np.vstack([s._data for s in lazy]))
        for s, w in zip(lazy, np.split(world, np.cumsum([len(s._data) for s in lazy])[:-1])):
            s._world = w

    return spines


# 3. per-update cache shared by the coordinates of one map ---------------------------------
def _update_tick_and_label_positions(self, keep_coord_range=False):
    for coords in self._all_coords:
        coords._tick_cache = {}
    try:
        return _ORIG["utlp"](self, keep_coord_range)
    finally:
        for coords in self._all_coords:
            coords.__dict__.pop("_tick_cache", None)


def _shifted_world(helper, frame, cache, axis, index, shift):
    """All world columns of sampled spine `axis` moved `shift` display px along `index`.

    The first request in a direction (forward: +2 px in x and +-2 px "up"; backward: the
    NaN fallback) computes both shifts of every spine in one transform call.
    """
    key = (id(helper.transform), axis, index, shift)
    if key not in cache:
        transData = helper.parent_axes.transData
        inverted = transData.inverted()
        amount = 2.0 if helper.frame.origin == "lower" else -2.0
        sign = 1.0 if shift == (2.0 if index == 0 else amount) else -1.0
        keys, pixels = [], []
        for a, spine in frame.items():
            if spine.data.size == 0:
                continue
            axes0 = transData.transform(spine.data)
            for i, s in ((0, 2.0 * sign), (1, amount * sign)):
                pixel = axes0.copy()
                pixel[:, i] += s
                keys.append((id(helper.transform), a, i, s))
                pixels.append(inverted.transform(pixel))
        with np.errstate(invalid="ignore"):
            world = helper.transform.transform(np.vstack(pixels))
        for k, w in zip(keys, np.split(world, np.cumsum([len(p) for p in pixels])[:-1])):
            cache[k] = w
    return cache[key]


def _update_ticks(self):
    if self.coord_index is None:
        return

    coord_range = self.parent_map._coord_range

    # First find the ticks we want to show
    tick_world_coordinates, self._fl_spacing = self.locator(*coord_range[self.coord_index])

    if self._ticks.get_display_minor_ticks():
        minor_ticks_w_coordinates = self._formatter_locator.minor_locator(
            self._fl_spacing,
            self.get_minor_frequency(),
            *coord_range[self.coord_index],
        )

    from astropy.visualization.wcsaxes import conf

    # CHANGED: the sampled frame is shared by every coordinate of this map in one update.
    cache = getattr(self.parent_map, "_tick_cache", None)
    if cache is None:
        cache = {}
    if "sample" not in cache:
        cache["sample"] = self.frame.sample(conf.frame_boundary_samples)
    frame = cache["sample"]

    self._ticks.clear()
    self._ticklabels.clear()
    self._lblinfo = []
    self._lbl_world = []
    transData = self.parent_axes.transData

    for axis, spine in frame.items():
        if spine.data.size == 0:
            continue

        if not isinstance(self.frame, RectangularFrame1D):
            pixel0 = spine.data
            world0 = spine.world[:, self.coord_index]
            if np.isnan(world0).all():
                continue

            # CHANGED: shared, batched shifted samples instead of one call per shift.
            def shifted_pixel_to_world(index, shift):
                return _shifted_world(self, frame, cache, axis, index, shift)[:, self.coord_index]

            world1 = shifted_pixel_to_world(0, 2)
            dx = world1 - world0

            invalid1 = np.isnan(world1)
            if invalid1.any():
                world1 = shifted_pixel_to_world(0, -2)
                dx[invalid1] = (world0 - world1)[invalid1]

            amount = 2.0 if self.frame.origin == "lower" else -2.0
            world2 = shifted_pixel_to_world(1, amount)
            dy = world2 - world0

            invalid2 = np.isnan(world2)
            if invalid2.any():
                world2 = shifted_pixel_to_world(1, -amount)
                dy[invalid2] = (world0 - world2)[invalid2]

            dx, dy = -dy, dx

            if self.coord_type == "longitude":
                if self._coord_scale_to_deg is not None:
                    dx *= self._coord_scale_to_deg
                    dy *= self._coord_scale_to_deg

                dx = wrap_angle_at(dx, 180.0)
                dy = wrap_angle_at(dy, 180.0)

            tick_angle = np.degrees(np.arctan2(dy, dx))

            normal_angle_full = np.hstack([spine.normal_angle, spine.normal_angle[-1]])
            with np.errstate(invalid="ignore"):
                reset = ((normal_angle_full - tick_angle) % 360 > 90.0) & (
                    (tick_angle - normal_angle_full) % 360 > 90.0
                )
            tick_angle[reset] -= 180.0

        else:
            rotation = 90 if axis == "b" else -90
            tick_angle = np.zeros((conf.frame_boundary_samples,)) + rotation

        w1 = spine.world[:-1, self.coord_index]
        w2 = spine.world[1:, self.coord_index]

        if self.coord_type == "longitude":
            if self._coord_scale_to_deg is not None:
                w1 = w1 * self._coord_scale_to_deg
                w2 = w2 * self._coord_scale_to_deg

            w1 = wrap_angle_at(w1, self.coord_wrap.to_value(u.deg))
            w2 = wrap_angle_at(w2, self.coord_wrap.to_value(u.deg))
            with np.errstate(invalid="ignore"):
                w1[w2 - w1 > 180.0] += 360
                w2[w1 - w2 > 180.0] += 360

            if self._coord_scale_to_deg is not None:
                w1 = w1 / self._coord_scale_to_deg
                w2 = w2 / self._coord_scale_to_deg

        self._compute_ticks(tick_world_coordinates, spine, axis, w1, w2, tick_angle)

        if self._ticks.get_display_minor_ticks():
            self._compute_ticks(
                minor_ticks_w_coordinates, spine, axis, w1, w2, tick_angle, ticks="minor"
            )

    text = self.formatter(u.Quantity(self._lbl_world), spacing=self._fl_spacing)

    for kwargs, txt in zip(self._lblinfo, text):
        self._ticklabels.add(text=txt, **kwargs)


# install / uninstall -----------------------------------------------------------------------
# Checked once at import, so install()/uninstall() stay cheap enough to toggle between draws.
for _name, (_get, _digest) in _COPIED.items():
    if hashlib.sha1(inspect.getsource(_get()).encode()).hexdigest()[:12] != _digest:
        raise ImportError(f"astropy's {_name} changed since wcsaxes_batch copied it")


def install():
    if _ORIG:
        return
    _ORIG.update(
        data=fr.Spine.data, world=fr.Spine.world, sample=fr.BaseFrame.sample,
        utlp=core.WCSAxes._update_tick_and_label_positions, ticks=ch.CoordinateHelper._update_ticks,
    )
    fr.Spine.data = property(_ORIG["data"].fget, _spine_data_set)
    fr.Spine.world = property(_spine_world_get, _ORIG["world"].fset)
    fr.BaseFrame.sample = _sample
    core.WCSAxes._update_tick_and_label_positions = _update_tick_and_label_positions
    ch.CoordinateHelper._update_ticks = _update_ticks


def uninstall():
    if not _ORIG:
        return
    fr.Spine.data, fr.Spine.world = _ORIG["data"], _ORIG["world"]
    fr.BaseFrame.sample = _ORIG["sample"]
    core.WCSAxes._update_tick_and_label_positions = _ORIG["utlp"]
    ch.CoordinateHelper._update_ticks = _ORIG["ticks"]
    _ORIG.clear()
