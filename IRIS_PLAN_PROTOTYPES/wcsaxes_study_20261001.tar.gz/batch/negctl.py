"""Negative control: perturb the batched shifted samples by 1 part in 1e12 and confirm compare.py flags it."""
import runpy, sys
sys.path.insert(0, "/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes/batch")
import wcsaxes_batch as B
f = B._shifted_world
B._shifted_world = lambda *a: f(*a) * (1 + 1e-12)
sys.argv = ["compare.py", sys.argv[1]]
runpy.run_path("compare.py", run_name="__main__")
