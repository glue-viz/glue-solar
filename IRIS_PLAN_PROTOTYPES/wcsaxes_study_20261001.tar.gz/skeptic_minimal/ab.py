"""Independent A/B of memo_patch: plain matplotlib Agg + WCSAxes made with fig.add_axes(WCSAxes(..., wcs, slices)).

Patch toggled in-process every repetition (ABBA), so machine-load drift hits both arms equally.
usage: python ab.py <case> [WxH] [sep:base|sep:memo]  (sep:* = no toggling, one arm only, for a separate-process run)
"""
import glob, json, statistics as st, sys
from time import perf_counter

sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
sys.path.insert(0, "/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes/minimal")
import numpy as np
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure
from astropy.visualization.wcsaxes import WCSAxes, core, wcsapi

CASE = sys.argv[1]
W, H = map(int, (sys.argv[2] if len(sys.argv) > 2 else "400x330").split("x"))
SEP = sys.argv[3] if len(sys.argv) > 3 else None
R = "/Users/nabil/DATA/IRIS"

NCALL = [0]
_orig_tr = wcsapi.WCSPixel2WorldTransform.transform
def counting(self, pixel):
    NCALL[0] += 1
    return _orig_tr(self, pixel)
wcsapi.WCSPixel2WorldTransform.transform = counting

NAMES = ("_update_tick_and_label_positions", "draw_wcsaxes")
ORIG = {n: core.WCSAxes.__dict__[n] for n in NAMES}
import memo_patch  # noqa: E402
MEMO = {n: core.WCSAxes.__dict__[n] for n in NAMES}
assert all(MEMO[n] is not ORIG[n] for n in NAMES)


def arm(tag):
    for n in NAMES:
        setattr(core.WCSAxes, n, (MEMO if tag == "memo" else ORIG)[n])


def load():
    from glue_solar.sources.loaders.iris import image_data, raster_data
    import glue_solar
    print("glue_solar", glue_solar.__file__)
    if CASE in ("sji1400", "sji2796"):
        pat = "4000255147_SJI_1400_t000.fits.gz" if CASE == "sji1400" else "4000005156_SJI_2796_t000_deconvolved.fits.gz"
        d = image_data(glob.glob(f"{R}/*{pat}")[0])
        a = d[d.main_components[0]]
        n = a.shape[0]
        return d.coords, 3, lambda i: a[i], 2, 1, list(range(n // 2, n // 2 + 16)), "equal", d
    if CASE.startswith("siiv"):
        d = raster_data(sorted(glob.glob(f"{R}/*4000255147_raster/*_r00000.fits")), windows=["Si IV 1403"])[0]
        a = d[d.main_components[0]]
        if CASE == "siiv_spec":
            n = a.shape[0]
            return d.coords, 3, lambda i: a[i], 2, 1, list(range(n // 2, n // 2 + 16)), "auto", d
        n = a.shape[1]
        return d.coords, 3, lambda i: a[:, i, :], 2, 0, list(range(n // 2, n // 2 + 16)), "auto", d
    from astropy.wcs import WCS
    w = WCS(naxis=2)
    w.wcs.ctype = ["HPLN-TAN", "HPLT-TAN"]; w.wcs.cunit = ["arcsec", "arcsec"]
    w.wcs.cdelt = [0.6, 0.6]; w.wcs.crpix = [512.5, 512.5]; w.wcs.crval = [-300.0, 200.0]
    img = np.random.default_rng(0).random((1024, 1024), dtype=np.float32)
    return w, 2, lambda i: img, 1, 0, [None], "equal", None


def slices(ndim, x, y, idx):
    if ndim == 2:
        return None
    return ["x" if i == x else "y" if i == y else idx for i in range(ndim)][::-1]


wcs, ndim, img, x, y, steps, aspect, d = load()
labels = ("x", "y") if d is None else (d.world_component_ids[x].label, d.world_component_ids[y].label)
fig = Figure(figsize=(W / 100, H / 100), dpi=100)
canvas = FigureCanvasAgg(fig)
w_, h_ = W / 100, H / 100
ax = WCSAxes(fig, [1 / w_, 0.5 / h_, 1 - 1.25 / w_, 1 - 0.75 / h_], wcs=wcs, slices=slices(ndim, x, y, steps[0]))
fig.add_axes(ax)
for c in ax.coords:
    c.set_ticklabel(size=8)
ax.set_xlabel(labels[0], size=10); ax.set_ylabel(labels[1], size=10)
im0 = np.asarray(img(steps[0]))
im = ax.imshow(im0, origin="lower", cmap="gray", interpolation="nearest", aspect=aspect)
ax.set_xlim(-0.5, im0.shape[1] - 0.5); ax.set_ylim(-0.5, im0.shape[0] - 0.5)

tags = [SEP.split(":")[1]] if SEP else ["base", "memo"]
res = {t: {"draw": [], "calls": [], "set": [], "set_calls": [], "step": [], "pan": []} for t in tags}
for t in tags * 3:  # warm-up
    arm(t); canvas.draw()
N = 40
for i in range(N):
    order = tags if (i % 2 == 0 or SEP) else tags[::-1]
    for t in order:
        arm(t)
        NCALL[0] = 0
        t0 = perf_counter(); canvas.draw(); dt = perf_counter() - t0
        res[t]["draw"].append(dt); res[t]["calls"].append(NCALL[0])
    x0, x1 = ax.get_xlim()
    for t in order:  # pan by one data pixel and back
        arm(t)
        ax.set_xlim(x0 + 1, x1 + 1)
        t0 = perf_counter(); canvas.draw(); res[t]["pan"].append(perf_counter() - t0)
        ax.set_xlim(x0, x1)
if ndim == 3:
    for k, idx in enumerate(steps[1:] * 2):
        order = tags if (k % 2 == 0 or SEP) else tags[::-1]
        for t in order:
            arm(t)
            NCALL[0] = 0
            t0 = perf_counter()
            ax.reset_wcs(slices=slices(ndim, x, y, idx), wcs=wcs)
            ax.set_xlabel("", size=10); ax.set_ylabel("", size=10)
            ax.set_xlabel(labels[0], size=10); ax.set_ylabel(labels[1], size=10)
            for c in ax.coords:
                c.set_ticklabel(size=8)
            t1 = perf_counter()
            res[t]["set_calls"].append(NCALL[0])
            im.set_data(np.asarray(img(idx)))
            canvas.draw()
            t2 = perf_counter()
            res[t]["set"].append(t1 - t0); res[t]["step"].append(t2 - t0)
out = {}
for t, r in res.items():
    out[t] = {k: (round(st.median(v) * 1e3, 2) if k in ("draw", "set", "step", "pan") else st.median(v)) for k, v in r.items() if v}
print(CASE, f"{W}x{H}", SEP or "interleaved", json.dumps(out), "memo", memo_patch.STATS)
