#!/bin/sh
cd /private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes
export HOME="$(mktemp -d)" QT_QPA_PLATFORM=offscreen MPLBACKEND=agg
for t in base memo base2 memo2; do
  /Users/nabil/mamba/envs/iris-plan/bin/python skeptic_minimal/edge.py $t > skeptic_minimal/edge_$t.log 2>&1 || echo FAIL $t
done
echo ALLDONE
