"""Edge-case output identity for memo_patch: run once per arm in separate processes, compare the JSONs.

usage: python edge.py <base|memo> [scenario ...]  -> edge_<tag>.json
Every step records: RGBA sha256 of the Agg buffer, every Ticks/TickLabels data dict of every coord of every
coords map (bit exact), axis labels, tight bbox, exceptions (type+message) and warnings (kept separately).
"""
import glob, hashlib, io, json, sys, traceback, warnings

sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
sys.path.insert(0, "/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes/minimal")
import os
if os.environ.get("SHADOW"):  # astropy main wcsaxes (optionally with the upstream diff) over installed 8.0.1
    import astropy.visualization as _v
    _v.__path__.insert(0, os.environ["SHADOW"])
import numpy as np
import matplotlib
matplotlib.use("agg")
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure
import astropy.units as u
from astropy.coordinates import SkyCoord
from astropy.wcs import WCS
from astropy.wcs.wcsapi import BaseLowLevelWCS, HighLevelWCSWrapper
from astropy.visualization.wcsaxes import WCSAxes
from astropy.visualization.wcsaxes.frame import EllipticalFrame
from astropy.visualization.wcsaxes.transforms import CurvedTransform

TAG = sys.argv[1]
ONLY = sys.argv[2:]
if TAG.startswith("memo"):
    import memo_patch
R = "/Users/nabil/DATA/IRIS"


def dg(v):
    if isinstance(v, np.ndarray) or isinstance(v, np.generic):
        a = np.asarray(v)
        if a.dtype == object:
            return [dg(x) for x in a.ravel()]
        return f"{a.dtype.str}{a.shape}:{hashlib.sha1(np.ascontiguousarray(a).tobytes()).hexdigest()[:16]}"
    if isinstance(v, float):
        return v.hex()
    if isinstance(v, dict):
        return {str(k): dg(x) for k, x in sorted(v.items(), key=lambda kv: str(kv[0]))}
    if isinstance(v, (list, tuple)):
        if v and all(isinstance(x, (float, int, np.floating, np.integer)) for x in v):
            return dg(np.asarray(v, float))
        return [dg(x) for x in v]
    if isinstance(v, (int, bool, str, type(None))):
        return v
    return type(v).__name__


DATA_ATTRS = ("world", "pixel", "angle", "disp", "minor_world", "minor_pixel", "minor_angle", "minor_disp",
              "data", "text", "_axis_bboxes", "_all_bboxes")


def fingerprint(fig, ax):
    out = {}
    fig.canvas.draw()
    out["rgba"] = hashlib.sha256(np.asarray(fig.canvas.buffer_rgba()).tobytes()).hexdigest()[:20]
    for m, coords in enumerate(ax._all_coords):
        for c in coords:
            key = f"map{m}.c{c.coord_index}"
            for part in ("_ticks", "_ticklabels"):
                o = getattr(c, part)
                out[f"{key}.{part}"] = {a: dg(getattr(o, a)) for a in DATA_ATTRS if hasattr(o, a) and a in vars(o)}
            al = c._axislabels
            out[f"{key}.axislabel"] = [al.get_text(), dg(tuple(al.get_position())), dg(float(al.get_rotation())),
                                       al.get_visible(), c.get_ticks_position(), c.get_ticklabel_position(),
                                       c.get_axislabel_position()]
            out[f"{key}.spacing"] = dg(getattr(c, "_fl_spacing", None)) if hasattr(c, "_fl_spacing") else None
            out[f"{key}.grid"] = [dg(p.vertices) for p in getattr(c, "_grid_lines", [])]
    r = fig.canvas.get_renderer()
    out["tightbbox"] = dg(tuple(map(float, ax.get_tightbbox(r).bounds)))
    out["xlabel"], out["ylabel"] = ax.get_xlabel(), ax.get_ylabel()
    try:
        out["fmt"] = ax.format_coord(*np.mean([ax.get_xlim(), ax.get_ylim()], axis=1))
    except Exception as e:
        out["fmt"] = f"EXC {type(e).__name__}: {e}"
    return out


def png(fig):
    b = io.BytesIO()
    fig.savefig(b, format="png", bbox_inches="tight", metadata={"Software": None})
    return hashlib.sha256(b.getvalue()).hexdigest()[:20]


def new(wcs=None, size=(4, 3.3), rect=(0.25, 0.15, 0.7, 0.75), **kw):
    fig = Figure(figsize=size, dpi=100)
    FigureCanvasAgg(fig)
    ax = WCSAxes(fig, list(rect), wcs=wcs, **kw)
    fig.add_axes(ax)
    return fig, ax


def tan(crval=(-300.0, 200.0), ctype=("HPLN-TAN", "HPLT-TAN"), unit="arcsec", cdelt=0.6, n=256, pc=None):
    w = WCS(naxis=2)
    w.wcs.ctype = list(ctype); w.wcs.cunit = [unit, unit]
    w.wcs.cdelt = [-cdelt if ctype[0].startswith("RA") else cdelt, cdelt]
    w.wcs.crpix = [n / 2 + 0.5, n / 2 + 0.5]; w.wcs.crval = list(crval)
    if pc is not None:
        w.wcs.pc = pc
    w.wcs.dateobs = "2013-09-02T16:39:35"
    return w


IMG = np.random.default_rng(0).random((256, 256), dtype=np.float32)


def show(ax, img=IMG, **kw):
    im = ax.imshow(img, origin="lower", cmap="gray", **kw)
    ax.set_xlim(-0.5, img.shape[1] - 0.5); ax.set_ylim(-0.5, img.shape[0] - 0.5)
    return im


# ---------------------------------------------------------------- scenarios
def s_spacing():
    fig, ax = new(tan()); show(ax)
    ax.coords[0].set_ticks(spacing=13 * u.arcsec); ax.coords[1].set_ticks(number=3)
    ax.coords[0].display_minor_ticks(True); ax.coords[0].set_minor_frequency(4)
    ax.coords[1].display_minor_ticks(True)
    ax.coords[1].set_major_formatter("s.s")
    return fig, ax


def s_values():
    fig, ax = new(tan()); show(ax)
    ax.coords[0].set_ticks(values=[-350, -320, -300, -260] * u.arcsec, exclude_overlapping=True)
    ax.coords[1].set_ticks(values=[] * u.arcsec)
    ax.coords[0].set_ticklabel(exclude_overlapping=True, simplify=False)
    return fig, ax


def s_hidden():
    fig, ax = new(tan()); show(ax)
    ax.coords[0].set_ticks_visible(False); ax.coords[0].set_ticklabel_visible(False)
    ax.coords[1].set_axislabel_visibility_rule("always")
    ax.coords[1].set_axislabel("lat")
    return fig, ax


def s_hidden2():
    fig, ax = new(tan()); show(ax)
    ax.coords[1].set_visible(False)
    return fig, ax


def s_topright():
    fig, ax = new(tan(pc=[[0.9, -0.43], [0.43, 0.9]])); show(ax)
    ax.coords[0].set_ticks_position("t"); ax.coords[0].set_ticklabel_position("t"); ax.coords[0].set_axislabel_position("t")
    ax.coords[1].set_ticks_position("r"); ax.coords[1].set_ticklabel_position("r"); ax.coords[1].set_axislabel_position("r")
    ax.coords[0].set_axislabel("lon top"); ax.coords[1].set_axislabel("lat right")
    return fig, ax


def s_allpos():
    fig, ax = new(tan(pc=[[0.9, -0.43], [0.43, 0.9]])); show(ax)
    for c in ax.coords:
        c.set_ticks_position("bltr"); c.set_ticklabel_position("#"); c.set_axislabel_position("#")
    return fig, ax


def s_overlay():
    w = tan(crval=(45.0, 88.5), ctype=("RA---TAN", "DEC--TAN"), unit="deg", cdelt=0.02,
            pc=[[0.866, -0.5], [0.5, 0.866]])
    fig, ax = new(w); show(ax)
    ax.coords.grid(color="w", alpha=0.4)
    ov = ax.get_coords_overlay("galactic")
    ov.grid(color="r", ls="dotted")
    ov[0].set_ticks_position("tr"); ov[0].set_ticklabel_position("tr"); ov[1].set_ticklabel_position("tr")
    ov2 = ax.get_coords_overlay("icrs")  # same frame: CoordinateTransform.same_frames path
    ov2[0].set_ticks(spacing=1 * u.deg, color="y")
    return fig, ax


def s_tickable():
    w = tan(crval=(266.4, -28.9), ctype=("RA---TAN", "DEC--TAN"), unit="deg", cdelt=0.05)
    fig, ax = new(w); show(ax)
    ov = ax.get_coords_overlay("galactic")
    ov.grid(color="c")
    ov[1].add_tickable_gridline("g", -1.0 * u.deg)
    ov[0].add_tickable_gridline("const-glon", 359.5 * u.deg)
    ov[0].set_ticklabel_position("gt"); ov[0].set_axislabel("glon")
    ov[1].set_ticklabel_position(("const-glon", "r")); ov[1].set_axislabel("glat")
    return fig, ax


def s_overlay_wcs():
    fig, ax = new(tan()); show(ax)
    ov = ax.get_coords_overlay(tan(crval=(-280.0, 180.0), pc=[[0.96, -0.26], [0.26, 0.96]]))
    ov.grid(color="m")
    ov[0].set_ticklabel_position("t"); ov[1].set_ticklabel_position("r")
    return fig, ax


def s_colorbar():
    fig, ax = new(tan()); im = show(ax)
    fig.colorbar(im, ax=ax)
    return fig, ax


def s_colorbar_cax():
    fig, ax = new(tan(), rect=(0.2, 0.15, 0.6, 0.75)); im = show(ax)
    cax = fig.add_axes([0.85, 0.15, 0.04, 0.75]); fig.colorbar(im, cax=cax)
    return fig, ax


def s_tiny():
    fig, ax = new(tan(), size=(0.6, 0.5)); show(ax)
    return fig, ax


def s_zero():
    fig, ax = new(tan(), rect=(0.1, 0.1, 0.0, 0.0)); show(ax)
    return fig, ax


def s_flat():
    fig, ax = new(tan(), rect=(0.1, 0.5, 0.8, 0.0)); show(ax)
    return fig, ax


def s_allsky():
    w = WCS(naxis=2)
    w.wcs.ctype = ["GLON-AIT", "GLAT-AIT"]; w.wcs.crpix = [180.5, 90.5]; w.wcs.cdelt = [-1, 1]; w.wcs.crval = [0, 0]
    fig, ax = new(w, frame_class=EllipticalFrame)
    show(ax, np.random.default_rng(1).random((180, 360)))
    ax.coords.grid(color="w"); ax.coords[0].set_ticklabel(color="r")
    return fig, ax


def s_contours():
    fig, ax = new(tan(pc=[[0.9, -0.43], [0.43, 0.9]])); show(ax)
    ax.coords[0].grid(grid_type="contours", color="r"); ax.coords[1].grid(grid_type="contours", color="b")
    return fig, ax


class Ident(CurvedTransform):
    """Returns its input object itself (a view-returning transform)."""
    has_inverse = True

    def transform(self, xy):
        return xy

    transform_non_affine = transform

    def inverted(self):
        return Ident()


class Polar(CurvedTransform):  # the astropy test's DistanceToLonLat
    has_inverse = True

    def __init__(self, R=6378.273):
        super().__init__(); self.R = R

    def transform(self, xy):
        x, y = xy[:, 0], xy[:, 1]
        return np.array((np.degrees(np.arctan2(y, x)), 90.0 - np.degrees(np.hypot(x, y) / self.R))).transpose()

    transform_non_affine = transform

    def inverted(self):
        return PolarInv(self.R)


class PolarInv(CurvedTransform):
    def __init__(self, R):
        super().__init__(); self.R = R

    def transform(self, lp):
        r = np.radians(90 - lp[:, 1]) * self.R
        return np.array((r * np.cos(np.radians(lp[:, 0])), r * np.sin(np.radians(lp[:, 0])))).transpose()

    transform_non_affine = transform

    def inverted(self):
        return Polar(self.R)


META_S = {"type": ("scalar", "scalar"), "wrap": (None, None), "unit": (u.one, u.one), "name": ("x", "y")}
META_LL = {"type": ("longitude", "latitude"), "wrap": (360 * u.deg, None), "unit": (u.deg, u.deg), "name": ("lon", "lat")}


def s_ident():
    fig, ax = new(transform=Ident(), coord_meta=META_S); show(ax)
    ax.coords.grid(color="r")
    return fig, ax


def s_polar():
    fig, ax = new(transform=Polar(), coord_meta=META_LL)
    ax.set_xlim(-2000, 2000); ax.set_ylim(-1500, 2500)
    ax.coords.grid(color="r"); ax.coords[0].set_ticklabel_position("brtl")
    return fig, ax


class Failing(BaseLowLevelWCS):
    """Delegates to a TAN WCS; pixel_to_world_values raises if any |pixel - centre| > LIM (pure, deterministic)."""
    LIM = 200.0

    def __init__(self, w):
        self.w = w

    def __getattribute__(self, n):
        if n in ("pixel_to_world_values", "w", "LIM", "__class__", "_as_mpl_axes", "__dict__"):
            return object.__getattribute__(self, n)
        return getattr(object.__getattribute__(self, "w"), n)

    def pixel_to_world_values(self, *p):
        if any(np.nanmax(np.abs(np.asarray(a) - 127.5), initial=0) > self.LIM for a in p):
            raise ValueError("pixel out of model range")
        return self.w.pixel_to_world_values(*p)

    # abstract API, delegated
    pixel_n_dim = property(lambda s: s.w.pixel_n_dim)
    world_n_dim = property(lambda s: s.w.world_n_dim)
    world_axis_physical_types = property(lambda s: s.w.world_axis_physical_types)
    world_axis_units = property(lambda s: s.w.world_axis_units)
    world_axis_object_components = property(lambda s: s.w.world_axis_object_components)
    world_axis_object_classes = property(lambda s: s.w.world_axis_object_classes)
    def world_to_pixel_values(self, *w): return self.w.world_to_pixel_values(*w)


class NaNOutside(Failing):
    def pixel_to_world_values(self, *p):
        out = [np.array(v, float) for v in self.w.pixel_to_world_values(*p)]
        bad = np.zeros(np.shape(p[0]), bool)
        for a in p:
            bad |= np.abs(np.asarray(a) - 127.5) > 150
        for o in out:
            o[bad] = np.nan
        return tuple(out)


def s_failing():
    fig, ax = new(Failing(tan())); show(ax)
    return fig, ax


def s_nanwcs():
    fig, ax = new(NaNOutside(tan())); show(ax)
    ax.coords.grid(color="g")
    return fig, ax


def s_spectral1d():
    w = WCS(naxis=1); w.wcs.ctype = ["WAVE"]; w.wcs.cunit = ["Angstrom"]; w.wcs.cdelt = [0.025]; w.wcs.crpix = [1]
    w.wcs.crval = [1402.0]
    fig, ax = new(w); ax.plot(np.random.default_rng(2).random(400))
    return fig, ax


def s_cube_swap():
    w = WCS(naxis=3)
    w.wcs.ctype = ["RA---TAN", "DEC--TAN", "VELO-LSR"]; w.wcs.cunit = ["deg", "deg", "km/s"]
    w.wcs.cdelt = [-0.01, 0.01, 2.0]; w.wcs.crpix = [64.5, 64.5, 1]; w.wcs.crval = [83.6, 22.0, -50]
    fig, ax = new(w, slices=("y", "x", 7)); show(ax, IMG[:128, :128])
    ax.coords[2].set_ticks_position("t"); ax.coords[2].set_ticklabel_position("t")
    return fig, ax


def s_cube_slice():
    w = WCS(naxis=3)
    w.wcs.ctype = ["RA---TAN", "VELO-LSR", "DEC--TAN"]; w.wcs.cunit = ["deg", "km/s", "deg"]
    w.wcs.cdelt = [-0.01, 2.0, 0.01]; w.wcs.crpix = [64.5, 1, 64.5]; w.wcs.crval = [83.6, -50, 22.0]
    fig, ax = new(w, slices=("x", 50, "y")); show(ax, IMG[:128, :128])
    return fig, ax


def s_plotcoord():
    fig, ax = new(tan(crval=(83.6, 22.0), ctype=("RA---TAN", "DEC--TAN"), unit="deg", cdelt=0.01)); show(ax)
    ax.plot_coord(SkyCoord([83.5, 83.7] * u.deg, [21.9, 22.1] * u.deg), "r-")
    ax.scatter_coord(SkyCoord([83.55, 83.65] * u.deg, [22.0, 22.05] * u.deg), color="y")
    return fig, ax


def s_axisoff():
    fig, ax = new(tan()); show(ax); ax.axis("off")
    return fig, ax


SJI = {}


def sji():
    if not SJI:
        from glue_solar.sources.loaders.iris import image_data
        import glue_solar
        print("glue_solar", glue_solar.__file__)
        d = image_data(glob.glob(f"{R}/*4000255147_SJI_1400_t000.fits.gz")[0])
        SJI["d"] = d
    return SJI["d"]


def s_sji_time():
    d = sji(); a = d[d.main_components[0]]
    fig, ax = new(d.coords, slices=("x", "y", a.shape[0] // 2)); show(ax, np.asarray(a[a.shape[0] // 2]))
    ax.coords[2].set_ticks_position("t"); ax.coords[2].set_ticklabel_position("t")  # show the constant time coord
    ax.coords[0].set_ticks(number=7); ax.coords[1].set_ticklabel_position("r")
    return fig, ax


def s_siiv_lt():
    from glue_solar.sources.loaders.iris import raster_data
    d = raster_data(sorted(glob.glob(f"{R}/*4000255147_raster/*_r00000.fits")), windows=["Si IV 1403"])[0]
    a = d[d.main_components[0]]
    i = a.shape[1] // 2
    fig, ax = new(d.coords, slices=("x", i, "y")); show(ax, np.asarray(a[:, i, :]), aspect="auto")
    for c in ax.coords:
        c.set_ticks_position("bltr")
    ax.coords[1].set_ticklabel_position("t")
    return fig, ax


SCEN = {k[2:]: v for k, v in list(globals().items()) if k.startswith("s_")}


def steps(fig, ax):
    x0, x1 = ax.get_xlim(); y0, y1 = ax.get_ylim(); dx, dy = x1 - x0, y1 - y0
    yield "draw", lambda: None
    yield "redraw", lambda: None
    yield "pan", lambda: (ax.set_xlim(x0 + 0.137 * dx, x1 + 0.137 * dx), ax.set_ylim(y0 - 0.09 * dy, y1 - 0.09 * dy))
    yield "zoomin", lambda: (ax.set_xlim(x0 + dx / 4, x1 - dx / 4), ax.set_ylim(y0 + dy / 4, y1 - dy / 4))
    yield "zoomout", lambda: (ax.set_xlim(x0 - 2 * dx, x1 + 2 * dx), ax.set_ylim(y0 - 2 * dy, y1 + 2 * dy))
    yield "offside", lambda: (ax.set_xlim(x1 + 0.5 * dx, x1 + 1.5 * dx), ax.set_ylim(y0, y1))
    yield "back", lambda: (ax.set_xlim(x0, x1), ax.set_ylim(y0, y1))
    yield "resize", lambda: fig.set_size_inches(12.58, 8.1)
    yield "dpi2", lambda: fig.set_dpi(200)
    yield "labels", lambda: (ax.set_xlabel("X label"), ax.set_ylabel("Y label"))
    yield "tick_params", lambda: ax.tick_params(direction="in", length=7, labelsize=6)


res, warns = {}, {}
for name, fn in SCEN.items():
    if ONLY and name not in ONLY:
        continue
    res[name], warns[name] = {}, {}
    try:
        with warnings.catch_warnings(record=True) as wl:
            warnings.simplefilter("always")
            fig, ax = fn()
        warns[name]["setup"] = sorted({f"{w.category.__name__}: {w.message}" for w in wl})
    except Exception as e:
        res[name]["setup"] = f"EXC {type(e).__name__}: {e}"
        continue
    for step, act in list(steps(fig, ax)) + [("savefig_tight", None)]:
        with warnings.catch_warnings(record=True) as wl:
            warnings.simplefilter("always")
            try:
                if act is None:
                    res[name][step] = png(fig)
                else:
                    act()
                    res[name][step] = fingerprint(fig, ax)
            except Exception as e:
                res[name][step] = f"EXC {type(e).__name__}: {e} @ {traceback.extract_tb(e.__traceback__)[-1].name}"
        warns[name][step] = sorted({f"{w.category.__name__}: {w.message}" for w in wl})
    print(name, {k: (v if isinstance(v, str) else v["rgba"]) for k, v in res[name].items()})
json.dump({"res": res, "warns": warns, "stats": memo_patch.STATS if TAG.startswith("memo") else None},
          open(f"/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes/skeptic_minimal/edge_{TAG}.json", "w"), indent=0)
print("stats", memo_patch.STATS if TAG.startswith("memo") else None)
