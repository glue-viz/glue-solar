"""memo_patch through glue's Qt ImageViewer (offscreen), SJI 1400, patch toggled in-process (ABBA).
Static redraws (canvas.draw) and slice steps (state.slices change -> _set_wcs, then canvas.draw)."""
import glob, statistics as st, sys
from time import perf_counter

sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
sys.path.insert(0, "/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes/minimal")
from astropy.visualization.wcsaxes import core
NAMES = ("_update_tick_and_label_positions", "draw_wcsaxes")
ORIG = {n: core.WCSAxes.__dict__[n] for n in NAMES}
import memo_patch
MEMO = {n: core.WCSAxes.__dict__[n] for n in NAMES}

def arm(t):
    for n in NAMES:
        setattr(core.WCSAxes, n, (MEMO if t == "memo" else ORIG)[n])

from glue.core import DataCollection
from glue.core.session import Session
from glue_qt.utils import get_qapp
from glue_qt.viewers.image import ImageViewer
import glue_solar
from glue_solar.sources.loaders.iris import image_data

print("glue_solar", glue_solar.__file__)
app = get_qapp()
d = image_data(glob.glob("/Users/nabil/DATA/IRIS/*4000255147_SJI_1400_t000.fits.gz")[0])
dc = DataCollection([d])
v = ImageViewer(Session(data_collection=dc, hub=dc.hub))
v.add_data(d)
v.show()
v.resize(400 + (v.width() - v.figure.canvas.width()), 330 + (v.height() - v.figure.canvas.height()))
app.processEvents()
canvas = v.figure.canvas
print("canvas", canvas.width(), canvas.height(), "dpr", canvas.device_pixel_ratio)
n = d.shape[0]
R = {t: {"static": [], "step": []} for t in ("base", "memo")}
for t in ("base", "memo") * 3:
    arm(t); canvas.draw()
idx = iter(list(range(n // 2, n)) * 4)
for i in range(30):
    order = ("base", "memo") if i % 2 == 0 else ("memo", "base")
    for t in order:
        arm(t)
        t0 = perf_counter(); canvas.draw(); R[t]["static"].append(perf_counter() - t0)
    for t in order:
        arm(t)
        t0 = perf_counter(); v.state.slices = (next(idx), 0, 0); canvas.draw(); R[t]["step"].append(perf_counter() - t0)
for t, r in R.items():
    print(f"glue ImageViewer sji1400 {t}: static {st.median(r['static'])*1e3:.2f} ms, slice step {st.median(r['step'])*1e3:.2f} ms")
print("stats", memo_patch.STATS)
