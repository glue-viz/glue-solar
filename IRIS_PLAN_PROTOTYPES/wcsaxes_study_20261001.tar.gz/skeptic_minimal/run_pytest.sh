#!/bin/sh
cd /private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes
export HOME="$(mktemp -d)" QT_QPA_PLATFORM=offscreen MPLBACKEND=agg PYTHONPATH=$PWD/minimal
D=$PWD/skeptic_minimal
P=/Users/nabil/mamba/envs/iris-plan/bin/python
WCSAXES_MEMO=1 $P -m pytest -p memo_plugin --pyargs astropy.visualization.wcsaxes -q -p no:cacheprovider -rfE > $D/pt_memo_plain.log 2>&1
$P -m pytest -p memo_plugin --pyargs astropy.visualization.wcsaxes -q -p no:cacheprovider -rfE > $D/pt_base_plain.log 2>&1
FIG_HASHES=$D/fig_base.json $P -m pytest -p memo_plugin --pyargs astropy.visualization.wcsaxes --remote-data=any -q -p no:cacheprovider -rfE > $D/pt_base_fig.log 2>&1
WCSAXES_MEMO=1 FIG_HASHES=$D/fig_memo.json $P -m pytest -p memo_plugin --pyargs astropy.visualization.wcsaxes --remote-data=any -q -p no:cacheprovider -rfE > $D/pt_memo_fig.log 2>&1
FIG_HASHES=$D/fig_base2.json $P -m pytest -p memo_plugin --pyargs astropy.visualization.wcsaxes --remote-data=any -q -p no:cacheprovider -rfE > $D/pt_base2_fig.log 2>&1
echo ALLDONE
