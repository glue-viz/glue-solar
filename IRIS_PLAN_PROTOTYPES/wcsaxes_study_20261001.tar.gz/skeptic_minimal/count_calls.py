"""p2w transform calls per draw on the TAN case, for whichever wcsaxes is loaded (SHADOW env)."""
import os, sys
if os.environ.get("SHADOW"):
    import astropy.visualization as v
    v.__path__.insert(0, os.environ["SHADOW"])
if len(sys.argv) > 1:
    sys.path.insert(0, "/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes/minimal")
    import memo_patch
import numpy as np
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure
from astropy.wcs import WCS
from astropy.visualization.wcsaxes import WCSAxes, wcsapi
n = [0]
f = wcsapi.WCSPixel2WorldTransform.transform
def c(self, p):
    n[0] += 1
    return f(self, p)
wcsapi.WCSPixel2WorldTransform.transform = c
w = WCS(naxis=2); w.wcs.ctype = ["HPLN-TAN", "HPLT-TAN"]; w.wcs.cunit = ["arcsec"] * 2; w.wcs.cdelt = [0.6, 0.6]; w.wcs.crpix = [128.5] * 2
fig = Figure(figsize=(4, 3.3)); FigureCanvasAgg(fig); ax = WCSAxes(fig, [0.25, 0.15, 0.7, 0.75], wcs=w); fig.add_axes(ax)
ax.imshow(np.zeros((256, 256))); fig.canvas.draw(); n[0] = 0; fig.canvas.draw(); d = n[0]; n[0] = 0; ax.set_xlabel("x")
print(wcsapi.__file__.split("/")[-5:-2], "draw calls", d, "set_xlabel calls", n[0], "transform attr left behind:", "transform" in vars(ax.coords._transform))
