import json, sys
def load(t): return json.load(open(f"edge_{t}.json"))
a, b = load(sys.argv[1]), load(sys.argv[2])
nsteps = ndiff = 0
for scen, steps in a["res"].items():
    for step, fa in steps.items():
        fb = b["res"].get(scen, {}).get(step)
        nsteps += 1
        if fa != fb:
            ndiff += 1
            if isinstance(fa, dict) and isinstance(fb, dict):
                keys = [k for k in set(fa) | set(fb) if fa.get(k) != fb.get(k)]
                print("DIFF", scen, step, keys[:8])
            else:
                print("DIFF", scen, step, str(fa)[:100], "|", str(fb)[:100])
    for step, wa in a["warns"].get(scen, {}).items():
        wb = b["warns"].get(scen, {}).get(step)
        if wa != wb:
            print("WARN-DIFF", scen, step, sorted(set(wa) ^ set(wb or [])))
print(f"{sys.argv[1]} vs {sys.argv[2]}: {len(a['res'])} scenarios, {nsteps} steps, {ndiff} differ; stats", b.get("stats"))
