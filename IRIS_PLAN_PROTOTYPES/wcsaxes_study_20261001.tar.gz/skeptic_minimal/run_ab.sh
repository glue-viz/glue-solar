#!/bin/sh
cd /private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes
export HOME="$(mktemp -d)" QT_QPA_PLATFORM=offscreen MPLBACKEND=agg
P=/Users/nabil/mamba/envs/iris-plan/bin/python
for c in sji1400 siiv_spec siiv_lt sji2796 tan; do
  $P skeptic_minimal/ab.py $c 400x330 2>&1 | tail -1
done
$P skeptic_minimal/ab.py sji1400 1258x810 2>&1 | tail -1
for t in base memo memo base; do $P skeptic_minimal/ab.py sji1400 400x330 sep:$t 2>&1 | tail -1; done
for t in base memo memo base; do $P skeptic_minimal/ab.py siiv_spec 400x330 sep:$t 2>&1 | tail -1; done
echo ALLDONE
