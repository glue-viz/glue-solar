"""Risk 3: a transform that warns on every call. Count warnings per draw, base vs memo, under 'always' and default filters."""
import sys, warnings
sys.path.insert(0, "/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes/minimal")
import numpy as np
import astropy.units as u
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure
from astropy.visualization.wcsaxes import WCSAxes, core
from astropy.visualization.wcsaxes.transforms import CurvedTransform
NAMES = ("_update_tick_and_label_positions", "draw_wcsaxes")
ORIG = {n: core.WCSAxes.__dict__[n] for n in NAMES}
import memo_patch
MEMO = {n: core.WCSAxes.__dict__[n] for n in NAMES}

class Warny(CurvedTransform):
    has_inverse = True
    def transform(self, xy):
        warnings.warn("model evaluated", RuntimeWarning)
        return np.array(xy, float) * 2
    transform_non_affine = transform
    def inverted(self):
        return Half()

class Half(CurvedTransform):
    def transform(self, xy): return np.array(xy, float) / 2
    transform_non_affine = transform
    def inverted(self): return Warny()

meta = {"type": ("scalar", "scalar"), "wrap": (None, None), "unit": (u.one, u.one), "name": ("x", "y")}
for flt in ("always", "default"):
    for t in ("base", "memo"):
        for n in NAMES:
            setattr(core.WCSAxes, n, (MEMO if t == "memo" else ORIG)[n])
        fig = Figure(); FigureCanvasAgg(fig); ax = WCSAxes(fig, [0.2, 0.2, 0.7, 0.7], transform=Warny(), coord_meta=meta); fig.add_axes(ax)
        ax.set_xlim(0, 10); ax.set_ylim(0, 10)
        with warnings.catch_warnings(record=True) as wl:
            warnings.simplefilter(flt)
            fig.canvas.draw()
        print(flt, t, "warnings seen in one draw:", len(wl))
