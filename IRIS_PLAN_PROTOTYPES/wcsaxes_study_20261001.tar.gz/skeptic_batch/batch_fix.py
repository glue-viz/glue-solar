"""wcsaxes_batch plus two fixes for the failing-WCS differences found by identity.py.

1. _update_ticks inverts transData up front, as stock does (coordinate_helpers.py:1006), so a
   zero-size axes still raises LinAlgError when every spine is NaN.
2. If the batched shift call raises, fall back to stock's one-call-per-request evaluation, so a WCS
   that raises outside its domain fails (or not) exactly where stock does.
Not fixed: lazy Spine.world still moves a construction-time exception (core.py:151) to draw time.
"""
import numpy as np

import wcsaxes_batch as B

_batched, _ticks = B._shifted_world, B._update_ticks


def _shifted_world(helper, frame, cache, axis, index, shift):
    if not cache.get("unbatched"):
        try:
            return _batched(helper, frame, cache, axis, index, shift)
        except Exception:
            cache["unbatched"] = True
    key = ("one", id(helper.transform), axis, index, shift)
    if key not in cache:
        transData = helper.parent_axes.transData
        pixel = transData.transform(frame[axis].data)
        pixel[:, index] += shift
        with np.errstate(invalid="ignore"):
            cache[key] = helper.transform.transform(transData.inverted().transform(pixel))
    return cache[key]


def _update_ticks(self):
    if self.coord_index is not None:
        self.parent_axes.transData.inverted()
    return _ticks(self)


B._shifted_world = _shifted_world
B._update_ticks = _update_ticks
install, uninstall = B.install, B.uninstall
