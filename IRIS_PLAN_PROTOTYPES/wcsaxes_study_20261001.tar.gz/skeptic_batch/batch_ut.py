def _update_ticks(self):
    if self.coord_index is None:
        return

    coord_range = self.parent_map._coord_range

    tick_world_coordinates, self._fl_spacing = self.locator(*coord_range[self.coord_index])

    if self._ticks.get_display_minor_ticks():
        minor_ticks_w_coordinates = self._formatter_locator.minor_locator(
            self._fl_spacing,
            self.get_minor_frequency(),
            *coord_range[self.coord_index],
        )

    from astropy.visualization.wcsaxes import conf

    cache = getattr(self.parent_map, "_tick_cache", None)
    if cache is None:
        cache = {}
    if "sample" not in cache:
        cache["sample"] = self.frame.sample(conf.frame_boundary_samples)
    frame = cache["sample"]

    self._ticks.clear()
    self._ticklabels.clear()
    self._lblinfo = []
    self._lbl_world = []
    transData = self.parent_axes.transData

    for axis, spine in frame.items():
        if spine.data.size == 0:
            continue

        if not isinstance(self.frame, RectangularFrame1D):
            pixel0 = spine.data
            world0 = spine.world[:, self.coord_index]
            if np.isnan(world0).all():
                continue

            def shifted_pixel_to_world(index, shift):
                return _shifted_world(self, frame, cache, axis, index, shift)[:, self.coord_index]

            world1 = shifted_pixel_to_world(0, 2)
            dx = world1 - world0

            invalid1 = np.isnan(world1)
            if invalid1.any():
                world1 = shifted_pixel_to_world(0, -2)
                dx[invalid1] = (world0 - world1)[invalid1]

            amount = 2.0 if self.frame.origin == "lower" else -2.0
            world2 = shifted_pixel_to_world(1, amount)
            dy = world2 - world0

            invalid2 = np.isnan(world2)
            if invalid2.any():
                world2 = shifted_pixel_to_world(1, -amount)
                dy[invalid2] = (world0 - world2)[invalid2]

            dx, dy = -dy, dx

            if self.coord_type == "longitude":
                if self._coord_scale_to_deg is not None:
                    dx *= self._coord_scale_to_deg
                    dy *= self._coord_scale_to_deg

                dx = wrap_angle_at(dx, 180.0)
                dy = wrap_angle_at(dy, 180.0)

            tick_angle = np.degrees(np.arctan2(dy, dx))

            normal_angle_full = np.hstack([spine.normal_angle, spine.normal_angle[-1]])
            with np.errstate(invalid="ignore"):
                reset = ((normal_angle_full - tick_angle) % 360 > 90.0) & (
                    (tick_angle - normal_angle_full) % 360 > 90.0
                )
            tick_angle[reset] -= 180.0

        else:
            rotation = 90 if axis == "b" else -90
            tick_angle = np.zeros((conf.frame_boundary_samples,)) + rotation

        w1 = spine.world[:-1, self.coord_index]
        w2 = spine.world[1:, self.coord_index]

        if self.coord_type == "longitude":
            if self._coord_scale_to_deg is not None:
                w1 = w1 * self._coord_scale_to_deg
                w2 = w2 * self._coord_scale_to_deg

            w1 = wrap_angle_at(w1, self.coord_wrap.to_value(u.deg))
            w2 = wrap_angle_at(w2, self.coord_wrap.to_value(u.deg))
            with np.errstate(invalid="ignore"):
                w1[w2 - w1 > 180.0] += 360
                w2[w1 - w2 > 180.0] += 360

            if self._coord_scale_to_deg is not None:
                w1 = w1 / self._coord_scale_to_deg
                w2 = w2 / self._coord_scale_to_deg

        self._compute_ticks(tick_world_coordinates, spine, axis, w1, w2, tick_angle)

        if self._ticks.get_display_minor_ticks():
            self._compute_ticks(
                minor_ticks_w_coordinates, spine, axis, w1, w2, tick_angle, ticks="minor"
            )

    text = self.formatter(u.Quantity(self._lbl_world), spacing=self._fl_spacing)

    for kwargs, txt in zip(self._lblinfo, text):
        self._ticklabels.add(text=txt, **kwargs)
