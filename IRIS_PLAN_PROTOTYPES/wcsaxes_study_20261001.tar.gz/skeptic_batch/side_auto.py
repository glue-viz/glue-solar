"""Stock astropy only: does '#' auto placement on the SJI gWCS (3 world coords) break later draws?"""
import glob, sys, traceback
sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
import numpy as np, matplotlib
matplotlib.use("agg")
from matplotlib.figure import Figure
from matplotlib.backends.backend_agg import FigureCanvasAgg
from glue_solar.sources.loaders.iris import image_data
d = image_data(glob.glob("/Users/nabil/DATA/IRIS/*4000255147_SJI_1400_t000.fits.gz")[0])
a = d[d.main_components[0]]
i = a.shape[0] // 2
for variant in ("ticks all + labels #", "labels # only"):
    fig = Figure(figsize=(4, 3.3)); FigureCanvasAgg(fig)
    ax = fig.add_axes([0.15, 0.15, 0.75, 0.75], projection=d.coords, slices=("x", "y", i))
    ax.imshow(np.asarray(a[i]), origin="lower")
    print(variant, [(c.coord_index, c.get_ticks_position(), c.get_ticklabel_position()) for c in ax.coords])
    for c in ax.coords:
        if variant.startswith("ticks"):
            c.set_ticks_position("all")
        c.set_ticklabel_position("#"); c.set_axislabel_position("#")
    for step, act in (("draw", lambda: None), ("invert_x", ax.invert_xaxis), ("redraw", lambda: None), ("uninvert", ax.invert_xaxis)):
        act()
        try:
            fig.canvas.draw(); print("  ", step, "ok", {k: v for c in ax.coords for k, v in c._ticklabels.text.items()})
        except Exception as e:
            tb = traceback.extract_tb(e.__traceback__)[-1]
            print("  ", step, type(e).__name__, e, f"{tb.filename.split('site-packages/')[-1]}:{tb.lineno}")
