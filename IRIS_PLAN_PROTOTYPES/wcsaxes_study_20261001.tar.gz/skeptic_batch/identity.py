"""Edge-case identity of wcsaxes_batch: one process per (group, mode), fingerprints dumped to JSON.

usage: python identity.py <group> <0|1>     group: synthetic | sji1400 | sji2796 | siiv_spec | siiv_lt
Then: python identity.py diff <group>
Plain matplotlib Figure + FigureCanvasAgg; axes via fig.add_axes(projection=wcs, slices=...).
Each step = action, canvas.draw(), fingerprint. Exceptions and warnings are part of the fingerprint.
"""
import collections
import glob
import hashlib
import io
import json
import os
import sys
import traceback
import warnings

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
sys.path.insert(0, os.path.join(HERE, "..", "batch"))
sys.path.insert(0, HERE)

if sys.argv[1] == "diff":
    g = sys.argv[2]
    a = json.load(open(f"{HERE}/fp_{g}_0.json"))
    b = json.load(open(f"{HERE}/fp_{g}_{sys.argv[3] if len(sys.argv) > 3 else 1}.json"))
    nd = 0
    da, db = dict(a), dict(b)
    for sa in list(dict.fromkeys([n for n, _ in a] + [n for n, _ in b])):
        fa, fb = da.get(sa, {"missing": True}), db.get(sa, {"missing": True})
        keys = sorted(k for k in set(fa) | set(fb) if k not in ("calls", "nwarn", "where") and fa.get(k) != fb.get(k))
        tag = "identical" if not keys else f"DIFF {keys[:6]}"
        nd += bool(keys)
        extra = ""
        if fa.get("nwarn") != fb.get("nwarn"):
            extra += f" nwarn {fa.get('nwarn')}->{fb.get('nwarn')}"
        if fa.get("where") != fb.get("where"):
            extra += f" raised-in {fa.get('where')} -> {fb.get('where')}"
        print(f"  {sa:45s} {tag}  p2w {fa.get('calls')} -> {fb.get('calls')}{extra}")
        for k in keys[:3]:
            print("      stock  ", k, str(fa.get(k))[:300])
            print("      patched", k, str(fb.get(k))[:300])
    print(g, "steps", len(da), "/", len(db), "differ", nd)
    sys.exit()

import numpy as np
import matplotlib

matplotlib.use("agg")
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure
import astropy.units as u
from astropy.wcs import WCS
from astropy.visualization.wcsaxes import WCSAxes, wcsapi, frame as fr

GROUP, MODE = sys.argv[1], sys.argv[2]  # 0 stock, 1 wcsaxes_batch, 2 batch_fix
ON = MODE != "0"
if ON:
    import importlib

    importlib.import_module("batch_fix" if MODE == "2" else "wcsaxes_batch").install()

CALLS = collections.Counter()
_t = wcsapi.WCSPixel2WorldTransform.transform


def _counted(self, pixel):
    CALLS["p2w"] += 1
    return _t(self, pixel)


wcsapi.WCSPixel2WorldTransform.transform = wcsapi.WCSPixel2WorldTransform.transform_non_affine = _counted


def h(x):
    return hashlib.sha1(repr(x).encode()).hexdigest()[:16]


def fp_axes(ax, out, p):
    for m, coords in enumerate(ax._all_coords):
        for n, c in enumerate(coords):
            q = f"{p}.m{m}c{n}"
            t = c._ticks
            for f in ("world", "pixel", "angle", "disp", "minor_world", "minor_pixel", "minor_angle", "minor_disp"):
                out[f"{q}.ticks.{f}"] = h(sorted((k, list(v)) for k, v in getattr(t, f).items()))
            tl = c._ticklabels
            for f in ("text", "world", "data", "angle", "disp", "xy"):
                if hasattr(tl, f):
                    out[f"{q}.tl.{f}"] = h(sorted((k, list(v)) for k, v in getattr(tl, f).items()))
            out[f"{q}.nticks"] = sum(len(v) for v in t.world.values())
            out[f"{q}.labels"] = repr(sorted((k, list(v)) for k, v in tl.text.items()))[:400]
            out[f"{q}.axislabel"] = repr((c.get_axislabel(), c._axislabels.get_position(), c._axislabels.get_rotation()))


def fingerprint(fig, extra=None):
    out = {}
    out["rgba"] = hashlib.sha1(np.asarray(fig.canvas.buffer_rgba()).tobytes()).hexdigest()
    for i, ax in enumerate(fig.axes):
        if isinstance(ax, WCSAxes):
            fp_axes(ax, out, f"ax{i}")
    if extra:
        out.update(extra)
    return out


RESULTS = []


def run_step(name, fig, action, extra_fn=None):
    CALLS.clear()
    with warnings.catch_warnings(record=True) as W:
        warnings.simplefilter("always")
        try:
            action()
            fig.canvas.draw()
            fp = fingerprint(fig, extra_fn() if extra_fn else None)
        except Exception as e:
            tb = traceback.extract_tb(e.__traceback__)
            fp = {"exception": f"{type(e).__name__}: {e}", "where": f"{tb[-1].name} ({os.path.basename(tb[-1].filename)})"}
            ast = [f.name for f in tb if "wcsaxes" in f.filename]
            fp["where"] += " via " + "/".join(ast[-4:])
    fp["warnings"] = sorted({f"{w.category.__name__}: {w.message}"[:200] for w in W})
    fp["nwarn"] = len(W)
    fp["calls"] = CALLS["p2w"]
    RESULTS.append((name, fp))


def new_fig(w=400, h=330, dpi=100):
    fig = Figure(figsize=(w / dpi, h / dpi), dpi=dpi)
    FigureCanvasAgg(fig)
    return fig


def raw_at_dpi(fig, dpi):
    def f():
        b = io.BytesIO()
        fig.savefig(b, format="raw", dpi=dpi)
        return {f"raw_dpi{dpi}": hashlib.sha1(b.getvalue()).hexdigest()}

    return f


def tight_png(fig):
    def f():
        b = io.BytesIO()
        fig.savefig(b, format="raw", bbox_inches="tight")
        r = fig.canvas.get_renderer()
        bb = [a.get_tightbbox(r).bounds for a in fig.axes]
        return {"raw_tight": hashlib.sha1(b.getvalue()).hexdigest(), "tightbbox": repr(bb)}

    return f


def hpc_wcs(n=200):
    w = WCS(naxis=2)
    w.wcs.ctype = ["HPLN-TAN", "HPLT-TAN"]
    w.wcs.cunit = ["arcsec", "arcsec"]
    w.wcs.cdelt = [0.6, 0.6]
    w.wcs.crpix = [n / 2 + 0.5, n / 2 + 0.5]
    w.wcs.crval = [-300.0, 200.0]
    w.wcs.dateobs = "2013-09-02T16:39:35"
    w.wcs.set()
    return w


class FailWCS(WCS):
    """FITS WCS whose pixel_to_world_values raises or returns NaN in chosen regions."""

    fail = None
    n = 200

    def pixel_to_world_values(self, *pixel):
        x, y = (np.asarray(p, dtype=float) for p in pixel)
        if self.fail == "always":
            raise ValueError("world transform failed")
        if self.fail == "left_raises" and np.any(x < -1.0):
            raise ValueError("pixel left of the detector")
        world = super().pixel_to_world_values(*pixel)
        if self.fail in ("left_raises", "top_nan"):
            world = [np.where(y > self.n - 0.4, np.nan, wi) for wi in world]
        if self.fail == "all_nan":
            world = [np.full_like(wi, np.nan) for wi in world]
        return world


def fail_wcs(mode):
    w = FailWCS(naxis=2)
    w.wcs.ctype = ["HPLN-TAN", "HPLT-TAN"]
    w.wcs.cunit = ["arcsec", "arcsec"]
    w.wcs.cdelt = [0.6, 0.6]
    w.wcs.crpix = [100.5, 100.5]
    w.wcs.crval = [-300.0, 200.0]
    w.wcs.dateobs = "2013-09-02T16:39:35"
    w.wcs.set()
    w.fail = mode
    return w


def simple(name, wcs, img, steps, rect=(0.15, 0.15, 0.75, 0.75), size=(400, 330), frame_class=None, slices=None):
    fig = new_fig(*size)
    kw = dict(projection=wcs)
    if frame_class:
        kw["frame_class"] = frame_class
    if slices is not None:
        kw["slices"] = slices
    try:
        ax = fig.add_axes(rect, **kw)
        im = ax.imshow(img, origin="lower", cmap="gray")
    except Exception as e:
        tb = traceback.extract_tb(e.__traceback__)
        RESULTS.append((f"{name}:build", {"exception": f"{type(e).__name__}: {e}", "calls": 0, "nwarn": 0,
                                          "where": " <- ".join(f"{f.name}:{f.lineno}" for f in tb[::-1] if "wcsaxes" in f.filename)}))
        return
    ctx = dict(fig=fig, ax=ax, im=im, ny=img.shape[0], nx=img.shape[1])
    for sname, act, *ex in steps:
        run_step(f"{name}:{sname}", fig, (lambda a=act: a(ctx)), ex[0](ctx) if ex else None)


def lims(ax, x0, x1, y0, y1):
    ax.set_xlim(x0, x1)
    ax.set_ylim(y0, y1)


def common_steps():
    """Steps usable on any 2-coordinate image axes."""
    return [
        ("initial", lambda c: None),
        ("spacing_coarse", lambda c: [k.set_ticks(number=3) for k in c["ax"].coords if k.coord_index is not None]),
        ("spacing_dense", lambda c: [k.set_ticks(number=25) for k in c["ax"].coords if k.coord_index is not None]),
        ("number_default", lambda c: [k.set_ticks(number=8) for k in c["ax"].coords if k.coord_index is not None]),
        ("minor_freq7", lambda c: [(k.display_minor_ticks(True), k.set_minor_frequency(7)) for k in c["ax"].coords]),
        ("exclude_overlap", lambda c: [k.set_ticks(exclude_overlapping=True) for k in c["ax"].coords if k.coord_index is not None]),
        ("hide_ticks_c0", lambda c: c["ax"].coords[0].set_ticks_visible(False)),
        ("hide_labels_c1", lambda c: c["ax"].coords[1].set_ticklabel_visible(False)),
        ("hide_both_c0", lambda c: c["ax"].coords[0].set_ticklabel_visible(False)),
        ("unhide", lambda c: [(k.set_ticks_visible(True), k.set_ticklabel_visible(True)) for k in c["ax"].coords]),
        ("pos_empty_c1", lambda c: (c["ax"].coords[1].set_ticks_position(""), c["ax"].coords[1].set_ticklabel_position(""))),
        ("top_right", lambda c: (c["ax"].coords[0].set_ticks_position("t"), c["ax"].coords[0].set_ticklabel_position("t"),
                                 c["ax"].coords[0].set_axislabel_position("t"), c["ax"].coords[1].set_ticks_position("r"),
                                 c["ax"].coords[1].set_ticklabel_position("r"), c["ax"].coords[1].set_axislabel_position("r"),
                                 c["ax"].coords[0].set_axislabel("top"), c["ax"].coords[1].set_axislabel("right"))),
        ("all_auto", lambda c: [(k.set_ticks_position("all"), k.set_ticklabel_position("#"), k.set_axislabel_position("#"))
                                for k in c["ax"].coords]),
        ("invert_x", lambda c: c["ax"].invert_xaxis()),
        ("flip_y_too", lambda c: c["ax"].invert_yaxis()),
        ("zoom_out_5x", lambda c: lims(c["ax"], -2 * c["nx"], 3 * c["nx"], -2 * c["ny"], 3 * c["ny"])),
        ("zoom_in_tiny", lambda c: lims(c["ax"], c["nx"] / 2 - 1.3, c["nx"] / 2 + 1.1, c["ny"] / 2 - 0.9, c["ny"] / 2 + 1.7)),
        ("home", lambda c: lims(c["ax"], -0.5, c["nx"] - 0.5, -0.5, c["ny"] - 0.5)),
        ("dpi_37", lambda c: None, lambda c: raw_at_dpi(c["fig"], 37)),
        ("dpi_250", lambda c: None, lambda c: raw_at_dpi(c["fig"], 250)),
        ("colorbar", lambda c: c["fig"].colorbar(c["im"], ax=c["ax"])),
        ("tight", lambda c: None, lambda c: tight_png(c["fig"])),
        ("small_30x25px", lambda c: c["ax"].set_position([0.1, 0.1, 30 / 400, 25 / 330])),
        ("small_2x2px", lambda c: c["ax"].set_position([0.1, 0.1, 2 / 400, 2 / 330])),
        ("zero_width", lambda c: c["ax"].set_position([0.1, 0.1, 0.0, 0.5])),
        ("zero_size", lambda c: c["ax"].set_position([0.1, 0.1, 0.0, 0.0])),
        ("restore_size", lambda c: c["ax"].set_position([0.15, 0.15, 0.6, 0.75])),
        ("set_xlabel", lambda c: c["ax"].set_xlabel("probe", size=10), lambda c: (lambda: {"xl": c["ax"].get_xlabel(), "yl": c["ax"].get_ylabel()})),
        ("axis_off", lambda c: c["ax"].set_axis_off()),
    ]


def synthetic():
    import sunpy.coordinates  # noqa: F401  registers the solar frames and the FITS-WCS mapping

    rng = np.random.default_rng(0)
    img = rng.random((200, 200))
    simple("hpc", hpc_wcs(), img, common_steps())
    # overlays: HGS and HGC on a helioprojective map, galactic on rotated RA/Dec
    ov_steps = [
        ("hgs_overlay", lambda c: c.__setitem__("ov", c["ax"].get_coords_overlay("heliographic_stonyhurst"))),
        ("hgs_grid_all", lambda c: (c["ov"].grid(True, color="c"), [k.set_ticks_position("all") for k in c["ov"]],
                                    [k.set_ticklabel_position("tr") for k in c["ov"]])),
        ("hgs_spacing", lambda c: c["ov"][0].set_ticks(spacing=0.05 * u.deg)),
        ("hgs_hidden", lambda c: (c["ov"][1].set_ticks_visible(False), c["ov"][1].set_ticklabel_visible(False))),
        ("zoom_out_limb", lambda c: lims(c["ax"], -1800, 2000, -1600, 2000)),
        ("hgc_overlay2", lambda c: c["ax"].get_coords_overlay("heliographic_carrington")),
        ("colorbar", lambda c: c["fig"].colorbar(c["im"], ax=c["ax"])),
        ("tight", lambda c: None, lambda c: tight_png(c["fig"])),
    ]
    simple("hpc_ov", hpc_wcs(), img, ov_steps)
    w = WCS(naxis=2)
    w.wcs.ctype = ["RA---TAN", "DEC--TAN"]
    w.wcs.crval = [2.0, 78.0]
    w.wcs.crpix = [100.5, 100.5]
    w.wcs.cdelt = [-0.1, 0.1]
    th = np.radians(30)
    w.wcs.pc = [[np.cos(th), -np.sin(th)], [np.sin(th), np.cos(th)]]
    simple("radec_rot", w, img, common_steps()[:6] + [
        ("gal_overlay", lambda c: [k.set_ticks_position("all") for k in c["ax"].get_coords_overlay("galactic")]),
        ("zoom_out_pole", lambda c: lims(c["ax"], -600, 800, -600, 800)),
        ("zoom_out_beyond_horizon", lambda c: lims(c["ax"], -1200, 1400, -1200, 1400)),
    ])
    # TAN beyond 90 deg from the tangent point: NaN regions inside the frame
    w2 = WCS(naxis=2)
    w2.wcs.ctype = ["RA---TAN", "DEC--TAN"]
    w2.wcs.crval = [180.0, 0.0]
    w2.wcs.crpix = [100.5, 100.5]
    w2.wcs.cdelt = [-1.0, 1.0]
    simple("tan_nan", w2, img, [("initial", lambda c: None), ("zoom_out", lambda c: lims(c["ax"], -3000, 3200, -3000, 3200))])
    # all-sky in a rectangular frame (NaN spines, NaN fallback) and in an elliptical frame
    w3 = WCS(naxis=2)
    w3.wcs.ctype = ["GLON-AIT", "GLAT-AIT"]
    w3.wcs.crpix = [180.5, 90.5]
    w3.wcs.cdelt = [-1.0, 1.0]
    sky = rng.random((180, 360))
    rect_steps = [("initial", lambda c: lims(c["ax"], -60, 420, -30, 210)),
                  ("fk5_overlay_all", lambda c: [k.set_ticks_position("all") for k in c["ax"].get_coords_overlay("fk5")]),
                  ("spacing", lambda c: c["ax"].coords[0].set_ticks(spacing=15 * u.deg)),
                  ("top_right", lambda c: (c["ax"].coords[0].set_ticks_position("t"), c["ax"].coords[1].set_ticks_position("r"),
                                           c["ax"].coords[0].set_ticklabel_position("t"), c["ax"].coords[1].set_ticklabel_position("r"))),
                  ("flip_y", lambda c: c["ax"].set_ylim(210, -30)),
                  ("small", lambda c: c["ax"].set_position([0.1, 0.1, 0.05, 0.05]))]
    simple("allsky_rect", w3, sky, rect_steps)
    simple("allsky_ell", w3, sky, rect_steps[:3], frame_class=fr.EllipticalFrame)
    # world transform failures
    for mode in ("always", "all_nan", "top_nan", "left_raises"):
        steps = [("initial", lambda c: None), ("pan_left", lambda c: c["ax"].set_xlim(-30, 170)), ("home", lambda c: c["ax"].set_xlim(-0.5, 199.5))]
        if mode == "always":
            steps.append(("axis_off", lambda c: c["ax"].set_axis_off()))
        if mode == "all_nan":
            steps.append(("zero_size", lambda c: c["ax"].set_position([0.1, 0.1, 0.0, 0.0])))
        simple(f"fail_{mode}", fail_wcs(mode), img, steps)
    # 1-D spectrum axes
    w1 = WCS(naxis=1)
    w1.wcs.ctype = ["WAVE"]
    w1.wcs.cunit = ["Angstrom"]
    w1.wcs.crval = [1400.0]
    w1.wcs.cdelt = [0.025]
    w1.wcs.crpix = [1.0]
    fig = new_fig()
    ax = fig.add_axes([0.15, 0.15, 0.75, 0.75], projection=w1)
    ax.plot(np.sin(np.arange(200) / 10.0))
    for sname, act in (("initial", lambda: None), ("top", lambda: ax.coords[0].set_ticks_position("t")),
                       ("spacing", lambda: ax.coords[0].set_ticks(spacing=0.3 * u.AA)),
                       ("small", lambda: ax.set_position([0.1, 0.1, 0.01, 0.01]))):
        run_step(f"spec1d:{sname}", fig, act)


def iris(case):
    import glue_solar
    from glue_solar.sources.loaders.iris import image_data, raster_data

    print("glue_solar", glue_solar.__file__, file=sys.stderr)
    R = "/Users/nabil/DATA/IRIS"
    if case.startswith("sji"):
        pat = "4000255147_SJI_1400_t000.fits.gz" if case == "sji1400" else "4000005156_SJI_2796_t000_deconvolved.fits.gz"
        d = image_data(glob.glob(f"{R}/*{pat}")[0])
        a = d[d.main_components[0]]
        i = a.shape[0] // 2
        img, sl = np.asarray(a[i]), ("x", "y", i)
    else:
        d = raster_data(sorted(glob.glob(f"{R}/*4000255147_raster/*_r00000.fits")), windows=["Si IV 1403"])[0]
        a = d[d.main_components[0]]
        if case == "siiv_spec":
            i = a.shape[0] // 2
            img, sl = np.asarray(a[i]), ("x", "y", i)
        else:
            i = a.shape[1] // 2
            img, sl = np.asarray(a[:, i, :]), ("x", i, "y")
    print(case, "world", d.coords.world_axis_physical_types, "slices", sl, file=sys.stderr)
    steps = common_steps()
    # stock astropy raises (IndexError in simplify_labels / TypeError in _auto) after the auto steps on SJI,
    # in both modes, so run them last to keep the other steps meaningful.
    auto = [s for s in steps if s[0] == "all_auto"]
    steps = [s for s in steps if s[0] not in ("all_auto", "axis_off")] + auto + [s for s in steps if s[0] == "axis_off"]
    if case.startswith("sji"):
        steps.insert(len(steps) - 1, ("hgs_overlay", lambda c: [k.set_ticks_position("all") for k in c["ax"].get_coords_overlay("heliographic_stonyhurst")]))
    simple(case, d.coords, img, steps, slices=sl)


if GROUP == "synthetic":
    synthetic()
else:
    iris(GROUP)
json.dump(RESULTS, open(f"{HERE}/fp_{GROUP}_{MODE}.json", "w"), indent=0)
print(GROUP, "mode", MODE, "steps", len(RESULTS), "exceptions", sum("exception" in r[1] for r in RESULTS))
