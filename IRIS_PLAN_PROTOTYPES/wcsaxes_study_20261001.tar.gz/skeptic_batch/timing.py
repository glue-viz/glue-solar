"""Independent re-timing of wcsaxes_batch: one process per (case, mode), no WCS call counters.

usage: python timing.py <case> <0|1> [mpl]
  case: sji1400 sji2796 siiv_spec siiv_lt tan
  mode 1 installs wcsaxes_batch before any figure is made.
  'mpl' builds the axes with plain fig.add_subplot(projection=wcs, slices=...) instead of glue's init_mpl.
Prints one JSON line of medians (ms).
"""
import glob
import json
import os
import statistics as st
import sys
import warnings
from time import perf_counter

sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "batch"))
import numpy as np
import matplotlib

matplotlib.use("agg")
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure
from astropy.wcs import WCS

warnings.simplefilter("ignore")
CASE, ON = sys.argv[1], sys.argv[2] == "1"
MPL = len(sys.argv) > 3 and sys.argv[3] == "mpl"
R = "/Users/nabil/DATA/IRIS"
if ON:
    import wcsaxes_batch

    wcsaxes_batch.install()


def load():
    import glue_solar
    from glue_solar.sources.loaders.iris import image_data, raster_data

    print("glue_solar", glue_solar.__file__, file=sys.stderr)
    if CASE in ("sji1400", "sji2796"):
        pat = "4000255147_SJI_1400_t000.fits.gz" if CASE == "sji1400" else "4000005156_SJI_2796_t000_deconvolved.fits.gz"
        d = image_data(glob.glob(f"{R}/*{pat}")[0])
        a = d[d.main_components[0]]
        n = a.shape[0]
        return d.coords, 3, 2, 1, (lambda i: a[i]), [(n // 2 + k) % n for k in range(20)], "equal"
    if CASE.startswith("siiv"):
        d = raster_data(sorted(glob.glob(f"{R}/*4000255147_raster/*_r00000.fits")), windows=["Si IV 1403"])[0]
        a = d[d.main_components[0]]
        if CASE == "siiv_spec":
            n = a.shape[0]
            return d.coords, 3, 2, 1, (lambda i: a[i]), [(n // 2 + k) % n for k in range(20)], "auto"
        n = a.shape[1]
        return d.coords, 3, 2, 0, (lambda i: a[:, i, :]), [(n // 2 + k) % n for k in range(20)], "auto"
    w = WCS(naxis=2)
    w.wcs.ctype = ["HPLN-TAN", "HPLT-TAN"]
    w.wcs.cunit = ["arcsec", "arcsec"]
    w.wcs.cdelt = [0.6, 0.6]
    w.wcs.crpix = [512.5, 512.5]
    w.wcs.crval = [-300.0, 200.0]
    w.wcs.dateobs = "2013-09-02T16:39:35"
    img = np.random.default_rng(1).random((1024, 1024), dtype=np.float32)
    return w, 2, 1, 0, (lambda i: img), [None], "equal"


wcs, ndim, X, Y, img_of, steps, aspect = load()


def slices(i):
    if ndim == 2:
        return None
    return ["x" if k == X else "y" if k == Y else i for k in range(ndim)][::-1]


def build(w, h):
    fig = Figure(figsize=(w / 100, h / 100), dpi=100)
    FigureCanvasAgg(fig)
    if MPL:
        ax = fig.add_subplot(projection=wcs, slices=slices(steps[0]) and tuple(slices(steps[0])))
    else:
        from glue.viewers.matplotlib.mpl_axes import init_mpl

        _, ax = init_mpl(figure=fig, wcs=True)
        W, H = w / 100, h / 100
        ax.set_position([1 / W, 0.5 / H, 1 - 1.25 / W, 1 - 0.75 / H])
        ax.reset_wcs(slices=slices(steps[0]), wcs=wcs)
    im = ax.imshow(np.asarray(img_of(steps[0])), origin="lower", cmap="gray", aspect=aspect)
    return fig, ax, im


def step(ax, im, i):
    ax.reset_wcs(slices=slices(i), wcs=wcs)
    ax.set_xlabel("", size=10)
    ax.set_ylabel("", size=10)
    ax.set_xlabel("x label", size=10)
    ax.set_ylabel("y label", size=10)
    for c in ax.coords:
        c.set_ticklabel(size=8)
    im.set_data(np.asarray(img_of(i)))


out = dict(case=CASE, batch=ON, axes="mpl add_subplot" if MPL else "glue init_mpl")
for w, h in ((400, 330), (1258, 810)):
    fig, ax, im = build(w, h)
    for _ in range(5):
        fig.canvas.draw()
    t = []
    for _ in range(40):
        t0 = perf_counter()
        fig.canvas.draw()
        t.append(perf_counter() - t0)
    out[f"draw_{w}"] = st.median(t) * 1e3
    if not MPL:
        t = []
        for _ in range(20):
            t0 = perf_counter()
            ax.set_xlabel("x label", size=10)
            t.append(perf_counter() - t0)
        out[f"set_xlabel_{w}"] = st.median(t) * 1e3
        if ndim == 3:
            ts, tt = [], []
            for i in steps:
                t0 = perf_counter()
                step(ax, im, i)
                t1 = perf_counter()
                fig.canvas.draw()
                t2 = perf_counter()
                ts.append(t1 - t0)
                tt.append(t2 - t0)
            out[f"step_set_{w}"] = st.median(ts) * 1e3
            out[f"step_total_{w}"] = st.median(tt) * 1e3
print(json.dumps({k: (round(v, 2) if isinstance(v, float) else v) for k, v in out.items()}))
