"""Axes on against axes off (WCSAxes axison=False) in a real quicklook, alternating in one process."""
import sys, time, statistics
sys.path.insert(0, "/Users/nabil/Git/glue-solar-frame-time-empty-collapse")
import glue_solar
print(glue_solar.__file__)
from qtpy import QtWidgets
from glue_qt.app.application import GlueApplication
from astropy.visualization.wcsaxes.coordinate_helpers import CoordinateHelper
from glue_solar.quicklook import quicklook
from glue_solar.sources.loaders.iris import image_data, raster_data

D = "/Users/nabil/DATA/IRIS/"
raster = raster_data([D + "2dd2d12db374b3466aa27a65bec235d3-iris_l2_20130902_163935_4000255147_raster/iris_l2_20130902_163935_4000255147_raster_t000_r00000.fits"], windows=["Si IV 1403"])
sji = image_data(D + "534d789bb0a2821fb2b78eb36d1d6753-iris_l2_20130902_163935_4000255147_SJI_1400_t000.fits.gz")
glue_solar.setup()
app = GlueApplication()
viewers = quicklook(app, [*raster, sji])
QtWidgets.QApplication.processEvents()

calls = {"n": 0}
orig = CoordinateHelper._update_ticks
def counted(self):
    calls["n"] += 1
    return orig(self)
CoordinateHelper._update_ticks = counted

panels = {"map": viewers["map"], "spectrogram": viewers["spectrogram"], "wavelength": viewers["wavelength"], "sji": viewers["sji"][0]}
for v in panels.values():
    v.parent().resize(400, 330) if v.parent() else v.resize(400, 330)
QtWidgets.QApplication.processEvents()

def step(v, i):
    s = list(v.state.slices)
    shown = {v.state.x_att.axis, v.state.y_att.axis}
    ax = next(k for k in range(len(s)) if k not in shown)
    n = v.state.reference_data.shape[ax]
    s[ax] = (i * 7) % n
    v.state.slices = tuple(s)

N = 15
res = {}
for name, v in panels.items():
    canvas = v.figure.canvas
    print(name, "size", canvas.get_width_height(), "slices", v.state.slices, flush=True)
    for mode in (True, False):  # warm up both
        v.axes.set_axis_on() if mode else v.axes.set_axis_off()
        canvas.draw(); canvas.draw()
    t = {("draw", m): [] for m in (True, False)} | {("step", m): [] for m in (True, False)}
    c = {k: [] for k in t}
    for i in range(N):
        for m in ((True, False) if i % 2 == 0 else (False, True)):
            v.axes.set_axis_on() if m else v.axes.set_axis_off()
            calls["n"] = 0; t0 = time.perf_counter(); canvas.draw(); t[("draw", m)].append(time.perf_counter() - t0); c[("draw", m)].append(calls["n"])
            calls["n"] = 0; t0 = time.perf_counter(); step(v, i + (0 if m else 50)); QtWidgets.QApplication.processEvents(); canvas.draw()
            t[("step", m)].append(time.perf_counter() - t0); c[("step", m)].append(calls["n"])
            assert v.axes.axison == m, "glue turned the axes back on"
    for kind in ("draw", "step"):
        on, off = (statistics.median(t[(kind, m)]) * 1e3 for m in (True, False))
        con, coff = (statistics.median(c[(kind, m)]) for m in (True, False))
        print(f"  {kind:5s} on {on:7.1f} ms ({con:.0f} tick updates)  off {off:7.1f} ms ({coff:.0f})  saved {100 * (1 - off / on):4.0f} %", flush=True)
    v.axes.set_axis_on()
