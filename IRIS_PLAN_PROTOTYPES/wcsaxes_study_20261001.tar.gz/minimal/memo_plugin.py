"""pytest plugin: run astropy's WCSAxes tests with or without memo_patch, and hash every figure test.

  WCSAXES_MEMO=1  -> install memo_patch before any test module is imported
  FIG_HASHES=path -> run the @figure_test tests without pytest-mpl: render the returned figure the way
                     pytest-mpl would (style context, savefig_kwargs, PNG) and store sha256 per test id,
                     so a base run and a memo run can be compared pixel for pixel.
usage: python -m pytest -p memo_plugin --pyargs astropy.visualization.wcsaxes --remote-data=any
"""
import hashlib
import io
import json
import os

import pytest
from astropy.utils.compat import optional_deps

if os.environ.get("WCSAXES_MEMO") == "1":
    import memo_patch
else:
    memo_patch = None

FIG_HASHES = os.environ.get("FIG_HASHES")
if FIG_HASHES:
    optional_deps.HAS_PYTEST_MPL = True  # read by astropy/tests/figures/helpers.py at import
HASHES = {}


def pytest_configure(config):
    config.addinivalue_line("markers", "mpl_image_compare: pytest-mpl figure test (hashed by memo_plugin)")


@pytest.hookimpl(tryfirst=True)
def pytest_pyfunc_call(pyfuncitem):
    mark = pyfuncitem.get_closest_marker("mpl_image_compare")
    if not FIG_HASHES or mark is None:
        return None
    import matplotlib.pyplot as plt

    kwargs = {a: pyfuncitem.funcargs[a] for a in pyfuncitem._fixtureinfo.argnames}
    with plt.style.context(mark.kwargs.get("style", "classic"), after_reset=True):
        fig = pyfuncitem.obj(**kwargs)
        buf = io.BytesIO()
        fig.savefig(buf, format="png", **mark.kwargs.get("savefig_kwargs", {}))
    plt.close(fig)
    HASHES[pyfuncitem.nodeid] = hashlib.sha256(buf.getvalue()).hexdigest()
    return True


def pytest_sessionfinish(session):
    if FIG_HASHES:
        json.dump(HASHES, open(FIG_HASHES, "w"), indent=0, sort_keys=True)
    print(f"\nmemo_plugin: patch={'on' if memo_patch else 'off'} figures_hashed={len(HASHES)}"
          + (f" memo_stats={memo_patch.STATS}" if memo_patch else ""))
