"""Compare id_<case>_base.json with id_<case>_memo.json step by step; print first differing paths."""
import json, sys


def diff(a, b, path=""):
    if type(a) is not type(b):
        return [path]
    if isinstance(a, dict):
        return [p for k in sorted(set(a) | set(b)) for p in diff(a.get(k), b.get(k), f"{path}/{k}")]
    if isinstance(a, list):
        if len(a) != len(b):
            return [f"{path}[len]"]
        return [p for i, (x, y) in enumerate(zip(a, b)) for p in diff(x, y, f"{path}[{i}]")]
    return [] if a == b else [path]


for case in sys.argv[1:]:
    A, B = (json.load(open(f"id_{case}_{t}.json")) for t in ("base", "memo"))
    ok = len(A["steps"]) == len(B["steps"])
    for sa, sb in zip(A["steps"], B["steps"]):
        same = sa["digest"] == sb["digest"]
        ok &= same
        if not same:
            print(case, sa["step"], "DIFF", diff(sa["state"], sb["state"])[:5])
    n_ticks = sum(len(v) for s in A["steps"] if s["state"] for c in s["state"]["coords"] for v in c["ticks"]["world"].values())
    n_lab = sum(len(v) for s in A["steps"] if s["state"] for c in s["state"]["coords"] for v in c["labels"]["text"].values())
    print(f"{case}: {len(A['steps'])} steps, identical={ok}, ticks compared={n_ticks}, labels compared={n_lab}, memo {B.get('memo_stats')}")
