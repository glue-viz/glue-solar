"""base vs memo tables from out_<case>_{base,base2,memo,memo2}.json (ABBA; each cell = mean of the two runs' medians)."""
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
CASES = ("sji1400", "siiv_spec", "siiv_lt", "sji2796", "tan")
R = {(c, t): json.load(open(f"{HERE}/out_{c}_{t}.json")) for c in CASES for t in ("base", "base2", "memo", "memo2")
     if os.path.exists(f"{HERE}/out_{c}_{t}.json")}


def v(c, kind, size, sect, f):
    xs = [f(R[(c, t)][size][sect]) for t in ((kind, kind + "2")) if (c, t) in R and sect in R[(c, t)][size]]
    return sum(xs) / len(xs) if xs else None


def g(k):
    return lambda d: d["stage_ms"].get(k, 0.0)


wcsax = lambda d: g("WCSAxes.draw_wcsaxes")(d) + g("frame._update_patch_path")(d)
both = lambda f: lambda d: f(d)


def cell(c, size, sect, f, fmt="{:.1f}"):
    b, m = v(c, "base", size, sect, f), v(c, "memo", size, sect, f)
    if b is None:
        return "-"
    return f"{fmt.format(b)} → {fmt.format(m)} ({100 * (m - b) / b:+.0f}%)" if b else f"{fmt.format(b)} → {fmt.format(m)}"


calls = lambda d: f"{d['p2w']:.0f}"
print("| case | panel | draw ms | WCSAxes ms | placement ms | p2w calls (distinct) | p2w ms | pan draw ms | static output identical |")
print("|---|---|---|---|---|---|---|---|---|")
for c in CASES:
    for size in ("400x330", "1258x810"):
        mb = R[(c, "base")][size]["static"]
        mm = R[(c, "memo")][size]["static"]
        print(f"| {c} | {size} | {cell(c, size, 'static', g('canvas.draw'))} | {cell(c, size, 'static', wcsax)} | "
              f"{cell(c, size, 'static', g('update_ticks_all'))} | {mb['p2w']:.0f} ({mb['p2w_distinct']:.0f}) → {mm['p2w']:.0f} ({mm['p2w_distinct']:.0f}) | "
              f"{cell(c, size, 'static', lambda d: d['p2w_ms'])} | {cell(c, size, 'pan', g('canvas.draw'))} | "
              f"{mm['fingerprint_identical']} |")
print()
print("| case | panel | glue set phase ms (reset_wcs + 4 label sets) | p2w calls in set phase | draw after step ms | step total ms | one set_xlabel ms (p2w calls) |")
print("|---|---|---|---|---|---|---|")
for c in CASES:
    for size in ("400x330", "1258x810"):
        rb, rm = R[(c, "base")][size], R[(c, "memo")][size]
        one = (f"{cell(c, size, 'set_xlabel_alone', g('WCSAxes.set_xlabel'))} "
               f"({rb['set_xlabel_alone']['p2w']:.0f} → {rm['set_xlabel_alone']['p2w']:.0f})")
        if "step_set_phase" not in rb:
            print(f"| {c} | {size} | - | - | - | - | {one} |")
            continue
        tot = lambda kind: v(c, kind, size, "step_set_phase", g("glue_set_phase")) + v(c, kind, size, "step_draw", g("canvas.draw"))
        b, m = tot("base"), tot("memo")
        print(f"| {c} | {size} | {cell(c, size, 'step_set_phase', g('glue_set_phase'))} | "
              f"{rb['step_set_phase']['p2w']:.0f} → {rm['step_set_phase']['p2w']:.0f} | {cell(c, size, 'step_draw', g('canvas.draw'))} | "
              f"{b:.1f} → {m:.1f} ({100 * (m - b) / b:+.0f}%) | {one} |")
print()
for c in CASES:
    print(c, "memo stats", R[(c, "memo")]["memo_stats"], "rss GB", round(max(R[(c, t)]["rss_gb"] for t in ("base", "memo")), 2))
    print("   memo static sites", R[(c, "memo")]["400x330"]["static"]["sites"])
