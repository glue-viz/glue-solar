"""astropy-benchmarks' visualization/wcsaxes.py time_basic_plot* (MSX header, copied), plus a sliced 3-D cube
(tests/data/cube_header) as a candidate new benchmark. usage: python bench_asv.py <base|memo>"""
import statistics as st
import sys
from time import perf_counter

import numpy as np
from astropy.io import fits
from astropy.utils.data import get_pkg_data_filename
from astropy.wcs import WCS
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from matplotlib.figure import Figure

if sys.argv[1] == "memo":
    import memo_patch
from astropy.visualization.wcsaxes import WCSAxes

D = "astropy.visualization.wcsaxes.tests"
MSX_WCS = WCS(fits.Header.fromtextfile(get_pkg_data_filename("data/msx_header", D)))
CUBE_WCS = WCS(fits.Header.fromtextfile(get_pkg_data_filename("data/cube_header", D)))


def plot(grid=False, overlay=False, wcs=MSX_WCS, slices=None):
    fig = Figure()
    canvas = FigureCanvas(fig)
    ax = WCSAxes(fig, [0.15, 0.15, 0.7, 0.7], wcs=wcs, slices=slices)
    fig.add_axes(ax)
    if grid:
        ax.grid(color="red", alpha=0.5, linestyle="solid")
    ax.set_xlim(-0.5, 148.5)
    ax.set_ylim(-0.5, 148.5)
    if overlay:
        ov = ax.get_coords_overlay("fk5")
        ov.grid(color="purple", ls="dotted")
    canvas.draw()


cases = {
    "time_basic_plot": lambda: plot(),
    "time_basic_plot_with_grid": lambda: plot(grid=True),
    "time_basic_plot_with_grid_and_overlay": lambda: plot(grid=True, overlay=True),
    "sliced cube_header (x, 50, y)": lambda: plot(wcs=CUBE_WCS, slices=("x", 50, "y")),
}
for name, f in cases.items():
    for _ in range(3):
        f()
    ts = []
    for _ in range(25):
        t = perf_counter()
        f()
        ts.append(perf_counter() - t)
    print(f"{sys.argv[1]} {name}: {st.median(ts) * 1e3:.1f} ms")
