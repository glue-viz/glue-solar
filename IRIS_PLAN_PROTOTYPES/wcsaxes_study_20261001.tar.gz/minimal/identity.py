"""Record everything WCSAxes produces over a pan/zoom/slice/resize sequence, exactly (bit patterns).

usage: python identity.py <case> <base|memo>   -> id_<case>_<tag>.json
cases: sji1400 sji2796 siiv_spec siiv_lt tan rot (rotated RA/Dec TAN + galactic overlay + grid lines)
       allsky (Aitoff, EllipticalFrame, grid lines, off-sky NaN)
Plain matplotlib Agg + glue's init_mpl axes; reset_wcs with glue's wcsaxes_slice; glue's 4 label sets per slice step.
"""
import glob
import hashlib
import io
import json
import sys

sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
import numpy as np
import matplotlib

matplotlib.use("agg")
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure

CASE, TAG = sys.argv[1], sys.argv[2]
if TAG == "memo":
    import memo_patch
from astropy.wcs import WCS
from glue.viewers.matplotlib.mpl_axes import init_mpl

R = "/Users/nabil/DATA/IRIS"


def load():
    """(wcs, img(idx), x, y, ndim, [idx...], labels, frame_class)"""
    if CASE in ("sji1400", "sji2796"):
        from glue_solar.sources.loaders.iris import image_data
        import glue_solar

        print("glue_solar", glue_solar.__file__)
        pat = "4000255147_SJI_1400_t000.fits.gz" if CASE == "sji1400" else "4000005156_SJI_2796_t000_deconvolved.fits.gz"
        d = image_data(glob.glob(f"{R}/*{pat}")[0])
        arr = d[d.main_components[0]]
        n = arr.shape[0]
        lab = (d.world_component_ids[2].label, d.world_component_ids[1].label)
        return d.coords, (lambda i: arr[i]), 2, 1, 3, [n // 2, n // 2 + 1, n - 1], lab, None
    if CASE.startswith("siiv"):
        from glue_solar.sources.loaders.iris import raster_data
        import glue_solar

        print("glue_solar", glue_solar.__file__)
        d = raster_data(sorted(glob.glob(f"{R}/*4000255147_raster/*_r00000.fits")), windows=["Si IV 1403"])[0]
        arr = d[d.main_components[0]]
        if CASE == "siiv_spec":
            x, y, n, img = 2, 1, arr.shape[0], (lambda i: arr[i])
        else:
            x, y, n, img = 2, 0, arr.shape[1], (lambda i: arr[:, i, :])
        lab = (d.world_component_ids[x].label, d.world_component_ids[y].label)
        return d.coords, img, x, y, 3, [n // 2, n // 2 + 1, 0], lab, None
    w = WCS(naxis=2)
    rng = np.random.default_rng(0)
    if CASE == "tan":
        w.wcs.ctype = ["HPLN-TAN", "HPLT-TAN"]
        w.wcs.cunit = ["arcsec", "arcsec"]
        w.wcs.cdelt = [0.6, 0.6]
        w.wcs.crpix = [512.5, 512.5]
        w.wcs.crval = [-300.0, 200.0]
        w.wcs.dateobs = "2013-09-02T16:39:35"
        img = rng.random((1024, 1024), dtype=np.float32)
        return w, (lambda i: img), 1, 0, 2, [None], ("x world", "y world"), None
    if CASE == "rot":  # 3 deg field near the north celestial pole, rotated 30 deg: curved, wrapping RA
        w.wcs.ctype = ["RA---TAN", "DEC--TAN"]
        w.wcs.crpix = [256.5, 256.5]
        w.wcs.crval = [45.0, 88.5]
        c, s = np.cos(np.radians(30)), np.sin(np.radians(30))
        w.wcs.cdelt = [-0.01, 0.01]
        w.wcs.pc = [[c, -s], [s, c]]
        img = rng.random((512, 512), dtype=np.float32)
        return w, (lambda i: img), 1, 0, 2, [None], ("RA", "Dec"), None
    # allsky Aitoff in galactic coordinates
    from astropy.visualization.wcsaxes.frame import EllipticalFrame

    w.wcs.ctype = ["GLON-AIT", "GLAT-AIT"]
    w.wcs.crpix = [180.5, 90.5]
    w.wcs.cdelt = [-1.0, 1.0]
    w.wcs.crval = [0.0, 0.0]
    img = rng.random((180, 360), dtype=np.float32)
    return w, (lambda i: img), 1, 0, 2, [None], ("l", "b"), EllipticalFrame


def glue_slices(ndim, x, y, idx):
    if ndim == 2:
        return None
    s = ["x" if i == x else "y" if i == y else idx for i in range(ndim)]
    return s[::-1]


def canon(o):
    """Exact, JSON-able form: floats as hex bit patterns, arrays as dtype/shape/sha1 of bytes."""
    if hasattr(o, "unit") and hasattr(o, "value"):
        return ["Q", str(o.unit), canon(np.asarray(o.value))]
    if isinstance(o, np.ndarray):
        a = np.ascontiguousarray(o)
        if a.dtype == object:
            return [canon(v) for v in a.ravel()]
        return ["A", a.dtype.str, list(a.shape), hashlib.sha1(a.tobytes()).hexdigest()]
    if isinstance(o, (float, np.floating)):
        return float(o).hex()
    if isinstance(o, (bool, np.bool_)):
        return bool(o)
    if isinstance(o, (int, np.integer)):
        return int(o)
    if isinstance(o, dict):
        return {str(k): canon(v) for k, v in sorted(o.items(), key=lambda kv: str(kv[0]))}
    if isinstance(o, (list, tuple)):
        return [canon(v) for v in o]
    if o is None or isinstance(o, str):
        return o
    if hasattr(o, "bounds"):  # Bbox
        return canon(np.asarray(o.bounds))
    return repr(o)


def record(fig, ax, label):
    canvas = fig.canvas
    canvas.draw()
    st = {"img": hashlib.sha256(np.asarray(canvas.buffer_rgba()).tobytes()).hexdigest()}
    coords = []
    for m, cmap in enumerate(ax._all_coords):
        for coord in cmap:
            t, tl, al = coord._ticks, coord._ticklabels, coord._axislabels
            coords.append({
                "map": m, "index": coord.coord_index, "type": coord.coord_type,
                "ticks": {k: getattr(t, k) for k in ("world", "pixel", "angle", "disp", "minor_world", "minor_pixel",
                                                    "minor_angle", "minor_disp", "ticks_locs")},
                "labels": {k: getattr(tl, k) for k in ("world", "data", "angle", "tick_angle", "text", "disp")},
                "label_bboxes": tl._all_bboxes,
                "axislabel": [coord.get_axislabel(), al.get_text(), al.get_position(), al.get_rotation(), al.get_visible()],
                "positions": [coord.get_ticks_position(), coord.get_ticklabel_position(), coord.get_axislabel_position()],
                "spacing": getattr(coord, "_fl_spacing", None),
            })
    st["coords"] = coords
    x0, x1 = ax.get_xlim()
    y0, y1 = ax.get_ylim()
    st["format_coord"] = [ax.format_coord(x0 + f * (x1 - x0), y0 + g * (y1 - y0)) for f, g in ((.1, .2), (.5, .5), (.93, .71))]
    st["xlabel"], st["ylabel"] = ax.get_xlabel(), ax.get_ylabel()
    c = canon(st)
    return label, c, hashlib.sha256(json.dumps(c, sort_keys=True).encode()).hexdigest()


def main():
    wcs, img_of, x, y, ndim, idxs, labels, frame_class = load()
    fig = Figure(figsize=(4.0, 3.3), dpi=100)
    FigureCanvasAgg(fig)
    if frame_class is None:
        _, ax = init_mpl(figure=fig, wcs=True)
        ax.set_position([1 / 4.0, 0.5 / 3.3, 1 - 1.25 / 4.0, 1 - 0.75 / 3.3])
    else:
        ax = fig.add_subplot(projection=wcs, frame_class=frame_class)

    def set_wcs(idx):  # glue ImageViewer._set_wcs + _update_axes
        ax.reset_wcs(slices=glue_slices(ndim, x, y, idx), wcs=wcs)
        for c in ax.coords:
            c.set_ticklabel(size=8)
        ax.set_xlabel("", size=10)
        ax.set_ylabel("", size=10)
        ax.set_xlabel(labels[0], size=10)
        ax.set_ylabel(labels[1], size=10)
        if CASE == "rot":
            ax.coords.grid(color="w", alpha=0.5)
            ov = ax.get_coords_overlay("galactic")
            ov.grid(color="y", ls="dotted")
            ov[0].set_axislabel("l")
            ov[1].set_axislabel("b")
        if CASE == "allsky":
            ax.coords.grid(color="k")

    set_wcs(idxs[0])
    im = ax.imshow(np.asarray(img_of(idxs[0])), origin="lower", cmap="gray", interpolation="nearest",
                   aspect="auto" if CASE.startswith("siiv") else "equal")
    ny, nx = np.asarray(img_of(idxs[0])).shape
    ax.set_xlim(-0.5, nx - 0.5)
    ax.set_ylim(-0.5, ny - 0.5)

    out = [record(fig, ax, "initial")]
    out.append(record(fig, ax, "redraw"))
    x0, x1 = ax.get_xlim()
    y0, y1 = ax.get_ylim()
    w, h = x1 - x0, y1 - y0
    ax.set_xlim(x0 + 0.137 * w, x1 + 0.137 * w)
    out.append(record(fig, ax, "pan x"))
    ax.set_ylim(y0 - 0.09 * h, y1 - 0.09 * h)
    out.append(record(fig, ax, "pan y"))
    cx, cy = x0 + 0.4 * w, y0 + 0.55 * h
    ax.set_xlim(cx - w / 4, cx + w / 4)
    ax.set_ylim(cy - h / 4, cy + h / 4)
    out.append(record(fig, ax, "zoom in 2x"))
    ax.set_xlim(cx - 1.5 * w, cx + 1.5 * w)
    ax.set_ylim(cy - 1.5 * h, cy + 1.5 * h)
    out.append(record(fig, ax, "zoom out 3x (off footprint)"))
    ax.set_xlim(x0, x1)
    ax.set_ylim(y0, y1)
    for idx in idxs[1:]:
        set_wcs(idx)
        im.set_data(np.asarray(img_of(idx)))
        out.append(record(fig, ax, f"slice {idx}"))
    fig.set_size_inches(12.58, 8.10)
    if frame_class is None:
        ax.set_position([1 / 12.58, 0.5 / 8.10, 1 - 1.25 / 12.58, 1 - 0.75 / 8.10])
    out.append(record(fig, ax, "resize 1258x810"))
    ax.set_xlabel(labels[0] + " again", size=10)  # eager label path with nothing drawn since
    ax.set_ylabel(labels[1] + " again", size=10)
    out.append(record(fig, ax, "relabel after resize"))
    buf = io.BytesIO()
    fig.savefig(buf, format="png", bbox_inches="tight", metadata={"Software": None})  # get_tightbbox path
    out.append(("savefig tight png", None, hashlib.sha256(buf.getvalue()).hexdigest()))
    res = dict(case=CASE, tag=TAG, steps=[{"step": s, "digest": d, "state": c} for s, c, d in out])
    if TAG == "memo":
        res["memo_stats"] = memo_patch.STATS
    json.dump(res, open(f"{sys.path[1]}/id_{CASE}_{TAG}.json", "w"))
    print(CASE, TAG, [d[:8] for _, _, d in out], res.get("memo_stats"))


main()
