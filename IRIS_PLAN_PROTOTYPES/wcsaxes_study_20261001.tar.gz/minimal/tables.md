| case | panel | draw ms | WCSAxes ms | placement ms | p2w calls (distinct) | p2w ms | pan draw ms | static output identical |
|---|---|---|---|---|---|---|---|---|
| sji1400 | 400x330 | 27.4 → 21.2 (-23%) | 23.1 → 16.9 (-27%) | 16.5 → 10.0 (-39%) | 37 (17) → 21 (17) | 15.9 → 9.4 (-41%) | 28.5 → 21.1 (-26%) | True |
| sji1400 | 1258x810 | 34.3 → 27.4 (-20%) | 23.8 → 17.1 (-28%) | 16.8 → 10.1 (-40%) | 37 (17) → 21 (17) | 16.2 → 9.5 (-41%) | 33.8 → 27.3 (-19%) | True |
| siiv_spec | 400x330 | 22.3 → 19.2 (-14%) | 18.9 → 15.9 (-16%) | 8.0 → 5.1 (-36%) | 53 (17) → 21 (17) | 5.3 → 2.4 (-55%) | 22.5 → 18.8 (-16%) | True |
| siiv_spec | 1258x810 | 34.2 → 30.9 (-10%) | 19.1 → 16.1 (-16%) | 8.2 → 5.3 (-35%) | 53 (17) → 21 (17) | 5.4 → 2.4 (-55%) | 33.0 → 30.9 (-6%) | True |
| siiv_lt | 400x330 | 39.5 → 35.5 (-10%) | 30.7 → 27.1 (-12%) | 10.6 → 6.9 (-34%) | 59 (20) → 24 (20) | 6.6 → 2.8 (-57%) | 39.4 → 35.9 (-9%) | True |
| siiv_lt | 1258x810 | 50.7 → 48.6 (-4%) | 30.5 → 27.7 (-9%) | 10.5 → 7.1 (-32%) | 59 (20) → 24 (20) | 6.5 → 2.9 (-55%) | 50.8 → 49.0 (-4%) | True |
| sji2796 | 400x330 | 48.7 → 41.9 (-14%) | 26.7 → 19.7 (-26%) | 17.7 → 10.7 (-39%) | 37 (17) → 21 (17) | 16.6 → 9.7 (-42%) | 50.4 → 41.8 (-17%) | True |
| sji2796 | 1258x810 | 58.9 → 51.7 (-12%) | 27.0 → 19.7 (-27%) | 17.7 → 10.6 (-40%) | 37 (17) → 21 (17) | 16.8 → 9.7 (-42%) | 59.3 → 52.1 (-12%) | True |
| tan | 400x330 | 23.4 → 22.9 (-2%) | 7.9 → 7.4 (-7%) | 3.6 → 3.1 (-13%) | 37 (17) → 21 (17) | 1.4 → 0.8 (-41%) | 23.3 → 23.2 (-1%) | True |
| tan | 1258x810 | 30.8 → 30.2 (-2%) | 8.0 → 7.5 (-6%) | 3.6 → 3.1 (-13%) | 37 (17) → 21 (17) | 1.4 → 0.8 (-40%) | 30.9 → 30.4 (-2%) | True |

| case | panel | glue set phase ms (reset_wcs + 4 label sets) | p2w calls in set phase | draw after step ms | step total ms | one set_xlabel ms (p2w calls) |
|---|---|---|---|---|---|---|
| sji1400 | 400x330 | 66.5 → 39.6 (-40%) | 132 → 68 | 27.6 → 21.0 (-24%) | 94.1 → 60.5 (-36%) | 16.7 → 9.7 (-42%) (33 → 17) |
| sji1400 | 1258x810 | 65.8 → 39.8 (-40%) | 132 → 68 | 33.7 → 27.4 (-19%) | 99.6 → 67.1 (-33%) | 16.2 → 9.5 (-41%) (33 → 17) |
| siiv_spec | 400x330 | 33.2 → 20.6 (-38%) | 196 → 68 | 22.1 → 18.9 (-15%) | 55.3 → 39.5 (-29%) | 7.9 → 4.8 (-39%) (49 → 17) |
| siiv_spec | 1258x810 | 31.7 → 20.4 (-36%) | 196 → 68 | 33.0 → 31.6 (-4%) | 64.7 → 52.1 (-20%) | 7.4 → 4.8 (-35%) (49 → 17) |
| siiv_lt | 400x330 | 41.0 → 26.2 (-36%) | 220 → 80 | 36.5 → 32.8 (-10%) | 77.5 → 59.0 (-24%) | 10.2 → 6.4 (-37%) (55 → 20) |
| siiv_lt | 1258x810 | 41.1 → 26.9 (-34%) | 220 → 80 | 49.1 → 46.6 (-5%) | 90.2 → 73.6 (-18%) | 9.9 → 6.7 (-33%) (55 → 20) |
| sji2796 | 400x330 | 69.1 → 41.3 (-40%) | 132 → 68 | 48.7 → 41.5 (-15%) | 117.9 → 82.8 (-30%) | 17.5 → 10.0 (-43%) (33 → 17) |
| sji2796 | 1258x810 | 70.4 → 41.4 (-41%) | 132 → 68 | 59.5 → 51.8 (-13%) | 129.9 → 93.2 (-28%) | 17.2 → 10.2 (-41%) (33 → 17) |
| tan | 400x330 | - | - | - | - | 3.2 → 2.7 (-14%) (33 → 17) |
| tan | 1258x810 | - | - | - | - | 3.1 → 2.7 (-13%) (33 → 17) |

sji1400 memo stats {'hit': 5696, 'miss': 6052} rss GB 1.25
   memo static sites [['coord_range', 1], ['patch_path.update_spines', 4], ['sample.resampled_spines', 4], ['sample.update_spines', 4], ['shifted_pixel_to_world', 8]]
siiv_spec memo stats {'hit': 11392, 'miss': 6052} rss GB 1.61
   memo static sites [['coord_range', 1], ['patch_path.update_spines', 4], ['sample.resampled_spines', 4], ['sample.update_spines', 4], ['shifted_pixel_to_world', 8]]
siiv_lt memo stats {'hit': 12448, 'miss': 7108} rss GB 1.62
   memo static sites [['coord_range', 1], ['patch_path.update_spines', 4], ['sample.resampled_spines', 4], ['sample.update_spines', 4], ['shifted_pixel_to_world', 11]]
sji2796 memo stats {'hit': 5696, 'miss': 6052} rss GB 1.06
   memo static sites [['coord_range', 1], ['patch_path.update_spines', 4], ['sample.resampled_spines', 4], ['sample.update_spines', 4], ['shifted_pixel_to_world', 8]]
tan memo stats {'hit': 3136, 'miss': 3332} rss GB 0.69
   memo static sites [['coord_range', 1], ['patch_path.update_spines', 4], ['sample.resampled_spines', 4], ['sample.update_spines', 4], ['shifted_pixel_to_world', 8]]
