"""Runtime monkeypatch: memoize WCSAxes' pixel->world transform for one tick placement.

Upstream equivalent (astropy/visualization/wcsaxes/core.py): while ``coords._coord_range`` is alive
(set in ``_update_tick_and_label_positions``, deleted there or after the grid in ``draw_wcsaxes``,
astropy#16366), ``coords._transform.transform`` returns a copy of the first result for a repeated input.
The WCS cannot change inside that scope, which is the per-draw context astrofrog asked for on #16362,
so nothing is cached across draws and nothing needs invalidating.

Here the scope is the whole of ``_update_tick_and_label_positions`` and ``draw_wcsaxes`` (the latter
also covers the grid, as ``_coord_range`` does; tick/label drawing after it makes no transform calls).
``import memo_patch`` installs it.
"""
import functools
from contextlib import ExitStack, contextmanager

import numpy as np
from astropy.visualization.wcsaxes import core

STATS = {"hit": 0, "miss": 0}


@contextmanager
def memoized(transform):
    if "transform" in vars(transform):  # already memoized by an enclosing scope
        yield
        return
    compute = transform.transform
    cache = {}

    def transform_memo(values):
        arr = np.asarray(values)
        key = (arr.shape, arr.dtype.str, arr.tobytes())
        if key in cache:
            STATS["hit"] += 1
        else:
            STATS["miss"] += 1
            cache[key] = compute(values)
        return cache[key].copy(order="K")  # same layout as computed; callers keep views, never share one array

    transform.transform = transform_memo  # instance attribute shadows the method for every caller
    try:
        yield
    finally:
        del transform.transform


def _scoped(method):
    @functools.wraps(method)
    def wrapper(self, *args, **kwargs):
        with ExitStack() as stack:
            for coords in self._all_coords:
                stack.enter_context(memoized(coords._transform))
            return method(self, *args, **kwargs)

    return wrapper


for _name in ("_update_tick_and_label_positions", "draw_wcsaxes"):
    setattr(core.WCSAxes, _name, _scoped(core.WCSAxes.__dict__[_name]))
