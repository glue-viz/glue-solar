#!/bin/sh
# ABBA: base, memo, memo2, base2 per case, one process each
cd /private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes
export HOME="$(mktemp -d)" QT_QPA_PLATFORM=offscreen MPLBACKEND=agg
for c in sji1400 siiv_spec siiv_lt sji2796 tan; do
  for t in base memo memo2 base2; do
    /Users/nabil/mamba/envs/iris-plan/bin/python minimal/measure.py $c $t > minimal/log_${c}_${t}.txt 2>&1 || echo "FAIL $c $t"
  done
done
echo ALLDONE
