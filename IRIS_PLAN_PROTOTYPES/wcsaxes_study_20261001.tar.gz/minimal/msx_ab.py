"""In-process A/B on the MSX header (astropy-benchmarks time_basic_plot): first draw of a fresh axes, and a redraw.
Alternates patch off/on every repetition. usage: python msx_ab.py [grid|overlay]"""
import sys
MODE = sys.argv[1] if len(sys.argv) > 1 else ""
import statistics as st
from time import perf_counter

from astropy.io import fits
from astropy.utils.data import get_pkg_data_filename
from astropy.visualization.wcsaxes import WCSAxes, core
from astropy.wcs import WCS
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from matplotlib.figure import Figure

NAMES = ("_update_tick_and_label_positions", "draw_wcsaxes")
ORIG = {n: core.WCSAxes.__dict__[n] for n in NAMES}
import memo_patch

MEMO = {n: core.WCSAxes.__dict__[n] for n in NAMES}
W = WCS(fits.Header.fromtextfile(get_pkg_data_filename("data/msx_header", "astropy.visualization.wcsaxes.tests")))
T = {k: [] for k in ("base first", "memo first", "base redraw", "memo redraw", "base placement", "memo placement")}
for i in range(240):
    tag = "memo" if i % 2 else "base"
    for n in NAMES:
        setattr(core.WCSAxes, n, (MEMO if tag == "memo" else ORIG)[n])
    fig = Figure()
    canvas = FigureCanvas(fig)
    ax = WCSAxes(fig, [0.15, 0.15, 0.7, 0.7], wcs=W)
    fig.add_axes(ax)
    ax.set_xlim(-0.5, 148.5)
    ax.set_ylim(-0.5, 148.5)
    if MODE:
        ax.grid(color='red', alpha=0.5, linestyle='solid')
    if MODE == 'overlay':
        ax.get_coords_overlay('fk5').grid(color='purple', ls='dotted')
    t = perf_counter(); canvas.draw(); t1 = perf_counter(); canvas.draw(); t2 = perf_counter()
    ax._update_tick_and_label_positions(); t3 = perf_counter()
    if i >= 20:
        T[f"{tag} first"].append(t1 - t); T[f"{tag} redraw"].append(t2 - t1); T[f"{tag} placement"].append(t3 - t2)
for k, v in T.items():
    print(f"{k}: {st.median(v) * 1e3:.3f} ms")
