# memo bookkeeping cost per call (key + lookup + copy), vs the WCS call costs in measure/tables.md
import numpy as np
from time import perf_counter
import statistics as st
for n in (2, 1000, 2601):
    a = np.random.default_rng(0).random((n, 2)); out = np.random.default_rng(1).random((n, 3)); cache = {}
    ts = []
    for _ in range(2000):
        t = perf_counter(); arr = np.asarray(a); key = (arr.shape, arr.dtype.str, arr.tobytes())
        if key not in cache: cache[key] = out
        r = cache[key].copy(); ts.append(perf_counter() - t)
    print(n, "pts: %.2f us" % (st.median(ts) * 1e6))
