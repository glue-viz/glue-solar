import sys, traceback
from collections import Counter
sys.path.insert(0, "/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes/explain")
import calls
ax, fig, low = calls.ax, calls.fig, calls.low
low.pixel_to_world_values = calls.spy
ax.coords.grid(True)
calls.log.clear()
try:
    fig.canvas.draw()
except Exception:
    traceback.print_exc(limit=-4)
c = Counter(x[0] for x in calls.log)
print(f"GRID DRAW: {len(calls.log)} calls, {len({x[1] for x in calls.log})} distinct")
for k, v in c.most_common():
    print(f"  {v:3d}  {k}")
