import sys, time, statistics
sys.path.insert(0, "/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes/explain")
import calls
from astropy.wcs.wcsapi import SlicedLowLevelWCS
ax, fig = calls.ax, calls.fig
n = [0]
o = SlicedLowLevelWCS.pixel_to_world_values
def c(self, *p):
    n[0] += 1
    return o(self, *p)
SlicedLowLevelWCS.pixel_to_world_values = c
ts = []
for i in range(10):
    n[0] = 0
    t0 = time.perf_counter(); ax.reset_wcs(calls.wcs, slices=calls.slices); ts.append(1e3*(time.perf_counter()-t0))
print(f"reset_wcs: {statistics.median(ts):.2f} ms, {n[0]} pixel_to_world_values calls")
ts = []
for i in range(10):
    n[0] = 0
    t0 = time.perf_counter(); ax.set_xlabel("x"); ts.append(1e3*(time.perf_counter()-t0))
print(f"set_xlabel: {statistics.median(ts):.2f} ms, {n[0]} calls")
n[0] = 0
ax.format_coord(100.0, 100.0)
fig.canvas.draw(); n[0] = 0
t0 = time.perf_counter(); s = ax.format_coord(100.0, 100.0); dt = 1e3*(time.perf_counter()-t0)
print(f"format_coord: {dt:.2f} ms, {n[0]} calls -> {s!r}")
