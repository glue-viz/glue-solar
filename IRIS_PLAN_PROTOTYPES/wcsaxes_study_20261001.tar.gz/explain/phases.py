"""Split draw_wcsaxes into phases (median ms over N draws after warm-up), then
repeat with grid lines on, and count pixel_to_world_values calls in each mode.
Plain matplotlib + WCSAxes, Agg, 400x300 px at dpi 100.
"""
import statistics
import sys
import time
from collections import defaultdict

sys.argv += [] if len(sys.argv) > 1 else ["tan"]
sys.path.insert(0, "/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes/explain")
import calls  # noqa: E402  (loads data, builds fig/ax, prints the call attribution)

from astropy.visualization.wcsaxes.coordinate_helpers import CoordinateHelper
from astropy.visualization.wcsaxes.core import WCSAxes
from astropy.visualization.wcsaxes.frame import BaseFrame

ax, fig, low = calls.ax, calls.fig, calls.low
print("units:", [(c.coord_type, str(c.coord_unit), str(c.get_format_unit())) for c in ax.coords])
acc = defaultdict(float)


def timed(cls, name, key):
    f = getattr(cls, name)

    def w(*a, **k):
        t0 = time.perf_counter()
        try:
            return f(*a, **k)
        finally:
            acc[key] += time.perf_counter() - t0

    setattr(cls, name, w)


timed(WCSAxes, "_update_tick_and_label_positions", "placement")
timed(CoordinateHelper, "_draw_grid", "grid")
timed(CoordinateHelper, "_draw_ticks", "ticks+ticklabels")
timed(CoordinateHelper, "_draw_axislabels", "axislabels")
timed(BaseFrame, "draw", "frame")
timed(BaseFrame, "_update_patch_path", "patch_path")
timed(WCSAxes, "draw_wcsaxes", "draw_wcsaxes")

ncalls = [0]
orig = low.pixel_to_world_values


def count(*p):
    ncalls[0] += 1
    return orig(*p)


low.pixel_to_world_values = count


def run(label, n=15):
    fig.canvas.draw()
    per = defaultdict(list)
    tot = []
    for _ in range(n):
        acc.clear()
        ncalls[0] = 0
        t0 = time.perf_counter()
        fig.canvas.draw()
        tot.append(1e3 * (time.perf_counter() - t0))
        for k, v in acc.items():
            per[k].append(1e3 * v)
    print(f"\n[{label}] canvas.draw median {statistics.median(tot):.1f} ms, "
          f"{ncalls[0]} pixel_to_world_values calls")
    for k in ("draw_wcsaxes", "placement", "grid", "ticks+ticklabels", "axislabels", "frame", "patch_path"):
        if k in per:
            print(f"  {k:18s} {statistics.median(per[k]):6.1f} ms")


run("grid off")
try:
    ax.coords.grid(True, color="white", alpha=0.5)
    run("grid lines on")
except Exception as e:  # noqa: BLE001
    print("\n[grid lines on] FAILED:", type(e).__name__, e)
    for c in ax.coords:
        c.grid(False)
    ax.coords.grid(True, grid_type="contours")
    run("grid contours on")
