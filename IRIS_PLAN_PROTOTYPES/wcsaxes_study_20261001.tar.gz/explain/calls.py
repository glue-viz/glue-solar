"""Attribute every pixel_to_world_values call in one WCSAxes draw to its caller.

Plain matplotlib + WCSAxes (fig.add_subplot(projection=wcs, slices=...)), Agg,
400x300 px panel at dpi 100. Prints per-caller counts, distinct-input counts,
and median timings over repeated draws after warm-up.
"""
import glob
import hashlib
import statistics
import sys
import time
from collections import Counter

sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
import matplotlib

matplotlib.use("agg")
import matplotlib.pyplot as plt
import numpy as np
from astropy.wcs import WCS

import glue_solar
from glue_solar.sources.loaders.iris import image_data, raster_data
from astropy.visualization.wcsaxes import core, coordinate_helpers

print("glue_solar:", glue_solar.__file__)
print("wcsaxes:", core.__file__)

D = "/Users/nabil/DATA/IRIS"
which = sys.argv[1]
N = 15


def tan_map():
    w = WCS(naxis=2)
    w.wcs.ctype = ["HPLN-TAN", "HPLT-TAN"]
    w.wcs.cunit = ["arcsec", "arcsec"]
    w.wcs.cdelt = [0.6, 0.6]
    w.wcs.crpix = [512, 512]
    w.wcs.crval = [0, 0]
    w.wcs.dateobs = "2013-09-02T16:39:35"
    return w, None, (1024, 1024)


def load(which):
    if which == "tan":
        return tan_map()
    if which == "sji":
        (path,) = glob.glob(f"{D}/*4000255147_SJI_1400_t000.fits.gz")
        data = image_data(path)
    elif which == "siiv":
        (f,) = glob.glob(f"{D}/*4000255147_raster/*_r00000.fits")
        data = raster_data([f], windows=["Si IV 1403"])
    elif which == "dec2796":
        (path,) = glob.glob(f"{D}/*4000005156*SJI_2796*")
        data = image_data(path)
    d = data[0] if isinstance(data, (list, tuple)) else data
    print(which, type(d.coords).__name__, d.shape, d.label)
    slices = ["x", "y"] + [0] * (d.ndim - 2)
    return d.coords, slices, d.shape[-2:]


wcs, slices, shape = load(which)
fig = plt.figure(figsize=(4, 3), dpi=100)
ax = fig.add_subplot(projection=wcs, slices=slices)
ax.imshow(np.zeros(shape, dtype=np.float32), origin="lower")
fig.canvas.draw()

low = ax.coords._transform.wcs  # SlicedLowLevelWCS (or the WCS for 2-D)
print("transform wcs:", type(low).__name__, "world_n_dim", low.world_n_dim,
      "coords", [(c.coord_type, c.coord_index) for c in ax.coords])
orig = low.pixel_to_world_values
log = []


def caller():
    f = sys._getframe(2)
    names = []
    while f is not None:
        if "wcsaxes" in f.f_code.co_filename:
            names.append(f.f_code.co_name)
        f = f.f_back
    # innermost wcsaxes function below the transform plus the entry point
    inner = [n for n in names if n not in ("transform", "transform_non_affine", "data")]
    return " <- ".join(inner[:4]) if inner else "?"


def spy(*pixel):
    t0 = time.perf_counter()
    out = orig(*pixel)
    dt = time.perf_counter() - t0
    key = hashlib.sha1(b"".join(np.ascontiguousarray(p).tobytes() for p in pixel)).hexdigest()
    log.append((caller(), key, len(np.atleast_1d(pixel[0])), dt))
    return out


low.pixel_to_world_values = spy

# One draw, attributed
log.clear()
fig.canvas.draw()
c = Counter(x[0] for x in log)
print(f"\nDRAW: {len(log)} calls, {len({x[1] for x in log})} distinct, "
      f"{1e3 * sum(x[3] for x in log):.1f} ms in pixel_to_world_values")
for k, v in c.most_common():
    print(f"  {v:3d}  {k}")

# set_xlabel + set_ylabel (eager placement)
log.clear()
ax.set_xlabel("x")
ax.set_ylabel("y")
print(f"\nset_xlabel+set_ylabel: {len(log)} calls, {len({x[1] for x in log})} distinct")

# Timings: median over N draws after warm-up
def med(fn):
    ts = []
    for _ in range(N):
        t0 = time.perf_counter()
        fn()
        ts.append(1e3 * (time.perf_counter() - t0))
    return statistics.median(ts)

low.pixel_to_world_values = orig
fig.canvas.draw()
r = fig.canvas.get_renderer()
t_draw = med(fig.canvas.draw)
t_wcsaxes = med(lambda: ax.draw_wcsaxes(r))
t_place = med(ax._update_tick_and_label_positions)
t_p2w = med(lambda: low.pixel_to_world_values(np.arange(1000.0), np.arange(1000.0)))
t_p2w2 = med(lambda: low.pixel_to_world_values(np.arange(2.0), np.arange(2.0)))
print(f"\nmedians (n={N}): canvas.draw {t_draw:.1f} ms, draw_wcsaxes {t_wcsaxes:.1f} ms, "
      f"one tick placement {t_place:.1f} ms, p2w(1000 pts) {t_p2w:.3f} ms, p2w(2 pts) {t_p2w2:.3f} ms")
labels = {c.coord_index: (c.get_ticklabel_position(), c.get_ticks_position(), len(c._ticklabels.text)) for c in ax.coords}
print("positions after draw:", labels)
