"""Count WCS and text-extent calls during one WCSAxes draw (Agg, no timing)."""
import collections
import numpy as np
import matplotlib
matplotlib.use("agg")
import matplotlib.pyplot as plt
from matplotlib.text import Text
from astropy.wcs import WCS
from astropy.visualization.wcsaxes.frame import BaseFrame

w = WCS(naxis=2)
w.wcs.ctype = ["HPLN-TAN", "HPLT-TAN"]
w.wcs.cunit = ["arcsec", "arcsec"]
w.wcs.cdelt = [0.33, 0.33]
w.wcs.crpix = [250, 250]
w.wcs.crval = [-300, 200]
w.wcs.pc = [[0.98, -0.17], [0.17, 0.98]]  # IRIS-like roll

calls = collections.Counter()
npts = collections.Counter()
orig_p2w = WCS.pixel_to_world_values
orig_w2p = WCS.world_to_pixel_values
def p2w(self, *a):
    calls["pixel_to_world_values"] += 1; npts["pixel_to_world_values"] += np.size(a[0]); return orig_p2w(self, *a)
def w2p(self, *a):
    calls["world_to_pixel_values"] += 1; npts["world_to_pixel_values"] += np.size(a[0]); return orig_w2p(self, *a)
WCS.pixel_to_world_values = p2w
WCS.world_to_pixel_values = w2p
orig_ext = Text.get_window_extent
def ext(self, *a, **k):
    calls[f"get_window_extent[{type(self).__name__}]"] += 1; return orig_ext(self, *a, **k)
Text.get_window_extent = ext

assert not hasattr(BaseFrame, "update") or BaseFrame.update is collections.OrderedDict.update, "frame.update() is no longer dict.update"

fig = plt.figure(figsize=(6, 6))
ax = fig.add_subplot(projection=w)
ax.imshow(np.random.random((500, 500)))
for grid in (False, True):
    if grid:
        ax.coords.grid(color="w")
    fig.canvas.draw()  # warm
    calls.clear(); npts.clear()
    fig.canvas.draw()
    print(f"grid={grid}:", dict(calls), "points:", dict(npts))
calls.clear(); npts.clear()
ax.get_xlabel()
print("get_xlabel():", dict(calls), "points:", dict(npts))
