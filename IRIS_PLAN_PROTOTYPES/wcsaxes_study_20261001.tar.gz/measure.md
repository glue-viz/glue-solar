## Setup

- **Drawing path:** plain matplotlib with an Agg FigureCanvas, not glue's Qt ImageViewer. The axes come from glue's own `init_mpl(figure, wcs=True)`, so they are a WCSAxesSubplot. They use glue's margins of [1, .25, .5, .25] in, 8 pt tick labels and 10 pt axis labels.
- **WCS:** each case calls `ax.reset_wcs(slices=<glue's wcsaxes_slice>, wcs=data.coords)`, the same call glue's `_set_wcs` makes. `data.coords` is glue-solar's `_GlueWCS`.
- **Image:** `imshow(nearest)` stands in for glue's FRB artist. Use the absolute WCSAxes milliseconds rather than the image times or the share column.
- **Versions:** astropy 8.0.1 (conda-forge build; `astropy.__version__` reports 8.1.0.dev509+gfeec07c4e), matplotlib 3.11.2, gwcs 1.0.3, glue-core 1.27.0. `glue_solar.__file__` = /Users/nabil/Git/glue-solar-main/glue_solar/__init__.py (2fdb847).
- **Run conditions:** DPR1 at dpi 100, offscreen, HOME set to a mktemp directory. Each case ran in its own process; the largest peak RSS was 1.62 GB.
- **Method:** inclusive perf_counter wrappers on each stage, plus a wrapper on `WCSPixel2WorldTransform.transform` and `WCSWorld2PixelTransform.transform`. That wrapper records the point count, the input bytes hash and the call site from the stack.
- **Sampling:** medians of 30 static redraws and 30 pan draws after 3 warm-ups, plus 15 slice steps.
- **Agreement with GLUE_SPEED.md:** the call counts match the in-app numbers exactly (37/53/59), and the SJI WCSAxes time is 22.3 ms here against 24.5 ms in the app.

## Cases

| Case | WCS | Slice | Coordinates |
|---|---|---|---|
| SJI 1400 (4000255147) | gWCS, 400x417x388 | t = 200 | lon, lat (time sliced out) |
| Si IV spectrogram | -TAB FITS WCS, 1600x417x262 | exposure 800 | λ, lat, lon (3 shown) |
| Si IV λ-time | -TAB FITS WCS | slit 208 | λ, lat, lon (3 shown) |
| SJI 2796 deconvolved (4000005156) | gWCS, 32x771x1506 | — | lon, lat |
| Plain 2-D map | HPLN/HPLT-TAN, 1024², 0.6"/px | — | lon, lat |

## Table 1: static redraw where nothing changed (ms, medians)

`_update_ticks` is split per coordinate; "sample" is `frame.sample`. The p2w column is calls per draw with the distinct count in brackets; the ms column is p2w time with the time spent on repeated inputs in brackets. "pan WCSAxes" is a draw after a 1-px xlim change.

| case | panel | draw | WCSAxes (share) | image | placement | coord_range | _update_ticks per coord | sample | TickLabels.draw | AxisLabels.draw | Ticks.draw | frame.draw | patch_path | grid | p2w calls (distinct) | p2w ms (repeated) | pan WCSAxes |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| SJI 1400 | 400x330 | 26.6 | 22.3 (84%) | 4.0 | 15.9 | 0.87 | 7.7 / 7.3 | 6.7 | 2.0 | 2.2 | 0.24 | 0.24 | 1.63 | 0 | 37 (17) | 15.4 (8.0) | 22.6 |
| SJI 1400 | 1258x810 | 34.4 | 23.8 (69%) | 10.1 | 17.0 | 1.10 | 8.1 / 7.8 | 6.9 | 2.1 | 2.3 | 0.26 | 0.33 | 1.67 | 0 | 37 (17) | 16.2 (8.3) | 22.9 |
| Si IV spec | 400x330 | 21.7 | 18.4 (85%) | 3.1 | 7.9 | 0.40 | 2.6 / 2.3 / 2.6 | 2.8 | 6.7 | 2.8 | 0.27 | 0.24 | 0.41 | 0 | 53 (17) | 5.3 (3.4) | 18.4 |
| Si IV spec | 1258x810 | 37.0 | 20.8 (56%) | 15.8 | 9.1 | 0.77 | 2.9 / 2.6 / 2.7 | 3.1 | 7.4 | 3.0 | 0.33 | 0.33 | 0.46 | 0 | 53 (17) | 6.0 (3.8) | 19.9 |
| Si IV λ-time | 400x330 | 37.2 | 29.1 (78%) | 7.8 | 10.0 | 0.47 | 2.7 / 3.5 / 3.3 | 2.8 | **14.8** | 3.0 | 0.59 | 0.25 | 0.43 | 0 | 59 (20) | 6.3 (3.9) | 31.8 |
| Si IV λ-time | 1258x810 | 50.0 | 29.8 (59%) | 19.7 | 10.2 | 0.55 | 2.7 / 3.5 / 3.3 | 2.8 | 15.0 | 3.0 | 0.61 | 0.31 | 0.44 | 0 | 59 (20) | 6.3 (3.9) | 29.4 |
| SJI 2796 | 400x330 | 50.6 | 27.6 (55%) | 22.6 | 18.3 | 1.16 | 8.9 / 8.2 | 7.5 | 4.1 | 2.4 | 0.44 | 0.26 | 1.84 | 0 | 37 (17) | 17.2 (8.7) | 24.9 |
| SJI 2796 | 1258x810 | 56.9 | 25.9 (45%) | 30.5 | 17.3 | 1.10 | 8.2 / 7.7 | 7.0 | 3.9 | 2.3 | 0.43 | 0.30 | 1.70 | 0 | 37 (17) | 16.3 (8.2) | 28.5 |
| TAN map | 400x330 | 20.6 | 7.0 (34%) | 13.2 | 3.2 | 0.44 | 1.6 / 1.2 | 0.7 | 2.3 | 0.9 | 0.24 | 0.21 | 0.08 | 0 | 37 (17) | 1.3 (0.6) | 6.9 |
| TAN map | 1258x810 | 28.0 | 7.2 (26%) | 20.3 | 3.3 | 0.51 | 1.6 / 1.2 | 0.8 | 2.3 | 0.9 | 0.24 | 0.25 | 0.08 | 0 | 37 (17) | 1.3 (0.6) | 7.4 |

- **world_to_pixel_values:** 0 calls per draw in every case and scenario.
- **Automatic placement (`auto_assign`):** 0.04-0.07 ms.
- **Points per call:**
  - 2-coordinate views: 12 calls of 2 points, 24 of 1000 and 1 of 2601.
  - Si IV spectrogram: 16 of 2, 36 of 1000 and 1 of 2601.
  - Si IV λ-time: 16 of 2, 42 of 1000 and 1 of 2601.
- **Where the calls come from (SJI per draw):**
  - `shifted_pixel_to_world`: 16 calls, 6.8 ms
  - `sample` resampled spines: 8 calls, 3.5 ms
  - `sample` update_spines: 8 calls, 2.9 ms
  - `_update_patch_path` update_spines: 4 calls, 1.6 ms
  - coordinate range: 1 call, 0.7 ms
- **Si IV call sites:** 24-30 shifted, 12 + 12 sample, 4 patch and 1 range. λ-time has 2 extra shifted calls per coordinate from the NaN fallback.
- **Repeated inputs within one draw:** 20 of 37 calls (54%) for SJI and TAN, 36 of 53 (68%) for the spectrogram, 39 of 59 (66%) for λ-time.
- **Static redraws are cacheable:** across 30/30 redraws the WCS inputs were byte-identical to the previous draw, and the tick-text and position fingerprints were identical.
- **Pan draws** (limits change, WCS unchanged) cost the same as static redraws.
- **Non-WCS work in `_update_ticks`:** about 0.7-1.1 ms per coordinate (`_update_ticks` minus that coordinate's p2w time).

## Table 2: eager set_xlabel/set_ylabel path, glue slice step (ms)

The set phase is reset_wcs followed by four label sets (x/y to '' and back), as glue's `_set_wcs` does.

| case | panel | set phase | reset_wcs | 4 label sets | p2w calls (distinct) | same step with coord.set_axislabel | draw after step | one set_xlabel alone (calls) |
|---|---|---|---|---|---|---|---|---|
| SJI 1400 | 400x330 | 66.6 | 0.58 | 65.7 | 132 (17) | 0.40 | 27.7 | 16.1 (33) |
| SJI 1400 | 1258x810 | 64.3 | 0.57 | 63.6 | 132 (17) | 0.40 | 34.0 | 15.6 (33) |
| Si IV spec | 400x330 | 32.1 | 0.73 | 31.0 | 196 (17) | 0.61 | 22.1 | 7.9 (49) |
| Si IV λ-time | 400x330 | 38.6 | 0.71 | 37.4 | 220 (20) | 0.56 | 35.0 | 10.2 (55) |
| SJI 2796 | 400x330 | 65.8 | 0.55 | 64.8 | 132 (17) | 0.40 | 46.1 | 16.1 (33) |
| TAN map | 400x330 | — | — | — | — | — | — | 3.0 (33) |

The 1258x810 Si IV and SJI 2796 rows are within 1 ms of the 400x330 rows.

## Table 3: WCS cost per call against point count (ms, medians)

| WCS | layer | 1 pt | 1000 pts | 5000 pts | fixed per call | per 1000 pts |
|---|---|---|---|---|---|---|
| SJI 1400 gWCS | WCSPixel2WorldTransform.transform | 0.361 | 0.427 | 0.684 | 0.360 | 0.065 |
| | SlicedLowLevelWCS.p2w | 0.347 | 0.421 | 0.841 | 0.342 | 0.094 |
| | _GlueWCS.p2w (3-D) | 0.389 | 0.407 | 0.810 | 0.352 | 0.086 |
| | inner gwcs p2w (3-D) | 0.289 | 0.360 | 0.691 | 0.288 | 0.076 |
| | WCSWorld2PixelTransform (minus the forward call) | about 1.8 | | | about 1.8 | about 0.17 |
| SJI 2796 gWCS | transform | 0.352 | 0.422 | 0.861 | 0.338 | 0.097 |
| | inner gwcs | 0.292 | 0.354 | 0.724 | 0.285 | 0.084 |
| Si IV -TAB | transform | 0.067-0.071 | 0.091-0.093 | 0.23-0.26 | 0.061-0.067 | 0.031-0.036 |
| | _GlueWCS | 0.057-0.061 | 0.084-0.102 | 0.18-0.21 | 0.056-0.061 | 0.024-0.030 |
| | inner astropy WCS | 0.019-0.023 | 0.036-0.044 | 0.11-0.12 | 0.019-0.020 | 0.019 |
| TAN map | transform | 0.005 | 0.047 | 0.25-0.28 | 0.003-0.004 | 0.049-0.057 |

What the per-call costs mean:
- **gWCS is per-call bound:** a 1000-point call costs about 1.2 times a 1-point call. glue-solar's wrapper adds about 0.05 ms per call on gWCS and about 0.04 ms on FITS (this is S7).
- **The plain TAN map is per-point bound.**
- **gWCS world-to-pixel is expensive:** about 2.1-2.2 ms per call, roughly 6 times the forward call. It is not on the draw path.
- **Si IV world-to-pixel is very slow and is blocked inside WCSAxes.** On the sliced Si IV WCS, `SlicedLowLevelWCS.world_to_pixel_values` takes 5-15 ms for 1 point and 3.5-8.0 s for 1000 points (that is R8). WCSAxes' own `WCSWorld2PixelTransform.transform` raises `ValueError('Expected 2 world coordinates, got 3')` on both Si IV slices (wcsapi.py:369-370; main 388), so plot_coord and other inverse paths cannot be used there.

## Table 4: WCS time for one static draw's p2w inputs, measured (batch.py)

| case | as WCSAxes calls them | distinct inputs only | one call on all distinct inputs | results identical |
|---|---|---|---|---|
| SJI 1400 | 37 calls, 26,625 pts, 14.2 ms | 17 calls, 14,609 pts, 6.6 ms | 1.22 ms | True |
| SJI 2796 | 37 calls, 14.3 ms | 17 calls, 6.7 ms | 1.25 ms | True |
| Si IV spec | 53 calls, 4.07 ms | 17 calls, 1.34 ms | 0.36 ms | True |
| Si IV λ-time | 59 calls, 5.49 ms | 20 calls, 1.76 ms | 0.54 ms | True |
| TAN map | 37 calls, 1.05 ms | 17 calls, 0.57 ms | 0.50 ms | True |

## Hot spots

Line numbers are for installed astropy 8.0.1; "main" is astropy origin/main 1f930be7c4.

1. **Eager tick placement in set_xlabel/set_ylabel (R1).**
   - Code: core.py:596-598 and 613-615 (main 670/685 and 700/715). get_xlabel/get_ylabel (634-635, 643-644; main 735, 744) and `tick_params(axis='x'/'y')` (core.py:935; main 1046) also place ticks eagerly.
   - Cost: 65.7 ms of SJI work per slice step and 31-37 ms for Si IV. The step makes 132-220 WCS calls but has only 17-20 distinct inputs.
   - Putting the labels on the coordinates directly with coord.set_axislabel takes 0.40-0.61 ms.
2. **The WCS is called once per coordinate per frame sample.**
   - Code: coordinate_helpers.py:995 runs `frame.sample` per coordinate (main 1013). `shifted_pixel_to_world` (1023-1028, called at 1031/1037/1042/1048; main 1041-1066) evaluates every world axis and keeps one column. The `Spine.data` setter re-transforms the samples (frame.py:57-64; main 64).
   - SJI: WCS evaluation is 15.4 of 26.6 ms (58%), and 8.0 ms of it repeats inputs already seen in the draw.
   - The fix needs batching, not only de-duplication: one call takes 1.2 ms against 6.6 ms for the distinct calls.
3. **Every draw places the ticks again, with no cache.**
   - Code: core.py:529 in draw_wcsaxes (main 597).
   - A cache would save, per redraw: SJI 17.5 ms of 26.6 (66%), Si IV spec 8.3 of 21.7 (38%), λ-time 10.4 of 37.2 (28%), TAN 3.3 of 20.6.
   - This is safe for static redraws: the inputs and outputs were identical in 30/30 draws.
4. **Tick-label layout on the λ-time view (new).**
   - TickLabels.draw takes 14.8 ms, 40% of the draw.
   - Latitude wobbles with time in sit-and-stare data, so it gets 48 labels, and all 24 on the left spine are drawn on top of each other. `exclude_overlapping` defaults to False (ticklabels.py:46).
   - The wavelength labels are 12-character strings in metres and cost 4.3 ms.
   - Each label is measured twice with get_window_extent (ticklabels.py:239 and 305; main 257 and 332) before Text.draw. The clutter is visible in measure/lt_400x330.png.
5. **The frame is updated 1 + ncoords times per draw.**
   - `coords.frame.update()` at core.py:503 (main 571) is `OrderedDict.update()` with no arguments. It has done nothing since 2016, because BaseFrame subclasses OrderedDict and never defined `update`.
   - The real spine updates happen in `_update_patch_path` (core.py:589 → frame.py:192) and in `sample()` once per coordinate (frame.py:224-239 → update_spines at 271/373). These are 4 + 4·ncoords calls on the same four 2-point inputs: on SJI, 1.6 ms (patch path) plus 2.9 ms per draw.
6. **WCSAxes cost does not depend on panel size.** The 1000 frame samples and the 51x51 range grid are fixed (conf at `__init__.py`:29-35). SJI WCSAxes goes 22.3 → 23.8 ms from 400x330 to 1258x810; only the image grows.
7. **Smaller costs:** AxisLabels.draw 0.9-3.0 ms, Ticks.draw 0.24-0.6 ms, frame.draw about 0.25 ms, grid 0 (off), auto placement under 0.1 ms.

## Prior art

astropy PR #16366 (ayshih, merged 2024-09-05, for issue #16362, "Eliminate redundant transformations when drawing WCSAxes ticks/gridlines") made the coordinate range compute once per draw. That shows maintainers accept this kind of change; the per-coordinate sample and shift transforms are still there on main.

## Files

All in /private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes/measure/:
- measure.py: the harness.
- out_{sji1400,siiv_spec,siiv_lt,sji2796,tan}.json and log_*.txt: per-case results.
- tables.py and tables.md: the tables above.
- batch.py and batch.log: Table 4.
- probe2.py, probe2.log and probe2b.log: per-coordinate label counts, labels drawn, and Si IV world_to_pixel cost.
- lt_400x330.png, lt_1258x810.png, spec_400x330.png and spec_1258x810.png: renders of the Si IV views.
- main_*.py: astropy origin/main copies read with `git show`.

Key numbers: Static redraw at 400x330 (medians, DPR1):
- SJI 1400: WCSAxes 22.3 of 26.6 ms (84%); tick placement 15.9 ms; 37 p2w calls, 17 distinct; p2w 15.4 ms, of which 8.0 ms on repeated inputs.
- Si IV spectrogram: 18.4 of 21.7 ms; 53 calls, 17 distinct; 5.3 ms.
- Si IV λ-time: 29.1 of 37.2 ms; 59 calls, 20 distinct; TickLabels.draw 14.8 ms (48 latitude labels, 24 drawn overlapping).
- SJI 2796: placement 18.3 ms; 37 calls (17).
- TAN map: WCSAxes 7.0 ms; 37 calls (17), only 1.3 ms.
- world_to_pixel: 0 calls per draw everywhere.
- WCSAxes cost does not depend on panel size: SJI 22.3 → 23.8 ms at 1258x810.

WCS cost per call:
- SJI gWCS: 0.36 ms fixed + 0.065-0.094 ms per 1000 pts (inner gwcs 0.29, _GlueWCS adds 0.05).
- Si IV -TAB: 0.061-0.067 ms fixed (inner astropy WCS 0.019-0.020) + 0.03 ms per 1000 pts.
- TAN: 0.004 ms fixed + 0.05 ms per 1000 pts.
- gWCS world-to-pixel: 2.1-2.2 ms per call.

Batching, measured (identical results):
- SJI: 14.2 ms as called, 6.6 ms distinct only, 1.22 ms in one call.
- Si IV: 4.1-5.5 ms → 1.3-1.8 → 0.36-0.54 ms.
- TAN: 1.05 → 0.57 → 0.50 ms.

Eager label path:
- One set_xlabel: SJI 16.1 ms (33 calls), Si IV spectrogram 7.9 ms (49), λ-time 10.2 ms (55), TAN 3.0 ms.
- glue slice-step set phase: SJI 66.6 ms (132 calls, 17 distinct), Si IV 32-39 ms (196-220 calls).
- Same step with coord.set_axislabel: 0.40-0.61 ms.

Static redraws: inputs and tick output identical in 30/30 draws. A placement cache would save SJI 17.5 of 26.6 ms, Si IV 8.3-10.4 ms, TAN 3.3 ms.

coords.frame.update() at core.py:503 (main 571) has been a no-op OrderedDict.update since 2016.
