"""Markdown tables from out/bench_<case>_<mode>.json."""
import json
import os

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "out")
CASES = ("sji1400", "sji2796", "siiv_spec", "siiv_lt", "tan")
MODES = ("base", "cache", "lazy")
B = {(c, m): json.load(open(f"{OUT}/bench_{c}_{m}.json")) for c in CASES for m in MODES
     if os.path.exists(f"{OUT}/bench_{c}_{m}.json")}


def cell(c, size, kind, key="ms"):
    return " / ".join(f"{B[(c, m)][size][kind][key]:.1f}" if (c, m) in B and kind in B[(c, m)][size] else "-"
                      for m in MODES)


def calls(c, size, kind):
    return " / ".join(f"{B[(c, m)][size][kind]['p2w']:.0f}" if (c, m) in B and kind in B[(c, m)][size] else "-"
                      for m in MODES)


print("Per draw, ms (base / cache / lazy); WCSAxes = draw_wcsaxes + patch path; p2w = pixel_to_world calls\n")
print("| case | panel | static draw | static WCSAxes | contrast draw | pan draw | pan WCSAxes | p2w static | p2w pan |")
print("|---|---|---|---|---|---|---|---|---|")
for c in CASES:
    for size in ("400x330", "1258x810"):
        print(f"| {c} | {size} | {cell(c, size, 'static')} | {cell(c, size, 'static', 'wcsaxes')} | "
              f"{cell(c, size, 'contrast')} | {cell(c, size, 'pan')} | {cell(c, size, 'pan', 'wcsaxes')} | "
              f"{calls(c, size, 'static')} | {calls(c, size, 'pan')} |")

print("\nglue slice step, ms (base / cache / lazy): set phase = reset_wcs + 4 label sets + set_ticklabel\n")
print("| case | panel | set phase | draw after | step total | p2w set | p2w draw | one set_xlabel |")
print("|---|---|---|---|---|---|---|---|")
for c in CASES:
    for size in ("400x330", "1258x810"):
        print(f"| {c} | {size} | {cell(c, size, 'step_set')} | {cell(c, size, 'step_draw')} | "
              f"{cell(c, size, 'step_total')} | {calls(c, size, 'step_set')} | {calls(c, size, 'step_draw')} | "
              f"{cell(c, size, 'set_xlabel_alone')} |")
