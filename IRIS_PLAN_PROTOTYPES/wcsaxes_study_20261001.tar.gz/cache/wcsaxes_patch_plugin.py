"""pytest plugin for astropy's WCSAxes tests with the prototype installed.

WCSAXES_PATCH=base|cache|lazy|stale picks the mode (stale = negative control). pytest-mpl is not installed, so the figure tests
(@figure_test) are un-skipped and run here instead: each returned figure is saved to PNG twice
(the second save reuses the tick cache) and the hashes go to $WCSAXES_HASHES for a base/patched diff.
"""
import hashlib
import io
import json
import os

import pytest

MODE = os.environ.get("WCSAXES_PATCH", "base")
HASHES = {}


def pytest_configure(config):
    import astropy.utils.compat.optional_deps as od

    od.HAS_PYTEST_MPL = True  # read by astropy.tests.figures.helpers at test-module import
    if MODE != "base":
        import wcsaxes_cache

        wcsaxes_cache.install(lazy=MODE == "lazy")
        if MODE == "stale":  # negative control: a key that never changes
            wcsaxes_cache._key = lambda ax, coords: (b"", ())


@pytest.hookimpl(tryfirst=True)
def pytest_pyfunc_call(pyfuncitem):
    mark = pyfuncitem.get_closest_marker("mpl_image_compare")
    if mark is None:
        return None
    import matplotlib.pyplot as plt

    args = {a: pyfuncitem.funcargs[a] for a in pyfuncitem._fixtureinfo.argnames}
    with plt.style.context(mark.kwargs.get("style", "classic"), after_reset=True):
        fig = pyfuncitem.obj(**args)
        out = []
        for _ in range(2):
            buf = io.BytesIO()
            fig.savefig(buf, format="png", **mark.kwargs.get("savefig_kwargs", {}))
            out.append(hashlib.sha256(buf.getvalue()).hexdigest()[:16])
    plt.close(fig)
    HASHES[pyfuncitem.nodeid] = out
    return True


def pytest_sessionfinish(session):
    if path := os.environ.get("WCSAXES_HASHES"):
        with open(path, "w") as f:
            json.dump(HASHES, f, indent=1)
