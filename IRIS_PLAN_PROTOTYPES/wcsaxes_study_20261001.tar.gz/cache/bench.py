"""Timing per draw and per glue slice step, base against the prototype.

usage: python bench.py <case> <mode>     mode in base, cache, lazy
Same setup as ../measure/measure.py (glue init_mpl axes, glue margins, 8 pt tick labels, 10 pt
axis labels, imshow nearest), panels 400x330 and 1258x810, 3 warm-up draws, medians.
WCSAxes ms = draw_wcsaxes + frame._update_patch_path, as in measure/tables.py.
"""
import json
import os
import resource
import statistics as st
import sys
from collections import defaultdict
from time import perf_counter

import numpy as np

import wcsaxes_cache as P
from cases import glue_step, load, setup

CASE, MODE = sys.argv[1], sys.argv[2]
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "out")
if MODE != "base":
    P.install(lazy=MODE == "lazy")

from astropy.visualization.wcsaxes import core, frame as fr, wcsapi  # noqa: E402

T = defaultdict(float)
N = defaultdict(int)


def timed(owner, name, lab):
    f = owner.__dict__[name]

    def w(*a, **k):
        t = perf_counter()
        try:
            return f(*a, **k)
        finally:
            T[lab] += perf_counter() - t

    setattr(owner, name, w)


timed(core.WCSAxes, "draw_wcsaxes", "wcsaxes")
timed(fr.BaseFrame, "_update_patch_path", "wcsaxes")
_p2w = wcsapi.WCSPixel2WorldTransform.transform


def p2w(self, pixel):
    N["p2w"] += 1
    return _p2w(self, pixel)


wcsapi.WCSPixel2WorldTransform.transform = wcsapi.WCSPixel2WorldTransform.transform_non_affine = p2w


def sample(fn):
    T.clear(), N.clear()
    hit0, miss0 = P.STATS["hit"], P.STATS["miss"]
    t = perf_counter()
    fn()
    return dict(ms=(perf_counter() - t) * 1e3, wcsaxes=T["wcsaxes"] * 1e3, p2w=N["p2w"],
                hit=P.STATS["hit"] - hit0, miss=P.STATS["miss"] - miss0)


def med(rows):
    return {k: round(st.median(r[k] for r in rows), 3) for k in rows[0]}


def run(c, w, h):
    fig, ax, art = setup(c, w, h)
    draw = fig.canvas.draw
    for _ in range(3):
        draw()
    res = dict(static=med([sample(draw) for _ in range(30)]))

    def contrast(i):
        art.set_clim(*((0.0, 1.0) if c["data"] is None else np.nanpercentile(np.asarray(c["img_of"](c["steps"][0])), [i % 3, 99 - i % 3])))
        draw()

    res["contrast"] = med([sample(lambda i=i: contrast(i)) for i in range(30)])
    x0, x1 = ax.get_xlim()
    rows = []
    for i in range(33):
        ax.set_xlim(x0 + i % 2, x1 + i % 2)
        rows.append(sample(draw))
    res["pan"] = med(rows[3:])
    ax.set_xlim(x0, x1)
    draw()
    res["set_xlabel_alone"] = med([sample(lambda: ax.set_xlabel(c["labels"][0], size=10)) for _ in range(30)])
    draw()
    if c["ndim"] == 3:
        rows_set, rows_draw = [], []
        for idx in c["steps"][1:16]:
            rows_set.append(sample(lambda: glue_step(ax, c, idx)))
            art.set_data(np.asarray(c["img_of"](idx)))
            rows_draw.append(sample(draw))
        res["step_set"] = med(rows_set)
        res["step_draw"] = med(rows_draw)
        res["step_total"] = med([{k: s[k] + d[k] for k in s} for s, d in zip(rows_set, rows_draw)])
    return res


def main():
    c = load(CASE)
    out = dict(case=CASE, mode=MODE)
    for w, h in ((400, 330), (1258, 810)):
        out[f"{w}x{h}"] = run(c, w, h)
    out["rss_gb"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1e9
    json.dump(out, open(f"{OUT}/bench_{CASE}_{MODE}.json", "w"), indent=1)
    print(CASE, MODE, "rss GB", round(out["rss_gb"], 2))


main()
