"""Shared cases for ident.py and bench.py (same setup as ../measure/measure.py).

Plain matplotlib + Agg. IRIS and 2-D map cases use glue's init_mpl axes (WCSAxesSubplot, glue
margins) and reset_wcs(slices=<glue's wcsaxes_slice>, wcs=data.coords) as glue's _set_wcs does;
the image is imshow(nearest), not glue's FRB artist. spec1d uses fig.add_subplot(projection=wcs).
"""
import glob
import sys

sys.path.insert(0, "/Users/nabil/Git/glue-solar-main")
import matplotlib

matplotlib.use("agg")
import numpy as np
from astropy.wcs import WCS
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure

R = "/Users/nabil/DATA/IRIS"
CASES = ("sji1400", "sji2796", "siiv_spec", "siiv_lt", "tan", "tan_rot", "allsky", "spec1d")


def _tan(roll_deg=0.0):
    w = WCS(naxis=2)
    w.wcs.ctype = ["HPLN-TAN", "HPLT-TAN"]
    w.wcs.cunit = ["arcsec", "arcsec"]
    w.wcs.cdelt = [0.6, 0.6]
    w.wcs.crpix = [512.5, 512.5]
    w.wcs.crval = [-300.0, 200.0]
    w.wcs.dateobs = "2013-09-02T16:39:35"
    if roll_deg:
        r = np.radians(roll_deg)
        w.wcs.pc = [[np.cos(r), -np.sin(r)], [np.sin(r), np.cos(r)]]
    return w


def load(case, nsteps=16):
    """dict(wcs, ndim, x, y, img_of, steps, aspect, labels, data, fits_wcs, overlay, plain)."""
    c = dict(case=case, overlay=None, plain=False, fits_wcs=None)
    if case in ("sji1400", "sji2796"):
        from glue_solar.sources.loaders.iris import image_data
        import glue_solar

        print("glue_solar", glue_solar.__file__, file=sys.stderr)
        pat = "4000255147_SJI_1400_t000.fits.gz" if case == "sji1400" else "4000005156_SJI_2796_t000_deconvolved.fits.gz"
        d = image_data(glob.glob(f"{R}/*{pat}")[0])
        arr = d[d.main_components[0]]
        nt = arr.shape[0]
        c.update(data=d, wcs=d.coords, ndim=3, x=2, y=1, img_of=lambda i: arr[i],
                 steps=list(range(nt // 2, nt // 2 + nsteps)), aspect="equal")
    elif case.startswith("siiv"):
        from glue_solar.sources.loaders.iris import raster_data
        import glue_solar

        print("glue_solar", glue_solar.__file__, file=sys.stderr)
        d = raster_data(sorted(glob.glob(f"{R}/*4000255147_raster/*_r00000.fits")), windows=["Si IV 1403"])[0]
        arr = d[d.main_components[0]]
        if case == "siiv_spec":  # x = wavelength, y = slit, exposure sliced
            n = arr.shape[0]
            c.update(x=2, y=1, img_of=lambda i: arr[i])
        else:  # x = wavelength, y = exposure, slit sliced
            n = arr.shape[1]
            c.update(x=2, y=0, img_of=lambda i: arr[:, i, :])
        c.update(data=d, wcs=d.coords, ndim=3, steps=list(range(n // 2, n // 2 + nsteps)), aspect="auto")
    else:
        img = np.random.default_rng(0).random((1024, 1024), dtype=np.float32)
        if case == "allsky":  # curved all-sky frame with off-sky NaNs, plus an FK5 overlay
            w = WCS(naxis=2)
            w.wcs.ctype = ["GLON-AIT", "GLAT-AIT"]
            w.wcs.crval = [0.0, 0.0]
            w.wcs.cdelt = [-1.0, 1.0]
            w.wcs.crpix = [180.5, 90.5]
            img = np.random.default_rng(0).random((180, 360), dtype=np.float32)
            c["overlay"] = "fk5"
        elif case == "spec1d":
            w = WCS(naxis=1)
            w.wcs.ctype = ["WAVE"]
            w.wcs.cunit = ["Angstrom"]
            w.wcs.crval = [1402.77]
            w.wcs.cdelt = [0.0254]
            w.wcs.crpix = [1.0]
            img = np.sin(np.linspace(0, 20, 500))
            c["plain"] = True
        else:
            w = _tan(30.0 if case == "tan_rot" else 0.0)
        c.update(data=None, wcs=w, fits_wcs=w, ndim=w.naxis, x=1, y=0, img_of=lambda i: img, steps=[None],
                 aspect="equal")
    c["labels"] = (("x world", "y world") if c["data"] is None
                   else (c["data"].world_component_ids[c["x"]].label, c["data"].world_component_ids[c["y"]].label))
    return c


def glue_slices(ndim, x, y, idx):
    """glue ImageViewerState.wcsaxes_slice for numpy axes x, y and index idx on the other axis."""
    if ndim != 3:
        return None
    s = ["x" if i == x else "y" if i == y else idx for i in range(ndim)]
    return s[::-1]


def make_axes(c, w, h):
    fig = Figure(figsize=(w / 100, h / 100), dpi=100)
    FigureCanvasAgg(fig)
    if c["plain"]:
        ax = fig.add_subplot(projection=c["wcs"])
    else:
        from glue.viewers.matplotlib.mpl_axes import init_mpl

        _, ax = init_mpl(figure=fig, wcs=True)
    W, H = w / 100, h / 100
    ax.set_position([1 / W, 0.5 / H, 1 - 1.25 / W, 1 - 0.75 / H])  # glue margins [1, .25, .5, .25] in
    return fig, ax


def set_labels(ax, c, x="", y=""):
    ax.set_xlabel(x, size=10)
    ax.set_ylabel(y, size=10)


def glue_step(ax, c, idx):
    """What glue's _set_wcs does on a slice change: reset_wcs, then the '' / label round trip."""
    ax.reset_wcs(slices=glue_slices(c["ndim"], c["x"], c["y"], idx), wcs=c["wcs"])
    set_labels(ax, c)
    set_labels(ax, c, *c["labels"])
    for coord in ax.coords:
        coord.set_ticklabel(size=8)


def setup(c, w, h):
    """Return (fig, ax, artist)."""
    fig, ax = make_axes(c, w, h)
    if c["plain"]:
        (art,) = ax.plot(c["img_of"](None))
        set_labels(ax, c, *c["labels"])
        return fig, ax, art
    glue_step(ax, c, c["steps"][0])
    if c["overlay"]:
        ov = ax.get_coords_overlay(c["overlay"])
        ov.grid(color="white", linestyle="solid", alpha=0.5)
    im0 = np.asarray(c["img_of"](c["steps"][0]))
    art = ax.imshow(im0, origin="lower", cmap="gray", interpolation="nearest", aspect=c["aspect"])
    ny, nx = im0.shape
    ax.set_xlim(-0.5, nx - 0.5)
    ax.set_ylim(-0.5, ny - 0.5)
    return fig, ax, art
