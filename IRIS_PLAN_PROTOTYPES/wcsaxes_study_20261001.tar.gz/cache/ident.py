"""Run one scripted sequence of view changes and dump a fingerprint after every draw.

usage: python ident.py <case> <mode>    mode in base, cache, lazy (stale = negative control)
Fingerprint: canvas RGBA sha256; per coordinate (every map, overlays included): tick world,
pixel and angle bytes per spine (major and minor), drawn tick-label strings and their xy,
tick/ticklabel/axislabel positions, axis label text/visibility/position/rotation, _fl_spacing.
"""
import os
import hashlib
import json
import pickle
import sys

import numpy as np
from astropy import units as u
from matplotlib import rcParams

import wcsaxes_cache as P
from cases import glue_step, load, setup

CASE, MODE = sys.argv[1], sys.argv[2]
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "out")
if MODE != "base":
    P.install(lazy=MODE == "lazy")
if MODE == "stale":  # negative control: a key that never changes, so every draw after the first is a hit
    P._key = lambda ax, coords: (b"", ())


def sha(b):
    return hashlib.sha256(b).hexdigest()[:16]


def arr(d):
    return {a: np.asarray(v, dtype=float).tobytes().hex() for a, v in sorted(d.items()) if len(v)}


def fp(ax, fig):
    out = dict(img=sha(np.asarray(fig.canvas.buffer_rgba()).tobytes()), coords=[])
    for m, coords in enumerate(ax._all_coords):
        for c in coords:
            t, tl, al = c._ticks, c._ticklabels, c._axislabels
            out["coords"].append(dict(
                map=m, index=c.coord_index,
                ticks=sha(pickle.dumps((arr(t.world), arr(t.pixel), arr(t.angle)))),
                minor=sha(pickle.dumps((arr(t.minor_world), arr(t.minor_pixel), arr(t.minor_angle)))),
                labels={a: list(v) for a, v in sorted(tl.text.items()) if v},
                label_xy=sha(pickle.dumps(getattr(tl, "xy", None))),
                pos=[c.get_ticks_position(), c.get_ticklabel_position(), c.get_axislabel_position()],
                axislabel=[al.get_text(), al.get_visible(), [float(v) for v in al.get_position()], al.get_rotation()],
                spacing=str(getattr(c, "_fl_spacing", None)),
            ))
    return out


def first_angle(ax):
    return next((c for c in ax.coords if c.coord_index is not None and c.coord_type in ("longitude", "latitude")), None)


def main():
    c = load(CASE)
    fig, ax, art = setup(c, 400, 330)
    steps = []
    stats0 = dict(P.STATS)

    def draw(name):
        before = dict(P.STATS)
        fig.canvas.draw()
        f = fp(ax, fig)
        f["step"] = name
        f["cache"] = {k: P.STATS[k] - before[k] for k in P.STATS}
        steps.append(f)

    draw("init")
    draw("static")
    if not c["plain"]:
        art.set_clim(0.2, 0.8)
    draw("contrast")
    x0, x1 = ax.get_xlim()
    y0, y1 = ax.get_ylim()
    ax.set_xlim(x0 + 7.3, x1 + 7.3)
    draw("pan")
    ax.set_xlim(x0 + (x1 - x0) / 4, x1 - (x1 - x0) / 4)
    if not c["plain"]:
        ax.set_ylim(y0 + (y1 - y0) / 4, y1 - (y1 - y0) / 4)
    draw("zoom")
    draw("static2")
    for k, idx in enumerate(c["steps"][1:3]):
        glue_step(ax, c, idx)
        art.set_data(np.asarray(c["img_of"](idx)))
        draw(f"slice{k + 1}")
    fig.set_size_inches(6.0, 4.0)
    draw("resize")
    draw("static3")
    vis = [co for co in ax.coords if co.coord_index is not None]
    vis[0].set_ticks(number=8)
    draw("set_ticks")
    a = first_angle(ax)
    if a is not None:
        a.set_format_unit(u.deg, decimal=True)
        draw("format_unit")
        a.set_major_formatter("d.ddd")
        draw("major_formatter")
    vis[-1].display_minor_ticks(True)
    draw("minor_ticks")
    rcParams["axes.unicode_minus"] = not rcParams["axes.unicode_minus"]
    draw("unicode_minus")
    rcParams["axes.unicode_minus"] = not rcParams["axes.unicode_minus"]
    draw("unicode_minus_back")
    if not c["plain"]:
        ax.coords.grid(True, grid_type="contours" if len(vis) > 2 else None, color="yellow")
        draw("grid")
    if c["fits_wcs"] is not None:  # in-place WCS edit after reset_wcs: only the probe can see it
        w = c["fits_wcs"]
        w.wcs.crval = w.wcs.crval + (5.0 if w.naxis == 1 else np.array([20.0, 0.0 if CASE == "allsky" else -10.0]))
        w.wcs.set()
        draw("wcs_inplace")
    if not c["plain"]:
        vis[0].set_ticklabel_position("t")
        draw("ticklabel_pos")
        ax.set_xlabel("X after move", size=10)
        ax.set_ylabel("Y after move", size=10, color="red")
        draw("relabel")
        ax.set_xlabel("first", color="blue")
        vis[0].set_axislabel("direct wins")
        ax.set_xlabel("second")
        draw("label_order")
    labels = dict(x=ax.get_xlabel(), y=ax.get_ylabel())
    draw("after_get_label")
    steps[-1]["get_label"] = labels
    json.dump(dict(case=CASE, mode=MODE, steps=steps, stats_total={k: P.STATS[k] - stats0[k] for k in P.STATS}),
              open(f"{OUT}/ident_{CASE}_{MODE}.json", "w"), indent=1)
    print(CASE, MODE, "steps", len(steps), "stats", P.STATS)


main()
