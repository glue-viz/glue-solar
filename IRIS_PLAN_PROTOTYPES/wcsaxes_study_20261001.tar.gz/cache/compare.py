"""Compare ident_<case>_<mode>.json fingerprints: base against cache and lazy, step by step."""
import json
import os
import sys

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "out")
cases = sys.argv[1:]
for case in cases:
    runs = {m: json.load(open(f"{OUT}/ident_{case}_{m}.json")) for m in ("base", "cache", "lazy")}
    base = runs["base"]["steps"]
    for m in ("cache", "lazy"):
        steps = runs[m]["steps"]
        bad = []
        for b, s in zip(base, steps, strict=True):
            keys = [k for k in b if k not in ("cache",) and b[k] != s.get(k)]
            if keys:
                bad.append((b["step"], keys))
        hm = " ".join(f"{s['step']}:{'H' * s['cache']['hit']}{'m' * s['cache']['miss']}{'u' * s['cache']['uncacheable']}"
                      for s in steps)
        print(f"{case:10s} {m:5s} steps={len(steps)} identical={not bad} {bad if bad else ''}")
        print(f"    per-draw cache (H=hit m=miss): {hm}")
