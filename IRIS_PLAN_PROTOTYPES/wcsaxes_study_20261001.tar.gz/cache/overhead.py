"""Cost of the cache bookkeeping per placement: _key (probe + pickle), _save, _restore. Medians, ms."""
import statistics as st
import sys
from time import perf_counter

import wcsaxes_cache as P
from cases import load, setup

P.install()
for case in sys.argv[1:]:
    c = load(case)
    fig, ax, art = setup(c, 400, 330)
    fig.canvas.draw()
    coords = ax.coords
    tr = coords._transform

    def t(fn, n=200):
        fn()
        ts = []
        for _ in range(n):
            s = perf_counter()
            fn()
            ts.append(perf_counter() - s)
        return st.median(ts) * 1e3

    import numpy as np
    x0, x1 = ax.get_xlim(); y0, y1 = ax.get_ylim()
    gx, gy = np.meshgrid(np.linspace(x0, x1, 3), np.linspace(y0, y1, 3))
    probe = np.column_stack([gx.ravel(), gy.ravel()])
    states = [P._save(co) for co in coords]
    print(f"{case}: _key {t(lambda: P._key(ax, coords)):.3f}  (probe transform alone {t(lambda: tr.transform(probe)):.3f})"
          f"  _save {t(lambda: [P._save(co) for co in coords]):.3f}"
          f"  _restore {t(lambda: [P._restore(co, s) for co, s in zip(coords, states)]):.3f}"
          f"  hit placement {t(lambda: ax._update_tick_and_label_positions()):.3f}")
