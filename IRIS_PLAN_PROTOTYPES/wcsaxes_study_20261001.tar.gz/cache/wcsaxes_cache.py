"""Prototype for astropy 8.0.1 WCSAxes (runtime monkeypatch, astropy is not edited).

(b) cache: WCSAxes._update_tick_and_label_positions reuses the previous tick placement of a
    CoordinatesMap while everything _update_ticks reads is unchanged (see _key). The eager
    set_xlabel/set_ylabel/get_xlabel/get_ylabel/tick_params calls go through it too.
(a) lazy (optional): WCSAxes.set_xlabel/set_ylabel queue the call; the queue is replayed, in
    order, after the next tick placement (draw, get_xlabel, tick_params(axis='x'/'y')), and
    before any CoordinateHelper call that could change which coordinate the label lands on.

install(lazy=False) / uninstall(); STATS counts cache hits and misses.
"""
import pickle
import warnings
from collections import defaultdict

import numpy as np
from matplotlib import rcParams

from astropy.visualization.wcsaxes import conf, core
from astropy.visualization.wcsaxes.coordinate_helpers import CoordinateHelper
from astropy.visualization.wcsaxes.frame import RectangularFrame1D

STATS = {"hit": 0, "miss": 0, "uncacheable": 0}
_ORIG = {}

# Everything CoordinateHelper._update_ticks writes.
_TICKS = ("world", "pixel", "angle", "disp", "minor_world", "minor_pixel", "minor_angle", "minor_disp")
_LABELS = ("world", "data", "angle", "tick_angle", "text", "disp")

# CoordinateHelper calls after which a queued set_xlabel/set_ylabel could pick another coordinate
# (or would be overridden / read out of order), so the queue is replayed first.
_FLUSH_BEFORE = ("set_axislabel", "get_axislabel", "set_axislabel_position", "set_ticklabel_position",
                 "set_ticks_position", "set_ticks", "set_ticks_visible", "set_ticklabel_visible",
                 "set_visible", "set_format_unit", "set_major_formatter", "set_coord_type")


def _copy(d):
    return defaultdict(list, {k: list(v) for k, v in d.items()})


def _save(c):
    if c.coord_index is None:  # _update_ticks returned without writing anything
        return None
    return (c._fl_spacing, {a: _copy(getattr(c._ticks, a)) for a in _TICKS},
            {a: _copy(getattr(c._ticklabels, a)) for a in _LABELS}, list(c._lblinfo), list(c._lbl_world))


def _restore(c, state):
    if state is None:
        return
    c._fl_spacing, ticks, labels, lblinfo, lblworld = state
    for a, d in ticks.items():
        setattr(c._ticks, a, _copy(d))
    for a, d in labels.items():  # fresh lists: simplify_labels() rewrites text in place at draw time
        setattr(c._ticklabels, a, _copy(d))
    c._ticklabels._stale = True
    c._lblinfo, c._lbl_world = list(lblinfo), list(lblworld)


def _key(ax, coords):
    """What _update_ticks reads for this map, or None if it cannot be captured (then no caching).

    Plain values are compared by their pickle, objects by identity. The transform is identity
    plus its output on a 3x3 grid over the view, which catches in-place WCS edits that move any
    of those 9 points. ponytail: probe, not a WCS hash; an edit invisible at all 9 points is missed.
    """
    x0, x1 = ax.get_xlim()
    y0, y1 = ax.get_ylim()
    frame = coords.frame
    if isinstance(frame, RectangularFrame1D):
        probe = np.linspace(x0, x1, 3)[:, None]
    else:
        gx, gy = np.meshgrid(np.linspace(x0, x1, 3), np.linspace(y0, y1, 3))
        probe = np.column_stack([gx.ravel(), gy.ravel()])
    try:
        with warnings.catch_warnings(), np.errstate(all="ignore"):
            warnings.simplefilter("ignore")
            world = np.asarray(coords._transform.transform(probe), dtype=float)
        plain = pickle.dumps((
            (x0, x1, y0, y1), ax.get_xscale(), ax.get_yscale(),
            ax.transData.get_affine().get_matrix(),  # axes bbox, figure size, dpi, limits
            tuple(frame), conf.frame_boundary_samples, conf.coordinate_range_samples,
            rcParams["text.usetex"], rcParams["axes.unicode_minus"], world,
            [(c.coord_index, c.coord_type, c.coord_unit, c.coord_wrap, c._coord_scale_to_deg,
              vars(c._formatter_locator), c._ticks.get_display_minor_ticks(), c._minor_frequency)
             for c in coords],
        ))
    except Exception:
        return None
    objs = (type(frame), coords._transform, *(o for c in coords for o in (c._formatter_locator, c._custom_formatter)))
    return plain, objs


def _same(a, b):
    return a[0] == b[0] and len(a[1]) == len(b[1]) and all(x is y for x, y in zip(a[1], b[1]))


def _update_tick_and_label_positions(self, keep_coord_range=False):
    pending = self.__dict__.pop("_pending_labels", None)  # popped first: nested flushes are no-ops
    for coords in self._all_coords:
        coords.frame.update()
        key = _key(self, coords)
        cached = coords.__dict__.get("_tick_cache")
        if key is not None and cached is not None and _same(key, cached[0]):
            STATS["hit"] += 1
            coords._coord_range = cached[1]
            for c, state in zip(coords, cached[2]):
                _restore(c, state)
            continue
        coords._coord_range = coords.get_coord_range()
        for c in coords:
            c._update_ticks()
        if key is None:
            STATS["uncacheable"] += 1
            coords.__dict__.pop("_tick_cache", None)
        else:
            STATS["miss"] += 1
            coords._tick_cache = (key, coords._coord_range, [_save(c) for c in coords])

    core.auto_assign_coord_positions(self)

    for axis, label, labelpad, kwargs in pending or ():
        _apply_label(self, axis, label, labelpad, kwargs)

    if not keep_coord_range:
        for coords in self._all_coords:
            del coords._coord_range


# ---------------------------------------------------------------- (a) lazy axis labels
def _apply_label(ax, axis, label, labelpad, kwargs):
    """The body of the original set_xlabel/set_ylabel after its tick placement."""
    spines = ("b", "h") if axis == "x" else ("l", "c")
    for coord in ax.coords:
        if any(s in coord._axislabels.get_visible_axes() for s in spines):
            coord.set_axislabel(label, minpad=labelpad, **kwargs)
            break


def _queue(ax, axis, label, labelpad, kwargs):
    if label is None:
        label = kwargs.pop("label", None)
        if label is None:
            raise TypeError(f"set_{axis}label() missing 1 required positional argument: '{axis}label'")
    ax.__dict__.setdefault("_pending_labels", []).append((axis, label, labelpad, kwargs))


def set_xlabel(self, xlabel=None, labelpad=1, loc=None, **kwargs):
    """Set x-label (applied at the next tick placement)."""
    _queue(self, "x", xlabel, labelpad, kwargs)


def set_ylabel(self, ylabel=None, labelpad=1, loc=None, **kwargs):
    """Set y-label (applied at the next tick placement)."""
    if self.frame_class is RectangularFrame1D:  # matplotlib's own y axis: keep the original path
        return _ORIG["set_ylabel"](self, ylabel, labelpad=labelpad, loc=loc, **kwargs)
    _queue(self, "y", ylabel, labelpad, kwargs)


def _flush(ax):
    if ax.__dict__.get("_pending_labels"):
        ax._update_tick_and_label_positions()


def _flushing(name):
    f = _ORIG[name]

    def w(self, *args, **kwargs):
        _flush(self.parent_axes)
        return f(self, *args, **kwargs)

    w.__name__, w.__doc__ = f.__name__, f.__doc__
    return w


def _flushing_ax(name):
    f = _ORIG[name]

    def w(self, *args, **kwargs):
        _flush(self)
        return f(self, *args, **kwargs)

    w.__name__, w.__doc__ = f.__name__, f.__doc__
    return w


def reset_wcs(self, *args, **kwargs):
    # The queued labels belong to the coordinates being replaced; the eager original applied
    # them to those coordinates, which reset_wcs then discards.
    self.__dict__.pop("_pending_labels", None)
    return _ORIG["reset_wcs"](self, *args, **kwargs)


# ---------------------------------------------------------------- install
_W_NAMES = ("_update_tick_and_label_positions", "set_xlabel", "set_ylabel", "reset_wcs", "get_coords_overlay")


def install(lazy=False):
    uninstall()
    W = core.WCSAxes
    _ORIG.update({n: W.__dict__[n] for n in _W_NAMES})
    _ORIG.update({n: CoordinateHelper.__dict__[n] for n in _FLUSH_BEFORE})
    W._update_tick_and_label_positions = _update_tick_and_label_positions
    if lazy:
        W.set_xlabel, W.set_ylabel, W.reset_wcs = set_xlabel, set_ylabel, reset_wcs
        W.get_coords_overlay = _flushing_ax("get_coords_overlay")  # overlays reserve spines t and r
        for name in _FLUSH_BEFORE:
            setattr(CoordinateHelper, name, _flushing(name))


def uninstall():
    for n, f in _ORIG.items():
        setattr(core.WCSAxes if n in _W_NAMES else CoordinateHelper, n, f)
    _ORIG.clear()
