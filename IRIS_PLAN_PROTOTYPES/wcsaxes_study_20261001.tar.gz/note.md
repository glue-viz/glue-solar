## WCSAxes tick rendering

This section records a read-only study of astropy's WCSAxes. It covers how WCSAxes places and draws ticks, where the time goes on IRIS data, and three ways to make it cheaper. Each way was built as a runtime monkeypatch and then re-measured by a second agent (the "skeptic") with its own harness. Nothing in astropy, glue, glue-qt, glue-solar or irispy was edited, and nothing was posted upstream. It expands R5 and the astropy halves of R1 and R18. The architecture question (can WCSAxes leave matplotlib) is in "Decoupling WCSAxes from matplotlib" above.

- [ ] Re-verified on current versions
- [ ] Proposed upstream (M4, on the user's direction)

**References and versions.**
- File:line references are to `astropy/visualization/wcsaxes/` on astropy main 1f930be7c4, the #20499 merge. The wcsaxes tree is unchanged at c55a2b2067. "8.0.1:" marks a line in the installed release, which every prototype ran against.
- Scripts are in `IRIS_PLAN_PROTOTYPES/wcsaxes_study_20261001.tar.gz`. Paths below are relative to that archive.
- Run them with `env HOME="$(mktemp -d)" QT_QPA_PLATFORM=offscreen MPLBACKEND=agg ~/mamba/envs/iris-plan/bin/python <script>` from the archive root, with a glue-solar checkout first on `sys.path`.
- Versions: astropy 8.0.1, matplotlib 3.11.2, gwcs 1.0.3, numpy 2.5.3, glue-core 1.27.0. glue-solar was main 2fdb847, at /Users/nabil/Git/glue-solar-main.

**Short answer.**
- **The WCS is called too often.** WCSAxes is slow on IRIS because of this, not because of matplotlib.
  - An SJI draw makes 37 `pixel_to_world_values` calls, and only 17 of them have distinct inputs.
  - Each gWCS call costs about 0.36 ms, whatever the number of points.
  - One tick placement is 33 of those calls. Every draw places the ticks again, and glue's `_set_wcs` adds 4 more placements per slice step through `set_xlabel`/`set_ylabel`.
- **Three prototypes.** All three draw identical output on the IRIS cases and pass astropy's WCSAxes tests. Every runnable figure PNG stayed byte-identical (59 or 60 of 60; the 60th needs LaTeX).
  - A per-placement memo: SJI draw -25%. Confirmed, and also run on astropy main.
  - Batching the frame calls: SJI draw -50%. Not confirmed, because it changes behaviour for WCSes that raise or return NaN. Two of the three changes have a verified fix.
  - A placement cache across draws: SJI redraw with nothing changed -60%. Confirmed, with known limits on how it detects a changed WCS. It does nothing for pans, zooms or new slices.
- **Recommendation.** Propose the memo PR first, then batching. Decide on the cache only after both are in. glue's R1 fix is independent of all three and should go first in glue-core: it removes the 4 eager placements per slice step whatever astropy does.
- **"Tricky" applies mainly to the cache.** The memo touches only core.py and leaves the tick algorithm alone. Batching changes only how `_update_ticks` calls the WCS, not its arithmetic. Both kept every figure byte-identical. The cache is the hard one, because it has to know when a WCS has changed, which is the design astrofrog argued against on #16362.

### How tick placement works

This is what someone changing placement needs to know. The full walkthrough, with more detail and measurements, is `walkthrough.md` in the archive.

**Objects.**
- **WCSAxes** (core.py:51) is an ordinary Axes.
  - It hides matplotlib's own spines and x/y axes (195-202).
  - `transData` stays the affine data-to-display transform, and data coordinates are image pixels. World coordinates never enter `transData`.
  - It draws its decorations from `_WCSAxesArtist` (32-48), a dummy artist that calls `draw_wcsaxes` inside matplotlib's z-order pass.
- **CoordinatesMap.** `ax.coords` is one (coordinates_map.py:11), and `ax._all_coords` holds it plus any overlays (core.py:528, 794).
  - Each map owns a frame (coordinates_map.py:57) and a transform.
  - It holds one `CoordinateHelper` per world axis of the **unsliced** WCS (65-102).
  - A world axis the slice drops gets `coord_index=None` (84-87). It never gets ticks, a grid or a mouse-over value.
- **CoordinateHelper** (coordinate_helpers.py:49) owns:
  - a formatter_locator (411-426);
  - one `Ticks` Line2D (117);
  - one `TickLabels` Text (120-124);
  - one `AxisLabels` Text (129-133).

  The Text artists are moved and drawn once per label.
- **Frames** are OrderedDicts of `Spine`s.
  - Shapes: rectangular `brtl`, with auto order `bltr` (frame.py:378-395); 1-D `bt` with `SpineXAligned` (326-375); elliptical `chv` (398-462).
  - Setting `Spine.data` (pixel coordinates) transforms it to world at once and stores the inward normal in display space (57-65, 104-109).
  - `add_tickable_gridline` (coordinate_helpers.py:1341-1455) adds spines whose `data_func` `update_spines` re-runs (frame.py:279-282).

**Transforms and slices.**
- `reset_wcs` (core.py:455-554) builds the coordinate metadata (type, wrap, unit, format unit, names) from the WCS physical types through `transform_coord_meta_from_wcs` (wcsapi.py:135-293).
  - Helioprojective longitude wraps at 180° and formats in arcsec.
  - It makes no WCS calls: 0.40 ms on SJI.
  - It rebuilds the CoordinatesMap, which loses every `set_ticks`, `set_major_formatter`, `set_ticklabel` and `grid` customization and drops overlays. It keeps the frame's Path object, so clipped artists stay valid (496-526).
- `apply_slices` (wcsapi.py:296-329) returns a `SlicedLowLevelWCS`. The slice index is frozen into the transform, so every slice step needs a new `reset_wcs`.
- **`WCSPixel2WorldTransform`** (wcsapi.py:419-491) is a non-affine matplotlib Transform.
  - `.transform(N×2)` (460-485) is one `pixel_to_world_values` call that returns every kept world axis. Callers keep one column, `[:, coord_index]`.
  - The inverse (340-416) accepts exactly two world inputs (387-388).
- Overlays compose that transform with a `CoordinateTransform`, which runs `SkyCoord.transform_to` on every call (transforms.py:118-154).
- Nothing on this path is memoized.

**One draw.**
1. `WCSAxes.draw` (core.py:628-667) runs `apply_aspect`.
2. It then runs `frame._update_patch_path()` (663), which calls `update_spines`. That is 4 two-point WCS calls whose world values nothing reads.
3. `Axes.draw` reaches `draw_wcsaxes` (585-626). It returns at once when the axes is off (586; that is S14). Otherwise it does three things.
   1. **Places the ticks:** `_update_tick_and_label_positions(keep_coord_range=True)` (556-583). For each map:
      - `coords.frame.update()` (571), which is `OrderedDict.update()` with no arguments, a no-op since 2016;
      - `_coord_range` from `find_coordinate_range` (coordinate_range.py:23-147), one call on a 51×51 grid over the view;
      - `_update_ticks()` for every coordinate;
      - then `auto_assign_coord_positions` once.
   2. **Draws the grid:** `_draw_grid` for every coordinate (only after `grid()`), then `del coords._coord_range` "to protect from accidental use of a stale range".
   3. **Draws the decorations:** `_draw_ticks` per coordinate, which collects tick-label bboxes, then `_draw_axislabels`, then the frame.
4. `_drawn = True` turns on `format_coord`.

**`_update_ticks`** (coordinate_helpers.py:984-1139; 8.0.1: 966). A `# TODO: this method should be optimized for speed` comment sits at 988.
1. **Skip.** It returns when `coord_index is None`.
2. **Values.** It calls `self.locator(*range)`, which returns tick values and a spacing. The spacing is stored in `_fl_spacing`, and `format_coord` takes its precision from it.
3. **Frame sampling.** It calls `frame.sample(1000)` (1013). That runs `update_spines()` (4 two-point calls), then builds new spines resampled to 1000 points, one WCS call per spine.
4. **Tick angles, per spine.**
   - Spines that are empty or all-NaN for this coordinate are skipped (1026-1037).
   - The spine is moved to display space with `transData`, shifted +2 px in x, mapped back with `transData.inverted()` (1024) and evaluated again. The same is done with ±2 px in y, the sign taken from `frame.origin` (`shifted_pixel_to_world`, 1041-1067). Where a shift lands on NaN, the other direction is tried.
   - That is 2 calls per spine per coordinate, or 4 with the NaN fallback. The result depends on axes size and DPI.
   - The display-space gradient rotated by 90° gives the gridline direction (1070-1082). It is flipped when it points away from the inward normal (1084-1091).
5. **Crossings.** `_compute_ticks` (1141-1241) finds every segment where the coordinate crosses a tick value. Longitudes also test t+360. Position and angle are interpolated linearly. One value can give several ticks on one spine, and ticks are found on **every** spine, visible or not.
6. **Labels.** All of a coordinate's labels are formatted in one call (1136-1139).

The second coordinate repeats the first's sample and shift inputs exactly. With n visible coordinates, one draw therefore makes **5 + 16n** calls: 1 range call, then for each coordinate 4 corner, 4 sampled and 8 shifted calls, then 4 patch-path calls. That is 37 calls for SJI and TAN (n=2) and 53 for the Si IV spectrogram (n=3), each with 17 distinct inputs.

**Automatic spine assignment** (_auto.py:8-139).
- Every visible coordinate starts with '#' (automatic) positions. With exactly two visible coordinates, both also get ticks on all four spines (core.py:537-551, wcsapi.py:254-267).
- The remaining '#' coordinates try every permutation of the free spines in `bltr` order. Each option is scored by the number of ticks it would show, which is why ticks are needed on every spine first.
- The winner is written back as `[spine, '#']`.
- On main, a coordinate with both ticks and tick labels hidden is left out (57-65, #20499). It still runs `_update_ticks`.

**Drawing.**
- **Ticks:** one `draw_markers` per tick on each visible spine (ticks.py:174-249).
- **Tick labels:**
  - `_set_xy_alignments` (ticklabels.py:222-309) runs on every draw. It simplifies sexagesimal labels, measures each label and anchors it.
  - The draw (349-376) measures each label again (257 and 332). With `exclude_overlapping`, which defaults to False (51), it skips labels that overlap earlier ones.
- **Axis labels** (axislabels.py:61-151) sit outside the union of **all** coordinates' tick-label bboxes. They are shown only on spines where that coordinate drew tick labels.
- **`get_tightbbox`** (core.py:913-926) runs a whole `draw_wcsaxes`.
- **Grid:**
  - 'lines' (coordinate_helpers.py:1281-1339) makes one inverse call and one round-trip call, and clips each path to `frame.patch`. That patch runs `update_spines` again (931-936).
  - 'contours' (1467-1525) makes a 200×200 forward call and runs `ax.contour` on every draw.

**Eager `set_xlabel`/`set_ylabel`** (core.py:670-732; eager calls at 685 and 715; 8.0.1: 598, 615).
- **What.** Each call runs a full `_update_tick_and_label_positions()`, then gives the text to the first coordinate whose axis-label positions contain 'b' (or 'l').
- **Also eager:** `get_xlabel`, `get_ylabel` (735, 744) and `tick_params(axis='x'|'y')` (1046).
- **Why.** With '#' positions, the coordinate on b is known only after auto-assignment, and that needs every spine's tick count. Before the first draw no coordinate has 'b', so without the placement the label would be lost.
- **Origin.** The eager call came with automatic placement (#17243, astropy 7.0), in commit 46a541d624, "Fixed non-image tests".
- **Cost.** The ticks it computes are thrown away and the next draw recomputes them.

**What survives between draws:** nothing on the placement path.
- `_coord_range` is deleted on purpose.
- `sample` builds new spines every time.
- The `TickLabels._stale` flag only saves work within one draw.
- The transforms have no memo.

**Invariants a change must keep.**
1. Ticks are computed on every spine, because auto-assignment scores spines by tick count. The default 2-D view has ticks on all four spines and labels on b and l.
2. Rotated, curved and wrapping grids keep working: several crossings per spine, the t+360 test, `coord_wrap`, and `_coord_scale_to_deg` for arcsec longitudes (IRIS).
3. NaN handling stays: all-NaN spines are skipped, a NaN shift goes the other way, and a NaN segment gives no tick (off-limb and off-footprint views).
4. Hidden coordinates stay hidden. A coordinate with `coord_index None` gets no ticks, grid, range entry or mouse-over value. A hidden-but-present coordinate still sets `_fl_spacing`.
5. Overlays keep their own frame and transform, at fixed 't' and 'r' (core.py:802-806).
6. 1-D frames, elliptical frames and `data_func` spines keep working.
7. Label simplification and overlap exclusion depend on the order along the spine and on the coordinate draw order. Axis labels need every coordinate's tick-label bboxes.
8. Grid lines and ticks share the locator values, and `format_coord` needs `_fl_spacing`.
9. The frame's Path object keeps its identity across `reset_wcs`.
10. `set_xlabel` attaches to the coordinate that ends up on b or l, even before the first draw.

### Where the time goes on IRIS WCSes

**Setup** (`measure/measure.py`).
- **Axes.** Plain matplotlib on an Agg canvas, with the axes from glue's own `init_mpl(wcs=True)`: glue's margins, 8 pt tick labels and 10 pt axis labels.
- **WCS.** `ax.reset_wcs(slices=<glue's wcsaxes_slice>, wcs=data.coords)`, the call glue's `_set_wcs` makes.
- **Image.** `imshow(nearest)` stands in for glue's FRB artist. Use the WCSAxes milliseconds, not the image or total draw times.
- **Sampling.** DPR1, medians of 30 redraws after 3 warm-ups.
- **Agreement with the app.** The call counts match the in-app survey exactly (37/53/59). SJI WCSAxes takes 22.3 ms here against 24.5 ms in the app.

**Cases.**

| Case | WCS | Slice | Shown coordinates |
|---|---|---|---|
| SJI 1400 (4000255147) | gWCS, 400x417x388 | t = 200 | lon, lat |
| SJI 2796 deconvolved (4000005156) | gWCS, 32x771x1506 | | lon, lat |
| Si IV spectrogram (4000255147) | -TAB FITS, 1600x417x262 | exposure 800 | λ, lat, lon |
| Si IV λ-time | -TAB FITS | slit 208 | λ, lat, lon |
| Plain 2-D map | HPLN/HPLT-TAN, 1024², 0.6"/px | | lon, lat |

**Static redraw at 400x330 (ms, medians).** "p2w ms" is the time spent in `pixel_to_world_values`, with the share spent on repeated inputs in brackets.

| Case | Draw | WCSAxes (share) | Placement | p2w calls (distinct) | p2w ms (repeats) | TickLabels.draw | AxisLabels.draw | Patch path |
|---|---|---|---|---|---|---|---|---|
| SJI 1400 | 26.6 | 22.3 (84%) | 15.9 | 37 (17) | 15.4 (8.0) | 2.0 | 2.2 | 1.63 |
| SJI 2796 | 50.6 | 27.6 (55%) | 18.3 | 37 (17) | 17.2 (8.7) | 4.1 | 2.4 | 1.84 |
| Si IV spectrogram | 21.7 | 18.4 (85%) | 7.9 | 53 (17) | 5.3 (3.4) | 6.7 | 2.8 | 0.41 |
| Si IV λ-time | 37.2 | 29.1 (78%) | 10.0 | 59 (20) | 6.3 (3.9) | **14.8** | 3.0 | 0.43 |
| TAN map | 20.6 | 7.0 (34%) | 3.2 | 37 (17) | 1.3 (0.6) | 2.3 | 0.9 | 0.08 |

- **Panel size.** WCSAxes does not depend on panel size: at 1258x810 SJI takes 23.8 ms and the Si IV spectrogram 20.8 ms. Only the image grows. The 1000 frame samples and the 51×51 range grid are fixed by `conf` (`__init__.py`:29-35).
- **Pans** (limits change, WCS unchanged) cost the same as static redraws.
- **World-to-pixel:** 0 calls per draw in every case.
- **Automatic assignment:** under 0.1 ms.
- **Non-WCS work in `_update_ticks`:** about 0.7-1.1 ms per coordinate.
- **Static redraws are cacheable.** Over 30 redraws the WCS inputs were byte-identical draw to draw, and so was the tick output.

**Where the 37 SJI calls come from.**

| Call site | Calls | ms |
|---|---|---|
| `shifted_pixel_to_world` | 16 | 6.8 |
| `frame.sample`, resampled spines | 8 | 3.5 |
| `frame.sample`, `update_spines` | 8 | 2.9 |
| `_update_patch_path`, `update_spines` | 4 | 1.6 |
| Coordinate range | 1 | 0.7 |

On the Si IV views the split is 24-30 shifted, 12 + 12 sample, 4 patch and 1 range. λ-time has 2 extra shifted calls per coordinate from the NaN fallback.

**Cost per call (ms, medians; `measure/` Table 3).**

| WCS | 1 pt | 1000 pts | 5000 pts | Fixed per call | Per 1000 pts |
|---|---|---|---|---|---|
| SJI 1400 gWCS, WCSAxes transform | 0.361 | 0.427 | 0.684 | 0.360 | 0.065 |
| SJI 1400, inner gwcs | 0.289 | 0.360 | 0.691 | 0.288 | 0.076 |
| Si IV -TAB, WCSAxes transform | 0.067-0.071 | 0.091-0.093 | 0.23-0.26 | 0.061-0.067 | 0.031-0.036 |
| Si IV, inner astropy WCS | 0.019-0.023 | 0.036-0.044 | 0.11-0.12 | 0.019-0.020 | 0.019 |
| TAN map | 0.005 | 0.047 | 0.25-0.28 | 0.003-0.004 | 0.049-0.057 |

- **gWCS is bound by the number of calls:** a 1000-point call costs 1.2 times a 1-point call. The plain TAN map is bound by points.
- **glue-solar's wrapper.** `_GlueWCS` adds about 0.05 ms per call (S7).
- **World-to-pixel.** gWCS world-to-pixel costs 2.1-2.2 ms per call, but it is not on the draw path.

**WCS time for one static draw's inputs (`measure/batch.py`; results identical in every row).** This table shows why batching beats de-duplicating.

| Case | As WCSAxes calls it | Distinct inputs only | One call on all distinct inputs |
|---|---|---|---|
| SJI 1400 | 37 calls, 26,625 pts, 14.2 ms | 17 calls, 14,609 pts, 6.6 ms | 1.22 ms |
| SJI 2796 | 14.3 ms | 6.7 ms | 1.25 ms |
| Si IV spectrogram | 53 calls, 4.07 ms | 1.34 ms | 0.36 ms |
| Si IV λ-time | 59 calls, 5.49 ms | 1.76 ms | 0.54 ms |
| TAN map | 1.05 ms | 0.57 ms | 0.50 ms |

**Eager labels on a glue slice step (ms).** The set phase is `reset_wcs` followed by glue's 4 label sets (x and y to '' and back).

| Case | Set phase | reset_wcs | WCS calls (distinct) | Same step with `coord.set_axislabel` | One `set_xlabel` (calls) |
|---|---|---|---|---|---|
| SJI 1400 | 66.6 | 0.58 | 132 (17) | 0.40 | 16.1 (33) |
| SJI 2796 | 65.8 | 0.55 | 132 (17) | 0.40 | 16.1 (33) |
| Si IV spectrogram | 32.1 | 0.73 | 196 (17) | 0.61 | 7.9 (49) |
| Si IV λ-time | 38.6 | 0.71 | 220 (20) | 0.56 | 10.2 (55) |
| TAN map | | | | | 3.0 (33) |

**Hot spots, largest first.**
1. **Eager placement in `set_xlabel`/`set_ylabel`** (R1): 66 ms of SJI work per slice step, with only 17 distinct inputs among 132 calls. These placements also run with the axes off (S14).
2. **One WCS call per coordinate per frame sample and per shift** (R5): on SJI, WCS evaluation is 15.4 of 26.6 ms, and 8.0 ms of that repeats inputs already seen in the same draw.
3. **No reuse across draws** (R5, R18): a redraw with nothing changed pays the full placement, 15.9 ms on SJI.
4. **Tick labels on the λ-time view.**
   - TickLabels.draw takes 14.8 ms, 40% of the draw.
   - Latitude wobbles with time in sit-and-stare data, so it gets 48 labels. All 24 on the left spine are drawn on top of each other (see `measure/lt_400x330.png`).
   - The wavelength labels are 12-character strings in metres and cost 4.3 ms.
   - This is a display problem, not an algorithm one; see the open questions.
5. **The frame is updated 1 + n times per draw**: in `_update_patch_path` and once per coordinate in `sample()`. Those are 4 + 4n calls on the same four 2-point inputs, 1.6 + 2.9 ms on SJI.

### Prototypes

All three are runtime monkeypatches against installed astropy 8.0.1. Each skeptic used its own harness. Their baselines differ by up to 1 ms, so compare the gains within a row more than across rows.

| | Per-placement memo | Batched calls | Placement cache |
|---|---|---|---|
| Scope | One placement | One placement | Across draws |
| Files touched upstream | core.py | core.py, frame.py, coordinate_helpers.py | core.py |
| WCS calls per SJI draw | 37 -> 21 | 37 -> 3 | 37 -> 5 on a hit, 37 + 1 on a miss |
| SJI static draw (skeptic, ms) | 25.7 -> 19.3 (-25%) | 26.3 -> 13.2 (-50%) | 26.6 -> 10.7 (-60%) |
| Pans, zooms, new slices | same gain as static | gain on every draw (not timed separately) | no gain, +0.4-0.5 ms per miss |
| SJI glue slice step (skeptic, ms) | 90.2 -> 58.6 (-35%) | 91.0 -> 28.9 (-68%) | 92.4 -> 30.7 (-67%) |
| Si IV spectrogram static draw | 21.7 -> 19.0 | 22.1 -> 16.6 | 21.5 -> 12.9 |
| TAN map static draw | 22.8 -> 22.6 (noise) | gain about 0.7 ms, interleaved only | 22.0 -> 20.0 |
| Output | identical | identical on IRIS; 3 differences on failing WCSes | identical, except the known probe and formatter limits |
| Skeptic verdict | confirmed; also run on main | not confirmed | confirmed |

#### Prototype 1: per-placement memo of `pixel_to_world_values`

**Files.** `minimal/memo_patch.py` (59 lines; importing it installs it). The upstream form is `minimal/upstream_core.diff`, against main core.py, +55/-16.

**What it changes.** While a placement runs, `coords._transform.transform` returns a copy of an earlier result when it sees byte-identical input.
- **Lifetime.** It is the same lifetime `_coord_range` already has: from `_update_tick_and_label_positions` to the `del` after the grid in `draw_wcsaxes` (main core.py:556-604).
- **Mechanism.**
  - A context manager puts an instance attribute `transform` on the transform object, which shadows the method. It deletes the attribute in a `finally`.
  - The key is `(shape, dtype.str, tobytes())`, and every caller gets its own copy (`copy(order="K")`).
  - Re-entry is a no-op, so the draw and the eager label paths nest safely.
- **What it covers.** Every caller goes through `self.transform.transform`: the `Spine.data` setter, `shifted_pixel_to_world`, `find_coordinate_range` and the grid. So it covers the overlay composite too.
- **What it leaves.** The 4 `_update_patch_path` calls in `WCSAxes.draw` sit outside the scope. That is why a draw goes to 21 calls, not 17.

**Measured gain.** Prototype numbers, separate processes:
- **Static draw:** SJI 1400 27.4 -> 21.2 ms (-23%), SJI 2796 48.7 -> 41.9, Si IV spectrogram 22.3 -> 19.2, λ-time 39.5 -> 35.5, TAN 23.4 -> 22.9.
- **Glue slice step:** SJI 94.1 -> 60.5 ms (-36%), with 132 -> 68 calls in the set phase. Si IV spectrogram 55.3 -> 39.5, λ-time 77.5 -> 59.0.
- **One `set_xlabel`:** SJI 16.7 -> 9.7 ms (33 -> 17 calls), Si IV 7.9 -> 4.8 ms (49 -> 17).
- **astropy's own benchmark headers** (in-process A/B, `minimal/msx_ab.py`):
  - basic plot 7.62 -> 7.49 ms and with grid 9.85 -> 9.85, both neutral;
  - **grid with fk5 overlay 37.4 -> 27.5 ms (-26%)**, the only existing asv benchmark that moves.
- **Bookkeeping cost:** 0.4-11 µs per call, about 0.13 ms per placement. That is why cheap 2-D FITS WCSes come out neutral.

**Skeptic** (`skeptic_minimal/`). Confirmed.
- **Timing.** In-process ABBA toggling: SJI 25.65 -> 19.34 ms (-25%), SJI 2796 -13%, Si IV spectrogram -13%, λ-time -8%, TAN -1%. The slice step went SJI 90.2 -> 58.6 ms.
- **Through glue's Qt ImageViewer** (offscreen, `skeptic_minimal/glue_viewer.py`): SJI static draw 24.71 -> 18.29 ms, slice step 88.41 -> 56.70 ms.

**Identity.**
- **Prototype check.** It compared 7 cases bit for bit after every step: the IRIS cases, TAN, a rotated RA/Dec near the pole with a galactic overlay and grid, and an all-sky Aitoff ellipse.
  - Fields compared: the RGBA hash; every tick, tick-label and axis-label field; `_fl_spacing`; `format_coord`; a tight savefig.
  - Steps: pan, zoom in and out, off-footprint, slice change, resize.
  - Every step was identical.
- **Skeptic check** (`skeptic_minimal/edge.py`). 27 scenarios × 12 steps, with 0 of 324 steps different. It covered:
  - custom spacing and values, minor ticks, hidden coordinates, all-auto positions;
  - three kinds of overlay, colorbars, tiny and zero-size axes;
  - NaN-outside and raising WCSes, custom transforms;
  - 1-D, swapped and sliced 3-D cubes;
  - `plot_coord`, and the IRIS data.

**astropy tests.**
- Plain run: 237 passed, 63 skipped, 1 xfailed, the same as stock.
- With the figure tests forced to run through the prototype's plugin (pytest-mpl is not installed): 296 passed, and 1 failed in both modes (`test_latex_labels`, no LaTeX installed).
- 59 of 59 PNGs were byte-identical. These are macOS hashes, not astropy's Linux baselines.

**On astropy main.** The skeptic loaded main's wcsaxes tree from `git archive` over the installed astropy (`skeptic_minimal/shadow_plugin.py`). Nothing in ~/Git/astropy was touched.
- `upstream_core.diff` applies cleanly.
- Calls on a TAN draw: 37 -> 21. Calls in `set_xlabel`: 33 -> 17.
- main's tests: 319 passed and 1 failed (LaTeX), the same with and without the diff.
- Figures: 59 of 59 identical.
- Edge harness: 0 of 324 steps differ. The same harness finds 34 steps where 8.0.1 and main differ, so it does catch real changes.

**Risks and notes.**
- **Review style.** Shadowing a method with an instance attribute is unusual. The alternatives:
  - an explicit `_cache` checked inside `WCSPixel2WorldTransform.transform` and `CoordinateTransform.transform`. This loses most of the overlay gain, because the composite calls `transform_non_affine`;
  - a proxy transform swapped into `coords._transform`, `frame.transform` and each helper. That is more invasive.
- **Purity.** It assumes the transform is a pure function of its input during one placement. Code that counts WCS calls sees fewer.
- **Warnings.** A warning the WCS raises is reported fewer times under the `'always'` filter: 37 -> 21 per draw. Under the default filter it is 2 in both.
- **Sketch mismatch.** The diff's wrapper calls `uncached(np.asarray(values))`, which would strip a mask or a Quantity. The monkeypatch passes `values` unchanged (memo_patch.py:35). No WCSAxes caller passes either today, but change the diff to match before proposing it.
- **Remaining SJI WCS time.** It keeps the 17 distinct calls separate: SJI WCS time 15.4 -> 9.4 ms, against about 1.2 ms batched.

#### Prototype 2: batch the WCS calls of one placement and share them between coordinates

**Files.** `batch/wcsaxes_batch.py` (265 lines, `install()`/`uninstall()`). Pytest plugin `batch/wcsaxes_batch_plugin.py`. Skeptic's fixes in `skeptic_batch/batch_fix.py` (40 lines, layered on the module).

**What it changes.**
1. **Lazy `Spine.world`** (wcsaxes_batch.py:40-52, replacing the setter at main frame.py:57-65). World values are computed on first read. Nothing in wcsaxes reads the world values of the frame's own spines, so `update_spines` no longer calls the WCS. That removes the 4 patch-path calls, the 4 per coordinate in `sample`, and the 4 per coordinate in the grid's `frame.patch`.
2. **One call for all resampled spines.** `BaseFrame.sample` (wcsaxes_batch.py:55-78; main frame.py:232) transforms them together. Spine classes that set world eagerly (`SpineXAligned`, 1-D) keep their own behaviour.
3. **One cache per placement.** `_update_tick_and_label_positions` is wrapped (81-88) to give each CoordinatesMap a `_tick_cache` for one call only, which is astrofrog's per-draw pattern from #16362.
   - The copied `_update_ticks` (120-233) takes the sampled frame from the cache.
   - Its `shifted_pixel_to_world` reads `_shifted_world` (91-117). That computes both ±2 px shifts for every spine in one call, and the NaN-fallback direction in one more call, only when a coordinate needs it.
   - The cache key includes `id(transform)`.
- **Result.** A draw makes 3 calls: range, sample and shifts. It makes 4 when the NaN fallback is needed. Folding the 51×51 range grid into the same call would make it 2 and save about 0.7 ms more on gWCS; this was not done.
- **Guard.** The three copied functions are checked by source hash at import. They are byte-identical on 8.0.1 and main, so the change carries over directly.

**Measured gain** (prototype, interleaved in one process; skeptic's separate-process numbers in brackets):

| Case | Static draw 400x330 | Static draw 1258x810 | Slice step, set phase | Slice step + draw | WCS calls per draw |
|---|---|---|---|---|---|
| SJI 1400 | 28.1 -> 13.9 [26.3 -> 13.2] | 35.2 -> 20.8 [34.9 -> 21.5] | 65.5 -> 17.1 [65.4 -> 16.8] | 93.4 -> 31.0 [91.0 -> 28.9] | 37 -> 3 |
| SJI 2796 | 48.9 -> 34.4 [44.0 -> 29.5] | 58.6 -> 44.1 | 71.3 -> 20.9 | 119.7 -> 55.3 [111.5 -> 48.2] | 37 -> 3 |
| Si IV spectrogram | 23.0 -> 17.3 [22.1 -> 16.6] | 35.4 -> 30.5 | 31.6 -> 13.0 | 54.4 -> 30.9 [53.0 -> 29.2] | 53 -> 3 |
| Si IV λ-time | 39.4 -> 33.2 [37.2 -> 31.5] | 51.9 -> 46.2 | 40.5 -> 19.8 | 76.9 -> 50.4 [73.5 -> 47.6] | 59 -> 4 |
| TAN map | 21.8 -> 20.8 [lost in noise] | 29.8 -> 28.7 | | | 37 -> 3 |

- **One `set_xlabel`:** SJI 16.5 -> 3.8 ms (33 -> 3 calls), Si IV spectrogram 7.7 -> 2.9, λ-time 9.7 -> 4.5, TAN 2.9 -> 2.1.
- **Stage split** (`batch/measure_patched/`, SJI):
  - placement 15.9 -> 4.3 ms;
  - WCS time 15.4 ms in 37 calls -> 2.6 ms in 3 calls (range 0.82, sample 0.72, shifts 1.02);
  - `frame.sample` 6.7 -> 0.9 ms, and `_update_patch_path` 1.63 -> 0.04 ms.
- **Largest piece left.** On the Si IV spectrogram, TickLabels.draw (7.1 ms) is now the largest piece.
- **R5's estimate holds.** R5 estimated 12-13 ms saved per SJI placement; measured, it is 11.6 ms.

**Identity** (`batch/compare.py`).
- **What it compares.** It builds stock and patched figures in one process and compares exact sha1 fingerprints after every draw:
  - every tick and tick-label field, major and minor;
  - the resolved positions, axis labels and `_fl_spacing`;
  - `format_coord`;
  - the Agg RGBA buffer.
- **Steps (13-15 per case).** Pan, zoom, zoom past the footprint, flip y (the negative shift branch), 16 glue slice steps, resize, minor ticks, grid (lines, or contours on Si IV) and `set_xlabel`.
- **Cases (9).** The 5 IRIS and TAN cases, plus:
  - a rotated RA/Dec wrapping through 0 with a galactic overlay;
  - an all-sky AIT ellipse with an fk5 overlay;
  - AIT in a rectangular frame running off the sky (NaN spines and the NaN fallback);
  - a 1-D frame.
- **Result.** Identical at every step.
- **Negative control** (`batch/negctl.py`). Scaling the batched shifts by (1 + 1e-12) broke 11 of 12 steps.

**astropy tests.**
- Plain run: 237 passed, 63 skipped, 1 xfailed, the same as stock.
- With figure tests run through the plugin: 297 passed in both modes. All 60 figure tests ran, and 60 of 60 PNGs were byte-identical.
- The skeptic re-ran the plain suite under astropy's CI warning rules (`filterwarnings=error`, `xfail_strict`; `skeptic_batch/pytest_cfg/pytest.ini`) with the same result. Its figures were also identical, 60 of 60.

**Skeptic** (`skeptic_batch/`). Not confirmed: the gain holds, but output changes were found.
- **Where nothing changed.** 191 edge steps were identical (`skeptic_batch/identity.py`). They covered:
  - spacing and number;
  - `exclude_overlapping`;
  - hidden coordinates;
  - top and right spines;
  - inversions;
  - zoom and sub-pixel zoom;
  - dpi 37 and 250;
  - colorbars, tight bbox, tiny and zero-size axes;
  - axis off;
  - a heliographic overlay.
- **Output changes**, all on failing-WCS or zero-size cases (`skeptic_batch/fp_synthetic_*.json`):
  1. **A WCS whose `pixel_to_world_values` always raises.** Stock raises when the axes is created, through `self.patch = self.coords.frame.patch` (main core.py:155) -> `update_spines` -> the `Spine.data` setter. The patched axes is created without error, and every draw raises from `find_coordinate_range` instead. The cause is the lazy `Spine.world`. **Not fixed.**
  2. **Zero-size axes with an all-NaN WCS.** Stock raises `LinAlgError: Singular matrix` from `transData.inverted()` (main coordinate_helpers.py:1024), which runs on every call. The copy dropped that line, so the patched version draws. **Fixed in `batch_fix.py`** by keeping the inversion at the top of `_update_ticks`.
  3. **A WCS that raises outside its domain** (NaN above the top edge, raises for x < -1). Stock draws 14 ticks. The patched version raises, because the batched calls evaluate points stock never touches: fallback shifts for every spine, and shifts around all-NaN spines. **Fixed in `batch_fix.py`** by falling back to one call per request when a batched call raises. In the normal case the call count stays at 3.
- **Notes.**
  - The TAN gain shows only interleaved (about 0.7 ms).
  - The prototype's own TAN table (21.8 -> 20.8) disagrees with its `batch/out_tan.json` (23.3 -> 22.4).

**Risks.**
- **Pointwise transforms.** Batching assumes output row i depends only on input row i. That holds for wcslib including -TAB, gWCS, `SlicedLowLevelWCS` and SkyCoord overlays. Stock already calls with 2, 1000 and 2601 points, so a non-pointwise user transform is already inconsistent there.
- **One platform.** Bitwise identity was checked on macOS arm64 only. On x86 Linux, SIMD loops could differ by one ulp between batch lengths, and the figure tests (tolerance 0) would show it.
- **Lazy `Spine.world` is a public behaviour change.** `Spine` is a public class, and an exception now appears at first read rather than when the data is set (change 1). There are three options:
  - (i) document it;
  - (ii) keep the eager setter and accept 8 more calls per draw: 4 in `sample`, which runs once per placement because the sample is shared, and the 4 patch-path calls. That is about 2.9 ms on SJI (estimated: 8 × 0.36 ms). The memo PR does not help here, because the two sets of 4 fall in different scopes;
  - (iii) keep it lazy but read `.world` once in `WCSAxes.__init__`, so creation still raises. This is untested.
- **The NaN fallback is computed for every spine** once any coordinate needs it: about 8,000 extra points, about 0.25 ms on -TAB.
- **Stale shifts.** If a formatter or locator callback changed limits, size or DPI in the middle of a placement, the shared shifts would be stale. This is unlikely.
- **1-D frames gain nothing:** 7 calls stay 7.

#### Prototype 3: placement cache across draws, with optional lazy labels

**Files.** `cache/wcsaxes_cache.py` (214 lines; `install(lazy=False|True)`, `uninstall()`, and a `STATS` hit/miss counter). Pytest plugin `cache/wcsaxes_patch_plugin.py` with `cache/pytest.ini`.

**What it changes.**
- **(b) The cache.** It replaces `_update_tick_and_label_positions` (main core.py:556-583).
  - Each CoordinatesMap keeps its last placement while the key matches: the coordinate range plus everything `_update_ticks` writes (`_fl_spacing`, the Ticks and TickLabels dicts, `_lblinfo`, `_lbl_world`).
  - On a hit it restores fresh copies and marks the TickLabels stale. `auto_assign_coord_positions` still runs every time (0.05 ms), so position, visibility and overlay changes behave exactly as before.
  - `reset_wcs` builds a new CoordinatesMap, so a new WCS or slice always starts empty.
- **The key** (`_key`, 60-91). Plain values are compared by pickle bytes, objects by identity.
  - The map and frame: the transform's identity, the frame class and the spine names.
  - The view: xlim and ylim, the scale names, and the full `transData` matrix (size, DPI, limits).
  - `conf.frame_boundary_samples`, `conf.coordinate_range_samples`, and rcParams `text.usetex` and `axes.unicode_minus`.
  - Per coordinate:
    - `coord_index`, type, unit, wrap and `_coord_scale_to_deg`;
    - the formatter_locator's identity and the pickle of its `vars()`;
    - the custom formatter's identity;
    - the minor-tick settings.
  - **A probe of the WCS:** the transform's output on a 3×3 grid over the view, one extra call per placement. This catches in-place WCS edits, such as a crval change, but only if one of the 9 points moves. The `ponytail: probe, not a WCS hash` comment at line 65 marks this limit.
  - If the key cannot be built, the placement runs uncached.
- **(a) Lazy labels** (`install(lazy=True)`).
  - `set_xlabel`/`set_ylabel` append to a queue. The next placement replays it in order after auto-assignment.
  - The queue is also replayed before 12 CoordinateHelper methods that could change or read the label's coordinate, and before `get_coords_overlay`.
  - `reset_wcs` drops the queue.

**Measured gain** (base / cache / lazy, ms, 400x330; `cache/out/tables.md`):

| Case | Static draw | Slice step total | WCS calls per draw |
|---|---|---|---|
| SJI 1400 | 28.1 / 11.9 / 11.5 | 95.6 / 31.7 / 29.2 | 37 -> 5 |
| SJI 2796 | 48.2 / 30.8 / 30.9 | 115.4 / 52.0 / 50.7 | 37 -> 5 |
| Si IV spectrogram | 22.5 / 15.1 / 14.6 | 56.2 / 25.7 / 23.9 | 53 -> 5 |
| Si IV λ-time | 38.3 / 28.8 / 28.8 | 75.2 / 38.1 / 37.6 | 59 -> 5 |
| TAN map | 22.0 / 20.0 / 19.5 | | 37 -> 5 |

- **Calls on a hit.** The 5 calls are the probe plus the 4 patch-path calls.
- **Contrast change:** SJI 28.7 -> 12.7 ms, which matches R18's tick-reuse estimate of about -16 ms.
- **Pans** miss every time: no faster, and 0.41 ms of bookkeeping on SJI (0.35 ms of it the probe).
- **One `set_xlabel`:** SJI 16.4 -> 0.5 -> 0.0 ms.
- **Lazy adds little.** On glue's slice step, lazy saves only 0.5-5 ms beyond the cache, because the cache already turns glue's 4 label sets into 1 placement plus 3 hits. Lazy only saves a whole placement when the limits change between the label set and the draw, or when no draw follows.

**Identity** (`cache/ident.py`, `cache/compare.py`).
- **Cases.** The IRIS cases, TAN, TAN rolled 30°, an all-sky AIT with off-sky NaN and an FK5 overlay, and a 1-D frame.
- **Steps.** Static draw, contrast, pan, zoom, glue slice steps and resize. Then `set_ticks(number=8)`, a format unit, a formatter, minor ticks, toggling `unicode_minus`, grids, an in-place crval edit, tick labels moved to 't', and label-ordering cases.
- **Result.** 16 of 16 case/mode pairs were identical to base at every step.
  - The hit/miss log shows hits on static, contrast, grid, position moves and relabel.
  - It shows misses on pan, zoom, resize, set_ticks, unit, formatter, minor ticks, unicode_minus and the crval edit.
- **Negative control.** A key that never changes broke 16-20 of about 20 steps per case.

**astropy tests** (`pytest -c cache/pytest.ini`, astropy 8.0.1's own pytest settings including `filterwarnings=error`).
- Base and cache: 297 passed, 1 failed (LaTeX), 3 skipped, 1 xfailed. Lazy: 296 passed, 2 failed.
- **The lazy-only failure** is `test_misc.py::test_set_label_properties` (8.0.1 test_misc.py:152-171). It reads private `_axislabels` right after `set_xlabel`, with no draw.
- **Figures.** All 59 runnable PNGs were identical to base, on a first save and on a second save that hits the cache.
- **Coverage warning.** With a key that never changes, the suite still passes, and only 2 of 59 figures change (`TestFrame::test_update_clip_path_*`). astropy's tests barely exercise redraws after a change.

**Skeptic** (`skeptic/`). Confirmed.
- **Plain matplotlib:**
  - SJI static draw 26.6 -> 10.7 ms;
  - slice step 92.4 -> 30.7 ms;
  - one `set_xlabel` 16.3 -> 0.49 ms;
  - Si IV spectrogram static draw 21.5 -> 12.9 ms;
  - λ-time static draw 36.0 -> 27.8 ms.
- **glue's Qt ImageViewer** (`skeptic/glue_app.py`, offscreen, no plugins): static draw 26.6 -> 10.4 ms, slice step 96.3 -> 31.0 ms.
- **Pans.** Interleaved A/B (`skeptic/pan_ab.py`, n=200) gives +0.5 ms per miss.
- **Tests.** Same as the prototype, with 171 cache hits during the suite.
- **Edge sequences.** 19 synthetic and 2 IRIS sequences were identical to base (`skeptic/edge.py`). They covered:
  - spacings, values, formats and units;
  - `set_coord_type`;
  - hidden coordinates;
  - top and right spines;
  - overlays added after the first draw;
  - colorbars, tiny and zero-size axes, NaN regions;
  - a transform that starts raising;
  - `savefig` at other DPIs and with a tight bbox;
  - constrained layout;
  - an elliptical frame;
  - inversions and a log scale.
- **Problems found.**
  - Both reported limits reproduce as stale ticks: a formatter whose output depends on a global, and a transform mutated only between the probe points.
  - **Warnings.** The probe's `catch_warnings` resets Python's once-per-location registry. A warning shown once per draw in base appears [2,0,1,3,2,0] times over six draws.
  - **Lazy mode after `ax.cla()`.** A label queued just before `cla()` is never flushed into private state. The pixels are the same.
  - **Pickling.** The prototype's pickling caveat does not matter, because a WCSAxes figure cannot be unpickled in 8.0.1 anyway.

**Risks.**
- **The cache checks the WCS by probing, which is not proof.** This is the objection astrofrog raised on #16362 ("hash(wcs) does not change even if some of the transformation parameters change"). Upstream will probably want an explicit invalidation instead of the probe.
- **Some state is outside the key:** formatter output, custom frames whose `update_spines` reads other state, mutable custom transforms, other rcParams, and non-linear scales (keyed by name only).
- **Warnings are not repeated on a hit.**
- **astropy's suite would not catch a bad key.** New invalidation tests are needed, and `cache/ident.py`'s sequence is a template.
- **Lazy labels change behaviour.**
  - The label's coordinate is chosen at the next placement, not at call time.
  - Exactness relies on a hand-kept list of 12 flushing methods.
  - A test that reads private state needs rewriting.
- **Misses are not faster**, so slider drags still need batching.

### Recommended astropy PRs, smallest first

These are for M4 and only on the user's direction. Each PR should state numbers on solar data, because astrofrog asked for exactly that on #16366.

**Step 0, in glue-core and independent of astropy: the R1 fix.** In `_set_wcs`, set the labels with `axes.coords[...].set_axislabel(...)` instead of `set_xlabel`/`set_ylabel`.
- **Gain.** The SJI set phase drops from 66 ms to 0.4 ms, with ticks and labels identical. The astropy changes can at best match it. Each step still needs one placement for its new transform: with the cache, the first label set makes it and the draw hits; with lazy labels, the draw makes it.
- **What still needs astropy.** Other WCSAxes users (sunpy, mpl-animators, scripts) still pay the eager placement. That is the astropy half below.

**PR 1: reuse `pixel_to_world_values` results within one placement (the memo).**
- **The change.** core.py only, about 30 lines of logic (`minimal/upstream_core.diff`, +55/-16), with the same scope and argument as `_coord_range` from #16366. Pass `values` through unchanged in the wrapper before opening it.
- **What reviewers will want:**
  - A non-image test that counts `pixel_to_world_values` calls on a 2-D WCS (37 -> 21 per draw, 33 -> 17 per `set_xlabel`).
  - A test that no `transform` attribute is left behind and that callers never share a result array.
  - Every figure hash unchanged on CI (the `py312-test-image-mpl380-cov` tox env; 56 `@figure_test` functions, 60 collected tests).
  - A `performance` changelog entry.
  - The `benchmark` label. `time_basic_plot_with_grid_and_overlay` moves about -23 to -26%, near asv's 1.3x threshold. The other four do not move.
  - A new asv benchmark in astropy-benchmarks with a sliced 3-D WCS or an APE-14 WCS with a fixed per-call delay, standing in for gWCS. All 5 existing wcsaxes benchmarks use 2-D FITS headers.
- **Expected objection.** The instance-attribute shadowing may be challenged ("follow local idioms"). Have the explicit-cache alternative ready, and say what it loses: the overlay gain.
- **Why first.** It is the smallest and most reviewable, it matches the maintainer's stated design, it was already run on main, and an existing benchmark moves.

**PR 2: batch the frame sample and the tick-angle shifts (prototype 2 plus `batch_fix.py`).**
- **The change.** frame.py (the `Spine.data` setter and `world` getter, `sample`), coordinate_helpers.py (`_update_ticks`, about 10 lines plus a helper) and core.py (`_update_tick_and_label_positions`). These are private methods, which #10936 allows to change.
- **Before opening:**
  - Fold in both skeptic fixes.
  - Pick an option for the lazy `Spine.world` behaviour change (see prototype 2's risks).
  - Consider evaluating shifts only for spines stock would evaluate, so the batched call never touches new points. Untested.
  - Measure it stacked on PR 1, which was not done. After PR 1 its extra gain on SJI should be roughly 19 -> 13 ms per draw. That is an estimate from separate harnesses.
- **What reviewers will want:**
  - The same call-count test (37 -> 3).
  - Tests for WCSes that raise outside their domain, all-NaN spines and zero-size axes, showing unchanged behaviour.
  - Figure hashes unchanged on Linux CI. This is the real test of the x86 ulp risk.
  - The benchmark from PR 1.
  - The bit-exact fingerprint harness (`batch/compare.py`) described in the PR as evidence.
- **Why second.** It is the biggest gain on every draw, pans and slider drags included, but it changes the code few people know (`_update_ticks`) and needs the failing-WCS fixes.

**PR 3, only after PRs 1 and 2 are in and re-measured: the placement cache across draws.**
- **How much it would still save.** Once batched, an SJI placement costs about 4.3 ms. That is what the cache would still save per unchanged redraw, against 16 ms today (estimated).
- **What it would still be for:** contrast and bias drags, and redraws of unchanged viewers.
- **What it cannot help:** glue slice steps, because every step makes a new transform.
- **The alternative.** R18's redraw caching in glue/glue-qt, which avoids the invalidation question inside astropy. It can skip WCSAxes only if the decorations are cached as their own layer above the image; R18's upper bound assumes no WCSAxes work at all.
- **If proposed:**
  - Open an issue first, asking astrofrog which invalidation he would accept, for example an explicit `invalidate` hook plus the cheap key fields, instead of the probe.
  - Bring new tests that redraw after every kind of change (`cache/ident.py`'s sequence), because the current suite passes with a cache that never invalidates.

**PR 4, optional: lazy `set_xlabel`/`set_ylabel`.**
- **Gain after PRs 1 and 2.** An eager placement costs SJI 3.8 ms batched, or 9.7 ms with the memo alone, so the gain per label call is small.
- **Cost.** It changes when a label picks its coordinate, needs a hand-kept list of 12 flushing methods, and breaks `test_set_label_properties`.
- **Ask first.** Ask astrofrog whether the eager call in 46a541d624 ("Fixed non-image tests") was only there for the tests.
- **Skip it if R1 lands in glue.**

**A drive-by for PR 1 or 2.** `coords.frame.update()` (core.py:571) is a no-op. Removing it is safe unless a custom frame defines `update()`, which would currently be called on every placement. Check sunpy's custom frames first.

**How this changes the ranked items.**
- **R5.** Both candidate fixes are now prototyped and measured: batching -11.6 ms per SJI placement (estimate was 12-13), caching -15.9 ms per unchanged SJI redraw (estimate 16).
- **R1.** The astropy alternative (lazy labels) is prototyped, and adds 0.5-5 ms beyond the cache for glue. The glue-side fix stays the first choice.
- **R18.** Tick reuse measured SJI contrast 27.4 -> 11.0 ms (skeptic).
- **S7.** After batching, `_GlueWCS`'s 0.05 ms per call matters for only 3 calls per draw instead of 37.

### Upstream context

**Earlier WCSAxes speed work (all merged).**
- [#7568](https://github.com/astropy/astropy/pull/7568) (astrofrog, 2018): all contour paths go through one transform call, which made contours 10-1000x faster (14.5 s -> 198 ms). It is the only earlier batching change.
- [#14164](https://github.com/astropy/astropy/pull/14164) (ayshih, 2022): `_update_ticks` reuses spine world values already computed and bails out on all-NaN spines. It was approved by Cadair and larrybradley and backported to 5.2 as a bugfix, after [sunpy#6652](https://github.com/sunpy/sunpy/issues/6652).
- [#16362](https://github.com/astropy/astropy/issues/16362) and [#16366](https://github.com/astropy/astropy/pull/16366) (ayshih, merged 2024-09 by astrofrog): `find_coordinate_range` now runs once per draw instead of 4 times. The gain was only about 8% (66 -> 61 ms; 483 -> 448 ms with an overlay). It introduced `_coord_range` and used the `performance` changelog type.
- [#17404](https://github.com/astropy/astropy/pull/17404) (thuiop, 2024): imshow was slow because of a `minversion(PIL)` call.
- [#17243](https://github.com/astropy/astropy/pull/17243) (astrofrog, astropy 7.0): automatic placement. Its commit 46a541d624 added the eager placement to `set_xlabel`, `set_ylabel`, `get_xlabel`, `get_ylabel` and `tick_params`. The tests that cover this are test_misc.py:155-172, 549-574 and 664-674, and test_images.py:602 and 1150.
- [#12630](https://github.com/astropy/astropy/pull/12630) (dstansby): moved tick-label pixel coordinates to draw time, because computing them earlier "is not a safe thing to do".

**Open items that match ours.**
- [glue#1587](https://github.com/glue-viz/glue/issues/1587) (astrofrog, 2018): slicing is slow because the labels and ticks are redrawn every time. This is R1/R18.
- [glue#1823](https://github.com/glue-viz/glue/issues/1823): the image viewer is slow with overplotted points.
- [sunpy#6652](https://github.com/sunpy/sunpy/issues/6652) (2022): `draw_grid` takes 0.38 s, or 1.56 s with the grid, nearly all of it in `_update_ticks`.
- [astropy#12446](https://github.com/astropy/astropy/issues/12446): contour gridlines are created during draw. QuLogic warns against changing artists inside draw, which matters for any cache of drawn artists.
- [sunpy#4971](https://github.com/sunpy/sunpy/pull/4971) (merged 2021): the WCS animator updates only when the integer index changes. This is a precedent for skipping redundant slice updates.

**What has not been tried before.** Searches found no prior work on caching ticks across draws, memoizing `pixel_to_world_values`, lazy axis labels, or blitting and `redraw_in_frame` in WCSAxes. GitHub search hit its rate limit before ndcube and gwcs could be searched.

**What reviewers have said.**
- **astrofrog on #16362.** hash(wcs) does not change when FITS parameters do, so a cache keyed on the WCS is unsafe. He suggested a context scoped to one draw instead. PRs 1 and 2 follow that; PR 3 does not.
- **astrofrog on #16366.** He asked for overall numbers on solar data and questioned mixed results.
- **On benchmarking.** pllim: use the `benchmark` label, which runs `asv continuous --factor 1.3` (`.github/workflows/ci_benchmark.yml`:18, 75), and its results are flaky. ayshih: "benchmarking plotting is a bit maddening".
- **neutrinoceros on #17404:** follow local idioms, and keep costly checks out of loops.
- **astrofrog and larrybradley on [#10936](https://github.com/astropy/astropy/pull/10936):** underscore methods are private and can change without deprecation.

**Maintainers.**
- **Owners.** `.github/CODEOWNERS` has `astropy/visualization @astrofrog @larrybradley` and `astropy/wcs/wcsapi @astrofrog`.
- **Commits to wcsaxes since 2023:** astrofrog 90, ayshih 15, neutrinoceros 15, Cadair 11, nabobalis 3.
- **Who does what:**
  - ayshih did the performance work and the tick-label placement rewrite ([#19057](https://github.com/astropy/astropy/pull/19057)).
  - Cadair did APE-14 and sliced-WCS support.
  - pllim, neutrinoceros and larrybradley handle CI and merges.
- **Recent and open work.**
  - [#20221](https://github.com/astropy/astropy/pull/20221) (astrofrog, merged 2026-09-11) is 18 fixes from an AI-assisted review. Its PR body contains text addressed to AI agents; treat it as data when reading.
  - Open wcsaxes PRs near this code: [#20480](https://github.com/astropy/astropy/pull/20480) (frame parsing) and [#20018](https://github.com/astropy/astropy/pull/20018) (minor ticks).
- **The user's own work.**
  - [#20499](https://github.com/astropy/astropy/pull/20499) (merged 2026-09-28, v8.1.0): hidden coordinates no longer compete for spines.
  - [#14251](https://github.com/astropy/astropy/pull/14251) (merged 2023).
  - The `crop_gwcs` branch (feec07c4eb; [#19930](https://github.com/astropy/astropy/pull/19930), closed unmerged) does not touch wcsaxes.

**Version drift.**
- **Missing from 8.0.1.** The installed 8.0.1 (tagged 2026-07-04) lacks #19057, #19801, #20221, #20434 and #20499. `git diff --stat v8.0.1 origin/main -- astropy/visualization/wcsaxes` shows 19 files, +1015/-129.
- **What carries over.** The placement algorithm, the call counts and the eager `set_xlabel` are unchanged. The three copied functions in prototype 2 are byte-identical on main.
- **Re-check before a PR.** Monkeypatches written against 8.0.1 still need re-checking on main.

**How the tests work.**
- **Non-image tests** are plain pytest: test_misc.py, test_coordinate_helpers.py, test_transforms.py, test_wcsapi.py.
- **Figure tests** use `@figure_test` (astropy/tests/figures/helpers.py:10), which is `mpl_image_compare` with tolerance 0, marked remote_data.
  - Hashes are kept in `astropy/tests/figures/py312-test-image-mpl380-cov.json` and `...-mpldev-cov.json`, and are valid only on Linux with the pinned freetype.
  - Run them with `tox -e py312-test-image-mpl380-cov`.
  - When a hash changes, download the JSON from the CI summary page. Baselines live in astropy/astropy-figure-tests (docs/development/testguide.rst:669-750).
  - A performance PR should change no hash.
- **Benchmarks.** [astropy-benchmarks](https://github.com/astropy/astropy-benchmarks) `benchmarks/visualization/wcsaxes.py` has 5 benchmarks, all on 2-D FITS celestial headers:
  - `time_basic_plot`;
  - `..._with_grid`;
  - `..._with_grid_and_overlay`;
  - two contour benchmarks.

### Stock astropy problems found on the way

These behave the same with and without every prototype. All were found on 8.0.1; those marked "main?" have not been re-checked on main, and #20221 may have fixed some.
- [ ] **`format_coord` on a 1-D WCSAxes** raises `ValueError('Expected 1 world coordinates, got 2')` (8.0.1 core.py:167). main's `_display_world_coords` (core.py:160-187) has the same code. No issue found.
- [ ] **Three-coordinate views (both Si IV views).**
  - `grid(draw_grid=True)` with 'lines' raises `IndexError` in `SlicedLowLevelWCS.world_to_pixel_values`.
  - `WCSWorld2PixelTransform` raises `ValueError('Expected 2 world coordinates, got 3')` (main wcsapi.py:387-388), so `plot_coord`, `scatter_coord` and line grids cannot be used there. Contour grids work.
  - Related: R8, where the sliced Si IV world-to-pixel takes 5-15 ms per point.
- [ ] **A sliced-out coordinate (SJI time, `coord_index` None).** main?
  - `set_ticklabel_position('#')` on all three coordinates makes every draw raise `TypeError: 'NoneType' object is not iterable` (8.0.1 _auto.py:116).
  - With `set_ticks_position('all')` as well, after `invert_xaxis()` every draw raises `IndexError` (8.0.1 ticklabels.py:155), even after un-inverting.
  - Reproducer: `skeptic_batch/side_auto.py`.
- [ ] **Swapped 3-D cube.** With slices `('y','x',7)`, the third coordinate's labels on top and `tick_params(labelsize=6)`, `simplify_labels` raises `IndexError`. main?
- [ ] **`add_tickable_gridline` fully outside the view** raises `IndexError` in `transform`. main?
- [ ] **Zero-width or zero-height axes** raise `LinAlgError: Singular matrix` on draw. main?
- [ ] **Pickling.** A WCSAxes figure cannot be unpickled (`TypeError: BaseFrame.__init__() missing parent_axes and transform`). main?
- [ ] **First draw against second draw.** They differ in the last bits of one axis-label y position and one label bbox. A cache across draws must reproduce the second draw.
- [ ] **Wrong second crossing (8.0.1 only, fixed on main by #20221).** `t *= _coord_scale_to_deg` mutates the loop variable (8.0.1 coordinate_helpers.py:1178). A second crossing of an arcsec longitude on one spine therefore gets a wrong value. IRIS longitudes are arcsec, so rolled IRIS views on 8.0.1 can show it.

### Open questions

1. **Stacking.** Do PRs 1 and 2 stack as expected? They were never measured together. After batching, the memo may only help overlays and grids.
2. **Linux hashes.** Does batching keep the figure hashes on Linux x86? Only CI can tell.
3. **Lazy `Spine.world`.** Which option should PR 2 take: (i), (ii) or (iii)?
4. **Range call.** Should PR 2 also fold the range call into the batch (3 -> 2 calls, about 0.7 ms on gWCS)?
5. **Patch-path calls.** Should the 4 `_update_patch_path` calls (1.6 ms on SJI) be covered? The memo would need a wider scope, around all of `Axes.draw`. Batching's lazy `Spine.world` already removes them.
6. **The cache upstream.** Is the cross-draw cache worth proposing once PRs 1 and 2 and R18's redraw caching in glue exist? If so, what invalidation would astrofrog accept?
7. **Eager labels.** Was the eager placement in `set_xlabel` (46a541d624) only for the tests? Do sunpy or mpl-animators call `set_xlabel` per frame? If not, PR 4 has little value beyond glue.
8. **λ-time tick labels** (glue-solar, unmeasured). The fix could be:
   - `set_ticklabel(exclude_overlapping=True)` on latitude;
   - hiding latitude labels when the coordinate barely changes;
   - formatting wavelength in Angstrom, as the plan already decided (arcsec + Angstrom units).

   `exclude_overlapping` still measures every label, so its gain needs measuring.
9. **Not covered.** No prototype was run at DPR2 or on a real screen. Batching was not run in glue's Qt viewer. The cache's pan cost was measured only offscreen.
10. **Reporting.** Should the stock problems above be re-checked on main and reported upstream? That is an outward action for the user to decide.

### Files

All files are in `IRIS_PLAN_PROTOTYPES/wcsaxes_study_20261001.tar.gz`. Paths are relative to the archive root, which was scratchpad `wcsaxes/`.

| Path | What |
|---|---|
| `walkthrough.md`, `measure.md`, `upstream.md` | Full understand-phase notes this section condenses |
| `explain/` | `calls.py`, `phases.py`, `grid_probe.py`, `reset_probe.py`; outputs `out_*.txt`, `phases_*.txt` |
| `measure/` | `measure.py` (harness), `out_*.json`, `log_*.txt`, `tables.py`/`tables.md`, `batch.py`/`batch.log` (batching table), `probe2.py` and logs (label counts, Si IV world-to-pixel cost), `lt_*.png`/`spec_*.png` (Si IV renders) |
| `upstream/` | Search outputs and main copies read with `git show` |
| `minimal/memo_patch.py` | **Prototype 1** monkeypatch |
| `minimal/upstream_core.diff` | Prototype 1 as a diff against main core.py |
| `minimal/` (other) | `memo_plugin.py` (pytest), `identity.py`/`compare.py`, `measure.py`/`run_all.sh`/`tables.md`, `msx_ab.py`, `bench_asv.py`, `overhead.py` |
| `skeptic_minimal/` | `ab.py`, `edge.py`/`cmp_edge.py`, `glue_viewer.py`, `warn_check.py`, `count_calls.py`, `run_pytest.sh`, `shadow_plugin.py` (main's wcsaxes over 8.0.1) |
| `batch/wcsaxes_batch.py` | **Prototype 2** monkeypatch |
| `batch/` (other) | `wcsaxes_batch_plugin.py`, `compare.py`, `negctl.py`, `measure_patched/`, `figs_0`/`figs_1` |
| `skeptic_batch/batch_fix.py` | The two failing-WCS fixes for prototype 2 |
| `skeptic_batch/` (other) | `timing.py`, `identity.py`, `fp_*.json`, `side_auto.py` (stock bugs), `pytest_cfg/pytest.ini` |
| `cache/wcsaxes_cache.py` | **Prototype 3** monkeypatch |
| `cache/` (other) | `wcsaxes_patch_plugin.py`, `pytest.ini`, `cases.py`, `ident.py`/`compare.py`, `bench.py`/`tables.py`/`overhead.py`, `py` (wrapper), `out/` |
| `skeptic/` | `bench.py`, `glue_app.py`, `pan_ab.py`, `edge.py`/`edge_compare.py`, `warn_probe.py`, `cla_probe.py`, `stats_plugin.py`, `out/` |
| `axesoff/` | S14's scripts |
