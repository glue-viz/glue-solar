import json, sys, statistics as st, collections
for fn in sys.argv[1:]:
    rows = [json.loads(l) for l in open(fn) if l.startswith("{")]
    g = collections.defaultdict(list)
    for r in rows:
        if r["rep"] == 0: continue
        g[(r["case"], r["flow"], r["which"])].append(r)
    print("==", fn)
    for k, rs in g.items():
        m = lambda key: st.median(r[key] for r in rs)
        print(f"{k[0]:12} {k[1]:6} {k[2]:5} n={len(rs)} s={m('s'):.3f} [{min(r['s'] for r in rs):.3f}-{max(r['s'] for r in rs):.3f}] peakRSS={m('peak_rss_GB'):+.3f} keptRSS={m('kept_rss_GB'):+.3f} peakFP={m('peak_fp_GB'):.3f} keptFP={m('kept_fp_GB'):.3f} infl={m('inflated_MiB')} load1={m('load1')} others={rs[0]['others']}")
