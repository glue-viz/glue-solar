"""apply_dust_mask / remove_dust / radiometric_calibration on memmap vs eager cubes, and on glue-solar's meta['scaled']=True cube."""
import warnings, numpy as np
warnings.simplefilter("ignore")
from irispy.io.sji import read_sji_lvl2
from irispy.utils.dust import remove_dust
F = "/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-207/vimpact/data/iris_l2_20130902_163935_4000255147_SJI_1400_t000.fits"
m = read_sji_lvl2(F, memmap=True)[0:3]
e = read_sji_lvl2(F, memmap=False)[0:3]
for name, c in (("memmap", m), ("eager", e)):
    before = np.asarray(c.mask, dtype=bool).copy()
    try:
        c.apply_dust_mask()
        added = np.asarray(c.mask, dtype=bool) & ~before
        print(name, "apply_dust_mask ok, dust % of non-fill:", round(100 * added.sum() / (~before).sum(), 4), "scaled", c.meta["scaled"])
    except Exception as ex:
        print(name, "apply_dust_mask raised", type(ex).__name__, ex)
for name, c in (("memmap", read_sji_lvl2(F, memmap=True)[0:3]), ("eager", read_sji_lvl2(F, memmap=False)[0:3])):
    try:
        remove_dust(c); print(name, "remove_dust ok")
    except Exception as ex:
        print(name, "remove_dust raised", type(ex).__name__, ex)
c = read_sji_lvl2(F, memmap=True)[0:3]
c.meta["scaled"] = True  # as glue-solar's _image_cube_data sets it
try:
    out = remove_dust(c); print("memmap+scaled=True remove_dust passes check_scaled; out min/max", np.nanmin(out.data), np.nanmax(out.data))
except Exception as ex:
    print("memmap+scaled=True remove_dust raised", type(ex).__name__, ex)
