#!/bin/bash
V=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-207/vimpact
P=/Users/nabil/Git/glue-solar/IRIS_PLAN_PROTOTYPES
I=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-main-check/irispy
cd $V
run() { # label env repo
  local start=$(date +%s)
  env HOME="$(mktemp -d)" QT_QPA_PLATFORM=offscreen MPLBACKEND=agg PYTHONPATH=$P /Users/nabil/mamba/envs/$2/bin/python -B $P/run_checks.py "$I:$3:$P" $3/glue_solar --remote-data=any > $V/$1.log 2>&1
  echo "$1 exit=$? secs=$(( $(date +%s)-start ))" >> $V/suites.summary
}
run gs-accept-plan iris-plan /Users/nabil/Git/glue-solar-accept
run gs-accept-floor iris-plan-floor /Users/nabil/Git/glue-solar-accept
run gs-origin-plan iris-plan $V/gs-origin-main
