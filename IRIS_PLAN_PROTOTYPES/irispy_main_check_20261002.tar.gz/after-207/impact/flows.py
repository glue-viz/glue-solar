"""SJI read flows for glue-solar's image_data. flow(name, path) -> glue Data.
now: glue-solar 341a82b image_data. bytes: one gunzip, read_sji_lvl2(bytes, memmap=True), raw = cube.data
(plain files: read_files). read_files: irispy's read outright, raw = cube.data."""
import gzip
from irispy.io import read_files
from irispy.io.sji import read_sji_lvl2
from glue_solar.sources.loaders import iris as L
from glue_solar.sources.loaders.lazy import allow_open_files


def alt(name, path):
    with open(path, "rb") as f:
        gz = f.read(2) == b"\x1f\x8b"
    if name == "bytes" and gz:
        with gzip.open(path) as f:
            cube = read_sji_lvl2(f.read(), memmap=True, uncertainty=False)
    else:
        cube = read_files(path, memmap=True, uncertainty=False)
    scaling = L._raw_scaling(cube.meta)
    if scaling:
        allow_open_files()
    return L._image_cube_data(cube, path, cube.data if scaling else None, scaling), cube


def flow(name, path):
    return L.image_data(path) if name == "now" else alt(name, path)[0]
