"""Process memory and disk counters on macOS: proc_pid_rusage(RUSAGE_INFO_V4)."""
import ctypes, os, resource
_libproc = ctypes.CDLL("/usr/lib/libproc.dylib")
_buf = ctypes.create_string_buffer(512)

def usage():
    if _libproc.proc_pid_rusage(os.getpid(), 4, _buf) != 0:
        raise OSError("proc_pid_rusage")
    q = lambda off: int.from_bytes(_buf.raw[off:off + 8], "little")
    return {
        "rss": q(64),            # ri_resident_size (= psutil rss), includes file-backed mapped pages
        "footprint": q(72),      # ri_phys_footprint (Activity Monitor 'Memory'), excludes clean file-backed pages
        "max_footprint": q(240), # ri_lifetime_max_phys_footprint
        "disk_read": q(144),     # ri_diskio_bytesread
        "pageins": q(48),
        "maxrss": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,  # bytes on macOS, lifetime peak
    }
