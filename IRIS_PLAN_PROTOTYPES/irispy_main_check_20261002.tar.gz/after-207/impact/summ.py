import json, sys, statistics as st
from collections import defaultdict
rows = [json.loads(l) for l in open(sys.argv[1]) if l.strip()]
g = defaultdict(list)
for r in rows:
    if r["rep"] > 0:
        g[(r["file"], r["which"], r["flow"])].append(r)
keys = ["s", "peak_rss_GB", "peak_fp_GB", "kept_fp_GB", "kept_rss_GB", "inflated_MB", "load1"]
for k, rs in sorted(g.items()):
    print(k, len(rs), {f: st.median(r[f] for r in rs) for f in keys}, "s range", min(r["s"] for r in rs), max(r["s"] for r in rs))
