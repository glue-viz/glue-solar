#!/bin/bash
# run1.sh <irispy: main|base|57813b8> <flow> <gz|fits>: one fresh process, CPU of others logged
W=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-207/impact
S=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad
G=/Users/nabil/Git/glue-solar-accept
case $1 in main) PP=$S/irispy-main-check/irispy:$G;; pre) PP=$S/irispy-207/irispy-57813b8:$G;; base) PP=$G;; esac
if [ $3 = gz ]; then F=$(ls /Users/nabil/DATA/IRIS/*4000255147_SJI_1400_t000.fits.gz); else F=$W/data/iris_l2_20130902_163935_4000255147_SJI_1400_t000.fits; fi
cd $W
{ date +%T; ps -Ao pcpu,comm -r | sed -n 2,5p | tr '\n' ';'; echo; } >> cpu.log
env HOME="$(mktemp -d)" MPLCONFIGDIR=$W/mplcfg QT_QPA_PLATFORM=offscreen MPLBACKEND=agg PYTHONPATH=$PP:$W /Users/nabil/mamba/envs/iris-plan/bin/python -B time_flow.py $2 $F 2>>err.log | sed "s/^{/{\"which\": \"$1\", /"
