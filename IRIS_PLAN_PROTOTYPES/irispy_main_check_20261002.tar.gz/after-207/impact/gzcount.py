"""python gzcount.py <what>: MB inflated (gzip) and time for one operation on 4000255147 SJI 1400 .gz"""
import glob, gzip, json, sys, time
inflated = [0]
_read = gzip._GzipReader.read
def read(self, size=-1):
    out = _read(self, size); inflated[0] += len(out); return out
gzip._GzipReader.read = read
import irispy, irispy.io
from astropy.io import fits
path = glob.glob("/Users/nabil/DATA/IRIS/*4000255147_SJI_1400_t000.fits.gz")[0]
what = sys.argv[1]
t = time.perf_counter()
if what == "read_files_memmap":
    irispy.io.read_files(path, memmap=True)
elif what == "read_files_eager":
    irispy.io.read_files(path, memmap=False)
elif what == "getheader":
    fits.getheader(path)
elif what == "open_data":
    with fits.open(path) as h:
        h[0].data
print(json.dumps({"what": what, "irispy": irispy.__version__, "inflated_MB": round(inflated[0] / 2**20, 1), "s": round(time.perf_counter() - t, 3)}))
