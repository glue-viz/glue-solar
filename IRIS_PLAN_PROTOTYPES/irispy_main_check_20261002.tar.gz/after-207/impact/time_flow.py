"""python time_flow.py <now|bytes|read_files> <path>: one fresh-process load; JSON line."""
import gc, gzip, json, os, sys, threading, time
import psutil
from mem import usage
inflated = [0]
_read = gzip._GzipReader.read
def read(self, size=-1):
    out = _read(self, size); inflated[0] += len(out); return out
gzip._GzipReader.read = read
import irispy, irispy.io, irispy.io.sji
from flows import flow
name, path = sys.argv[1], sys.argv[2]
proc = psutil.Process(); gc.collect(); u0 = usage(); rss0 = proc.memory_info().rss
peak = [rss0]; stop = threading.Event()
def sample():
    while not stop.is_set():
        peak[0] = max(peak[0], proc.memory_info().rss); time.sleep(0.001)
th = threading.Thread(target=sample, daemon=True); th.start()
t = time.perf_counter()
data = flow(name, path)
dt = time.perf_counter() - t
stop.set(); th.join(); gc.collect(); u1 = usage()
GB = 1e9
print(json.dumps({"flow": name, "file": "gz" if path.endswith(".gz") else "fits", "irispy": irispy.__version__, "s": round(dt, 3),
                  "peak_rss_GB": round((max(peak[0], u1["maxrss"] if u1["maxrss"] > u0["maxrss"] else 0) - rss0) / GB, 3), "kept_rss_GB": round((u1["rss"] - rss0) / GB, 3),
                  "peak_fp_GB": round((u1["max_footprint"] - u0["footprint"]) / GB, 3), "kept_fp_GB": round((u1["footprint"] - u0["footprint"]) / GB, 3),
                  "inflated_MB": round(inflated[0] / 2**20, 1), "type": type(data).__name__, "load1": round(os.getloadavg()[0], 2)}))
