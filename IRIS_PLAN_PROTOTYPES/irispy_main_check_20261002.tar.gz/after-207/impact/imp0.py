import sys, time, json
t = time.perf_counter(); import irispy.io; t1 = time.perf_counter()
import irispy
print(json.dumps({"irispy": irispy.__version__[-9:], "import_irispy_io_s": round(t1 - t, 3), "sunpy_map_after_import": "sunpy.map" in sys.modules}))
