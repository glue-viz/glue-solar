"""python opens.py <mode>: fits.open calls and time for 3602506433 (99 files), memmap=True.
mode: rf = read_files(files) once; rf_each = read_files([f]) per file (glue-solar's way); reader = read_spectrograph_lvl2(files); gs = glue-solar raster_data(stack=True)"""
import glob, json, sys, time, warnings
warnings.simplefilter("ignore")
from astropy.io import fits
import irispy
from irispy.io import read_files
from irispy.io.spectrograph import read_spectrograph_lvl2
files = sorted(glob.glob("/Users/nabil/DATA/IRIS/*3602506433_raster/*.fits"))
n = [0]; _open = fits.open
def counted(*a, **k):
    n[0] += 1; return _open(*a, **k)
fits.open = counted
import irispy.io.utils, irispy.io.spectrograph
irispy.io.utils.fits.open = counted  # same module object; kept for clarity
mode = sys.argv[1]
t = time.perf_counter()
if mode == "rf":
    read_files(files, memmap=True)
elif mode == "rf_each":
    for f in files: read_files([f], memmap=True)
elif mode == "reader":
    read_spectrograph_lvl2(files, memmap=True)
elif mode == "gs":
    from glue_solar.sources.loaders import iris as L
    L.raster_data(files, stack=True)
elif mode == "headers":
    for f in files:
        with fits.open(f) as h: h[0].header
print(json.dumps({"mode": mode, "irispy": irispy.__version__[-9:], "opens": n[0], "s": round(time.perf_counter() - t, 3)}))
