"""One glue-solar load in a fresh process: python load_probe.py <case>; prints one JSON line.
Peak RSS sampled every 1 ms plus ru_maxrss; footprint from proc_pid_rusage; gzip bytes inflated counted."""
import gc, glob, gzip, json, os, sys, threading, time
import psutil
from mem import usage

D = "/Users/nabil/DATA/IRIS"
SCR = os.path.dirname(os.path.abspath(__file__))
CASES = {
    "sji1400gz": ("image", glob.glob(f"{D}/*4000255147_SJI_1400_t000.fits.gz")),
    "sji1400fits": ("image", [f"{SCR}/data/iris_l2_20130902_163935_4000255147_SJI_1400_t000.fits"]),
    "sji2796gz": ("image", glob.glob(f"{D}/*4000005156_SJI_2796_t000_deconvolved.fits.gz")),
    "r4000005156": ("raster", sorted(glob.glob(f"{D}/*4000005156_raster/*.fits"))),
    "r3824262996": ("raster", sorted(glob.glob(f"{D}/*3824262996_raster/*.fits"))),
    "r4000255147": ("raster", sorted(glob.glob(f"{D}/*4000255147_raster/*.fits"))),
    "r3400109360": ("raster", sorted(glob.glob(f"{D}/*3400109360_raster/*.fits"))),
    "r3602506433": ("stack", sorted(glob.glob(f"{D}/*3602506433_raster/*.fits"))),
}
case = sys.argv[1]
kind, files = CASES[case]
inflated = [0]
_read = gzip._GzipReader.read
def read(self, size=-1):
    out = _read(self, size)
    inflated[0] += len(out)
    return out
gzip._GzipReader.read = read

import irispy
from glue_solar.sources.loaders import iris as L
import irispy.io  # imports done before the baseline

proc = psutil.Process()
gc.collect()
u0 = usage(); rss0 = proc.memory_info().rss
peak = [rss0]; stop = threading.Event()
def sample():
    while not stop.is_set():
        peak[0] = max(peak[0], proc.memory_info().rss); time.sleep(0.001)
th = threading.Thread(target=sample, daemon=True); th.start()
t = time.perf_counter()
if kind == "image":
    datasets = [L.image_data(files[0])]
else:
    datasets = L.raster_data(files, stack=kind == "stack")
dt = time.perf_counter() - t
stop.set(); th.join()
gc.collect()
u1 = usage()
el = sum(d.size for d in datasets)
GB = 1e9
print(json.dumps({"case": case, "irispy": irispy.__version__, "n_data": len(datasets), "elements_M": round(el / 1e6, 1),
                  "load_s": round(dt, 3), "peak_rss_delta_GB": round((max(peak[0], u1["maxrss"] if u1["maxrss"] > u0["maxrss"] else 0) - rss0) / GB, 3),
                  "peak_B_per_el": round((max(peak[0], u1["maxrss"] if u1["maxrss"] > u0["maxrss"] else 0) - rss0) / el, 3),
                  "kept_rss_delta_GB": round((u1["rss"] - rss0) / GB, 3),
                  "peak_footprint_delta_GB": round((u1["max_footprint"] - u0["footprint"]) / GB, 3), "kept_footprint_delta_GB": round((u1["footprint"] - u0["footprint"]) / GB, 3),
                  "disk_read_GB": round((u1["disk_read"] - u0["disk_read"]) / GB, 3),
                  "gzip_inflated_MB": round(inflated[0] / 2**20, 1),
                  "loadavg": [round(x, 2) for x in os.getloadavg()]}))
