"""python eq.py <path> <alt flow>: alt's Data equals glue-solar's current image_data (values, mask, DN/s, Time,
exposure, world components, coords round trips, meta, units, labels, raw dtype and buffer)."""
import sys, gc
import numpy as np
from flows import flow, alt
from glue_solar.sources.loaders import iris as L
path, name = sys.argv[1], sys.argv[2]
a = L.image_data(path)
b, cube = alt(name, path)
assert type(a) is type(b) and a.label == b.label, (a.label, b.label)
assert [c.label for c in a.components] == [c.label for c in b.components]
n = 0
for ca, cb in zip(a.components, b.components):
    xa, xb = a.get_component(ca), b.get_component(cb)
    assert type(xa) is type(xb) and xa.units == xb.units, (ca.label, type(xa), type(xb), xa.units, xb.units)
    for i in range(0, a.shape[0], 25):  # every 25th frame of every component, full planes
        np.testing.assert_array_equal(a[ca, i], b[cb, i])
    n += 1
# whole-cube values and mask
sci = a.main_components[0]
np.testing.assert_array_equal(np.asarray(a[sci]), np.asarray(b[b.main_components[0]]))
np.testing.assert_array_equal(a[f"{sci.label} mask"], b[f"{sci.label} mask"])
assert a.meta.keys() == b.meta.keys(), set(a.meta) ^ set(b.meta)
for k, v in a.meta.items():
    if k == "frame_wcs_headers":
        assert len(v) == len(b.meta[k]) and all(dict(x) == dict(y) for x, y in zip(v, b.meta[k])), k
    else:
        np.testing.assert_equal(b.meta[k], v, err_msg=k)
rng = np.random.default_rng(0)
pix = [rng.uniform(0, s - 1, 1000) for s in a.shape[::-1]]
for wa, wb in zip(a.coords.pixel_to_world_values(*pix), b.coords.pixel_to_world_values(*pix)):
    np.testing.assert_array_equal(wa, wb)
ra = a.get_component(sci)._source if hasattr(a.get_component(sci), "_source") else None
rb = b.get_component(b.main_components[0])._source if ra is not None else None
info = {}
if ra is not None:
    info = {"raw_dtype": (str(ra.raw.dtype), str(rb.raw.dtype)), "raw_equal": bool(np.array_equal(ra.raw, rb.raw)),
            "scaling": ((ra.bscale, ra.bzero), (rb.bscale, rb.bzero)), "fill": (ra.fill, rb.fill),
            "alt_raw_is_cube_data": rb.raw is cube.data or np.shares_memory(rb.raw, cube.data),
            "alt_writeable": rb.raw.flags.writeable, "now_writeable": ra.raw.flags.writeable,
            "n_fill_raw": int(np.isin(np.asarray(rb.raw), (-32768, -32764)).sum())}
print({"path": path[-30:], "flow": name, "components": n, "meta_keys": len(a.meta), "cube_scaled": cube.meta["scaled"],
       "mask_type": type(cube.mask).__name__, **info, "EQUAL": True})
