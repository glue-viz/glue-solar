#!/bin/bash
# matrix.sh <reps>: warm-up then interleaved runs; JSON to sji.jsonl (rep 0 = warm-up)
W=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-207/impact
cd $W
for r in $(seq 0 $1); do
  for f in gz fits; do
    cat /Users/nabil/DATA/IRIS/*4000255147_SJI_1400*.gz data/*.fits > /dev/null
    for c in "base now" "pre now" "main now" "main bytes" "main read_files"; do
      ./run1.sh $c $f | sed "s/^{/{\"rep\": $r, /" >> sji.jsonl
    done
  done
done
