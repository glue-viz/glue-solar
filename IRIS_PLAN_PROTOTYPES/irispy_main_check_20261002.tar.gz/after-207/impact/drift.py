"""python drift.py <obs> <memmap 0|1>: calculate_wavelength_drift time, peak RSS, disk read; saves the table."""
import glob, json, sys, threading, time, warnings
import numpy as np, psutil
from mem import usage
import irispy
from irispy.io import read_files
from irispy.utils.wavelength_drift import calculate_wavelength_drift
warnings.simplefilter("ignore")
obs, memmap = sys.argv[1], bool(int(sys.argv[2]))
files = sorted(glob.glob(f"/Users/nabil/DATA/IRIS/*{obs}_raster/*.fits"))
proc = psutil.Process(); u0 = usage(); rss0 = proc.memory_info().rss; peak = [rss0]; stop = threading.Event()
def sample():
    while not stop.is_set():
        peak[0] = max(peak[0], proc.memory_info().rss); time.sleep(0.002)
threading.Thread(target=sample, daemon=True).start()
t = time.perf_counter()
raster = read_files(files, memmap=memmap)
t1 = time.perf_counter()
table = calculate_wavelength_drift(raster)
t2 = time.perf_counter(); stop.set(); u1 = usage()
tag = "main" if "dev64" in irispy.__version__ else ("pre" if "dev61" in irispy.__version__ else "base")
np.savez(f"drift_{obs}_{tag}_{int(memmap)}.npz", nuv=np.asarray(table["nuv"].value), fuv=np.asarray(table["fuv"].value))
print(json.dumps({"obs": obs, "irispy": tag, "memmap": memmap, "read_s": round(t1 - t, 2), "drift_s": round(t2 - t1, 2),
                  "peak_rss_GB": round((peak[0] - rss0) / 1e9, 2), "disk_read_GB": round((u1["disk_read"] - u0["disk_read"]) / 1e9, 2),
                  "rows": len(table), "nuv_finite": int(np.isfinite(table["nuv"]).sum()), "fuv_finite": int(np.isfinite(table["fuv"]).sum()),
                  "load1": round(__import__("os").getloadavg()[0], 1)}))
