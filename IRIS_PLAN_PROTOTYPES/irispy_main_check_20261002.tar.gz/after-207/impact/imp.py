import sys, time, json
t = time.perf_counter()
import irispy.io
t1 = time.perf_counter()
from irispy.io import read_files
cube = read_files(sys.argv[1], memmap=True)
t2 = time.perf_counter()
import irispy
print(json.dumps({"irispy": irispy.__version__[-9:], "import_s": round(t1 - t, 3), "after_import_sunpy_map": None, "read_s": round(t2 - t1, 3), "sunpy_map_after_read": "sunpy.map" in sys.modules}))
