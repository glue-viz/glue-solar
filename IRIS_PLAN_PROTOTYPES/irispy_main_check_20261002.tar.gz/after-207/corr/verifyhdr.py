import warnings, sys
from astropy.io import fits
from files import all_files
bad = 0
for f in all_files():
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        with fits.open(f) as h:
            try:
                h.verify('exception')
                status = 'ok'
            except Exception as e:
                status = f'VERIFY-ERR: {str(e)[:300]}'
                bad += 1
    msgs = sorted({f'{x.category.__name__}: {str(x.message)[:150]}' for x in w})
    if status != 'ok' or msgs:
        print(f.split('/')[-1], status, msgs)
print('files', len(all_files()), 'with verify issues', bad)
