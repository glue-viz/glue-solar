import glob
R = '/Users/nabil/DATA/IRIS'
T = '/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-main-check/irispy/irispy/data/test'
def local_inputs():
    """(label, input for read_files) pairs; raster dirs grouped as one read."""
    out = []
    for d in sorted(glob.glob(f'{R}/*_raster')):
        fs = sorted(glob.glob(f'{d}/*.fits'))
        out.append((d.split('-', 1)[1], fs))
    for f in sorted(glob.glob(f'{R}/*.fits.gz')):
        out.append((f.split('/')[-1].split('-', 1)[1], f))
    for f in sorted(glob.glob(f'{R}/*_SDO/*.fits')):
        out.append((f.split('/')[-1], f))
    return out
def test_inputs():
    out = []
    for f in sorted(glob.glob(f'{T}/**/*.fits', recursive=True)):
        if '3860258481_raster/' in f:
            continue
        out.append(('test:' + f.split('/')[-1], f))
    out.append(('test:3860258481_raster', sorted(glob.glob(f'{T}/raster/iris_l2_20140329_140938_3860258481_raster/*.fits'))))
    return out
def all_files():
    fs = []
    for _, x in local_inputs() + test_inputs():
        fs += x if isinstance(x, list) else [x]
    return fs
