"""
===============================
Open the IRIS Aligned AIA Cubes
===============================

In this example we will show how ``irispy`` handles the AIA cubes provided by
the IRIS instrument team. These cubes are aligned to the IRIS observation and
are 50" larger than the IRIS FOV.

They have the same format as IRIS SJI files, so you can read them via ``irispy``.
"""

import matplotlib.pyplot as plt
import pooch

from irispy.io import read_files

###############################################################################
# `We start with getting data from the IRIS data archive <https://www.lmsal.com/hek/hcr?cmd=view-event&event-id=ivo%3A%2F%2Fsot.lmsal.com%2FVOEvent%23VOEvent_IRIS_20250519_165924_3640107442_2025-05-19T16%3A59%3A242025-05-19T16%3A59%3A24.xml>`__.
# The full set of AIA cubes for this observation is available as an
# `SDO tarball <https://www.lmsal.com/solarsoft/irisa/data/level2_compressed/2025/05/19/20250519_165924_3640107442/iris_l2_20250519_165924_3640107442_SDO.tar.gz>`__.
# To keep the download small, we use a cutout of it that has every AIA channel but only the first five minutes.
#
# In this case, we will use ``pooch`` to keep this example self-contained
# but you can download the data manually using your browser as well.
#
# You will need to update the path to the data in the next section if you do that.

sdo_aia_file = pooch.retrieve(
    "https://github.com/LM-SAL/irispy-data/releases/download/v1/iris_l2_20250519_165924_3640107442_cutout_SDO.tar.gz",
    known_hash="db95aec5c0b3400e39d077b0e840e9280f72e2fac798e1fd15975257f3677dc4",
)

###############################################################################
# We will now open the AIA dataset. It is a compressed archive with one file per AIA
# channel, for example ``aia_l2_20250519_165924_3640107442_171.fits``, and reading it
# returns a collection of the AIA cubes keyed by channel.

aia_collection = read_files(sdo_aia_file)

###############################################################################
# Let us look at the collection of AIA cubes.

print(aia_collection)

###############################################################################
# We will then select the 304 bandpass cube.

print(aia_collection["304_THIN"])

###############################################################################
# We will now plot the AIA data in the same manner as the SJI data, with the AIA 304
# color map. ``get_animation`` lets Sphinx Gallery render the sequence as an animation.

fig = plt.figure()
animation = aia_collection["304_THIN"].plot(fig=fig, cmap="sdoaia304").get_animation()

plt.show()
