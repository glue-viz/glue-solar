"""
=============================
Make a False-Color RGB Raster
=============================

In this example, we are going to render each spectrum as one RGB pixel.

The spectrum in a pixel is treated as a spectral power distribution and
converted to a single sRGB color, so brightness is the total intensity of the
spectral window and hue is the wavelength within it. Plasma moving towards us
is blue-shifted and appears bluer, plasma moving away appears redder, and a
line with asymmetric wings picks up a color the same line would not have if
it were symmetric.

.. warning::

    This needs the optional ``colorsynth`` dependency, which you can install
    with ``pip install 'irispy-lmsal[rgb]'``.
"""

import matplotlib.pyplot as plt
import numpy as np
import pooch

import astropy.units as u

from irispy.io import read_files
from irispy.utils.rgb import asinh_velocity

###############################################################################
# `We start with getting data from the IRIS data archive <https://www.lmsal.com/hek/hcr?cmd=view-event&event-id=ivo%3A%2F%2Fsot.lmsal.com%2FVOEvent%23VOEvent_IRIS_20130902_182935_4000005156_2013-09-02T18%3A29%3A352013-09-02T18%3A29%3A35.xml>`__.
# The full observation is available as a `Level 2 raster tarball <https://www.lmsal.com/solarsoft/irisa/data/level2_compressed/2013/09/02/20130902_182935_4000005156/iris_l2_20130902_182935_4000005156_raster.tar.gz>`__.
# To keep the download small, we use a cutout of it that only has the first raster scan of the Si IV 1403, Mg II k 2796 and C II 1336 windows.
#
# In this case, we will use ``pooch`` to keep this example self-contained
# but you can download the data manually using your browser as well.
#
# You will need to update the path to the data in the next section if you do that.

raster_filename = pooch.retrieve(
    "https://github.com/LM-SAL/irispy-data/releases/download/v1/iris_l2_20130902_182935_4000005156_cutout_raster.tar.gz",
    known_hash="caec6a9d7e4d8fac70163f5f11ef992f3efd5a05b9b5fa6f67b79418bc183e1a",
)

# We will only focus on the Si IV 1403 window.
si_iv = read_files(raster_filename, spectral_windows="Si IV 1403")["Si IV 1403"][0]

###############################################################################
# By default, the metadata stored in the cube will be used: the rest
# wavelength and a mapping of +/-100 km/s to color, with the Doppler velocity
# mapped linearly.

si_iv.plotter.plot_rgb()

###############################################################################
# If you want to override the range, pass the wavelength limits, here +/-200 km/s.
# ``velocity_norm`` replaces the default linear mapping, here with
# `~irispy.utils.rgb.asinh_velocity` (``arcsinh(v / 25 km/s)``), which emphasizes
# small shifts. A square-root intensity stretch brightens faint signal, and
# wavelengths outside the limits contribute no color.

doppler = u.doppler_optical(si_iv.meta.rest_wavelength)
wavelength_min, wavelength_max = ([-200, 200] * u.km / u.s).to(u.AA, equivalencies=doppler)
si_iv.plotter.plot_rgb(
    wavelength_min=wavelength_min,
    wavelength_max=wavelength_max,
    velocity_norm=asinh_velocity,
    stretch=np.sqrt,
)

###############################################################################
# For a sit-and-stare, you can use ``coordinates="time"`` to plot time along
# the horizontal axis.
#
# This sit-and-stare is from the observation used in
# :ref:`sphx_glr_generated_gallery_analysis_05_red_blue_asymmetry.py`.
# The full observation is available as a `Level 2 raster tarball <https://www.lmsal.com/solarsoft/irisa/data/level2_compressed/2021/04/29/20210429_110908_3660259102/iris_l2_20210429_110908_3660259102_raster.tar.gz>`__.
# To keep the download small, we use a cutout of it that only has the Si IV 1403 window.

sns_filename = pooch.retrieve(
    "https://github.com/LM-SAL/irispy-data/releases/download/v1/iris_l2_20210429_110908_3660259102_cutout_raster.tar.gz",
    known_hash="3b0a5c731334bc952aad0078a2865338f1165ed78603398df115f5bde2d1d513",
)
sit_and_stare = read_files(sns_filename, spectral_windows="Si IV 1403")["Si IV 1403"][0]

sit_and_stare.plotter.plot_rgb(coordinates="time")

plt.show()
