# Configuration file for the Sphinx documentation builder.
#
# This file does only contain a selection of the most common options. For a
# full list see the documentation:
# http://www.sphinx-doc.org/en/master/config

import configparser
import datetime
import logging
import os
from pathlib import Path
from shutil import copyfile

from packaging.version import Version

DOCS_DIR = Path(__file__).resolve().parent

# -- Read the Docs Specific Configuration -------------------------------------

# This needs to be done before anything is imported
on_rtd = os.environ.get("READTHEDOCS", None) == "True"
if on_rtd:
    os.environ["SUNPY_CONFIGDIR"] = "/home/docs/"
    os.environ["HOME"] = "/home/docs/"
    os.environ["LANG"] = "C"
    os.environ["LC_ALL"] = "C"
os.environ["PARFIVE_HIDE_PROGRESS"] = "True"

# -- Project information ------------------------------------------------------

# The full version, including alpha/beta/rc tags
from irispy import __version__

_version = Version(__version__)
version = release = str(_version)
# Avoid "post" appearing in version string in rendered docs
if _version.is_postrelease:
    version = release = _version.base_version
# Avoid long githashes in rendered Sphinx docs
elif _version.is_devrelease:
    version = release = f"{_version.base_version}.dev{_version.dev}"
is_development = _version.is_devrelease
is_release = not (_version.is_prerelease or _version.is_devrelease)

project = "irispy"
author = "IRIS Instrument Team @ LMSAL"
copyright = f"{datetime.datetime.now(datetime.UTC).year}, {author}"  # NOQA: A001

# -- General configuration ----------------------------------------------------

import warnings
from astropy.utils.exceptions import AstropyDeprecationWarning
from matplotlib import MatplotlibDeprecationWarning
from sunpy.util.exceptions import SunpyDeprecationWarning, SunpyPendingDeprecationWarning

# Need to make sure that our documentation does not raise any of these
warnings.filterwarnings("error", category=SunpyDeprecationWarning)
warnings.filterwarnings("error", category=SunpyPendingDeprecationWarning)
warnings.filterwarnings("error", category=MatplotlibDeprecationWarning)
warnings.filterwarnings("error", category=AstropyDeprecationWarning)

# Suppress spurious RuntimeWarning from astropy's Angle.to_string() vectorized
# formatter (astropy/astropy#18989). It fires benignly when WCSAxes formats tick
# labels and can appear during gallery builds for examples with grid/contour plots.
warnings.filterwarnings(
    "ignore",
    message="invalid value encountered in do_format",
    category=RuntimeWarning,
)

# Wrap large function/method signatures
maximum_signature_line_length = 80

extensions = [
    "matplotlib.sphinxext.plot_directive",
    "sphinx_automodapi.automodapi",
    "sphinx_automodapi.smart_resolver",
    "sphinx_changelog",
    "sphinx_copybutton",
    "sphinx_design",
    "sphinx_gallery.gen_gallery",
    "sphinx.ext.autodoc",
    "sphinx.ext.coverage",
    "sphinx.ext.doctest",
    "sphinx.ext.intersphinx",
    "sphinx.ext.mathjax",
    "sphinx.ext.napoleon",
    "sphinx.ext.todo",
    "sphinx.ext.viewcode",
    "sphinxcontrib.bibtex",
]

# Add any paths that contain templates here, relative to this directory.
# templates_path = ["_templates"]

# Add any paths that contain static files for the docs, relative to this directory.
html_static_path = ["_static"]

# These paths are either relative to html_static_path or fully qualified paths
html_css_files = [
    "css/style.css",
]

# Register the template for the robots.txt
html_extra_path = ["robots.txt"]

# List of patterns, relative to source directory, that match files and
# directories to ignore when looking for source files.
# This pattern also affects html_static_path and html_extra_path.
exclude_patterns = ["_build", "Thumbs.db", ".DS_Store"]

# The suffix(es) of source filenames.
source_suffix = {".rst": "restructuredtext"}

# The master toctree document.
master_doc = "index"

# Treat everything in single ` as a Python reference.
default_role = "py:obj"

# Enable and configure nitpicky mode
nitpicky = True
# This is not used. See docs/nitpick-exceptions file for the actual listing.
nitpick_ignore = []
with (DOCS_DIR / "nitpick-exceptions").open() as nitpick_exceptions:
    for line in nitpick_exceptions:
        if line.strip() == "" or line.startswith("#"):
            continue
        dtype, target = line.split(None, 1)
        target = target.strip()
        nitpick_ignore.append((dtype, target))

# -- Options for intersphinx extension ----------------------------------------
intersphinx_mapping = {
    "aiapy": ("https://aiapy.readthedocs.io/en/latest/", None),
    "astropy": ("https://docs.astropy.org/en/latest/", None),
    "astroscrappy": ("https://astroscrappy.readthedocs.io/en/latest/", None),
    "fiasco": ("https://fiasco.readthedocs.io/en/latest/", None),
    "matplotlib": ("https://matplotlib.org/stable", None),
    "mpl_animators": ("https://docs.sunpy.org/projects/mpl-animators/en/latest/", None),
    "ndcube": ("https://docs.sunpy.org/projects/ndcube/en/latest/", None),
    "numpy": ("https://numpy.org/doc/stable/", None),
    "parfive": ("https://parfive.readthedocs.io/en/latest/", None),
    "python": ("https://docs.python.org/3/", None),
    "reproject": ("https://reproject.readthedocs.io/en/latest/", None),
    "scipy": ("https://docs.scipy.org/doc/scipy/reference/", None),
    "sunkit_image": ("https://docs.sunpy.org/projects/sunkit-image/en/latest/", None),
    "sunpy": ("https://docs.sunpy.org/en/latest/", None),
    "sunraster": ("https://docs.sunpy.org/projects/sunraster/en/latest/", None),
}

# -- Options for sphinxcontrib-bibtex ------------------------------------------
bibtex_bibfiles = ["references.bib"]
bibtex_default_style = "plain"
# Cite as "Pereira et al. [2013]" with :cite:t: and "[Pereira et al., 2013]" with :cite:p:
bibtex_reference_style = "author_year"

# -- Options for sphinxext-opengraph ------------------------------------------

ogp_image = "https://raw.githubusercontent.com/sunpy/sunpy-logo/master/generated/sunpy_logo_word.png"
ogp_use_first_image = True
ogp_description_length = 160
ogp_custom_meta_tags = ('<meta property="og:ignore_canonical" content="true" />',)

# -- Options for sphinx-copybutton ---------------------------------------------

# Python Repl + continuation, Bash, ipython and qtconsole + continuation, jupyter-console + continuation
copybutton_prompt_text = r">>> |\.\.\. |\$ |In \[\d*\]: | {2,5}\.\.\.: | {5,8}: "
copybutton_prompt_is_regexp = True

# -- Options for HTML output --------------------------------------------------

# The theme to use for HTML and HTML Help pages.  See the documentation for
# a list of builtin themes.
html_theme = "sunpy"
html_context = {
    "is_development": not is_release,
}
# No inheritance diagrams on the API pages, so the docs do not need graphviz.
automodapi_inheritance_diagram = False

# Add any paths that contain custom static files (such as style sheets) here,
# relative to this directory. They are copied after the builtin static files,
# so a file named "default.css" will overwrite the builtin "default.css".
# html_static_path = ["_static"]

# By default, when rendering docstrings for classes, sphinx.ext.autodoc will
# make docs with the class-level docstring and the class-method docstrings,
# but not the __init__ docstring, which often contains the parameters to
# class constructors across the scientific Python ecosystem. The option below
# will append the __init__ docstring to the class-level docstring when rendering
# the docs. For more options, see:
# https://www.sphinx-doc.org/en/master/usage/extensions/autodoc.html#confval-autoclass_content
autoclass_content = "both"
# Render callable defaults by name, e.g. ``velocity_norm=linear_velocity``, not by memory address.
autodoc_preserve_defaults = True

# -- Other options ------------------------------------------------------------

# Configuration for sphinx-gallery
from sunpy_sphinx_theme import PNG_ICON
from sphinx_gallery.sorting import ExplicitOrder

# Enable extra Sphinx-Gallery runtime and memory reporting only for the
# GitHub Actions gallery tox job. Do not enable this on Read the Docs.
profile_gallery = os.environ.get("IRISPY_GALLERY_PROFILE") == "1" and not on_rtd

sphinx_gallery_conf = {
    "backreferences_dir": str(Path("generated") / "modules"),
    "filename_pattern": "^((?!skip_).)*$",
    "examples_dirs": str(Path("..") / "examples"),
    "subsection_order": ExplicitOrder(
        [
            "../examples/how_to",
            "../examples/calibration",
            "../examples/coalign",
            "../examples/analysis",
        ]
    ),
    "within_subsection_order": "FileNameSortKey",
    "gallery_dirs": str(Path("generated") / "gallery"),
    "default_thumb_file": PNG_ICON,
    "abort_on_example_error": False,
    "plot_gallery": "True",
    "remove_config_comments": True,
    "doc_module": ("sunpy"),
    "only_warn_on_example_error": True,
    "matplotlib_animations": (True, "html5"),
    "write_computation_times": profile_gallery,
    "show_memory": profile_gallery,
    # Inherits sphinx's -j; memory profiling only works with serial execution.
    "parallel": not profile_gallery,
}


def jinja_to_rst(app, docname, source):
    """
    Render our pages as a jinja template for fancy templating goodness.

    Depending on the building format, we render the page as a jinja template.

    For the linkchecker, we bypass templating as it doesn't support jinja, but we remove
    the jinja blocks so the page is still valid for checking.
    """
    jinja_pages = ["index"]
    if app.builder.format == "html":
        if docname in jinja_pages:
            rendered = app.builder.templates.render_string(source[0], app.config.html_context)
            source[0] = rendered
    elif docname == "index":
        # This page only has a single jinja block that renders if the docs are
        # being built in development mode. We can simply  remove this block.
        for to_replace in ["{% if is_development %}", "{%else%}", "{% endif %}"]:
            source[0] = source[0].replace(to_replace, "")


# -- Database on RTD or CI ----------------------------------------------------
on_gha = os.environ.get("CI") == "true"


class _FiascoDatabaseVersionFilter(logging.Filter):
    def filter(self, record):
        message = record.getMessage()
        return not (
            record.name.startswith("fiasco")
            and "was produced with an earlier version of fiasco" in message
            and "You may need to rebuild the HDF5 database" in message
        )


def _ensure_hdf5_database(database_url, destination):
    from astropy.utils.data import download_file  # noqa: PLC0415

    import h5py  # noqa: PLC0415

    if destination.is_file():
        try:
            with h5py.File(destination, "r"):
                return
        except OSError:
            pass

    downloaded_database = download_file(database_url, cache=True, show_progress=True)
    tmp_destination = destination.with_name(f"{destination.name}.tmp")
    copyfile(downloaded_database, tmp_destination)
    try:
        with h5py.File(tmp_destination, "r"):
            pass
    except OSError:
        tmp_destination.unlink(missing_ok=True)
        raise
    tmp_destination.replace(destination)


if on_rtd or on_gha:
    fiasco_home = Path.home() / ".fiasco"
    ascii_dbase_root = fiasco_home / "chianti_dbase"
    hdf5_dbase_root = fiasco_home / "chianti_dbase.h5"
    fiasco_rc = fiasco_home / "fiascorc"

    fiasco_home.mkdir(exist_ok=True, parents=True)
    ascii_dbase_root.mkdir(exist_ok=True, parents=True)

    config = configparser.ConfigParser()
    config.add_section("database")
    config.set("database", "ascii_dbase_root", str(ascii_dbase_root))
    config.set("database", "hdf5_dbase_root", str(hdf5_dbase_root))
    with fiasco_rc.open(mode="w") as fd:
        config.write(fd)

    _ensure_hdf5_database(
        "https://github.com/LM-SAL/irispy-data/releases/download/v1/chianti_dbase_o4.h5",
        hdf5_dbase_root,
    )

try:
    import fiasco
except ImportError:
    pass
else:
    fiasco.log.addFilter(_FiascoDatabaseVersionFilter())


# -- Sphinx setup -------------------------------------------------------------


def setup(app):
    # Handles the templating for the jinja pages in our docs
    app.connect("source-read", jinja_to_rst)
