import json, sys, collections
import numpy as np
a_lab, b_lab, mm = sys.argv[1], sys.argv[2], sys.argv[3]
def load(lab):
    d = {}
    for line in open(f'dig_{lab}_{mm}.jsonl'):
        r = json.loads(line); d[(r['name'], str(r['windows']))] = r
    return d
A, B = load(a_lab), load(b_lab)
summary = collections.Counter()
for k in sorted(set(A) | set(B)):
    if k not in A or k not in B:
        print('MISSING', k, k in A, k in B); continue
    a, b = A[k], B[k]
    for f in ('err', 'warnings', 'logs'):
        if a[f] != b[f]:
            print(k[0][:50], k[1], f, '\n   A:', a[f], '\n   B:', b[f])
    if set(a['cubes']) != set(b['cubes']):
        print(k[0][:50], 'cube keys differ', sorted(a['cubes'])[:3], sorted(b['cubes'])[:3])
    for ck in sorted(set(a['cubes']) & set(b['cubes'])):
        ca, cb = a['cubes'][ck], b['cubes'][ck]
        for f in sorted(set(ca) | set(cb)):
            va, vb = ca.get(f), cb.get(f)
            if va == vb:
                continue
            summary[f] += 1
            if f == 'wcs':
                try:
                    dm = max(float(np.nanmax(np.abs(np.array(x) - np.array(y)))) for x, y in zip(va, vb))
                except Exception as e:
                    dm = repr(e)
                print(k[0][:50], ck[-40:], 'wcs maxdiff', dm)
            elif f == 'meta':
                ks = sorted(kk for kk in set(va) | set(vb) if va.get(kk) != vb.get(kk))
                print(k[0][:50], ck[-40:], 'meta keys differ:', ks)
            elif f == 'frame0':
                ks = sorted(kk for kk in set(va) | set(vb) if va.get(kk) != vb.get(kk))
                print(k[0][:50], ck[-40:], 'frame0 differs:', [(kk, va.get(kk), vb.get(kk)) for kk in ks])
            elif f in ('fw0', 'fwN'):
                diffs = []
                for i, (x, y) in enumerate(zip(va, vb)):
                    if x != y:
                        if i < 2:
                            diffs.append((i, float(np.max(np.abs(np.array(x) - np.array(y))))))
                        elif i == 3:
                            diffs.append((i, (np.array(x) - np.array(y)).tolist()))
                        elif i == 4:
                            xa, ya = x.split('\n') if '\n' in x else [x[j:j+80] for j in range(0, len(x), 80)], y.split('\n') if '\n' in y else [y[j:j+80] for j in range(0, len(y), 80)]
                            diffs.append((i, [(p, q) for p, q in zip(xa, ya) if p != q][:6]))
                        else:
                            diffs.append((i, x, y))
                print(k[0][:50], ck[-40:], f, diffs)
            else:
                print(k[0][:50], ck[-40:], f, str(va)[:80], '|', str(vb)[:80])
print('SUMMARY field->ncubes differing:', dict(summary), 'entries', len(A), len(B))
