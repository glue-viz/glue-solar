import copy, warnings, sys
import numpy as np
import matplotlib; matplotlib.use('agg')
import matplotlib.pyplot as plt
import astropy.units as u
import irispy
from irispy.io import read_files
warnings.simplefilter('ignore')
T = '/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-main-check/irispy/irispy/data/test/'
print('irispy', irispy.__version__)
def mt(m):
    return None if m is None else f'{type(m).__name__}[{int(np.count_nonzero(np.asarray(m)))}]'
def op(name, f):
    try:
        r = f()
        print(f'  {name:32s} ok   {r}')
    except Exception as e:
        print(f'  {name:32s} FAIL {type(e).__name__}: {str(e)[:120]}')
    plt.close('all')
for mm in (True, False):
    print('memmap', mm)
    sji = read_files(T + 'bursts/iris_l2_20130902_163935_4000255147_SJI_1400_t000_test.fits', memmap=mm)
    op('sji mask', lambda: mt(sji.mask))
    op('sji[0:2] slice', lambda: mt(sji[0:2].mask))
    op('sji[0] slice', lambda: mt(sji[0].mask))
    op('sji rebin (1,2,2)', lambda: mt(sji.rebin((1, 2, 2)).mask))
    op('sji[0].plot()', lambda: type(sji[0].plot()).__name__)
    op('sji.plot()', lambda: type(sji.plot()).__name__)
    op('sji.to_maps(0)', lambda: type(sji.to_maps(0)).__name__)
    op('sji + 1 DN', lambda: mt((sji + 1 * sji.unit).mask))
    op('deepcopy sji', lambda: mt(copy.deepcopy(sji).mask))
    def dust():
        c = copy.deepcopy(sji[0:3])
        before = int(np.count_nonzero(np.asarray(c.mask)))
        c.apply_dust_mask()
        mid = int(np.count_nonzero(np.asarray(c.mask)))
        c.apply_dust_mask(undo=True)
        return f'mask {before} -> dust {mid} of {c.data.size} -> undo {int(np.count_nonzero(np.asarray(c.mask)))} ({type(c.mask).__name__})'
    op('apply_dust_mask / undo', dust)
    r = read_files(T + 'wavelength_drift/iris_l2_20140708_114109_3824262996_raster_t000_r00000_wavelength_drift_test.fits', memmap=mm)
    seq = r['Si IV 1394']
    c = seq[0]
    op('raster mask', lambda: mt(c.mask))
    op('raster[0:2] slice', lambda: mt(c[0:2].mask))
    op('raster rebin (1,1,2)', lambda: mt(c.rebin((1, 1, 2)).mask) if c.data.shape[2] % 2 == 0 else mt(c[..., :-1].rebin((1, 1, 2)).mask))
    op('raster[:, 10].plot()', lambda: type(c[:, 10].plot()).__name__)
    op('seq.index_as_cube[0:2]', lambda: mt(seq.index_as_cube[0:2][0].mask))
    op('seq.plot()', lambda: type(seq.plot()).__name__)
    op('raster * 2', lambda: mt((c * 2).mask))
