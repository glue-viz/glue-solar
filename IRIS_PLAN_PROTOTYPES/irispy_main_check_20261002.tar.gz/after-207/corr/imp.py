import sys, warnings
import irispy, irispy.io, irispy.sji, irispy.spectrograph, irispy.utils
print('after import irispy+io+sji+utils: sunpy.map loaded =', 'sunpy.map' in sys.modules)
from irispy.io import read_files
T = '/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-main-check/irispy/irispy/data/test/'
c = read_files(T + 'sns/iris_l2_20210905_001833_3620258102_SJI_1330_t000_test.fits')
r = read_files(T + 'sns/iris_l2_20210905_001833_3620258102_raster_t000_r00000_test.fits', memmap=True)
print('after reading SJI + raster: sunpy.map loaded =', 'sunpy.map' in sys.modules)
