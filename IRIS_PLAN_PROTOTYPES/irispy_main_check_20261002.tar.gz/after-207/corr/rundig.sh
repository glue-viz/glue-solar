#!/bin/bash
cd /private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-207/corr
for spec in "test False" "local True" "local False"; do
  set -- $spec
  for v in v0ee:/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-main-check/irispy v578:/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-207/irispy-57813b8 v091:; do
    l=${v%%:*}; p=${v#*:}
    /usr/bin/time -l env HOME="$(mktemp -d)" PYTHONPATH=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-207/corr:$p MPLBACKEND=agg PYTHONDONTWRITEBYTECODE=1 /Users/nabil/mamba/envs/iris-plan/bin/python -B digest.py $l $2 $1 > log_${l}_$2_$1.txt 2>&1
    echo "$l $1 $2 exit $?"
  done
done
