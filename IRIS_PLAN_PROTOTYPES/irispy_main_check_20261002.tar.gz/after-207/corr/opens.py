import collections, glob, warnings
import numpy as np
from astropy.io import fits
from astropy.io.fits import HDUList
warnings.simplefilter('ignore')
calls = collections.Counter(); ver = collections.Counter()
orig_open = HDUList.fromfile.__func__
def fromfile(cls, fileobj, *a, **k):
    calls[str(fileobj)] += 1
    return orig_open(cls, fileobj, *a, **k)
HDUList.fromfile = classmethod(fromfile)
orig_verify = HDUList.verify
def verify(self, *a, **k):
    ver['verify'] += 1
    return orig_verify(self, *a, **k)
HDUList.verify = verify
from irispy.io import read_files
from irispy.io.spectrograph import read_spectrograph_lvl2
R = sorted(glob.glob('/Users/nabil/DATA/IRIS/*3602506433_raster/*.fits'))
for label, fn in (('read_spectrograph_lvl2', lambda m: read_spectrograph_lvl2(R, memmap=m)), ('read_files', lambda m: read_files(R, memmap=m))):
    for m in (True, False):
        calls.clear(); ver.clear()
        fn(m)
        per = collections.Counter(calls.values())
        print(f'{label:24s} memmap={m!s:5s} files={len(R)} opens={sum(calls.values())} opens-per-file={dict(per)} HDUList.verify calls={ver["verify"]}')
