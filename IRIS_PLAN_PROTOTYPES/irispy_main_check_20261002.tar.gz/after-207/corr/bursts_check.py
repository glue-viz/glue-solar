import copy, glob, warnings
import numpy as np
from astropy.io import fits
from astropy.table import Table
from irispy.io.sji import read_sji_lvl2
from irispy.utils.bursts import find_sji_bursts
warnings.simplefilter('ignore')
T = '/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-main-check/irispy/irispy/data/test/'
f = glob.glob('/Users/nabil/DATA/IRIS/*4000255147_SJI_1400_t000.fits.gz')[0]
summary = Table.read(T + 'bursts/iris_sji_burst_check_4000255147_summary.ecsv')[:50]
cube = read_sji_lvl2(f)[0:50]
with fits.open(f) as h:
    scaled = h[0].data[:50].astype(np.float32)  # astropy-scaled DN
print('frames', cube.data.shape, '-199 pixels in 50 frames:', int(np.sum(scaled == -199)), 'per frame nonzero at', np.flatnonzero(np.sum(scaled == -199, axis=(1, 2))).tolist())
def run(c):
    labels, events = find_sji_bursts(c)
    npix = np.count_nonzero(labels.data, axis=(1, 2))
    nev = np.bincount(events['frame'], minlength=50)
    thr = {int(fr): float(t.value) for fr, t in zip(events['frame'], events['threshold'])}
    return labels, npix, nev, thr
lab, npix, nev, thr = run(cube)
d = npix - np.asarray(summary['npix'])
print('irispy (both fills masked): nevents==IDL', bool(np.array_equal(nev, summary['nevents'])), '| npix diff frames', np.flatnonzero(d).tolist(), 'by', d[d != 0].tolist())
print('   thresholds 0/37/49:', [round(thr[i], 4) for i in (0, 37, 49)])
added = ([0, 37, 49], [291, 290, 52], [93, 86, 126])
print('   added pixels labelled', bool(lab.data[added].all()), 'values', cube.data[added].tolist())
# IDL-like: -199 kept as data, only -200 masked
idl = copy.deepcopy(cube)
idl.data[...] = np.where(scaled == -200, np.nan, scaled)
idl.mask = scaled == -200
lab2, npix2, nev2, thr2 = run(idl)
d2 = npix2 - np.asarray(summary['npix'])
print('-199 kept as data (IDL-like): nevents==IDL', bool(np.array_equal(nev2, summary['nevents'])), '| npix==IDL', bool(np.array_equal(npix2, summary['npix'])), 'diff frames', np.flatnonzero(d2).tolist())
print('   thresholds 0/37/49:', [round(thr2[i], 4) for i in (0, 37, 49)])
print('   frames whose threshold changes:', sorted(i for i in thr if i in thr2 and abs(thr[i] - thr2[i]) > 1e-9)[:60])
dd = np.array([thr[i] - thr2[i] for i in sorted(thr) if i in thr2])
print('threshold change (both masked - IDL-like) over', dd.size, 'frames: min %.4f max %.4f DN; all lower: %s' % (dd.min(), dd.max(), bool((dd < 0).all())))
