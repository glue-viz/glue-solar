import json, sys, numbers
import numpy as np
from irispy.io import read_files
from files import local_inputs, test_inputs
lab = sys.argv[1]
out = {}
for name, inp in local_inputs() + test_inputs():
    if isinstance(inp, list) or 'fexxi' in name or '_raster' in name:
        continue
    c = read_files(inp, memmap=True)
    hd = c.meta['frame_wcs_headers']
    rows = []
    for h in hd:
        rows.append({k: (['num', float(v), type(v).__name__] if isinstance(v, numbers.Number) else ['str', str(v), type(v).__name__]) for k, v in h.items()})
    out[name] = rows
    # to_maps check on frames 0 and -1
    m = c[:2].to_maps()
    out[name + '#maps'] = [{k: str(v) for k, v in mm.meta.items()} | {'_wcs': mm.wcs.to_header_string(), '_obs': str(mm.observer_coordinate), '_date': mm.date.isot, '_wl': str(mm.wavelength), '_exp': str(mm.exposure_time), '_unit': str(mm.unit), '_data': float(np.nansum(np.asarray(mm.data, dtype=float)))} for mm in m]
json.dump(out, open(f'frames_{lab}.json', 'w'))
print(lab, len(out))
