"""Item 3: remove_dust / radiometric_calibration on raw memmap input and on scaled input."""
import hashlib, warnings, sys
import numpy as np
import irispy
from irispy.io import read_files
from irispy.utils.dust import remove_dust
from irispy.utils.spectrograph import radiometric_calibration
T = '/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-main-check/irispy/irispy/data/test/'
g = lambda f: f if f.startswith('/') else T + f
import glob
R = '/Users/nabil/DATA/IRIS/'
np.set_printoptions(threshold=sys.maxsize, floatmode='unique')
def h(a):
    return None if a is None else hashlib.blake2b(np.ascontiguousarray(np.asarray(a)).tobytes(), digest_size=8).hexdigest()
print('irispy', irispy.__version__)
warnings.simplefilter('ignore')
sjis = ['sns/iris_l2_20210905_001833_3620258102_SJI_1330_t000_test.fits',
        'bursts/iris_l2_20130902_163935_4000255147_SJI_1400_t000_test.fits'] + sorted(glob.glob(R + '*SJI*.fits.gz'))
for f in sjis:
    raw = read_files(g(f), memmap=True)
    try:
        out = remove_dust(raw); print('remove_dust memmap', f.split('/')[-1][-40:], 'NO RAISE dtype', out.data.dtype, 'sample', np.asarray(out.data).ravel()[:3])
    except ValueError as e:
        print('remove_dust memmap', f.split('/')[-1][-40:], 'ValueError:', e)
    try:
        out = raw.remove_dust(); print('cube.remove_dust memmap NO RAISE')
    except ValueError as e:
        print('cube.remove_dust memmap ValueError')
    sc = read_files(g(f), memmap=False)[:12]
    rd = np.asarray(read_files(g(f), memmap=True).data[:12])
    n199 = int(np.sum(rd == -32764)) if rd.dtype.kind == 'i' else int(np.sum(rd == -199))
    nbetween = int(np.sum((rd > -32768) & (rd < -32764))) if rd.dtype.kind == 'i' else int(np.sum((rd > -200) & (rd < -199)))
    out = remove_dust(sc)
    print('   n(-200,-199) in first 12 frames:', nbetween)
    print('remove_dust scaled', f.split('/')[-1][-40:], 'n_raw-199=', n199, 'data', h(out.data), 'mask', h(out.mask), 'unit', out.unit)
for f in ['wavelength_drift/iris_l2_20140708_114109_3824262996_raster_t000_r00000_wavelength_drift_test.fits',
          'sns/iris_l2_20210905_001833_3620258102_raster_t000_r00000_test.fits']:
    rc_raw = read_files(g(f), memmap=True)
    w = list(rc_raw.keys())[0]
    for seq in (False, True):
        try:
            out = radiometric_calibration(rc_raw[w] if seq else rc_raw[w][0])
            o = out[0] if seq else out
            print('radcal memmap', f[:20], w, 'seq' if seq else 'cube', 'NO RAISE sample', np.nanmax(np.asarray(o.data, dtype=float)))
        except ValueError as e:
            print('radcal memmap', f[:20], w, 'seq' if seq else 'cube', 'ValueError:', e)
    rc = read_files(g(f), memmap=False)
    for w in rc.keys():
        out = radiometric_calibration(rc[w])
        o = out[0]
        print('radcal scaled', f[:20], w, 'data', h(o.data), 'unc', h(None if o.uncertainty is None else o.uncertainty.array), 'mask', h(o.mask), 'unit', o.unit)
