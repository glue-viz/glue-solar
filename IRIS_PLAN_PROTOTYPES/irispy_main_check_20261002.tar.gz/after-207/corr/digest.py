"""Digest every cube irispy.io.read_files returns: data, mask, meta, WCS, warnings."""
import hashlib, json, logging, os, sys, warnings, itertools, io
import numpy as np
import irispy
from irispy.io import read_files
from astropy.io import fits
from files import local_inputs, test_inputs

np.set_printoptions(threshold=sys.maxsize, floatmode='unique')
label, memmap, which = sys.argv[1], sys.argv[2] == 'True', sys.argv[3]
only = sys.argv[4] if len(sys.argv) > 4 else None
out = open(f'dig_{label}_{memmap}.jsonl', 'a')
BIG = 1.0e9

def hsh(arr, slab=16):
    b = hashlib.blake2b(digest_size=12)
    n = arr.shape[0]
    for i in range(0, n, slab):
        b.update(np.ascontiguousarray(np.asarray(arr[i:i + slab])).tobytes())
    return b.hexdigest()

def msum(arr, slab=16):
    return int(sum(np.count_nonzero(np.asarray(arr[i:i + slab])) for i in range(0, arr.shape[0], slab)))

def hval(v):
    return hashlib.blake2b(repr(v).encode(), digest_size=10).hexdigest()

def wcs_points(cube):
    shp = cube.data.shape
    pts = list(itertools.product(*[(0, n - 1) for n in shp])) + [tuple((n - 1) / 2 for n in shp)]
    pix = np.array(pts, dtype=float)[:, ::-1].T  # wcs order
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        w = cube.wcs.low_level_wcs.pixel_to_world_values(*pix)
    return [np.asarray(x, dtype=float).tolist() for x in (w if isinstance(w, (list, tuple)) else [w])]

def meta_digest(meta):
    d = {}
    for k in sorted(meta.keys()):
        if k == 'frame_wcs_headers':
            continue
        v = meta[k]
        d[k] = hval(v)
    fh = getattr(meta, 'fits_header', None)
    if fh is not None:
        d['__fits_header__'] = hval(fh.tostring())
    return d

def sji_extra(cube):
    hd = cube.meta.get('frame_wcs_headers')
    if hd is None:
        return {}
    from astropy.wcs import WCS
    res = {'nframes': len(hd), 'frame0': {k: repr(v) for k, v in sorted(hd[0].items())},
           'frames_hash': hval([sorted((k, repr(v)) for k, v in h.items()) for h in hd])}
    sh = cube.data.shape[1:]
    pts = [(0, 0), (sh[1] - 1, 0), (0, sh[0] - 1), (sh[1] - 1, sh[0] - 1), ((sh[1] - 1) / 2, (sh[0] - 1) / 2)]
    for tag, i in (('fw0', 0), ('fwN', len(hd) - 1)):
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            w = WCS(hd[i])
            c = w.pixel_to_world(*np.array(pts, dtype=float).T)
        res[tag] = [c.Tx.arcsec.tolist(), c.Ty.arcsec.tolist(), str(c.obstime.isot),
                    [c.observer.lon.deg, c.observer.lat.deg, c.observer.radius.m], w.to_header_string()]
    return res

def describe(cube):
    rec = {'type': type(cube).__name__, 'shape': list(cube.data.shape), 'dtype': str(cube.data.dtype),
           'data': hsh(cube.data), 'unit': str(cube.unit),
           'mask_type': type(cube.mask).__name__ if cube.mask is not None else None}
    if cube.mask is not None:
        m = cube.mask
        rec['mask'] = hsh(np.asarray(m) if np.ndim(m) == 0 else m.astype(bool) if hasattr(m, 'astype') else m)
        rec['mask_sum'] = msum(m)
        rec['mask_dtype'] = str(m.dtype)
    rec['meta'] = meta_digest(cube.meta)
    rec['wcs'] = wcs_points(cube)
    rec['phys'] = list(cube.wcs.world_axis_physical_types)
    rec.update(sji_extra(cube) if hasattr(cube, 'fits_wcs') else {})
    return rec

class H(logging.Handler):
    def __init__(self):
        super().__init__(); self.msgs = []
    def emit(self, r):
        self.msgs.append(f'LOG {r.levelname} {r.name}: {r.getMessage()[:200]}')

def run(name, inp, windows=None):
    h = H(); logging.getLogger().addHandler(h)
    for lg in ('irispy', 'astropy', 'sunpy'):
        logging.getLogger(lg).addHandler(h)
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        try:
            res = read_files(inp, memmap=memmap, spectral_windows=windows)
            err = None
        except Exception as e:  # record, compare
            res, err = {}, f'{type(e).__name__}: {e}'[:300]
        warns = sorted({f'{x.category.__name__}: {str(x.message)[:200]}' for x in w})
    for lg in ('', 'irispy', 'astropy', 'sunpy'):
        logging.getLogger(lg or None).removeHandler(h)
    cubes = {}
    if type(res).__name__ in ('RasterCollection', 'SJICube', 'AIACube') or not isinstance(res, dict):
        res = {'_': res}
    for key, val in res.items():
        if hasattr(val, 'keys'):  # RasterCollection
            for win in val.keys():
                for i, c in enumerate(val[win]):
                    cubes[f'{key}|{win}|{i}'] = describe(c)
        else:
            cubes[key] = describe(val)
    rec = {'name': name, 'windows': windows, 'err': err, 'warnings': warns, 'logs': sorted(set(h.msgs)), 'cubes': cubes}
    out.write(json.dumps(rec) + '\n'); out.flush()
    del res

print('irispy', irispy.__version__, irispy.__file__, file=sys.stderr)
inputs = local_inputs() if which == 'local' else test_inputs()
for name, inp in inputs:
    if only and only not in name:
        continue
    files = inp if isinstance(inp, list) else [inp]
    size = sum(os.path.getsize(f) for f in files)
    if not memmap and size > BIG and files[0].endswith('.fits'):
        with fits.open(files[0]) as hl:
            wins = [hl[0].header[f'TDESC{i}'] for i in range(1, hl[0].header['NWIN'] + 1)]
        for win in wins:
            run(name, inp, [win])
    else:
        run(name, inp)
    print('done', name, file=sys.stderr)
