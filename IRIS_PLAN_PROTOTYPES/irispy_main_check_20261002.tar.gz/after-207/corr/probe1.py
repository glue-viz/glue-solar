import numpy as np
from astropy.io import fits
from files import test_inputs, local_inputs
for name, inp in test_inputs():
    fs = inp if isinstance(inp, list) else [inp]
    for f in fs[:1]:
        with fits.open(f, do_not_scale_image_data=True) as h:
            for i, hdu in enumerate(h):
                if hdu.header.get('NAXIS', 0) == 3:
                    d = hdu.data
                    bs, bz = hdu.header.get('BSCALE'), hdu.header.get('BZERO')
                    vals = d.astype(float) * (bs or 1) + (bz or 0)
                    between = int(np.sum((vals > -200) & (vals < -199)))
                    print(name[-45:], i, d.dtype, bs, bz, 'n-200', int(np.sum(vals == -200)), 'n-199', int(np.sum(vals == -199)), 'n(-200,-199)', between, 'nnan', int(np.isnan(vals).sum()))
                    break
