import glob, collections
from astropy.io import fits
files = sorted(glob.glob('/Users/nabil/DATA/IRIS/*/*.fits') + glob.glob('/Users/nabil/DATA/IRIS/*.fits.gz'))
for f in files:
    if '3602506433' in f and not f.endswith('r00000.fits'):
        continue
    with fits.open(f) as h:
        combos = collections.Counter()
        for i, hdu in enumerate(h):
            hd = hdu.header
            if hd.get('NAXIS', 0) >= 2 and not isinstance(hdu, (fits.BinTableHDU, fits.TableHDU)) and 'XTENSION' not in hd or hd.get('XTENSION') == 'IMAGE':
                if hd.get('NAXIS',0) >= 2:
                    combos[(hd['BITPIX'], hd.get('BSCALE'), hd.get('BZERO'), hd.get('NAXIS'))] += 1
        print(f.split('/')[-1][-60:], dict(combos), 'INSTRUME=', h[0].header.get('INSTRUME'))
