"""Item 4: planted -199 in calculate_dust_mask, calculate_mg_features and the wobble trim."""
import copy, sys, warnings
import numpy as np
import irispy
from irispy.utils import calculate_dust_mask
print('irispy', irispy.__version__)
for fill in (-200, -199, -199.5):
    for shape in ((7, 7), (2, 7, 7)):
        d = np.full(shape, 10.0); d[..., 3, 3] = fill
        print(f'dust_mask fill={fill} shape={shape} flagged={int(calculate_dust_mask(d).sum())}')
# mg_features
try:
    from irispy.utils.mg_features import calculate_mg_features
    from irispy.io import read_files
    from irispy.data.test import get_test_filepath
    raster = read_files(get_test_filepath('mg_features/iris_l2_20130902_182935_4000005156_raster_t000_r00000_mg_features_test.fits'))
    base = raster['Mg II k 2796'][0]
    for fill in (-200, -199):
        cube = copy.deepcopy(base)
        cube.data[1, 300, 10] = fill
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            v = calculate_mg_features(cube, lines=('k',))['k3_velocity'].data
        print(f'mg_features fill={fill} k3 at planted={v[1, 300]} neighbour={v[1, 299]}')
except ImportError as e:
    print('mg_features n/a', e)
# wobble trim
try:
    import matplotlib; matplotlib.use('agg')
    import matplotlib.pyplot as plt
    from astropy.io import fits
    from irispy.utils.wobble import generate_wobble_movie
    import tempfile, pathlib, inspect
    sjif = get_test_filepath('sns/iris_l2_20210905_001833_3620258102_SJI_2832_t000_test.fits')
    for fill in (-200, -199):
        header = fits.getheader(sjif); header['CUNIT3'] = 's'; header['CDELT3'] = 180
        data = np.full((3, 8, 8), fill, dtype=float); data[:, 1:-1, 1:-1] = np.arange(108).reshape(3, 6, 6) + 1
        tmp = pathlib.Path(tempfile.mkdtemp()) / 'sji.fits'
        fits.PrimaryHDU(data=data, header=header).writeto(tmp)
        try:
            generate_wobble_movie(tmp, outdir=tmp.parent, trim=True)
        except Exception as e:
            print('wobble err', type(e).__name__, e)
        img = np.asarray(plt.gcf().axes[0].images[0].get_array())
        drawn = {'img': img}
        img = drawn.get('img')
        print(f'wobble fill={fill} trimmed_shape={None if img is None else img.shape} min={None if img is None else float(np.min(img))}')
        plt.close('all')
except ImportError as e:
    print('wobble n/a', e)
