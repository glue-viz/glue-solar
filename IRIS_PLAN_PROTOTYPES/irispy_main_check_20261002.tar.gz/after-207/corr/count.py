import json, collections
import numpy as np
from astropy.io import fits
from files import local_inputs, test_inputs
res = {}
for name, inp in local_inputs() + test_inputs():
    fs = inp if isinstance(inp, list) else [inp]
    c = collections.Counter()
    for f in fs:
        with fits.open(f, do_not_scale_image_data=True, memmap=True) as h:
            for hdu in h:
                if hdu.header.get('NAXIS', 0) != 3 or 'TTYPE1' in hdu.header:
                    continue
                d = hdu.data
                bs, bz = hdu.header.get('BSCALE', 1), hdu.header.get('BZERO', 0)
                for i in range(0, d.shape[0], 64):
                    s = np.asarray(d[i:i + 64])
                    if s.dtype.kind == 'i':
                        c['raw-200'] += int(np.count_nonzero(s == round((-200 - bz) / bs)))
                        c['raw-199'] += int(np.count_nonzero(s == round((-199 - bz) / bs)))
                        lo, hi = sorted([(-200 - bz) / bs, (-199 - bz) / bs])
                        c['between'] += int(np.count_nonzero((s > lo) & (s < hi)))
                        c['below-200'] += int(np.count_nonzero(s * bs + bz < -200))
                    else:
                        c['raw-200'] += int(np.count_nonzero(s == -200)); c['raw-199'] += int(np.count_nonzero(s == -199))
                        c['between'] += int(np.count_nonzero((s > -200) & (s < -199)))
                        c['below-200'] += int(np.count_nonzero(s < -200))
                        c['nan'] += int(np.count_nonzero(np.isnan(s)))
    res[name] = dict(c)
    print(name[-55:], dict(c), flush=True)
json.dump(res, open('counts.json', 'w'))
