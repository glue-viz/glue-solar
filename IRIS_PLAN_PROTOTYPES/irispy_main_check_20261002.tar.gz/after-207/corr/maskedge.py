import glob, warnings, tempfile, os
import numpy as np
import dask.array as da
from astropy.io import fits
from irispy.io._mask import _memmap_fill_mask
from irispy.io.spectrograph import read_spectrograph_lvl2
warnings.simplefilter('ignore')
def mk(arr, hdr):
    return np.asarray(_memmap_fill_mask(arr, hdr).compute())
# 1. raw codes
iris = np.array([[[-32768, -32764, -32767, -32766, -32765, 0, 32767]]], dtype='>i2')
print('IRIS 0.25/7992      ', mk(iris, {'BSCALE': 0.25, 'BZERO': 7992}).astype(int).ravel().tolist(), '(expect 1,1,0,0,0,0,0)')
aia = np.array([[[-200, -199, -198, -201, 0]]], dtype='>i2')
print('AIA 1.0/0           ', mk(aia, {'BSCALE': 1.0, 'BZERO': 0}).astype(int).ravel().tolist(), '(expect 1,1,0,0,0)')
print('no BSCALE int16     ', mk(aia, {}).astype(int).ravel().tolist(), '(expect 1,1,0,0,0)')
# float memmap, big-endian, from disk
fn = os.path.join(tempfile.mkdtemp(), 'f.fits')
fl = np.array([[[-200, -199, np.nan, -199.5, np.inf, -200.0001, 5]]], dtype='>f4')
fits.PrimaryHDU(fl).writeto(fn)
with fits.open(fn, memmap=True, do_not_scale_image_data=True) as h:
    d = h[0].data
    print('float32 memmap      ', type(d).__name__, d.dtype, mk(d, h[0].header).astype(int).ravel().tolist(), '(expect 1,1,0,0,0,0,0)')
    print('   isin reference   ', np.isin(d, [-200., -199.]).astype(int).ravel().tolist())
# uint16 convention: BZERO=32768 -> raw codes out of int16 range
u = np.array([[[-32768, 0, 32767, -200]]], dtype='>i2')
try:
    print('BZERO=32768 int16   ', mk(u, {'BSCALE': 1, 'BZERO': 32768}).astype(int).ravel().tolist(), '(expect all 0; -200 unrepresentable)')
except Exception as e:
    print('BZERO=32768 int16    RAISES', type(e).__name__, e)
# non-integral raw code
try:
    print('BSCALE=0.3 int16    ', mk(np.array([[[-667, -666, -663, 0]]], dtype='>i2'), {'BSCALE': 0.3, 'BZERO': 0}).astype(int).ravel().tolist(), '(expect all 0; isin', np.isin([-667, -666, -663, 0], (np.array([-200, -199]) / 0.3)).astype(int).tolist(), ')')
except Exception as e:
    print('BSCALE=0.3 RAISES', e)
# zero-length / one-frame
print('zero frames         ', _memmap_fill_mask(np.zeros((0, 3, 3), dtype='>i2'), {}).compute().shape)
# 2. negative-step raster: mask follows the flip
R = sorted(glob.glob('/Users/nabil/DATA/IRIS/*3400109360_raster/*.fits'))
with fits.open(R[0]) as h:
    print('3400109360 STEPS_AV', h[0].header['STEPS_AV'])
a = read_spectrograph_lvl2(R, memmap=True)
b = read_spectrograph_lvl2(R, memmap=True, revert_v34=True)
e = read_spectrograph_lvl2(R[:2], memmap=False)
ok = True
for w in a.keys():
    for j, (ca, cb) in enumerate(zip(a[w], b[w])):
        for s in (0, ca.data.shape[0] // 2, -1):
            raw = np.asarray(ca.data[s])
            m = np.asarray(ca.mask[s].compute())
            ok &= np.array_equal(m, (raw == -32768) | (raw == -32764))
            ok &= np.array_equal(m, np.asarray(cb.mask[-1 - s if s >= 0 else 0].compute()))
            ok &= np.array_equal(np.asarray(ca.data[s]), np.asarray(cb.data[-1 - s if s >= 0 else 0]))
            if j < 2:
                ok &= np.array_equal(m, np.asarray(e[w][j].mask[s]))
print('3400109360 flipped mask == flipped raw codes == revert_v34 mirror == eager mask:', bool(ok))
