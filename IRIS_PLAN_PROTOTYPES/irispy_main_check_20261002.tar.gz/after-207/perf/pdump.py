"""python pdump.py OUT: cProfile of read_files on 3602506433's 99 files (after a warm-up read), stats dumped to OUT."""
import cProfile, glob, sys
from irispy.io import read_files
p = sorted(glob.glob("/Users/nabil/DATA/IRIS/*3602506433_raster/*.fits"))
read_files(p[:3], memmap=True)
pr = cProfile.Profile()
pr.enable()
read_files(p, memmap=True, uncertainty=False)
pr.disable()
pr.dump_stats(sys.argv[1])
