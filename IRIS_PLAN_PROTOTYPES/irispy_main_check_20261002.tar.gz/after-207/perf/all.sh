#!/bin/sh
# round 0 warms the page cache (dropped); variants interleaved within each case, order rotated per round
cd "$(dirname "$0")"
for r in 0 1 2 3 4 5; do
  case $((r % 3)) in 0) VS="091 578 main" ;; 1) VS="578 main 091" ;; 2) VS="main 091 578" ;; esac
  for lc in irispy:r4000255147 irispy:r3824262996 irispy:r3400109360 irispy:r3602506433 irispy:sji irispy:sjigz irispy:aia \
            glue:r4000255147 glue:r3824262996 glue:r3400109360 glue:r3602506433 glue:sji glue:sjigz glue:aia \
            glue:r4000255147_stack glue:r3602506433_stack; do
    for v in $VS; do ./r.sh $v ${lc%%:*} ${lc#*:} | sed "s/^{/{\"round\": $r, /" >> time.jsonl; done
  done
done
echo done > all.done
