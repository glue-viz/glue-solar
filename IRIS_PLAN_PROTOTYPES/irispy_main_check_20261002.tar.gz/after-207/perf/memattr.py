"""python memattr.py VARIANT: read_files(3602506433's 99 files, memmap=True) under tracemalloc: Python memory kept after
gc, by top-level package of the allocating frame, and by the irispy line on the stack."""
import collections, gc, glob, json, sys, tracemalloc

from irispy.io import read_files

paths = sorted(glob.glob("/Users/nabil/DATA/IRIS/*3602506433_raster/*.fits"))
gc.collect()
tracemalloc.start(40)
out = read_files(paths, memmap=True, uncertainty=False)
gc.collect()
snap = tracemalloc.take_snapshot()
KB = 1024
pkg, line = collections.Counter(), collections.Counter()
for s in snap.statistics("traceback"):
    fr = s.traceback[-1].filename  # allocation site (frames run oldest to newest)
    pkg[fr.split("site-packages/")[-1].split("/")[0] if "site-packages/" in fr else
        "irispy" if "/irispy/" in fr else fr.rsplit("/", 1)[-1]] += s.size
    ir = [f for f in s.traceback if "/irispy/" in f.filename]  # innermost irispy frame
    line[f"{ir[-1].filename.split('/irispy/')[-1]}:{ir[-1].lineno}" if ir else "-"] += s.size
print(json.dumps({"v": sys.argv[1], "kept_MB": round(tracemalloc.get_traced_memory()[0] / 2**20, 2),
                  "by_pkg_KB": {k: round(v / KB) for k, v in pkg.most_common(8)},
                  "by_irispy_line_KB": {k: round(v / KB) for k, v in line.most_common(8)}}))
