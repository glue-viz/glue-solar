"""python acc.py VARIANT LAYER: wall time inside HDUList.verify and _memmap_fill_mask (perf_counter, no profiler) during
the 99-file read (irispy read_files, or glue-solar's stack read)."""
import glob, json, sys, time
from astropy.io import fits
from astropy.io.fits import verify as fv
import irispy, irispy.io.spectrograph as sp
from irispy.io import read_files

acc = {"hdulist_verify_s": 0.0, "hdulist_verify_n": 0, "mask_s": 0.0, "mask_n": 0}
_v = fv._Verify.verify


def verify(self, option="warn"):
    if not isinstance(self, fits.HDUList):
        return _v(self, option)
    t = time.perf_counter()
    try:
        return _v(self, option)
    finally:
        acc["hdulist_verify_s"] += time.perf_counter() - t
        acc["hdulist_verify_n"] += 1


fv._Verify.verify = verify
if hasattr(sp, "_memmap_fill_mask"):
    _m = sp._memmap_fill_mask

    def mask(*a):
        t = time.perf_counter()
        try:
            return _m(*a)
        finally:
            acc["mask_s"] += time.perf_counter() - t
            acc["mask_n"] += 1

    sp._memmap_fill_mask = mask
paths = sorted(glob.glob("/Users/nabil/DATA/IRIS/*3602506433_raster/*.fits"))
if sys.argv[2] == "glue":
    from glue_solar.sources.loaders import iris as L
    run = lambda: L.raster_data(paths, stack=True)  # noqa
else:
    run = lambda: read_files(paths, memmap=True, uncertainty=False)  # noqa
t = time.perf_counter()
run()
acc["total_s"] = time.perf_counter() - t
print(json.dumps({"v": sys.argv[1], "layer": sys.argv[2], **{k: round(v, 3) for k, v in acc.items()}}))
