"""Raw -200 and -199 codes counted in each case's data; an AIA cutout copy with both codes planted reads as masked."""
import glob, shutil, numpy as np
from astropy.io import fits
from irispy.io import read_files

D = "/Users/nabil/DATA/IRIS"
for o in (4000255147, 3824262996, 3400109360, 3602506433):
    f = sorted(glob.glob(f"{D}/*{o}_raster/*.fits"))[0]
    with fits.open(f, memmap=True, do_not_scale_image_data=True) as h:
        n = {}
        for i in range(1, h[0].header["NWIN"] + 1):
            d, hd = h[i].data, h[i].header
            for v in (-200, -199):
                n[v] = n.get(v, 0) + int(np.count_nonzero(d == (v - hd.get("BZERO", 0)) / hd.get("BSCALE", 1)))
        print(o, "file 0, all windows:", n)
src = sorted(glob.glob(f"{D}/*3640107442_SDO/*_1600.fits"))[0]
dst = "aia_fill/" + src.rsplit("/", 1)[1]
shutil.copy(src, dst)
with fits.open(dst, mode="update", do_not_scale_image_data=True) as h:
    h[0].data[0, :2, :3] = -200
    h[0].data[1, :2, :2] = -199
cube = read_files(dst, memmap=True)
m = cube.mask[:2].compute()
print("AIA planted: mask -200 plane", int(m[0].sum()), "of 6, -199 plane", int(m[1].sum()), "of 4; unmasked 0 elsewhere:",
      int(cube.mask[2:].sum().compute()) == int(np.isin(np.asarray(cube.data[2:]), [-200, -199]).sum()))
