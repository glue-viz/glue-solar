"""python bench.py VARIANT LAYER CASE: one load in this fresh process, one JSON line.

LAYER irispy: read_files(paths, memmap=True, uncertainty=False). LAYER glue: glue-solar main's raster_data / image_data
(LAZY on); CASE suffix _stack: raster_data(paths, stack=True), every window, as the browser reads it.
Wall time of the call; peak RSS over the post-import baseline (max of ru_maxrss and a 1 ms psutil sampler);
RSS kept after gc; other processes' CPU (cores busy) during the call; modules the call imported.
"""
import gc, glob, json, os, resource, sys, threading, time

import psutil

variant, layer, case = sys.argv[1:4]
D = "/Users/nabil/DATA/IRIS"
W = os.path.dirname(os.path.abspath(__file__))


def files(obsid):
    return sorted(glob.glob(f"{D}/*{obsid}_raster/*.fits"))


INPUT = {
    "r4000255147": files(4000255147), "r3824262996": files(3824262996),
    "r3400109360": files(3400109360), "r3602506433": files(3602506433),
    "sji": [f"{W}/iris_l2_20130902_163935_4000255147_SJI_1400_t000.fits"],
    "sjigz": glob.glob(f"{D}/*4000255147_SJI_1400_t000.fits.gz"),
    "aia": sorted(glob.glob(f"{D}/*3640107442_SDO/*.fits")),
}
stack = case.endswith("_stack")
paths = INPUT[case.removesuffix("_stack")]

import numpy as np  # noqa
import irispy  # noqa
from irispy.io import read_files  # noqa

if layer == "glue":
    from glue_solar.sources.loaders import iris as L  # noqa

    assert L.LAZY

    def run():
        if case.startswith("r"):
            return L.raster_data(paths, stack=stack)
        return [L.image_data(p) for p in paths]
else:
    def run():
        return read_files(paths, memmap=True, uncertainty=False)

proc = psutil.Process()
gc.collect()
mods0 = set(sys.modules)
rss0 = proc.memory_info().rss
ru0 = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss  # bytes on macOS
peak = [rss0]
stop = threading.Event()


def sample():
    while not stop.is_set():
        peak[0] = max(peak[0], proc.memory_info().rss)
        time.sleep(0.001)


th = threading.Thread(target=sample, daemon=True)
th.start()
s0, m0 = psutil.cpu_times(), proc.cpu_times()
t = time.perf_counter()
out = run()
dt = time.perf_counter() - t
s1, m1 = psutil.cpu_times(), proc.cpu_times()
stop.set()
th.join()
ru1 = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
gc.collect()
MB = 2**20
new = sorted(m for m in set(sys.modules) - mods0 if m.count(".") <= 1)
row = {"v": variant, "layer": layer, "case": case, "irispy": irispy.__version__, "n": len(out) if hasattr(out, "__len__") and not hasattr(out, "wcs") else 1, "s": round(dt, 3),
       # ru_maxrss counts only when the call raised it
       "peak_MB": round((max(peak[0], ru1 if ru1 > ru0 else 0) - rss0) / MB, 1), "sampled_MB": round((peak[0] - rss0) / MB, 1),
       "ru_MB": round((ru1 - max(ru0, rss0)) / MB, 1) if ru1 > ru0 else 0.0,
       "kept_MB": round((proc.memory_info().rss - rss0) / MB, 1),
       "other_cores": round((sum(getattr(s1, k) - getattr(s0, k) for k in ("user", "system", "nice"))
                             - (m1.user - m0.user + m1.system - m0.system)) / dt, 2),
       "load1": round(os.getloadavg()[0], 1), "new_mods": len(set(sys.modules) - mods0), "new_top": new[:12]}
print(json.dumps(row), flush=True)
os._exit(0)
