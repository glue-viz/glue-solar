"""python gzfoot.py VARIANT: read_files(SJI .fits.gz, memmap=True): RSS and macOS physical footprint before and after."""
import gc, glob, json, os, subprocess, sys

import psutil

from irispy.io import read_files


def foot():
    out = subprocess.run(["vmmap", "-summary", str(os.getpid())], capture_output=True, text=True).stdout
    line = next(l for l in out.splitlines() if l.startswith("Physical footprint:"))
    v = line.split()[-1]
    return float(v[:-1]) * {"K": 1 / 1024, "M": 1, "G": 1024}[v[-1]]


p = psutil.Process()
gc.collect()
r0, f0 = p.memory_info().rss / 2**20, foot()
out = read_files(glob.glob("/Users/nabil/DATA/IRIS/*4000255147_SJI_1400_t000.fits.gz")[0], memmap=True)
gc.collect()
r1, f1 = p.memory_info().rss / 2**20, foot()
print(json.dumps({"v": sys.argv[1], "rss_kept_MB": round(r1 - r0, 1), "footprint_kept_MB": round(f1 - f0, 1),
                  "footprint_peak_MB": round(p.memory_full_info().uss / 2**20 - r0, 1)}))
