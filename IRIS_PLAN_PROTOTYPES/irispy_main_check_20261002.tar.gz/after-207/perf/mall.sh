#!/bin/sh
cd "$(dirname "$0")"
for c in r4000255147 r3824262996 r3400109360 r3602506433 sji sjigz aia; do ./m.sh check $c >> check.jsonl; done
for r in 0 1 2 3 4 5; do
  for c in r4000255147 r3824262996 r3400109360 r3602506433 sji sjigz aia; do ./m.sh plane $c | sed "s/^{/{\"round\": $r, /" >> plane.jsonl; done
done
echo done > mall.done
