"""python summ.py time.jsonl: medians (round 0 dropped) per layer, case and variant, with 0ee8fad against 0.9.1."""
import json, statistics as st, sys
from collections import defaultdict

g = defaultdict(list)
for line in open(sys.argv[1]):
    if line.startswith("{"):
        r = json.loads(line)
        if r["round"] != 0:
            g[(r["layer"], r["case"], r["v"])].append(r)
med = lambda rs, f: st.median(r[f] for r in rs)  # noqa
print("| layer | case | 0.9.1 s | 57813b8 s | 0ee8fad s | main/0.9.1 | 0.9.1 peak MB | 57813b8 peak | 0ee8fad peak "
      "| main-0.9.1 MB | kept 0.9.1/578/main | other cores | n | runs (0ee8fad s) | holds |")
print("|" + "---|" * 15)
for layer, case in dict.fromkeys((k[0], k[1]) for k in g):
    a, b, c = (g[(layer, case, v)] for v in ("091", "578", "main"))
    ratio = med(c, "s") / med(a, "s")
    dmem = med(c, "peak_MB") - med(a, "peak_MB")
    holds = "yes" if ratio <= 1.10 and dmem <= 5 else ("time" if ratio > 1.10 and dmem <= 5 else "mem" if ratio <= 1.10 else "no")
    print(f"| {layer} | {case} | {med(a, 's'):.3f} | {med(b, 's'):.3f} | {med(c, 's'):.3f} | {ratio:.2f} "
          f"| {med(a, 'peak_MB'):g} | {med(b, 'peak_MB'):g} | {med(c, 'peak_MB'):g} | {dmem:+.1f} "
          f"| {med(a, 'kept_MB'):g}/{med(b, 'kept_MB'):g}/{med(c, 'kept_MB'):g} "
          f"| {st.median(r['other_cores'] for r in a + b + c):.1f} | {c[0]['n']} | {len(a)}/{len(b)}/{len(c)} "
          f"({', '.join(f'{r['s']:.3f}' for r in c)}) | {holds} |")
