"""python mask.py MODE CASE (irispy 0ee8fad): the lazy memmap fill mask of read_files(paths, memmap=True).

check: every cube's mask is a bool dask array of one plane per chunk; after read_files returned (its HDULists closed)
plane 0 and, after gc.collect(), the full mask equal np.isin(raw, raw codes) with the codes from the file's own header;
then only the masks are kept (cubes and collection deleted, gc.collect()) and recomputed: same sums and hashes.
plane: one plane (middle) of the largest cube's mask: time, peak RSS, the _MappedArray reads; then the full mask.
"""
import gc, glob, hashlib, json, os, resource, sys, threading, time

import numpy as np
import psutil

mode, case = sys.argv[1:3]
D = "/Users/nabil/DATA/IRIS"
W = os.path.dirname(os.path.abspath(__file__))
INPUT = {
    "r4000255147": "4000255147_raster/*.fits", "r3824262996": "3824262996_raster/*.fits",
    "r3400109360": "3400109360_raster/*.fits", "r3602506433": "3602506433_raster/*.fits",
    "sjigz": "4000255147_SJI_1400_t000.fits.gz", "aia": "3640107442_SDO/*.fits",
}
paths = ([f"{W}/iris_l2_20130902_163935_4000255147_SJI_1400_t000.fits"] if case == "sji"
         else sorted(glob.glob(f"{D}/*{INPUT[case]}")))

import dask.array as da  # noqa
from astropy.io import fits  # noqa
from astropy.io.fits import file as fitsfile  # noqa
from ndcube import NDCollection, NDCube, NDCubeSequence  # noqa

from irispy.io import read_files  # noqa
from irispy.io import _mask  # noqa  (0ee8fad only)

created = []
_init = fitsfile._File.__init__


def init(self, *a, **k):
    _init(self, *a, **k)
    created.append(self)


fitsfile._File.__init__ = init
reads = []
_getitem = _mask._MappedArray.__getitem__


def getitem(self, item):
    reads.append(repr(item))
    return _getitem(self, item)


_mask._MappedArray.__getitem__ = getitem


def flatten(obj, key=()):
    if isinstance(obj, NDCube):
        yield key, obj
    elif isinstance(obj, NDCubeSequence):
        for i, cube in enumerate(obj.data):
            yield from flatten(cube, (*key, i))
    else:  # NDCollection, RasterCollection
        for k, v in obj.items():
            yield from flatten(v, (*key, k))


def header_of(key):
    """The header of the HDU a cube came from, read on its own."""
    if case.startswith("r"):
        window, i = key[-2], key[-1]
        path = paths[i]
        h0 = fits.getheader(path)
        ext = next(j for j in range(1, h0["NWIN"] + 1) if h0[f"TDESC{j}"] == window)
        return fits.getheader(path, ext)
    if len(paths) == 1:
        return fits.getheader(paths[0])
    return next(h for h in map(fits.getheader, paths) if h["TDESC1"] == key[-1])


def codes(header):
    return (np.array([-200, -199]) - header.get("BZERO", 0)) / header.get("BSCALE", 1)


out = read_files(paths, memmap=True, uncertainty=False)
cubes = list(flatten(out))
row = {"case": case, "cubes": len(cubes), "files_opened": len(created),
       "all_closed_after_read": all(f.closed for f in created), "reads_at_open": len(reads)}

if mode == "check":
    bad, fills, hashes, codeset = [], [], [], set()
    for key, cube in cubes:  # right after read_files: plane 0
        m = cube.mask
        c = codes(header_of(key))
        codeset.add(tuple(c.tolist()))
        ok = (isinstance(m, da.Array) and m.dtype == bool and m.shape == cube.data.shape
              and all(n == 1 for n in m.chunks[0]) and np.array_equal(m[0].compute(), np.isin(cube.data[0], c)))
        if not ok:
            bad.append(("plane0", key))
    gc.collect()
    for key, cube in cubes:  # after gc.collect(): the full mask
        full = cube.mask.compute()
        if not np.array_equal(full, np.isin(np.asarray(cube.data), codes(header_of(key)))):
            bad.append(("full", key))
        fills.append(int(full.sum()))
        hashes.append(hashlib.sha1(np.packbits(full).tobytes()).hexdigest())
        del full
    masks = [cube.mask for _, cube in cubes]
    del out, cubes, cube
    gc.collect()
    again = [m.compute() for m in masks]  # only the masks hold the maps now
    survivors_ok = ([int(a.sum()) for a in again] == fills
                    and [hashlib.sha1(np.packbits(a).tobytes()).hexdigest() for a in again] == hashes)
    row.update(bad=bad[:5], n_bad=len(bad), fill_pixels=sum(fills), cubes_with_fill=sum(f > 0 for f in fills),
               raw_codes=sorted(codeset), masks_only_after_gc_ok=survivors_ok, error=None)
else:
    key, cube = max(cubes, key=lambda kc: kc[1].data.nbytes)
    k = cube.shape[0] // 2
    proc = psutil.Process()
    MB = 2**20

    def measure(fn):
        gc.collect()
        rss0 = proc.memory_info().rss
        peak, stop = [rss0], threading.Event()

        def sample():
            while not stop.is_set():
                peak[0] = max(peak[0], proc.memory_info().rss)
                time.sleep(0.001)

        th = threading.Thread(target=sample, daemon=True)
        th.start()
        n0 = len(reads)
        ru0 = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        t = time.perf_counter()
        value = fn()
        dt = time.perf_counter() - t
        stop.set()
        th.join()
        ru = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        return value, dt, round((max(peak[0], ru if ru > ru0 else 0) - rss0) / MB, 1), reads[n0:]

    plane, dt1, pk1, r1 = measure(lambda: cube.mask[k].compute())
    plane2, dt3, pk3, r3 = measure(lambda: cube.mask[k + 1].compute())  # after dask's first-compute setup
    raw, dt4, pk4, _ = measure(lambda: np.isin(cube.data[k + 2], codes(header_of(key))))  # reference: plain NumPy
    full, dt2, pk2, r2 = measure(lambda: cube.mask.compute())
    row.update(key=str(key), shape=cube.shape, plane_raw_MB=round(cube.data[k].nbytes / MB, 2),
               cube_raw_MB=round(cube.data.nbytes / MB, 1), plane_s=round(dt1, 4), plane_peak_MB=pk1,
               plane_reads=r1, plane2_s=round(dt3, 4), plane2_peak_MB=pk3, plane2_reads=len(r3), numpy_plane_s=round(dt4, 4), numpy_plane_peak_MB=pk4, full_s=round(dt2, 3), full_peak_MB=pk2, full_reads=len(r2),
               plane_ok=bool(np.array_equal(plane, full[k]) and np.array_equal(plane2, full[k + 1])))
print(json.dumps(row, default=str), flush=True)
os._exit(0)
