"""python gzmem.py VARIANT: read_files(SJI 1400 .fits.gz, memmap=True): tracemalloc peak and the allocations kept, by
the irispy/astropy line that made them."""
import gc, glob, json, sys, tracemalloc

from irispy.io import read_files

path = glob.glob("/Users/nabil/DATA/IRIS/*4000255147_SJI_1400_t000.fits.gz")[0]
gc.collect()
tracemalloc.start(25)
out = read_files(path, memmap=True, uncertainty=False)
cur, peak = tracemalloc.get_traced_memory()
gc.collect()
snap = tracemalloc.take_snapshot()
MB = 2**20
rows = []
for s in snap.statistics("traceback")[:5]:
    if s.size < MB:
        break
    frames = [f"{f.filename.split('site-packages/')[-1].split('/irispy/irispy/')[-1]}:{f.lineno}" for f in s.traceback
              if "astropy" in f.filename or "irispy" in f.filename or "numpy" in f.filename]
    rows.append({"MB": round(s.size / MB, 1), "frames": frames[-6:]})
print(json.dumps({"v": sys.argv[1], "tm_peak_MB": round(peak / MB, 1), "tm_kept_MB": round(cur / MB, 1),
                  "kept_after_gc_MB": round(tracemalloc.get_traced_memory()[0] / MB, 1),
                  "data_owns": bool(out.data.flags.owndata), "data_base": type(out.data.base).__name__,
                  "top": rows}, indent=1))
