"""python count.py VARIANT LAYER CASE [prof]: FITS file opens and verify calls per raster file during one load.

Opens are astropy _File objects (fits.open, getheader, ...) by file, attributed to the first irispy or glue_solar
frame on the stack (file:line); verify calls are _Verify.verify (HDUList.verify, hdu.verify). prof: cProfile.
"""
import collections, cProfile, glob, io, json, os, pstats, sys, traceback

variant, layer, case = sys.argv[1:4]
prof = len(sys.argv) > 4
D = "/Users/nabil/DATA/IRIS"
W = os.path.dirname(os.path.abspath(__file__))
paths = sorted(glob.glob(f"{D}/*{case.removeprefix('r').removesuffix('_stack')}_raster/*.fits"))
stack = case.endswith("_stack")

from astropy.io.fits import file as fitsfile, verify as fitsverify  # noqa
import irispy  # noqa
from irispy.io import read_files  # noqa

if layer == "glue":
    from glue_solar.sources.loaders import iris as L  # noqa

    run = lambda: L.raster_data(paths, stack=stack)  # noqa
else:
    run = lambda: read_files(paths, memmap=True, uncertainty=False)  # noqa

opens, sites, verifies = collections.Counter(), collections.Counter(), collections.Counter()


def site():
    for fr in reversed(traceback.extract_stack()[:-2]):
        if "/irispy/" in fr.filename or "/glue_solar/" in fr.filename:
            return f"{fr.filename.split('/irispy/')[-1].split('/glue_solar/')[-1]}:{fr.lineno} {fr.name}"
    return "?"


_init = fitsfile._File.__init__


def init(self, fileobj=None, *a, **k):
    _init(self, fileobj, *a, **k)
    name = os.path.basename(str(getattr(self, "name", None) or fileobj))
    opens[name] += 1
    sites[site()] += 1


fitsfile._File.__init__ = init
_verify = fitsverify._Verify.verify


def verify(self, option="warn"):
    verifies[(type(self).__name__, site())] += 1
    return _verify(self, option)


fitsverify._Verify.verify = verify

if prof:
    p = cProfile.Profile()
    p.enable()
    run()
    p.disable()
    s = io.StringIO()
    st = pstats.Stats(p, stream=s)
    st.sort_stats("cumulative").print_stats(r"verify\.py.*\(verify\)|\(fitsopen\)|\(getheader\)|\(read_spectrograph_lvl2\)|"
                                            r"\(read_files\)|\(_memmap_fill_mask\)|\(isin\)|\(_window_scaling\)|"
                                            r"\(_raster_windows_data\)|\(_raster_collection_data\)|\(_get_spec_group_key\)|"
                                            r"\(_get_simple_metadata\)|\(_create_tabular_wcs\)|\(__init__\).*file\.py")
    print("\n".join(line for line in s.getvalue().splitlines() if "(" in line and ":" in line))
else:
    run()
    raster = [os.path.basename(p) for p in paths]
    per = [opens[n] for n in raster]
    print(json.dumps({"v": variant, "layer": layer, "case": case, "files": len(paths),
                      "opens_per_file": sorted(collections.Counter(per).items()), "opens_file0": per[0],
                      "opens_total": sum(opens.values()), "verify_total": sum(verifies.values()),
                      "verify_per_file": round(sum(verifies.values()) / len(paths), 2),
                      "verify_sites": {f"{k[0]} {k[1]}": v for k, v in verifies.items()},
                      "open_sites": dict(sites.most_common())}))
sys.stdout.flush()
os._exit(0)
