"""
One open of one case in this fresh process; prints one JSON line.

python bench.py VARIANT CASE   (VARIANT only labels the line; irispy comes from PYTHONPATH; WA=1 installs wa.py;
ATTRIB=1 times irispy's np.isin and HDUList.verify calls by caller line; NOVERIFY=1 makes HDUList.verify a no-op)
Baseline after imports and gc.collect(). Peak RSS: psutil RSS sampled every 1 ms in a thread and ru_maxrss;
footprint: proc_pid_rusage v4 phys_footprint (excludes clean file-backed pages) and its lifetime max.
Other load: system busy CPU over the open minus this process's CPU, in cores.
"""

import gc
import glob
import gzip
import io
import json
import os
import sys
import threading
import time
from collections import defaultdict

import psutil

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from mem import usage  # noqa: E402

variant, case = sys.argv[1:3]
D = "/Users/nabil/DATA/IRIS"
PERF = os.path.dirname(os.path.abspath(__file__))
SJI_GZ = glob.glob(f"{D}/*4000255147_SJI_1400_t000.fits.gz")[0]
SJI_FITS = f"{PERF}/iris_l2_20130902_163935_4000255147_SJI_1400_t000.fits"


def files(obsid):
    return sorted(glob.glob(f"{D}/*{obsid}_raster/*.fits"))


import numpy as np  # noqa: E402
from astropy.io import fits  # noqa: E402
from glue_solar.sources.loaders import iris as L  # noqa: E402
from glue_solar.sources.loaders.scan import scan_directory  # noqa: E402
import irispy  # noqa: E402
from irispy.io import read_files  # noqa: E402
from irispy.io.sji import read_sji_lvl2  # noqa: E402
import irispy.io.spectrograph  # noqa: E402

if os.environ.get("WA"):
    import wa

    wa.install()
    wa.wrap_loaders()

timed = defaultdict(lambda: [0, 0.0, 0])  # caller -> calls, seconds, bytes of result
if os.environ.get("ATTRIB"):
    for module in (irispy.io.sji, irispy.io.spectrograph):
        real = module.np

        class _NP:
            def __getattr__(self, name, real=real):
                return getattr(real, name)

            @staticmethod
            def isin(*a, real=real, **k):
                f = sys._getframe(1)
                t = time.perf_counter()
                out = real.isin(*a, **k)
                entry = timed[f"isin {os.path.relpath(f.f_code.co_filename, os.path.dirname(irispy.__file__))}:{f.f_lineno}"]
                entry[0] += 1
                entry[1] += time.perf_counter() - t
                entry[2] += getattr(out, "nbytes", 0)
                return out

        module.np = _NP()
    _verify = fits.HDUList.verify

    def verify(self, *a, **k):
        f = sys._getframe(1)
        t = time.perf_counter()
        out = _verify(self, *a, **k)
        entry = timed[f"verify {os.path.relpath(f.f_code.co_filename, os.path.dirname(irispy.__file__))}:{f.f_lineno}"]
        entry[0] += 1
        entry[1] += time.perf_counter() - t
        return out

    fits.HDUList.verify = verify
if os.environ.get("NOVERIFY"):
    fits.HDUList.verify = lambda self, *a, **k: None


def browser(obsid):
    [obs] = scan_directory(os.path.dirname(files(obsid)[0]), recursive=False)
    picks = [(0, "raster", w) for w in obs.windows]
    _, loaded, error = L._load(1, [obs], picks, False, None, threading.Event(), lambda *a: None)
    assert error is None, error
    return [d for *_, ds in loaded for d in ds]


def sji_irispy_only(path):
    """Hypothetical: glue-solar's own SJI read and gzip handling dropped, irispy main's memmap cube's raw values used."""
    cube = read_files(path, memmap=True, uncertainty=False)
    scaling = L._raw_scaling(cube.meta)
    return [L._image_cube_data(cube, path, cube.data, scaling)]


def sji_bytes(path):
    """Hypothetical: glue-solar decompresses once, irispy main reads the bytes (no copy), its raw values used."""
    with gzip.open(path) as f:
        content = f.read()
    cube = read_sji_lvl2(content, memmap=True, uncertainty=False)
    scaling = L._raw_scaling(cube.meta)
    return [L._image_cube_data(cube, path, cube.data, scaling)]


if case == "a_ql":  # the browser's worker with the quicklook's colour-limit counts (D36), scanned beforehand
    from functools import partial
    from glue_solar.sources.iris import _shown

    QL_OBS = [o for o in scan_directory(D, recursive=True) if o.obsid.endswith("4000255147")]
    QL_PICKS = [(0, "raster", w) for w in QL_OBS[0].windows] + [(0, "sji", b) for b in QL_OBS[0].sji]


def browser_ql():
    _, loaded, error = L._load(1, QL_OBS[:1], QL_PICKS, False, partial(_shown, quicklooks=True), threading.Event(),
                               lambda *a: None)
    assert error is None, error
    return [d for *_, ds in loaded for d in ds]


CASES = {
    "a_ql": browser_ql,
    "c_all": lambda: L.raster_data(files(3824262996)),
    "a": lambda: L.raster_data(files(4000255147)),
    "a_browser": lambda: browser(4000255147),
    "b": lambda: L.raster_data(files(3602506433), ["Si IV 1403"], stack=True),
    "c": lambda: L.raster_data(files(3824262996), ["Mg II k 2796"]),
    "d": lambda: L.raster_data(files(4000005156)[:1]),
    "g": lambda: L.raster_data(files(3400109360)[:1]),
    "e_gz": lambda: [L.image_data(SJI_GZ)],
    "e_fits": lambda: [L.image_data(SJI_FITS)],
    "e_irispy_gz": lambda: sji_irispy_only(SJI_GZ),
    "e_irispy_fits": lambda: sji_irispy_only(SJI_FITS),
    "e_bytes_gz": lambda: sji_bytes(SJI_GZ),
    "f_a": lambda: read_files(files(4000255147), memmap=True),
    "f_b": lambda: read_files(files(3602506433), spectral_windows=["Si IV 1403"], memmap=True),
    "f_b_all": lambda: read_files(files(3602506433), memmap=True),
    "f_c": lambda: read_files(files(3824262996), spectral_windows=["Mg II k 2796"], memmap=True),
    "f_d": lambda: read_files(files(4000005156)[:1], memmap=True),
    "f_g": lambda: read_files(files(3400109360)[:1], memmap=True),
}

proc = psutil.Process()
gc.collect()
u0 = usage()
rss0 = proc.memory_info().rss
peak = [rss0]
stop = threading.Event()


def sample():
    while not stop.is_set():
        peak[0] = max(peak[0], proc.memory_info().rss)
        time.sleep(0.001)


th = threading.Thread(target=sample, daemon=True)
th.start()
sys0, me0 = psutil.cpu_times(), proc.cpu_times()
t = time.perf_counter()
out = CASES[case]()
dt = time.perf_counter() - t
sys1, me1 = psutil.cpu_times(), proc.cpu_times()
stop.set()
th.join()
u1 = usage()
busy = sum(getattr(sys1, k) - getattr(sys0, k) for k in ("user", "system", "nice"))
mine = (me1.user - me0.user) + (me1.system - me0.system)
gc.collect()
u2 = usage()
mask_types = set()
for item in (out.values() if hasattr(out, "values") else out):
    for cube in (item if hasattr(item, "__iter__") and not hasattr(item, "main_components") else [item]):
        if hasattr(cube, "mask"):
            mask_types.add(type(cube.mask).__name__)
MB = 2**20
row = {
    "round": int(os.environ.get("ROUND", -1)), "variant": variant, "case": case, "irispy": irispy.__version__, "wa": bool(os.environ.get("WA")),
    "noverify": bool(os.environ.get("NOVERIFY")), "n": len(out), "open_s": round(dt, 3),
    "peak_rss_MB": round((max(peak[0], u1["maxrss"]) - rss0) / MB),
    "kept_rss_MB": round((u1["rss"] - rss0) / MB), "kept_rss_gc_MB": round((u2["rss"] - rss0) / MB),
    "peak_fp_MB": round((u1["max_footprint"] - u0["footprint"]) / MB),
    "kept_fp_MB": round((u1["footprint"] - u0["footprint"]) / MB),
    "kept_fp_gc_MB": round((u2["footprint"] - u0["footprint"]) / MB),
    "base_rss_MB": round(rss0 / MB), "other_cores": round((busy - mine) / dt, 2), "own_cpu_s": round(mine, 2),
    "masks": sorted(mask_types),
}
if timed:
    row["timed"] = {k: [v[0], round(v[1], 3), round(v[2] / MB)] for k, v in timed.items()}
print(json.dumps(row), flush=True)
os._exit(0)
