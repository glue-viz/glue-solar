#!/bin/sh
# run1.sh VARIANT CASE [env...]: one fresh process
V=$1; C=$2; shift 2
case $V in
  091) IP="" ;;
  main|wa) IP="/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-main-check/irispy:" ;;
  fix) IP="/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-main-check/perf/irispy-fix:" ;;
  dask) IP="/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-main-check/perf/irispy-dask:" ;;
esac
W=""; [ "$V" = wa ] && W="WA=1"
cd /private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-main-check/perf && env HOME="$(mktemp -d)" QT_QPA_PLATFORM=offscreen MPLBACKEND=agg MPLCONFIGDIR=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-main-check/perf/mplcfg PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="${IP}/Users/nabil/Git/glue-solar-accept" $W "$@" /Users/nabil/mamba/envs/iris-plan/bin/python -B /private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-main-check/perf/bench.py $V $C 2>>/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-main-check/perf/stderr.log
