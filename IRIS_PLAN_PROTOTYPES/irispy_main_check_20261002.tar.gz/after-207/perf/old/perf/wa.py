"""
Prototype glue-solar workaround (glue_patches.py style): irispy's Level 2 readers build no fill mask of a memory map
while glue-solar's loaders read, as glue-solar never reads irispy's mask (it masks from the raw codes it reads).

Gated at call time by the behaviour itself: it acts only when irispy's reader asks ``np.isin`` for a mask of a
memory-mapped array inside `reading()`; once irispy builds no such mask (or a lazy one), it never acts.
"""

import mmap
import threading
from contextlib import contextmanager

import numpy as np

_state = threading.local()


def _mapped(array):
    """Whether ``array`` is a view of a memory map."""
    while isinstance(array, np.ndarray):
        if isinstance(array, np.memmap):
            return True
        array = array.base
    return isinstance(array, mmap.mmap)


class _ReaderNumpy:
    """NumPy, as irispy's readers see it: no ``isin`` mask of a memory map during `reading`."""

    def __getattr__(self, name):
        return getattr(np, name)

    @staticmethod
    def isin(element, test_elements, *args, **kwargs):
        if getattr(_state, "reading", False) and _mapped(element):
            _state.skipped = getattr(_state, "skipped", 0) + 1
            return None  # irispy's cubes take mask=None, as 0.9.1 gave under memmap
        return np.isin(element, test_elements, *args, **kwargs)


@contextmanager
def reading():
    """irispy reads in here build no mask of memory-mapped data, on this thread only."""
    _state.reading = True
    try:
        yield
    finally:
        _state.reading = False


def install():
    from irispy.io import sji, spectrograph

    for module in (sji, spectrograph):
        module.np = _ReaderNumpy()


def wrap_loaders():
    """What glue-solar's loaders would do: read through irispy inside `reading`."""
    from glue_solar.sources.loaders import iris

    def wrapped(function):
        def inner(*args, **kwargs):
            with reading():
                return function(*args, **kwargs)

        return inner

    iris._raster_windows_data = wrapped(iris._raster_windows_data)
    iris.image_data = wrapped(iris.image_data)


if __name__ == "__main__":  # self-check
    import tempfile

    with tempfile.NamedTemporaryFile() as f:
        np.arange(10, dtype=np.int16).tofile(f.name)
        mapped = np.ndarray((10,), np.int16, buffer=mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_COPY))[::-1]
        assert _mapped(mapped) and not _mapped(np.arange(3))
        npx = _ReaderNumpy()
        assert npx.isin(mapped, [1]).sum() == 1  # outside reading(): unchanged
        with reading():
            assert npx.isin(mapped, [1]) is None
            assert npx.isin(np.arange(3), [1]).sum() == 1  # in memory: unchanged
        assert npx.float32 is np.float32
    print("ok")
