#!/bin/sh
# Interleaved rounds: round 0 warms the page cache and is discarded.
cd "$(dirname "$0")"
OUT=${OUT:-results.jsonl}
for r in 0 1 2 3 4 5; do
  for c in a a_browser b c d g e_gz e_fits; do
    for v in 091 main fix dask wa; do ./run1.sh $v $c ROUND=$r >> $OUT; done
  done
  for c in f_a f_b f_c f_d f_g; do
    for v in 091 main fix dask; do ./run1.sh $v $c ROUND=$r >> $OUT; done
  done
  for c in e_irispy_gz e_irispy_fits e_bytes_gz; do
    for v in main fix dask; do ./run1.sh $v $c ROUND=$r >> $OUT; done
  done
done
# attribution (main) and A5 verify
for r in 1 2 3; do
  for c in a b c d g e_gz e_fits f_b_all; do ./run1.sh main $c ROUND=$r ATTRIB=1 >> attrib.jsonl; done
  for c in f_b_all b; do ./run1.sh 091 $c ROUND=$r ATTRIB=1 >> attrib.jsonl; done
done
for r in 0 1 2 3 4 5; do
  for c in f_b_all b; do
    for v in 091 main; do
      ./run1.sh $v $c ROUND=$r >> verify.jsonl
      ./run1.sh $v $c ROUND=$r NOVERIFY=1 >> verify.jsonl
    done
  done
done
echo done >> runs.done
