"""wa.py on irispy main: glue-solar's datasets equal those without it (values and mask, two planes per window)."""
import glob
import numpy as np
import wa
from glue_solar.sources.loaders import iris as L

files = sorted(glob.glob("/Users/nabil/DATA/IRIS/*4000005156_raster/*.fits"))[:1]
neg = sorted(glob.glob("/Users/nabil/DATA/IRIS/*3400109360_raster/*.fits"))[:1]
sji = "iris_l2_20130902_163935_4000255147_SJI_1400_t000.fits"
plain = L.raster_data(files) + L.raster_data(neg) + [L.image_data(sji)]
wa.install(); wa.wrap_loaders()
patched = L.raster_data(files) + L.raster_data(neg) + [L.image_data(sji)]
assert wa._state.skipped == 9 + 7 + 1, wa._state.skipped
for a, b in zip(plain, patched):
    assert a.label == b.label
    for cid_a, cid_b in zip(a.components, b.components):
        for i in (0, a.shape[0] // 2):
            assert np.array_equal(np.asarray(a[cid_a][i]), np.asarray(b[cid_b][i]), equal_nan=True), (a.label, cid_a)
print("equal:", len(plain), "datasets; masks skipped:", wa._state.skipped)
