"""
What irispy main's memmap mask line costs on one window (4000255147 C II 1336, 1600x417x229 int16, 306 MB), split
into page-in and compare, and against integer fill codes; tracemalloc peak per call. One JSON line.
"""
import glob
import json
import time
import tracemalloc

import numpy as np
from astropy.io import fits

f = glob.glob("/Users/nabil/DATA/IRIS/*4000255147_raster/*.fits")[0]
hdul = fits.open(f, memmap=True, do_not_scale_image_data=True)
data = hdul[1].data
raw_fill = (np.asarray((-200, -199)) - 7992) / 0.25  # as irispy main computes it: float64


def run(label, fn):
    tracemalloc.start()
    t = time.perf_counter()
    out = fn()
    dt = time.perf_counter() - t
    peak = tracemalloc.get_traced_memory()[1]
    tracemalloc.stop()
    row[label] = [round(dt, 3), round(peak / 2**20), int(out.sum())]


row = {"window_MB": round(data.nbytes / 2**20)}
run("isin_float_first_touch", lambda: np.isin(data, raw_fill))
run("isin_float_resident", lambda: np.isin(data, raw_fill))
run("isin_int16", lambda: np.isin(data, raw_fill.astype(np.int16)))
run("two_int_compares", lambda: (data == np.int16(-32768)) | (data == np.int16(-32764)))
run("isin_float_flipped", lambda: np.isin(data[::-1], raw_fill))
print(json.dumps(row))
