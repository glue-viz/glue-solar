"""Medians per (case, variant) of results.jsonl (round 0 dropped), and the attribution and verify tables."""
import json
import statistics as st
import sys
from collections import defaultdict

FIELDS = ("open_s", "peak_rss_MB", "peak_fp_MB", "kept_fp_MB", "kept_fp_gc_MB", "kept_rss_gc_MB", "other_cores")


def load(path):
    try:
        return [json.loads(line) for line in open(path) if line.startswith("{")]
    except FileNotFoundError:
        return []


def table(rows, key):
    groups = defaultdict(list)
    for r in rows:
        if r["round"] != 0:
            groups[key(r)].append(r)
    print("| case | variant | runs | " + " | ".join(FIELDS) + " | open_s all |")
    print("|---" * (len(FIELDS) + 4) + "|")
    for k in sorted(groups, key=str):
        rs = groups[k]
        med = [st.median(r[f] for r in rs) for f in FIELDS]
        print(f"| {k[0]} | {k[1]} | {len(rs)} | " + " | ".join(f"{m:g}" for m in med)
              + " | " + ", ".join(f"{r['open_s']:.2f}" for r in rs) + " |")


table(load(sys.argv[1] if len(sys.argv) > 1 else "results.jsonl"), lambda r: (r["case"], r["variant"]))
print()
attrib = defaultdict(lambda: defaultdict(list))
for r in load("attrib.jsonl"):
    for line, (calls, secs, mb) in r.get("timed", {}).items():
        attrib[(r["case"], r["variant"])][line].append((calls, secs, mb, r["open_s"]))
print("| case | variant | call | calls | s (median) | result MB | open_s (median) |")
print("|---|---|---|---|---|---|---|")
for k in sorted(attrib):
    for line, vals in sorted(attrib[k].items()):
        print(f"| {k[0]} | {k[1]} | {line} | {vals[0][0]} | {st.median(v[1] for v in vals):.3f} | {vals[0][2]} | "
              f"{st.median(v[3] for v in vals):.2f} |")
print()
table(load("verify.jsonl"), lambda r: (r["case"], r["variant"] + ("-noverify" if r["noverify"] else "")))
