import json, statistics as st, sys
from collections import defaultdict

g = defaultdict(list)
for line in open(sys.argv[1]):
    if line.startswith("{"):
        r = json.loads(line)
        if r.get("round", 1) != 0:
            g[(r.get("case", r.get("kind")), r.get("v", r.get("variant")))].append(r)
keys = [k for k in next(iter(g.values()))[0] if k not in ("round", "v", "variant", "case", "kind", "irispy", "n", "wa", "noverify", "masks", "timed", "cold")]
print("| case | v | runs | " + " | ".join(keys) + " | open_s all |")
for k in sorted(g):
    rs = g[k]
    print(f"| {k[0]} | {k[1]} | {len(rs)} | " + " | ".join(f"{st.median(r[f] for r in rs):g}" for f in keys if f in rs[0])
          + " | " + ", ".join(f"{r['open_s']:.3f}" for r in rs) + " |")
