"""cProfile of CASE on whatever irispy is on the path: callers of numpy isin and astropy verify, cumulative s."""
import cProfile, glob, os, pstats, sys, time
case = sys.argv[1]
from glue_solar.sources.loaders import iris as L  # noqa
import irispy.io  # noqa  (imports outside the profile)
D = "/Users/nabil/DATA/IRIS"
f = lambda o: sorted(glob.glob(f"{D}/*{o}_raster/*.fits"))  # noqa
run = {"a": lambda: L.raster_data(f(4000255147)), "c": lambda: L.raster_data(f(3824262996), ["Mg II k 2796"]),
       "b": lambda: L.raster_data(f(3602506433), ["Si IV 1403"], stack=True)}[case]
p = cProfile.Profile(); t = time.perf_counter(); p.enable(); run(); p.disable(); dt = time.perf_counter() - t
st = pstats.Stats(p).stats
print(case, irispy.__version__, "open under profile", round(dt, 3))
for func, (cc, nc, tt, ct, callers) in st.items():
    if (func[2] == "isin" and "arraysetops" in func[0]) or (func[2] == "verify" and "fits/verify" in func[0]):
        for caller, (ccc, cnc, ctt, cct) in callers.items():
            print(f"  {func[2]} <- {os.path.basename(caller[0])}:{caller[1]} {caller[2]}: calls {cnc}, cum {cct:.3f} s")
