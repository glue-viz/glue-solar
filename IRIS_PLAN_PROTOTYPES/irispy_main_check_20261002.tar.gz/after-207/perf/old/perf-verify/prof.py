"""cProfile of glue-solar's raster_data on CASE (a, c, b): top functions by own time, and np.isin's callers."""
import cProfile, glob, io, pstats, sys

case = sys.argv[1]
from glue_solar.sources.loaders import iris as L  # noqa

D = "/Users/nabil/DATA/IRIS"
f = lambda o: sorted(glob.glob(f"{D}/*{o}_raster/*.fits"))  # noqa
run = {"a": lambda: L.raster_data(f(4000255147)), "c": lambda: L.raster_data(f(3824262996), ["Mg II k 2796"]),
       "b": lambda: L.raster_data(f(3602506433), ["Si IV 1403"], stack=True)}[case]
p = cProfile.Profile()
p.enable()
run()
p.disable()
s = io.StringIO()
st = pstats.Stats(p, stream=s)
st.sort_stats("tottime").print_stats(8)
st.print_callers(r"\(isin\)|HDUList.verify|\(verify\)")
print("\n".join(line for line in s.getvalue().splitlines() if line.strip())[:6000])
