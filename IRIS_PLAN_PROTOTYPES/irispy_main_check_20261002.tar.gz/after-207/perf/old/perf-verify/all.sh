#!/bin/sh
# round 0 warms the page cache (discarded); variants interleaved within each case
cd "$(dirname "$0")"
for r in 0 1 2 3 4 5; do
  for c in a c c_all d g b e_fits e_gz f_a f_c; do
    for v in 091 main fix dask wa; do
      case "$c,$v" in f_*,wa) continue ;; esac
      ./r.sh $v $c | sed "s/^{/{\"round\": $r, /" >> time.jsonl
    done
  done
done
for r in 1 2 3; do
  for c in a c e_fits e_gz; do
    for v in 091 main fix dask wa; do ./r.sh $v $c mem | sed "s/^{/{\"round\": $r, /" >> mem.jsonl; done
  done
done
echo done > all.done
