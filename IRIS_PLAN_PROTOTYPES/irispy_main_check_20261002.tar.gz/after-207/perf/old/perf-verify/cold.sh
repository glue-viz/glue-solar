#!/bin/sh
# Cold page cache without purge: a fresh APFS clone (cp -c) shares the blocks but has no cached pages.
S=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-main-check
H=$S/perf-verify
SRC=$(ls /Users/nabil/DATA/IRIS/*4000255147_raster/*.fits)
mkdir -p $H/cold
for r in 1 2 3; do
  for v in 091 main fix; do
    case $v in 091) IP="" ;; main) IP="$S/irispy:" ;; fix) IP="$S/perf/irispy-fix:" ;; esac
    D=$H/cold/c$r$v; mkdir -p $D; cp -c "$SRC" $D/
    env HOME="$(mktemp -d)" QT_QPA_PLATFORM=offscreen MPLBACKEND=agg MPLCONFIGDIR=$H/mpl PYTHONPATH="${IP}/Users/nabil/Git/glue-solar-accept" \
      /Users/nabil/mamba/envs/iris-plan/bin/python -B $H/one.py $v raster $D/*.fits 2>>$H/err.log | sed "s/^{/{\"round\": $r, \"cold\": true, /"
    rm -rf $D
  done
done
