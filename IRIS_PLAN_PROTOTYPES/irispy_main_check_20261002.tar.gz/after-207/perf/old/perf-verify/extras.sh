#!/bin/sh
# Extras after all.sh: 3602506433 every window stacked (one.py), A5 verify on/off, the bytes SJI path and the
# browser-with-quicklook case (the investigator's bench.py, re-run), interleaved, round 0 discarded.
S=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-main-check
H=$S/perf-verify
B99=$(ls /Users/nabil/DATA/IRIS/*3602506433_raster/*.fits)
ip() { case $1 in 091) echo "" ;; main) echo "$S/irispy:" ;; fix) echo "$S/perf/irispy-fix:" ;; dask) echo "$S/perf/irispy-dask:" ;; esac; }
py() { v=$1; shift; env HOME="$(mktemp -d)" QT_QPA_PLATFORM=offscreen MPLBACKEND=agg MPLCONFIGDIR=$H/mpl PYTHONPATH="$(ip $v)/Users/nabil/Git/glue-solar-accept" "$@" 2>>$H/err.log; }
cd $H
for r in 0 1 2 3 4; do
  for v in 091 main fix dask; do
    py $v /Users/nabil/mamba/envs/iris-plan/bin/python -B $H/one.py $v raster_stack $B99 | sed "s/^{/{\"round\": $r, /" >> b_all.jsonl
  done
  for v in 091 main; do
    for nv in "" 1; do
      py $v env NOVERIFY=$nv ROUND=$r /Users/nabil/mamba/envs/iris-plan/bin/python -B $S/perf/bench.py $v${nv:+-nov} b >> a5.jsonl
    done
  done
  for v in main fix; do
    py $v env ROUND=$r /Users/nabil/mamba/envs/iris-plan/bin/python -B $S/perf/bench.py $v e_bytes_gz >> sji4.jsonl
    py $v env ROUND=$r /Users/nabil/mamba/envs/iris-plan/bin/python -B $S/perf/bench.py $v e_irispy_gz >> sji4.jsonl
  done
  [ $r -le 3 ] && for v in 091 main; do
    py $v env ROUND=$r /Users/nabil/mamba/envs/iris-plan/bin/python -B $S/perf/bench.py $v a_ql >> aql.jsonl
  done
done
echo done > extras.done
