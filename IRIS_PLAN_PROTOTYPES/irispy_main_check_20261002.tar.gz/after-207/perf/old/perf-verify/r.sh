#!/bin/sh
# r.sh VARIANT CASE [mem]: one fresh process
S=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-main-check
case $1 in
  091) IP="" ;;
  main|wa) IP="$S/irispy:" ;;
  fix) IP="$S/perf/irispy-fix:" ;;
  dask) IP="$S/perf/irispy-dask:" ;;
esac
cd $S/perf-verify && env HOME="$(mktemp -d)" QT_QPA_PLATFORM=offscreen MPLBACKEND=agg MPLCONFIGDIR=$S/perf-verify/mpl \
  PYTHONPATH="${IP}/Users/nabil/Git/glue-solar-accept" /Users/nabil/mamba/envs/iris-plan/bin/python -B $S/perf-verify/vb.py "$@" 2>>$S/perf-verify/err.log
