"""python one.py VARIANT KIND PATH...: glue-solar raster_data of PATHs (KIND raster, or raster_stack for stack=True,
or vmmap: also print vmmap's resident split after gc). One JSON line: open s, peak RSS MB, kept RSS after gc."""
import gc, json, os, resource, subprocess, sys, threading, time

import psutil

variant, kind, *paths = sys.argv[1:]
from glue_solar.sources.loaders import iris as L  # noqa
import irispy.io  # noqa

proc = psutil.Process()
gc.collect()
rss0 = proc.memory_info().rss
peak = [rss0]
stop = threading.Event()


def sample():
    while not stop.is_set():
        peak[0] = max(peak[0], proc.memory_info().rss)
        time.sleep(0.001)


th = threading.Thread(target=sample, daemon=True)
th.start()
s0, m0 = psutil.cpu_times(), proc.cpu_times()
t = time.perf_counter()
out = L.raster_data(paths, stack=kind == "raster_stack")
dt = time.perf_counter() - t
s1, m1 = psutil.cpu_times(), proc.cpu_times()
stop.set()
th.join()
gc.collect()
MB = 2**20
row = {"v": variant, "kind": kind, "n": len(out), "open_s": round(dt, 3),
       "peak_rss": round((max(peak[0], resource.getrusage(resource.RUSAGE_SELF).ru_maxrss) - rss0) / MB),
       "rss_kept_gc": round((proc.memory_info().rss - rss0) / MB),
       "other_cores": round((sum(getattr(s1, k) - getattr(s0, k) for k in ("user", "system", "nice"))
                             - (m1.user - m0.user + m1.system - m0.system)) / dt, 2)}
print(json.dumps(row), flush=True)
if kind == "vmmap":
    res = subprocess.run(["vmmap", "-summary", str(os.getpid())], capture_output=True, text=True); text = res.stdout; print(res.returncode, res.stderr[:300], len(text))
    for line in text.splitlines():
        if any(k in line for k in ("REGION TYPE", "mapped file", "MALLOC_LARGE", "MALLOC_MEDIUM", "MALLOC_SMALL", "TOTAL", "Physical footprint", "VM_ALLOCATE", "MALLOC ")):
            print(line)
sys.stdout.flush(); os._exit(0)
