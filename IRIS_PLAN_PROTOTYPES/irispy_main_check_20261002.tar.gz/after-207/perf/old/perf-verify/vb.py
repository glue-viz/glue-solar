"""Independent re-measure: python vb.py VARIANT CASE [mem]. One open in this fresh process, one JSON line.

time mode: wall time of the open, peak RSS (1 ms psutil sampler + ru_maxrss) over the post-import baseline,
other cores busy. mem mode: tracemalloc peak and kept (NumPy allocations), RSS kept before/after gc.collect().
"""
import gc, glob, json, os, resource, sys, threading, time

import psutil

variant, case = sys.argv[1:3]
mem = len(sys.argv) > 3
D = "/Users/nabil/DATA/IRIS"
HERE = os.path.dirname(os.path.abspath(__file__))
SJI_GZ = glob.glob(f"{D}/*4000255147_SJI_1400_t000.fits.gz")[0]
SJI_FITS = f"{HERE}/../perf/iris_l2_20130902_163935_4000255147_SJI_1400_t000.fits"


def files(obsid):
    return sorted(glob.glob(f"{D}/*{obsid}_raster/*.fits"))


import numpy as np  # noqa
import irispy  # noqa
from irispy.io import read_files  # noqa
from glue_solar.sources.loaders import iris as L  # noqa

if variant == "wa":
    sys.path.insert(0, f"{HERE}/../perf")
    import wa

    wa.install()
    wa.wrap_loaders()

CASES = {
    "a": lambda: L.raster_data(files(4000255147)),
    "b": lambda: L.raster_data(files(3602506433), ["Si IV 1403"], stack=True),
    "c": lambda: L.raster_data(files(3824262996), ["Mg II k 2796"]),
    "c_all": lambda: L.raster_data(files(3824262996)),
    "d": lambda: L.raster_data(files(4000005156)[:1]),
    "g": lambda: L.raster_data(files(3400109360)[:1]),
    "e_gz": lambda: [L.image_data(SJI_GZ)],
    "e_fits": lambda: [L.image_data(SJI_FITS)],
    "f_a": lambda: read_files(files(4000255147), memmap=True),
    "f_c": lambda: read_files(files(3824262996), spectral_windows=["Mg II k 2796"], memmap=True),
}
proc = psutil.Process()
gc.collect()
rss0 = proc.memory_info().rss
peak = [rss0]
stop = threading.Event()


def sample():
    while not stop.is_set():
        peak[0] = max(peak[0], proc.memory_info().rss)
        time.sleep(0.001)


if mem:
    import tracemalloc

    tracemalloc.start()
th = threading.Thread(target=sample, daemon=True)
th.start()
s0, m0 = psutil.cpu_times(), proc.cpu_times()
t = time.perf_counter()
out = CASES[case]()
dt = time.perf_counter() - t
s1, m1 = psutil.cpu_times(), proc.cpu_times()
stop.set()
th.join()
MB = 2**20
row = {"v": variant, "case": case, "irispy": irispy.__version__, "open_s": round(dt, 3),
       "peak_rss": round((max(peak[0], resource.getrusage(resource.RUSAGE_SELF).ru_maxrss) - rss0) / MB),
       "other_cores": round((sum(getattr(s1, k) - getattr(s0, k) for k in ("user", "system", "nice"))
                             - (m1.user - m0.user + m1.system - m0.system)) / dt, 2)}
if mem:
    cur, pk = tracemalloc.get_traced_memory()
    row["tm_peak"], row["tm_kept"] = round(pk / MB), round(cur / MB)
    row["rss_kept"] = round((proc.memory_info().rss - rss0) / MB)
    gc.collect()
    row["tm_kept_gc"] = round(tracemalloc.get_traced_memory()[0] / MB)
    row["rss_kept_gc"] = round((proc.memory_info().rss - rss0) / MB)
print(json.dumps(row), flush=True)
os._exit(0)
