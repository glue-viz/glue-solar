"""irispy-dask: does SJICube.apply_dust_mask (irispy/sji.py:128-137) work on the lazy memmap mask? And on main?"""
import numpy as np
import irispy
from irispy.data.test import get_test_filepath
from irispy.io.sji import read_sji_lvl2

f = get_test_filepath("bursts/iris_l2_20130902_163935_4000255147_SJI_1400_t000_test.fits")
eager = read_sji_lvl2(f, memmap=True)
print(irispy.__file__, type(eager.mask).__name__)
before = np.asarray(eager.mask).copy()
try:
    eager.apply_dust_mask()
    after = np.asarray(eager.mask)
    print("apply ok", type(eager.mask).__name__, "added", int(after.sum() - before.sum()))
    eager.apply_dust_mask(undo=True)
    print("undo ok", int(np.asarray(eager.mask).sum() - before.sum()))
except Exception as e:  # noqa
    print("apply failed:", type(e).__name__, e)
