import glob, gzip, io, resource, sys, time
import numpy as np
from irispy.io.sji import read_sji_lvl2
p = glob.glob("/Users/nabil/DATA/IRIS/534d789b*SJI_1400_t000.fits.gz")[0]
with gzip.open(p) as f:
    content = f.read()
b = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
t = time.perf_counter()
cube = read_sji_lvl2(content if sys.argv[1] == "bytes" else io.BytesIO(content), memmap=True, uncertainty=False)
dt = time.perf_counter() - t
print(sys.argv[1], "s", round(dt, 3), "rss rise MiB after decompression", round((resource.getrusage(resource.RUSAGE_SELF).ru_maxrss - b) / 2**20),
      "data shares the bytes:", np.shares_memory(cube.data, np.frombuffer(content, np.uint8)))
