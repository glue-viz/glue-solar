#!/bin/bash
# usage: run2.sh <env> <irispy dir or "base"> <label> <glue_solar_root> [pytest targets...]
S=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-main-check
P=/Users/nabil/Git/glue-solar/IRIS_PLAN_PROTOTYPES
ENV=$1; IRISPY=$2; LABEL=$3; G=$4; shift 4
if [ "$IRISPY" = base ]; then PATHS="$G:$P"; else PATHS="$IRISPY:$G:$P"; fi
T=${@:-$G/glue_solar}
cd $S/suite-verify
{ date; ps -Ao pcpu,comm -r | head -8; } > $LABEL.load
env HOME="$(mktemp -d)" QT_QPA_PLATFORM=offscreen MPLBACKEND=agg PYTHONPATH=$P /Users/nabil/mamba/envs/$ENV/bin/python -B $P/run_checks.py "$PATHS" $T --remote-data=any -rfEsw > $LABEL.log 2>&1
echo "EXIT $?" >> $LABEL.log
