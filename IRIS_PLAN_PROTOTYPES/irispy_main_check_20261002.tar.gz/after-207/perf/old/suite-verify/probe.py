"""Load one dataset through glue-solar's loaders in a fresh process; print one JSON line.

usage: probe.py CASE [mem]   (mem: also trace numpy allocations with tracemalloc; slower, no timing use)
"""
import glob, json, logging, os, resource, sys, time, warnings

D = "/Users/nabil/DATA/IRIS/"
V = os.path.dirname(os.path.abspath(__file__))
CASES = {
    "mg2-400": lambda: glob.glob(D + "c7600*_raster/*.fits"),
    "sns-raster": lambda: glob.glob(D + "2dd2d*_raster/*.fits"),
    "99-scans": lambda: glob.glob(D + "f783c*_raster/*.fits"),
    "neg-step": lambda: glob.glob(D + "38a343*_raster/*.fits"),
    "sji-1400": lambda: [V + "/data/iris_l2_20130902_163935_4000255147_SJI_1400_t000.fits"],
    "sji-1400-gz": lambda: glob.glob(D + "534d789b*SJI_1400_t000.fits.gz"),
    "aia-9": lambda: sorted(glob.glob(D + "df7fe*_SDO/*.fits")),
}
case = sys.argv[1]
mem = len(sys.argv) > 2
files = CASES[case]()
assert files, case

import irispy.io  # noqa
import glue_solar
from glue_solar.sources.loaders.iris import image_data, raster_data

records = []
class Keep(logging.Handler):
    def emit(self, record):
        records.append(f"{record.name}:{record.levelname}:{record.getMessage()[:120]}")
logging.getLogger().addHandler(Keep(logging.WARNING))
for name in ("irispy", "astropy", "sunpy", "ndcube", "glue"):
    logging.getLogger(name).addHandler(Keep(logging.WARNING))

if mem:
    import tracemalloc
    tracemalloc.start()
base = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
with warnings.catch_warnings(record=True) as caught:
    warnings.simplefilter("always")
    t0 = time.perf_counter()
    loaded = [image_data(p) for p in files] if case.startswith(("sji", "aia")) else raster_data(files)
    dt = time.perf_counter() - t0
peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
out = {"case": case, "irispy": os.path.dirname(irispy.__file__), "glue_solar": os.path.dirname(glue_solar.__file__),
       "s": round(dt, 3), "rss_rise_MiB": round((peak - base) / 2**20), "base_MiB": round(base / 2**20),
       "n": len(loaded), "warnings": sorted({f"{w.category.__name__}: {str(w.message)[:120]}" for w in caught}),
       "logs": sorted(set(records))}
if mem:
    out["traced_peak_MiB"] = round(tracemalloc.get_traced_memory()[1] / 2**20)
print(json.dumps(out))
