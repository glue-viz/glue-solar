import gc, glob, resource, sys, time
import irispy.io
from glue_solar.sources.loaders.iris import image_data
files = sorted(glob.glob("/Users/nabil/DATA/IRIS/df7fe*_SDO/*.fits"))
mode = sys.argv[1]
if mode == "nogc": gc.disable()
b = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
out = []
for p in files:
    out.append(image_data(p))
    if mode == "collect": gc.collect()
print(mode, irispy.__file__.split("/")[-3], "rss rise MiB", round((resource.getrusage(resource.RUSAGE_SELF).ru_maxrss - b) / 2**20))
