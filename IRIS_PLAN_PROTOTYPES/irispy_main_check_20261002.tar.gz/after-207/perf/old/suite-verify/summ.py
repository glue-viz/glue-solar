import json, statistics as st, collections, sys
g = collections.defaultdict(list)
for line in open(sys.argv[1]):
    r = json.loads(line)
    if "done" in r or r["round"] == 0 or not r["r"]:
        continue
    g[(r["r"]["case"], r["v"])].append(r)
for (case, v), rs in sorted(g.items()):
    s = [r["r"]["s"] for r in rs]; m = [r["r"]["rss_rise_MiB"] for r in rs]
    busy = [r["busy"]["sum"] for r in rs]
    extra = {k: rs[0]["r"][k] for k in ("traced_peak_MiB",) if k in rs[0]["r"]}
    warn = sorted({w for r in rs for w in r["r"]["warnings"] + r["r"]["logs"]})
    print(f"{case:12} {v:8} n={len(s)} s med {st.median(s):.3f} [{min(s):.3f}-{max(s):.3f}]  rss med {st.median(m):.0f} [{min(m)}-{max(m)}] MiB  others' CPU% {busy} {extra} {warn or ''}")
