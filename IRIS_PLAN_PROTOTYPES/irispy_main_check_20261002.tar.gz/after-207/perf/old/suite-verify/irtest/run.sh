#!/bin/bash
cd /private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-main-check/suite-verify/irtest/$1
env HOME="$(mktemp -d)" MPLBACKEND=agg MPLCONFIGDIR=$(mktemp -d) PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=$PWD /Users/nabil/mamba/envs/iris-plan/bin/python -B -m pytest irispy -q -p no:cacheprovider -o addopts= -m "not mpl_image_compare" -p no:unraisableexception -p no:threadexception > ../$1.log 2>&1
echo "EXIT $?" >> ../$1.log
