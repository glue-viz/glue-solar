import glob, resource, numpy as np, dask, dask.array as da
from astropy.io import fits
def rss(): return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 2**20
files = sorted(glob.glob("/Users/nabil/DATA/IRIS/0598*_raster/*.fits"))
h = fits.open(files[0], memmap=True, do_not_scale_image_data=True); d = h[1].data
print("window MiB", d.nbytes / 2**20, "dask", dask.__version__)
b = rss()
class View:  # not an ndarray, so dask slices it lazily
    def __init__(self, a): self.a, self.shape, self.dtype, self.ndim = a, a.shape, a.dtype, a.ndim
    def __getitem__(self, k): return self.a[k]
for name, src in (("wrapped", View(d)), ("asarray=False", d)):
    x = da.from_array(src, chunks=(1, *d.shape[1:]), name=False, **({"asarray": False} if name != "wrapped" else {}))
    m = da.isin(x, np.array([-32768., -32764.]))
    print(name, "rss rise after graph", round(rss() - b, 1))
m0 = m[0].compute(); print("one plane computed", round(rss() - b, 1), m0.shape)
