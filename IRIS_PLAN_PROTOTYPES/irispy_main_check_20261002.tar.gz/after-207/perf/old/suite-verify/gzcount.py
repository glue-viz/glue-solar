import glob, gzip, sys
total = [0]
orig = gzip._GzipReader.read
def read(self, size=-1):
    out = orig(self, size); total[0] += len(out); return out
gzip._GzipReader.read = read
import irispy
from glue_solar.sources.loaders.iris import image_data, iris_data
p = glob.glob("/Users/nabil/DATA/IRIS/534d789b*SJI_1400_t000.fits.gz")[0]
f = {"image_data": image_data, "iris_data": iris_data}[sys.argv[1]]
f(p)
print(sys.argv[1], irispy.__file__.split("/")[-3], "decompressed MB:", round(total[0] / 1e6, 1), "file MB 129.6")
if len(sys.argv) > 2:
    from irispy.io import read_files
    total[0] = 0; read_files(p, memmap=True); print("irispy read_files(.gz, memmap=True) decompressed MB:", round(total[0] / 1e6, 1))
