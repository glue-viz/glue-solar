#!/bin/bash
# usage: timing.sh OUT ROUNDS "cases" "variants"
S=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-main-check; V=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-main-check/suite-verify; G=/Users/nabil/Git/glue-solar-accept
cd $V
OUT=$1; ROUNDS=$2
for c in $3; do
  for r in $(seq 0 $ROUNDS); do   # round 0 warms the page cache and is dropped
    for v in $4; do
      case $v in main) PP=$S/irispy:$G;; base) PP=$G;; *) PP=$V/$v:$G;; esac
      busy=$(ps -Ao pid,pcpu,comm | awk -v me=$$ 'NR>1 && $1!=me {s+=$2; if ($2>20) t=t sprintf("%s:%.0f ", $3, $2)} END {printf "{\"sum\": %.0f, \"top\": \"%s\"}", s, t}')
      res=$(HOME=$(mktemp -d) QT_QPA_PLATFORM=offscreen MPLBACKEND=agg MPLCONFIGDIR=$V/mpl PYTHONPATH=$PP /Users/nabil/mamba/envs/iris-plan/bin/python -B probe.py $c $5 2>>$V/probe.err | tail -1)
      echo "{\"round\": $r, \"v\": \"$v\", \"busy\": $busy, \"r\": ${res:-null}}" >> $OUT
    done
  done
done
echo '{"done": 1}' >> $OUT
