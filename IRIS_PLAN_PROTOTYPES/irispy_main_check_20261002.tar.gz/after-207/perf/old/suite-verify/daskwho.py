import glob, resource, traceback
import dask.array as da
seen = set()
orig = da.Array.__array__
def arr(self, *a, **k):
    stack = "".join(traceback.format_stack(limit=12)[:-1])
    if stack not in seen:
        seen.add(stack); print("=== dask array materialised, shape", self.shape, "\n", stack)
    return orig(self, *a, **k)
da.Array.__array__ = arr
import dask
ocomp = dask.base.compute
from glue_solar.sources.loaders.iris import raster_data
files = glob.glob("/Users/nabil/DATA/IRIS/0598*_raster/*.fits")
b = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
raster_data(files)
print("rss rise MiB", (resource.getrusage(resource.RUSAGE_SELF).ru_maxrss - b) / 2**20)
