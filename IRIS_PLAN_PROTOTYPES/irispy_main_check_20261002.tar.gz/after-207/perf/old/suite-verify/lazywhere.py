import glob, resource, sys
import numpy as np
def rss(): return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 2**20
import irispy.io.spectrograph as sp
from irispy.io import read_files
files = sorted(glob.glob("/Users/nabil/DATA/IRIS/0598*_raster/*.fits"))
b = rss()
if sys.argv[1] == "isin-only":
    import dask.array as da
    from astropy.io import fits
    h = fits.open(files[0], memmap=True, do_not_scale_image_data=True)
    d = h[1].data
    x = da.from_array(d, chunks=(1, *d.shape[1:]), name=False); print("from_array", rss() - b)
    m = da.isin(x, np.array([-32768., -32764.])); print("isin", rss() - b)
else:
    c = read_files(files[0], memmap=True, uncertainty=False); print("read_files", rss() - b)
    print(type(next(iter(c.values()))[0].mask))
