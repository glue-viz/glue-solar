import gc, glob
import irispy.io
from irispy.sji import AIACube
from glue_solar.sources.loaders.iris import image_data, raster_data
from irispy.spectrograph import SpectrogramCube
gc.disable()
d = image_data(sorted(glob.glob("/Users/nabil/DATA/IRIS/df7fe*_SDO/*.fits"))[3])
r = raster_data(sorted(glob.glob("/Users/nabil/DATA/IRIS/0598*_raster/*.fits"))[:1])
alive = lambda cls: [o for o in gc.get_objects() if type(o) is cls]
cubes, scans = alive(AIACube), alive(SpectrogramCube)
print("AIA cubes alive after image_data, before gc:", len(cubes), "raster cubes alive:", len(scans))
if cubes:
    c = cubes[0]
    print("referrers of the AIA cube:", sorted({type(x).__name__ for x in gc.get_referrers(c) if x is not cubes}))
del cubes, scans
print("collected:", gc.collect(), "AIA cubes alive after gc:", len(alive(AIACube)), "raster cubes:", len(alive(SpectrogramCube)))
