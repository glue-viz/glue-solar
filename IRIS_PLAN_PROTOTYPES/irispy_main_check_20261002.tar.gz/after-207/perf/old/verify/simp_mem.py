"""image_data(gz or fits) now vs the simplified flows, irispy main: python simp_mem.py <now|read_files|bytes> <path>"""
import ctypes, gc, gzip, json, os, sys, threading, time
lib = ctypes.CDLL("/usr/lib/libproc.dylib"); buf = ctypes.create_string_buffer(512)
def use():
    lib.proc_pid_rusage(os.getpid(), 4, buf); q = lambda o: int.from_bytes(buf.raw[o:o + 8], "little"); return q(64), q(72)
import irispy.io  # noqa
from irispy.io import read_files, read_sji_lvl2
from glue_solar.sources.loaders import iris as L
how, path = sys.argv[1:3]
gc.collect(); r0, f0 = use(); pk = [r0, f0]; stop = threading.Event()
def sample():
    while not stop.is_set():
        r, f = use(); pk[0] = max(pk[0], r); pk[1] = max(pk[1], f); time.sleep(0.0005)
th = threading.Thread(target=sample, daemon=True); th.start()
t = time.perf_counter()
if how == "now":
    d = L.image_data(path)
elif how == "read_files":
    cube = read_files(path, memmap=True)
    d = L._image_cube_data(cube, path, cube.data, L._raw_scaling(cube.meta))
else:  # own gunzip, bytes to irispy
    with gzip.open(path) as f:
        content = f.read()
    cube = read_sji_lvl2(content, memmap=True)
    d = L._image_cube_data(cube, path, cube.data, L._raw_scaling(cube.meta))
dt = time.perf_counter() - t
stop.set(); th.join(); gc.collect(); r1, f1 = use()
print(json.dumps({"how": how, "gz": path.endswith(".gz"), "s": round(dt, 3), "rss_pk_GB": round((pk[0] - r0) / 1e9, 3),
                  "fp_pk_GB": round((pk[1] - f0) / 1e9, 3), "fp_kept_GB": round((f1 - f0) / 1e9, 3), "load1": round(os.getloadavg()[0], 2)}))
