"""Behaviour checks, irispy main or 0.9.1 depending on PYTHONPATH: python checks.py <name>"""
import glob, gzip, io, sys, time, warnings
import numpy as np
import astropy.units as u
from astropy.io import fits
import irispy
warnings.simplefilter("ignore")

D = "/Users/nabil/DATA/IRIS"
GZ = glob.glob(f"{D}/*4000255147_SJI_1400_t000.fits.gz")[0]
which = "main" if "irispy-main-check/irispy" in irispy.__file__ else "base"
name = sys.argv[1]

if name == "a1a2":  # SJI fill under memmap, gzip inflation
    inflated = [0]
    _read = gzip._GzipReader.read
    def read(self, size=-1):
        out = _read(self, size); inflated[0] += len(out); return out
    gzip._GzipReader.read = read
    from irispy.io import read_files
    t = time.perf_counter()
    cube = read_files(GZ, memmap=True)
    dt = time.perf_counter() - t
    d = np.asarray(cube.data)
    m = cube.mask
    print(which, "dtype", d.dtype, "n-32768", int((d == -32768).sum()), "n-32764", int((d == -32764).sum()),
          "n0", int((d == 0).sum()), "mask", None if m is None or np.ndim(m) == 0 else int(np.sum(m)),
          "scaled", cube.meta.get("scaled"), "inflated_MB", round(inflated[0] / 2**20, 1), "s", round(dt, 2))
    with gzip.open(GZ) as f:
        raw = fits.open(io.BytesIO(f.read()), do_not_scale_image_data=True)[0].data
    print("file: n-32768", int((raw == -32768).sum()), "n-32764", int((raw == -32764).sum()), "n0", int((raw == 0).sum()))

elif name == "a7":  # check_scaled and the unchecked functions
    from irispy.io import read_files
    from irispy.utils._spectral import check_scaled
    from irispy.utils.dust import remove_dust
    from irispy.utils.spectrograph import radiometric_calibration
    cube = read_files(GZ, memmap=True)
    for flag in (cube.meta.get("scaled"), True):
        cube.meta["scaled"] = flag
        try:
            check_scaled(cube); print(which, "check_scaled scaled=", flag, "-> passes")
        except ValueError as e:
            print(which, "check_scaled scaled=", flag, "-> raises", e)
    small = cube[:3, :60, :60]
    small.meta["scaled"] = False
    try:
        out = remove_dust(small); print(which, "remove_dust on raw: no error; out min/max", np.nanmin(out.data), np.nanmax(out.data), "unit", out.unit)
    except Exception as e:
        print(which, "remove_dust raises", type(e).__name__, e)
    rf = sorted(glob.glob(f"{D}/*4000005156_raster/*.fits"))[0]
    sp = read_files(rf, spectral_windows=["Si IV 1403"], memmap=True)["Si IV 1403"][0]
    print(which, "raster meta scaled key:", sp.meta.get("scaled", "<absent>"), "dtype", sp.data.dtype)
    try:
        check_scaled(sp); print(which, "raster check_scaled passes")
    except ValueError as e:
        print(which, "raster check_scaled raises")
    try:
        rc = radiometric_calibration(sp[:2]); print(which, "radiometric_calibration on raw: median", np.nanmedian(rc.data), rc.unit)
    except Exception as e:
        print(which, "radiometric_calibration raises", type(e).__name__, e)
    eager = read_files(rf, spectral_windows=["Si IV 1403"], memmap=False)["Si IV 1403"][0]
    rc = radiometric_calibration(eager[:2]); print(which, "radiometric_calibration on eager: median", np.nanmedian(rc.data))

elif name == "a3":  # -199 in the dust mask
    from irispy.utils import calculate_dust_mask
    a = np.full((5, 5), 100.0); a[2, 2] = -199; a[0, 0] = -200
    m = calculate_dust_mask(a)
    print(which, "dust mask at -199:", bool(m[2, 2]), "at -200:", bool(m[0, 0]))

elif name == "simplify":  # item (2)1: image_data from irispy's memmap cube alone
    from glue_solar.sources.loaders import iris as L
    from irispy.io import read_files
    plain = sys.argv[2]
    for path in (plain, GZ):
        ref = L.image_data(path)
        cube = read_files(path, memmap=True)
        scaling = L._raw_scaling(cube.meta)
        new = L._image_cube_data(cube, path, cube.data, scaling)
        same = [cid.label for cid in new.components] == [cid.label for cid in ref.components]
        frames = sorted({0, 100, ref.shape[0] // 2, ref.shape[0] - 1})
        for cid, rcid in zip(new.components, ref.components):
            a, b = new[cid], ref[rcid]
            if a.ndim == 3:
                a, b = a[list(frames)], b[list(frames)]
            same &= bool(np.array_equal(np.asarray(a), np.asarray(b), equal_nan=a.dtype.kind == "f"))
        print(which, path.rsplit(".", 1)[-1], "scaling", scaling, "identical:", same, ref.label == new.label)

elif name == "moments":  # all-fill pixels and +Inf
    from irispy.io import read_files
    from irispy.utils.moments import calculate_moments
    rf = sorted(glob.glob(f"{D}/*4000005156_raster/*.fits"))[0]
    cube = read_files(rf, spectral_windows=["C II 1336"], memmap=False)["C II 1336"][0]
    allfill = np.all(cube.mask, axis=-1)
    m = calculate_moments(cube, rest_wavelength=1335.708 * u.AA, wings=0.5 * u.AA)
    I, C = m["intensity"], m["centroid"]
    print(which, "all-fill pixels", int(allfill.sum()), "intensity there: unique", np.unique(I.data[allfill])[:5],
          "masked", bool(np.all(I.mask[allfill])) if I.mask is not None else None, "centroid NaN", bool(np.all(np.isnan(C.data[allfill]))))
    sub = cube[:4]
    data = np.array(sub.data, copy=True)
    j = np.argwhere(~np.all(sub.mask, axis=-1) & (np.nanmax(data, axis=-1) < 1e4))[0]
    k = int(np.argmin(np.abs(sub.axis_world_coords(2)[0].to_value(u.AA) - 1335.708)))
    data[tuple(j) + (k,)] = np.inf
    from irispy.spectrograph import SpectrogramCube
    s2 = SpectrogramCube(data, sub.wcs, unit=sub.unit, meta=sub.meta, mask=sub.mask)
    m2 = calculate_moments(s2, rest_wavelength=1335.708 * u.AA, wings=0.5 * u.AA, saturation_limit=1e4 * sub.unit)
    print(which, "Inf pixel intensity with saturation_limit:", m2["intensity"].data[tuple(j)])
