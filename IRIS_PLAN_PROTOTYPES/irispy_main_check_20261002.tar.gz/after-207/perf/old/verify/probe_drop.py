"""One glue-solar lazy open in a fresh process: python probe.py <case>; one JSON line.
Footprint (anonymous+compressed, excludes clean file pages) and RSS sampled every 0.5 ms via proc_pid_rusage."""
import ctypes, gc, glob, json, os, sys, threading, time

D = "/Users/nabil/DATA/IRIS"
CASES = {
    "r4000005156": ("raster", sorted(glob.glob(f"{D}/*4000005156_raster/*.fits"))),
    "r3824262996": ("raster", sorted(glob.glob(f"{D}/*3824262996_raster/*.fits"))),
    "r4000255147": ("raster", sorted(glob.glob(f"{D}/*4000255147_raster/*.fits"))),
    "r3610108077": ("raster", sorted(glob.glob(f"{D}/*3610108077_raster/*.fits"))),
    "s3602506433": ("stack", sorted(glob.glob(f"{D}/*3602506433_raster/*.fits"))),
    "sji1400gz": ("image", glob.glob(f"{D}/*4000255147_SJI_1400_t000.fits.gz")),
}
lib = ctypes.CDLL("/usr/lib/libproc.dylib")
buf = ctypes.create_string_buffer(512)
def use():
    assert lib.proc_pid_rusage(os.getpid(), 4, buf) == 0
    q = lambda o: int.from_bytes(buf.raw[o:o + 8], "little")
    return q(64), q(72), q(144)  # rss, phys_footprint, diskio_bytesread

case = sys.argv[1]
kind, files = CASES[case]
import irispy, irispy.io  # noqa
from glue_solar.sources.loaders import iris as L
L.LAZY = True
import irispy.io as _io
_rf = _io.read_files
def _read(*a, **k):
    out = _rf(*a, **k)
    for seq in out.values():
        for c in seq:
            c._mask = None
    return out
if os.environ.get("DROPMASK") == "1": _io.read_files = _read
gc.collect()
rss0, fp0, disk0 = use()
pk = [rss0, fp0]; stop = threading.Event()
def sample():
    while not stop.is_set():
        r, f, _ = use(); pk[0] = max(pk[0], r); pk[1] = max(pk[1], f); time.sleep(0.0005)
th = threading.Thread(target=sample, daemon=True); th.start()
t = time.perf_counter()
ds = [L.image_data(files[0])] if kind == "image" else L.raster_data(files, stack=kind == "stack")
dt = time.perf_counter() - t
stop.set(); th.join(); gc.collect()
rss1, fp1, disk1 = use()
el = sum(d.size for d in ds)
G = 1e9
print(json.dumps({"case": case, "irispy": irispy.__file__.split("/")[-3], "el_M": round(el / 1e6, 1), "s": round(dt, 3),
                  "fp_pk_GB": round((pk[1] - fp0) / G, 3), "fp_pk_B_el": round((pk[1] - fp0) / el, 2),
                  "fp_kept_GB": round((fp1 - fp0) / G, 3), "rss_pk_GB": round((pk[0] - rss0) / G, 3),
                  "rss_kept_GB": round((rss1 - rss0) / G, 3), "disk_GB": round((disk1 - disk0) / G, 3),
                  "load1": round(os.getloadavg()[0], 2)}))
