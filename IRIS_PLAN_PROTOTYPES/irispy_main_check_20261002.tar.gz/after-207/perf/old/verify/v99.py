"""99 files of 3602506433 read one by one, memmap=True (as glue-solar does); argv[1]=1 drops verify. Median of 3."""
import glob, os, statistics, sys, time
from astropy.io import fits
import irispy, irispy.io
if sys.argv[1] == "1":
    fits.HDUList.verify = lambda self, *a, **k: None
files = sorted(glob.glob("/Users/nabil/DATA/IRIS/*3602506433_raster/*.fits"))
ts = []
for _ in range(3):
    t = time.perf_counter()
    for f in files:
        irispy.io.read_files([f], memmap=True, uncertainty=False)
    ts.append(time.perf_counter() - t)
print(irispy.__file__.split("/")[-3], "noverify", sys.argv[1], round(statistics.median(ts), 2), [round(x, 2) for x in ts], "load", round(os.getloadavg()[0], 1))
