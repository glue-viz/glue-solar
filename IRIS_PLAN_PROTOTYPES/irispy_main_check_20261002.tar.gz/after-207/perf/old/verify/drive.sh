#!/bin/bash
# drive.sh <reps> <case...>: interleaved base/main/nomask, fresh process each; JSON -> runs.jsonl, others' CPU -> cpu.log
V=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-main-check/verify
S=$(dirname $V)
G=/Users/nabil/Git/glue-solar-accept
PY=/Users/nabil/mamba/envs/iris-plan/bin/python
cd $V
N=$1; shift
for c in "$@"; do
  for r in $(seq $N); do
    for w in base main nomask; do
      case $w in base) PP=$G;; main) PP=$S/irispy:$G;; nomask) PP=$V/nomask:$G;; esac
      { date +%T; ps -Ao pcpu,comm -r | sed -n 2,7p | awk '{printf "%s %s; ", $1, $2}'; echo; } >> cpu.log
      env HOME="$(mktemp -d)" MPLCONFIGDIR=$V/mpl QT_QPA_PLATFORM=offscreen MPLBACKEND=agg PYTHONPATH=$PP $PY -B probe.py $c 2>>err.log \
        | sed "s/^{/{\"w\": \"$w\", /" | tee -a runs.jsonl
    done
  done
done
