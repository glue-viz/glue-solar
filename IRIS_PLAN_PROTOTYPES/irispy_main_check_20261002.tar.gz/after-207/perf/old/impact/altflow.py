"""glue-solar image_data now vs two simplifications irispy main allows: python altflow.py <now|read_files|bytes> <path>"""
import gc, gzip, json, os, sys, threading, time
import numpy as np, psutil
from mem import usage
import irispy
from irispy.io import read_files
from irispy.io.sji import read_sji_lvl2
from glue_solar.sources.loaders import iris as L
flow, path = sys.argv[1], sys.argv[2]

def alt(path):
    if flow == "read_files":
        cube = read_files(path, memmap=True, uncertainty=False)
    else:  # bytes: our one decompression, irispy parses the bytes in place
        with open(path, "rb") as f:
            gz = f.read(2) == b"\x1f\x8b"
        if gz:
            with gzip.open(path) as f:
                cube = read_sji_lvl2(f.read(), memmap=True, uncertainty=False)
        else:
            cube = read_files(path, memmap=True, uncertainty=False)
    scaling = L._raw_scaling(cube.meta)
    return L._image_cube_data(cube, path, cube.data if scaling else None, scaling)

proc = psutil.Process(); gc.collect(); u0 = usage(); rss0 = proc.memory_info().rss
peak = [rss0]; stop = threading.Event()
def sample():
    while not stop.is_set():
        peak[0] = max(peak[0], proc.memory_info().rss); time.sleep(0.001)
threading.Thread(target=sample, daemon=True).start()
t = time.perf_counter()
data = L.image_data(path) if flow == "now" else alt(path)
dt = time.perf_counter() - t
stop.set(); gc.collect(); u1 = usage()
science = data.main_components[0]
frames = data[science, (slice(0, 400, 57),)]
mask = data[data.id[f"{science.label} mask"], (slice(0, 400, 57),)]
np.save(f"alt_{flow}_{os.path.basename(path)[:40]}.npy", np.stack([np.nan_to_num(frames, nan=-1e9), mask]))
print(json.dumps({"flow": flow, "file": os.path.basename(path)[-40:], "s": round(dt, 3), "peak_rss_GB": round((max(peak[0], u1["maxrss"]) - rss0) / 1e9, 3),
                  "kept_fp_GB": round((u1["footprint"] - u0["footprint"]) / 1e9, 3), "type": type(data).__name__, "label": data.label, "load": round(os.getloadavg()[0], 1)}))
