import glob, warnings, numpy as np, astropy.units as u
warnings.simplefilter("ignore")
from irispy.io import read_files
from irispy.utils.moments import calculate_moments
f = sorted(glob.glob("/Users/nabil/DATA/IRIS/*4000005156_raster/*.fits"))[0]
cube = read_files([f], spectral_windows=["C II 1336"], memmap=False)["C II 1336"][0]
allfill = np.asarray(cube.mask).all(axis=-1)
print("all-fill pixels:", int(allfill.sum()), "of", allfill.size, "| raw values there", np.unique(cube.data[allfill])[:4])
m = calculate_moments(cube, rest_wavelength=133.5708 * u.nm, wings=0.05 * u.nm)
I = m["intensity"]
print("intensity over all-fill pixels: unique", np.unique(I.data[allfill])[:5], "masked", None if I.mask is None else bool(np.asarray(I.mask)[allfill].all()))
print("centroid over all-fill: all NaN", bool(np.isnan(m["centroid"].data[allfill]).all()))
cube.data[0, 400, 200] = np.inf
m2 = calculate_moments(cube, rest_wavelength=133.5708 * u.nm, saturation_limit=1e30)
print("pixel with +Inf sample, saturation_limit set: intensity", m2["intensity"].data[0, 400], "finite", bool(np.isfinite(m2["intensity"].data[0, 400])))
