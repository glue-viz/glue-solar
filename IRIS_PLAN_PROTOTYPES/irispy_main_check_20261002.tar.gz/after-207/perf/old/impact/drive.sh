#!/bin/bash
# drive.sh <reps> <case...>: interleaved base/main runs, one fresh process each, JSON to loads.jsonl, CPU of others to loads.cpu
S=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-main-check
cd $S/impact
PY=/Users/nabil/mamba/envs/iris-plan/bin/python
G=/Users/nabil/Git/glue-solar-accept
N=$1; shift
for c in "$@"; do
  cat /Users/nabil/DATA/IRIS/*4000255147_SJI_1400*.gz >/dev/null
  for r in $(seq $N); do
    for which in base main; do
      if [ $which = main ]; then PP=$S/irispy:$G; else PP=$G; fi
      { date +%T; ps -Ao pcpu,comm -r | sed -n 2,6p | tr '\n' ';'; echo; } >> loads.cpu
      env HOME="$(mktemp -d)" MPLCONFIGDIR=$S/impact/mplcfg QT_QPA_PLATFORM=offscreen MPLBACKEND=agg PYTHONPATH=$PP:$S/impact $PY -B load_probe.py $c 2>>loads.err | sed "s/^{/{\"which\": \"$which\", /" | tee -a loads.jsonl
    done
  done
done
