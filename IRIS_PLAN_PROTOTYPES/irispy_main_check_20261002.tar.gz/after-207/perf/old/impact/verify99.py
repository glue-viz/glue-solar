"""99 raster files read one by one with memmap=True, as glue-solar does: <noisin> <noverify>; median of 3 runs."""
import glob, mmap, os, statistics, sys, time
import numpy as np
from astropy.io import fits
import irispy.io, irispy.io.spectrograph as sp
noisin, noverify = sys.argv[1] == "1", sys.argv[2] == "1"
if noisin:
    real = np.isin
    class NP:
        def __getattr__(self, n): return getattr(np, n)
        @staticmethod
        def isin(a, b, **k):
            x = a
            while x is not None:
                if isinstance(x, (np.memmap, mmap.mmap)): return False
                x = getattr(x, "base", None)
            return real(a, b, **k)
    sp.np = NP()
if noverify:
    fits.HDUList.verify = lambda self, *a, **k: None
files = sorted(glob.glob("/Users/nabil/DATA/IRIS/*3602506433_raster/*.fits"))
ts = []
for _ in range(3):
    t = time.perf_counter()
    for f in files:
        irispy.io.read_files([f], memmap=True, uncertainty=False)
    ts.append(time.perf_counter() - t)
print(irispy.__version__[:12], "noisin", noisin, "noverify", noverify, round(statistics.median(ts), 2), [round(x, 2) for x in ts], "load", round(os.getloadavg()[0], 1))
