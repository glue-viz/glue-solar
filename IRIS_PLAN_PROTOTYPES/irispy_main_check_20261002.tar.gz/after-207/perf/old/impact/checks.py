import glob, warnings, numpy as np, irispy
warnings.simplefilter("ignore")
from irispy.io import read_files
from irispy.utils import calculate_dust_mask
from irispy.utils._spectral import check_scaled
from irispy.utils.dust import remove_dust
from irispy.utils.spectrograph import radiometric_calibration
print("irispy", irispy.__version__)
print("dust mask flags -199:", bool(calculate_dust_mask(np.full((3, 3), -199.0))[1, 1]), "| -200:", bool(calculate_dust_mask(np.full((3, 3), -200.0))[1, 1]))
sji = read_files(glob.glob(f"{__file__.rsplit('/',1)[0]}/data/*SJI_1400*.fits")[0], memmap=True)
print("memmap SJI dtype", sji.data.dtype, "meta scaled", sji.meta.get("scaled"), "mask", None if sji.mask is None else sji.mask.dtype)
for flag in (None, True):
    if flag: sji.meta["scaled"] = True  # as glue-solar's _image_cube_data does
    try:
        check_scaled(sji); print(f"check_scaled with meta scaled={sji.meta.get('scaled')}: passes")
    except ValueError as e:
        print(f"check_scaled with meta scaled={sji.meta.get('scaled')}: raises {e}")
small = sji[0:3, 300:340, 300:340]
try:
    out = remove_dust(small); print("remove_dust on raw int16 memmap slice: no error; input range", int(small.data.min()), int(small.data.max()), "-> output", float(np.nanmin(out.data)), float(np.nanmax(out.data)))
except Exception as e:
    print("remove_dust raises", type(e).__name__, e)
r = read_files(sorted(glob.glob("/Users/nabil/DATA/IRIS/*4000005156_raster/*.fits"))[:1], spectral_windows=["Si IV 1403"], memmap=True)["Si IV 1403"][0]
print("memmap raster dtype", r.data.dtype, "meta scaled", r.meta.get("scaled"), "BSCALE" in r.meta)
try:
    check_scaled(r); print("raster check_scaled passes")
except ValueError as e:
    print("raster check_scaled raises:", e)
try:
    out = radiometric_calibration(r[0:2, 300:310]); print("radiometric_calibration on raw int16: no error; out unit", out.unit, "max", float(np.nanmax(out.data)))
except Exception as e:
    print("radiometric_calibration raises", type(e).__name__, str(e)[:200])
