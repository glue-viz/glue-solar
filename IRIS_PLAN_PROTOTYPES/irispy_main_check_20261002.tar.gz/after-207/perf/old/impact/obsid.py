import time, json, irispy
from irispy.obsid import ObsID
ids = [4000255147, 4000005156, 3824262996, 3610108077, 3400109360, 3602506433, 3860258481, 3880012095, 3660259102, 3640107442, 3620258102]
t = time.perf_counter(); out = {}
for i in ids:
    try:
        o = ObsID(i); out[i] = (o["raster_fulldesc"], sorted((k, str(v)) for k, v in o.items()))
    except Exception as e:
        out[i] = repr(e)
dt = time.perf_counter() - t
print(irispy.__version__[:6], round(dt, 3)); json.dump(out, open(f"obsid_{"main" if "post" in irispy.__version__ else "base"}.json", "w"), default=str)
