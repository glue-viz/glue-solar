#!/bin/sh
# acceptance.sh time OBSID [ROUNDS=6] | memory OBSID | crash OBSID [RUNS=20]
# Every process gets a scratch HOME, offscreen Qt and Agg, with its cwd here; TREE= picks the checkout under
# test, WINDOW= another raster window for time and crash, CYCLES= quicklook cycles per crash process (1).
# JSON lines are appended to out/OBSID_MODE.jsonl (delete it to start over; the summary pools per window),
# stderr to out/OBSID_MODE.err; every mode ends with the pooled budget summary of that file.
P=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/accept/probe
PY=~/mamba/envs/iris-plan/bin/python
TREE=${TREE:-/Users/nabil/Git/glue-solar-wp4-tests}
MODE=$1 OBS=$2 N=$3
mkdir -p "$P/out_pr0"
OUT="$P/out_pr0/${OBS}_$MODE.jsonl"
run() {
  H=$(mktemp -d "$P/home.XXXXXX"); mkdir -p "$H/cache" "$H/config" "$H/sunpy"
  (cd "$P" && env HOME="$H" MPLCONFIGDIR="$P/mplcfg" XDG_CACHE_HOME="$H/cache" XDG_CONFIG_HOME="$H/config" \
    SUNPY_CONFIGDIR="$H/sunpy" QT_QPA_PLATFORM=offscreen MPLBACKEND=agg PYTHONDONTWRITEBYTECODE=1 \
    $PY -B "$P/acceptance_probe.py" "$TREE" "$@" 2>>"$P/out_pr0/${OBS}_$MODE.err")
  rc=$?
  rm -rf "$H"
  [ $rc -eq 0 ] || echo "{\"mode\": \"$1\", \"obs\": \"$OBS\", \"exit\": $rc}"
}
echo "{\"tree\": \"$TREE\", \"rev\": \"$(git -C "$TREE" rev-parse HEAD)\", \"started\": \"$(date +%FT%T)\", \"window\": \"$WINDOW\"}" >>"$OUT"
cat /Users/nabil/DATA/IRIS/*_${OBS}_raster/*.fits /Users/nabil/DATA/IRIS/*_${OBS}_SJI_*.fits.gz >/dev/null 2>&1  # warm cache
case $MODE in
  time)
    r=0
    while [ $r -lt "${N:-6}" ]; do run ql "$OBS"; run image "$OBS"; r=$((r + 1)); done | tee -a "$OUT" | cut -c1-300;;
  memory) run memory "$OBS" | tee -a "$OUT";;
  crash)  # one process per run, so a segfault or hang ends that run only
    r=0
    while [ $r -lt "${N:-20}" ]; do run crash "$OBS" "${CYCLES:-1}"; r=$((r + 1)); done | tee -a "$OUT" | cut -c1-300;;
  *) echo "usage: $0 time|memory|crash OBSID [N]"; exit 2;;
esac
(cd "$P" && $PY -B "$P/acceptance_probe.py" summary "$OUT")
