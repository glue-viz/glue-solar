#!/bin/sh
# run.sh SCRIPT ARGS... : one fresh process from this directory, scratch HOME, offscreen Qt, the branch's glue_solar
C=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/lazy-impl/check
H=$(mktemp -d "$C/home.XXXXXX")
cd "$C" && env HOME="$H" MPLCONFIGDIR="$H/mpl" QT_QPA_PLATFORM=offscreen MPLBACKEND=agg PYTHONPATH="${TREE:-/Users/nabil/Git/glue-solar-lazy-loading}:$C" \
  /Users/nabil/mamba/envs/iris-plan/bin/python -B "$@"
rc=$?
rm -rf "$H"
exit $rc
