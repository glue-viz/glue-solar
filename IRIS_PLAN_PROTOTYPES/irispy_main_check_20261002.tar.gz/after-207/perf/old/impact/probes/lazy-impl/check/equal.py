"""
Lazy (LAZY on) against eager (LAZY off) loading of the branch's glue_solar, one dataset at a time: every value and NaN
(glue views of 32 leading planes), the mask, glue's fixed-resolution buffers of every pair of axes (values and mask,
native and resampled), Time and Exposure time, units, component labels, and the 99.5 % limits (glue's call) against
the exact percentiles of every finite eager value, as % of each value.

python equal.py raster FILE...      every window of each file, per scan (File -> Open)
python equal.py stack WINDOW FILE...  the stack of FILEs (browser, stack ticked)
python equal.py image FILE...       SJI or AIA cubes
One JSON line per dataset.
"""

import gc
import json
import sys
import time
from itertools import combinations

import numpy as np

from glue_solar.sources.loaders import iris as L
from glue_solar.sources.loaders.lazy import RawComponent


def load(lazy, fn):
    L.LAZY = lazy
    try:
        return fn()
    finally:
        L.LAZY = True


def compare(d, e):
    out = {"label": d.label, "shape": d.shape, "raw": isinstance(d.get_component(d.main_components[0]), RawComponent)}
    cid, mcid = d.main_components[0], d.derived_components[0]
    ecid, emcid = e.main_components[0], e.main_components[1]
    out["labels_equal"] = [c.label for c in d.components] == [c.label for c in e.components] and d.label == e.label
    out["units_equal"] = d.get_component(cid).units == e.get_component(ecid).units
    values = mask = True
    nan = 0
    t = time.perf_counter()
    for a in range(0, d.shape[0], 32):
        view = (slice(a, a + 32),)
        v = d[cid, view]
        nan += int(np.isnan(v).sum())
        values &= np.array_equal(v, e[ecid, view], equal_nan=True)
        m = d[mcid, view]
        mask &= m.dtype == np.uint8 and np.array_equal(m, e[emcid, view])
    out.update(values=bool(values), mask=bool(mask), nan=nan, views_s=round(time.perf_counter() - t, 2))
    frb = True
    for axes in combinations(range(d.ndim), 2):
        native = [(0, n - 1, n) if i in axes else n // 2 for i, n in enumerate(d.shape)]
        resampled = [(0, n - 1, max(2, n // 3 + 1)) if i in axes else n // 3 for i, n in enumerate(d.shape)]
        for bounds in (native, resampled):
            for a, b in ((cid, ecid), (mcid, emcid)):
                frb &= np.array_equal(d.compute_fixed_resolution_buffer(bounds, target_cid=a),
                                      e.compute_fixed_resolution_buffer(bounds, target_cid=b), equal_nan=True)
    out["frb"] = bool(frb)
    out["time_exposure"] = all(np.array_equal(d[n], e[n]) for n in ("Time", "Exposure time"))
    t = time.perf_counter()
    limits = [d.compute_statistic("percentile", cid, percentile=p, random_subset=10000) for p in (0.25, 99.75)]
    out["limits_s"] = round(time.perf_counter() - t, 2)
    ev = e.get_component(ecid).data
    exact = [float(np.nanpercentile(ev, p)) for p in (0.25, 99.75)]
    out.update(limits=limits, exact=exact,
               err_pct_value=[round(100 * abs(a - b) / max(abs(b), 1e-30), 3) for a, b in zip(limits, exact)])
    return out


mode, args = sys.argv[1], sys.argv[2:]
if mode == "raster":
    for path in args:
        for d in load(True, lambda: L.iris_data(path)):
            window = d.label.split("-")[0].replace("_", " ")
            [e] = load(False, lambda: L.raster_data([path], [window]))
            e.label = d.label  # File -> Open's raster number
            print(json.dumps({"file": path.rsplit("/", 1)[-1][-11:-5], **compare(d, e)}), flush=True)
            del e
            gc.collect()
elif mode == "stack":
    window, files = args[0], args[1:]
    [d] = load(True, lambda: L.raster_data(files, [window], stack=True))
    [e] = load(False, lambda: L.raster_data(files, [window], stack=True))
    print(json.dumps(compare(d, e)), flush=True)
else:
    for path in args:
        d, e = load(True, lambda: L.image_data(path)), load(False, lambda: L.image_data(path))
        print(json.dumps({"file": path.rsplit("/", 1)[-1], "scaled": d.meta["scaled"], **compare(d, e)}), flush=True)
        del d, e
        gc.collect()
