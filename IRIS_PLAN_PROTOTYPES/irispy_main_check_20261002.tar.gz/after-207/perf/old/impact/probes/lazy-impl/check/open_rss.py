"""Peak memory of lazily (or eagerly) opening every window of one observation, no viewer.

python open_rss.py <lazy|eager> <open|browser> <obsid>. One case per fresh process; prints one JSON line.
Baseline is taken after imports and gc.collect(). Peak RSS: psutil RSS sampled every 1 ms in a thread
and ru_maxrss (bytes on macOS); footprint: proc_pid_rusage v4 phys_footprint and its lifetime max.
"""
import gc, glob, json, os, sys, threading, time

import psutil
from mem import usage
from glue_solar.sources.loaders import iris as L
from glue_solar.sources.loaders.scan import scan_directory

mode, path, obsid = sys.argv[1:4]
L.LAZY = mode == "lazy"
files = sorted(glob.glob(f"/Users/nabil/DATA/IRIS/*{obsid}_raster/*.fits"))


def run():
    if path == "open":
        return [d for f in files for d in L.iris_data(f)]
    [obs] = scan_directory(os.path.dirname(files[0]), recursive=False)
    return [d for w in obs.windows for d in L.load_entry(obs, "raster", w)]


proc = psutil.Process()
gc.collect()
u0 = usage(); rss0 = proc.memory_info().rss
peak = [rss0]; stop = threading.Event()
def sample():
    while not stop.is_set():
        peak[0] = max(peak[0], proc.memory_info().rss); time.sleep(0.001)
th = threading.Thread(target=sample, daemon=True); th.start()
t = time.perf_counter(); datasets = run(); dt = time.perf_counter() - t
stop.set(); th.join()
gc.collect()
u1 = usage()
GB = 1e9
print(json.dumps({"mode": mode, "path": path, "obsid": obsid, "n_data": len(datasets),
                  "elements_M": round(sum(d.size for d in datasets) / 1e6, 1), "load_s": round(dt, 2),
                  "baseline_rss_GB": round(rss0 / GB, 3), "peak_rss_GB": round(max(peak[0], u1["maxrss"]) / GB, 3),
                  "peak_rss_delta_GB": round((max(peak[0], u1["maxrss"]) - rss0) / GB, 3),
                  "kept_rss_delta_GB": round((u1["rss"] - rss0) / GB, 3),
                  "peak_footprint_delta_GB": round((u1["max_footprint"] - u0["footprint"]) / GB, 3),
                  "open_files": len(proc.open_files())}))
