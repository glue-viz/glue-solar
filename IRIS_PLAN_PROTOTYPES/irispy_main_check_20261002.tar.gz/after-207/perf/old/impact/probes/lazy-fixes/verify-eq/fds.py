"""The observation browser on 4000255147 with three raster windows ticked: open files before and after, and values."""
import sys
from pathlib import Path

import numpy as np
import psutil
from qtpy.QtCore import QSettings, Qt
from glue_qt.utils import get_qapp

from glue_solar.sources.loaders import iris

FOLDER = "/Users/nabil/DATA/IRIS/2dd2d12db374b3466aa27a65bec235d3-iris_l2_20130902_163935_4000255147_raster"
WINDOWS = ["C II 1336", "Si IV 1403", "Mg II k 2796"]
ini = Path(__file__).with_name("settings.ini")
iris.QSettings = lambda *args: QSettings(str(ini), QSettings.IniFormat)  # macOS would write ~/Library/Preferences

app = get_qapp()
process = psutil.Process()
dialog = iris.QtIRISImporter(FOLDER)
dialog.stack.setChecked(len(sys.argv) > 1)
row = dialog.obs_tree.topLevelItem(0)
ticked = []
for i in range(row.childCount()):
    child = row.child(i)
    if child.text(0).split(" — ")[0] in WINDOWS:
        child.setCheckState(0, Qt.Checked)
        ticked.append(child.text(0))
before, maps_before = process.num_fds(), sum('raster_t000' in f.path for f in process.open_files())
dialog.finalize()
after, maps_after = process.num_fds(), sum('raster_t000' in f.path for f in process.open_files())
print("ticked", ticked, "progress:", dialog.progress.format())
print(f"open fds {before} -> {after} (+{after - before}); the raster file open {maps_before} -> {maps_after} times")
print("loaded", [(name, [type(d).__name__ for d in datasets]) for _, _, name, datasets in dialog.loaded])
# the browser's datasets against eager loading of the same windows
iris.LAZY = False
for _, _, name, [data] in dialog.loaded:
    [eager] = iris.raster_data([next(Path(FOLDER).glob("*.fits"))], [name])
    cid = data.main_components[0]
    np.testing.assert_array_equal(np.asarray(data[cid]), eager[eager.main_components[0]])
    np.testing.assert_array_equal(np.asarray(data[data.derived_components[0]]), eager[f"{eager.label} mask"])
    print(name, "equal to eager")
