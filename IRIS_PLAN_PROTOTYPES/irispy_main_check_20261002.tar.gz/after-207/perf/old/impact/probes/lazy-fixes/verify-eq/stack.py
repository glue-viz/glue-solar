"""A lazy stack of 4 scans of 3602506433 against the eager one: values, mask, derived limits, value subsets."""
import warnings
from pathlib import Path

import numpy as np
from glue.core.component_id import ComponentID
from glue.core.parse import ParsedCommand, ParsedComponentLink
from glue.core.subset import RangeSubsetState

from glue_solar.sources.loaders import iris

warnings.simplefilter("ignore", RuntimeWarning)
FOLDER = Path("/Users/nabil/DATA/IRIS/f783c3f42607685b74b3230d3c7cc427-iris_l2_20260209_215233_3602506433_raster")
files = sorted(FOLDER.glob("*.fits"))[:4]
[lazy] = iris.raster_data(files, ["C II 1336"], stack=True)
iris.LAZY = False
[eager] = iris.raster_data(files, ["C II 1336"], stack=True)
print(type(lazy).__name__, type(eager).__name__, lazy.shape)
cid, ecid = lazy.main_components[0], eager.main_components[0]
values = np.asarray(lazy[cid])
np.testing.assert_array_equal(values, eager[ecid])
np.testing.assert_array_equal(np.asarray(lazy[lazy.derived_components[0]]), eager[f"{eager.label} mask"])
np.testing.assert_array_equal((cid > 10).to_mask(lazy), (ecid > 10).to_mask(eager))
for data, c in ((lazy, cid), (eager, ecid)):
    within = RangeSubsetState(5, 50, c)
    print(data.label[:4], type(data).__name__, "range-subset min/mean",
          data.compute_statistic("minimum", c, subset_state=within, random_subset=10000),
          data.compute_statistic("mean", c, subset_state=within, random_subset=10000))
    rate = ComponentID("rate", parent=data)
    data.add_component_link(ParsedComponentLink(rate, ParsedCommand("{v} / {t}", {"v": c, "t": data.id["Exposure time"]})))
    print("  derived limits", [data.compute_statistic("percentile", rate, percentile=p, random_subset=10000)
                                for p in (0.25, 99.75)], "exact", np.nanpercentile(np.asarray(data[rate]), [0.25, 99.75]))
print("stack equal values/mask/inequality mask")
