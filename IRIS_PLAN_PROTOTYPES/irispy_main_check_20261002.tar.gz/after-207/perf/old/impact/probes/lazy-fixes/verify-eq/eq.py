"""Lazy against eager (LAZY=False): values, NaN and mask of every window of one full raster file and of the SJI."""
import sys
import time
import warnings

import numpy as np
from glue.core.component_id import ComponentID
from glue.core.parse import ParsedCommand, ParsedComponentLink

from glue_solar.sources.loaders import iris
from glue_solar.sources.loaders.lazy import LazyData

warnings.simplefilter("ignore", RuntimeWarning)
RASTER = ("/Users/nabil/DATA/IRIS/2dd2d12db374b3466aa27a65bec235d3-iris_l2_20130902_163935_4000255147_raster/"
          "iris_l2_20130902_163935_4000255147_raster_t000_r00000.fits")


def load(fn, lazy):
    iris.LAZY = lazy
    try:
        return fn()
    finally:
        iris.LAZY = True


def compare(lazy, eager, what):
    assert type(lazy) is LazyData and type(eager) is not LazyData, (type(lazy), type(eager))
    assert lazy.shape == eager.shape and lazy.label == eager.label, (lazy.label, eager.label)
    cid, mask = lazy.main_components[0], lazy.derived_components[0]
    ecid, emask = eager.main_components[0], eager.id[f"{eager.main_components[0].label} mask"]
    values, before = np.asarray(lazy[cid]), eager[ecid]
    assert values.dtype == np.float32, values.dtype
    np.testing.assert_array_equal(values, before)  # NaN where eager has NaN, equal elsewhere
    assert np.array_equal(np.isnan(values), np.isnan(before))
    np.testing.assert_array_equal(np.asarray(lazy[mask]), eager[emask])
    view = (slice(len(before) // 3, len(before) // 3 + 7), slice(None, None, 3))
    np.testing.assert_array_equal(lazy[cid, view], before[view])
    # a derived attribute (fix 1): random-point colour limits near the exact percentiles
    rate = ComponentID("rate", parent=lazy)
    command = ParsedCommand("{v} / {t}", {"v": cid, "t": lazy.id["Exposure time"]})
    lazy.add_component_link(ParsedComponentLink(rate, command))
    t = time.perf_counter()
    limits = [lazy.compute_statistic("percentile", rate, percentile=p, random_subset=10000) for p in (0.25, 99.75)]
    dt = time.perf_counter() - t
    exact = np.nanpercentile(np.asarray(lazy[rate]), [0.25, 99.75])
    assert np.all(np.isfinite(limits)), limits
    raw_limits = [lazy.compute_statistic("percentile", cid, percentile=p, random_subset=10000) for p in (0.25, 99.75)]
    print(f"{what}: {lazy.shape} eager {before.dtype} equal values/NaN ({np.isnan(before).sum()} NaN)/mask; raw limits {raw_limits} "
          f"exact {np.nanpercentile(before, [0.25, 99.75]).tolist()}; derived limits {limits} exact {exact.tolist()} "
          f"in {dt:.2f}s", flush=True)


if sys.argv[1] == "raster":
    from astropy.io import fits

    with fits.open(RASTER) as hdulist:
        windows = [hdulist[0].header[f"TDESC{i}"] for i in range(1, hdulist[0].header["NWIN"] + 1)]
    for window in windows:
        [eager] = load(lambda w=window: iris.raster_data([RASTER], [w]), False)
        [lazy] = load(lambda w=window: iris.raster_data([RASTER], [w]), True)
        compare(lazy, eager, window)
        del eager, lazy
    # File -> Open of the same file
    [lazy] = [d for d in iris.iris_data(RASTER) if d.label.startswith("Si_IV_1403")]
    [eager] = [d for d in load(lambda: iris.iris_data(RASTER), False) if d.label.startswith("Si_IV_1403")]
    compare(lazy, eager, "iris_data Si IV 1403")
else:
    path = sys.argv[2]
    compare(iris.image_data(path), load(lambda: iris.image_data(path), False), path.rsplit("/", 1)[-1])
