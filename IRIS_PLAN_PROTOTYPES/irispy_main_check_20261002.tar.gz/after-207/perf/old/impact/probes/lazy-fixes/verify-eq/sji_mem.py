"""Memory of a lazy SJI open (uncompressed copy): after it returns, after each gc generation, and the peak."""
import gc
import resource
import sys

import psutil

from glue_solar.sources.loaders import iris

process = psutil.Process()


def uss():
    return process.memory_full_info().uss / 2**20


gc.collect()
base, peak0 = uss(), resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 2**20
data = iris.image_data(sys.argv[1])
print(f"after open +{uss() - base:.0f} MB USS, peak RSS +{resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 2**20 - peak0:.0f} MB")
print("gc counts", gc.get_count())
for generation in (0, 1, 2):
    gc.collect(generation)
    print(f"after gc.collect({generation}) +{uss() - base:.0f} MB USS")
