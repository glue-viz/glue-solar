"""Attribute main's raster load cost to the memmap mask: patch np.isin in irispy.io.spectrograph/sji to skip memmap arrays."""
import glob, sys, time, os
import numpy as np, mmap
import irispy.io.spectrograph as sp, irispy.io.sji as sj
from glue_solar.sources.loaders import iris as L
real = np.isin
class NP:  # numpy with isin returning False for memory maps
    def __getattr__(self, name):
        return getattr(np, name)
    @staticmethod
    def isin(a, b, **k):
        x = a
        while x is not None:
            if isinstance(x, (np.memmap, mmap.mmap)):
                return False
            x = getattr(x, "base", None)
        return real(a, b, **k)
if sys.argv[1] == "patched":
    sp.np = NP(); sj.np = NP()
files = sorted(glob.glob("/Users/nabil/DATA/IRIS/*3824262996_raster/*.fits"))
t = []
for _ in range(3):
    t0 = time.perf_counter(); d = L.raster_data(files); t.append(time.perf_counter() - t0)
print(sys.argv[1], [round(x, 3) for x in t], os.getloadavg()[0])
