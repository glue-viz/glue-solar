"""SJI .fits.gz flows: python gzflow.py <glue|read_files|bytes|hdulist>; prints time, inflated MB, RSS/footprint deltas, raw check."""
import gc, glob, gzip, io, json, os, sys, threading, time
import numpy as np, psutil
from mem import usage
inflated = [0]
_read = gzip._GzipReader.read
def read(self, size=-1):
    out = _read(self, size); inflated[0] += len(out); return out
gzip._GzipReader.read = read
import irispy, irispy.io
from irispy.io.sji import read_sji_lvl2
from astropy.io import fits
from glue_solar.sources.loaders import iris as L
path = glob.glob("/Users/nabil/DATA/IRIS/*4000255147_SJI_1400_t000.fits.gz")[0]
flow = sys.argv[1]
proc = psutil.Process(); gc.collect(); u0 = usage(); rss0 = proc.memory_info().rss
peak = [rss0]; stop = threading.Event()
def sample():
    while not stop.is_set():
        peak[0] = max(peak[0], proc.memory_info().rss); time.sleep(0.001)
threading.Thread(target=sample, daemon=True).start()
t = time.perf_counter()
if flow == "glue":
    out = L.image_data(path); raw = None
elif flow == "read_files":
    cube = irispy.io.read_files(path, memmap=True); raw = cube.data
elif flow == "bytes":
    with gzip.open(path) as f: content = f.read()
    cube = read_sji_lvl2(content, memmap=True); raw = cube.data
elif flow == "hdulist":
    with gzip.open(path) as f: content = f.read()
    with fits.open(io.BytesIO(content), do_not_scale_image_data=True) as hdul:
        cube = read_sji_lvl2(hdul, memmap=True); raw = cube.data
dt = time.perf_counter() - t
stop.set(); gc.collect(); u1 = usage()
res = {"flow": flow, "irispy": irispy.__version__, "s": round(dt, 3), "inflated_MB": round(inflated[0] / 2**20, 1),
       "peak_rss_GB": round((max(peak[0], u1["maxrss"]) - rss0) / 1e9, 3),
       "peak_fp_GB": round((u1["max_footprint"] - u0["footprint"]) / 1e9, 3), "load": round(os.getloadavg()[0], 2)}
if raw is not None:
    res.update(dtype=str(raw.dtype), n_m32768=int((raw == -32768).sum()), n_m32764=int((raw == -32764).sum()),
               mask_sum=int(np.asarray(cube.mask).sum()) if cube.mask is not None else None,
               scaled=cube.meta.get("scaled"), bscale=cube.meta.get("BSCALE"), bzero=cube.meta.get("BZERO"))
print(json.dumps(res))
