import sys, traceback, importlib.abc
targets = set(sys.argv[2].split(","))
class F(importlib.abc.MetaPathFinder):
    def find_spec(self, name, path, target=None):
        if name in targets:
            targets.discard(name)
            stack = [f"{f.filename.split('site-packages/')[-1].split('irispy-main-check/')[-1]}:{f.lineno}" for f in traceback.extract_stack()[:-1] if "importlib" not in f.filename and "<frozen" not in f.filename]
            print(name, "<-", " > ".join(stack[-4:]))
        return None
sys.meta_path.insert(0, F())
__import__(sys.argv[1])
