import re, sys, statistics, subprocess, os
# usage: imptime.py <PYTHONPATH or ''> <stmt> <n>
pp, stmt, n = sys.argv[1], sys.argv[2], int(sys.argv[3])
env = dict(os.environ, PYTHONPATH=pp)
tot, smap, pdx = [], [], []
for _ in range(n):
    err = subprocess.run([sys.executable, "-B", "-X", "importtime", "-c", stmt], env=env, capture_output=True, text=True).stderr
    rows = [re.match(r"import time:\s+(\d+) \|\s+(\d+) \| (\s*)(\S+)", l) for l in err.splitlines()]
    rows = [r for r in rows if r]
    cum = {}
    for r in rows:
        cum.setdefault(r.group(4), int(r.group(2)))
    top = sum(int(r.group(2)) for r in rows if len(r.group(3)) == 0)
    tot.append(top / 1e6); smap.append(cum.get("sunpy.map", 0) / 1e6)
print(f"{stmt!r}: total {statistics.median(tot):.3f} s (runs {[round(t,2) for t in tot]}), sunpy.map cumulative {statistics.median(smap):.3f} s")
