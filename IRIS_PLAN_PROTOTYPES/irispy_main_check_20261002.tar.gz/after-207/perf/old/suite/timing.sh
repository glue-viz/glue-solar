#!/bin/bash
cd /private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-main-check/suite
S=..; G=/Users/nabil/Git/glue-solar-accept
: > timing.jsonl
for c in mg2-400 sns-raster 99-scans sji-1400-gz aia-9; do
  for r in 0 1 2 3 4 5; do   # run 0 warms the page cache and is dropped
    for v in main base; do
      if [ $v = main ]; then PP=$S/irispy:$G; else PP=$G; fi
      load=$(ps -Ao pcpu,comm -r | awk 'NR>1 && $2 !~ /python/ {s+=$1} END {print s}')
      out=$(HOME=$(mktemp -d) QT_QPA_PLATFORM=offscreen MPLBACKEND=agg PYTHONPATH=$PP /Users/nabil/mamba/envs/iris-plan/bin/python -B probe.py $c 2>&1 | tail -1)
      echo "{\"run\": $r, \"v\": \"$v\", \"other_cpu\": $load, \"r\": $out}" >> timing.jsonl
    done
  done
done
echo DONE >> timing.jsonl
