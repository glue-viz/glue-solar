"""Load one IRIS dataset through glue-solar's loaders; print time, peak RSS rise, warnings and log records as JSON."""
import glob
import json
import logging
import resource
import sys
import time
import warnings

D = "/Users/nabil/DATA/IRIS/"
CASES = {
    "mg2-400": lambda: glob.glob(D + "c7600*_raster/*.fits"),
    "sns-raster": lambda: glob.glob(D + "2dd2d*_raster/*.fits"),
    "99-scans": lambda: glob.glob(D + "f783c*_raster/*.fits"),
    "sji-1400-gz": lambda: [D + "534d789bb0a2821fb2b78eb36d1d6753-iris_l2_20130902_163935_4000255147_SJI_1400_t000.fits.gz"],
    "aia-9": lambda: sorted(glob.glob(D + "df7fe*_SDO/*.fits")),
}
case = sys.argv[1]
files = CASES[case]()
assert files, case

import irispy.io  # NOQA: E402,F401
from glue_solar.sources.loaders.iris import image_data, raster_data  # NOQA: E402

records = []


class Keep(logging.Handler):
    def emit(self, record):
        records.append(f"{record.name}:{record.levelname}:{record.getMessage()[:160]}")


logging.getLogger().addHandler(Keep(logging.WARNING))
for name in ("irispy", "astropy", "sunpy", "ndcube", "glue"):
    logging.getLogger(name).addHandler(Keep(logging.WARNING))
base = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
with warnings.catch_warnings(record=True) as caught:
    warnings.simplefilter("always")
    t0 = time.perf_counter()
    if case.startswith(("sji", "aia")):
        loaded = [image_data(path) for path in files]
    else:
        loaded = raster_data(files)
    dt = time.perf_counter() - t0
peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
print(json.dumps({
    "case": case, "irispy": irispy.__file__.split("/")[-3], "seconds": round(dt, 3),
    "peak_rise_MiB": round((peak - base) / 2**20), "base_MiB": round(base / 2**20), "n_data": len(loaded),
    "warnings": sorted({f"{w.category.__name__}: {str(w.message)[:160]} ({w.filename.split('/')[-1]}:{w.lineno})"
                        for w in caught}),
    "logs": sorted(set(records)),
}))
