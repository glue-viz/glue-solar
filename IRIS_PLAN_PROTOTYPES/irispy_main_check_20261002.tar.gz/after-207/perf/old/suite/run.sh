#!/bin/bash
# usage: run.sh <env> <main|base> <label> [glue_solar_root]
S=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-main-check
P=/Users/nabil/Git/glue-solar/IRIS_PLAN_PROTOTYPES
G=${4:-/Users/nabil/Git/glue-solar-accept}
if [ "$2" = main ]; then PATHS="$S/irispy:$G:$P"; else PATHS="$G:$P"; fi
cd $S/suite
H=$(mktemp -d)
{ date; ps -Ao pcpu,comm -r | head -6; } > $S/suite/$3.load
env HOME="$H" QT_QPA_PLATFORM=offscreen MPLBACKEND=agg PYTHONPATH=$P /Users/nabil/mamba/envs/$1/bin/python -B $P/run_checks.py "$PATHS" $G/glue_solar --remote-data=any -rfEsw > $S/suite/$3.log 2>&1
echo "EXIT $?" >> $S/suite/$3.log
{ date; ps -Ao pcpu,comm -r | head -6; } >> $S/suite/$3.load
