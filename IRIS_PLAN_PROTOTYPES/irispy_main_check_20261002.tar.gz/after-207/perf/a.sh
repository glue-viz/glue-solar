#!/bin/sh
case $1 in
  091) IP="" ;;
  578) IP="/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-207/irispy-57813b8:" ;;
  main) IP="/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-main-check/irispy:" ;;
esac
cd /private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-207/perf && env HOME="$(mktemp -d)" QT_QPA_PLATFORM=offscreen MPLBACKEND=agg MPLCONFIGDIR=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-207/perf/mpl PYTHONDONTWRITEBYTECODE=1 \
  PYTHONPATH="${IP}/Users/nabil/Git/glue-solar-accept" /Users/nabil/mamba/envs/iris-plan/bin/python -B /private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-207/perf/acc.py "$@" 2>>/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/irispy-207/perf/err_acc.log
