# SST dataset for checking glue-solar's IRIS features

**Short answer:** I recommend the IRIS-SST 2015-09-17 set (IRIS OBSID 3630104144). It is the smallest public set where SST and IRIS observed together, and the SST data are already aligned to the IRIS slit-jaw images. Most glue-solar features still won't work on it or on any other SST file without a reader, but they are close. I downloaded one archive SOLARNET cube as well, so both formats could be tested. Both fit the 1 GB limit (781 MB in total).

## Recommended dataset: IRIS-SST 2015-09-17, OBSID 3630104144

- **Target:** quiet Sun at about (725, 38)″. IRIS ran from 07:39 to 10:57 UT; SST ran from 09:02:51 to 09:27 UT (HOP257 with SST).
- **SST data:** CRISP H-alpha, 15 line points from 6561.5 to 6564.5 Å plus 2 wideband slots, 62 time steps about 24 s apart. Fe I 6173 comes only as Milne-Eddington maps: magnetic field along and across the line of sight, and line-of-sight velocity, plus 2 wideband slots. There is Ca II 8542 too.
- **Format:** IRIS Level 3 files made for CRISPEX (the IDL viewer). This is not the IRIS Level 2 or slit-jaw layout. The SST data are resampled onto the IRIS slit-jaw pixel grid: 220×208 pixels at 0.3327″, with the same reference pixel and rotation as the slit-jaw files.
- **Download:** no registration. Folder: https://www.lmsal.com/solarsoft/irisa/data/level3_published/20150917_073915_3630104144/ redirects (302) to `iris.aws.lmsal.com`, which returned 200 for every file I checked. The whole bundle is 3.4 GB.
- **Terms:** no licence file. The folder README asks users to cite Rouppe van der Voort et al. 2020 (A&A 641, A146, doi:10.1051/0004-6361/202038732; https://arxiv.org/abs/2005.14175) and to add the SST and IRIS acknowledgement texts it gives.

## What I downloaded

`/Users/nabil/DATA/SST/IRIS-SST_20150917_073915_3630104144/` (365 MB). Every file's size matched the server's:
- `iris_l3_…_t000_HI6563_tstart=090251_im.fits`, 193.1 MB: the H-alpha spectral scans over time.
- `iris_l3_…_t000_FeI6173ME_tstart=090259_im.fits`, 56.9 MB: the Fe I 6173 maps over time.
- `iris_l2_…_SJI_2796_t000.fits`, 88.3 MB, and `iris_l2_…_SJI_2832_t000.fits`, 22.1 MB: IRIS slit-jaw images.
- `README.txt`

`/Users/nabil/DATA/SST/SST-archive_obs171_20201016_CRISP_6563/` (421.2 MB):
- `nb_6563_2020-10-16T09:11:04_scans=0,1,3-5_corrected_export2021-06-08T15:21:18_im.fits`. This is an SST archive cube in the standard SOLARNET format, with coordinates stored in lookup tables (WCS-TAB). It holds CRISP H-alpha, 11 wavelength points, intensity only, 5 scans from 09:11:44 to 09:15:16 UT. IRIS OBS 3660258923 observed the same area at the same time (https://dubshen.astro.su.se/sst_archive/observations/171).
- It is public since its RELEASE date, 2022-06-08. Cite Scharmer et al. 2003 (SPIE 4853, 341) and Löfdahl et al. 2021 (A&A 653, A68), add the SST acknowledgement text (https://dubshen.astro.su.se/wiki/index.php/Science_data), and the header's RELEASEC note credits the Horizon 2020 grant 824135 (PI Murabito).

Not downloaded:
- the `_sp` files (the same data reordered for CRISPEX);
- Ca II 8542 (306.6 MB) and the combined cubes (522 and 582 MB);
- the IRIS Level 3 file (about 3 GB) and slit-jaw 1330/1400 (88 MB each);
- the IRIS Level 2 raster for 2015-09-17 (917 MB tar on umbra), which `wp1-m3-multi-instrument` needs;
- the 2020-10-16 IRIS files (slit-jaw 2796 is 132 MB gzipped, the raster tar 1.3 GB).

## Read results

All runs were headless in `iris-plan-qt6` (irispy 8c220d4, astropy 8.0.1, glue-core 1.27.0) against a detached checkout of glue-solar `origin/main` f073033, with an isolated HOME. I've since removed that checkout. The scripts are in `/private/tmp/claude-501/-Users-nabil-Git-glue-solar/07d33ef8-b8df-4ddb-b55c-24b6271a724b/scratchpad/sst-search/try/` (`probe.py`, `sji_frame.py`, `dvarr.py`, `glue_tab.py`, `tabcheck.py`).

### IRIS Level 3 files (2015-09-17)

**Headers and coordinates:**
- The data are 4D: x, y, wavelength, time (numpy shape (62, 17, 208, 220)). The axis types are the non-standard `'x','y','wave','time'`. The header has `INSTRUME='IRIS'` and `LVL_NUM=3`, and no `TELESCOP`.
- The wavelength axis is wrong. It reads 1332.676 Å plus n×0.026 Å, copied from an IRIS window. The real wavelengths are in extension 1, `lambda-coordinate`: 15 unevenly spaced points (6561.5 to 6564.5 Å), then the wideband slots at 6563.0 and 6563.1 (`NWIN=2`). The two wideband slots also break the steady increase a wavelength lookup table needs.
- In the Fe I file, extension 1 holds placeholder values (6173.0, 6173.1, 6173.2, 6563.0, 6563.1). They name the map parameters, not wavelengths.
- The time axis is wrong too. Its reference value is the first step's time (5015.77 s), but its reference pixel is 60, not 1. So the WCS puts the middle frame at 4339 s, while the real times in extension 2 run from 5015.8 to 6487.3 s after the observation start. Those times are one per step and identical across x (spread 0.0 s).
- Pointing: I relabelled x/y as helioprojective and compared with the slit-jaw image. Pixel (110, 104) comes out at (725.54, 37.80)″. irispy puts the same pixel of slit-jaw frame 403 (09:02:48, the SST start) at (724.07, 37.93)″, so the two are 1.5″ apart. The Level 3 header carries the slit-jaw header's mid-observation pointing, but the data share the slit-jaw pixel grid. Linking by pixel is therefore exact; linking by sky position is off by IRIS's tracking drift.

**irispy:**
- `read_files` fails with `ValueError: Expected 62 SJI auxiliary rows, found 1`, because it sends `INSTRUME='IRIS'` files to its slit-jaw reader. Report 1 predicted a `KeyError`; the real error is this `ValueError`.
- With `allow_errors=True` it raises "No supported IRIS files were loaded".
- `read_sji_lvl2` fails with the same `ValueError`.
- The slit-jaw 2796 file reads fine.

**glue and glue-solar (File > Open, `load_data`):**
- glue-solar's IRIS reader does not claim the file (no `TELESCOP`), so glue's own FITS reader opens it. Each file becomes 4 datasets: the 4D cube plus the 3 extensions as plain arrays.
- The cube's world axis types are `[None, None, 'em.wl', 'time']`. glue-solar's checks give: no IRIS role, no time axis, wavelength axis {1} (numpy order), not time-synced.
- The slit-jaw file loads as a normal slit-jaw dataset: role `sji`, time axis 0, time-synced.
- `link_hpc` with the slit-jaw image returns `[]`, because the cube's x/y are not helioprojective.

**Prototype with a corrected header:** I relabelled x/y as HPLN-TAN/HPLT-TAN, put the 15 line points in a lookup-table wavelength axis and fixed the time reference pixel. Then:
- glue-solar's wavelength helper returns the real 6561.5 to 6564.5 Å.
- `link_hpc` returns 2 sky-position links to the slit-jaw image (glue's `LinkSameWithUnits`).

### SST archive SOLARNET file (obs 171)

**Format:** 5D, numpy shape (5, 1, 11, 1323, 1326): scan, Stokes, wavelength point, y, x. The axis types are `HPLN-TAB`, `HPLT-TAB`, `WAVE-TAB` (in nm), `STOKES` and `UTC--TAB`. Coordinates come from a `WCS-TAB` table, a lookup table (`CWDIS3='Lookup'`, extension `WCSDVARR`) corrects the wavelength for cavity errors, there are 30 `VAR-EXT-*` extensions, and `SPECSYS` is missing.

**astropy:**
- `WCS(header)` alone fails ("HDUList is required"). With `fobj=hdul` it works, and its values match the table exactly at every tabulated corner, for every scan and wavelength point.
- The high-level `pixel_to_world` raises `SPECSYS= not yet supported`. It works after setting `specsys='TOPOCENT'`, and so does building an NDCube from it.
- astropy reports the two sky axes as coupled. It reports wavelength as depending only on the wavelength-point axis and time only on the scan axis, but in the table both vary with wavelength point and scan.
- The cavity-error correction is not applied. At the pixel where the correction is largest (−0.0061 nm), astropy returns the same 656.12987 nm as at the centre. Ignoring it can shift Doppler velocities by up to about 2.8 km/s.

**irispy:** `read_files` skips the file ("unrecognized INSTRUME='CRISP'"). `read_sji_lvl2` raises a `ValueError` about a (1, 1) table.

**glue's File > Open:**
- It already loads the cube with correct coordinates, because glue's FITS reader passes the whole file to the WCS. It also adds 32 extra datasets, one per extension.
- glue-solar's checks give: wavelength axis {2}, real wavelengths 6561.30 to 6564.30 Å, no IRIS role. `link_hpc` with an IRIS slit-jaw image gives 2 links.
- **Times are wrong inside a scan.** At scan 4, wavelength point 5, glue's Time is 33313.313 s but the table and astropy give 33314.409 s. glue only evaluates each world coordinate along the pixel axes astropy reports for it (`glue/core/coordinate_helpers.py:47`), and astropy underreports which axes time depends on. The error grows to about 2.2 s per scan.
- **A saved session does not reopen.** Restoring it fails with `ValueError: HDUList is required to retrieve -TAB coordinates and/or indices`.

### glue-solar features on these files today

| Feature | IRIS Level 3 (as glue opens it) | SOLARNET cube (as glue opens it) | What's needed |
|---|---|---|---|
| Quicklook | No (no IRIS role) | No | A reader that gives the data a role |
| Time sync | No (no role, no Time component, wrong time axis) | No (no role or Time component) | Reader adds role and Time |
| `link_hpc` | No (x/y not helioprojective) | Yes, sky-position links | Level 3: relabel x/y |
| Line moments, Doppler | No (they need the IRIS raster role and wavelength as the last axis) | No (wavelength is axis 2 of 5) | A reordered view, or loosen the checks |
| Light curves | No (raster role only) | No | Same as above |
| Path diagrams | Yes (any dataset with 3 or more dimensions) | Yes | none |
| Profile, line and velocity tools | Partly: glue's profile works, but wavelengths read 1332 Å | Mostly: real wavelengths. The velocity tool needs a rest wavelength set by hand, as H-alpha isn't in the IRIS line list. | Level 3 needs the wavelength fix |

The `_sp` files store the same data with wavelength last (numpy (y, x, t, λ)), which is the order the moments and Doppler checks want. A reader could also just reorder the `_im` data to (t, y, x, λ).

## Alternatives

- **IRIS-SST 2016-04-29 (OBSID 3620106129):** sunspot. The bundle is 4.1 GB and each H-alpha file is about 786 MB; it has the smallest IRIS slit-jaw files.
- **SST archive obs 160 (2020-08-30):** H-alpha, 254 MB, the smallest public SOLARNET cube. IRIS co-pointing is not verified.
- **Stokes cubes (`wp13-stokes`), for you to approve:**
  - obs 167, Fe I 6173 with full polarization (IQUV), 1.9 GB, same pointing as obs 171;
  - obs 161, Ca II 8542 IQUV, 1.7 GB.

  No public Stokes cube is under 1 GB, and the Level 3 releases contain none.
- **CHROMIS with IRIS:** obs 498 (H-beta, 1.0 GB, with IRIS OBS 4204700143). Its axis 5 may be mosaic tiles rather than time steps (filename says "mosaic"); I didn't check.
- **2023-05-03 SOLARNET Ca II K:** 107 GB for the main cube, so only its headers are useful, as test fixtures.

## Mapping to the Other missions items

- **`wp8-m3-level3-input`:** real files now exist (the H-alpha spectral cube and the Fe I parameter-map cube), and their exact headers can serve for the synthetic ITN 26 test files. The glue-solar reader should:
  - recognise the files by `LVL_NUM=3` plus the `lambda-coordinate` and `time-coordinates` extensions;
  - relabel x/y as HPLN/HPLT;
  - take wavelengths from extension 1 as a lookup table, keeping the wideband window separate, and treat the Fe I file's axis as parameters, not wavelengths;
  - take per-step times from extension 2, ignoring the broken time reference pixel, and add a Time component;
  - give the data a role.

  The wrong error irispy raises on these files is a fix for the M4 upstream work.
- **`wp1-m3-multi-instrument`:** because the cube shares the slit-jaw pixel grid, the recipe can link pixel axes exactly. Sky-position links are 1.5″ off unless the reader uses irispy's per-frame slit-jaw pointing. The item's done condition (a point on the SST cube gives the IRIS spectrum there) needs the 917 MB 2015-09-17 IRIS raster, which is waiting on your approval.
- **`wp13-solarnet-tab-wcs`:** its literal done condition, "a real -TAB file loads", already holds with glue's own reader. What's left:
  - a session restore that works;
  - correct times inside a scan, either by passing glue the true axis coupling or by giving glue the full coupling for tabulated axes;
  - the cavity-error correction;
  - loading only the main cube, not the 32 extensions;
  - a default `SPECSYS`;
  - handling the length-1 Stokes axis;
  - a role and a reordered axis view for the glue-solar features.