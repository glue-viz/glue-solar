"""Is the WCSDVARR cavity-error lookup applied by astropy? Compare world wavelength with the plain table at pixels where it is large."""
import sys
import numpy as np
from astropy.io import fits
from astropy.wcs import WCS

hdul = fits.open(sys.argv[1], memmap=True)
dv = hdul["WCSDVARR"].data
print("WCSDVARR shape", dv.shape, "min/max", float(np.nanmin(dv)), float(np.nanmax(dv)))
w = WCS(hdul[0].header, fobj=hdul)
s, _, _, y, x = np.unravel_index(int(np.nanargmax(np.abs(dv))), dv.shape)
for tuning in (0, 5):
    world = w.pixel_to_world_values(x, y, tuning, 0, s)[2]
    plain = w.pixel_to_world_values(663, 661, tuning, 0, s)[2]
    print(f"scan {s} tuning {tuning} pixel ({x},{y}) dw={float(dv[s,0,0,y,x]):.5f} world {world:.5f} nm, centre {plain:.5f} nm")
print("w.wcs has dis:", [a for a in ("lin",) if hasattr(w.wcs, a)], "det2im/cpdis:", w.det2im1, w.det2im2, w.cpdis1, w.cpdis2)
