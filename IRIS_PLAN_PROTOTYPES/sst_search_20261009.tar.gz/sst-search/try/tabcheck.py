"""Compare astropy's -TAB world values with the WCS-TAB table itself, per tuning and scan."""
import sys
import warnings
import numpy as np
from astropy.io import fits
from astropy.wcs import WCS

warnings.simplefilter("ignore")
hdul = fits.open(sys.argv[1], memmap=True)
tab = hdul["WCS-TAB"].data
coords = np.asarray(tab["HPLN+HPLT+WAVE+TIME"][0])  # numpy (Nscan, Ntun, 2, 2, 4)
print("table shape", coords.shape, "HPLN-INDEX", tab["HPLN-INDEX"][0], "HPLT-INDEX", tab["HPLT-INDEX"][0])
w = WCS(hdul[0].header, fobj=hdul)
ny, nx = hdul[0].data.shape[-2:]
worst = {"lon": 0, "lat": 0, "wave": 0, "time": 0}
for scan in range(coords.shape[0]):
    for tun in range(coords.shape[1]):
        for (iy, y), (ix, x) in [((0, 0), (0, 0)), ((1, ny - 1), (1, nx - 1))]:
            got = w.pixel_to_world_values(x, y, tun, 0, scan)
            want = coords[scan, tun, iy, ix]
            for k, name in enumerate(worst):
                worst[name] = max(worst[name], abs(float(got[[0, 1, 2, 4][k]]) - float(want[k])))
print("max |astropy - table| at the tabulated corners:", worst)
print("table time, scan 0, tunings 0..3:", coords[0, :4, 0, 0, 3].tolist())
print("table time, scan 4, tunings 0..3:", coords[4, :4, 0, 0, 3].tolist())
print("table wave, tuning 0, scans 0..4:", coords[:, 0, 0, 0, 2].tolist())
print("table corner lon, scans 0..4:", coords[:, 0, 0, 0, 0].tolist())
print("astropy time, scan 4, tunings 0..3:", [float(w.pixel_to_world_values(0, 0, t, 0, 4)[4]) for t in range(4)])
