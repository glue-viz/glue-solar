"""Probe SST/IRIS-SST files: headers, WCS, irispy, glue's FITS reader, glue-solar's File > Open. Run with python -I."""

import re
import sys
import warnings

TREE = "/private/tmp/claude-501/-Users-nabil-Git-glue-solar/07d33ef8-b8df-4ddb-b55c-24b6271a724b/scratchpad/sst-search/tree"
sys.path.insert(0, TREE)

import numpy as np  # noqa: E402

from astropy.io import fits  # noqa: E402
from astropy.wcs import WCS  # noqa: E402

warnings.simplefilter("ignore")
WCSKEY = re.compile(r"^(CTYPE|CUNIT|CRVAL|CDELT|CRPIX|PC\d|PS\d|PV\d|CNAME|CWDIS|CWERR|CSYER|DW\d|SPECSYS|DATEREF|MJDREF|TIMESYS|WCSNAME|DATE[-_]?(OBS|BEG|END|AVG)|TELESCOP|INSTRUME|LVL_NUM|SOLARNET|OBS_HDU|OBSID|BUNIT|TDESC|TWAVE|WAVEMIN|WAVEMAX|STARTOBS|FILENAME|EXTNAME|RELEASE|XCEN|YCEN|FOVX|FOVY|CROTA|NWIN)")


def attempt(label, fn):
    try:
        result = fn()
        print(f"{label}: OK -> {result}")
        return result
    except Exception as exc:  # report every failure, do not stop
        print(f"{label}: {type(exc).__name__}: {str(exc)[:400]}")
        return None


def headers(path):
    print(f"\n=== headers {path}")
    with fits.open(path, memmap=True) as hdul:
        for i, hdu in enumerate(hdul):
            h = hdu.header
            dims = [h.get(f"NAXIS{k}") for k in range(1, (h.get("NAXIS") or 0) + 1)]
            print(f"HDU {i} {hdu.name!r} {type(hdu).__name__} NAXIS={dims} BITPIX={h.get('BITPIX')}")
        for card in hdul[0].header.cards:
            if WCSKEY.match(card.keyword):
                print("   ", str(card).rstrip())
        for hdu in hdul[1:]:
            if isinstance(hdu, fits.BinTableHDU):
                print(f"  table {hdu.name}: columns {hdu.columns.names} formats {hdu.columns.formats} dims {[c.dim for c in hdu.columns]}")


def level3(path):
    print(f"\n=== level 3 extensions {path}")
    with fits.open(path, memmap=True) as hdul:
        print("primary numpy shape", hdul[0].data.shape, hdul[0].data.dtype)
        frame = np.asarray(hdul[0].data[0, 0])
        print("frame t0 w0 min/max/nan", np.nanmin(frame), np.nanmax(frame), int(np.isnan(frame).sum()))
        for hdu in hdul[1:]:
            d = hdu.data
            print(f"ext {hdu.name!r} shape {getattr(d, 'shape', None)} dtype {getattr(d, 'dtype', None)}")
            if d is not None and d.size < 64:
                print("   values", np.asarray(d).ravel().tolist())
            elif d is not None:
                print("   min/max", float(np.nanmin(d)), float(np.nanmax(d)), "first col", np.asarray(d)[:3, 0].tolist())
        wcs = WCS(hdul[0].header)
        print("WCS physical types", wcs.world_axis_physical_types, "units", wcs.world_axis_units)
        centre = [n / 2 for n in hdul[0].data.shape[::-1]]
        print("pixel_to_world_values at centre", wcs.pixel_to_world_values(*centre))


def wcstab(path):
    print(f"\n=== WCS-TAB {path}")
    with fits.open(path, memmap=True) as hdul:
        hdr = hdul[0].header
        attempt("WCS(header) without fobj", lambda: WCS(hdr).world_axis_physical_types)
        wcs = attempt("WCS(header, fobj=hdul)", lambda: WCS(hdr, fobj=hdul))
        if wcs is None:
            return
        print("physical types", wcs.world_axis_physical_types, "units", wcs.world_axis_units)
        print("axis_correlation_matrix\n", wcs.axis_correlation_matrix.astype(int))
        shape = hdul[0].data.shape
        print("numpy shape", shape, hdul[0].data.dtype)
        for pix in ([0, 0, 0, 0, 0], [shape[4] // 2, shape[3] // 2, shape[2] // 2, 0, 0], [shape[4] // 2, shape[3] // 2, 0, 0, shape[0] - 1]):
            print("pixel", pix, "->", [float(v) for v in wcs.pixel_to_world_values(*pix)])
        attempt("high-level pixel_to_world", lambda: wcs.pixel_to_world(0, 0, 0, 0, 0))
        import sunpy.coordinates  # noqa: F401  helioprojective frames

        w2 = wcs.deepcopy()
        if not w2.wcs.specsys:
            w2.wcs.specsys = "TOPOCENT"
        attempt("high-level pixel_to_world, sunpy + SPECSYS", lambda: w2.pixel_to_world(0, 0, 0, 0, 0))
        from ndcube import NDCube

        cube = attempt("NDCube(data, wcs)", lambda: NDCube(hdul[0].data, wcs=w2))
        if cube is not None:
            attempt("cube[0, 0, :, y, x] spectral axis", lambda: cube[0, 0, :, shape[3] // 2, shape[4] // 2].axis_world_coords()[0])
        frame = np.asarray(hdul[0].data[0, 0, 0])
        print("frame min/max/nan", np.nanmin(frame), np.nanmax(frame), int(np.isnan(frame).sum()))


def irispy(path):
    print(f"\n=== irispy {path}")
    from irispy.io.sji import read_sji_lvl2
    from irispy.io.utils import read_files

    attempt("read_files", lambda: read_files(path, memmap=True))
    attempt("read_files(allow_errors=True)", lambda: read_files(path, memmap=True, allow_errors=True))
    attempt("read_sji_lvl2", lambda: read_sji_lvl2(path, memmap=True))


def describe(data):
    from glue_solar.quicklook import _role, _spectral_axes, _time_axis, _timed

    coords = data.coords
    print(f"  Data {data.label!r} shape {data.shape} coords {type(coords).__name__}")
    print(f"    components {[c.label for c in data.components]}")
    print(f"    physical types {getattr(coords, 'world_axis_physical_types', None)} units {getattr(coords, 'world_axis_units', None)}")
    print(f"    INSTRUME {data.meta.get('INSTRUME')!r} role {_role(data)!r} time axis {attempt('    _time_axis', lambda: _time_axis(data))}")
    attempt("    _spectral_axes", lambda: _spectral_axes(data))
    attempt("    _timed", lambda: _timed(data))


def glue_reads(paths):
    from glue.core.data_factories import find_factory, load_data
    from glue.core.data_factories.fits import fits_reader

    print("\n=== glue's own fits_reader (no plugins)")
    for path in paths:
        print(path)
        for d in attempt("fits_reader", lambda: fits_reader(path)) or []:
            print(f"  Data {d.label!r} shape {d.shape} coords {type(d.coords).__name__} types {getattr(d.coords, 'world_axis_physical_types', None)}")
    print("factory without plugins:", {p: getattr(find_factory(p), '__name__', None) for p in paths})

    from glue_qt.utils import get_qapp

    get_qapp()
    from glue.main import load_plugins

    load_plugins()
    import glue_solar

    print("\n=== File > Open path with plugins; glue_solar from", glue_solar.__file__)
    loaded = []
    for path in paths:
        factory = find_factory(path)
        print(path, "-> factory", getattr(factory, "__name__", factory))
        result = attempt("load_data", lambda: load_data(path))
        for data in result if isinstance(result, list) else [result] if result is not None else []:
            describe(data)
            loaded.append(data)
    if len(loaded) > 1:
        from glue.core import DataCollection

        from glue_solar.sources.loaders.iris import link_hpc

        dc = DataCollection(loaded)
        links = attempt("link_hpc", lambda: link_hpc(dc))
        for link in links or []:
            print("   ", type(link).__name__, link)


def _glue_setup():
    from glue_qt.utils import get_qapp

    get_qapp()
    from glue.main import load_plugins

    load_plugins()


def fix3(level3_path, sji_path):
    """What a minimal Level-3 reader would give: the header's x/y/wave/time made standard, wavelengths from ext 1."""
    from glue.core import Data, DataCollection
    from glue.core.data_factories import load_data

    _glue_setup()
    from glue_solar.quicklook import _spectral_axes, _wavelengths
    from glue_solar.sources.loaders.iris import link_hpc

    print(f"\n=== fixed Level-3 header {level3_path}")
    hdul = fits.open(level3_path, memmap=True)
    waves, times = hdul[1].data, hdul[2].data
    print("time spread across x per step (s): max", float(np.ptp(times, axis=1).max()), "steps", np.diff(times[:, 0])[:3].tolist())
    keep = 15  # drop the 2 wideband slots, which break the monotonic wavelength table
    hdr = hdul[0].header.copy()
    hdr.update(CTYPE1="HPLN-TAN", CTYPE2="HPLT-TAN", CTYPE3="WAVE-TAB", PS3_0="WCS-TAB", PS3_1="WAVE",
               CRPIX3=1.0, CDELT3=1.0, CRVAL3=1.0, CTYPE4="UTC", CRPIX4=1.0, CRVAL4=float(times[0, 0]),
               CDELT4=float(np.diff(times[:, 0]).mean()), DATEREF=hdr["DATE_OBS"], TIMESYS="UTC", NAXIS3=keep)
    table = fits.BinTableHDU.from_columns([fits.Column(name="WAVE", format=f"{keep}D", dim=f"(1,{keep})", array=waves[None, :keep, None].astype(float))], name="WCS-TAB")
    wcs = WCS(hdr, fobj=fits.HDUList([fits.PrimaryHDU(header=hdr), table]))
    print("physical types", wcs.world_axis_physical_types, "units", wcs.world_axis_units)
    data = Data(label="HI6563 level 3 (fixed header)", coords=wcs)
    data.add_component(hdul[0].data[:, :keep], "HI6563")
    data.meta.update(hdr)
    print("_spectral_axes", _spectral_axes(data))
    wl, axis = _wavelengths(data)
    print("_wavelengths", np.round(wl, 2).tolist(), "axis", axis)
    print("world at pixel (110, 104, 7, 0):", [float(v) for v in wcs.pixel_to_world_values(110, 104, 7, 0)])
    sji = load_data(sji_path)
    print("SJI world at (110, 104, 0):", [float(v) for v in sji.coords.pixel_to_world_values(110, 104, 0)])
    links = link_hpc(DataCollection([sji, data]))
    print("link_hpc:", [f"{type(link).__name__}: {link}" for link in links])


def solarnet_glue(path, sji_path):
    """glue's own reader, glue-solar's factory, and glue Data built on WCS(header, fobj) for a SOLARNET -TAB cube."""
    from glue.core import Data, DataCollection
    from glue.core.data_factories import find_factory, load_data

    _glue_setup()
    from glue_solar.quicklook import _role, _spectral_axes, _time_axis, _wavelengths
    from glue_solar.sources.loaders.iris import link_hpc

    print(f"\n=== glue on SOLARNET {path}")
    print("factory", getattr(find_factory(path), "__name__", None))
    result = attempt("load_data", lambda: load_data(path))
    for d in result if isinstance(result, list) else [result] if result is not None else []:
        print(f"  Data {d.label!r} shape {d.shape} coords {type(d.coords).__name__} types {getattr(d.coords, 'world_axis_physical_types', None)}")
    hdul = fits.open(path, memmap=True)
    wcs = WCS(hdul[0].header, fobj=hdul)
    if not wcs.wcs.specsys:
        wcs.wcs.specsys = "TOPOCENT"
    data = Data(label="nb_6563 (WCS with fobj)", coords=wcs)
    data.add_component(hdul[0].data, "nb_6563")
    data.meta.update(hdul[0].header)
    print("role", _role(data), "time axis", _time_axis(data), "_spectral_axes", _spectral_axes(data))
    attempt("_wavelengths", lambda: [round(float(w), 3) for w in _wavelengths(data)[0]])
    attempt("world components", lambda: [c.label for c in data.world_component_ids])
    sji = load_data(sji_path)
    links = attempt("link_hpc with an IRIS SJI", lambda: link_hpc(DataCollection([sji, data])))
    for link in links or []:
        print("   ", type(link).__name__, link)


if __name__ == "__main__":
    if sys.argv[1] in ("fix3", "solarnet_glue"):
        {"fix3": fix3, "solarnet_glue": solarnet_glue}[sys.argv[1]](*sys.argv[2:])
        sys.exit()
    mode, *paths = sys.argv[1:]
    if mode == "glue":
        glue_reads(paths)
    else:
        for path in paths:
            {"headers": headers, "level3": level3, "wcstab": wcstab, "irispy": irispy}[mode](path)
