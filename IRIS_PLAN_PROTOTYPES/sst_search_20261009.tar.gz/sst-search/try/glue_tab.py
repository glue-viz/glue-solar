"""glue's own File > Open of a SOLARNET -TAB cube: world components at a pixel, and a session save/restore round trip."""
import sys
import numpy as np
from glue.core import DataCollection
from glue.core.data_factories import load_data
from glue.core.state import GlueSerializer, GlueUnSerializer

path = sys.argv[1]
datasets = load_data(path)
data = next(d for d in datasets if d.label.endswith("[PRIMARY]"))
print("labels of world components:", [c.label for c in data.world_component_ids])
index = (4, 0, 5, 661, 663)
print("world at numpy", index, {c.label or "<empty>": float(data[c, index]) for c in data.world_component_ids})
dc = DataCollection([data])
try:
    text = GlueSerializer(dc).dumps()
    restored = GlueUnSerializer.loads(text).object("__main__")
    d2 = restored[0]
    print("session round trip OK:", {c.label or "<empty>": float(d2[c, index]) for c in d2.world_component_ids})
except Exception as exc:
    print("session round trip:", type(exc).__name__, str(exc)[:300])
