"""SJI 2796 world coordinates at pixel (110, 104) for the frame nearest the SST start (DATE_OBS + 5015.8 s)."""
import sys
sys.path.insert(0, "/private/tmp/claude-501/-Users-nabil-Git-glue-solar/07d33ef8-b8df-4ddb-b55c-24b6271a724b/scratchpad/sst-search/tree")
import numpy as np
from astropy.time import Time
from irispy.io.sji import read_sji_lvl2

cube = read_sji_lvl2(sys.argv[1], memmap=True)
times = cube.axis_world_coords("time")[0] if hasattr(cube, "axis_world_coords") else None
t = Time(times)
target = Time("2015-09-17T07:39:15.350") + 5015.77 / 86400
i = int(np.argmin(abs((t - target).sec)))
print("frame", i, t[i].isot)
print("world at (110, 104, frame):", cube.wcs.pixel_to_world_values(110, 104, i)[:2])
