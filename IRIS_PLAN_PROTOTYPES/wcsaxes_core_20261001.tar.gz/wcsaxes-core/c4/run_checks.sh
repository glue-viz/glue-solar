#!/bin/bash
# Checks (a)-(d) plus no-matplotlib collection, on the current clone tree.
set -u
S=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes-core
PY=/Users/nabil/mamba/envs/astropy-wcsaxes-core/bin/python
R=$S/runs/c4
mkdir -p $R
cd $S
ENV=(env HOME="$(mktemp -d)" XDG_CACHE_HOME=$S/cache MPLBACKEND=agg QT_QPA_PLATFORM=offscreen)
"${ENV[@]}" nice -n 19 $PY -m pytest -c /Users/nabil/Git/astropy-wcsaxes-core/pyproject.toml -p no:cacheprovider --pyargs astropy.visualization.wcsaxes -rs > $R/pytest_default.txt 2>&1
echo "default: $(tail -1 $R/pytest_default.txt)"
"${ENV[@]}" nice -n 19 $PY -m pytest -c /Users/nabil/Git/astropy-wcsaxes-core/pyproject.toml -p no:cacheprovider --pyargs astropy.visualization.wcsaxes -rs --remote-data=any > $R/pytest_remote.txt 2>&1
echo "remote: $(tail -1 $R/pytest_remote.txt)"
rm -rf $S/runs/c4_compare
$S/compare_figures.sh $S/runs/c4_compare -q > $R/compare.txt 2>&1
echo "compare: $(tail -1 $R/compare.txt)"
"${ENV[@]}" nice -n 19 $PY tick_tables.py $R/tick_tables.json > $R/tick_tables_counts.txt 2>&1
cmp $S/baseline/tick_tables.json $R/tick_tables.json && echo "tick_tables: IDENTICAL" || echo "tick_tables: DIFFERENT"
diff $S/baseline/tick_tables_counts.txt $R/tick_tables_counts.txt > /dev/null && echo "counts: SAME" || echo "counts: DIFFERENT"
"${ENV[@]}" nice -n 19 $PY c3/label_state.py $R/label_state.json > /dev/null 2>&1
cmp $S/c3/label_state_before.json $R/label_state.json && echo "label_state: IDENTICAL" || echo "label_state: DIFFERENT"
"${ENV[@]}" $PY no_mpl.py astropy.visualization.wcsaxes astropy.visualization.wcsaxes._layout astropy.visualization.wcsaxes.coordinate_range > $R/no_mpl.txt 2>&1
echo "no_mpl exit $?"
"${ENV[@]}" $PY no_mpl.py --hide-pytest astropy.visualization.wcsaxes astropy.visualization.wcsaxes._layout astropy.visualization.wcsaxes.coordinate_range > $R/no_mpl_hide_pytest.txt 2>&1
echo "no_mpl --hide-pytest exit $?"
"${ENV[@]}" nice -n 19 $PY c1/collect_without_mpl.py /Users/nabil/Git/astropy-wcsaxes-core/pyproject.toml > $R/collect_without_mpl.txt 2>&1
echo "collect_without_mpl exit $?: $(tail -1 $R/collect_without_mpl.txt)"
