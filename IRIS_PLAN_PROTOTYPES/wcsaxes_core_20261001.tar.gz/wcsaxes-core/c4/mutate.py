import shutil, subprocess, sys, os, tempfile
L = "/Users/nabil/Git/astropy-wcsaxes-core/astropy/visualization/wcsaxes/_layout.py"
GOOD = os.path.join(os.path.dirname(__file__), "_layout.py.good")
PY = sys.executable
muts = [
    ("flip rule", "    if 135 < label_angle < 225:\n        label_angle += 180\n", "    if 135 < label_angle < 225:\n        pass\n"),
    ("l uses x1", "            if union is not None:\n                x = x0\n", "            if union is not None:\n                x = x1\n"),
    ("t uses y0", "            if union is not None:\n                y = y1\n", "            if union is not None:\n                y = y0\n"),
    ("r padding sign", "                x = x1\n            x = x + padding\n", "                x = x1\n            x = x - padding\n"),
    ("ignore union", "        if union is not None:\n            x0, y0", "        if False:\n            x0, y0"),
    ("non-rect 1.5", "(padding + text_size * 1.5)\n        y", "(padding + text_size * 1.0)\n        y"),
    ("non-rect sin", "        y = y + np.sin(np.radians(normal_angle))", "        y = y + np.cos(np.radians(normal_angle))"),
    ("midpoint no +180", "    normal_angle = normal_angle[imin] + 180.0\n", "    normal_angle = normal_angle[imin]\n"),
    ("midpoint quarter", "    xcen = np.interp(d[-1] / 2.0, d, x_disp)\n", "    xcen = np.interp(d[-1] / 4.0, d, x_disp)\n"),
]
src = open(GOOD).read()
env = dict(os.environ, HOME=tempfile.mkdtemp(), MPLBACKEND="agg")
try:
    for name, old, new in muts:
        assert src.count(old) == 1, name
        open(L, "w").write(src.replace(old, new))
        r = subprocess.run([PY, "-m", "pytest", "-c", "/Users/nabil/Git/astropy-wcsaxes-core/pyproject.toml",
                            "-p", "no:cacheprovider", "--pyargs", "astropy.visualization.wcsaxes.tests.test_layout",
                            "-q", "-k", "without_matplotlib"], capture_output=True, text=True, env=env)
        print(f"{name}: {'CAUGHT' if r.returncode else 'MISSED'} ({r.stdout.strip().splitlines()[-1]})")
finally:
    shutil.copy(GOOD, L)
