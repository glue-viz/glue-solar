
import json
import sys
from collections import defaultdict
from types import SimpleNamespace

sys.modules["matplotlib"] = None

import numpy as np

from astropy import units as u
from astropy.visualization.wcsaxes._layout import (
    MOVETO,
    CoordSpec,
    SpineArrays,
    anchor_tick_labels,
    axis_label_position,
    grid_lines,
    keep_tick_labels,
    place_ticks,
    resample_spine,
    simplify_labels,
    sort_labels,
    spine_midpoint,
    spine_normal_angle,
)
from astropy.visualization.wcsaxes.coordinate_range import find_coordinate_range
from astropy.wcs import WCS


class PixelToWorld:
    def __init__(self, wcs):
        self.wcs = wcs

    def transform(self, pixel):
        return np.array(self.wcs.pixel_to_world_values(*pixel.T)).T

    def world_to_pixel(self, world):
        return np.array(self.wcs.world_to_pixel_values(*world.T)).T


def to_display(xy):
    return 2.0 * np.asarray(xy) + 10.0


def from_display(xy):
    return (xy - 10.0) / 2.0


def locator(spacing):
    def locate(vmin, vmax):
        n = np.arange(np.ceil(vmin / spacing), np.floor(vmax / spacing) + 1)
        return n * spacing * u.deg, spacing * u.deg

    return locate


def minor_locator(spacing, frequency, vmin, vmax):
    return locator(spacing.to_value(u.deg) / frequency)(vmin, vmax)[0]


def formatter(values, spacing):
    # Degrees and arcminutes, so that simplify_labels has a prefix to drop
    return [f"{int(v)}d{round(abs(v) % 1 * 60):02d}m" for v in values.to_value(u.deg)]


def measure(text, x, y):
    return 7.0 * len(text), 12.0


def tick_labels(placed):
    # As CoordinateHelper fills TickLabels
    labels = SimpleNamespace(
        world=defaultdict(list),
        data=defaultdict(list),
        angle=defaultdict(list),
        tick_angle=defaultdict(list),
        text=defaultdict(list),
        disp=defaultdict(list),
    )
    m = placed.major
    for axis, world, (x, y), angle, normal, disp, text in zip(
        m.axis, m.world, m.pixel, m.angle, m.normal, m.disp, placed.text
    ):
        labels.world[axis].append(world)
        labels.data[axis].append((x, y))
        labels.angle[axis].append(normal)
        labels.tick_angle[axis].append(angle)
        labels.text[axis].append(text)
        labels.disp[axis].append(disp)
    return labels


def layout(ctype, crval, cdelt, shape, spacing, rectangular):
    wcs = WCS(naxis=2)
    wcs.wcs.ctype = ctype
    wcs.wcs.crval = crval
    wcs.wcs.cdelt = cdelt
    wcs.wcs.crpix = [(shape[0] + 1) / 2, (shape[1] + 1) / 2]
    p2w = PixelToWorld(wcs)
    x0, x1, y0, y1 = -0.5, shape[0] - 0.5, -0.5, shape[1] - 0.5
    outlines = {
        "b": [[x0, y0], [x1, y0]],
        "r": [[x1, y0], [x1, y1]],
        "t": [[x1, y1], [x0, y1]],
        "l": [[x0, y1], [x0, y0]],
    }
    spines = {}
    for name, outline in outlines.items():
        data = resample_spine(np.array(outline), 100)
        with np.errstate(invalid="ignore"):
            world = p2w.transform(data)
        spines[name] = SpineArrays(data, world, spine_normal_angle(to_display(data)))
    types = ["longitude", "latitude"]
    wraps = [360 * u.deg, None]
    ranges = find_coordinate_range(p2w, [x0, x1, y0, y1], types, [u.deg] * 2, wraps)
    result = []
    existing = [(100.0, -10.0, 110.0, 0.0)]
    for i in range(2):
        spec = CoordSpec(
            coord_index=i,
            coord_type=types[i],
            coord_unit=u.deg,
            coord_wrap=wraps[i],
            coord_scale_to_deg=None,
            locator=locator(spacing[i]),
            formatter=formatter,
            minor_locator=minor_locator,
            minor_frequency=2,
        )
        placed = place_ticks(
            spec, ranges[i], spines, p2w.transform, to_display, from_display
        )
        lines = grid_lines(spec, ranges, 50, p2w.transform, p2w.world_to_pixel)

        labels = tick_labels(placed)
        sort_labels(labels)
        simplify_labels(labels, "0123456789.+-")
        anchors = anchor_tick_labels(labels, list("brtl"), to_display, 8.0, measure)

        def extent(axis, i):
            if labels.text[axis][i] == "":
                return None
            x, y = anchors[axis][i]
            width, height = measure(labels.text[axis][i], x, y)
            return (x - width / 2, y - height / 2, x + width / 2, y + height / 2)

        kept = list(keep_tick_labels(labels, list("brtl"), extent, True, existing))
        existing += [box for _, _, box in kept]

        boxes = np.array(existing[1:])
        union = (*boxes[:, :2].min(axis=0), *boxes[:, 2:].max(axis=0))
        axis_label = {}
        for axis in labels.text:
            # As Spine._halfway_x_y_angle, on the outline before resampling
            pixel = to_display(np.array(outlines[axis]))
            x, y, normal = spine_midpoint(pixel, spine_normal_angle(pixel))
            axis_label[axis] = [
                float(value)
                for value in axis_label_position(
                    axis, x, y, normal, 12.0, 10.0, rectangular, union
                )
            ]

        result.append(
            {
                "axis": "".join(placed.major.axis),
                "world": placed.major.world.tolist(),
                "pixel": placed.major.pixel.tolist(),
                "angle": placed.major.angle.tolist(),
                "text": list(placed.text),
                "minor": "".join(placed.minor.axis),
                "grid_moveto": [
                    np.flatnonzero(codes == MOVETO).tolist() for _, codes in lines
                ],
                "grid_pixel": [
                    pixel[[0, 25, -1]].ravel().tolist() for pixel, _ in lines
                ],
                "label_text": dict(labels.text),
                "anchor": [
                    [float(x), float(y)] for xy in anchors.values() for x, y in xy.values()
                ],
                "kept": " ".join(f"{axis}{i}" for axis, i, _ in kept),
                "axis_label": axis_label,
            }
        )
    return result


tan = layout(
    ["RA---TAN", "DEC--TAN"], [266.4, -28.9], [-0.002, 0.002], (100, 80), [0.05, 0.05], True
)
ait = layout(["GLON-AIT", "GLAT-AIT"], [0, 0], [-1, 1], (300, 150), [60, 50], False)
print(json.dumps({"tan": tan, "ait": ait}))
