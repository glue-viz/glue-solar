"""Check that modules import with matplotlib unavailable.

Usage: python no_mpl.py [--hide-pytest] MODULE [MODULE ...]

Each module is imported in a fresh subprocess with sys.modules['matplotlib']
set to None, so any import of matplotlib fails. Prints OK, or the chain of
module-level lines that led to matplotlib. Exit status 1 if any failed.

astropy/visualization/wcsaxes/__init__.py calls pytest.importorskip
("matplotlib") when pytest is importable, which stops the chain there.
--hide-pytest also sets sys.modules['pytest'] to None, to show the chain an
environment without pytest would hit.
"""

import subprocess
import sys

CHILD = r"""
import sys, traceback
sys.modules["matplotlib"] = None
if sys.argv[2] == "1":
    sys.modules["pytest"] = None
try:
    __import__(sys.argv[1])
except BaseException as exc:  # pytest.importorskip raises Skipped
    if "matplotlib" not in str(exc):
        raise
    frames = traceback.extract_tb(exc.__traceback__)
    chain = [f for f in frames if f.name == "<module>" and not f.filename.startswith("<")]
    for f in chain:
        print(f"  {f.filename}:{f.lineno}: {f.line}")
    print(f"  {type(exc).__name__}: {exc}")
    sys.exit(1)
"""


def main(args):
    hide_pytest = "--hide-pytest" in args
    modules = [a for a in args if a != "--hide-pytest"]
    failed = 0
    for module in modules:
        proc = subprocess.run(
            [sys.executable, "-c", CHILD, module, str(int(hide_pytest))],
            capture_output=True,
            text=True,
        )
        if proc.returncode == 0:
            print(f"OK    {module}")
        else:
            failed += 1
            print(f"FAIL  {module}, import chain:")
            print(proc.stdout + proc.stderr, end="")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
