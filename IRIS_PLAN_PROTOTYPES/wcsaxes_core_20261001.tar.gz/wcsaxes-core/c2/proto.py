import sys

sys.modules["matplotlib"] = None
import numpy as np

from astropy import units as u
from astropy.visualization.wcsaxes._layout import MOVETO, CoordSpec, grid_lines
from astropy.visualization.wcsaxes.coordinate_range import find_coordinate_range
from astropy.wcs import WCS


class PixelToWorld:
    def __init__(self, wcs):
        self.wcs = wcs

    def transform(self, pixel):
        return np.array(self.wcs.pixel_to_world_values(*pixel.T)).T

    def world_to_pixel(self, world):
        return np.array(self.wcs.world_to_pixel_values(*world.T)).T


def locator(spacing):
    def locate(vmin, vmax):
        n = np.arange(np.ceil(vmin / spacing), np.floor(vmax / spacing) + 1)
        return n * spacing * u.deg, spacing * u.deg
    return locate


def run(ctype, crval, cdelt, shape, spacing, n):
    wcs = WCS(naxis=2)
    wcs.wcs.ctype = ctype
    wcs.wcs.crval = crval
    wcs.wcs.cdelt = cdelt
    wcs.wcs.crpix = [(shape[0] + 1) / 2, (shape[1] + 1) / 2]
    p2w = PixelToWorld(wcs)
    x0, x1, y0, y1 = -0.5, shape[0] - 0.5, -0.5, shape[1] - 0.5
    types = ["longitude", "latitude"]
    wraps = [360 * u.deg, None]
    ranges = find_coordinate_range(p2w, [x0, x1, y0, y1], types, [u.deg] * 2, wraps)
    print(ctype, ranges)
    for i in range(2):
        spec = CoordSpec(i, types[i], u.deg, wraps[i], None, locator(spacing[i]), None, None, 2)
        lines = grid_lines(spec, ranges, n, p2w.transform, p2w.world_to_pixel)
        for pixel, codes in lines:
            print(i, np.flatnonzero(codes == MOVETO).tolist(), np.round(pixel[[0, n // 2, -1]], 6).tolist(), np.isnan(pixel).sum())

run(["RA---TAN", "DEC--TAN"], [266.4, -28.9], [-0.002, 0.002], (100, 80), [0.05, 0.05], 50)
run(["GLON-AIT", "GLAT-AIT"], [0, 0], [-1, 1], (300, 150), [60, 30], 50)
