import json, subprocess, sys
src = open(sys.argv[1]).read()
start = src.index('NO_MATPLOTLIB = """') + len('NO_MATPLOTLIB = """')
script = src[start:src.index('"""', start)]
out = subprocess.run([sys.executable, "-c", script], capture_output=True, text=True)
sys.stderr.write(out.stderr[-2000:])
res = json.loads(out.stdout)
json.dump(res, open(sys.argv[2], "w"))
for case, coords in res.items():
    for i, c in enumerate(coords):
        print(case, i, c["axis"], c["minor"], c["text"])
        print("  world", c["world"]); print("  pixel", [[round(v, 6) for v in p] for p in c["pixel"]]); print("  angle", [round(v, 6) for v in c["angle"]])
        print("  moveto", c["grid_moveto"])
        for p in c["grid_pixel"]:
            print("   ", [round(v, 6) for v in p])
