import sys, runpy, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import base_finder  # noqa
import astropy.visualization.wcsaxes as w
assert "review-identity/base" in w.__file__, w.__file__
sys.argv = ["tick_tables.py", sys.argv[1]]
runpy.run_path(str(pathlib.Path(__file__).resolve().parent.parent / "tick_tables.py"), run_name="__main__")
