"""Import this first to make astropy.visualization.wcsaxes load from the base tree."""
import importlib.abc, importlib.util, pathlib, sys
BASE = pathlib.Path(__file__).resolve().parent / "base/astropy/visualization/wcsaxes"
class _Finder(importlib.abc.MetaPathFinder):
    def find_spec(self, name, path, target=None):
        if name == "astropy.visualization.wcsaxes":
            return importlib.util.spec_from_file_location(name, BASE / "__init__.py", submodule_search_locations=[str(BASE)])
        return None
sys.meta_path.insert(0, _Finder())
