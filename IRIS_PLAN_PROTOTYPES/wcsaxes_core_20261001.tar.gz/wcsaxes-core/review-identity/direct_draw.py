import sys, importlib.abc, importlib.util, pathlib, warnings
R = pathlib.Path(__file__).resolve().parent
if sys.argv[1] == "base":
    BASE = R / "base/astropy/visualization/wcsaxes"
    class F(importlib.abc.MetaPathFinder):
        def find_spec(self, name, path, target=None):
            if name == "astropy.visualization.wcsaxes":
                return importlib.util.spec_from_file_location(name, BASE / "__init__.py", submodule_search_locations=[str(BASE)])
    sys.meta_path.insert(0, F())
import matplotlib; matplotlib.use("agg")
from matplotlib.figure import Figure
from matplotlib.backends.backend_agg import FigureCanvasAgg
from astropy.wcs import WCS
from astropy.visualization.wcsaxes import WCSAxes
from astropy.visualization.wcsaxes.ticklabels import TickLabels
w = WCS(naxis=2); w.wcs.ctype = ["RA---TAN", "DEC--TAN"]; w.wcs.cdelt = [-0.01, 0.01]
fig = Figure(); FigureCanvasAgg(fig)
ax = WCSAxes(fig, [0.1, 0.1, 0.8, 0.8], wcs=w); fig.add_axes(ax)
r = fig.canvas.get_renderer()
# a fresh TickLabels with no labels, drawn directly
tl = TickLabels(ax.coords.frame)
try:
    tl.draw(r); print("fresh empty TickLabels.draw: OK")
except Exception as e:
    print("fresh empty TickLabels.draw:", type(e).__name__, e)
with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    tl2 = ax.coords[0].ticklabels
print("labels before first draw:", sum(len(v) for v in tl2.text.values()))
try:
    tl2.draw(r); print("coord.ticklabels.draw before first canvas draw: OK")
except Exception as e:
    print("coord.ticklabels.draw before first canvas draw:", type(e).__name__, e)
