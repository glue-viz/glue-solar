import sys, runpy
import numpy as np
sys.argv = ["diff_harness.py", "head", sys.argv[1], "tan_minor_grid", "hexagon_docs"]
import astropy.visualization.wcsaxes._layout as L
orig = L.spine_normal_angle
L.spine_normal_angle = lambda p: orig(p) + 1e-9
import astropy.visualization.wcsaxes.frame as F
F.spine_normal_angle = L.spine_normal_angle
runpy.run_path("diff_harness.py", run_name="__main__")
