#!/bin/bash
set -u
S=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes-core
R=$S/review-identity
PY=/Users/nabil/mamba/envs/astropy-wcsaxes-core/bin/python
cd $S
echo "== (a) default"; env HOME="$(mktemp -d)" XDG_CACHE_HOME=$S/cache MPLBACKEND=agg QT_QPA_PLATFORM=offscreen nice -n 19 $PY -m pytest -c /Users/nabil/Git/astropy-wcsaxes-core/pyproject.toml -p no:cacheprovider --pyargs astropy.visualization.wcsaxes -rs -q > $R/runs/pytest_default.txt 2>&1; tail -3 $R/runs/pytest_default.txt
echo "== (a) remote"; env HOME="$(mktemp -d)" XDG_CACHE_HOME=$S/cache MPLBACKEND=agg QT_QPA_PLATFORM=offscreen nice -n 19 $PY -m pytest -c /Users/nabil/Git/astropy-wcsaxes-core/pyproject.toml -p no:cacheprovider --pyargs astropy.visualization.wcsaxes -rs -q --remote-data=any > $R/runs/pytest_remote.txt 2>&1; tail -3 $R/runs/pytest_remote.txt
echo "== (b) figures"; $S/compare_figures.sh $R/runs/compare -q > $R/runs/compare.txt 2>&1; tail -3 $R/runs/compare.txt
echo "== (b) tampered"; TAMPER='TestBasic::test_tick_angles' $S/compare_figures.sh $R/runs/compare_tampered -q -p tamper_plugin > $R/runs/compare_tampered.txt 2>&1; tail -3 $R/runs/compare_tampered.txt
echo "== (c) tick tables"; env HOME="$(mktemp -d)" MPLBACKEND=agg QT_QPA_PLATFORM=offscreen nice -n 19 $PY tick_tables.py $R/runs/tick_tables.json > $R/runs/tick_tables_counts.txt 2>&1; cmp $S/baseline/tick_tables.json $R/runs/tick_tables.json && echo IDENTICAL || diff -u $S/baseline/tick_tables.json $R/runs/tick_tables.json | head -50
diff $S/baseline/tick_tables_counts.txt $R/runs/tick_tables_counts.txt
echo "== (d) no_mpl"; env HOME="$(mktemp -d)" $PY no_mpl.py astropy.visualization.wcsaxes astropy.visualization.wcsaxes._layout astropy.visualization.wcsaxes.coordinate_range; echo "exit $?"
env HOME="$(mktemp -d)" $PY no_mpl.py --hide-pytest astropy.visualization.wcsaxes astropy.visualization.wcsaxes._layout astropy.visualization.wcsaxes.coordinate_range; echo "exit $?"
echo DONE
