"""Differential harness: run scenarios against the base (c55a2b2067) or HEAD
wcsaxes tree and dump everything observable to JSON.

Usage: python diff_harness.py base|head OUT.json [scenario ...]
"""

import hashlib
import importlib.abc
import importlib.machinery
import importlib.util
import io
import json
import pathlib
import pickle
import sys
import traceback

TREE = sys.argv[1]
OUT = sys.argv[2]
ONLY = set(sys.argv[3:])
R = pathlib.Path(__file__).resolve().parent

if TREE == "base":
    BASE = R / "base/astropy/visualization/wcsaxes"

    class _Finder(importlib.abc.MetaPathFinder):
        def find_spec(self, name, path, target=None):
            if name == "astropy.visualization.wcsaxes":
                return importlib.util.spec_from_file_location(
                    name, BASE / "__init__.py", submodule_search_locations=[str(BASE)]
                )
            return None

    sys.meta_path.insert(0, _Finder())

import matplotlib

matplotlib.use("agg")
matplotlib.rcdefaults()
import numpy as np
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure
from matplotlib.transforms import Affine2D

import astropy.units as u
import astropy.visualization.wcsaxes as wcsaxes_pkg
from astropy.visualization.wcsaxes import WCSAxes
from astropy.visualization.wcsaxes.frame import (
    BaseFrame,
    EllipticalFrame,
    RectangularFrame,
)
from astropy.wcs import WCS
from astropy.wcs.wcsapi import BaseLowLevelWCS

assert str(R / "base") in wcsaxes_pkg.__file__ if TREE == "base" else (
    "astropy-wcsaxes-core" in wcsaxes_pkg.__file__
), wcsaxes_pkg.__file__
HAS_LAYOUT = (pathlib.Path(wcsaxes_pkg.__file__).parent / "_layout.py").exists()
assert HAS_LAYOUT == (TREE == "head")

# --- WCS call log with argument hashes ---------------------------------------

LOG = []


def _h(*arrays):
    m = hashlib.sha256()
    for a in arrays:
        a = np.asarray(a, dtype=float)
        m.update(repr(a.shape).encode())
        m.update(np.ascontiguousarray(a).tobytes())
    return m.hexdigest()[:16]


def _wrap(cls, name):
    original = getattr(cls, name)

    def wrapper(self, *args, **kwargs):
        out = original(self, *args, **kwargs)
        outs = out if isinstance(out, tuple) else (out,)
        LOG.append((cls.__name__ + "." + name, _h(*args), _h(*outs)))
        return out

    setattr(cls, name, wrapper)


for _n in ("pixel_to_world_values", "world_to_pixel_values"):
    _wrap(WCS, _n)


class _RasterLikeWCS(BaseLowLevelWCS):
    pixel_n_dim = 2
    world_n_dim = 4
    world_axis_physical_types = [
        "custom:pos.helioprojective.lon",
        "custom:pos.helioprojective.lat",
        "time",
        "custom:step",
    ]
    world_axis_units = ["deg", "deg", "s", "pix"]
    world_axis_names = ["lon", "lat", "time", "step"]
    axis_correlation_matrix = np.array(
        [[True, True], [True, False], [False, True], [False, True]]
    )
    world_axis_object_components = [
        ("celestial", 0, "spherical.lon.degree"),
        ("celestial", 1, "spherical.lat.degree"),
        ("time", 0, "value"),
        ("step", 0, "value"),
    ]
    world_axis_object_classes = {}

    def pixel_to_world_values(self, x, y):
        x, y = np.asarray(x, dtype=float), np.asarray(y, dtype=float)
        return -0.1 + 0.002 * y + 1e-5 * x, 0.05 + 0.002 * x, 100.0 * y, y

    def world_to_pixel_values(self, lon, lat, time, step):
        return (np.asarray(lat) - 0.05) / 0.002, np.asarray(step, dtype=float)


for _n in ("pixel_to_world_values", "world_to_pixel_values"):
    _wrap(_RasterLikeWCS, _n)

# --- WCSs ----------------------------------------------------------------------


def wcs_tan():
    w = WCS(naxis=2)
    w.wcs.ctype = ["RA---TAN", "DEC--TAN"]
    w.wcs.crval = [266.4, -28.9]
    w.wcs.crpix = [50, 50]
    w.wcs.cdelt = [-0.01, 0.01]
    w.wcs.radesys = "FK5"
    w.wcs.equinox = 2000.0
    return w


def wcs_hpc():
    w = WCS(naxis=2)
    w.wcs.ctype = ["HPLN-TAN", "HPLT-TAN"]
    w.wcs.cunit = ["arcsec", "arcsec"]
    w.wcs.crval = [-300, 200]
    w.wcs.crpix = [50, 50]
    w.wcs.cdelt = [0.6, 0.6]
    t = np.radians(20)
    w.wcs.pc = [[np.cos(t), -np.sin(t)], [np.sin(t), np.cos(t)]]
    w.wcs.dateobs = "2020-01-01T00:00:00"
    return w


def wcs_allsky(proj):
    w = WCS(naxis=2)
    w.wcs.ctype = [f"GLON-{proj}", f"GLAT-{proj}"]
    w.wcs.crval = [0, 0]
    w.wcs.crpix = [180.5, 90.5]
    w.wcs.cdelt = [-1, 1]
    return w


def wcs_cube_dependent():
    w = WCS(naxis=3)
    w.wcs.ctype = ["RA---TAN", "VELO-LSR", "DEC--TAN"]
    w.wcs.crval = [50, 1000, -20]
    w.wcs.crpix = [20, 10, 20]
    w.wcs.cdelt = [-0.01, 500, 0.01]
    w.wcs.cunit = ["deg", "m/s", "deg"]
    w.wcs.pc = [[1, 0.3, 0], [0, 1, 0.2], [0, 0, 1]]
    return w


def wcs_1d():
    w = WCS(naxis=1)
    w.wcs.ctype = ["FREQ"]
    w.wcs.crval = [1.4e9]
    w.wcs.crpix = [1]
    w.wcs.cdelt = [1e6]
    w.wcs.cunit = ["Hz"]
    return w


def wcs_scalar():
    w = WCS(naxis=2)
    w.wcs.ctype = ["WAVE", "TIME"]
    w.wcs.crval = [5e-7, 0]
    w.wcs.crpix = [1, 1]
    w.wcs.cdelt = [1e-10, 2.5]
    w.wcs.cunit = ["m", "s"]
    return w


class HexagonalFrame(BaseFrame):
    spine_names = "abcdef"

    def update_spines(self):
        xmin, xmax = self.parent_axes.get_xlim()
        ymin, ymax = self.parent_axes.get_ylim()
        ymid = 0.5 * (ymin + ymax)
        xmid1 = (xmin + xmax) / 4.0
        xmid2 = (xmin + xmax) * 3.0 / 4.0
        self["a"].data = np.array(([xmid1, ymin], [xmid2, ymin]))
        self["b"].data = np.array(([xmid2, ymin], [xmax, ymid]))
        self["c"].data = np.array(([xmax, ymid], [xmid2, ymax]))
        self["d"].data = np.array(([xmid2, ymax], [xmid1, ymax]))
        self["e"].data = np.array(([xmid1, ymax], [xmin, ymid]))
        self["f"].data = np.array(([xmin, ymid], [xmid1, ymin]))


class InsetRectFrame(RectangularFrame):
    """A user RectangularFrame subclass: inset spines plus an empty spine."""


    def update_spines(self):
        super().update_spines()
        xmin, xmax = self.parent_axes.get_xlim()
        ymin, ymax = self.parent_axes.get_ylim()
        dx = 0.05 * (xmax - xmin)
        self["b"].data = np.array(([xmin + dx, ymin], [xmax - dx, ymin]))


class OwnSampleFrame(BaseFrame):
    """A user frame overriding sample() to return its own sampling."""

    spine_names = "abcd"

    def update_spines(self):
        xmin, xmax = self.parent_axes.get_xlim()
        ymin, ymax = self.parent_axes.get_ylim()
        self["a"].data = np.array(([xmin, ymin], [xmax, ymin]))
        self["b"].data = np.array(([xmax, ymin], [xmax, ymax]))
        self["c"].data = np.array(([xmax, ymax], [xmin, ymax]))
        self["d"].data = np.array(([xmin, ymax], [xmin, ymin]))

    def sample(self, n_samples):
        return super().sample(max(3, n_samples // 7))


# --- recording -----------------------------------------------------------------


def _arr(v):
    try:
        return _h(np.asarray(v, dtype=float))
    except Exception:
        return repr(v)


def coord_state(coord):
    t, tl = coord._ticks, coord._ticklabels
    st = {
        "ticks": {
            k: {a: _arr(v) for a, v in getattr(t, k).items()}
            for k in ("world", "pixel", "angle", "disp")
        },
        "minor": {
            k: {a: _arr(v) for a, v in getattr(t, k).items()}
            for k in ("minor_world", "minor_pixel", "minor_angle", "minor_disp")
            if hasattr(t, k)
        },
        "labels_text": {a: list(v) for a, v in tl.text.items()},
        "labels": {
            k: {a: _arr(v) for a, v in getattr(tl, k).items()}
            for k in ("world", "data", "angle", "tick_angle", "disp")
        },
        "xy": {a: {i: _arr(p) for i, p in d.items()} for a, d in getattr(tl, "xy", {}).items()},
        "axis_bboxes": {a: [_arr(b.get_points()) for b in v] for a, v in tl._axis_bboxes.items()},
        "lbl_world": [repr(q) for q in getattr(coord, "_lbl_world", [])],
        "fl_spacing": repr(getattr(coord, "_fl_spacing", None)),
        "grid_lines": [
            (_arr(p.vertices), None if p.codes is None else _arr(p.codes))
            for p in coord._grid_lines
        ],
        "grid": None if getattr(coord, "_grid", None) is None else repr(type(coord._grid)),
        "ticks_locs": {a: _arr(v) for a, v in coord._ticks.ticks_locs.items()},
        "axislabel_pos": _arr(coord._axislabels.get_position()),
        "axislabel_rot": coord._axislabels.get_rotation(),
        "ticklabel_position": list(coord.get_ticklabel_position()),
    }
    return st


def snapshot(fig, axes):
    LOG.clear()
    err = None
    try:
        fig.canvas.draw()
    except Exception as e:
        err = "".join(traceback.format_exception_only(e)).strip()
    rec = {
        "draw_error": err,
        "rgba": hashlib.sha256(np.asarray(fig.canvas.buffer_rgba()).tobytes()).hexdigest()[:16],
        "wcs_calls": len(LOG),
        "wcs_log": hashlib.sha256(repr(LOG).encode()).hexdigest()[:16],
        "wcs_log_full": [list(x) for x in LOG],
        "coords": [],
    }
    for ax in axes:
        for coords in ax._all_coords:
            for coord in coords:
                try:
                    rec["coords"].append(coord_state(coord))
                except Exception as e:
                    rec["coords"].append("ERR " + repr(e))
    return rec


def extras(fig, axes):
    out = {}
    r = fig.canvas.get_renderer()
    for i, ax in enumerate(axes):
        LOG.clear()
        try:
            bb = ax.get_tightbbox(r)
            out[f"ax{i}_tightbbox"] = None if bb is None else list(map(float, bb.bounds))
        except Exception as e:
            out[f"ax{i}_tightbbox"] = "ERR " + repr(e)
        out[f"ax{i}_tightbbox_calls"] = hashlib.sha256(repr(LOG).encode()).hexdigest()[:16]
        try:
            out[f"ax{i}_format_coord"] = ax.format_coord(10.3, 12.7)
        except Exception as e:
            out[f"ax{i}_format_coord"] = "ERR " + repr(e)
    for kind in ("png", "pdf", "svg"):
        buf = io.BytesIO()
        try:
            fig.savefig(
                buf,
                format=kind,
                bbox_inches="tight",
                metadata={"Creator": None, "Producer": None, "CreationDate": None}
                if kind == "pdf"
                else ({"Date": None} if kind == "svg" else None),
            )
            data = buf.getvalue()
            if kind == "svg":
                import re

                data = re.sub(rb'id="[^"]*"', b"", data)
                data = re.sub(rb"#[a-z0-9]{10,}", b"", data)
            out[f"save_tight_{kind}"] = hashlib.sha256(data).hexdigest()[:16]
        except Exception as e:
            out[f"save_tight_{kind}"] = "ERR " + repr(e)
    try:
        blob = pickle.dumps(fig)
        fig2 = pickle.loads(blob)
        FigureCanvasAgg(fig2)
        fig2.canvas.draw()
        out["pickle"] = hashlib.sha256(
            np.asarray(fig2.canvas.buffer_rgba()).tobytes()
        ).hexdigest()[:16]
    except Exception as e:
        out["pickle"] = "ERR " + "".join(traceback.format_exception_only(e)).strip()[:300]
    return out


def make(wcs=None, frame_class=None, slices=None, size=(5, 4), rect=(0.15, 0.15, 0.7, 0.7), **kw):
    fig = Figure(figsize=size, dpi=100)
    FigureCanvasAgg(fig)
    kwargs = dict(kw)
    if wcs is not None:
        kwargs["wcs"] = wcs
    if frame_class is not None:
        kwargs["frame_class"] = frame_class
    if slices is not None:
        kwargs["slices"] = slices
    ax = WCSAxes(fig, list(rect), **kwargs)
    fig.add_axes(ax)
    return fig, ax


def moves(fig, ax, axes, recs):
    x0, x1 = ax.get_xlim()
    y0, y1 = ax.get_ylim()
    w, h = x1 - x0, y1 - y0
    ax.set_xlim(x0 + 0.21 * w, x1 + 0.21 * w)
    recs["pan"] = snapshot(fig, axes)
    ax.set_xlim(x0 + 0.3 * w, x0 + 0.6 * w)
    ax.set_ylim(y0 + 0.25 * h, y0 + 0.55 * h)
    recs["zoom"] = snapshot(fig, axes)
    ax.set_xlim(x0, x1)
    ax.set_ylim(y0, y1)
    fig.set_size_inches(7, 3)
    recs["resize"] = snapshot(fig, axes)


SCEN = {}


def scenario(f):
    SCEN[f.__name__] = f
    return f


@scenario
def tan_minor_grid():
    fig, ax = make(wcs_tan())
    ax.set_xlim(-0.5, 99.5)
    ax.set_ylim(-0.5, 99.5)
    ax.coords.grid(color="k")
    for c in ax.coords:
        c.display_minor_ticks(True)
    ax.coords[1].set_minor_frequency(3)
    return fig, ax, [ax]


@scenario
def tan_set_ticks_variants():
    fig, ax = make(wcs_tan())
    ax.set_xlim(-0.5, 99.5)
    ax.set_ylim(-0.5, 99.5)
    ax.coords[0].set_ticks(values=[266.0, 266.3, 266.5, 266.8] * u.deg)
    ax.coords[1].set_ticks(spacing=7 * u.arcmin, exclude_overlapping=True)
    ax.coords[0].set_major_formatter("d.ddd")
    ax.coords[1].set_ticklabel(exclude_overlapping=True, simplify=False)
    ax.coords[0].set_ticklabel_position("bt")
    ax.coords[1].set_ticklabel_position("lr")
    return fig, ax, [ax]


@scenario
def tan_dense_overlap():
    fig, ax = make(wcs_tan(), size=(3, 2.5))
    ax.set_xlim(-0.5, 99.5)
    ax.set_ylim(-0.5, 99.5)
    ax.coords[0].set_ticks(number=25)
    ax.coords[1].set_ticks(number=25)
    ax.coords[0].set_ticklabel(exclude_overlapping=True)
    ax.coords[1].set_ticklabel(exclude_overlapping=True)
    ax.coords[0].set_ticklabel_position("bltr")
    return fig, ax, [ax]


@scenario
def tan_custom_callable_formatter():
    fig, ax = make(wcs_tan())
    ax.set_xlim(-0.5, 99.5)
    ax.set_ylim(-0.5, 99.5)

    def fmt(values, spacing=None):
        return [f"{v:.3f}" for v in values.to_value(u.deg)][:-1]

    ax.coords[0].set_major_formatter(fmt)
    return fig, ax, [ax]


@scenario
def tan_upper_origin_ascii_minus():
    matplotlib.rcParams["axes.unicode_minus"] = False
    fig, ax = make(wcs_tan())
    ax.set_xlim(-0.5, 99.5)
    ax.set_ylim(99.5, -0.5)
    ax.coords.grid()
    return fig, ax, [ax]


@scenario
def hpc_xlabel_then_draw():
    fig, ax = make(wcs_hpc())
    ax.set_xlim(-0.5, 99.5)
    ax.set_ylim(-0.5, 99.5)
    ax.set_xlabel("Solar X")
    ax.set_ylabel("Solar Y")
    ax.coords[0].set_ticks(number=7)
    ax.coords[1].set_format_unit(u.arcsec)
    ax.coords.grid()
    return fig, ax, [ax]


@scenario
def car_wrap180():
    fig, ax = make(wcs_allsky("CAR"), size=(6, 3.5))
    ax.set_xlim(-0.5, 359.5)
    ax.set_ylim(-0.5, 179.5)
    ax.coords[0].set_coord_type("longitude", coord_wrap=180 * u.deg)
    ax.coords.grid()
    for c in ax.coords:
        c.display_minor_ticks(True)
    return fig, ax, [ax]


@scenario
def ait_elliptical():
    fig, ax = make(wcs_allsky("AIT"), frame_class=EllipticalFrame, size=(6, 3.5))
    ax.set_xlim(-0.5, 359.5)
    ax.set_ylim(-0.5, 179.5)
    ax.coords.grid()
    ax.coords[0].set_ticklabel(color="red")
    return fig, ax, [ax]


@scenario
def ait_offsky():
    fig, ax = make(wcs_allsky("AIT"))
    ax.set_xlim(-60, -10)
    ax.set_ylim(-60, -10)
    ax.coords.grid()
    return fig, ax, [ax]


@scenario
def hexagon_docs():
    fig, ax = make(wcs_tan(), frame_class=HexagonalFrame)
    ax.set_xlim(-0.5, 99.5)
    ax.set_ylim(-0.5, 99.5)
    ax.coords.grid(color="white")
    ax.coords[0].set_ticklabel_position("ad")
    ax.coords[1].set_ticklabel_position("bf")
    ax.coords[0].set_axislabel("RA")
    ax.coords[1].set_axislabel("Dec")
    return fig, ax, [ax]


@scenario
def inset_rect_subclass():
    fig, ax = make(wcs_tan(), frame_class=InsetRectFrame)
    ax.set_xlim(-0.5, 99.5)
    ax.set_ylim(-0.5, 99.5)
    ax.coords.grid()
    ax.coords[0].set_ticks_position("bt")
    ax.coords[0].set_axislabel("RA")
    ax.coords[1].set_axislabel("Dec")
    return fig, ax, [ax]


@scenario
def own_sample_frame():
    fig, ax = make(wcs_hpc(), frame_class=OwnSampleFrame)
    ax.set_xlim(-0.5, 99.5)
    ax.set_ylim(-0.5, 99.5)
    ax.coords.grid()
    return fig, ax, [ax]


@scenario
def overlay_galactic():
    fig, ax = make(wcs_tan())
    ax.set_xlim(-0.5, 99.5)
    ax.set_ylim(-0.5, 99.5)
    ax.coords.grid()
    ov = ax.get_coords_overlay("galactic")
    ov.grid(color="red")
    ov[0].set_ticklabel_position("t")
    ov[1].set_ticklabel_position("r")
    ov[0].set_axislabel("l")
    ov[1].set_axislabel("b")
    ov[1].display_minor_ticks(True)
    return fig, ax, [ax]


@scenario
def frame_1d():
    fig, ax = make(wcs_1d())
    ax.set_xlim(-0.5, 99.5)
    ax.plot(np.arange(100), np.sin(np.arange(100) / 9))
    ax.coords[0].display_minor_ticks(True)
    ax.coords[0].grid()
    ax.set_xlabel("Frequency")
    return fig, ax, [ax]


@scenario
def contour_grid():
    fig, ax = make(wcs_hpc())
    ax.set_xlim(-0.5, 99.5)
    ax.set_ylim(-0.5, 99.5)
    ax.coords.grid(grid_type="contours", color="blue")
    return fig, ax, [ax]


@scenario
def contour_grid_car():
    fig, ax = make(wcs_allsky("CAR"), size=(6, 3.5))
    ax.set_xlim(-0.5, 359.5)
    ax.set_ylim(-0.5, 179.5)
    ax.coords.grid(grid_type="contours")
    return fig, ax, [ax]


@scenario
def tickable_gridline():
    fig, ax = make(wcs_tan())
    ax.set_xlim(-0.5, 99.5)
    ax.set_ylim(-0.5, 99.5)
    ax.coords.grid()
    ax.coords[0].add_tickable_gridline("const-ra", 266.4 * u.deg)
    ax.coords[1].set_ticks_position(("const-ra",))
    ax.coords[1].set_ticklabel_position(("const-ra",))
    ax.coords[1].set_axislabel_position(("const-ra",))
    ax.coords[1].set_axislabel("Dec on gridline")
    return fig, ax, [ax]


@scenario
def hidden_coordinates():
    fig, ax = make(_RasterLikeWCS(), rect=(0.1, 0.1, 0.8, 0.8), aspect="auto")
    ax.set_xlim(-0.5, 29.5)
    ax.set_ylim(-0.5, 39.5)
    for name in ("time", "step"):
        ax.coords[name].set_ticks(number=25)
        ax.coords[name].set_ticks_visible(False)
        ax.coords[name].set_ticklabel_visible(False)
    return fig, ax, [ax]


@scenario
def sliced_dependent():
    fig, ax = make(wcs_cube_dependent(), slices=("x", 5, "y"))
    ax.set_xlim(-0.5, 39.5)
    ax.set_ylim(-0.5, 39.5)
    return fig, ax, [ax]


@scenario
def sliced_spectral_x():
    fig, ax = make(wcs_cube_dependent(), slices=("x", "y", 7), aspect="auto")
    ax.set_xlim(-0.5, 39.5)
    ax.set_ylim(-0.5, 19.5)
    for c in ax.coords:
        c.display_minor_ticks(True)
    return fig, ax, [ax]


@scenario
def scalar_coords():
    fig, ax = make(wcs_scalar(), aspect="auto")
    ax.set_xlim(-0.5, 99.5)
    ax.set_ylim(-0.5, 49.5)
    ax.coords.grid()
    for c in ax.coords:
        c.display_minor_ticks(True)
    ax.coords[0].set_format_unit(u.nm)
    return fig, ax, [ax]


@scenario
def generic_transform_docs():
    transform = Affine2D()
    transform.scale(0.01)
    transform.translate(40, -30)
    transform.rotate(0.3)
    coord_meta = {
        "name": ("lon", "lat"),
        "type": ("longitude", "latitude"),
        "wrap": (180 * u.deg, None),
        "unit": (u.deg, u.deg),
        "format_unit": (None, None),
    }
    fig, ax = make(transform=transform, coord_meta=coord_meta)
    ax.set_xlim(-0.5, 499.5)
    ax.set_ylim(-0.5, 399.5)
    ax.coords.grid()
    return fig, ax, [ax]


@scenario
def reset_wcs_frames():
    # mpl-animators style: reset_wcs on every frame of a slider
    fig, ax = make(wcs_cube_dependent(), slices=("x", 0, "y"))
    ax.set_xlim(-0.5, 39.5)
    ax.set_ylim(-0.5, 39.5)
    return fig, ax, [ax]


@scenario
def two_axes_shared_fig():
    fig, ax = make(wcs_tan(), rect=(0.1, 0.1, 0.35, 0.8))
    ax.set_xlim(-0.5, 99.5)
    ax.set_ylim(-0.5, 99.5)
    ax2 = WCSAxes(fig, [0.6, 0.1, 0.35, 0.8], wcs=wcs_hpc())
    fig.add_axes(ax2)
    ax2.set_xlim(-0.5, 99.5)
    ax2.set_ylim(-0.5, 99.5)
    ax2.coords.grid()
    return fig, ax, [ax, ax2]


class _ArcsecLowLevelWCS(BaseLowLevelWCS):
    # A rolled helioprojective-like APE 14 WCS whose world units are arcsec,
    # so WCSAxes uses coord_scale_to_deg != None.
    pixel_n_dim = 2
    world_n_dim = 2
    world_axis_physical_types = ["custom:pos.helioprojective.lon", "custom:pos.helioprojective.lat"]
    world_axis_units = ["arcsec", "arcsec"]
    world_axis_names = ["hpln", "hplt"]
    axis_correlation_matrix = np.ones((2, 2), dtype=bool)
    world_axis_object_components = [
        ("celestial", 0, "spherical.lon.arcsec"),
        ("celestial", 1, "spherical.lat.arcsec"),
    ]
    world_axis_object_classes = {}
    _c, _s = np.cos(np.radians(25)), np.sin(np.radians(25))

    def pixel_to_world_values(self, x, y):
        x, y = np.asarray(x, dtype=float) - 50, np.asarray(y, dtype=float) - 50
        return -300 + 0.6 * (self._c * x - self._s * y), 200 + 0.6 * (self._s * x + self._c * y)

    def world_to_pixel_values(self, lon, lat):
        a, b = (np.asarray(lon) + 300) / 0.6, (np.asarray(lat) - 200) / 0.6
        return 50 + self._c * a + self._s * b, 50 - self._s * a + self._c * b


for _n in ("pixel_to_world_values", "world_to_pixel_values"):
    _wrap(_ArcsecLowLevelWCS, _n)


@scenario
def ape14_arcsec_minor():
    fig, ax = make(_ArcsecLowLevelWCS())
    ax.set_xlim(-0.5, 99.5)
    ax.set_ylim(-0.5, 99.5)
    ax.coords.grid()
    for c in ax.coords:
        c.display_minor_ticks(True)
    ax.coords[0].set_coord_type("longitude", coord_wrap=180 * u.deg)
    return fig, ax, [ax]


@scenario
def generic_arcsec_wrap():
    transform = Affine2D()
    transform.scale(30.0)
    transform.translate(-648000 + 3000, 1000)
    transform.rotate(0.4)
    coord_meta = {
        "name": ("lon", "lat"),
        "type": ("longitude", "latitude"),
        "wrap": (180 * u.deg, None),
        "unit": (u.arcsec, u.arcsec),
        "format_unit": (u.deg, u.arcmin),
    }
    fig, ax = make(transform=transform, coord_meta=coord_meta)
    ax.set_xlim(-0.5, 499.5)
    ax.set_ylim(-0.5, 399.5)
    ax.coords.grid()
    for c in ax.coords:
        c.display_minor_ticks(True)
    return fig, ax, [ax]


def run(name):
    matplotlib.rcdefaults()
    recs = {}
    try:
        fig, ax, axes = SCEN[name]()
    except Exception as e:
        return {"setup_error": repr(e)}
    recs["initial"] = snapshot(fig, axes)
    recs["second_draw"] = snapshot(fig, axes)
    if name == "reset_wcs_frames":
        for k in range(1, 5):
            ax.reset_wcs(wcs=wcs_cube_dependent(), slices=("x", k, "y"))
            recs[f"frame{k}"] = snapshot(fig, axes)
        ax.reset_wcs(wcs=wcs_hpc())
        recs["reset_hpc"] = snapshot(fig, axes)
    else:
        moves(fig, ax, axes, recs)
    recs["extras"] = extras(fig, axes)
    return recs


results = {}
for name in SCEN:
    if ONLY and name not in ONLY:
        continue
    results[name] = run(name)

with open(OUT, "w") as f:
    json.dump(results, f, indent=1, sort_keys=True, default=repr)
print("wrote", OUT, len(results), "scenarios")
