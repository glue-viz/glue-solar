import numpy as np
import astropy.visualization.wcsaxes._layout as L
from astropy.visualization.wcsaxes.tests import test_layout as T  # needs matplotlib, fine here
M = []
orig = L.count_overlaps
def spy(box, boxes):
    a = np.asarray(box, float).reshape(4)
    for b in boxes:
        b = np.asarray(b, float).reshape(4)
        # signed separation: positive = apart, negative = overlap; zero = touch
        sep = max(b[0] - a[2], a[0] - b[2], b[1] - a[3], a[1] - b[3])
        M.append(sep)
    return orig(box, boxes)
L.count_overlaps = spy
src = T.NO_MATPLOTLIB.replace('sys.modules["matplotlib"] = None', '')
import io, contextlib
with contextlib.redirect_stdout(io.StringIO()):
    exec(compile(src, "nompl", "exec"), {"__name__": "__main__"})
M = np.array(M)
print("comparisons", len(M), "min |separation| px", np.abs(M).min(), "closest", sorted(M, key=abs)[:5])
