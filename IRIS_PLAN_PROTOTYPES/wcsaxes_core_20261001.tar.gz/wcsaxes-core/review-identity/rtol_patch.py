# Does setting the documented-by-location constant in grid_paths still change the grid?
import sys, importlib.abc, importlib.util, pathlib, hashlib
R = pathlib.Path(__file__).resolve().parent
if sys.argv[1] == "base":
    BASE = R / "base/astropy/visualization/wcsaxes"
    class F(importlib.abc.MetaPathFinder):
        def find_spec(self, name, path, target=None):
            if name == "astropy.visualization.wcsaxes":
                return importlib.util.spec_from_file_location(name, BASE / "__init__.py", submodule_search_locations=[str(BASE)])
    sys.meta_path.insert(0, F())
import matplotlib; matplotlib.use("agg")
import numpy as np
from matplotlib.figure import Figure
from matplotlib.backends.backend_agg import FigureCanvasAgg
from astropy.wcs import WCS
from astropy.visualization.wcsaxes import WCSAxes, grid_paths
from astropy.visualization.wcsaxes.frame import EllipticalFrame
w = WCS(naxis=2); w.wcs.ctype = ["GLON-AIT", "GLAT-AIT"]; w.wcs.crpix = [180.5, 90.5]; w.wcs.cdelt = [-1, 1]
def grid_hash():
    fig = Figure(); FigureCanvasAgg(fig)
    ax = WCSAxes(fig, [0.1, 0.1, 0.8, 0.8], wcs=w, frame_class=EllipticalFrame); fig.add_axes(ax)
    ax.set_xlim(-0.5, 359.5); ax.set_ylim(-0.5, 179.5); ax.coords.grid()
    fig.canvas.draw()
    return hashlib.sha256(b"".join(p.codes.tobytes() for c in ax.coords for p in c._grid_lines)).hexdigest()[:12]
a = grid_hash(); grid_paths.ROUND_TRIP_RTOL = 1e-12; grid_paths.DISCONT_FACTOR = 1.0001; b = grid_hash()
print(sys.argv[1], "default", a, "patched grid_paths constants", b, "changed" if a != b else "NO EFFECT")
