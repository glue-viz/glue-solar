"""Run pytest as if matplotlib were not installed, on base or head wcsaxes.

Usage: python nompl_run.py base|head [pytest args]
"""
import importlib.abc
import importlib.metadata
import importlib.util
import pathlib
import sys

TREE = sys.argv[1]
R = pathlib.Path(__file__).resolve().parent
CLONE = "/Users/nabil/Git/astropy-wcsaxes-core"
if TREE == "base":
    BASE = R / "base/astropy/visualization/wcsaxes"

    class _Finder(importlib.abc.MetaPathFinder):
        def find_spec(self, name, path, target=None):
            if name == "astropy.visualization.wcsaxes":
                return importlib.util.spec_from_file_location(
                    name, BASE / "__init__.py", submodule_search_locations=[str(BASE)]
                )
            return None

    sys.meta_path.insert(0, _Finder())
    cfg = str(R / "base/pyproject.toml")
else:
    cfg = CLONE + "/pyproject.toml"

sys.modules["matplotlib"] = None
_distribution = importlib.metadata.distribution


def distribution(name):
    if name == "matplotlib":
        raise importlib.metadata.PackageNotFoundError(name)
    return _distribution(name)


importlib.metadata.distribution = distribution
import pytest  # noqa: E402

sys.exit(
    pytest.main(
        ["-c", cfg, "--rootdir", CLONE, "-p", "no:cacheprovider", "-p", "no:mpl", "-q", "-rs"]
        + sys.argv[2:]
    )
)
