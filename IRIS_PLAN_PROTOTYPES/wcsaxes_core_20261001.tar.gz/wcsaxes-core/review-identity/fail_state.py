# State left behind when a draw raises inside tick placement (e.g. a custom
# formatter that fails), as an interactive backend would keep running after it.
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
if sys.argv[1] == "base":
    import base_finder  # noqa
import matplotlib; matplotlib.use("agg")
from matplotlib.figure import Figure
from matplotlib.backends.backend_agg import FigureCanvasAgg
import astropy.units as u
from astropy.wcs import WCS
from astropy.visualization.wcsaxes import WCSAxes
w = WCS(naxis=2); w.wcs.ctype = ["RA---TAN", "DEC--TAN"]; w.wcs.crval = [266.4, -28.9]; w.wcs.cdelt = [-0.01, 0.01]; w.wcs.crpix = [50, 50]
fig = Figure(); FigureCanvasAgg(fig)
ax = WCSAxes(fig, [0.1, 0.1, 0.8, 0.8], wcs=w); fig.add_axes(ax)
ax.set_xlim(-0.5, 99.5); ax.set_ylim(-0.5, 99.5)
def bad(values, spacing=None):
    raise RuntimeError("formatter failed")
ax.coords[0].set_major_formatter(bad)
try:
    fig.canvas.draw()
except RuntimeError as e:
    print("draw raised:", e)
c = ax.coords[0]
print("has _fl_spacing:", hasattr(c, "_fl_spacing"))
print("ticks after failed draw:", sum(len(v) for v in c._ticks.world.values()))
print("format_coord:", repr(ax.format_coord(50, 50)))
