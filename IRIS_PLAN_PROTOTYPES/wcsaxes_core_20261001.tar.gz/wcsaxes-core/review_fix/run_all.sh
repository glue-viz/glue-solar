#!/bin/bash
set -u
D=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes-core/review_fix
C=/Users/nabil/Git/astropy-wcsaxes-core
n=0
for sha in $(git -C $C rev-list --reverse c55a2b2067..wcsaxes-layout-core); do
  n=$((n+1))
  git -C $C checkout -q --detach $sha || exit 1
  echo "===== c$n"
  $D/run_checks.sh c$n
done
git -C $C checkout -q wcsaxes-layout-core
echo "back on $(git -C $C branch --show-current), clean: $(git -C $C status --porcelain | wc -l | tr -d ' ') changes"
