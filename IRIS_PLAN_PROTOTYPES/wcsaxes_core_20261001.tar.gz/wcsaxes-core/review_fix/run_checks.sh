#!/bin/bash
# Identity checks (a)-(d), label state, no-matplotlib collection, the
# direct-draw check and lint, on the clone's current checkout.
# Usage: run_checks.sh NAME   (outputs in review_fix/runs/NAME)
set -u
S=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes-core
C=/Users/nabil/Git/astropy-wcsaxes-core
PY=/Users/nabil/mamba/envs/astropy-wcsaxes-core/bin/python
E=/Users/nabil/mamba/envs/astropy-wcsaxes-core/bin
R=$S/review_fix/runs/$1
rm -rf $R; mkdir -p $R
cd $S
echo "commit: $(git -C $C log --oneline -1)"
ENV=(env HOME="$(mktemp -d)" XDG_CACHE_HOME=$S/cache MPLBACKEND=agg QT_QPA_PLATFORM=offscreen)
"${ENV[@]}" nice -n 19 $PY -m pytest -c $C/pyproject.toml -p no:cacheprovider --pyargs astropy.visualization.wcsaxes -rs > $R/pytest_default.txt 2>&1
echo "default: $(tail -1 $R/pytest_default.txt)"
"${ENV[@]}" nice -n 19 $PY -m pytest -c $C/pyproject.toml -p no:cacheprovider --pyargs astropy.visualization.wcsaxes -rs --remote-data=any > $R/pytest_remote.txt 2>&1
echo "remote: $(tail -1 $R/pytest_remote.txt)"
$S/compare_figures.sh $R/compare -q > $R/compare.txt 2>&1
echo "figures: $(tail -1 $R/compare.txt)"
"${ENV[@]}" nice -n 19 $PY tick_tables.py $R/tick_tables.json > $R/tick_tables_counts.txt 2>&1
cmp -s $S/baseline/tick_tables.json $R/tick_tables.json && echo "tick_tables: IDENTICAL" || echo "tick_tables: DIFFERENT"
diff <(grep -v 'font cache' $S/baseline/tick_tables_counts.txt) <(grep -v 'font cache' $R/tick_tables_counts.txt) > /dev/null && echo "counts: SAME" || echo "counts: DIFFERENT"
"${ENV[@]}" nice -n 19 $PY c3/label_state.py $R/label_state.json > /dev/null 2>&1
cmp -s $S/c3/label_state_before.json $R/label_state.json && echo "label_state: IDENTICAL" || echo "label_state: DIFFERENT"
"${ENV[@]}" $PY no_mpl.py astropy.visualization.wcsaxes astropy.visualization.wcsaxes._layout astropy.visualization.wcsaxes.coordinate_range > $R/no_mpl.txt 2>&1
echo "no_mpl exit $?"
"${ENV[@]}" $PY no_mpl.py --hide-pytest astropy.visualization.wcsaxes astropy.visualization.wcsaxes._layout astropy.visualization.wcsaxes.coordinate_range > $R/no_mpl_hide_pytest.txt 2>&1
echo "no_mpl --hide-pytest exit $?"
"${ENV[@]}" nice -n 19 $PY c1/collect_without_mpl.py $C/pyproject.toml > $R/collect_without_mpl.txt 2>&1
echo "collect_without_mpl exit $?: $(tail -1 $R/collect_without_mpl.txt)"
"${ENV[@]}" $PY review-identity/direct_draw.py head > $R/direct_draw.txt 2>&1
echo "direct_draw: $(grep -c ': OK' $R/direct_draw.txt) of 2 OK"
# Lint the files this commit touches
FILES=$(git -C $C diff-tree --no-commit-id --name-only -r HEAD | grep -E '\.(py|toml|rst)$')
PYF=$(echo "$FILES" | grep '\.py$')
cd $C
{ $E/ruff check $PYF && $E/ruff format --check $PYF && $E/codespell $FILES && $PY -m numpydoc.hooks.validate_docstrings $PYF; } > $R/lint.txt 2>&1 && echo "lint: OK ($(echo $FILES | wc -w | tr -d ' ') files)" || echo "lint: FAIL"
$PY - $FILES >> $R/lint.txt 2>&1 <<'PYEOF' && echo "hygiene: OK" || echo "hygiene: FAIL"
import re, sys
bad = []
for f in sys.argv[1:]:
    t = open(f, encoding="utf-8").read()
    if not t.endswith("\n") or t.endswith("\n\n"): bad.append((f, "end of file"))
    for i, line in enumerate(t.split("\n"), 1):
        if line != line.rstrip(): bad.append((f, i, "trailing whitespace"))
        if "\r" in line or "�" in line: bad.append((f, i, "CR or U+FFFD"))
        if re.match(r"^(<<<<<<<|=======|>>>>>>>)( |$)", line): bad.append((f, i, "merge marker"))
print(bad)
sys.exit(1 if bad else 0)
PYEOF
git -C $C log -1 --format=%B | grep -qE '#[0-9]+|[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+#[0-9]+|github\.com/[^ ]+/(issues|pull|discussions)/|@[A-Za-z0-9-]' && echo "message: HAS REFERENCES" || echo "message: no references"
