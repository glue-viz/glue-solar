"""pytest plugin that alters one figure test, to prove the tolerance-0 check fails.

Use with PYTHONPATH=<this dir> pytest -p tamper_plugin, and TAMPER=<end of
the test id>. The matching test's figure gets one extra dot in a corner.
"""

import functools
import os


def pytest_collection_modifyitems(items):
    target = os.environ.get("TAMPER")
    if not target:
        return
    hits = [item for item in items if item.nodeid.endswith(target)]
    assert len(hits) == 1, f"TAMPER={target!r} matched {len(hits)} tests"
    item = hits[0]
    original = item.obj

    @functools.wraps(original)
    def tampered(*args, **kwargs):
        fig = original(*args, **kwargs)
        fig.text(0.02, 0.02, ".", fontsize=6)
        return fig

    item.obj = tampered
