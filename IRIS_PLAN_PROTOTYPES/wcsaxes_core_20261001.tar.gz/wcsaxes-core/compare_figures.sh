#!/bin/bash
# Compare every wcsaxes figure test against baseline/ with tolerance 0.
# Pass/fail is the exact PNG hash (baseline/figure_hashes.json); on a mismatch
# pytest-mpl also compares against baseline/figures and reports the RMS, with
# result and diff images under $OUT/mpl-results.
# Usage: compare_figures.sh OUT_DIR [extra pytest args]
set -u
S=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes-core
OUT=${1:?usage: compare_figures.sh OUT_DIR [pytest args]}; shift
mkdir -p "$OUT" "$S/cache/astropy"
cd "$OUT" || exit 2
# test_latex_labels needs a TeX install, which this machine does not have.
exec env HOME="$(mktemp -d)" XDG_CACHE_HOME="$S/cache" MPLBACKEND=agg QT_QPA_PLATFORM=offscreen \
  PYTHONPATH="$S" nice -n 19 /Users/nabil/mamba/envs/astropy-wcsaxes-core/bin/python -m pytest \
  -c /Users/nabil/Git/astropy-wcsaxes-core/pyproject.toml -p no:cacheprovider \
  --pyargs astropy.visualization.wcsaxes -m mpl_image_compare -k 'not test_latex_labels' \
  --remote-data=any --mpl --mpl-use-full-test-name \
  --mpl-hash-library="$S/baseline/figure_hashes.json" \
  --mpl-baseline-path="$S/baseline/figures" \
  --mpl-results-path="$OUT/mpl-results" "$@"
