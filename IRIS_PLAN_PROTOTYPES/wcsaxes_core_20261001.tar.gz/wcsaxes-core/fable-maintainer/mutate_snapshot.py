"""
Run the in-repo no-matplotlib snapshot test (test_layout.NO_MATPLOTLIB vs
EXPECTED) against mutated copies of _layout.py, without touching the clone.

Each mutation is a (label, old, new) string replacement on _layout.py source.
The mutated module is served by a meta-path finder in a subprocess, and the
subprocess output is checked with the same assertions as the test.
"""

import json
import subprocess
import sys

import numpy as np
from numpy.testing import assert_allclose

CLONE = "/Users/nabil/Git/astropy-wcsaxes-core"
LAYOUT = f"{CLONE}/astropy/visualization/wcsaxes/_layout.py"
TEST = f"{CLONE}/astropy/visualization/wcsaxes/tests/test_layout.py"

# Load NO_MATPLOTLIB and EXPECTED from the test module source without importing it
test_src = open(TEST).read()
ns = {}
import ast

tree = ast.parse(test_src)
for node in tree.body:
    if isinstance(node, ast.Assign) and node.targets[0].id in ("NO_MATPLOTLIB", "EXPECTED"):
        exec(compile(ast.Module([node], []), TEST, "exec"), ns)
NO_MATPLOTLIB, EXPECTED = ns["NO_MATPLOTLIB"], ns["EXPECTED"]

FINDER = r"""
import importlib.abc, importlib.util, sys
MUTATED_SRC = %r
class _F(importlib.abc.MetaPathFinder, importlib.abc.Loader):
    def find_spec(self, name, path, target=None):
        if name == "astropy.visualization.wcsaxes._layout":
            return importlib.util.spec_from_loader(name, self, origin=%r)
    def create_module(self, spec): return None
    def exec_module(self, module):
        exec(compile(MUTATED_SRC, %r, "exec"), module.__dict__)
sys.meta_path.insert(0, _F())
"""

MUTATIONS = [
    ("control (no change)", "", ""),
    ("drop tick-angle flip toward normal", "tick_angle[reset] -= 180.0", "pass"),
    ("drop 'tick exactly on frame point' guard", "if np.allclose(w1[imin], w2[imin], rtol=1.0e-13, atol=1.0e-13):\n                continue  # tick is exactly aligned with frame\n            else:", "if True:"),
    ("drop last-w2 intersection check", "if t - w2[-1] == 0:", "if False:"),
    ("drop dx NaN fallback", "if invalid1.any():", "if False:"),
    ("drop dy NaN fallback", "if invalid2.any():", "if False:"),
    ("wrap tick direction at 360 instead of 180", "dx = wrap_angle_at(dx, 180.0)", "dx = wrap_angle_at(dx, 360.0)"),
    ("longitude: skip +360 duplicate ticks", "[tick_world_coordinates_values, tick_world_coordinates_values + 360]", "[tick_world_coordinates_values]"),
    ("interpolate angle without delta wrap", "if delta_angle > 180.0:", "if False:"),
    ("ROUND_TRIP_RTOL 1 -> 100", "ROUND_TRIP_RTOL = 1.0", "ROUND_TRIP_RTOL = 100.0"),
    ("DISCONT_FACTOR 10 -> 1e6", "DISCONT_FACTOR = 10.0", "DISCONT_FACTOR = 1000000.0"),
    ("drop first-step discontinuity check", "if len(step) >= 2 and step[0] > DISCONT_FACTOR * step[1]:", "if False:"),
    ("anchor: cap at cos(45) instead of cos(60)", "scale = np.max([scale, 0.5])", "scale = np.max([scale, 0.7071])"),
    ("anchor: ignore NaN tick angle fallback", "if not np.isnan(labels.tick_angle[axis][i])", "if True"),
    ("simplify: keep '$$'", 'if labels.text[axis][i] == "$$":', "if False:"),
    ("simplify: prefix case uses len(t1) not len(t1)+1", "t2[: len(t1) + 1], numerical_chars", "t2[: len(t1)], numerical_chars"),
    ("count_overlaps: touching counts as overlap", "(bx1 <= ax0) | (by1 <= ay0) | (bx0 >= ax1) | (by0 >= ay1)", "(bx1 < ax0) | (by1 < ay0) | (bx0 > ax1) | (by0 > ay1)"),
    ("axis label: no upright flip", "if 135 < label_angle < 225:", "if False:"),
    ("axis label: non-rect uses 1.0x text size", "(padding + text_size * 1.5)", "(padding + text_size * 1.0)"),
    ("spine_midpoint: segment index off by one", "imin = np.searchsorted(d, d[-1] / 2.0) - 1", "imin = np.searchsorted(d, d[-1] / 2.0)"),
    ("resample: n_samples - 1 points", "p_new = np.linspace(0.0, 1.0, n_samples)", "p_new = np.linspace(0.0, 1.0, n_samples - 1)"),
]


def check(result):
    for case, coords in EXPECTED.items():
        for actual, expected in zip(result[case], coords, strict=True):
            assert actual["axis"] == expected["axis"]
            assert_allclose(actual["world"], expected["world"], rtol=1e-12)
            assert_allclose(actual["pixel"], expected["pixel"], rtol=0, atol=1e-6)
            assert_allclose(actual["angle"], expected["angle"], rtol=0, atol=1e-6)
            assert actual["text"] == expected["text"]
            assert actual["minor"] == expected["minor"]
            assert actual["grid_moveto"] == expected["grid_moveto"]
            assert_allclose(actual["grid_pixel"], expected["grid_pixel"], rtol=0, atol=1e-6)
            assert actual["label_text"] == expected["label_text"]
            assert_allclose(actual["anchor"], expected["anchor"], rtol=0, atol=1e-6)
            assert actual["kept"] == expected["kept"]
            assert actual["axis_label"].keys() == expected["axis_label"].keys()
            for axis, position in expected["axis_label"].items():
                assert_allclose(actual["axis_label"][axis], position, rtol=0, atol=1e-6)


src = open(LAYOUT).read()
rows = []
for label, old, new in MUTATIONS:
    if old and old not in src:
        rows.append((label, "MUTATION TEXT NOT FOUND"))
        continue
    mutated = src.replace(old, new) if old else src
    code = (FINDER % (mutated, LAYOUT, LAYOUT)) + NO_MATPLOTLIB
    p = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True)
    if p.returncode != 0:
        rows.append((label, "CAUGHT (script raised): " + p.stderr.strip().splitlines()[-1][:90]))
        continue
    try:
        check(json.loads(p.stdout))
    except AssertionError as e:
        msg = (str(e).strip().splitlines() or ["(bare assert)"])[0][:90]
        rows.append((label, "CAUGHT: " + msg))
    else:
        rows.append((label, "NOT CAUGHT"))

width = max(len(r[0]) for r in rows)
for label, outcome in rows:
    print(f"{label:<{width}}  {outcome}")
