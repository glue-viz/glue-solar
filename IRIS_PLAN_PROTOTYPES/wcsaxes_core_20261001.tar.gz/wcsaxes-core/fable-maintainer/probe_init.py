"""Probe the package __getattr__ without matplotlib, and what _layout imports with it."""

import subprocess
import sys

NO_MPL = r"""
import sys, inspect, unittest.mock
sys.modules["matplotlib"] = None
import astropy.visualization.wcsaxes as w

def attempt(label, fn):
    try:
        r = fn()
        print(f"{label}: returned {r!r}")
    except BaseException as e:
        print(f"{label}: {type(e).__name__}: {e}")

attempt("hasattr(w, 'WCSAxes')", lambda: hasattr(w, "WCSAxes"))
attempt("getattr(w, 'WCSAxes', None)", lambda: getattr(w, "WCSAxes", None))
attempt("inspect.getmembers(w)", lambda: len(inspect.getmembers(w)))
attempt("mock.patch('...WCSAxes')", lambda: unittest.mock.patch("astropy.visualization.wcsaxes.WCSAxes").start())
attempt("'WCSAxes' in dir(w)", lambda: "WCSAxes" in dir(w))
attempt("from w import WCSAxes", lambda: exec("from astropy.visualization.wcsaxes import WCSAxes"))
attempt("from w import coordinate_range", lambda: exec("from astropy.visualization.wcsaxes import coordinate_range"))
attempt("from w import frame", lambda: exec("from astropy.visualization.wcsaxes import frame"))
attempt("from w import *", lambda: sorted(k for k in (lambda d: (exec("from astropy.visualization.wcsaxes import *", d), d)[1])({}) if not k.startswith("_")))
attempt("import formatter_locator", lambda: exec("import astropy.visualization.wcsaxes.formatter_locator"))
attempt("import wcsapi", lambda: exec("import astropy.visualization.wcsaxes.wcsapi"))
"""

WITH_MPL = r"""
import sys
before = set(sys.modules)
import astropy.visualization.wcsaxes._layout
mpl = sorted(m for m in sys.modules if m.startswith("matplotlib"))
print("matplotlib modules loaded by importing _layout:", len(mpl))
print("matplotlib.axes loaded:", "matplotlib.axes" in sys.modules)
print("matplotlib.figure loaded:", "matplotlib.figure" in sys.modules)
"""

for label, code in [("--- without matplotlib ---", NO_MPL), ("--- with matplotlib ---", WITH_MPL)]:
    print(label)
    p = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True)
    print(p.stdout, p.stderr[-2000:] if p.returncode else "", sep="")
