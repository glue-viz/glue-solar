#!/bin/bash
# For each mutation the snapshot test missed, run the whole in-repo wcsaxes
# suite (unit tests plus figure tests against the tolerance-0 hash baseline)
# with the mutation applied in process. Reports which tests fail.
set -u
S=/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes-core
F=$S/fable-maintainer
R=$F/runs/mutate_suite
mkdir -p "$R" "$S/cache/astropy"
PY=/Users/nabil/mamba/envs/astropy-wcsaxes-core/bin/python
cd "$R" || exit 2

run() {
  local label="$1" old="$2" new="$3"
  local out="$R/$(echo "$label" | tr -c 'A-Za-z0-9' '_').txt"
  MUTATE_OLD="$old" MUTATE_NEW="$new" \
  env HOME="$(mktemp -d)" XDG_CACHE_HOME="$S/cache" MPLBACKEND=agg QT_QPA_PLATFORM=offscreen \
    PYTHONPATH="$F:$S" nice -n 19 "$PY" -m pytest \
    -c /Users/nabil/Git/astropy-wcsaxes-core/pyproject.toml -p no:cacheprovider -p mutate_plugin \
    --pyargs astropy.visualization.wcsaxes -k 'not test_latex_labels and not test_layout_without_matplotlib and not test_public_api_without_matplotlib' \
    --remote-data=any --mpl --mpl-use-full-test-name \
    --mpl-hash-library="$S/baseline/figure_hashes.json" \
    --mpl-baseline-path="$S/baseline/figures" \
    --mpl-results-path="$R/mpl-results" -q -rf > "$out" 2>&1
  local summary; summary=$(tail -1 "$out")
  local failed; failed=$(grep -E '^FAILED' "$out" | sed -E 's/^FAILED [^:]*::(.*) - .*/\1/' | sort -u | head -8 | tr '\n' ' ')
  printf '%-48s %s\n   %s\n' "$label" "$summary" "${failed:-no failures}"
}

run "control (no change)" "ROUND_TRIP_RTOL = 1.0" "ROUND_TRIP_RTOL = 1.0"
run "drop 'tick exactly on frame point' guard" "if np.allclose(w1[imin], w2[imin], rtol=1.0e-13, atol=1.0e-13):
                continue  # tick is exactly aligned with frame
            else:" "if True:"
run "drop last-w2 intersection check" "if t - w2[-1] == 0:" "if False:"
run "drop dx NaN fallback" "if invalid1.any():" "if False:"
run "drop dy NaN fallback" "if invalid2.any():" "if False:"
run "interpolate angle without delta wrap" "if delta_angle > 180.0:" "if False:"
run "ROUND_TRIP_RTOL 1 -> 100" "ROUND_TRIP_RTOL = 1.0" "ROUND_TRIP_RTOL = 100.0"
run "drop first-step discontinuity check" "if len(step) >= 2 and step[0] > DISCONT_FACTOR * step[1]:" "if False:"
run "anchor: ignore NaN tick angle fallback" "if not np.isnan(labels.tick_angle[axis][i])" "if True"
run "simplify: keep '\$\$'" 'if labels.text[axis][i] == "$$":' "if False:"
run "simplify: prefix case len(t1) not len(t1)+1" "t2[: len(t1) + 1], numerical_chars" "t2[: len(t1)], numerical_chars"
run "count_overlaps: touching counts as overlap" "(bx1 <= ax0) | (by1 <= ay0) | (bx0 >= ax1) | (by0 >= ay1)" "(bx1 < ax0) | (by1 < ay0) | (bx0 > ax1) | (by0 > ay1)"
echo ALLDONE
