"""pytest plugin: serve a mutated astropy.visualization.wcsaxes._layout.

MUTATE_OLD and MUTATE_NEW in the environment give the replacement. The clone
is never written to; the mutated source lives only in this process.
"""

import importlib.abc
import importlib.util
import os
import sys

LAYOUT = "/Users/nabil/Git/astropy-wcsaxes-core/astropy/visualization/wcsaxes/_layout.py"
NAME = "astropy.visualization.wcsaxes._layout"

assert NAME not in sys.modules, "_layout already imported before the plugin loaded"
old, new = os.environ["MUTATE_OLD"], os.environ["MUTATE_NEW"]
src = open(LAYOUT).read()
assert old in src, f"mutation text not found: {old!r}"
MUTATED = src.replace(old, new)


class _Finder(importlib.abc.MetaPathFinder, importlib.abc.Loader):
    def find_spec(self, name, path, target=None):
        if name == NAME:
            return importlib.util.spec_from_loader(name, self, origin=LAYOUT)

    def create_module(self, spec):
        return None

    def exec_module(self, module):
        module.__file__ = LAYOUT
        exec(compile(MUTATED, LAYOUT, "exec"), module.__dict__)


sys.meta_path.insert(0, _Finder())
