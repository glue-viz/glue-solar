#!/bin/bash
set -u
cd /Users/nabil/Git/astropy-wcsaxes-core || exit 2
E=/Users/nabil/mamba/envs/astropy-wcsaxes-core/bin
FILES="astropy/visualization/wcsaxes/__init__.py astropy/visualization/wcsaxes/_layout.py astropy/visualization/wcsaxes/axislabels.py astropy/visualization/wcsaxes/coordinate_helpers.py astropy/visualization/wcsaxes/frame.py astropy/visualization/wcsaxes/grid_paths.py astropy/visualization/wcsaxes/tests/__init__.py astropy/visualization/wcsaxes/tests/test_layout.py astropy/visualization/wcsaxes/tests/test_misc.py astropy/visualization/wcsaxes/ticklabels.py"
$E/ruff check $FILES && $E/ruff format --check $FILES && $E/codespell $FILES docs/changes/visualization/XXXXX.api.rst && HOME="$(mktemp -d)" $E/python -m numpydoc.hooks.validate_docstrings $FILES && echo LINT-OK
echo "--- importorskip in tests/__init__.py precedent"
grep -rln "importorskip" --include=__init__.py astropy | head
echo "--- doctest_subpackage_requires package-path entries"
grep -n "astropy/.* = " pyproject.toml | head
echo "--- git status"
git status --porcelain | wc -l
