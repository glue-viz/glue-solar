"""Fuzz _layout.count_overlaps against matplotlib's Bbox.count_overlaps with
values the design's 2000-case check did not use: inf, -inf, -0.0, Bbox.null(),
zero-area boxes, huge magnitudes, and boxes passed as TransformedBbox."""

import sys

import numpy as np
from matplotlib.transforms import Affine2D, Bbox, TransformedBbox

from astropy.visualization.wcsaxes import _layout

rng = np.random.default_rng(1)
specials = [np.inf, -np.inf, -0.0, 0.0, np.nan, 1e300, -1e300, 1e-300]


def rand_box():
    kind = rng.integers(0, 6)
    if kind == 0:
        return Bbox.null()
    if kind == 1:
        return Bbox.unit()
    v = rng.integers(-3, 4, size=4).astype(float)
    if kind == 2:
        v[rng.integers(0, 4)] = specials[rng.integers(0, len(specials))]
    if kind == 3:
        v[2] = v[0]  # zero width
    bb = Bbox.from_extents(*v)
    if kind == 4:
        return TransformedBbox(bb, Affine2D().scale(rng.choice([1.0, -1.0, 2.5])))
    return bb


mismatch = 0
n = 20000
for k in range(n):
    a = rand_box()
    boxes = [rand_box() for _ in range(rng.integers(0, 5))]
    ref = a.count_overlaps(boxes)
    got = _layout.count_overlaps(a, boxes)
    if ref != got:
        mismatch += 1
        if mismatch <= 10:
            print("MISMATCH", ref, got, a.extents, [b.extents for b in boxes])
print(f"cases={n} mismatches={mismatch}")
sys.exit(1 if mismatch else 0)
