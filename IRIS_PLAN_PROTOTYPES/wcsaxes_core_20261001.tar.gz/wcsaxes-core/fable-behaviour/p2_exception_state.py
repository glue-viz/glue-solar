"""State left on a CoordinateHelper when a draw fails part way.

Case A: the formatter raises on the second draw.
Case B: the world->pixel transform raises on the second draw (grid lines on).
Prints the state after the failed draw. Run with WCSAXES_TREE=base and branch."""

import base_finder  # noqa: F401  (must come first)
import numpy as np
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure

from astropy import units as u
from astropy.wcs import WCS
from astropy.visualization.wcsaxes import WCSAxes

print("tree:", base_finder.tree_name())


def wcs_tan():
    w = WCS(naxis=2)
    w.wcs.ctype = ["RA---TAN", "DEC--TAN"]
    w.wcs.crval = [266.4, -28.9]
    w.wcs.crpix = [50, 50]
    w.wcs.cdelt = [-0.01, 0.01]
    w.wcs.set()
    return w


def make():
    fig = Figure(figsize=(5, 4), dpi=100)
    FigureCanvasAgg(fig)
    ax = WCSAxes(fig, [0.15, 0.15, 0.7, 0.7], wcs=wcs_tan())
    fig.add_axes(ax)
    ax.set_xlim(-0.5, 99.5)
    ax.set_ylim(-0.5, 99.5)
    return fig, ax


def state(coord):
    t, tl = coord._ticks, coord._ticklabels
    return dict(
        fl_spacing=repr(getattr(coord, "_fl_spacing", "<unset>")),
        lbl_world=[round(float(q.value), 6) for q in getattr(coord, "_lbl_world", [])],
        ticks={a: len(v) for a, v in t.world.items()},
        labels={a: list(v) for a, v in tl.text.items()},
        n_grid_lines=len(coord._grid_lines),
        grid_first=None
        if not coord._grid_lines
        else np.round(coord._grid_lines[0].vertices[:2], 3).tolist(),
    )


# Case A: formatter raises on the second draw
fig, ax = make()
fig.canvas.draw()
lon = ax.coords[0]
calls = {"n": 0}
orig = lon.formatter


def bad_formatter(values, spacing=None, format="auto"):
    calls["n"] += 1
    if calls["n"] >= 2:
        raise RuntimeError("formatter boom")
    return orig(values, spacing=spacing, format=format)


lon.set_major_formatter(bad_formatter)
fig.canvas.draw()  # first draw with the custom formatter, succeeds
before = state(lon)
ax.set_xlim(10, 60)  # change the ticks
try:
    fig.canvas.draw()
    print("A: no error")
except RuntimeError as e:
    print("A: raised", e)
after = state(lon)
for k in before:
    print(f"A {k}: before={before[k]} after={after[k]}")

# Case B: world->pixel raises on the second draw, with grid lines on
fig, ax = make()
ax.coords.grid(True)
fig.canvas.draw()
lat = ax.coords[1]
before = state(lat)
inv = lat.transform.inverted()
real = type(inv).transform
flag = {"on": False}


def boom(self, values):
    if flag["on"]:
        raise RuntimeError("world2pix boom")
    return real(self, values)


type(inv).transform = boom
flag["on"] = True
ax.set_ylim(10, 60)
try:
    fig.canvas.draw()
    print("B: no error")
except RuntimeError as e:
    print("B: raised", e)
finally:
    type(inv).transform = real
after = state(lat); lon_after = state(ax.coords[0])
print("B lon grid after:", lon_after["n_grid_lines"], lon_after["grid_first"])
for k in ("n_grid_lines", "grid_first"):
    print(f"B {k}: before={before[k]} after={after[k]}")
