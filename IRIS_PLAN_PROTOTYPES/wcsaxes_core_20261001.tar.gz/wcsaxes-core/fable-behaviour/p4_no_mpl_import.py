"""What importing the package does without matplotlib, with pytest installed.

The old package __init__ ran pytest.importorskip("matplotlib"), which raises
pytest's Skipped (a BaseException) outside pytest too. Run with
WCSAXES_TREE=base and branch."""

import sys

sys.modules["matplotlib"] = None

import base_finder  # noqa: E402,F401  (must come before the wcsaxes import)

print("tree expected:", __import__("os").environ.get("WCSAXES_TREE", "branch"))


def attempt(label, fn):
    try:
        out = fn()
    except BaseException as e:  # Skipped is a BaseException
        print(f"{label}: {type(e).__module__}.{type(e).__name__}: {str(e)[:90]}")
    else:
        print(f"{label}: OK {out!r}"[:160])


def imp():
    import astropy.visualization.wcsaxes as w

    return sorted(k for k in vars(w) if not k.startswith("__"))[:12]


attempt("import astropy.visualization.wcsaxes", imp)
attempt(
    "from ... import WCSAxes",
    lambda: __import__("astropy.visualization.wcsaxes", fromlist=["WCSAxes"]).WCSAxes,
)


def gen():
    import io

    from astropy.config.configuration import generate_config

    buf = io.StringIO()
    generate_config("astropy", buf)
    text = buf.getvalue()
    return ("[visualization.wcsaxes]" in text, len(text))


attempt("astropy.config.configuration.generate_config", gen)
