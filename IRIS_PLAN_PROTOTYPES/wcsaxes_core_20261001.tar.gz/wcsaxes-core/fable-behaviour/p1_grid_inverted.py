"""_update_grid_lines now evaluates self.transform.inverted() before the
locator runs, where the old code returned first when the locator found no
ticks. A transform that advertises has_inverse but whose inverted() raises
shows the difference. Run with WCSAXES_TREE=base and branch."""

import base_finder  # noqa: F401  (must come first)
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure
from matplotlib.transforms import Affine2D, Transform

from astropy import units as u
from astropy.visualization.wcsaxes import WCSAxes

print("tree:", base_finder.tree_name())


class LazyInverse(Transform):
    """A pixel->world transform whose inverse is not available yet."""

    input_dims = output_dims = 2
    has_inverse = True

    def __init__(self):
        super().__init__()
        self._fwd = Affine2D().scale(0.01).translate(40, -30).rotate(0.3)

    def transform_non_affine(self, values):
        return self._fwd.transform(values)

    def inverted(self):
        raise NotImplementedError("inverse not available")


coord_meta = {
    "name": ("lon", "lat"),
    "type": ("longitude", "latitude"),
    "wrap": (180 * u.deg, None),
    "unit": (u.deg, u.deg),
    "format_unit": (None, None),
}
fig = Figure(figsize=(5, 4), dpi=100)
FigureCanvasAgg(fig)
ax = WCSAxes(fig, [0.15, 0.15, 0.7, 0.7], transform=LazyInverse(), coord_meta=coord_meta)
fig.add_axes(ax)
ax.set_xlim(-0.5, 499.5)
ax.set_ylim(-0.5, 399.5)
ax.coords.grid(True)
print("grid_type:", ax.coords[0]._grid_type)
# No ticks on either coordinate, so there is nothing to draw a grid for.
ax.coords[0].set_ticks(values=[] * u.deg)
ax.coords[1].set_ticks(values=[] * u.deg)
try:
    fig.canvas.draw()
    print("draw: OK, grid lines:", [len(c._grid_lines) for c in ax.coords])
except NotImplementedError as e:
    print("draw: raised NotImplementedError:", e)
