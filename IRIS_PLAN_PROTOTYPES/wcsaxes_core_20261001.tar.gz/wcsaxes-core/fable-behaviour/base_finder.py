"""Import first (or set WCSAXES_TREE=base) to load astropy.visualization.wcsaxes from the
git-archive export of c55a2b2067 under ./base instead of the installed branch."""

import importlib.abc
import importlib.util
import os
import pathlib
import sys

BASE = pathlib.Path(__file__).resolve().parent / "base/astropy/visualization/wcsaxes"


class _Finder(importlib.abc.MetaPathFinder):
    def find_spec(self, name, path, target=None):
        if name == "astropy.visualization.wcsaxes":
            return importlib.util.spec_from_file_location(
                name, BASE / "__init__.py", submodule_search_locations=[str(BASE)]
            )
        return None


def use_base():
    assert "astropy.visualization.wcsaxes" not in sys.modules
    sys.meta_path.insert(0, _Finder())


if os.environ.get("WCSAXES_TREE", "branch") == "base":
    use_base()


def tree_name():
    import astropy.visualization.wcsaxes as w

    return "base" if str(BASE) in w.__file__ else "branch"
