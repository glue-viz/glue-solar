"""Dump what WCSAxes lays out and draws, per case and per draw, to JSON.

Usage: python tick_tables.py OUT.json

Each case is drawn on Agg four times on the same figure: as built, after a
pan, after a zoom and after a figure resize. Each draw records, per
coordinate map and coordinate: tick world values, data-pixel positions,
angles and displacements per spine (major and minor), the drawn tick
locations, the tick label strings, the positions settings, the grid paths,
and the frame spines; plus every tick and axis label as drawn (text, display
position, rotation, alignment) in draw order, format_coord at the centre, and
the number of pixel_to_world_values / world_to_pixel_values calls (and
points) made by the draw. No timing. Two runs on the same tree are
byte-identical: compare with cmp, and find differences with diff -u (sorted
keys, one value per line).

Arrays longer than BIG elements are stored as shape, sha256 of the float64
bytes and every STRIDE-th row, so a large grid path is compared exactly but
stays readable. The private attributes read here are all in ``coord_table``
and ``frame_table``; adapt those two if the refactor moves them.
"""

import collections
import functools
import hashlib
import json
import sys

import matplotlib
import numpy as np
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure
from matplotlib.path import Path
from matplotlib.text import Text

import astropy.units as u
from astropy.visualization.wcsaxes import WCSAxes
from astropy.visualization.wcsaxes.frame import BaseFrame, EllipticalFrame
from astropy.wcs import WCS

matplotlib.rcdefaults()  # FigureCanvasAgg below needs no backend selection

BIG = 64
STRIDE = 25

# --- WCS call counting ------------------------------------------------------

CALLS = collections.Counter()


def _counted(name):
    original = getattr(WCS, name)

    @functools.wraps(original)
    def wrapper(self, *args, **kwargs):
        CALLS[name] += 1
        CALLS[name + "_points"] += int(np.size(args[0])) if args else 0
        return original(self, *args, **kwargs)

    setattr(WCS, name, wrapper)


_counted("pixel_to_world_values")
_counted("world_to_pixel_values")

# --- drawn-label spy ----------------------------------------------------------

OWNERS = {}  # id(Text artist) -> label for the record
DRAWN = []
_text_draw = Text.draw


@functools.wraps(_text_draw)
def _spy_draw(self, renderer):
    owner = OWNERS.get(id(self))
    if owner is not None and self.get_visible():
        DRAWN.append(
            {
                "owner": owner,
                "text": self.get_text(),
                "position": self.get_position(),
                "display": self.get_transform().transform(self.get_position()),
                "rotation": self.get_rotation(),
                "ha": self.get_ha(),
                "va": self.get_va(),
            }
        )
    return _text_draw(self, renderer)


Text.draw = _spy_draw

# --- JSON conversion ----------------------------------------------------------


def jsonable(x):
    if isinstance(x, u.Quantity):
        return {"value": jsonable(x.value), "unit": x.unit.to_string()}
    if isinstance(x, Path):
        return {"vertices": jsonable(x.vertices), "codes": jsonable(x.codes)}
    if isinstance(x, np.ndarray):
        if x.size > BIG:
            data = np.ascontiguousarray(x, dtype=float)
            return {
                "shape": list(x.shape),
                "sha256": hashlib.sha256(data.tobytes()).hexdigest(),
                "every_%dth" % STRIDE: data[::STRIDE].tolist(),
            }
        return x.tolist()
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, dict):
        return {str(k): jsonable(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        if len(x) > BIG and all(isinstance(v, (float, np.floating)) for v in x):
            return jsonable(np.asarray(x))
        return [jsonable(v) for v in x]
    if x is None or isinstance(x, (bool, int, float, str)):
        return x
    return repr(x)


# --- what one draw left behind --------------------------------------------------


def coord_table(coord):
    t, tl = coord._ticks, coord._ticklabels
    grid = getattr(coord, "_grid", None)
    return {
        "coord_index": coord.coord_index,
        "coord_type": coord.coord_type,
        "axislabel": coord.get_axislabel(),
        "ticks_position": coord.get_ticks_position(),
        "ticklabel_position": coord.get_ticklabel_position(),
        "axislabel_position": coord.get_axislabel_position(),
        "spacing": getattr(coord, "_fl_spacing", None),
        "ticks": {"world": t.world, "pixel": t.pixel, "angle": t.angle, "disp": t.disp},
        "minor_ticks": {
            "world": t.minor_world,
            "pixel": t.minor_pixel,
            "angle": t.minor_angle,
            "disp": t.minor_disp,
        },
        "ticks_drawn_display": getattr(t, "ticks_locs", None),
        "ticklabels": {
            "world": tl.world,
            "data": tl.data,
            "angle": tl.angle,
            "tick_angle": tl.tick_angle,
            "disp": tl.disp,
            "text": tl.text,
        },
        "grid_lines": coord._grid_lines,
        "grid_contours": None if grid is None else list(grid.get_paths()),
    }


def frame_table(frame):
    return {name: spine.data for name, spine in frame.items()}


def register_owners(ax):
    OWNERS.clear()
    for m, coords in enumerate(ax._all_coords):
        for i, coord in enumerate(coords):
            OWNERS[id(coord._ticklabels)] = f"map{m}.coord{i}.ticklabel"
            OWNERS[id(coord._axislabels)] = f"map{m}.coord{i}.axislabel"


def draw_and_record(fig, ax, state):
    register_owners(ax)
    DRAWN.clear()
    CALLS.clear()
    try:
        fig.canvas.draw()
        error = None
    except Exception as exc:  # recorded so a refactor must fail the same way
        error = f"{type(exc).__name__}: {exc}"
    calls = dict(sorted(CALLS.items()))
    record = {
        "state": state,
        "error": error,
        "figsize": fig.get_size_inches(),
        "xlim": ax.get_xlim(),
        "ylim": ax.get_ylim(),
        "calls": calls,
        "maps": [
            {
                "frame": frame_table(coords.frame),
                "coords": [coord_table(c) for c in coords],
            }
            for coords in ax._all_coords
        ],
        "drawn_text": list(DRAWN),
    }
    if error is None:
        x0, x1 = ax.get_xlim()
        y0, y1 = ax.get_ylim()
        try:
            text = ax.format_coord((x0 + x1) / 2, (y0 + y1) / 2)
        except Exception as exc:  # the 1-D frame raises on main
            text = f"{type(exc).__name__}: {exc}"
        record["format_coord_centre"] = text
    return jsonable(record)  # convert now: later draws replace these objects


# --- cases ----------------------------------------------------------------------


def new_axes(wcs, shape, figsize=(5, 4), **kwargs):
    fig = Figure(figsize=figsize, dpi=100)
    FigureCanvasAgg(fig)
    ax = fig.add_subplot(projection=wcs, **kwargs)
    ax.set_xlim(-0.5, shape[0] - 0.5)
    if len(shape) > 1:
        ax.set_ylim(-0.5, shape[1] - 0.5)
    return fig, ax


def rot(deg):
    c, s = np.cos(np.radians(deg)), np.sin(np.radians(deg))
    return [[c, -s], [s, c]]


def wcs2d(ctype, cunit, cdelt, crpix, crval, pc=None):
    w = WCS(naxis=2)
    w.wcs.ctype, w.wcs.cunit = ctype, cunit
    w.wcs.cdelt, w.wcs.crpix, w.wcs.crval = cdelt, crpix, crval
    if pc is not None:
        w.wcs.pc = pc
    return w


def tan_wcs():
    return wcs2d(
        ["RA---TAN", "DEC--TAN"],
        ["deg", "deg"],
        [-0.002, 0.002],
        [50, 40],
        [266.4, -28.9],
    )


def cube_wcs(roll=0):
    w = WCS(naxis=3)
    w.wcs.ctype = ["RA---TAN", "DEC--TAN", "FREQ"]
    w.wcs.cunit = ["deg", "deg", "Hz"]
    w.wcs.cdelt = [-0.01, 0.01, 1e6]
    w.wcs.crpix = [25, 15, 1]
    w.wcs.crval = [83.6, 22.0, 1.42e9]
    pc = np.eye(3)
    pc[:2, :2] = rot(roll)
    w.wcs.pc = pc
    return w


def case_tan():
    return new_axes(tan_wcs(), (100, 80))


def case_hpc_roll():
    w = wcs2d(
        ["HPLN-TAN", "HPLT-TAN"],
        ["arcsec", "arcsec"],
        [0.33, 0.33],
        [250, 250],
        [-300, 200],
        rot(20),
    )
    fig, ax = new_axes(w, (500, 500), figsize=(6, 6))
    ax.coords.grid(color="white")
    ax.set_xlabel("Solar X")  # eager placement path
    ax.set_ylabel("Solar Y")
    return fig, ax


def case_car_allsky():
    w = wcs2d(["GLON-CAR", "GLAT-CAR"], ["deg", "deg"], [-1, 1], [180.5, 90.5], [0, 0])
    fig, ax = new_axes(w, (360, 180), figsize=(8, 4))
    ax.coords.grid()
    return fig, ax


def case_ait_ellipse():
    w = wcs2d(["GLON-AIT", "GLAT-AIT"], ["deg", "deg"], [-1, 1], [180.5, 90.5], [0, 0])
    fig, ax = new_axes(w, (360, 180), figsize=(8, 4), frame_class=EllipticalFrame)
    ax.coords.grid()
    return fig, ax


def case_cube_sliced():
    return new_axes(cube_wcs(), (50, 30), slices=("x", "y", 5))


def case_cube_world_dependent():
    # Pixel axis 1 sliced: RA and Dec both vary along x, frequency along y.
    return new_axes(cube_wcs(roll=30), (50, 40), slices=("x", 15, "y"))


def case_cube_hidden():
    fig, ax = new_axes(cube_wcs(roll=30), (50, 40), slices=("x", 15, "y"))
    ax.coords[1].set_ticks_visible(False)
    ax.coords[1].set_ticklabel_visible(False)
    return fig, ax


def case_frame_1d():
    w = WCS(naxis=1)
    w.wcs.ctype = ["WAVE"]
    w.wcs.cunit = ["Angstrom"]
    w.wcs.cdelt = [0.1]
    w.wcs.crpix = [1]
    w.wcs.crval = [6563]
    fig, ax = new_axes(w, (100,))
    ax.set_ylim(0, 1)
    return fig, ax


def case_overlay():
    fig, ax = new_axes(tan_wcs(), (100, 80))
    ax.coords.grid(color="black")
    overlay = ax.get_coords_overlay("galactic")
    overlay.grid(color="red")
    overlay[0].set_axislabel("Galactic longitude")
    overlay[1].set_axislabel("Galactic latitude")
    return fig, ax


def case_contour_grid():
    fig, ax = new_axes(tan_wcs(), (100, 80))
    ax.coords[0].grid(grid_type="contours", color="purple")
    ax.coords[1].grid(grid_type="contours", color="orange")
    return fig, ax


def case_minor_ticks():
    fig, ax = new_axes(tan_wcs(), (100, 80))
    ax.coords[0].display_minor_ticks(True)
    ax.coords[0].set_minor_frequency(4)
    ax.coords[1].display_minor_ticks(True)
    return fig, ax


def case_tickable_gridline():
    # As test_images.test_tickable_gridlines.
    w = wcs2d(["RA---CAR", "DEC--CAR"], ["deg", "deg"], [-1, 1], [180.5, 90.5], [0, 0])
    fig, ax = new_axes(w, (360, 150))
    ax.coords.grid()
    overlay = ax.get_coords_overlay("galactic")
    overlay[0].set_ticks(spacing=30 * u.deg)
    overlay[1].set_ticks(spacing=30 * u.deg)
    overlay[1].add_tickable_gridline("g", -30 * u.deg)
    overlay[0].add_tickable_gridline("const-glon", 30 * u.deg)
    overlay[0].grid(color="magenta")
    overlay[0].set_ticklabel_position("gt")
    overlay[0].set_axislabel("Galactic longitude")
    overlay[1].grid(color="blue")
    overlay[1].set_ticklabel_position(("const-glon", "r"))
    overlay[1].set_axislabel("Galactic latitude")
    return fig, ax


def case_set_ticks_values_spacing():
    fig, ax = new_axes(tan_wcs(), (100, 80))
    ax.coords[0].set_ticks(values=[266.35, 266.4, 266.45] * u.deg)
    ax.coords[0].set_major_formatter("d.ddd")
    ax.coords[1].set_ticks(spacing=2 * u.arcmin)
    ax.coords.grid()
    return fig, ax


def case_set_ticks_number():
    fig, ax = new_axes(tan_wcs(), (100, 80))
    ax.coords[0].set_ticks(number=3)
    ax.coords[1].set_ticks(number=10)
    return fig, ax


def case_exclude_overlapping():
    fig, ax = new_axes(tan_wcs(), (100, 80), figsize=(2.5, 2))
    ax.coords[0].set_ticks(number=12)
    ax.coords[1].set_ticks(number=12)
    ax.coords[0].set_ticklabel(exclude_overlapping=True)
    ax.coords[1].set_ticklabel(exclude_overlapping=True)
    return fig, ax


class HexagonalFrame(BaseFrame):
    # From docs/visualization/wcsaxes/custom_frames.rst.
    spine_names = "abcdef"

    def update_spines(self):
        xmin, xmax = self.parent_axes.get_xlim()
        ymin, ymax = self.parent_axes.get_ylim()

        ymid = 0.5 * (ymin + ymax)
        xmid1 = (xmin + xmax) / 4.0
        xmid2 = (xmin + xmax) * 3.0 / 4.0

        self["a"].data = np.array(([xmid1, ymin], [xmid2, ymin]))
        self["b"].data = np.array(([xmid2, ymin], [xmax, ymid]))
        self["c"].data = np.array(([xmax, ymid], [xmid2, ymax]))
        self["d"].data = np.array(([xmid2, ymax], [xmid1, ymax]))
        self["e"].data = np.array(([xmid1, ymax], [xmin, ymid]))
        self["f"].data = np.array(([xmin, ymid], [xmid1, ymin]))


def case_custom_frame():
    w = wcs2d(
        ["GLON-CAR", "GLAT-CAR"],
        ["deg", "deg"],
        [-0.006666666828, 0.006666666828],
        [75.907, 74.8485],
        [0, 0],
    )
    fig, ax = new_axes(w, (149, 149), frame_class=HexagonalFrame)
    ax.coords.grid(color="white")
    return fig, ax


CASES = {
    name[len("case_") :]: func
    for name, func in sorted(globals().items())
    if name.startswith("case_")
}

# --- view changes, applied in turn to the same figure -------------------------


def pan(fig, ax):
    x0, x1 = ax.get_xlim()
    y0, y1 = ax.get_ylim()
    ax.set_xlim(x0 + 0.3 * (x1 - x0), x1 + 0.3 * (x1 - x0))
    ax.set_ylim(y0 - 0.2 * (y1 - y0), y1 - 0.2 * (y1 - y0))


def zoom(fig, ax):
    x0, x1 = ax.get_xlim()
    y0, y1 = ax.get_ylim()
    xc, yc, hx, hy = (x0 + x1) / 2, (y0 + y1) / 2, (x1 - x0) / 5, (y1 - y0) / 5
    ax.set_xlim(xc - hx, xc + hx)
    ax.set_ylim(yc - hy, yc + hy)


def resize(fig, ax):
    w, h = fig.get_size_inches()
    fig.set_size_inches(w * 1.3, h * 0.8)


STEPS = [("pan", pan), ("zoom", zoom), ("resize", resize)]


def run_case(build):
    CALLS.clear()
    fig, ax = build()
    assert isinstance(ax, WCSAxes)
    setup_calls = dict(sorted(CALLS.items()))
    draws = [draw_and_record(fig, ax, "initial")]
    for state, step in STEPS:
        step(fig, ax)
        draws.append(draw_and_record(fig, ax, state))
    return {"setup_calls": setup_calls, "draws": draws}


def main(out):
    tables = {name: run_case(build) for name, build in CASES.items()}
    with open(out, "w") as f:
        json.dump(tables, f, indent=1, sort_keys=True)
        f.write("\n")
    for name, case in tables.items():
        calls = [
            d["calls"].get("pixel_to_world_values", 0)
            + d["calls"].get("world_to_pixel_values", 0)
            for d in case["draws"]
        ]
        errors = [d["state"] for d in case["draws"] if d["error"]]
        print(
            f"{name:28s} WCS calls per draw {calls}"
            + (f" errors {errors}" if errors else "")
        )


if __name__ == "__main__":
    main(sys.argv[1])
