import json
import sys

sys.modules["matplotlib"] = None

import numpy as np

from astropy import units as u
from astropy.visualization.wcsaxes._layout import (
    CoordSpec,
    SpineArrays,
    place_ticks,
    resample_spine,
    spine_normal_angle,
)
from astropy.visualization.wcsaxes.coordinate_range import find_coordinate_range
from astropy.wcs import WCS


class PixelToWorld:
    def __init__(self, wcs):
        self.wcs = wcs

    def transform(self, pixel):
        return np.array(self.wcs.pixel_to_world_values(*pixel.T)).T


def to_display(xy):
    return 2.0 * xy + 10.0


def from_display(xy):
    return (xy - 10.0) / 2.0


def locator(spacing):
    def locate(vmin, vmax):
        n = np.arange(np.ceil(vmin / spacing), np.floor(vmax / spacing) + 1)
        return n * spacing * u.deg, spacing * u.deg

    return locate


def formatter(values, spacing):
    return [f"{v:g}" for v in values.to_value(u.deg)]


def ticks(ctype, crval, cdelt, shape, spacing):
    wcs = WCS(naxis=2)
    wcs.wcs.ctype = ctype
    wcs.wcs.crval = crval
    wcs.wcs.cdelt = cdelt
    wcs.wcs.crpix = [(shape[0] + 1) / 2, (shape[1] + 1) / 2]
    p2w = PixelToWorld(wcs)
    x0, x1, y0, y1 = -0.5, shape[0] - 0.5, -0.5, shape[1] - 0.5
    outlines = {
        "b": [[x0, y0], [x1, y0]],
        "r": [[x1, y0], [x1, y1]],
        "t": [[x1, y1], [x0, y1]],
        "l": [[x0, y1], [x0, y0]],
    }
    spines = {}
    for name, outline in outlines.items():
        data = resample_spine(np.array(outline), 100)
        with np.errstate(invalid="ignore"):
            world = p2w.transform(data)
        spines[name] = SpineArrays(data, world, spine_normal_angle(to_display(data)))
    types = ["longitude", "latitude"]
    wraps = [360 * u.deg, None]
    ranges = find_coordinate_range(p2w, [x0, x1, y0, y1], types, [u.deg] * 2, wraps)
    result = []
    for index in range(2):
        spec = CoordSpec(
            index, types[index], u.deg, wraps[index], None,
            locator(spacing[index]), formatter,
            lambda spacing, frequency, vmin, vmax: locator(spacing.value / frequency)(vmin, vmax)[0],
            2,
        )
        placed = place_ticks(spec, ranges[index], spines, p2w.transform, to_display, from_display)
        m = placed.major
        result.append({
            "axis": "".join(m.axis),
            "world": m.world.tolist(),
            "pixel": m.pixel.round(6).tolist(),
            "angle": m.angle.round(6).tolist(),
            "text": placed.text,
            "minor": "".join(placed.minor.axis),
        })
    return result


print(json.dumps({
    "tan": ticks(["RA---TAN", "DEC--TAN"], [266.4, -28.9], [-0.002, 0.002], (100, 80), [0.05, 0.05]),
    "ait": ticks(["GLON-AIT", "GLAT-AIT"], [0, 0], [-1, 1], (300, 150), [60, 30]),
}, indent=1))
