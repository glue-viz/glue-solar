"""Collect the wcsaxes tests and doctests as if matplotlib were not installed.

sys.modules['matplotlib'] = None blocks imports. doctestplus also looks for an
installed distribution, so importlib.metadata.distribution is patched, before
pytest loads the plugin, to report no matplotlib distribution.
Usage: python collect_without_mpl.py PYPROJECT [pytest args]
"""

import importlib.metadata
import sys

sys.modules["matplotlib"] = None

_distribution = importlib.metadata.distribution


def distribution(name):
    if name == "matplotlib":
        raise importlib.metadata.PackageNotFoundError(name)
    return _distribution(name)


importlib.metadata.distribution = distribution

import pytest  # noqa: E402

sys.exit(
    pytest.main(
        ["-c", sys.argv[1], "-p", "no:cacheprovider", "-p", "no:mpl"]
        + ["--pyargs", "astropy.visualization.wcsaxes", "-q", "-rs"]
        + sys.argv[2:]
    )
)
