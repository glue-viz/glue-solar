# Does a numpy port with C-style swaps reproduce Bbox.count_overlaps exactly?
import numpy as np
from matplotlib.transforms import Bbox


def count_overlaps(box, boxes):
    if len(boxes) == 0:
        return 0
    (ax0, ay0), (ax1, ay1) = np.reshape(np.asarray(box, dtype=float), (2, 2))
    if ax1 < ax0:
        ax0, ax1 = ax1, ax0
    if ay1 < ay0:
        ay0, ay1 = ay1, ay0
    b = np.array([np.reshape(np.asarray(x, dtype=float), (2, 2)) for x in boxes])
    bx0, by0, bx1, by1 = b[:, 0, 0], b[:, 0, 1], b[:, 1, 0], b[:, 1, 1]
    swap = bx1 < bx0
    bx0, bx1 = np.where(swap, bx1, bx0), np.where(swap, bx0, bx1)
    swap = by1 < by0
    by0, by1 = np.where(swap, by1, by0), np.where(swap, by0, by1)
    return int(np.count_nonzero(~((bx1 <= ax0) | (by1 <= ay0) | (bx0 >= ax1) | (by0 >= ay1))))


rng = np.random.default_rng(0)
print("empty:", Bbox([[0, 0], [1, 1]]).count_overlaps([]), count_overlaps(Bbox([[0, 0], [1, 1]]), []))
bad = 0
for trial in range(20000):
    pts = rng.integers(0, 6, size=(8, 2, 2)).astype(float)  # small ints -> many touching edges
    if trial % 3 == 0:
        pts[rng.integers(0, 8), rng.integers(0, 2), rng.integers(0, 2)] = np.nan
    boxes = [Bbox(p) for p in pts]
    a, rest = boxes[0], boxes[1:]
    if a.count_overlaps(rest) != count_overlaps(a, rest):
        bad += 1
        if bad < 5:
            print("MISMATCH", pts[0].tolist(), a.count_overlaps(rest), count_overlaps(a, rest))
print("mismatches:", bad)
