"""tick_tables.py plus the TickLabels state the tables do not record:
xy, ha, va (keys and values), _axis_bboxes (keys and extents) and the
number of existing boxes. Usage: python c3/label_state.py OUT.json"""
import sys

sys.path.insert(0, sys.path[0] + "/..")
import tick_tables as tt  # noqa: E402

_coord_table = tt.coord_table


def coord_table(coord):
    table = _coord_table(coord)
    tl = coord._ticklabels
    table["label_state"] = {
        "xy": getattr(tl, "xy", None),
        "ha": getattr(tl, "ha", None),
        "va": getattr(tl, "va", None),
        "stale": tl._stale,
        "axis_bboxes": {k: [b.extents for b in v] for k, v in tl._axis_bboxes.items()},
        "n_existing": len(getattr(tl, "_existing_bboxes", [])),
        "dict_keys": {
            name: list(getattr(tl, name).keys())
            for name in ("world", "data", "angle", "tick_angle", "text", "disp")
        },
    }
    return table


tt.coord_table = coord_table
tt.main(sys.argv[1])
