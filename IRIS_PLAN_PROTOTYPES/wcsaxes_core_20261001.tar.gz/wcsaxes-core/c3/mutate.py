"""Apply one mutation at a time to _layout.py, run the label tests, restore."""
import os
import shutil
import subprocess
import tempfile

S = "/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes-core"
L = "/Users/nabil/Git/astropy-wcsaxes-core/astropy/visualization/wcsaxes/_layout.py"
PY = "/Users/nabil/mamba/envs/astropy-wcsaxes-core/bin/python"
GOOD = open(f"{S}/c3/_layout.py.good").read()

MUTATIONS = {
    "overlap: touching counts (<= to <)": ("(bx1 <= ax0)", "(bx1 < ax0)"),
    "overlap: no swap of boxes": ("swap = bx1 < bx0", "swap = bx1 < bx0 * 0 - 1e300"),
    "overlap: no swap of box": ("    if ax1 < ax0:\n        ax0, ax1 = ax1, ax0\n", ""),
    "keep: ignore kept": ("count_overlaps(bb, kept + existing)", "count_overlaps(bb, existing)"),
    "keep: ignore existing": ("count_overlaps(bb, kept + existing)", "count_overlaps(bb, kept)"),
    "anchor: no 60 degree cap": ("scale = np.max([scale, 0.5])", "scale = np.max([scale, 0.01])"),
    "anchor: width/height swapped": ("np.abs(height / width)", "np.abs(width / height)"),
    "anchor: pad ignored": ("dx = ax + (vx + px) * pad", "dx = ax + (vx + px) * 0"),
    "simplify: off by one": ("                return j + 1\n", "                return j\n"),
    "sort: text not sorted": (
        "labels.text[axis] = sort_using(labels.text[axis], labels.disp[axis])",
        "pass",
    ),
}

env = dict(os.environ, HOME=tempfile.mkdtemp(), XDG_CACHE_HOME=f"{S}/cache",
           MPLBACKEND="agg", QT_QPA_PLATFORM="offscreen")
try:
    for name, (old, new) in MUTATIONS.items():
        assert GOOD.count(old) == 1, name
        open(L, "w").write(GOOD.replace(old, new))
        proc = subprocess.run(
            ["nice", "-n", "19", PY, "-m", "pytest", "-c",
             "/Users/nabil/Git/astropy-wcsaxes-core/pyproject.toml", "-p", "no:cacheprovider",
             "--pyargs", "astropy.visualization.wcsaxes.tests.test_layout",
             "astropy.visualization.wcsaxes.tests.test_misc", "-q", "-k",
             "layout or count_overlaps or simplify or matches"],
            cwd=S, env=env, capture_output=True, text=True, check=False)
        failed = [l.split(" - ")[0] for l in proc.stdout.splitlines() if l.startswith("FAILED")]
        print(f"{name:40s} {'CAUGHT' if failed else 'MISSED'} {failed}")
finally:
    open(L, "w").write(GOOD)
