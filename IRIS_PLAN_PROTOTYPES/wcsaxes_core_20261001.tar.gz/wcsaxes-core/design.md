# WCSAxes layout core: design

This is the design for a conversation-starter patch to astropy. It moves WCSAxes' tick, grid and label geometry into a private module, `astropy/visualization/wcsaxes/_layout.py`, which does not import matplotlib. The matplotlib side keeps its behaviour, and every figure stays hash-identical. Standalone demos, kept outside astropy, then draw the same ticks with Qt and with bqplot.

Base: upstream main c55a2b2067 on branch `wcsaxes-layout-core` in /Users/nabil/Git/astropy-wcsaxes-core. Line numbers below are on that commit; its wcsaxes sources match the study's 1f930be7c4 line for line. Nothing in the clone was edited for this design.

The checks referred to as (a), (b), (c) and (d) are the setup report's commands: (a) the test run, (b) the figure hashes, (c) the tick tables and WCS call counts, (d) `no_mpl.py`.

## 1. Summary

- **One new private module**, `_layout.py`. It imports numpy, `astropy.units` and (from commit 2) `astropy.coordinates.angular_separation`, and nothing from the package. The formatter, locator, WCS transform, display transform and text measurement all come in as duck-typed callables. Sample counts come in as arguments, so it never needs `from . import conf`.
- **The package `__init__` stops importing matplotlib unconditionally.** It imports the matplotlib-based public API only when `HAS_MATPLOTLIB` is true. The `pytest.importorskip("matplotlib")` goes; since section 13, a `tests/conftest.py` leaves the test modules out of collection when matplotlib is missing. Section 2 explains why this is required and covers the alternatives.
- **Code moves, it is not rewritten.** The bodies of `_update_ticks`, `_compute_ticks`, `_update_grid_lines`, the `grid_paths` code builders, the tick-label sorting, simplification and anchoring, and the axis-label placement move into `_layout` with `self.` replaced by explicit arguments. The classes `CoordinateHelper`, `Ticks`, `TickLabels`, `AxisLabels`, the frames and `core.py` keep their state, style and drawing. Each one calls `_layout` at the point where the moved code used to be.
- **Four commits**, each hash-identical and each passing the full suite: (1) frame and spine geometry plus tick placement, (2) grid lines, (3) tick-label layout, (4) axis labels.
- **About 600 lines move and about 200 are new**, covering the result types, adapters, the `__init__` change, one numpy port and four tests. That is smaller than the study's estimate of 1,100 to 1,200, because the frames and the orchestration in `core.py` stay where they are.

## 2. The import rule and the package `__init__`

**Rule.** `_layout.py` imports only numpy and astropy (`astropy.units`, `astropy.coordinates`). It does not import from `.` or from any sibling module, so it pulls in matplotlib neither directly nor transitively. A test enforces this: it imports the module in a subprocess with `sys.modules["matplotlib"] = None`.

**Why `__init__` has to change.** Importing any submodule runs `wcsaxes/__init__.py` first. Today that file runs `pytest.importorskip("matplotlib")`, which raises `Skipped`, a BaseException, whenever pytest is installed and matplotlib is not. It then imports `coordinate_helpers`, `core`, `helpers` and `patches` eagerly. So no submodule can be imported without matplotlib (setup check (d)).

**Proposed `__init__.py`** (the `Conf` class is unchanged and stays after the imports, so ruff's E402 does not apply):

```python
from astropy import config as _config
from astropy.utils.compat.optional_deps import HAS_MATPLOTLIB

# The public API needs matplotlib. The private _layout module, which computes
# the tick, label and grid geometry, needs only numpy and astropy, so the
# package itself has to be importable without matplotlib.
if HAS_MATPLOTLIB:
    from .coordinate_helpers import CoordinateHelper
    from .coordinates_map import CoordinatesMap
    from .core import *
    from .helpers import *
    from .patches import *
    from .wcsapi import custom_ucd_coord_meta_mapping

class Conf(_config.ConfigNamespace): ...   # unchanged
conf = Conf()
```

- `HAS_MATPLOTLIB` is astropy's own idiom. `core.py` already uses `HAS_PIL` from the same module. It calls `find_spec`, so a broken matplotlib still fails loudly on the eager import. With `sys.modules["matplotlib"] = None` it returns False (checked in the env).
- `tests/__init__.py` gains `import pytest` and `pytest.importorskip("matplotlib")`, with a comment saying why. The test modules still skip as a group when matplotlib is missing. **Replaced in section 13** by `tests/conftest.py` with `collect_ignore_glob = ["test_*.py"]` when `HAS_MATPLOTLIB` is false; `tests/__init__.py` is back to the base.
- `pyproject.toml` `doctest_subpackage_requires` gains `"astropy/visualization/wcsaxes/* = matplotlib"`. Without it, doctestplus would fail to import `core.py` and `wcsapi.py` (which has doctests) in a CI job without matplotlib, instead of skipping them as today.
- Side effects:
  - `astropy.config.generate_config` can now import the package without matplotlib, so `[visualization.wcsaxes]` appears in the generated config in that case. This was only true without pytest until section 13: with pytest installed, the walk reached `tests/__init__.py` and raised `Skipped`.
  - The quirk where `pkgutil.walk_packages` propagates `Skipped` moved from the package down to its `tests` subpackage. Since section 13 it is gone (`fable51/probe_walk.py`).
  - Without matplotlib, `from astropy.visualization.wcsaxes import WCSAxes` would raise "cannot import name" instead of "No module named 'matplotlib'". As built after the review (section 12), the `else` branch defines a module `__getattr__` that raises `ModuleNotFoundError("astropy.visualization.wcsaxes.<name> requires matplotlib", name="matplotlib")` for the nine public names, so the error says what is missing again. `HAS_MATPLOTLIB` is imported as `_HAS_MATPLOTLIB`, so it is not a new public name or star-import export. `docs/changes/visualization/XXXXX.api.rst` records that the package now imports without matplotlib.

**Alternatives considered:**
- (a) A PEP 562 lazy `__getattr__` with a name-to-module map. It also needs `__dir__`, so that sphinx-automodapi and star imports see the names, and it changes when the submodules are imported. That is more code and more risk.
- (b) Putting the core outside the package, for example `astropy/visualization/_wcsaxes_layout.py`, which leaves `__init__` alone. The goal says the core lives inside wcsaxes, and (b) puts the code far from its only user. If reviewers prefer it, it can move with a one-line change at each import site.

## 3. Conventions at the boundary

- **Data pixels**: the axes' data coordinates, which are image pixels. Spine outlines, tick positions and grid vertices are all in data pixels.
- **Display pixels**: matplotlib's display space, with the origin at the lower left, y pointing up, and one unit per device pixel. Every angle that `_layout` returns is in display space, in degrees, counter-clockwise from +x. The 2-pixel shifts used for tick angles are applied in display space. A toolkit whose y axis points down, such as Qt, converts only when it draws.
- **Callables** (the matplotlib side passes bound methods of its live objects):
  - `pixel_to_world(xy)`: (N, 2) data pixels to (N, n_world) world values in the WCS's units. This is `transform.transform`, for example `WCSPixel2WorldTransform.transform`, which makes one `pixel_to_world_values` call.
  - `world_to_pixel(xy)`: (N, 2) world values to (N, 2) data pixels. This is `transform.inverted().transform`, used only for grid lines.
  - `to_display(xy)` and `from_display(xy)`: data pixels to display pixels and back, for (N, 2) or (2,) arrays. These are `transData.transform` and `transData.inverted().transform`.
  - `measure(text, x, y) -> (width, height)` and `extent(axis, i) -> box or None` for text, defined in section 4.3.
- **DPI** never enters `_layout` directly. The caller converts tick lengths, pads and font sizes to display pixels. Matplotlib does this with `renderer.points_to_pixels`; another toolkit uses `points * dpi / 72`.
- **Boxes** are `(x0, y0, x1, y1)`, or anything `np.asarray` turns into four numbers or a 2x2 `[[x0, y0], [x1, y1]]`. A matplotlib `Bbox` qualifies through `__array__`.

## 4. `_layout.py` API, by commit

Each entry gives the source it moves from. Docstrings follow numpydoc as configured: every parameter documented, each description ending in a period. Private helpers have no docstring, since GL08 is excluded. The hook validates private functions, nested functions and the module docstring.

### 4.1 Commit 1: spine geometry and tick placement

```python
def wrap_angle_at(values, coord_wrap)           # coordinate_helpers.py:42-46, re-imported there (format_coord and contours use it)
def resample_spine(data, n_samples)             # frame.py:240-247 (BaseFrame.sample); returns data unchanged when data.size == 0
def spine_normal_angle(pixel)                   # frame.py:105-109 (Spine._update_normal); pixel in display px -> (N-1,) inward normals, degrees

class SpineArrays(NamedTuple):                  # the attributes place_ticks reads; frame.Spine has the same three
    data: np.ndarray          # (N, 2) data px
    world: np.ndarray         # (N, n_world) = pixel_to_world(data)
    normal_angle: np.ndarray  # (N-1,) = spine_normal_angle(to_display(data))

class CoordSpec(NamedTuple):                    # field names match CoordinateHelper's, so the moved lines only swap self. for spec.
    coord_index: int                            # column of pixel_to_world output
    coord_type: str                             # 'longitude' | 'latitude' | 'scalar'
    coord_unit: u.UnitBase
    coord_wrap: u.Quantity | None               # longitude wrap; .to_value(u.deg) is called where it was before
    coord_scale_to_deg: float | None            # CoordinateHelper._coord_scale_to_deg
    locator: Callable                           # (vmin, vmax) -> (values Quantity, spacing Quantity)
    formatter: Callable                         # (values Quantity, spacing=Quantity) -> list[str]; called once with all labels
    minor_locator: Callable | None              # (spacing, frequency, vmin, vmax) -> Quantity; None means no minor ticks
    minor_frequency: int

class TickTable(NamedTuple):                    # one row per tick, in placement order: spine order, then value order, then crossing order
    axis: list[str]          # spine name (plain str, so dict keys stay str)
    world: np.ndarray        # (n,) value in coord_unit, wrapped for longitudes
    pixel: np.ndarray        # (n, 2) data px
    angle: np.ndarray        # (n,) tick direction, display space, degrees
    normal: np.ndarray       # (n,) spine normal at the crossing, which is the label pad direction
    disp: np.ndarray         # (n,) segment index + fraction along the sampled spine

class PlacedTicks(NamedTuple):
    spacing: u.Quantity            # becomes CoordinateHelper._fl_spacing (format_coord precision)
    major: TickTable
    minor: TickTable               # empty when spec.minor_locator is None
    text: list[str]                # formatter output for the major rows, in row order
    label_world: list[u.Quantity]  # what the formatter received; becomes CoordinateHelper._lbl_world (test_set_ticks_values reads it)

def place_ticks(spec, coord_range, spines, pixel_to_world, to_display, from_display,
                *, origin="lower", frame_1d=False) -> PlacedTicks
    # coordinate_helpers.py:995-1139 minus the Ticks and TickLabels writes.
    # coord_range: (vmin, vmax) for this coordinate. spines: mapping name -> object
    # with .data/.world/.normal_angle (frame.sample(n) output or SpineArrays).
    # origin: frame.origin ('lower' flips the sign of the y shift as at 1059).
    # frame_1d: isinstance(frame, RectangularFrame1D) (the 1093-1095 branch).
def _ticks_on_spine(spec, values, spine, axis, w1, w2, tick_angle, table, label_world=None)
    # coordinate_helpers.py:1141-1241; appends rows to `table` (and to label_world for major ticks)
```

Notes on the move:

- The nested `shifted_pixel_to_world`, the NaN fallbacks, the `wrap_angle_at(dx, 180.0)` steps, the flip test against `np.hstack([normal, normal[-1]])` and every `np.errstate` block move unchanged. Tests run with `filterwarnings = error`, so a lost `errstate` would turn into a failure.
- The `# TODO: this method should be optimized for speed` comment moves with the code.

As built in commit 1 (5d9e3d625d), where it differs from the sketch above:

- `_ticks_on_spine(spec, tick_world_coordinates, spine, axis, w1, w2, tick_angle, rows, label_world=None)`. It keeps the old parameter name, so the moved body reads the same, and appends `(axis, world, (x, y), angle, normal, disp)` tuples to `rows`. A private `_tick_table(rows)` turns them into a `TickTable` with float64 arrays, `pixel` shaped (n, 2) even when empty.
- `PlacedTicks.text` is what the formatter returned, unconverted. `_update_ticks` zips it as the old code did.
- `TickTable.axis`, `PlacedTicks.text` and `label_world` are annotated as plain `list`.
- `_layout` has an `__all__`, as `_auto.py` does. `wrap_angle_at` keeps no docstring, and the other public names have numpydoc docstrings.
- Test (2) in section 8 calls `ax._update_tick_and_label_positions()` after the draw and compares against that. Drawing sorts and simplifies `_ticklabels` in place (`simplify_labels` in `_set_xy_alignments`), so after a draw the texts and label normals are no longer in formatter order. The second placement uses the settled `transData`, from which the test also takes its affine. It also compares the label normals with `TickTable.normal` to 1e-9 degrees.
- Test (1) places ticks for a TAN image (100x80) and an AIT all-sky image (300x150 at 1 degree per pixel, wrap 360). Its corners are off the sky, so it runs the NaN fallbacks, and the longitude seam falls mid-spine. It uses 100 samples per spine, display = 2 * data + 10 so that swapping `to_display` and `from_display` is caught, and plain-function locators and formatter. Values are stored to 6 decimals. Mutation check: swapping the display transforms or removing the `+= 360` seam fix fails it. Removing the dx NaN fallback does not, because no tick lands within one sample of the limb. The all-sky figure tests and the tick tables cover that line.

### 4.2 Commit 2: grid lines

```python
MOVETO = 1   # equal to matplotlib.path.Path.MOVETO; a test asserts it
LINETO = 2
ROUND_TRIP_RTOL = 1.0     # grid_paths.py:10, which re-imports it
DISCONT_FACTOR = 10.0     # grid_paths.py:13, which re-imports it

def lon_lat_path_codes(lon_lat, pixel, lon_lat_check) -> np.ndarray   # grid_paths.py:35-85, the codes part of get_lon_lat_path
def gridline_path_codes(world, pixel) -> np.ndarray                   # grid_paths.py:103-113, the codes part of get_gridline_path
def grid_lines(spec, coord_ranges, n_samples, pixel_to_world, world_to_pixel)
        -> list[tuple[np.ndarray, np.ndarray]] | None
    # coordinate_helpers.py:1293-1339 plus _get_gridline (1457-1461).
    # coord_ranges: the full parent_map._coord_range list (the other coordinate's range is the sampling axis).
    # Returns one (pixel (n_samples, 2), codes (n_samples,) uint8) per tick value,
    # or None when the locator gives no ticks.
```

- `grid_paths.get_lon_lat_path` and `get_gridline_path` keep their signatures and still return `Path(pixel, codes=...)`. `test_grid_paths.py` and `add_tickable_gridline` use them.
- A break in a grid line is a `MOVETO` code. A non-matplotlib caller splits at `codes == MOVETO` and drops NaN vertices.

As built in commit 2, where it differs from the sketch above or adds to it:

- The scalar or lon/lat dispatch of `CoordinateHelper._get_gridline` is moved as a private `_layout._gridline(spec, xy_world, pixel, xy_world_round) -> (pixel, codes)`. `CoordinateHelper._get_gridline` itself stays unchanged, because `add_tickable_gridline` still uses it, and it now reaches the moved code through the `grid_paths` wrappers.
- The comment about a WCS with more than two axes moved into `grid_lines`, so the cross-reference in `add_tickable_gridline` now says `_layout.grid_lines()`.
- `grid_paths` re-imports `DISCONT_FACTOR` and `ROUND_TRIP_RTOL` with `# noqa: F401`, which is how astropy marks re-exports outside `__init__.py`, plus a comment saying why. It drops its numpy and `angular_separation` imports.
- `_update_grid_lines` builds `Path(pixel, codes=codes)` from the same slices of the same arrays as before, so each Path's vertices are still views into one shared pixel array.
- Tests in `test_layout.py`:
  - The subprocess test is renamed `test_layout_without_matplotlib`. It also samples grid lines for the TAN and AIT images, with 50 samples per line, and stores each line's `MOVETO` indices plus its first, middle and last vertex. The AIT latitude lines break at index 25, where they cross the longitude seam.
  - The AIT latitude spacing went from 30 to 50 degrees. At 30, the locator puts grid lines on the poles. There every sample is the same point, `scale_size` is 0, and the round-trip mask depends on rounding noise (here 49 of the 50 codes came out as `MOVETO`), so the stored values would not be portable. At 50 the major ticks are unchanged, and the minor string changes from `bbrrrttlll` to `bbrttl`, which still has minor ticks on the bottom and top spines near the limb.
  - `test_path_codes_match_matplotlib` checks that `MOVETO` and `LINETO` equal matplotlib's codes.
  - `test_gridline_path_codes` checks that a NaN pixel breaks the line and that the line resumes at the next point. Nothing else covers this: neither the tick tables nor the figure tests draw a scalar 'lines' grid with invalid pixels.
  - `test_grid_lines_match_wcsaxes` is parametrized over a rolled HPC TAN WCS, which uses `lon_lat_path_codes`, and over a rolled linear WCS with empty ctypes, which uses `gridline_path_codes`. It draws with `ax.coords.grid()`, then recomputes from plain inputs: APE 14 functions, `find_coordinate_range` and `conf.grid_samples`. It asserts that the vertices and codes are exactly equal to `_grid_lines`.
  - Limit: after the move, both sides of that comparison run `_layout`, so it guards the plumbing (the callables, the ranges and the spec) and not the algorithm. Identity of the algorithm is guarded by the figure hashes and the tick tables against the pre-move baseline.
  - Mutation check: each of these fails at least one test. Swapping `world_to_pixel` for `pixel_to_world` fails the subprocess test, and so do removing the discontinuity `MOVETO`s and sampling along the wrong coordinate's range. Removing the after-NaN `MOVETO` in `gridline_path_codes` fails `test_gridline_path_codes`. Disabling the round-trip mask fails the existing `test_grid_paths.test_round_trip_visibility`, through the wrapper.

### 4.3 Commit 3: tick-label layout

`labels` below means any object with dict attributes `world`, `data`, `angle`, `tick_angle`, `text` and `disp`, each mapping a spine name to a list. `TickLabels` already is one. A demo uses a `types.SimpleNamespace` of `defaultdict(list)`. The functions index these dicts exactly as the old methods did, so a defaultdict gets the same empty keys as before. Those keys appear in the tick tables.

```python
def sort_using(X, Y)                                       # ticklabels.py:14-15 (ties fall back to comparing X, kept)
def find_start_of_last_number(label, numerical_chars)      # ticklabels.py:18-40; the caller derives numerical_chars from rcParams
def sort_labels(labels)                                    # ticklabels.py:144-150 (TickLabels.sort body), in place
def simplify_labels(labels, numerical_chars)               # ticklabels.py:159-195 (the loop after self.sort()), in place
def anchor_tick_labels(labels, visible_axes, to_display, pad, measure) -> dict[str, dict[int, tuple]]
    # ticklabels.py:238-305 (_set_xy_alignments minus the stale flag and the ha/va dicts).
    # pad: (pad + tick out size) in display px, computed once (it was recomputed per label, always the same value).
    # measure(text, x, y) -> (width, height) of the text placed at the tick (x, y), before anchoring.
def count_overlaps(box, boxes) -> int
    # port of matplotlib Bbox.count_overlaps: same swaps, same <=/>= comparisons, no arithmetic
def keep_tick_labels(labels, visible_axes, extent, exclude_overlapping, existing)
        -> Iterator[tuple[str, int, box]]
    # ticklabels.py:358-376. Yields (axis, i, box) for each label to draw, in draw order,
    # right after extent(axis, i) is called for it. extent returns None for an empty
    # label. existing: boxes of the coordinates drawn before.
```

`keep_tick_labels` is a generator so that the matplotlib side keeps today's interleaving exactly. `extent` sets the Text's text, position and alignment and measures it. The caller draws as soon as the label is yielded, and only then is the next label measured.

As built in commit 3 (46ca35f7d1), where it differs from the sketch above or adds to it:

- The label storage convention (the six dicts, `angle` being the spine normal) and the box forms are described once in the `_layout` module docstring. Each function's `labels` parameter refers to it.
- `ticklabels.py` uses `from . import _layout` and calls `_layout.sort_labels` and so on, rather than importing the names as `coordinate_helpers.py` does. Otherwise `TickLabels.simplify_labels` would call a bare `simplify_labels`, which reads like recursion. `ticklabels.py` drops its numpy import.
- `numerical_chars` is derived inline in `TickLabels.simplify_labels`, with the same lines that were in `_find_start_of_last_number`.
- `_set_xy_alignments` defines `measure` as a closure over `super().get_window_extent`, because zero-argument `super()` does not work inside a nested function. It then builds `ha` and `va` with `dict.fromkeys` over the keys of `xy`, which gives the same keys in the same order.
- `anchor_tick_labels` passes `labels.data[axis][i]`, a tuple, to `to_display`, as the old code passed it to `transData.transform`. So a non-matplotlib `to_display` must accept a tuple, for example through `np.asarray`.
- `keep_tick_labels` keeps its own list of the boxes it has yielded and counts overlaps against `kept + existing`. A count does not depend on order, and the list is in the same order as `_all_bboxes` anyway. The matplotlib caller still appends each box to `_axis_bboxes`. It binds the unused index as `_` (ruff B007).
- `count_overlaps` handles the empty list through `reshape(-1, 4)`, with no special case.
- Tests in `test_layout.py`:
  - The subprocess test also lays out the tick labels: it builds a `SimpleNamespace` of `defaultdict(list)` as `_update_ticks` fills `TickLabels`, then runs `sort_labels`, `simplify_labels(labels, "0123456789.+-")`, `anchor_tick_labels` (labels on all four spines, pad 8, text 7 px per character by 12 px) and `keep_tick_labels` with `exclude_overlapping=True`. It stores the simplified texts, the anchors to 1e-6 and the kept labels.
  - Its formatter changed from `f"{v:g}"` to degrees and arcminutes (`266d18m`). With all-numeric strings `simplify_labels` never drops anything, because `find_start_of_last_number` finds no non-number character. So the stored `text` values of commits 1 and 2 changed; nothing else did.
  - `existing` starts with one box over the middle label on the bottom spine of the TAN image, which is dropped. Without it, no label of the second coordinate meets one of the first in either image, so ignoring `existing` would go unnoticed. In the AIT image every other label on the bottom and top spines overlaps its neighbour and is dropped.
  - `test_count_overlaps_matches_matplotlib`: 2,000 seeded cases (seed 0), each one box against 7, with corners on a 6x6 integer grid and a NaN corner in one case in three. Each case is run with `Bbox` objects and with plain (x0, y0, x1, y1) arrays. The empty list gives 0 for both.
  - `test_anchor_tick_labels`: one 40x10 label whose normal and tick are both at 30 degrees, checked against the anchor worked out by hand, plus an empty label that must be left out. It was added because every spine normal in the subprocess test is axis-aligned, so swapping width and height in the branch test went unnoticed.
  - Mutation check: each of these fails at least one test. In `count_overlaps`, turning `<=` into `<`, or dropping the swap of the box or of the boxes. In `keep_tick_labels`, ignoring the kept boxes or `existing`. In `anchor_tick_labels`, removing the 60-degree cap, swapping width and height, or ignoring the pad. Returning `j` instead of `j + 1` in `find_start_of_last_number`, which also fails the existing `test_simplify_cases`. Not sorting the text in `sort_labels`.
- Extra identity check: `c3/label_state.py` runs `tick_tables.py` and also records the `TickLabels` state that the tables do not: `xy`, `ha`, `va`, `_stale`, the `_axis_bboxes` extents, the number of existing boxes, and the keys of the six dicts. Its output on the tree before the change and after the change is byte-identical (`c3/label_state_before.json` and `runs/c3/label_state.json`).

### 4.4 Commit 4: axis labels

```python
def spine_midpoint(pixel, normal_angle) -> tuple[float, float, float]
    # frame.py:115-129 (Spine._halfway_x_y_angle); pixel in display px; returns x, y and the outward normal
def axis_label_position(axis, x, y, normal_angle, padding, text_size, rectangular, union)
        -> tuple[float, float, float]
    # axislabels.py:98-101 and 123-145; returns x, y and the rotation in degrees.
    # rectangular: isinstance(frame, RectangularFrame) (False for 1-D and elliptical frames).
    # union: (x0, y0, x1, y1) of the tick-label union when the label is pushed past it,
    # else None. The `visible` condition at 119-121, which decides this, stays in AxisLabels.
    # padding and text_size are in display px.
```

As built in commit 4, where it differs from the sketch above or adds to it:

- `spine_midpoint` sits next to `spine_normal_angle`, and `axis_label_position` at the end of the module. `Spine._halfway_x_y_angle` is `return spine_midpoint(self._get_pixel(), self.normal_angle)`, which reads the pixels and then the normals, in the old order.
- `union` follows the module's box convention: `axis_label_position` reads it with `np.asarray(union, dtype=float).reshape(4)`, as `count_overlaps` does. So `AxisLabels` passes the union `Bbox` itself rather than `.extents`, and a demo passes a 4-tuple. The core reads `x0` and `y0` where `AxisLabels` read `.xmin` and `.ymin`. For a box built by `Bbox.union` these are the same float64 values, because its corners are the min and max over the boxes (or NaN on both sides), see 6.8(j).
- `AxisLabels.draw` sets `rectangular = isinstance(...)` and `union = None`, keeps the union and `[None]` bookkeeping and the `visible` test, then calls `axis_label_position` and sets the rotation and the position. The "Find label position" comment moved with the code. `axislabels.py` drops its numpy import.
- Tests: no new test function, but the no-matplotlib subprocess test now also places axis labels, so the moved code has a check that runs without matplotlib. For each coordinate and each spine that has its tick labels, it takes `spine_midpoint` of the unsampled outline in display pixels, as `_halfway_x_y_angle` does, and calls `axis_label_position` with a padding of 12 and a font size of 10 pixels. The TAN image is treated as rectangular, with the union of the tick-label boxes kept so far. The AIT image is treated as not rectangular, which runs the move along the normal. It stores x, y and the rotation; the bottom spine gives 360 degrees, so the upright flip is covered.
- Mutation check: each of these fails the subprocess test. Removing the upright flip; reading `x1` for `l` or `y0` for `t`; turning `+ padding` into `- padding` on `r`; ignoring `union`; changing the 1.5 or swapping `sin` for `cos` in the move along the normal; dropping the `+ 180` from the midpoint normal; interpolating at a quarter instead of halfway. A wrong segment index (`imin`) goes unnoticed, because the test spines are straight. The elliptical and hexagonal frames in the figure tests and tick tables cover it. `_layout.py` was restored from `c4/_layout.py.good` and checked by sha.
- Extra identity check: `c3/label_state.py` still gives output byte-identical to `c3/label_state_before.json`. The tick tables' `drawn_text` records the position and rotation of every drawn axis label.

## 5. What stays where, and how it calls the core

**CoordinateHelper** keeps every setter and getter, the style state, `format_coord`, `tick_params`, `add_tickable_gridline`, contour grids, the 1-D grid, `_draw_*` and the `_clear_grid_contour` handling. New and changed pieces:

```python
def _layout_spec(self):
    return _layout.CoordSpec(
        self.coord_index, self.coord_type, self.coord_unit, self.coord_wrap,
        self._coord_scale_to_deg, self.locator, self.formatter,
        self._formatter_locator.minor_locator if self._ticks.get_display_minor_ticks() else None,
        self.get_minor_frequency())

def _update_ticks(self):
    if self.coord_index is None:
        return
    from . import conf
    transData = self.parent_axes.transData
    placed = _layout.place_ticks(
        self._layout_spec(), self.parent_map._coord_range[self.coord_index],
        self.frame.sample(conf.frame_boundary_samples),
        self.transform.transform, transData.transform, transData.inverted().transform,
        origin=self.frame.origin, frame_1d=isinstance(self.frame, RectangularFrame1D))
    self._fl_spacing = placed.spacing
    self._lbl_world = placed.label_world
    self._ticks.clear()
    self._ticklabels.clear()
    m = placed.major
    for axis, world, (x, y), angle, disp in zip(m.axis, m.world, m.pixel, m.angle, m.disp):
        self._ticks.add(axis=axis, world=world, pixel=(x, y), angle=angle, axis_displacement=disp)
    for row in zip(...minor...):
        self._ticks.add_minor(...)
    for axis, world, (x, y), angle, normal, disp, txt in zip(m.axis, m.world, m.pixel, m.angle, m.normal, m.disp, placed.text):
        self._ticklabels.add(axis=axis, world=world, data=(x, y), angle=normal, tick_angle=angle,
                             axis_displacement=disp, text=txt)

def _update_grid_lines(self):          # commit 2
    if self.coord_index is None:
        return
    from . import conf
    lines = _layout.grid_lines(self._layout_spec(), self.parent_map._coord_range, conf.grid_samples,
                               self.transform.transform, self.transform.inverted().transform)
    if lines is not None:
        self._grid_lines = [Path(pixel, codes=codes) for pixel, codes in lines]
```

- The tick loop and the label loop must stay separate. The old code added every tick, and then zipped the labels with the formatter output, so a formatter returning fewer strings drops labels but not ticks.
- `_compute_ticks` and `_lblinfo` disappear. Both are private and only `_update_ticks` used them.
- `_lbl_world` and `_fl_spacing` remain.

**Ticks** (a Line2D) is unchanged. It keeps its storage, its style and `draw` with one `draw_markers` per tick, and records `ticks_locs`.

**TickLabels** (a Text) keeps its storage, `add`, `clear`, its style, `_get_bb`, `_all_bboxes` and the deprecated `draw` arguments.

- `sort()` calls `_layout.sort_labels(self)`. `simplify_labels()` calls `self.sort()`, then `_layout.simplify_labels(self, numerical_chars)`, and sets `_stale`.
- `numerical_chars` is computed from `rcParams["axes.unicode_minus"]` and `rcParams["text.usetex"]` exactly as at 28-32, once per simplify.
- `_set_xy_alignments` calls `_layout.anchor_tick_labels(self, visible_axes, transData.transform, pad, measure)`. Its `measure` does what lines 255-257 do: `set_text`, `set_position((x, y))`, `Text.get_window_extent(renderer)`, and returns width and height.
- It then fills `self.xy`, and fills `self.ha` and `self.va` with "center" for the same keys.
- `draw` becomes:

```python
for axis, i, bb in _layout.keep_tick_labels(self, self.get_visible_axes(),
                                            lambda axis, i: self._get_bb(axis, i, renderer),
                                            self._exclude_overlapping, self._existing_bboxes):
    super().draw(renderer)
    self._axis_bboxes[axis].append(bb)
```

  The `_find_start_of_last_number` and `sort_using` module functions leave `ticklabels.py`. They are private and nothing else uses them.

**AxisLabels** (a Text) keeps the visibility rules, the flattening of every coordinate's tick-label boxes, `Bbox.union`, and the in-place write of `[union]` or `[None]` into the coordinate's `_axis_bboxes`. It also keeps the draw and the appending of its own box to `bboxes`. Inside the spine loop:

```python
x, y, normal_angle = self._frame[axis]._halfway_x_y_angle()
union = None
if rectangular := isinstance(self._frame, RectangularFrame):
    ...union / [None] bookkeeping unchanged...
    if axis in visible_ticks and coord_ticklabels_bbox[axis][0] is not None:
        union = coord_ticklabels_bbox[axis][0].extents
x, y, rotation = _layout.axis_label_position(axis, x, y, normal_angle, padding, text_size, rectangular, union)
self.set_rotation(rotation)
self.set_position((x, y))
```

- `.extents` of a union Bbox is `(xmin, ymin, x1, y1)` as read at 125-140, because `Bbox.union` builds its corners from min and max.

**Frames** keep the public classes, `update_spines`, `patch`, `_update_patch_path`, `draw`, colour and linewidth, and the `Spine` data, world and pixel properties. The only changes are three one-line delegations:

- `Spine._update_normal` sets `self.normal_angle = _layout.spine_normal_angle(self._get_pixel())`.
- `Spine._halfway_x_y_angle` returns `_layout.spine_midpoint(self._get_pixel(), self.normal_angle)`.
- `BaseFrame.sample` sets `spines[axis].data = _layout.resample_spine(data, n_samples)`.

Sampling still builds `spine_class` instances, so custom spine classes, `data_func` spines and the 1-D `SpineXAligned` behave as before.

**core.py** is not touched. It still orchestrates across coordinates: `_update_tick_and_label_positions`, `auto_assign_coord_positions`, the order in `draw_wcsaxes`, `_bboxes`, `get_tightbbox`, the eager `set_xlabel`, overlays and transforms.

**coordinate_range.py and _auto.py** are not touched. After commit 1, `coordinate_range` imports without matplotlib, since its `from . import conf` now works, and the demos call it directly.

## 6. Keeping every figure hash-identical

1. **Moves are verbatim.** Expressions, operand order, numpy calls and dtypes stay the same. The scalar loops are not vectorized and nothing is reassociated: `w1 = w1 * scale` stays as written and `world /= scale` stays in place.
2. **The matplotlib side passes `transData.transform` and `transData.inverted().transform`.** It does not pass a matrix rebuilt from `get_matrix()`. `transData` is the composite `transScale + (transLimits + transAxes)`. Its `transform` runs the non-affine step and then the frozen affine, and its inverse comes from matplotlib's own matrix inversion. A hand-built 2x2 matrix agrees only to about one ULP. That is enough to flip Agg's rounding of a text position or a marker now and then.
3. **The WCS transform is passed as `self.transform.transform`, and `frame.sample()` still makes the spines.** So overlays (pixel to world plus `CoordinateTransform`), custom transforms, `invert_xy` and 1-D spines run as before. The WCS calls have the same number and inputs, so the counts in check (c) do not change.
4. **Results go back into `Ticks` and `TickLabels` as the same values, in the same order.**
   - Every value the loop produces is already a float64 scalar, so stacking into float64 arrays and iterating back is exact, and the types are still `np.float64`.
   - `axis` stays a list of `str`. Tick rows keep the global placement order, so per-spine list order, dict key insertion order and the single formatter call all match.
5. **Text measurement still goes through matplotlib, in the same sequence.**
   - `measure` and `extent` are today's `set_text`, `set_position`, `set_ha`/`set_va` and `get_window_extent` sequences.
   - All anchors are measured before any extent, as with `_set_xy_alignments` before the draw loop. During measuring, ha and va keep whatever value the previous draw left.
   - The generator interleaves extent and draw per label as the old loop did.
6. **The overlap port uses comparisons only.** It reproduces the C routine, including the swap of reversed boxes and NaN making a box count as overlapping. `design_checks/overlaps_check.py` found 0 mismatches against `Bbox.count_overlaps` in 20,000 random cases, each one box against 7 others, with corners on a 6x6 integer grid. Integer corners give many touching edges and reversed boxes, and a third of the cases contain a NaN. The empty list gives 0 for both. Commit 3 turns this into a seeded test. `Bbox.union` stays on the matplotlib side.
7. **rcParams are read on the matplotlib side and passed in as values, at the same moment as before:** the numerical characters per simplify, the tick sizes and pads per draw.
8. **The lines that are not verbatim**, and why each one is safe:
   - (a) In the 1-D branch, the length of `tick_angle` is `spine.data.shape[0]` instead of `conf.frame_boundary_samples`. These are equal after `sample()`.
   - (b) `place_ticks` gets spines that are already sampled, so the locator now runs after `frame.sample()`. Both are pure, and neither changes the WCS call sequence.
   - (c) The private state left by a draw that raises part way through `_update_ticks` differs (corrected in section 13). Base order: locator, which sets `_fl_spacing`; minor locator; `frame.sample`; clear `_ticks`, `_ticklabels`, `_lbl_world`; add each tick as it is found; formatter; add labels. Branch order: clear `_ticks` and `_ticklabels`; `frame.sample`; `place_ticks` (locator, minor locator, placement, formatter); set `_fl_spacing` and `_lbl_world`; add ticks; add labels. So:
     - a raising locator leaves the previous ticks on the base, and no ticks on the branch;
     - a raising minor locator or `frame.sample` leaves the new spacing and the previous ticks on the base, and the previous spacing and no ticks on the branch;
     - a WCS call that raises during placement leaves part of the new ticks and of `_lbl_world` on the base, and no ticks with the previous spacing on the branch;
     - a raising formatter leaves the new ticks, spacing and `_lbl_world` on the base, and no ticks with the previous spacing and `_lbl_world` on the branch.

     The draw raises in both trees and the next draw recomputes everything; only private state in between differs, and `format_coord` reads `_fl_spacing`. The first review's premise that the base cleared before the locator was wrong: it cleared after `frame.sample`, so "as before" did not hold.
   - (d) Until section 13, `_update_grid_lines` built `transform.inverted()` before the no-ticks return, so a transform whose `has_inverse` is true but whose `inverted()` raises made a draw with no ticks raise. It now passes `lambda world: self.transform.inverted().transform(world)`, which `grid_lines` calls once and only when there are ticks, as before.
   - (e) `pad` is computed once per anchor pass instead of once per label. It is the same value.
   - (f) The overlap port.
   - (g) In `_update_grid_lines`, `_grid_lines` is replaced once the new lines are computed. Before, it was emptied before the WCS calls. The two differ only if a transform raises (commit 2).
   - (h) `TickLabels` reads `transData.transform` once per draw instead of once per non-empty label. As built in commit 3 before the review, it also read `_tick_out_size` and `_existing_bboxes` eagerly, so a `TickLabels` drawn before `CoordinateHelper._draw_ticks` set them raised AttributeError even with no labels; the deprecated public `CoordinateHelper.ticklabels` accessor reaches that. After the review, `_tick_out_size` is read only if a visible spine has a non-empty label, and `_existing_bboxes` only if `exclude_overlapping` is on, as before; `review-identity/direct_draw.py` gives OK for both cases, as on the base. The one case left: with `exclude_overlapping` on and no non-empty labels, an unset `_existing_bboxes` is now read (and raises) where the old loop never reached it (commit 3).
   - (i) The numerical characters for `simplify_labels` are read from rcParams once per call instead of once per `find_start_of_last_number` call. rcParams cannot change in between (commit 3).
   - (j) `AxisLabels.draw` calls `set_rotation` after the union bookkeeping instead of before it. Nothing in between reads the rotation. The union's left and bottom edges are read as its corner `x0` and `y0` instead of `.xmin` and `.ymin`. `Bbox.union` builds the corner from `np.min` over the boxes and the opposite corner from `np.max`, so `x0 <= x1` and the two reads give the same float64 value, or NaN for both (commit 4).
9. **Quirks kept on purpose.** These belong to separate, hash-changing patches:
   - `_update_grid_lines` leaves the previous `_grid_lines` in place when there are no ticks.
   - `sort_using` breaks ties per field.
   - Axis labels are pushed past the union of every coordinate's tick labels, and `_axis_bboxes` is mutated.
   - `coords.frame.update()` does nothing.
   - 'lines' grids fail with three visible coordinates.
   - `format_coord` raises on the 1-D frame (the tick tables record that error).
10. **Unchanged private state is what keeps check (c) byte-identical.** `tick_tables.py` reads `_ticks`, `_ticklabels`, `_axislabels`, `_grid_lines`, `_grid`, `_fl_spacing`, the spine `.data` and `ax._all_coords`, and all of these keep their names, types and contents. It needs no changes.

## 7. APIs and extension points that must keep working

**Public API.**
- `WCSAxes`, including `projection=wcs`, `slices`, `frame_class` and `transData=`.
- `reset_wcs`, which keeps the frame Path's identity, colour and linewidth.
- `get_coords_overlay`, and `get_transform`, which returns a matplotlib Transform.
- `plot_coord`, `scatter_coord`, `text_coord`, the `imshow` and `contour` overrides, `grid`, `tick_params`, and `set_xlabel`/`get_xlabel` and their y versions, all still eager.
- `CoordinatesMap` indexing, aliases and repr.
- Every `CoordinateHelper` setter and getter:
  - `set_ticks`, `set_ticklabel(**Text kwargs)`, `set_axislabel(**Text kwargs)`;
  - `set_major_formatter` with a string or a callable; the callable still gets one call with every label;
  - `set_format_unit`, `set_separator`, the position, visibility and rule setters, the minor-tick setters;
  - `add_tickable_gridline`, `format_coord`, and the `locator` and `formatter` properties.
- `conf` and its four items, including `conf.set_temp`. `custom_ucd_coord_meta_mapping`.
- `SphericalCircle`, `Quadrangle`, `add_beam` and `add_scalebar`, which stay matplotlib-only.

**Extension points.**
- `BaseFrame` subclasses, with `spine_names`, `update_spines` reading `parent_axes.get_xlim()`, and the overrides `_update_patch_path` and `draw` (custom_frames.rst:81-97). Also `spine_class` and `Spine(data_func=...)`.
- Transforms: any matplotlib Transform with `transform`, `inverted` and `has_inverse` (generic_transforms.rst), and overlay composites.
- Custom formatter callables.
- rcParams defaults (`xtick.*`, `grid.*`, `axes.unicode_minus`, `text.usetex`, `axes.grid`) and `axisbelow`.

**Private state that downstream code and tests rely on.**
- `_ticks`: `world`, `pixel`, `angle`, `disp`, the `minor_*` fields, `ticks_locs`, `get_visible`, `get_visible_axes`.
- `_ticklabels`: `world`, `data`, `angle`, `tick_angle`, `text`, `disp`, `xy`, `ha`, `va`, `_axis_bboxes`, `_all_bboxes`.
- `_axislabels`, `_fl_spacing`, `_lbl_world` (test_coordinate_helpers.py:396), `_coord_range`, `_grid_lines` as a list of Path, `_grid`, `frame._path`, `ax._all_coords`.
- `coordinate_helpers.wrap_angle_at`.
- `grid_paths.get_lon_lat_path` and `get_gridline_path`, which still return a Path.
- glue's `frame.set_color` and `reset_wcs`, and mpl-animators' `reset_wcs` on every frame.

## 8. Commit plan

The commits go on `wcsaxes-layout-core` in the clone. Each passes checks (a) to (d) and lint by itself, and none touches figure hashes. The subjects follow astropy's style. The bodies explain why, and say that the diff reads best with `git diff --color-moved=dimmed-zebra --color-moved-ws=allow-indentation-change`.

Each message ends with the line `Claude-Session: https://claude.ai/code/session_016GzY8z27NRe3KLiFYRzsHk`. Messages contain no `#NNNN`, no `owner/repo#NNNN`, no github.com issue, PR or discussion URLs and no @-mentions. Related work is described in words, for example "the open astropy issue about making WCSAxes usable from other plotting libraries".

Only named files are staged. There is one changelog entry, `docs/changes/visualization/XXXXX.api.rst`, for the import behaviour without matplotlib (section 12). astropy names fragments by PR number; the precedent (commit 9e102cbe1a) is to commit `XXXXX.<type>.rst` and rename it once the PR exists. `other` is not allowed in sub-package directories.

1. **Move WCSAxes tick placement into a matplotlib-free module**
   - Files:
     - `wcsaxes/__init__.py` (section 2) and `wcsaxes/tests/__init__.py`;
     - `pyproject.toml` (one `doctest_subpackage_requires` line);
     - new `wcsaxes/_layout.py` (section 4.1);
     - `frame.py` (normals and resampling);
     - `coordinate_helpers.py` (`_layout_spec`, `_update_ticks`, remove `_compute_ticks`, import `wrap_angle_at`);
     - new `wcsaxes/tests/test_layout.py`.
   - Tests:
     - (1) In a subprocess with `sys.modules["matplotlib"] = None`, import `_layout` and `coordinate_range`.
     - (2) Draw a rolled helioprojective TAN `WCSAxes` on Agg. Recompute its ticks with `place_ticks`, using only numpy inputs: the rectangle outline, `resample_spine`, an APE 14 adapter, `spine_normal_angle` with a numpy affine taken from `transData.get_matrix()`, `find_coordinate_range`, and a spec built from the helper's locator and formatter.
     - Assert that world values, pixel positions and texts are exactly equal to `_ticks` and `_ticklabels`, and that the angles agree to 1e-9 degrees.
   - Why this is the smallest convincing step: the most expensive and most intricate part of WCSAxes, the tick placement, runs from plain arrays and callables, and the figures do not change.
2. **Compute WCSAxes grid lines in the matplotlib-free layout module**
   - Files: `_layout.py` (section 4.2), `grid_paths.py` (wrappers), `coordinate_helpers.py` (`_update_grid_lines`), and `test_layout.py`.
   - Test: `MOVETO` and `LINETO` equal matplotlib's codes, and `grid_lines` from plain inputs equals the vertices and codes of `_grid_lines`. As built, there are also grid lines in the no-matplotlib subprocess test and a NaN-break test of `gridline_path_codes`; see "As built in commit 2" in section 4.2.
3. **Lay out WCSAxes tick labels in the matplotlib-free layout module**
   - Files: `_layout.py` (section 4.3), `ticklabels.py`, and `test_layout.py`.
   - Test: a seeded randomized comparison of `count_overlaps` with `Bbox.count_overlaps`, including touching boxes, reversed boxes, NaN and the empty list. As built, there is also a label layout in the no-matplotlib subprocess test and a hand-computed anchor test; see "As built in commit 3" in section 4.3.
4. **Place WCSAxes axis labels in the matplotlib-free layout module**
   - Files: `_layout.py` (section 4.4), `frame.py` (`_halfway_x_y_angle`), `axislabels.py`.
   - No new test. Axis labels are covered by the figure tests and by `drawn_text` in the tick tables. As built, the no-matplotlib subprocess test also places axis labels; see "As built in commit 4" in section 4.4.

**Checks for every commit**, run from the setup report under `nice -n 19` with counts only and no timing:
- (a) The test run, default and with `--remote-data=any`. The counts equal the baseline plus the new tests.
- (b) `compare_figures.sh` gives 59 out of 59 hash-identical.
- (c) `cmp baseline/tick_tables.json` prints IDENTICAL, and the WCS calls per draw equal `baseline/tick_tables_counts.txt`.
- (d) `no_mpl.py`, without `--hide-pytest`, reports OK for `astropy.visualization.wcsaxes`, `astropy.visualization.wcsaxes._layout` and `astropy.visualization.wcsaxes.coordinate_range`. This applies from commit 1 on.
- No-matplotlib collection. All tests and doctests should be skipped, with no errors:

  ```
  python c1/collect_without_mpl.py <clone>/pyproject.toml
  ```

  It prints `12 skipped` and exits with 5, meaning no items. Changed in commit 1: the earlier one-liner, which only set `sys.modules['matplotlib'] = None`, cannot simulate a missing matplotlib. doctestplus's `ModuleChecker` also accepts an installed distribution (`importlib.metadata.distribution`), so with only the import blocked it still collects `core.py` and the other modules and gives 13 import errors, even with the `doctest_subpackage_requires` line in place. The script also patches `importlib.metadata.distribution` to report no matplotlib, before pytest loads the plugin; importing doctestplus first trips an assert-rewrite warning, which the config turns into an error. With the new line removed through `-o`, the same run gives the 13 errors, so the line is what keeps the doctests skipped.
- Lint on the touched files: `ruff check` and `ruff format --check` (0.15.20), `codespell` (2.4.3), `python -m numpydoc.hooks.validate_docstrings` (1.10.0), and the pre-commit file hygiene checks (end-of-file and trailing whitespace).
- Commit-message check before any push:

  ```
  git log --format=%B c55a2b2067..wcsaxes-layout-core | grep -nE '#[0-9]+|[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+#[0-9]+|github\.com/[^ ]+/(issues|pull|discussions)/|@[A-Za-z0-9-]'
  ```

  It must print nothing. Moved code keeps its existing comments, including issue URLs in comments. That is file content, which GitHub does not turn into notices.

## 9. What a demo calls, outside astropy

The demos live in /Users/nabil/Git/wcsaxes-core-demos and use the astropy-wcsaxes-core env. Each one follows the same pipeline, in `common.py`; only the drawing differs.

- **Matplotlib use.** The demos never create a Figure, an Axes, a transform or a renderer.
  - They do import `formatter_locator`, for the same label strings. That module reads `rcParams` and `Formatter.fix_minus` at import time.
  - They may import `wcsapi.transform_coord_meta_from_wcs`, for types, units and wraps. Its module subclasses matplotlib's `Transform`.
  - Making those two matplotlib-free is out of scope (section 10).
  - Each demo asserts at exit that no `matplotlib.pyplot`, `matplotlib.figure` or `matplotlib.backends` module was imported.

1. **WCS adapter.** `SlicedLowLevelWCS(wcs, slices[::-1])`, which `apply_slices` also does, with `invert_xy`. An object `p2w` with `.transform(pixel) -> np.array(wcs.pixel_to_world_values(*pixel.T)).T` and `.inverted()`. `find_coordinate_range` needs the object; `_layout` needs `p2w.transform`.
2. **View.** `xlim` and `ylim` in data pixels, and the display size in device pixels.
   - `to_display` and `from_display` are numpy affines in a y-up display space.
   - Qt maps with `y_qt = height - y` when drawing.
   - bqplot uses `LinearScale`s spanning the display pixel box, so marks are given in display pixels.
3. **Spines.** For a rectangle, the outlines are `b`, `r`, `t` and `l` as in `RectangularFrame.update_spines`. For each one: `data = _layout.resample_spine(outline, conf.frame_boundary_samples)`, and `SpineArrays(data, p2w.transform(data), _layout.spine_normal_angle(to_display(data)))`.
4. **Ranges.** `find_coordinate_range(p2w, [x0, x1, y0, y1], types, units, wraps)`.
5. **Ticks.** For each coordinate: `spec = CoordSpec(...)` built from an `AngleFormatterLocator` or a `ScalarFormatterLocator`, then `placed = _layout.place_ticks(spec, ranges[i], spines, p2w.transform, to_display, from_display)`.
   - Draw each row on the chosen spines as a segment from `to_display(pixel)`, of length `size_pt * dpi / 72`, at `angle`, plus 180 degrees when ticks point out. This is what `Ticks._draw_ticks` draws.
   - Spine choice: lon on `b`, lat on `l`, ticks on all four spines, as WCSAxes' defaults end up. `_auto` is not reused.
6. **Tick labels.**
   - Group the major rows into a `SimpleNamespace` of `defaultdict(list)` as `TickLabels.add` does: `angle = normal` and `tick_angle = angle`.
   - Call `_layout.sort_labels` and `_layout.simplify_labels(labels, "0123456789.+\N{MINUS SIGN}")`.
   - Get the anchors with `xy = _layout.anchor_tick_labels(labels, axes, to_display, pad_px, measure)`.
   - For each `axis, i, box` from `_layout.keep_tick_labels(labels, axes, extent, exclude, existing)`, draw the text centred at `xy[axis][i]`. `extent` returns the measured box centred on the anchor. Add the boxes to `existing` before the next coordinate.
   - `measure` in Qt is `QFontMetricsF(font).boundingRect(text)` scaled to device pixels.
   - bqplot cannot measure text synchronously from the kernel. It uses an approximation, `(0.6 * size_px * len(text), 1.2 * size_px)`, and the demo says so.
7. **Grid.** `_layout.grid_lines(spec, ranges, conf.grid_samples, p2w.transform, p2w.inverted().transform)`. Split at `codes == MOVETO`, drop NaN vertices, map through `to_display`, and clip to the frame: Qt with `QPainter.setClipRect` or `setClipPath`, bqplot to the scale domain.
8. **Axis labels.**
   - `x, y, n = _layout.spine_midpoint(to_display(outline), _layout.spine_normal_angle(to_display(outline)))`, using the unsampled outline as `Spine._halfway_x_y_angle` does.
   - Then `_layout.axis_label_position(axis, x, y, n, minpad * text_px, text_px, True, union)`. Here `union` is the min and max over all kept label boxes when the coordinate has labels on that spine, and None otherwise.
   - Apply the 'labels' visibility rule: no axis label for a coordinate with no kept tick labels.
   - Qt and bqplot rotate clockwise in y-down space, so they negate the rotation.
9. **Proof script `compare.py`.**
   - Build the matplotlib `WCSAxes` whose axes box covers the same display pixels: Agg, `ax` at `[0, 0, 1, 1]`, the same size and dpi.
   - Report that the world values and texts equal `ax.coords[i]._ticks` and `_ticklabels` exactly, and the largest pixel and angle difference.
   - Do the same for the grid vertices and the anchors. Anchors depend on font metrics, so they are compared only for Qt, with a tolerance.
10. **Demo outputs.** The Qt demo uses PyQt5 offscreen, rendering a `QImage` to PNG. The bqplot demo uses `ipywidgets.embed.embed_minimal_html` to write HTML. The cases are a rolled helioprojective TAN (IRIS-like, arcsec, built in code) and a plain FITS TAN.

## 10. Out of scope for this first patch

- **A text mode for formatters.** A 'unicode' or 'ascii' output instead of mathtext:
  - the hour-angle `$\mathregular{^h}$` separators;
  - the `{unit:latex}` default axis labels;
  - the reads of `text.usetex` and `axes.unicode_minus`.

  Also making `formatter_locator` importable without matplotlib. `Angle.to_string` already has a unicode mode.
- **A matplotlib-free WCS adapter and `coord_meta`.** `WCSPixel2WorldTransform`, `apply_slices` and `transform_coord_meta_from_wcs` live in `wcsapi.py`, which subclasses matplotlib's `Transform`.
- **Spine assignment.** `_auto` as a core function over tick counts per spine. The demos fix their spines.
- **Matplotlib-only drawing paths.** Contour grids (`ax.contour`), the 1-D grid, the `add_tickable_gridline` spine builder, overlays orchestration, `get_tightbbox`, and frame outline builders (rectangle and ellipse).
- **Any numeric or speed change.** The R1 lazy `set_xlabel`, R5's batched and cached sampling, and per-draw memoisation. These change call counts and possibly hashes, so they go in separate patches.
- **Making `_layout` public.** Public API, docs, changelog, an asv benchmark, and a pushed bqplot backend in glue-jupyter.

## 11. Decisions to confirm

The task ran without user input, so these are provisional choices.

1. **`__init__`:** `HAS_MATPLOTLIB` plus `importorskip` moved into `tests/`. The alternatives are a PEP 562 lazy loader, or the core outside the package (section 2).
2. **Overlap rule:** the numpy port of `Bbox.count_overlaps` is used on the matplotlib side too. That way the figure tests guard the same code the demos run. The alternative is to keep matplotlib's call and have the demos implement the rule themselves.
3. **Tick-label storage:** label storage is duck-typed, with `TickLabels` itself passed to the label functions, instead of a new container class. This keeps the defaultdict side effects, which the tick tables record, and adds no class.
4. **The boundary takes callables**, `pixel_to_world` and `to_display`/`from_display`, not transform objects. `find_coordinate_range` stays object-based (`.transform`) because it is not being moved.
5. **Module name:** `_layout`.

## Files

- This design: /private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes-core/design.md
- Overlap port check: /private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes-core/design_checks/overlaps_check.py. It prints `empty: 0 0` and `mismatches: 0`.

## 12. Review round (2026-10-01)

A review of the four commits gave 16 findings. Fixes were folded into the commit they belong to with `git commit --fixup` (content) and `amend!` commits (messages), then `GIT_SEQUENCE_EDITOR=: git rebase -i --autosquash`. The final tree equals the pre-rebase tip plus the fixups. New SHAs: ab1da84b88, 46a6b95e79, 4d9b546e32, 8371f45c41.

Changes, by commit:

1. Commit 1:
   - `__init__.py`: `_HAS_MATPLOTLIB`, and an `else` branch with a module `__getattr__` that raises `ModuleNotFoundError(..., name="matplotlib")` for the nine public names and `AttributeError` for anything else. A blanket `ModuleNotFoundError` would break `from astropy.visualization.wcsaxes import coordinate_range`, because `_handle_fromlist` calls `hasattr`, which only swallows `AttributeError`.
   - `tests/test_misc.py::test_public_api_without_matplotlib` takes the public names from the matplotlib branch and checks in a subprocess without matplotlib that each raises `ModuleNotFoundError` naming matplotlib, that `_layout` and `conf` import, and that other names raise `AttributeError`. It is in `test_misc.py` because no commit on the branch touches that file, so the fixup cannot conflict.
   - `docs/changes/visualization/XXXXX.api.rst`.
   - `_update_ticks` clears `_ticks` and `_ticklabels` before placement again (6.8(c)).
   - `TickTable` docstring maps `angle`/`normal`/`disp` to the label names `tick_angle`/`angle`/`axis_displacement`.
   - `test_place_ticks_matches_wcsaxes` says it checks that plain inputs are enough, not the placement, and asserts that the hand-built spec equals `coord._layout_spec()`.
2. Commit 2: the `grid_paths` comment says changing the re-exported tolerances has no effect; `test_grid_lines_match_wcsaxes` gets the same wording and spec assertion.
3. Commit 3:
   - `_layout.tick_labels(placed)` builds the label store (a `SimpleNamespace` of six `defaultdict(list)`) from `PlacedTicks`, mapping `normal` to `angle` and `angle` to `tick_angle`. The subprocess test and both demos use it. `CoordinateHelper` still fills `TickLabels` with `add`, so the matplotlib path is unchanged.
   - The `measure` docstring of `anchor_tick_labels` states the convention: advance width, and ascender plus descender unless the ink is taller.
   - `TickLabels` reads `_tick_out_size` and `_existing_bboxes` lazily again (6.8(h)).
   - `ticklabels.sort_using` is imported back from `_layout` (`noqa: F401`).
4. Commit 4: the `__init__` comment says "tick, grid and label geometry".
5. All four messages: the "reads best with --color-moved" line is replaced by what the renames are and that `--color-moved` marks only part of the move; "This is a pure move" became "Nothing that WCSAxes draws changes"; commit 1 says that with matplotlib installed `_layout` still comes with the package and matplotlib; the WCSAxes comparison tests are described as checking the inputs, not the algorithm.

Demos (`/Users/nabil/Git/wcsaxes-core-demos`): both demos use `_layout.tick_labels`; the Qt docstring says "without a matplotlib Figure, Axes or renderer"; README updated; a new commit adds `check_move.py`, which applies the renames to each moved piece at the base and compares it, through `ast.unparse`, with the function in `_layout`.

Provisional decisions, to confirm:

- **Readability of the move (review item on `--color-moved`):** a check script plus accurate commit messages, not a split of each commit into an in-place rename commit and a byte-for-byte move commit. The split doubles the commits to eight and needs four new verified trees; it is the better form for a pull request, and the script shows the same information now. Offering commit 1 alone as a first pull request is also open.
- **matplotlib-free claim:** narrowed in words rather than made lazy. A lazy package `__init__` would change when matplotlib modules import for every user and break attribute access such as `wcsaxes.frame` after `import astropy.visualization.wcsaxes`; `formatter_locator` would also need its rcParams reads moved.
- **Label boundary:** `tick_labels` only. No union helper: the union is two numpy lines, `AxisLabels` uses `Bbox.union`, so a helper would not be shared.
- **Not done (low, not trivial):** moving the no-matplotlib test script out of a string and shrinking its snapshot; renaming `TickTable` fields.


## 13. Second review round (2026-10-01)

A second review gave 11 findings. Fixes are new commits on top (no rebase): 0b8f6d0922, 9e901d940e, 47d4c790b9, 7a2f13fdbd, 7f4e1cb774 on `wcsaxes-layout-core`; on `wcsaxes-layout-core-demos`, the merge 90af21708c, then 124751d506 and c685829d4a. Every core commit passes `review_fix/run_checks.sh` (outputs in `review_fix/runs/f51_c5` to `f51_c9`). Probes and runs are in `fable51/`.

Applied:

- **Lazy grid inverse (6.8(d)):** `_update_grid_lines` passes a lambda that builds the inverse; `fable-behaviour/p1_grid_inverted.py` now gives "draw: OK, grid lines: [0, 0]", as on the base.
- **`grid_lines` returns `[]`** with no ticks; `_update_grid_lines` tests `if lines:`. The demos drop `or []`.
- **Exception state (6.8(c)):** documented exactly, above. Code unchanged.
- **`wrap_angle_at` hook:** a comment at the import in `coordinate_helpers.py`, and the commit 7a2f13fdbd message.
- **Package import change, in part.** Kept, because removing it fails check (d) at every commit and leaves no way to run `_layout` without matplotlib. Changed: `tests/__init__.py` is back to the base and `tests/conftest.py` leaves the test modules out when matplotlib is missing. Without matplotlib and with pytest installed, `pkgutil.walk_packages(astropy.__path__)` and `generate_config("astropy")` used to raise `Skipped` at the tests package, and `utils/iers/tests/test_leap_second.py` was skipped as a whole; now the walk finishes, the config has `[visualization.wcsaxes]`, and that module collects 33 tests. `test_public_api_without_matplotlib` imports the tests package, which fails with the old `importorskip`. Cost: a wcsaxes test file given explicitly without matplotlib errors on import instead of skipping, and `c1/collect_without_mpl.py` prints "no tests ran" instead of "12 skipped". Not applied: raising `AttributeError` from `__getattr__` (Python then turns `from astropy.visualization.wcsaxes import WCSAxes` into "cannot import name 'WCSAxes'", with no context, `fable51/probe_from_import.py`) and a `__dir__` listing names whose access raises (`inspect.getmembers` would then raise).
- **Label boundary, interim form:** `tick_labels` is renamed `label_store` and `_update_ticks` fills `TickLabels` from it, so the normal/tick_angle mapping is in one place and the figure tests cover it (`label_state` still IDENTICAL). The module docstring says `to_display` gets (N, 2) from `place_ticks` and a tuple from `anchor_tick_labels`. The demos README says the label functions are `TickLabels` internals and that a table-based interface would be a redesign. The `LabelTable` redesign itself is not done.
- **Tests:** `test_layout.py` goes from 659 to 388 lines. The TAN and AIT layouts run in process with hand-checkable expectations; `test_layout_without_matplotlib` reruns those two tests in a subprocess with matplotlib blocked (it fails if `_layout` imports matplotlib inside a function). The two WCSAxes self-comparisons become `test_layout_spec`. New: first-step discontinuity, NaN tick angle, the 60 degree cap, the prefix case, the `$$` case (the reviewer's `['$1$', '$1$']` does not reach it; `['$$x', '$$']` does), `resample_spine`. `fable51/mutate_all.py` runs 21 mutations through the whole suite with tolerance-0 figure hashes: all 21 fail at least one test (`fable51/runs/mutate_all_*.txt`); before, four failed none.
- **`__all__`** lists only toolkit-facing names; **`CoordSpec`** is a frozen keyword-only dataclass; the bqplot demo builds it with keywords.
- **`check_move.py`** lists three substitutions apart from the renames, with what makes each hold; the README sentence changed accordingly. Counts unchanged (251/69/25).

Not applied:

- **Restructure the series** (ticks-only first PR, rename-in-place then cut-and-paste commits): needs a history rewrite, which this round's rules forbid. It remains the better form for an upstream PR.
- **Drop `PlacedTicks.label_world`:** rebuilding `_lbl_world` needs the locator's unit, which `PlacedTicks` does not carry, and changing `test_set_ticks_values` to suit the move is the wrong direction.
- **`grid_lines` taking four fields instead of the spec:** left as is.
