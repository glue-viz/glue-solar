import re, sys
for path in sys.argv[1:]:
    rem, add = [], []
    for l in open(path, encoding='utf8', errors='replace').read().splitlines():
        m = re.match(r'\x1b\[(\d+)m([+-])', l)
        if not m or l.startswith('\x1b[1m'):
            continue
        text = re.sub(r'\x1b\[[0-9;]*m', '', l)[1:].strip()
        if not text:
            continue
        if m.group(1) == '31':
            rem.append(text)
        elif m.group(1) == '32':
            add.append(text)
    print(path.rsplit('/', 1)[1], 'plain removed (non-blank):', len(rem), 'plain added (non-blank):', len(add))
    if '-v' in sys.argv[0:1] or path.endswith('5d9e3d6.txt'):
        print('\n'.join('  - ' + r for r in rem[:200]))
