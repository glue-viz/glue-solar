import re, sys, collections
c = collections.Counter()
for l in open(sys.argv[1], encoding='utf8', errors='replace').read().splitlines():
    if l.startswith('\x1b[1m'):
        continue
    m = re.match(r'((?:\x1b\[[0-9;]*m)+)([+-])', l)
    if not m:
        continue
    text = re.sub(r'\x1b\[[0-9;]*m', '', l)[1:].strip()
    if not text:
        continue
    codes = m.group(1)
    kind = 'plain' if re.fullmatch(r'\x1b\[3[12]m', codes) else 'moved'
    c[(kind, m.group(2))] += 1
print(dict(c))
