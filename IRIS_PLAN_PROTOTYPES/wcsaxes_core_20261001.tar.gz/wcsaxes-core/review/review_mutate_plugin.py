# Mutates the _layout algorithm in-process (the source tree is untouched):
# every tick moves 5 data pixels in x, its angle turns by 30 degrees, and every
# grid line vertex moves 5 pixels in x.
import numpy as np

from astropy.visualization.wcsaxes import _layout

_orig_ticks_on_spine = _layout._ticks_on_spine
_orig_grid_lines = _layout.grid_lines


def _ticks_on_spine(spec, ticks, spine, axis, w1, w2, tick_angle, rows, label_world=None):
    start = len(rows)
    _orig_ticks_on_spine(spec, ticks, spine, axis, w1, w2, tick_angle, rows, label_world)
    for k in range(start, len(rows)):
        a, w, (x, y), ang, n, d = rows[k]
        rows[k] = (a, w, (x + 5.0, y), ang + 30.0, n, d)


def grid_lines(*args, **kwargs):
    lines = _orig_grid_lines(*args, **kwargs)
    return None if lines is None else [(p + [5.0, 0.0], c) for p, c in lines]


_layout._ticks_on_spine = _ticks_on_spine
_layout.grid_lines = grid_lines
import astropy.visualization.wcsaxes.coordinate_helpers as ch  # noqa: E402

ch.grid_lines = grid_lines
