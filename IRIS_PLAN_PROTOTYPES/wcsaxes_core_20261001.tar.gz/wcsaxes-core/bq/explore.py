import numpy as np
from astropy.wcs import WCS
from astropy.visualization.wcsaxes.wcsapi import transform_coord_meta_from_wcs
from astropy.visualization.wcsaxes.frame import RectangularFrame
import matplotlib
matplotlib.use("agg")
import matplotlib.pyplot as plt

def hpc():
    w = WCS(naxis=2)
    w.wcs.ctype = ["HPLN-TAN", "HPLT-TAN"]
    w.wcs.cunit = ["arcsec", "arcsec"]
    w.wcs.cdelt = [0.33, 0.33]
    w.wcs.crpix = [256.5, 256.5]
    w.wcs.crval = [900.0, 300.0]
    r = np.radians(20)
    w.wcs.pc = [[np.cos(r), -np.sin(r)], [np.sin(r), np.cos(r)]]
    w.wcs.dateobs = "2014-03-29T17:48:00"
    return w, (512, 512)

def ait():
    w = WCS(naxis=2)
    w.wcs.ctype = ["GLON-AIT", "GLAT-AIT"]
    w.wcs.cdelt = [-1.0, 1.0]
    w.wcs.crpix = [180.5, 90.5]
    w.wcs.crval = [0.0, 0.0]
    return w, (360, 180)

def tan():
    w = WCS(naxis=2)
    w.wcs.ctype = ["RA---TAN", "DEC--TAN"]
    w.wcs.cdelt = [-5/3600, 5/3600]
    w.wcs.crpix = [180.5, 180.5]
    w.wcs.crval = [83.82, -5.39]
    return w, (360, 360)

for f in (hpc, ait, tan):
    w, (nx, ny) = f()
    tr, meta = transform_coord_meta_from_wcs(w, RectangularFrame)
    print(f.__name__, {k: v for k, v in meta.items()})
    fig = plt.figure(figsize=(6, 6), dpi=100)
    ax = fig.add_axes([0.15, 0.15, 0.8, 0.8], projection=w)
    ax.set_xlim(-0.5, nx - 0.5); ax.set_ylim(-0.5, ny - 0.5)
    ax.coords.grid()
    fig.canvas.draw()
    for c in ax.coords:
        print(' ', c.coord_type, c.coord_wrap, c.get_format_unit(), repr(c.get_axislabel()), c._get_default_axislabel() if hasattr(c,'_get_default_axislabel') else None)
        print('  ', dict(c._ticklabels.text))
