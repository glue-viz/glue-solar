import matplotlib
from matplotlib.figure import Figure
from matplotlib.backends.backend_agg import FigureCanvasAgg
from PIL import ImageFont, __version__
print("pillow", __version__)
fig = Figure(figsize=(4, 4), dpi=100); FigureCanvasAgg(fig); r = fig.canvas.get_renderer()
px = 10 * 100 / 72
font = ImageFont.truetype(matplotlib.get_data_path() + "/fonts/ttf/DejaVuSans.ttf", px)
asc, desc = font.getmetrics()
for s, plain in [('850"', '850"'), ("−5°10'", "−5°10'"), ("30'", "30'"),
                 (r'5$\mathregular{^h}$36$\mathregular{^m}$00$\mathregular{^s}$', "5ʰ36ᵐ00ˢ"),
                 (r'00$\mathregular{^s}$', "00ˢ"), ("120°", "120°"), ("lp", "lp")]:
    t = fig.text(0.5, 0.5, s, size=10, ha="center", va="center")
    bb = t.get_window_extent(r)
    l, top, rr, b = font.getbbox(plain)
    print(f"{plain:10s} mpl {bb.width:6.2f} x {bb.height:5.2f} | pil len {font.getlength(plain):6.2f} bbox {rr-l:6.2f} x {b-top:5.2f} lp-h {font.getbbox('lp')[3]-font.getbbox('lp')[1]:.2f} asc+desc {asc+desc}")
