"""Without matplotlib (pytest installed): does walking astropy's packages
reach a pytest Skipped, and what does generate_config do?

Usage: python probe_walk.py walk|config
Results go to sys.__stdout__, since generate_config silences stdout and does
not restore it when an exception goes through.
"""

import sys

sys.modules["matplotlib"] = None
import io  # noqa: E402
import pkgutil  # noqa: E402

import astropy  # noqa: E402


def out(*args):
    sys.__stdout__.write(" ".join(map(str, args)) + "\n")


which = sys.argv[1]
last = None
try:
    if which == "walk":
        for m in pkgutil.walk_packages(astropy.__path__, prefix="astropy."):
            last = m.name
        out("walk OK, last:", last)
    else:
        from astropy.config import generate_config

        buf = io.StringIO()
        generate_config("astropy", buf)
        out("generate_config OK, has [visualization.wcsaxes]:",
            "[visualization.wcsaxes]" in buf.getvalue())
except BaseException as exc:
    out(which, "raised", type(exc).__name__, str(exc)[:90], "| last:", last)
