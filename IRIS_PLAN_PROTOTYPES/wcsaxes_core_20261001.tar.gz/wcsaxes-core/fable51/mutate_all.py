"""Run the whole wcsaxes suite (unit tests plus tolerance-0 figure hashes)
once per mutation of _layout.py, served in process by the reviewer's
mutate_plugin. The clone is not written to. Usage: mutate_all.py FIRST LAST"""
import ast
import os
import subprocess
import sys
import tempfile

S = "/private/tmp/claude-501/-Users-nabil-Git-glue-solar/b5d1bb18-02b0-4ce4-96ca-9a67ce2c9354/scratchpad/wcsaxes-core"
F = S + "/fable-maintainer"
R = S + "/fable51/runs/mutate_all"
os.makedirs(R, exist_ok=True)
src = open(F + "/mutate_snapshot.py").read()
node = next(n for n in ast.parse(src).body if isinstance(n, ast.Assign) and getattr(n.targets[0], "id", None) == "MUTATIONS")
MUTATIONS = ast.literal_eval(node.value)
MUTATIONS += [
    ("label_store: swap angle and tick_angle", "labels.angle[axis].append(normal)\n        labels.tick_angle[axis].append(angle)", "labels.angle[axis].append(angle)\n        labels.tick_angle[axis].append(normal)"),
]
first, last = int(sys.argv[1]), int(sys.argv[2])
for k, (label, old, new) in enumerate(MUTATIONS[first:last], first):
    if not old:
        old = new = "ROUND_TRIP_RTOL = 1.0"
    env = dict(os.environ, MUTATE_OLD=old, MUTATE_NEW=new, HOME=tempfile.mkdtemp(),
               XDG_CACHE_HOME=S + "/cache", MPLBACKEND="agg", PYTHONPATH=f"{F}:{S}")
    out = f"{R}/{k:02d}.txt"
    with open(out, "w") as fh:
        subprocess.run(
            ["nice", "-n", "19", sys.executable, "-m", "pytest",
             "-c", "/Users/nabil/Git/astropy-wcsaxes-core/pyproject.toml", "-p", "no:cacheprovider",
             "-p", "mutate_plugin", "--pyargs", "astropy.visualization.wcsaxes",
             "-k", "not test_latex_labels and not test_layout_without_matplotlib and not test_public_api_without_matplotlib",
             "--remote-data=any", "--mpl", "--mpl-use-full-test-name",
             f"--mpl-hash-library={S}/baseline/figure_hashes.json",
             f"--mpl-baseline-path={S}/baseline/figures",
             f"--mpl-results-path={R}/mpl-results", "-q", "-rf", "-p", "no:randomly"],
            cwd=R, env=env, stdout=fh, stderr=subprocess.STDOUT)
    lines = open(out).read().splitlines()
    failed = sorted({l.split(" - ")[0].rsplit("/", 1)[-1] for l in lines if l.startswith("FAILED")})
    tl = [f.split("::", 1)[1] for f in failed if f.startswith("test_layout.py::")]
    print(f"{k:02d} {label:50s} {lines[-1] if lines else ''}")
    print(f"     test_layout: {', '.join(tl) or '-'}; other: {len(failed) - len(tl)}", flush=True)
