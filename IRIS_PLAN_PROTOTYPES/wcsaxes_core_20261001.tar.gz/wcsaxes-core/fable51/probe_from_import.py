import types, sys
m = types.ModuleType("fakepkg")
def __getattr__(name):
    if name == "WCSAxes":
        raise AttributeError(f"fakepkg.{name} requires matplotlib")
    raise AttributeError(name)
m.__getattr__ = __getattr__
sys.modules["fakepkg"] = m
try:
    from fakepkg import WCSAxes
except ImportError as exc:
    print("from-import with AttributeError:", type(exc).__name__, exc, "| context:", repr(exc.__context__), "| cause:", repr(exc.__cause__))
