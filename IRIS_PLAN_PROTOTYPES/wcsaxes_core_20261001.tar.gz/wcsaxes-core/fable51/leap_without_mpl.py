"""Collect utils/iers/tests/test_leap_second.py as if matplotlib were missing."""
import importlib.metadata
import sys

sys.modules["matplotlib"] = None
_d = importlib.metadata.distribution


def distribution(name):
    if name == "matplotlib":
        raise importlib.metadata.PackageNotFoundError(name)
    return _d(name)


importlib.metadata.distribution = distribution
import pytest  # noqa: E402

sys.exit(pytest.main(["-c", sys.argv[1], "-p", "no:cacheprovider", "-p", "no:mpl",
                      "--pyargs", "astropy.utils.iers.tests.test_leap_second",
                      "-q", "-rs", "--co"]))
