"""
Independent equality and limits probe for the three wp10-m1-lazy-loading designs.
python digest.py DESIGN   (glue | robust | risk | eager); one JSON line per window with sha1 digests of
every value (read through glue's data[cid, view] in 50-step views), of the mask, of glue's fixed-resolution
buffers (map, spectrogram, lambda-t; values and mask), and the design's 99.5 % limits (eager: exact
np.nanpercentile of every finite value, and one glue draw). NaN canonicalised before hashing.
"""
import glob
import hashlib
import json
import sys
import time

import numpy as np

DESIGN = sys.argv[1]
D = "/Users/nabil/DATA/IRIS/"
f4 = glob.glob(D + "*4000255147_raster/*r00000.fits")[0]
f3 = glob.glob(D + "*3824262996_raster/*r00000.fits")[0]
f34 = sorted(glob.glob(D + "*3400109360_raster/*.fits"))
TARGETS = [(f4, ["C II 1336", "Si IV 1403", "Mg II k 2796"]), (f3, ["Si IV 1403", "Fe XII 1349"]),
           (f34[5], ["C II 1336", "Mg II k 2796", "Si IV 1394"])]

if DESIGN == "robust":
    import lazyload

    load = lambda p, w: lazyload.lazy_raster_data([p], [w])[0]  # noqa: E731
else:
    from glue_solar.sources.loaders import iris as L

    if DESIGN == "risk":
        L.LAZY = True
    load = lambda p, w: L.raster_data([p], [w])[0]  # noqa: E731


def cids(d):
    cid = d.main_components[0]
    if DESIGN in ("glue", "eager"):
        return cid, d.main_components[1]
    return cid, d.id[f"{d.label} mask"]


def limits(d, cid):
    if DESIGN == "glue":
        return list(d.get_component(cid).limits)
    return [float(d.compute_statistic("percentile", cid, percentile=p, random_subset=10000)) for p in (0.25, 99.75)]


def h(a):
    a = np.asarray(a)
    if a.dtype.kind == "f":
        a = np.where(np.isnan(a), np.nan, a.astype(np.float64))
    return hashlib.sha1(np.ascontiguousarray(a).tobytes()).hexdigest()[:16]


for path, windows in TARGETS:
    for w in windows:
        d = load(path, w)
        cid, mcid = cids(d)
        n, ny, nl = d.shape
        hv, hm = hashlib.sha1(), hashlib.sha1()
        nan = 0
        for a in range(0, n, 50):
            v = np.asarray(d[cid, (slice(a, a + 50),)])
            m = np.asarray(d[mcid, (slice(a, a + 50),)])
            nan += int(np.isnan(v).sum())
            hv.update(np.where(np.isnan(v), np.nan, v.astype(np.float64)).tobytes())
            hm.update(m.astype(np.uint8).tobytes() if m.dtype == np.uint8 else b"WRONG-DTYPE" + str(m.dtype).encode())
        s, y, k = n // 2, ny // 2, nl // 2
        bounds = {"map": [(0, n - 1, n), (0, ny - 1, ny), k], "spec": [s, (0, ny - 1, ny), (0, nl - 1, nl)],
                  "lt": [(0, n - 1, n), y, (0, nl - 1, nl)], "map_rs": [(0, n - 1, 97), (0, ny - 1, 113), k]}
        frb = {}
        for name, b in bounds.items():
            frb[name] = h(d.compute_fixed_resolution_buffer(b, target_cid=cid)) + "/" + h(d.compute_fixed_resolution_buffer(b, target_cid=mcid))
        t = time.perf_counter()
        if DESIGN == "eager":
            ev = d.get_component(cid).data
            lim = [float(x) for x in np.nanpercentile(ev, [0.25, 99.75])]
            draw = [float(d.compute_statistic("percentile", cid, percentile=p, random_subset=10000)) for p in (0.25, 99.75)]
        else:
            lim = limits(d, cid)
            # what glue's own 99.5 % preset returns on this data (the style-editor combo)
            draw = [float(super(type(d), d).compute_statistic("percentile", cid, percentile=p, random_subset=10000))
                    if type(d).__name__ != "Data" else float(d.compute_statistic("percentile", cid, percentile=p, random_subset=10000))
                    for p in (0.25, 99.75)]
            glue_preset = [float(d.compute_statistic("percentile", cid, percentile=p, random_subset=10000)) for p in (0.25, 99.75)]
        dt = time.perf_counter() - t
        row = {"design": DESIGN, "file": path[-11:-5], "window": w, "shape": list(d.shape), "nan": nan,
               "values": hv.hexdigest()[:16], "mask": hm.hexdigest()[:16], "frb": frb, "limits": lim,
               "glue_draw": draw, "limits_s": round(dt, 2)}
        if DESIGN != "eager":
            row["preset_99.5"] = glue_preset
        print(json.dumps(row), flush=True)
        del d
