**Judgement on risk, complexity and the amount of glue-solar code (higher score = less risk, less complexity, less code)**

| Design | Score | Non-test code (prototype vs main cbf75e4) |
|---|---|---|
| risk-first | 7/10 | +240/−34 across 4 files, `lazy.py` 159 lines (stacks included, SJI not yet) |
| glue-native | 5/10 | +273/−63 across 7 files, `lazy.py` 123 lines |
| minimal-memory | 4/10 | `rawsource.py` 323 + `lazyload.py` 202 (451 non-blank), several parts still unbuilt |

How I checked:
- Diffed each scratch tree against `/Users/nabil/Git/glue-solar-accept`.
- Checked their glue, dask and irispy line citations: almost all hold. These include `component.py:557-558`, `fixed_resolution_buffer.py:283-309`, `data.py:1627-1628`, `data.py:1840-1847`, `viewer.py:200` and `:212` (the registry is checked before `get_data_layer_artist`), `profile/state.py:435`, `dask/array/core.py:3649-3650` and `:3673-3677`, `irispy/io/sji.py:239-243` and `spectrograph.py:157-162,252`.
- Ran five probes, saved in `/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/lazy/judge-risk/`: `pv_probe.py`, `gz_probe.py`, `gz_equal.py`, `lim_probe.py`, `float_probe.py`, `imp.py`. Timings use `time.perf_counter`, memory uses `ru_maxrss`, and the test file `r0.fits.gz` is a gzip of 3400109360 r00000.

## risk-first — 7/10

**Why 7:**
- It has the fewest new ideas: a scaled view over irispy's own memmap that never goes through dask for views, one `Data.compute_statistic` override (the override point glue itself suggests), and the mask as a glue derived component, as the item and D4 say.
- The flip (D10) is irispy's own view, so glue-solar adds no flip code.
- The spectrum panel fix is a 9-line `ProfileViewer` subclass, in the same style as the existing `QuicklookImageViewer`.
- The `LAZY` switch and the split into PRs keep each step small.
- Against that: the memmap can crash glue with SIGBUS if a file is truncated or its drive goes away, the open-file limit is raised for the whole process, two loading paths (lazy and eager) stay in the code, and splitting into three PRs goes against "one item, one PR".
- Verified: `.fits.gz` rasters load lazily and slices equal eager (load 1.81 s, +57 MB `ru_maxrss`, against main's 1.56 s, +172 MB).

**Errors:**
1. **The PV slicer breaks on lazy rasters, and the design never mentions it.** glue-qt's `pv_slicer.py:203` passes `data[att]`, a dask array, to pvextractor, which then needs a WCS (`pvextractor.py:80-82`). Run against its `RawComponent`, `_slice_from_path` raises `AttributeError: 'NoneType' object has no attribute 'sub'`. This affects a feature main already works around (#81).
2. **The integer-only guard it describes (`values.dtype.kind == "i"`) is not in the prototype.** irispy's float32 test files go down the lazy path, and `_sample` truncates the floats to ints. Measured limits are wrong: Fe XII [-194, 37.7] against the exact [-200, 34.9], and C II [-201, 21] against [-201.6, 21.5].
3. **"Within 0.6 %" holds only as a share of the range.** I recomputed 4000255147 with the 128M-element cap:
   - C II lower limit -7.25 against -7.5, which is 3.33 % of the value (0.5 % of the range);
   - Si IV 1403 upper limit off by 0.58 % of the value.
4. **Its numbers disagree with each other.** The Image-viewer check gives 99.5 % on Mg II k as [-0.5, 196.0], while its own limits table and my recomputation give exactly [-0.5, 195.75].
5. **"One small PR meets the whole done-when" overstates it.** PR1 has no lazy SJIs and no lazy stacks, both of which the item names.
6. **Cold cache and RSS growth are not measured.** With memmaps, RSS grows as windows are viewed, and the first map of a large window is a cold read of the whole window.
7. It also changes the stack Time layout (one value per scan and step) and passes a `SimpleNamespace` stand-in for the cube into `_cube_data`: both small hacks.

## glue-native — 5/10

**Why 5:**
- It uses glue's `DaskComponent` and `map_blocks` as intended. The PV slicer workaround switches on a behaviour probe, which I measured as cheap (import 2.08 s against 2.06 s on main; probe call 0.001 s).
- It has the most patch points:
  - the `_Raw` wrapper;
  - block shapes tuned on one observation;
  - a fallback for n-d integer keys;
  - a PV-slice monkeypatch;
  - the open-file limit raised in `setup()` for the whole process;
  - two layer-artist makers, one of which hides the spectrum layer through a flag set on the viewer.
- It keeps the memmap's SIGBUS and RSS risks, and it accepts the subset FITS export regression.

**Errors:**
1. **"Samples of the raw ints do not reach 1 %" is wrong for a sample with a size cap.**
   - Its study applies fixed strides to every window, including small faint ones, where one 0.25 DN step is more than 1 % of the range.
   - A cap that keeps every plane below 128M elements is exact on 7 of 9 windows of 4000255147 and within 0.5 % of the range on the other two (my recomputation).
2. **Reading every raw value for the limits costs time that grows with the window, on the GUI thread.**
   - It runs inside the layer maker during `add_data`.
   - One thread took 0.68 s for 4000255147 Mg II k (740 MB).
   - At that rate a multi-GB window blocks for seconds, and a 20 GB one for about 18 s on one thread. Cold reads were not measured.
3. **Its reason for rejecting a derived mask ("cannot be drawn") does not hold.** Its own `LazyComponent.__getitem__` fallback serves exactly the n-d keys a derived mask needs. So it departs from the item and D4 without needing to.
4. **The style-editor presets, Min/Max and the Histogram range stay on glue's dask corner sample** (its own figure: 69–106 % off). The `compute_statistic` override that would fix this is cheap, and the other two designs include it; this one defers it.
5. **Data are scaled per block, not "per requested slice" as the item says.** The budgets depend on the block shape, and the λ–t step has only 23 ms of headroom.
6. **Every IRIS Image viewer now opens at 99.5 % (shown as Custom) instead of Min/Max.** That is a change of scope.
7. **"glue-solar's code changes little" understates it:** +273/−63 non-test lines across 7 files.

## minimal-memory — 4/10

**Why 4:**
- It has real runtime advantages:
  - plain reads, so no SIGBUS crash and no file pages held in RSS;
  - no change to the open-file limit;
  - faster cold reads (its own measurement);
  - the PV slicer and Point export keep working;
  - limits are exact through `compute_statistic`.
- But it has by far the most code and the most re-implementation:
  - its own FITS reader (data offset, byte order, the flip, plane batching);
  - overrides of glue's `get_data`, `compute_statistic` and `compute_histogram`;
  - managing the lifetime of decompressed temporary files;
  - an eager fallback.
- It also leaves the most decisions open.

**Errors:**
1. **`.fits.gz` rasters quietly fall back to eager loading, which I verified.**
   - `lazy_raster_data` opens the HDU without `do_not_scale_image_data` (`lazyload.py:126`), so the check compares scaled floats with raw ints and fails.
   - On my gzipped 3400109360 file it returned plain `Component`s and took 3.79 s, against 1.56 s for main's eager loader.
   - Its claimed in-memory path for compressed rasters is therefore never exercised.
2. **"About 300 lines" understates it:** 525 lines (451 non-blank), and the temp-file unlink with `os.preadv`, the Windows cleanup and the per-batch drop are not built yet.
3. **The batch fallback is an `assert`** (`lazyload.py:124`), which `python -O` removes, not the eager fallback it describes. The cubes are also kept across batches rather than dropped within each batch as it says.
4. **The same `.fits.gz` SJI loads two different ways.** File→Open (`lazy_iris_data` → `lazy_image_data`) holds the int16 in memory; the browser (`lazy_image_data_cached`) writes a temporary file.
5. **Its default temporary file for `.fits.gz` SJIs contradicts the plan note** ("`.fits.gz` SJIs an eager int16 read"). The disk has 17 GiB free (`df`), and the design itself leaked 16 × 130 MB of temporary files.
6. **Every whole read becomes a full float32 array.** With `get_data` returning NumPy, value subsets, the PV slice, derived-mask statistics and export each allocate 4 bytes per element: about 40 GB for a 20 GB file, which would run out of memory.
7. **A file moved or deleted while loaded breaks drawing**, because each read reopens the file by path; a memmap survives an unlink.
8. **Minimum and maximum requests without a random subset** also come from the sampled histogram, so they are not exact on large windows.

## Shared by all three

- Reading the window scales (`_scales` / `_window_scaling` / `_window_ext`) walks every HDU header, which for a `.fits.gz` raster means decompressing through the whole file.
- Saving a session fails first on the Quantity meta, as it does on main.
- glue-native and risk-first used main cbf75e4 and minimal-memory used 3c6812b (#94), the current main. The accept checkout `/Users/nabil/Git/glue-solar-accept` is still at cbf75e4, so the quicklook line numbers differ slightly between designs.