=== DESIGN glue-native ===
# wp10-m1-lazy-loading design: lean on glue (D18)

This design keeps the data as raw int16 memmaps inside glue `DaskComponent`s and scales them block by block with `map_blocks`. Colour limits come once from glue-solar's own count of the raw ints, and glue-solar's code changes little. I built it as a patched copy of main (cbf75e4) in scratch and measured it against main's eager loader.

**It meets every part of the done-when on the acceptance data:**
- **Memory at open:** lazily opening all windows peaks at 5.5–7.0 % of eager RSS, or 0.1 % counted above the starting RSS.
- **Equality:** 83 datasets equal eager exactly, including 3400109360.
- **Limits:** they equal the exact eager 99.5 % limits to within 1e-3 DN.
- **M0 budgets:** every one holds, medians and maxima, after one block-shape fix.
- **Tests:** glue-solar's 154 tests pass on it, including the 8 remote-data ones.

The angle needed six changes beyond its own wording. Each is measured below (§9).

## 1. Data per dataset kind

| Kind | Raw source | Science component | Mask | Limits from |
|---|---|---|---|---|
| Raster window, per scan (File→Open and browser) | irispy `read_files(memmap=True)` `cube.data`: a `>i2` memmap view, negative-stride for V34 (`spectrograph.py:157,162,252`) | `LazyComponent(lazy_values(raw, (BSCALE, BZERO)))`, float32 dask, blocks about (181, 32, 181) | `LazyComponent(np.isnan(values).astype(uint8))`, a dask expression in `main_components` as today | every raw value of the window |
| Stack | the scans' memmap views | `da.stack([lazy_values(scan) …])`, one scan per block | same | every scan |
| SJI `.fits` | own `fits.open(do_not_scale_image_data=True)` memmap; irispy `memmap=True` supplies only the gWCS, meta and extra coordinates | same, blocks of one frame (`IMAGE_BLOCK`) | same | every frame |
| SJI `.fits.gz` | the same own read, which loads the whole file as int16 (2 B per element kept, against 5 eager) | same | same | same |
| AIA cutout | own memmap, BSCALE 1, BZERO 0, missing `(-200,)` | same, now always float32 (eager kept `>i2` when no -200) | same | same |
| Time, Exposure time | unchanged numpy broadcasts (`loaders/iris.py:164-167, 190-196`) | | | |

Why SJIs need their own read: irispy's memmap path sets the fill to 0, and 0 is a valid value (7992 DN) (`irispy/io/sji.py:240`). irispy also labels those cubes `DN_IRIS_SJI_UNSCALED` (`:243`) and sets `meta["scaled"]=False` (`:256`). The design restores eager's unit (`DN_UNIT["SJI"]`) and sets `meta["scaled"]=True`.

Raster scaling comes from the first file's headers, through `_scales(path)`, one `fits.open` per load.

## 2. Where scaling, missing values, the flip and the mask happen

All of it lives in one new module, `glue_solar/sources/loaders/lazy.py` (123 lines), which `stack_spectrograms.py` and `loaders/iris.py` both import. `MISSING_VALUES` moves there and is re-exported from `stack_spectrograms`.

```python
class _Raw:   # no .copy: dask 2026.8 from_array copies (reads) anything with one (dask/array/core.py:3649-3650)
    def __init__(self, raw): self.raw, self.shape, self.dtype, self.ndim = raw, raw.shape, raw.dtype, raw.ndim
    def __getitem__(self, key): return self.raw[key]

def _scaled(raw, bscale, bzero, missing):          # astropy's order (image.py:845-861), then main's fill rule
    values = raw.astype(np.float32); values *= bscale; values += bzero
    values[np.isin(values, missing)] = np.nan       # loaders/iris.py:182-186 on each block
    return values

def lazy_values(raw, scale=(1.0, 0.0), missing=MISSING_VALUES, block=RASTER_BLOCK):
    chunks = normalize_chunks(block, raw.shape, limit="4MiB", dtype=np.float32)
    source = da.from_array(_Raw(raw), chunks=chunks, name=False, meta=...)   # name=False: no hashing of the file (core.py:3673-3677)
    return source.map_blocks(_scaled, *scale, missing, dtype=np.float32, meta=...)
```

- **Flip (D10):** the flip is irispy's negative-stride view. glue-solar adds no code for it, and V34 equality holds on all 56 window-files.
- **Mask:** a dask `isnan` over the same graph, held in a `LazyComponent` (a subclass of glue's `DaskComponent`). That keeps it in `main_components` as today (`test_importer.py:147,183`).
- **Glue's `DerivedComponent` as the mask was measured and rejected:**
  - It cannot be drawn. The FRB's dask path applies only when the target is a `DaskComponent` (`fixed_resolution_buffer.py:283-300`); otherwise glue fancy-indexes, and dask raises `NotImplementedError` (`component.py:557-558`).
  - Any whole read computes the full window (`component.py:207-208`, `component_link.py:166-190`). One limit request on it takes 0.19–2.9 s and adds 0.2–0.58 GB RSS.

`LazyComponent` (shown in §4) adds two things to glue's `DaskComponent`:
- **`__getitem__` fallback:** for the n-d integer keys dask refuses, it reads the bounding box and indexes that. glue's Image viewer passes such keys to every component a derived component reads.
- **`limits`:** a cached property, described in §4.

Without the fallback, Arithmetic attributes on IRIS data, a glue `DerivedComponent` mask and `wp1-dn-per-s` cannot be drawn. With it they draw, and a slice of `{v}*2` equals twice the values.

### Code changes on main

- **`loaders/iris.py`:**
  - `_cube_data` (170-201) takes `values, raw` and adds the two `LazyComponent`s; the eager fill block (181-189) is removed.
  - `_raster_collection_data` (220-236) gets scales from `_scales`.
  - `_image_cube_data` (239-247) does the own raw read.
  - `read_files(..., memmap=True)` at 263, 274 and 306.
- **`stack_spectrograms.py`:**
  - The temporary-file memmap, the copy loop and `np.isin` (44-59) become `da.stack`.
  - The full-stack `NDCube` mask (81) is dropped: it was 1 B per element that nothing used.
  - `memmap=` becomes `scale=`.

## 3. Chunking (measured)

Every slice scales whole blocks, so the block shape sets the cost. One block per window took 0.56–0.58 s for every slice. Dask costs about 0.1 ms per block, so small blocks lose too.

Dask slice compute on 4000255147 Mg II k (1600×417×555), warm, in ms:

| Blocks | λ–t | map | spectrogram |
|---|---|---|---|
| 4 MiB cubic (101³) | 52 | 44 | 16 |
| **4 MiB, slit thin (181, 32, 181), chosen** | 18 | 64 | 26 |
| 8 MiB, slit thin (256, 32, 256) | 17 | 81 | 33 |
| 4 MiB (256, 16, 256) | 12 | 94 | 40 |

- Through glue's FRB: 1 MiB cubic gave 56/20/70 ms (map/spectrogram/λ–t) and 16 MiB gave 50/19/65 ms.
- With cubic blocks the λ–t slit step on 4000255147 Mg II k failed its budget: 154 ms (max 157) against 150. Blocks thin along the slit fixed it.
- SJI blocks of one frame take 1.0 ms per frame, against 12.3 ms in 101³ blocks.
- On 3824262996 the slit-thin blocks make the spectrogram dearer, 57 ms against 37. The image-step budget still holds there (67 ms against 100).

## 4. Colour limits

`LazyComponent.limits` is computed once, at the first Image layer. It returns glue's 99.5 % preset: the 0.25 and 99.75 percentiles of the finite values (`state_objects.py:403-422`).
- **Method:** a histogram (`np.bincount`) of every raw int16 value, one step plane at a time on 4 threads. The fill codes are excluded, then numpy's 'linear' percentile is read off the cumulative counts and scaled.
- **Non-int16 data:** `np.nanpercentile` over all values. irispy's bundled test files are float32 with no BSCALE.
- **Cost:** 0.003–0.59 s per window, warm, with about +1 MB footprint. Before I bounded the threads, the pass peaked at +1.38 GB footprint.
- **Accuracy:** all 83 datasets equal the exact eager percentiles within 1e-3 DN.

Samples of the raw ints do not reach 1 %. Error is measured as a share of the exact range, over 75 windows:

| Sample | Windows over 1 % | Worst error |
|---|---|---|
| every 2nd step plane | 51 of 75 | 32 % |
| every 4th | 53 | 81 % |
| every 8th | 56 | 130 % |
| 64 planes | 2 of 18 | 3.2 % |
| 128 planes | 1 of 18 | 1.02 % |

The causes are 0.25 DN quantisation on faint windows and limb geometry on 3400109360. glue's own dask sample reads one corner of each of ten blocks (`data.py:1840-1847`, `array.py:723`). Its upper limit was off by 69–106 %: 4000255147 Si IV 6.55 against 42.75, and 3824262996 Mg II k 202.8 against 650.25.

### Setting the limits on layers

`iris_image_layer` (`sources/iris.py:34-47`, glue's `layer_artist_maker` registry, consulted first at `viewer.py:212`) now also sets the limits:

```python
if hasattr(state, "percentile"):
    limits = getattr(data.get_component(state.attribute), "limits", None)
    if limits is None: state.percentile = PERCENTILE          # numpy IRIS data: glue's own preset
    else:
        with delay_callback(state, "v_min", "v_max"): state.v_min, state.v_max = limits   # shows 'Custom'
```

- It covers every Image viewer, not only the quicklook. `quicklook.py:30` and `:744` (`percentile = PERCENTILE`) are removed.
- glue's own default limits still run once per layer, before the maker, because `image/state.py:561-563` applies keyword arguments only after computing them. That costs about 15 ms per layer.

## 5. Consumers

Measured with `consumers.py` on 3400109360 Mg II k in a real offscreen app, lazy against eager:

| Consumer | Lazy | Eager | Change needed |
|---|---|---|---|
| File→Open via glue's data factory | 0.08 s; `LazyComponent` with glue's load log | | none |
| Stock Image viewer | limits Custom [-2.0, 53.75] = exact | percentile 100, Min/Max [-18.25, 212] | the maker (opens at 99.5 % instead of Min/Max) |
| Mask attribute drawn | OK | OK | none |
| Arithmetic attribute drawn | OK, slice equals 2× values | OK | `LazyComponent` fallback |
| Cursor readout, one value | 2.1 ms (one block) | 0.0 ms | none |
| Coordinator, Frame time tool, `link_hpc`, geometry helpers | numpy Time/Exposure, coordinates only | | none |
| Quicklook spectrum (point) | slice path, 3–4 ms | | none |
| Quicklook spectrum, whole cube | would cost 0.53–1.7 s and +0.9 GB per open (glue computes it before the layer is hidden, `profile/state.py:430-436`) | 0.37–0.40 s (R14) | new `hidden_cube_profile` maker (below) |
| Stock Profile viewer | 0.31 s | 0.30 s | none (prompt at 1e8 as today) |
| Histogram | 0.24 s; range [-2.5, 41] from glue's dask sample | [-18.25, 212] | none; known limitation |
| PV slice tool | fails: glue-qt passes `data[att]` (dask, `pv_slicer.py:205`) to pvextractor, which then demands a WCS (`pvextractor.py:82`) | OK | probe-gated `pv_slice_from_path` in `glue_patches.py` |
| Subset export to FITS | `IndexError` (`gridded_fits.py:65,72`) | OK | none; regression, upstream |
| Whole-data export | OK, 0.48 s | OK | none |
| Scripts reading `data[cid]` | now get a dask array (`data.py:1414-1417`) | numpy | docs |

The `hidden_cube_profile` maker creates the quicklook's raster layer as `ProfileLayerState(..., visible=False)`. `_profile` (`quicklook.py:775-789`) sets `viewer._solar_hidden_layer = raster` around `add_data` and drops its visibility loop.

The PV-slice patch passes glue-qt a proxy of the data whose `__getitem__` returns numpy. It reads the whole cube, as eager does already.

## 6. Sessions, the large-data prompt and data export

- **Sessions do not crash.** `save_session` is wrapped in `catch_error` (`application_base.py:18-29, 100`) and serialises before it writes (`:123-126`). On lazy data, as on eager, the Quantity meta fails first: one "Failed to save session" dialog, no file written.
  - After WP3 fixes the meta, File→Open data save through glue's load log (`state.py:1093-1101`; dispatch walks the MRO, `:384-386`).
  - Browser data then raise `GlueSerializeError` in the same dialog until `wp3-file-references`.
- **'Add large data set?' is unchanged.** `data.size` is the same, the prompt fires at `viewer.py:200`, and the quicklook still skips it (`quicklook.py:781`).
- **Subset export to FITS** fails on lazy data, as in the table above. This is a glue gap in `gridded_fits.py:72`.

## 7. Browser and File→Open paths, and file descriptors

Both paths end in `_cube_data`, so neither needs its own change. Each `read_files(memmap=True)` call keeps one file descriptor per file.

The browser calls it once per ticked window. Stacking 3602506433 lazily (99 files, 7 windows) held 697 descriptors. Under macOS's GUI soft limit of 256 (`launchctl limit maxfiles`) it failed with `OSError: [Errno 24] Too many open files`.

`setup()` now raises the soft limit to `min(hard, 10240)`. With the limit raised, that stack opens in 9.1 s and peaks at +0.106 GB, against a 9.17 GB eager peak (M0).

## 8. Measurements

Method:
- One fresh process per case, scratch `HOME`, offscreen Qt, warm page cache.
- **Memory:** `ru_maxrss` (bytes on macOS); `psutil` RSS sampled every 2 ms; `proc_pid_rusage` v4 for `phys_footprint` and its lifetime peak. `gc.collect()` before each reading; imports done before the start reading.
- **Timings:** `time.perf_counter`.
- **Budgets:** the M0 acceptance probe's time mode with `TREE=` pointing at the scratch copy. Lazy ran 3 rounds (6 on 4000255147 Mg II k); eager (main) ran 2 rounds in the same session.

### Opening

Peak absolute and above the starting RSS, in GB:

| Case | Lazy | Eager | Ratio, absolute / above start |
|---|---|---|---|
| 3824262996 File→Open, 8 windows | 0.08 s, 0.398 / +0.006 | 1.7 s, 5.72 / +5.33 | 7.0 % / 0.1 % |
| 4000255147 File→Open, 9 windows | 0.12 s, 0.405 / +0.007 | 2.3 s, 7.30 / +6.91 | 5.5 % / 0.1 % |
| 3824262996 browser | 0.22 s, 0.396 / +0.008 | 1.9 s, 5.70 / +5.31 | 6.9 % / 0.15 % |
| 4000255147 browser | 0.30 s, 0.404 / +0.018 | 2.6 s, 6.84 / +6.45 | 5.9 % / 0.3 % |
| 3400109360 stack, 7×8 | 0.77 s, 0.409 / +0.018 | 2.0 s, 4.45 / +4.06 | 9.2 % / 0.4 % |
| SJI 1400 `.gz` | 2.26 s, +0.41 (footprint kept 0.14) | 1.75 s, +0.60 (0.27) | 68 % above start |

The SJI `.gz` read is slower and does not reach 10 %: it decompresses twice and must hold the int16. Its footprint still halves.

### Equality

These all hold on 3824262996 (8 windows), 4000255147 (9), all 56 window-files of 3400109360, its 7 stacks, SJI 1400, deconvolved SJI 2796 and AIA 171:
- values, NaN included;
- uint8 masks;
- units, Time and Exposure time;
- world coordinates at 27 points;
- limits.

The final code was re-run on all of them.

### M0 budgets

Lazy against eager, median (max):

| Observation, window | `quicklook()` s | image step | λ–t slit step | click to spectrum | SJI step | synced step |
|---|---|---|---|---|---|---|
| 4000255147 Mg II k | 1.73* / 1.86 | 46 (47) / 29 | 124 (130) / 106 | 238 (278*) / 201 | 26–35 / 24 | 128 (207*) / 101 |
| 4000255147 Si IV 1403 | 1.57 / 1.47 | 39 (41) / 19 | 111 (114) / 95 | 228 (262) / 178 | 35 / 24 | 113 (125) / 93 |
| 3824262996 Mg II k | 1.27 / 1.27 | 67 (69) / 20 | 80 (86) / 66 | 229 (280) / 177 | — | 120 (162) / 66 |
| 4000005156 (lazy; M0 eager in brackets) | 1.28 [1.04] | 49 [35] | 96 [106] | 219 [200] | 30 [38] | 119 (139) [108] |
| 3400109360 (lazy; M0 eager in brackets) | 0.90 [0.72] | 29 [31] | 65 [73] | 173 [185] | — | 71 [74] |

\* One of the six Mg II k runs was slow throughout, including `quicklook()` at 2.8 s before any interaction. Its clicks reached 539 ms and synced steps 385 ms. The maxima shown are from the other five runs.

### Memory with the quicklook open

Above the start, after 40 slider steps, in GB:

| | RSS lazy / eager | Footprint lazy / eager | `ru_maxrss` lazy / eager |
|---|---|---|---|
| 3824262996 Mg II k | 0.80 / 1.51 | 0.07 / 1.25 | 0.80 / 2.05 |
| 4000255147 Mg II k + SJI 1400 | 1.52 / 2.85 | 0.21 / 2.22 | 1.52 / 3.31 |

Lazy RSS is mostly memmap pages of the displayed window: the map slice touches every page.

### Tests

glue-solar's 154 tests pass on the scratch copy (exit 0), including the 8 remote-data tests on the irispy-data cutouts.

## 9. Where the angle had to bend

1. `da.from_array` would copy the memmap; the `_Raw` wrapper prevents it.
2. `map_blocks` scales whole blocks, so slices are scaled per block, not per requested slice. The slit-thin block shape is what keeps the budgets.
3. The mask is a dask `DaskComponent`, not a glue `DerivedComponent`.
4. `LazyComponent` handles the n-d keys dask refuses.
5. Colour limits come from every raw value, set by the existing layer maker.
6. Further fixes:
   - the hidden-from-creation Profile layer;
   - the PV-slice patch;
   - the open-file limit.

If λ–t headroom shrinks, `LazyComponent.__getitem__` could slice the raw data first and then scale. That is about 2 lines and is the competing slice-then-scale layout (consumer map's "C").

## 10. Tests

All are glue-side. Bundled irispy files are float32 without BSCALE, so they cover only the float path; the int16 path needs remote irispy-data cutouts.

1. **New, `test_importer.py`:**
   - `test_raster_values_stay_raw_in_the_file_until_read`: the components are `DaskComponent`s; a slice equals `raw*BSCALE+BZERO` with fill NaN; the mask slice; `limits == nanpercentile`.
   - `test_arithmetic_attribute_of_lazy_data_draws`: draws in an Image viewer, and the conftest fails the test on draw errors.
2. **Changed, `test_quicklook.py:249-254`:** lazy layers are Custom with the exact percentiles; numpy layers are at 99.5.
3. **New, `test_quicklook.py`:** `test_quicklook_never_computes_the_whole_cubes_spectrum`, which counts `compute_statistic` calls with `axis` and no subset.
4. **Pin updates:**
   - `stack_spectrogram_sequence(..., memmap=False)` becomes no keyword (`test_importer.py:258`).
   - The AIA int16 check becomes a "no NaN" check (`test_plugin.py:340`).
   - NaN frames are read via `np.asarray` (`test_plugin.py:328`).
5. **Still to add (not yet written):**
   - an int16 cutout from irispy-data: values and fill codes against astropy `do_not_scale`, and limits;
   - the open-file limit, in a subprocess with a soft limit of 64 and `raster_data([path]*80, …, stack=True)`;
   - `needs_pv_dask_workaround` against glue-qt's function and against the patch;
   - saving a session with lazy data reports an error and writes no file.

The existing remote test `test_negative_step_raster_keeps_irispys_orientation` already covers D10 on lazy data.

**Manual probe:** archive `open.py`, `equal.py`, `limits_study.py` and `qlmem.py` as `IRIS_PLAN_PROTOTYPES/wp10_lazy_probe/`, and run the acceptance probe's `time` mode with `TREE=<PR checkout>`. Results go in Current state.

## 11. PR order

1. **PR A**, eager-safe: `hidden_cube_profile` plus the `_profile` change and its test. It removes R14's 0.37–0.40 s pass from today's eager quicklook.
2. **PR B**, stacked on A. It contains:
   - `lazy.py`, the loaders and the stack;
   - the limits in the layer maker;
   - the PV-slice patch and the open-file limit;
   - `dask[array]>=2024.7.0` in `pyproject.toml` (irispy's floor; test it in a new env such as `iris-plan-dask-floor`);
   - docs: `user_guide/loading-iris-level-2-raster-and-sji-data.rst:43-44` and `dev_guide/loader-customization.rst:16-31`;
   - workaround-register rows for `LazyComponent` n-d keys, the lazy limits, the hidden Profile layer, `pv_slice_from_path` and the open-file limit;
   - the tests.

## 12. Risks

- **Files must stay readable while loaded.** Truncating a file or ejecting the drive it is on raises SIGBUS and kills glue. Unlinking is safe, and `extract_archive` refuses to overwrite (`scan.py:45-52`).
- **Cold cache:** the first map slice or the limits pass reads the whole window from disk. I did not measure this; the FITS map measured 0.26–0.79 s cold for memmap reads.
- **Limits in the style editor:** the presets and the Histogram range still use glue's dask sample. The upgrade path is overriding `Data.compute_statistic`, which glue invites at `data.py:1627-1628`, or an upstream fix.
- **Regressions to accept or fix upstream:**
  - subset export to FITS;
  - derived components still read the whole window for their statistics (0.2–2.9 s);
  - stock Profile and Histogram viewers of a whole window are slower than eager.
- **SJI `.fits.gz`:** +0.25–0.5 s per load from double decompression.
- **λ–t headroom** on 4000255147 Mg II k is 23 ms.

## 13. Decisions for the user

1. Accept "a sample of the raw ints" as every raw value. Every sample I tested missed 1 % on some windows.
2. Confirm "eager 99.5 %" means the exact 0.25/99.75 percentiles of the eager finite values. glue's own eager value is a random sample that is off by 2–82 %.
3. Confirm the 10 % RSS is measured at open, with no viewer. Both readings pass: 5.5–7.0 % absolute, 0.1–0.3 % above start.
4. Confirm the mask as a dask `DaskComponent` rather than a glue `DerivedComponent`.
5. Accept that stock Image viewers of IRIS data open at 99.5 % (shown as Custom for lazy data) instead of Min/Max.
6. Accept the subset FITS export regression until glue fixes it.
7. For `.fits.gz` SJIs: keep the int16 read held in memory, or gunzip once to a cache file. The disk is 97 % full.
8. Allow `setup()` to raise the open-file soft limit.
9. Land A and B as two stacked drafts, or as one PR.

Everything is in `/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/lazy/design-glue/`:
- `lazy_design.diff`: the full diff against main, 10 files, +367/−70
- `tree/`: the patched copy of main
- scripts: `proto.py`, `bench.py`, `prof_scaled.py`, `prof_hint.py`, `limits_study.py`, `hist_speed.py`, `limits_cost.py`, `equal.py`, `open.py`, `consumers.py`, `qlmem.py`, `run.sh`
- results: the `*.jsonl` files and `tests_full.log`
- `acc/lazy`, `acc/eager`: the acceptance-probe copies, results and `compare.py`

=== DESIGN minimal-memory ===
# wp10-m1-lazy-loading: design built for robustness

## Bottom line

- **The design is built and measured.** The prototype is about 300 lines in scratch, running on the real loaders, the quicklook and the M0 acceptance probe.
- **Open meets the 10 % target by a wide margin.** Opening every window of a raster file (File→Open) costs:

  | Observation | Lazy | Eager | Lazy as share of eager |
  |---|---|---|---|
  | 3824262996 | 0.08 s, +11 MB peak RSS | 1.66 s, +5.34 GB | 0.2 % |
  | 4000255147 | 0.13 s, +7 MB | 2.23 s, +6.91 GB | 0.1 % |

  Measured as absolute `ru_maxrss` instead, the shares are 7.0 % (0.40 vs 5.73 GB) and 5.4 % (0.40 vs 7.30 GB).
- **Slices, NaNs and masks equal eager exactly.** This holds for every window of 3824262996 (8) and 4000255147 (9), and all 56 window-files of 3400109360 (negative step). The check covers every value in 64-step blocks, plus glue's image buffers for the map, spectrogram and λ–t, for both the data and the derived mask.
- **Limits are exact.** For all 17 raster windows and SJI 1400, the 0.25 and 99.75 % limits equal the exact percentile of the eager values: 0 % error. Glue's own eager draw is off by up to 26.7 % of the range.
- **The M0 time budgets still hold, medians and maxima, on the lazy tree.** Covered: 4000255147 Si IV and Mg II k, 3824262996 and 3400109360; `quicklook()` takes 0.74 to 1.82 s.
- **The decisions in §11 need the user before code** (CLAUDE.md asks for this).

## 1. Data structures, one per dataset kind

All new code goes in `glue_solar/sources/loaders/lazy.py` (prototype: `rawsource.py`).

| Kind | Raw holder | Science component | Mask | Time / Exposure time |
|---|---|---|---|---|
| Raster window, one per scan file | `FileWindow(path, datLoc, shape, '>i2', flip)` | `LazyComponent(Scaled(...))` on `IRISData` | glue `DerivedComponent`, `ComponentLink([cid], mask, using=nan_mask)` | numpy broadcasts, unchanged (`loaders/iris.py:164-167, 190-196`) |
| Stack | `StackWindow([FileWindow per scan])` | same | same | Time is a (scan, step) broadcast; Exposure is per scan |
| SJI `.fits` | `FileWindow` on the primary HDU | same | same | unchanged |
| SJI `.fits.gz` | Gunzipped once to a temp file, then `FileWindow`; falls back to `MemoryWindow` (raw int16 in RAM) on `OSError` | same | same | unchanged |
| AIA cutout | Proposed to stay eager (decision 4): int16 stays int16, 2 B/element | eager `Component` | eager uint8 | unchanged |
| Float Level 2 (irispy's bundled CI files are BITPIX −32) | `FileWindow` with `'>f4'` | same | same | unchanged |
| Anything else (BITPIX 8/32, a failed probe, irispy skipping a file) | main's eager path, unchanged | | | |

- **`LazyComponent(DaskComponent)`** keeps glue's dask handling:
  - It passes `isinstance` checks, which turn on glue's image-buffer shortcut (`fixed_resolution_buffer.py:285-300`).
  - `.data` is a dask array, chunked by whole planes.
  - Its `__getitem__` reads straight from the source with no dask graph. Glue's own version is `np.asarray(self._data[key].compute())` (`glue/core/component.py:557-558`).
- **`IRISData(Data)`** overrides three methods. Glue says subclasses may override these (`glue/core/data.py:1627-1628`); `type(...) is Data` checks are absent from glue and glue-qt.
  - **`compute_statistic`:** answers whole-component minimum, maximum and percentile from the raw-code histogram (§4). Everything else goes to `super()`.
  - **`compute_histogram`:** streams one dask chunk at a time, and builds subset masks per chunk view.
  - **`get_data(cid, view=None)`:** a whole read returns numpy, read and scaled a chunk of planes at a time (decision 5). This keeps glue-qt's PV slicer and glue's subset export working: both read `data[cid]` whole (`pv_slicer.py:203`, `gridded_fits.py:65-72`). With a dask array they failed: the PV slice raised `AttributeError`, and Point export raised `IndexError: Incorrect shape`.
- **Sessions.** The Data saver dispatches by MRO (`glue/core/state.py:384-386`), so `IRISData` saves as a `Data`.

## 2. Where scaling, fill, flip and mask happen

**Flip (D10).** irispy decides it. `_source` reads the orientation from irispy's own memmap view: `flip = cube.data.strides[0] < 0`.
- The rule is `spectrograph.py:162`; the flipped view is created at `spectrograph.py:252`.
- Behaviour probe: our first and last planes must equal irispy's, which are raw under `memmap=True`. If they don't, the window falls back to eager.
- SJI fill that irispy has zeroed is tolerated in this comparison (`sji.py:240`).

**Scaling.** `Scaled.scale` copies astropy's scaling: a float32 copy, then `*= BSCALE`, then `+= BZERO` (`astropy/io/fits/hdu/image.py:845, 858-861`).
- BSCALE and BZERO come from each HDU's header, never hard-coded.
- The scaling is applied only to the requested box.
- A basic view larger than 8 MiB is scaled a chunk of planes at a time into its output. This took glue's value-subset read (`subset.py` `data[cid, ...]`) from +2.83 GB to +1.77 GB.

**Fill.** Fill values become raw codes per HDU: (−200 − BZERO) / BSCALE gives −32768, and −199 gives −32764. A `BLANK` keyword is added as a code. The codes are compared exactly, never as a threshold: raw −32763 to −32701 are real data.

**Mask (D12).** The `DerivedComponent` uses `nan_mask(v) = np.isnan(v).view(np.uint8)`.
- It is a module-level function, so sessions save it by name rather than through the broken base64 fallback (`state.py:1232`).
- Image viewers can show it: the fancy-index path through `LazyComponent.__getitem__` was measured at 41 ms per map buffer on 4000255147 Mg II k, and is equal to eager.
- This same property makes `wp1-dn-per-s` work.

**Changes in `loaders/iris.py`:**
- `_cube_data(cube, label, *, source=None, …)` (lines 170-201): with a source it builds an `IRISData` and calls `add_lazy`. Otherwise lines 180-189 run unchanged as the eager fallback.
- `iris_data` (267-282) and `raster_data` (285-307) call `read_files(..., memmap=True)` in batches of 64 files.
  - From each cube they keep only the WCS, meta, times, exposure and unit, then drop the cube within the batch. irispy's memmaps hold one file open per file.
  - `len(sequence) != len(batch)` triggers the eager fallback (irispy's `continue` at `spectrograph.py:251`).
- Stacks: `_raster_collection_data` (220-236) uses `Scaled(StackWindow)` with `_stack_wcs`, moved from `stack_spectrograms.py:66-75`.
  - This drops the tempfile memmap and the waste `NDCube(mask=np.isnan(output))` (lines 46-50, 81).
  - `stack_spectrogram_sequence` stays for the eager fallback.
- `image_data` (255-264): SJIs use `read_files(path, memmap=True)` for the WCS, meta and pointing; the data come from our own read. AIA keeps `memmap=False`.

## 3. Reads and chunking per access pattern

**The panels never go through dask.** `FileWindow.box` reads from a file object it opens itself, so it is thread-safe: astropy `section` silently gave wrong planes under threads.
- **Box spans every row (map, spectrogram, chunk reads):** contiguous runs of whole planes, 1 MiB per read.
- **Otherwise (λ–t, profile, pixel):** each plane's band of rows.
- No file pages stay mapped, so RSS does not grow with what has been viewed.

Warm, median of 5, 4000255147 Mg II k (1600×417×555), lazy vs eager:

| Read | Lazy direct | Lazy via glue's image buffer | Eager via glue's image buffer |
|---|---|---|---|
| profile | 0.03 ms | | |
| spectrogram | 0.3 ms | 2.1 ms | 1.1 ms |
| λ–t | 3.0 ms | 10 ms | 4.0 ms |
| map | 34 ms | 39 ms | 13 ms |

On 3824262996 Mg II k the map buffer is 27 ms lazy against 8.4 ms eager.

**Plain reads, not memory maps, because of the cold cache.** Measured after evicting the file (`msync` invalidate, residency checked with `mincore`):
- Map: 160 ms with plain reads against 786 ms with mmap.
- λ–t: 204 ms against 361 ms.
- The cost is the warm map: 33 ms against 22 ms. Files over RAM size are always cold.

**Dask chunks** (`.data`) are whole planes of about 8 MiB raw: 7 steps for 3824262996 Mg II k, 18 for 4000255147 Mg II k, 25 frames for SJI 1400, and (1, k, ny, nλ) for stacks. Only chunked consumers use them: the streamed histogram, `slices_from_chunks`, and `comp.data` callers.

## 4. Colour limits, set once

- `Scaled.counts()` runs once per source on its first use. It builds an exact `bincount` over the 65,536 raw codes, fill removed, from whole planes: all of them up to `SAMPLE_BYTES = 512 MiB` raw, then evenly spaced planes. Float sources take percentiles of the sampled planes.
- Percentiles use numpy's linear interpolation. Glue's `minimum` and `maximum` with `random_subset=n` become the 100/(n+1) and 100·n/(n+1) percentiles: the expected extremes of glue's random draw.
  - Without this, the Histogram's x range became [−197, 7945.75]; with it, [−1.75, 267.75], against [−1.75, 247.0] from eager.
- **No quicklook change is needed.** `quicklook.py:752` (`percentile = 99.5`) is answered exactly by `IRISData`, and so is any percentile chosen in the style editor or the Histogram viewer. Glue's dask path gave [0, 1] on these windows.
- **Cost:** the first call takes 0.05–0.57 s per window, 0.15 s for SJI 1400; cached calls take 0.2 ms.
- **Sampling at 128 MiB** instead gave a worst error of 0.66 % of the value (0.54 % of the range) in at most 0.18 s.

## 5. Consumers

| Consumer | Path | Measured (4000255147 Mg II k unless noted) |
|---|---|---|
| Image panels, SJI | `__getitem__` via glue's buffer shortcut | see §3; acceptance budgets hold |
| Cursor readout, Frame-time tool, coordinator, `link_hpc` | numpy Time/Exposure, scalar views, coordinates | same values as eager (0.17 ms per readout) |
| Quicklook spectrum (Point) | `SliceSubsetState.to_array`, one row | profile sum identical (3213.5) |
| Quicklook whole-cube profile | **removed**: new `@layer_artist_maker("IRIS: hidden spectrum layer")` in `sources/iris.py` builds `ProfileLayerState(..., visible=False)` for `viewer._solar_hidden_data`; `_profile` (`quicklook.py:783-798`) sets that attribute before `add_data` and drops the loop at 792-794 | glue skips hidden layers (`profile/state.py:435`); saves the 0.4–2.7 s pass (R14) for eager too |
| User-made whole-cube Profile | glue's chunked statistic | lazy 1.70 s, +0.96 GB vs eager 1.49 s, +0.71 GB |
| Histogram viewer | `IRISData.compute_histogram`, streamed | 1.7–2.2 s, +55–87 MB; dask path was +1.09 GB, eager +1.56 GB |
| Value subsets (`InequalitySubsetState`) | whole read, chunk-scaled | 0.61 s, +1.77 GB; eager +0.35 GB but holds the cube anyway |
| Pixel, slice and ROI subsets | coordinates only | unchanged |
| Derived mask read whole | numpy whole read | 0.58 s, +1.77 GB |
| PV slicer | whole read, numpy | works; was `AttributeError` with dask |
| Export: whole data or Point subset | whole read, numpy | Point export **works**; peak about 3.6 GB transient, like eager |
| Table viewer | 1-D only | unchanged |

## 6. Sessions, the large-data prompt and export

**Sessions.** Saving fails exactly as on main ("Failed to save session", Quantity meta, measured in both). It shows glue's error dialog and does not crash.
- Once WP3 fixes the meta, `LazyComponent.data` raises `GlueSerializeError` (no saver for dask), again a dialog.
- File→Open data carry glue's LoadLog, so `_save_component` saves a file reference without touching `.data` (`state.py:1096-1099`).
- `wp3-file-references` adds `__gluestate__` to `LazyComponent` (path, extension, flip, scaling, fill codes).

**"Add large data set?" prompt.** Unchanged (D18): Profile at 1e8, Histogram at 2e7 (glue-qt `data_viewer.py:25`), and the quicklook spectrum panel keeps `large_data_size=None` (`quicklook.py:789`). The prompt is still accurate: answering yes reads the whole window, but its memory is now bounded.

## 7. Browser and File→Open

- **File→Open / `--startup=iris_quicklook`:** `read_iris_file` → `iris_data`: one irispy memmap read, all windows lazy.
- **Browser:** `load_entry` → `raster_data` / `image_data`, called per window as on main.
- **99-scan stack (3602506433, all 7 windows):**

  | Variant | Load time | Peak RSS growth |
  |---|---|---|
  | Eager | 11.4 s | +9.23 GB |
  | Lazy, one irispy call per file | 15.8 s | |
  | Lazy, batched irispy reads | 10.3 s | +0.31 GB |

  irispy's WCS building is about 12 ms per file and window, so `wp10-nonblocking-load` is still needed for stacks.
- **Archive extraction:** unchanged.

## 8. Tests and manual probe

Tests cover the glue side only and use bundled irispy files, generated copies in `tmp_path`, or LM-SAL/irispy-data remote files.

**Note on bundled data.** irispy's bundled files are float32, so the int16 path is tested on int16 copies generated in `tmp_path` (BSCALE 0.25, BZERO 7992, with −32768 and −32764 planted), plus remote files.
- The 3400109360 cutout covers the flip.
- 4000005156 Si IV `.fits.gz` covers a compressed raster (the in-memory path).
- SJI 1400 f050 `.fits.gz` covers the temp file.

**New `tests/test_lazy.py`:**
1. Each window's views equal astropy's scaled `getdata` with fill as NaN: full, map, λ–t, spectrogram, pixel, negative steps, fancy indexing, bool masks. The derived mask equals `isnan` as uint8. Glue's image buffer for data and mask equals the same oracle.
2. Eight threads reading random views agree.
3. Limits: `compute_statistic` percentile equals `np.nanpercentile` of the oracle; an Image layer at 99.5 shows the exact limits; with `SAMPLE_BYTES` patched to 2 planes the error is at most 1 %.
4. The streamed histogram equals `np.histogram`.
5. `.fits.gz`: values equal the `.fits` load; the temp path is gone right after load (POSIX); an unwritable temp dir falls back to memory.
6. Fallback: a BITPIX 32 copy loads eagerly with equal values.
7. Stacks equal the per-scan loads.

**Adapted tests (the prototype tree ran the suite: 135 passed, 4 failed, 11 skipped):**
- `test_importer.py:147, 183, 206`: the mask is now derived, so it is not in `main_components`.
- `test_plugin.py:340` (AIA int16): passes if AIA stays eager.
- `test_plugin.py:328`: needs `sji[att, 0]` rather than `sji[att][0]`. With the whole-read change it already passes.

**`test_quicklook.py`:** add one test asserting no whole-cube `compute_statistic` call with an axis and no subset during `quicklook()`.

**Manual probe** (`IRIS_PLAN_PROTOTYPES/wp10_lazy_probe.py`, from scratch `p_open`, `p_slices`, `p_limits`, `p_whole`, `p_cold`):
- `open`: fresh process, psutil sampled every 1 ms, plus `ru_maxrss` and `phys_footprint`, eager against lazy.
- `equal`: 3824262996, 4000255147 and all 56 windows of 3400109360.
- `limits`: every window against the exact eager percentile.
- Then the M0 acceptance probe in time, memory and crash modes, with `TREE=<branch>`, 6 rounds.

## 9. PR order

Stacked drafts on `main`:
1. **Optional: the hidden spectrum layer** (layer maker plus the `_profile` change, one test). It is independent and speeds up eager too.
2. **`wp10-m1-lazy-loading`**, as commits:
   - `lazy.py` with its unit tests on generated files;
   - rasters and stacks;
   - SJI `.fits` and `.fits.gz`;
   - the `IRISData` statistic, histogram and whole-read overrides;
   - docs: the loading guide's stack-memmap paragraph and component-order paragraph, `loader-customization.rst`; changelog; `dask[array]` in `pyproject.toml`; a workaround-register row for "whole reads give numpy", retired once glue-qt's PV slicer and glue's exporters accept `DaskComponent`.

Follow-ups, outside this PR:
- An irispy request: `memmap=True` should keep SJI fill raw (`sji.py:240`).
- Two M4 report candidates: subset export and the PV slicer on dask.
- `wp3-file-references`, adding `LazyComponent.__gluestate__`.

## 10. Risks

- **Files must stay in place while loaded.** A moved, deleted or unmounted file raises `OSError` naming the file in a draw. Eager kept working.
- **Cold windows cost a full read on first touch.** The first map λ step is 160 ms on a 741 MB window, over the 100 ms step budget; files bigger than RAM are always cold.
- **gz temp files leak if the process ends abruptly.** This was measured: `os._exit` in the probes left 16 × 130 MB in `$TMPDIR` (deleted since). The design therefore unlinks the file after opening it on POSIX and reads with `os.preadv` (checked on macOS). On Windows it deletes on finalisation, so a crash leaves a file behind. The disk is 97 % full.
- **irispy's SJI zeroing** costs a transient of about +0.2 GB for SJI 1400, growing with SJI size; uncompressed SJIs pay a full page-in.
- **Whole-array consumers** (value subsets, derived mask read whole, subset export, PV slicer) hold the float32 window transiently. That is never more than eager keeps permanently.
- **Two one-sample outliers, so far:** the first acceptance run (memory-mapped reads, other agents active) had one image step at 129 ms and one click at 405 ms. The plain-read run had none. The 6-round PR run must confirm this on a quiet machine.
- **Floor environment:** dask at irispy's floor (2024.7) is untested. Only `from_array(name=, meta=, asarray=False)` and `slices_from_chunks` are used.

## 11. Decisions for the user (before code)

1. **Done-when metric.** Proposal: peak RSS growth over the post-import baseline during File→Open of the raster file, no viewer, with absolute `ru_maxrss` also reported. Limits compared against the exact 0.25/99.75 percentiles of the eager values, within 1 % of each value.
2. **`.fits.gz` SJIs.** Temp file (0.49 s, kept footprint +0.02 GB, disk equal to the uncompressed size) or RAM int16 (2.25 s, kept footprint +0.14 GB)?
3. **`SAMPLE_BYTES`.** 512 MiB (exact; first view up to 0.57 s) or 128 MiB (up to 0.66 % error; up to 0.18 s)?
4. **AIA.** Stay eager in this item?
5. **Whole reads.** Return numpy, so the PV slicer and subset export keep working with a transient cost? Or dask, which is lazier but breaks both?
6. **PRs.** One PR, or the hidden spectrum layer split out first?

## How it was measured

- **Setup:** `iris-plan` env, scratch HOME, offscreen Qt with Agg, a fresh process per case, warm cache unless marked cold. Apple M4 Pro, 24 GB.
- **Memory:** psutil RSS sampled every 1 ms; `ru_maxrss`; `phys_footprint` via `proc_pid_rusage`.
- **Time:** `time.perf_counter`, median of 5.
- **Budgets:** the M0 acceptance probe with `TREE` pointing at the prototype tree, 4 rounds (3 for 3400109360).
- **Code under test:** main 3c6812b.

Files are in /private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/lazy/design-robust/:
- Prototype: `rawsource.py`, `lazyload.py`, `check_keys.py` (synthetic self-check; `rawsource_mmap.py` is the memory-mapped variant)
- Probes: `p_open.py`, `p_slices.py`, `p_limits.py`, `p_whole.py`, `p_cold.py`, `p_mapread.py`, `p_gui.py`, `p_stackparts.py`
- Results: `open.jsonl`, `slices_*.jsonl`, `limits2.jsonl`, `whole.jsonl`, `cold*.json`, `gui_eager.json`, `gui_lazy4.json`, `pytest_tree2.log`, `acc_run2.log` (plain reads), `acc_mmap_results/`
- Trees: `tree2/` (main plus the prototype); `acc/probe/` (acceptance runner)

=== DESIGN risk-first ===
# wp10-m1-lazy-loading: an incremental design that keeps eager loading available

## Bottom line

- **One small PR meets the whole done-when for rasters.** I built it as a prototype on a copy of main (cbf75e4) and measured it on the full data.
  - **Memory on open:** lazily opening every window of 3824262996 and 4000255147 peaks at +3 MB and +9 MB RSS over the pre-load baseline. Eager peaks at +5.34 GB and +6.91 GB. Counting absolute RSS instead (0.404 vs 5.73 GB, 0.405 vs 7.31 GB), lazy is still only 7.0 % and 5.5 % of eager.
  - **Equality:** all 73 window-files equal eager, including the 56 flipped ones of 3400109360. That covers every value and NaN, the mask, and glue's own image buffers.
  - **Colour limits:** within 0.6 % of the exact limit range on every window.
  - **Budgets:** every M0 budget still holds, mostly faster than on main.
- **SJI/AIA and stacks follow as PR2 and PR3.** Both are prototyped and measured.
- **No new behaviour probes are needed.** Eager loading stays available through a module switch, and three cases fall back to it automatically.

## How I measured

- **Setup:** a prototype tree that copies `glue_solar` from glue-solar-accept and patches it. Python is iris-plan, with a scratch HOME, offscreen Qt and Agg, run from scratch.
- **Memory:** one fresh process per case.
  - Peak RSS is the larger of psutil RSS sampled every 1 ms and `ru_maxrss`, measured as the change over the baseline after imports and `gc.collect()`.
  - Footprint comes from `proc_pid_rusage` v4.
- **Times:** `time.perf_counter`, with a warm page cache.
- **GUI budgets:** the M0 acceptance probe (`acceptance_20261001.tar.gz`), run with `TREE=` pointing at the prototype, 2 rounds per case. Main's figures are the stored M0 results.

## 1. Data structures and where each step happens

**What each dataset kind becomes**

| Kind | Raw source | Value component | Mask | Time / Exposure | PR |
|---|---|---|---|---|---|
| Raster window, per scan (`.fits`) | irispy `read_files(memmap=True)` `cube.data`: raw `>i2` memmap view, flipped by irispy for V34 | `RawComponent` (a `DaskComponent` subclass) in `LazyData` | glue `DerivedComponent`: `fill_mask(values)`, uint8 | unchanged: 0-byte broadcasts (`iris.py:164-167, 190-196`) | 1 |
| Raster `.fits.gz` (e.g. the remote 4000005156 Si IV asset) | same call; astropy reads raw int16 into memory (2 B/element) | same | same | same | 1 |
| Stack | the per-scan raw views wrapped in `RawStack` (leading scan axis) | same | same | Time is a (scan, step) broadcast instead of today's (scan, step, slit) array | 3 |
| SJI `.fits` and AIA cutout | our own `fits.open(memmap=True, do_not_scale_image_data=True)[0].data`; irispy `memmap=True` only for meta, gWCS and extra coordinates (its reader writes 0 over fill, `irispy/io/sji.py:239-243`) | same, with unit `DN_UNIT["SJI"]` (irispy's memmap unit is `DN_IRIS_SJI_UNSCALED`) | same | unchanged | 2 |
| SJI `.fits.gz` | the same astropy call, which decompresses raw int16 into memory | same | same | unchanged | 2 |

**Where each step happens**
- **Scaling and fill to NaN:** only inside `_Scaled.__getitem__`. It computes float32 `raw*BSCALE+BZERO`, the same arithmetic astropy uses (`astropy/io/fits/hdu/image.py:858-861`), then sets NaN where the raw value is a fill code.
  - Fill codes are `(m − BZERO)/BSCALE` for `MISSING_VALUES` (`stack_spectrograms.py:14`): −32768 and −32764 for IRIS, −200 for AIA.
  - Rasters read BSCALE/BZERO from each window's header with `_window_scaling(path)`, never hard-coded.
- **Flip (D10):** irispy's own `data[steps]` view (`irispy/io/spectrograph.py:252`). All 56 window-files of 3400109360 arrive as negative-stride views and stay lazy. glue-solar adds no flip code.
- **Mask:** `add_component_link(ComponentLink([cid], ComponentID(f"{label} mask", parent=data), using=fill_mask))` (`glue/core/data.py:1112`).
  - It is a glue derived component, as the plan text and D4 say. `fill_mask` is module-level, so WP3 can save it by name.
- **Core code** (prototype `lazy.py`, 159 lines including PR3's `RawStack`):

```python
class RawComponent(DaskComponent):
    def __init__(self, raw, bscale, bzero, missing, units=None):
        fill = [(v - bzero) / bscale for v in missing]
        self._source = _Scaled(raw, bscale, bzero, [int(c) for c in fill if float(c).is_integer()])
        values = da.from_array(self._source, chunks=(CHUNK_STEPS,) + raw.shape[1:],
                               name=f"iris-raw-{uuid4().hex}", meta=np.empty((0,) * raw.ndim, np.float32), asarray=False)
        super().__init__(values, units=units)

    def __getitem__(self, key):          # every view: slice the raw ints, scale only that
        return self._source[key]
```

**Why this layout**
- **Views skip dask entirely.** Image slices, profiles, the cursor readout and glue's chunked statistics all ask for a view, so they never touch dask's graph optimiser.
- **Fancy indices work.** Because a memmap accepts them, glue's generic image-buffer path can draw the derived mask, or any later derived component such as `wp1-dn-per-s`.
  - Measured: map, spectrogram, λ–t and a resampled map, for both values and mask, equal eager on all 73 window-files.
  - Over a plain `DaskComponent`, glue raises `NotImplementedError` for these, through `component.py:557-558` and `fixed_resolution_buffer.py:285-309`.
- **dask does not copy the file.** `_Scaled` has no `.copy` method, so dask 2026.8 does not read the whole window at build time.

## 2. Chunking

- `.data` is `CHUNK_STEPS = 32` whole step planes per chunk.
- dask only runs for whole-component reads:
  - `compute_statistic` with no view and at most 40 M elements;
  - `compute_histogram`;
  - `RangeSubsetState` masks;
  - export.
- Larger statistics are already split by glue into views (`data.py:1660-1724`), so they use `__getitem__`.

## 3. Colour limits

- **Mechanism:** `LazyData(Data)` overrides `compute_statistic`, glue's documented override point (`data.py:1627-1628`).
  - It answers `minimum`, `maximum` and `percentile` calls that have `random_subset`, no subset, no axis and no view, and target a `RawComponent`.
  - The answer comes from a 65,536-bin count of raw codes, computed on first use and cached, using numpy's linear percentile.
  - Everything else goes to `super()`.
- **What this covers:** the quicklook's `percentile = 99.5` (`quicklook.py:744`), any Image viewer, the style editor's percentile combo, and the Histogram x range (`state_objects.py:403-422, 566-573`). No viewer code changes.
- **Why it is needed:** glue's dask sampling reads chunk corners (`data.py:1840-1847`, `utils/array.py:723-753`) and gives (0, 1).
- **Sample rule:** whole planes, evenly spaced, and every plane while the window is under `SAMPLE_SIZE = 128_000_000` elements.

| Sample rule (80 windows and stacks) | Worst error, % of exact range |
|---|---|
| 64 M elements, systematic | 3.74 % (3400109360 stacks) |
| 64 M elements, random planes | 13.3 % |
| 32 M elements, random planes | 27.1 % |
| **128 M elements, systematic** | **0.6 %** (3824262996 Si IV 1403 0.595, 4000255147 C II 0.498) |

- **Results at 128 M:** all 56 window-files of 3400109360 and all 7 stacks come out exact. The first call takes at most 0.27 s, warm.
- **The reference** is `np.nanpercentile([0.25, 99.75])` over every finite eager value. glue's own eager limit varies by 2–82 % from draw to draw.
- **End to end in a glue Image viewer** on 4000255147 Mg II k:
  - 99.5 % gives [−0.5, 196.0] against the exact [−0.5, 195.75];
  - 95 % is exact;
  - Min/Max are the sample's extremes, just as glue's eager Min/Max come from 10,000 sampled values;
  - the mask attribute draws in 0.59 s;
  - the Histogram x range takes 0.04 s.

## 4. Each consumer on lazy data

| Consumer | Behaviour | Gate |
|---|---|---|
| Coordinator, Frame time and exposure label, `link_hpc`, crosshair and pixel-point patches | read Time/Exposure (still numpy) or coordinates only | none needed |
| Cursor readout, Point profile, image slices, Collapse | `__getitem__`; the image step is faster than main (below) | none |
| Image and Histogram limits, style-editor percentile | `LazyData.compute_statistic` | always on; it is the item's design, not a workaround |
| Quicklook spectrum panel | glue computes a whole-cube mean on `add_data` (main thread, then the worker; R14). Lazy 4000255147 Mg II k `quicklook()` was 2.79 s (max 2.94) against main's 1.77 s | `QuicklookProfileViewer.get_data_layer_artist` creates the layer `visible=False` (`profile/state.py:435`), replacing the hide-afterwards loop in `quicklook.py:783-785`. Then 1.43 s |
| A plain Profile or Histogram of the whole cube | computes everything, about as eager does; glue's "Add large data set?" prompt (`viewer.py:200`; Profile 1e8, Histogram 2e7) fires on lazy data exactly as on eager | none: per D18, the prompt is left alone |
| Mask attribute statistics, Inequality subsets | read the whole window through dask (0.59 s on 370 M elements) | accepted |
| Session save | fails inside glue's `catch_error` (`application_base.py:18-29`): the error dialog appears, no file is written, nothing crashes. It fails first on Quantity meta, as eager does (measured), then would hit `GlueSerializeError` for dask | WP3 (Later); a docs note |
| FITS export of a Pixel or ROI subset | `values[~mask] = nan` on a dask array raises `IndexError` (`gridded_fits.py:65-75`); whole-data export works | known limitation; a wp0 report candidate |
| Merging datasets | glue builds a plain `Data` (`data_collection.py:353`), so limits fall back to glue's corner sampling | accepted (rare) |

## 5. The two loading paths

- **File→Open and `--startup=iris_quicklook`:** `iris_data(path)` passes `memmap=True` only when `LAZY` is set and the primary header says `INSTRUME == "SPEC"`, so SJIs stay eager until PR2. It then calls `_raster_collection_data(..., scaling=_window_scaling(path))`.
- **Browser:**
  - `raster_data(files, windows, stack)` is lazy whenever `LAZY` is set and `stack` is false (stacks too once PR3 lands).
  - Scaling is read from `files[0]`: an observation's files come from one pipeline run.
- **Open files:** every memory-mapped file stays open.
  - Browsing 3602506433 per scan (99 files) under macOS's GUI soft limit of 256 failed on the third window with `OSError [Errno 24] Too many open files`.
  - Lazy reads therefore first call `allow_open_files()`, which raises the soft limit to 10240 (never above the hard limit, never lower). After that, all 7 windows load with 693 files open.
- **Already merged:** neither path has anything else to do. glue's load log and autolinker look only at components and coordinates.

## 6. Fallbacks and probes

- **Fallbacks:**
  - `glue_solar.sources.loaders.iris.LAZY = False` (documented in `docs/dev_guide/loader-customization.rst`) restores main's code path exactly. The eager branch of `_cube_data` is kept verbatim.
  - SJI/AIA stay eager until PR2.
  - Stacks stay eager until PR3.
  - Integer data only: one guard `values.dtype.kind == "i"`; float Level-2 files take the eager branch.
- **Probes:** none are new.
  - Views do not depend on dask's slice push-down, and `.copy` never applies.
  - The `LazyData` override improves on glue rather than working around a bug: a fixed glue would still sample 10,000 random values with ±20 % error. If you want it listed anyway, add an "always on" row to the workaround register.

## 7. PR order

1. **PR1, `wp10-m1-lazy-loading` (rasters per scan).**
   - New `loaders/lazy.py` without `RawStack`.
   - In `iris.py`: `_cube_data` (`:170-201`) gains a `scaling` branch; `_window_scaling` is new; `iris_data` (`:267-282`) and `raster_data` (`:285-307`) change.
   - `QuicklookProfileViewer` in `quicklook.py`, used at `:777`.
   - `"dask[array]>=2024.7.0"` added to `pyproject.toml`.
   - Docs: the mask becomes derived (`loader-customization.rst:31-33`, user guide `:52, 63-65, 101-121`), a memory and file note, the switch.
   - Tests.
   - Prototype diff: +91/−35 lines in 3 existing files plus `lazy.py`.
2. **PR2, SJI and AIA.**
   - `image_data` and `_image_cube_data`.
   - Measured:

| File | Load time | Peak ΔRSS | Kept footprint |
|---|---|---|---|
| SJI 1400 `.gz` | 1.78 → 2.37 s (+0.6 s for one more decompression) | 594 → 398 MB | 264 → 135 MB |
| Deconvolved 2796 `.gz` | 0.76 → 0.97 s | 414 → 272 MB | 151 → 76 MB |
| AIA 171 `.fits` | 0.16 → 0.12 s | 347 → 175 MB | 117 → 3 MB |

   - All three equal eager, including the 1,905 raw −32764 values in SJI 1400. Limits are within 0.13 %.
3. **PR3, stacks.**
   - `RawStack`, whose `__getitem__` handles an int, a slice, or all-array keys grouped by scan.
   - `stack_wcs` and `stack_times` split out of `stack_spectrogram_sequence`, which stays the eager path.
   - Measured on 3400109360, Mg II k and C II over 8 scans: values, mask, four image buffers (including fancy keys across scans), Time and Exposure equal eager. Load 0.12 s / +4 MB against 0.36 s.
   - The 3602506433 stack (memory mode, tracemalloc on): peak RSS 0.99 GB against 9.17 GB on main. Load takes 60 s against 57 s, all of it irispy's per-file work.

## 8. Tests (glue side only; bundled irispy files and LM-SAL/irispy-data v1)

- **Existing suite on the prototype:**
  - It fails only `test_importer.py:206`, which expects 4 main components; with the mask derived, the scan has 3 main components plus the mask.
  - Everything else passes, including the 8 remote-data tests and the quicklook move/stay matrix.
- **PR1 adds:**
  - **Lazy vs eager, bundled 3620258102 Si IV 1403 file:**
    - The −199 copy from `:443-464` and its 35,027 fills.
    - Both paths, every view kind (step, slit, λ, scalar, fancy) and the whole `.data`.
    - The derived mask is uint8.
    - The raw stays a negative-stride view (no copy).
  - **Remote 3400109360 cutout, added to `:510`:**
    - Lazy equals eager.
    - Limits equal `np.nanpercentile` exactly.
    - With `SAMPLE_SIZE` patched to half the window, limits equal the percentiles of `eager[::2]`.
  - **A `bare_app` viewer test:**
    - 99.5 % limits and the mask attribute draw.
    - Image buffers equal eager.
    - The Histogram x range is finite.
    - `save_session` reports an error and does not raise.
  - **Spectrum panel:** the raster layer is hidden at creation, and no axis-wise `compute_statistic` call with `subset_state=None` runs.
  - **Switch:** `LAZY=False` gives today's eager layout.
  - **`allow_open_files`:** raises a 256 soft limit and never lowers one.
- **PR2:** adapt `:142-183` (bundled SJI); remote `SJI_1400_t000_f050.fits.gz` and the AIA tarball (−200 only).
- **PR3:** adapt `:210-258`; image buffers of the mask over a stack.

## 9. Manual probe on ~/DATA

Archive the prototype scripts as `wp10_lazy_probe` with these modes:
- `open`: `open_rss.py`, lazy and eager, File→Open and browser, on 3824262996, 4000255147 and 3400109360.
- `equal`: `equal.py`, `stack_equal.py`.
- `limits`: `limits_final.py`.
- `images`: `image_lazy.py`.
- `fd`: `fd_limit.py`.
- Then `acceptance.sh time | memory | crash` with `TREE=<branch>`.

**Lazy GUI budgets** (medians; main's M0 figures in brackets):

| Observation | `quicklook()` | Image step | λ–t | Click | Synced |
|---|---|---|---|---|---|
| 4000255147 Mg II k | 1.43 s [1.77] | 21 ms [31] | 99 ms [110] | 203 ms [230] | 99–104 ms [108] |
| 3824262996 | 1.04 s [1.15] | 22 ms [32] | 62 ms [80] | 171 ms [197] | 61–63 ms [79] |
| 3400109360 (64 M sample run) | 0.79 s [0.72] | 27 ms [31] | 58 ms [73] | 173 ms [185] | 60 ms [74] |

- SJI step on 4000255147: 25 ms [35] (that SJI was still eager).
- 4000005156 memory mode: RSS after the quicklook is +229 MB [main: peak +1.47 GB].
- Crash mode: 3 single-cycle runs on 4000255147, no crashes (a small sample).

## 10. Risks

1. **Mapped files can crash glue.** A file truncated in place, or a network or removable drive lost while loaded, raises SIGBUS. Eager loading is immune; the switch is the escape. Extraction never overwrites (`scan.py:41-50`).
2. **RSS grows while viewing.** Memory-mapped pages count in RSS: a map panel reads the whole window, so a 5 GB window's first map is a cold 5 GB read. Footprint stays small. If you want a bound, a plane-by-plane `pread` source can replace the memmap behind `_Scaled` (2–6× slower when warm).
3. **Sampling on clumpy data.** Windows over 128 M elements with clumpy bright features could pass 1 %.
4. **Open files on Windows.** Windows has no `resource` module, so the open-file limit cannot be raised there; untested.
5. **Browser stacks re-open every file per window.** The browser opens all files once per ticked window (7 × 99 for 3602506433). Reading all ticked windows in one `read_files` call is a follow-up.

## Decisions for you

1. **"Below 10 % of eager RSS":** peak RSS while opening, with no viewer, measured as the change over the pre-load baseline. It passes on absolute RSS too.
2. **"Within 1 %":** of the exact limit range.
3. **The mask as a glue derived component:** it is no longer in `main_components`, so tests and docs change.
4. **Fix the spectrum panel inside PR1,** or as a separate PR0 that helps eager too (R14).
5. **Raise the open-file soft limit to 10240** process-wide.
6. **Split the item into three PRs** (and so three items, under the one-item-one-PR rule).
7. **`.fits.gz` SJIs as an eager raw int16 read** rather than a cache file on a disk that is 97 % full.

Prototype and results are in `/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/lazy/incremental/`:
- `tree/glue_solar/sources/loaders/lazy.py` and `prototype.diff`
- `open_rss.py`, `equal.py` with `equal.jsonl`, `stack_equal.py`, `limits_policy.py`, `limits_random.py` with `limits_random.jsonl`, `limits_final.py` with `limits_final.jsonl`
- `gui_check.py`, `image_lazy.py`, `fd_limit.py`, `bincount_speed.py`
- `acc/probe/out_lazy*/` (GUI budget runs) and `tests_tree.log`