**Ranking:** minimal-memory scores 8/10, glue-native 7/10 and risk-first 6/10. All three meet the memory and equality parts of the done-when, and I reproduced both. They differ on the limits.

**How I checked.** Each probe ran in a fresh process with the iris-plan env, a scratch HOME and offscreen Qt.
- **Memory:** I re-ran each design's own open probe (psutil sampled every 1 ms plus `ru_maxrss`) on File→Open of 3824262996 and 4000255147.
- **Equality and limits:** I wrote `judge-done/digest.py`. It checks 8 windows (4000255147 C II, Si IV 1403, Mg II k; 3824262996 Si IV 1403, Fe XII; 3400109360 r00005 C II, Mg II k, Si IV 1394, which are flipped) against main's eager loader. Every value is read through glue's `data[cid, view]` in 50-step views and hashed with NaN normalised. It also hashes the mask and glue's FRB for map, spectrogram, λ–t and a resampled map, for both values and mask. Each design's limits are compared to `np.nanpercentile` of the eager values.
- **Stacks:** the 3400109360 Mg II k and C II stacks for minimal-memory (`stack_robust.py`) and risk-first (its own `stack_equal.py`).
- **Results on all three:** lazy File→Open peaks at about 0.394–0.397 GB absolute RSS (+3 to +19 MB over the post-import baseline). Eager peaks at 5.728 and 7.306 GB, so lazy is 6.9 % and 5.4 %. Values, NaN, masks and FRBs are identical on all 8 windows, and the stacks I checked are identical too.

**One reading affects all three.** If "all windows of 4000255147" includes its SJI 1400 `.fits.gz`, holding that SJI in memory reaches 10.8 % on absolute RSS (minimal-memory's `all4000255147`: 0.807 vs 7.485 GB). Only minimal-memory's temp-file option (about 8.4 %) passes both readings. All three read "windows" as raster windows, which is the natural IRIS meaning.

## minimal-memory: 8/10
- **Memory:** stored in `open.jsonl`, and my re-run reproduces it.
- **Equality:** stored for 73 window-files in `slices_*.jsonl`, using 64-step views plus FRBs of data and the derived mask.
- **Limits:** exact (0 %) on all 17 raster windows and SJI 1400 at `SAMPLE_BYTES = 512 MiB` (`rawsource.py:18`; `limits2.jsonl`). That is a capped sample that reads every plane on most windows. The 128 MiB option stays at or below 0.66 % of each value. Because `IRISData.compute_statistic` answers every glue 99.5 % request, re-picking the preset in glue's style editor (the percentile drop-down) also gives exact limits.

Errors:
1. **No stack equality evidence**, even though the prototype makes stacks lazy. I checked two 3400109360 stacks and they are equal.
2. **A `.fits.gz` raster silently loads eagerly.** `lazy_raster_data` opens with plain `fits.open(path)` (`lazyload.py:126`), so `MemoryWindow(hdu.data)` (`:51`) gets scaled floats and `_source` returns None. I verified this on an int16 `.gz`. The claimed "compressed raster (the in-memory path)" test would therefore not exercise the lazy path.
3. **AIA is not kept eager as proposed.** The design says AIA stays eager, but the prototype's `lazy_image_data` loads AIA lazily. Two AIA tests are among its 4 test failures.
4. **Limits for 3400109360 are not reported.** I confirmed they are exact.
5. **Whole reads of a component return the full window.** `get_data` hands back the whole float32 window as numpy. This is flagged as decision 5 and does not affect the done-when.

## glue-native: 7/10
- **Memory:** stored and reproduced (7.0 % and 5.5 %).
- **Equality:** 83 datasets, including 7 stacks and SJIs (`equal2_*.jsonl`).
- **Limits:** exact to 1e-3 DN, because it counts every raw value (`lazy.py:92-108`).

Errors:
1. **It drops the user-confirmed "sample".** The claim that "every sample I tested missed 1 %" holds only for fixed-fraction or fixed-count rules; it never tested a size cap.
   - Under a 128 M-element cap, 70 of its own 75 windows are read in full.
   - The other two designs show capped samples are exact or within 0.66 %.
2. **The exact limits apply only once.** The layer maker sets them as a one-off Custom value (`sources/iris.py:68`). glue's own 99.5 % preset on this design's lazy data was 72–83 % of the range off on the 4000255147 and 3824262996 windows, and NaN on the 3400109360 windows (glue then uses 0–1). Re-picking 99.5 % in glue's style editor therefore misses the 1 % bound.
3. **The limits pass has no size bound.** It reads the whole window on the first image layer, which for a 20 GB file means a 20 GB read; only warm-cache runs were timed.
4. **The reason for rejecting a glue derived mask is wrong.** It says such a mask "cannot be drawn", but its own `LazyComponent` fallback handles the keys, and both other designs' derived masks draw identically to eager (I verified). The item asks for a derived mask.
5. **Its equality check does not use glue's read paths.** It compares only whole `.data.compute()` arrays, not glue's views or FRBs. I verified those are equal.

## risk-first: 6/10
- **Memory:** no stored output (there is no `open_rss` results file). My re-run reproduces the claim (6.9 % and 5.4 %).
- **Equality:** stored for 73 window-files including FRBs. Its stack results were not saved; I reproduced them and they are equal.
- **Limits:** within 0.6 % of the range only. Measured per value, two windows in the done-when observations fail:
  - 3824262996 Si IV 1403 lower limit: −8.25 against −8.0, a 3.12 % error;
  - 4000255147 C II 1336 lower limit: −7.25 against −7.5, a 3.33 % error.
  
  So "one small PR meets the whole done-when" holds only if the user accepts the range metric (its decision 2).

Errors:
1. **The integer guard it describes is missing.** The design says `values.dtype.kind == "i"` keeps float rasters eager, but no such guard is in the prototype. irispy's bundled float32 test raster loads as `RawComponent`, and `_sample` bincounts truncated floats (`lazy.py:87`). Measured on that file:
   - Si IV 1403 lower limit: −10.0 against an exact −200.0;
   - Fe XII upper limit: 37.70 against 34.93.
2. **The 128 M-element sample is untested on large windows.** On a 20 GB window it reads about 1 plane in 79 (risk 3).
3. **It does not hold SJI data.** PR1 leaves SJIs eager and the item is split into three PRs. That is not a done-when failure, but PR1 does not complete the item.
4. **The text contradicts the prototype on stacks.** It says "stacks stay eager until PR3", but the prototype makes stacks lazy.

Files are in `/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/lazy/judge-done/`:
- scripts: `digest.py`, `stack_robust.py`, `float_risk.py`, `gz_robust.py`
- results: `d_eager.jsonl`, `d_glue.jsonl`, `d_robust.jsonl`, `d_risk.jsonl`, `open_riskfirst.jsonl`, `open_glue.jsonl`, `open_robust.jsonl`, `stack_robust.jsonl`, `stack_risk.jsonl`