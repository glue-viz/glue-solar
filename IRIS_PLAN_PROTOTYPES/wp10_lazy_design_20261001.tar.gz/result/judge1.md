**Ranking on fit with D2, D10, D12, D17, D18 and the test split:** risk-first 8, glue-native 7, minimal-memory 5.

All three keep D10, D12's fill rule and D17 on the data I probed. They differ on D18 (how much they re-build instead of using glue's own hooks) and on D2 (whether workarounds switch on a behaviour probe).

**How I checked:** I used the iris-plan Python with a scratch HOME and offscreen Qt, running from `/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/lazy/judge-decisions/`.
- `probe.py` reads the headers of each file kind and runs glue-qt's PV slicer on each design's lazy component.
- `gzboth.py` and `gzprobe.py` compare each prototype's whole window and mask, for C II and O I, against the eager result. The eager result is astropy's scaling, then the flip when `STEPS_AV < -0.01`, then -200/-199 set to NaN. Files: 3400109360 r00000 (negative step) and a gzipped copy of it, since deleted.
- IRIS rasters, SJI 1400 and AIA 171 have no BLANK keyword. The bundled irispy raster is BITPIX -32 (float32).

## glue-native: 7/10

**Fits:**
- **D10:** it holds irispy's negative-stride memmap view (`irispy/io/spectrograph.py:162,252`) and adds no flip code. On the gzipped flipped raster it loaded lazily, and values and the uint8 mask equal eager.
- **D12, D17:** it applies main's fill rule to each scaled block, and AIA is -200 only.
- **D2:** the PV-slice patch switches on a behaviour probe (`needs_pv_dask_workaround`). The colour limits and the hidden spectrum layer go through glue's `layer_artist_maker` registry, which glue checks first (`glue/viewers/common/viewer.py:212`).

**Errors:**
1. **D18, colour limits:** it writes v_min/v_max into the layer (shown as Custom) instead of overriding `Data.compute_statistic`. glue says subclasses may override that method (`glue/core/data.py:1627-1628`).
   - glue's own percentile presets, the style editor and the Histogram range therefore stay on glue's corner sample, off by 69–106 % on its own figures.
   - It also removes the quicklook's `percentile = 99.5`, which used glue's own preset.
2. **D18 and the item text, mask:** the mask is a dask `DaskComponent`, not a glue derived component. Its own `__getitem__` fallback would make a derived mask drawable, so the rejection rests only on statistics cost.
3. **D2:** it leaves the subset FITS export regression to upstream, but D2 says nothing waits for an upstream release.
4. **D12:** the float path's limits use `np.nanpercentile`, which counts +Inf (saturation). glue uses `finite=True`.
5. **Scaling scope (item text):** `map_blocks` scales whole blocks, not the requested slice.
6. **Open-file limit:** `setup()` raises it for every glue session, not only when IRIS data load.

## minimal-memory: 5/10

**Fits:**
- **D10:** it takes the orientation from irispy's strides (`lazyload.py:49`) and checks the first and last planes against irispy's. The flipped raster loaded lazily and equals eager.
- **D2:** a failed check falls back to eager loading. The overrides use glue's documented override point.

**Errors:**
1. **D2:** `IRISData.get_data` returns numpy for every whole read. It is an always-on workaround for glue-qt's PV slicer and glue's exporter, with no probe, although the design itself names the glue fix that would retire it (`rawsource.py:278-283`).
2. **D18, most re-implementation of the three:**
   - its own FITS byte reader (`FileWindow`, using the data offset, seek and readinto);
   - its own numpy index handling (`_expand` and `_normalise`, about 60 lines);
   - its own streamed histogram;
   - new semantics: Min/Max with `random_subset` become percentiles;
   - exact Min/Max requests (no `random_subset`) are answered from a sample above 512 MiB.
3. **Test split:** owning the byte reader and the flip moves reading responsibility into glue-solar's tests: views against astropy, negative steps, fancy and bool keys, and an eight-thread read test.
4. **D12:** it adds a header `BLANK` as an extra missing code (`lazyload.py:35`). No IRIS or AIA header I checked has one, so today it changes nothing.
5. **WP10 note:** the note says `.fits.gz` SJIs get an eager int16 read; this design defaults to a gunzipped temporary file, on a disk that is 96 % full.
6. **Prototype bug:** `lazyload.py:126` opens files without `do_not_scale_image_data`. A `.fits.gz` raster therefore fails the check and loads eagerly: confirmed on the gzipped 3400109360 copy, whose values are still correct. The design's claim that the in-memory path covers compressed rasters is false.

## risk-first: 8/10

**Fits:**
- **D10:** irispy's view, no flip code. The gzipped flipped raster loaded lazily, and values and mask equal eager.
- **D12:** fill codes come from `MISSING_VALUES` through (m − BZERO)/BSCALE and are compared exactly on the raw ints.
- **D18, closest to glue of the three:**
  - the mask is a glue derived component (`add_component_link` with `fill_mask`, uint8), as the item text says;
  - the limits override glue's own `compute_statistic`, only for calls with `random_subset`, so glue's presets, style editor and Histogram all benefit;
  - the "Add large data set?" prompt is untouched.

**Errors:**
1. **D2, PV slicer:** the design never mentions it. glue-qt's `_slice_from_path` (`pv_slicer.py:205`) fails on its `LazyData` (`AttributeError: 'NoneType' object has no attribute 'sub'`), and no probe-gated fix is proposed. Subset FITS export is also left to upstream.
2. **D2 registries:** the hidden spectrum layer comes from overriding `QuicklookProfileViewer.get_data_layer_artist` instead of glue's `layer_artist_maker` registry. It also hides any dataset added to that viewer later.
3. **Integer-only guard:** the text says one guard (`dtype.kind == "i"`) sends float files to the eager path. Neither `prototype.diff` nor `lazy.py` has it.
   - Float files go lazy, and `_sample` truncates the floats into integer bins. On the bundled float file the limits are [-201.0, 21.0] against the exact [-201.56, 21.54].
   - +Inf, or a value below -32768, would make `np.bincount` raise.
   - If the guard is added, the planned PR1 test on the bundled float32 file only exercises the eager branch.
4. **Test split:** asserting that the raw stays a negative-stride view tests irispy's internal layout.