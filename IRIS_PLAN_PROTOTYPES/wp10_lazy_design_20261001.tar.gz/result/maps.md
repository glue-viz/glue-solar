=== MAP loaders ===
**Eager loader map: glue-solar main (`/Users/nabil/Git/glue-solar-accept`, cbf75e4)**

**Answer:** every eager load ends holding 5 B per element: the float32 science array plus a uint8 mask. Peak is 5.5 to 6.3 B per element, and 7 for `.fits.gz` SJIs. Eager values match `raw*0.25+7992` bit for bit, with fill exactly raw {-32768, -32764} and the V34 flip a negative-stride view. That holds for all windows of 3824262996 and 4000255147, and all 56 window-files of 3400109360. Glue's own "eager 99.5 %" limit is not a usable reference: across 20 random draws its upper limit varies by 2 to 82 % against the exact percentile, so a "within 1 %" check can only be made against the exact percentile.

## 1. How Data is built today

**Rasters, per window and per scan**
- Entry points:
  - File→Open: `iris_data` (`loaders/iris.py:267-282`) reads every window of the file in one `read_files(memmap=False)` call.
  - Browser: `load_entry` (`iris.py:379-390`) calls `raster_data` (`iris.py:285-307`) once per ticked window.
- **astropy** (`astropy/io/fits/hdu/image.py:791-866`): reads the raw int16 (2 B per element). The headers have no BLANK, so it makes a float32 copy with `np.array(raw, float32)` (4 B, line 851) and scales it in place (lines 859-861). The raw buffer is then freed: 6 B per element at that moment, for each HDU.
- **irispy** (`irispy/io/spectrograph.py`):
  - Takes the flip as a view, `data[steps]` (line 252).
  - Builds `data_mask = data == -200` (line 257), a 1 B bool that stays on the cube until the collection is dropped.
  - The FITS-TAB WCS is built per file (`_create_tabular_wcs`, lines 57-113).
- **glue-solar** `_cube_data` (`iris.py:170-201`):
  - `np.isin(values, (-200, -199))` gives a 1 B fill array plus a temporary (line 182).
  - `astype(float32, copy=False)` copies nothing for IRIS data (line 185); `values[fill] = nan` writes in place (line 186).
  - `Component(values)` holds the float32 array; for V34 files it holds the negative-stride view.
  - Mask: `np.isnan(values).view(np.uint8)`, 1 B kept (line 189). The view is needed because glue's `coerce_numeric` turns bool into int64 (`glue/utils/array.py:159-160`).
- **Kept per window:** 4 + 1 B per element. Measured component lists confirm it:
  - 3824262996 C II: float32 331 MB plus uint8 82.8 MB.
  - 3400109360 data strides are `[-732128, 1336, 4]`, so the flip is still a view.

**Time and Exposure time**
- `_frame_times` (`iris.py:204-212`) gives one datetime64[ns] per step or frame.
- `_per_frame` (`iris.py:164-167`) broadcasts it with `broadcast_to`, so it costs 0 bytes. glue keeps the view, because `autotyped` → `DateTimeComponent` makes no copy (`glue/core/component.py:161-167, 507-514`). Strides are `[8, 0, 0]`.
- Exposure time is also a 0-byte broadcast: big-endian `>f8` for rasters (from the FITS table), native float64 for SJIs. For V34 files its stride is -8, so it follows the flip.
- Consumers only index small views: `quicklook.py:129-135, 508`, `tools.py:68-70, 244-246`. `tools.py:70` needs Time to stay a `DateTimeComponent`.

**Stacks** (`stack_spectrograms.py:17-85`, from `iris.py:224-231` when the browser's Stack box is ticked)
- `read_files` loads every scan of the window eagerly: float32 plus the irispy mask.
- The output is a float32 `np.memmap` on an unlinked `TemporaryFile`: 4 B per element of disk, whose pages count in RSS (lines 46-50). Each scan is copied in with `scan[...] = cube.data` (line 57), which makes the flipped data positive-stride, then filled with `isin` → NaN (line 59).
- Acquisition times are a real datetime64[ns] array of shape (scan, step, slit) (line 53): 2.2 MB for 3400109360.
- `NDCube(mask=np.isnan(output))` is a 1 B per element full-stack mask (line 81) that `_cube_data` never uses. It then computes a second `np.isnan` for the glue mask (`iris.py:189`), so that first mask is waste.
- `missing=()` skips the `isin` step. Exposure time comes from `np.stack` per scan (`iris.py:227`) and Time is added at `iris.py:230`.

**SJI and AIA** (`image_data`, `iris.py:255-264` → `_image_cube_data`, `iris.py:239-247`)
- irispy (`irispy/io/sji.py:236-263`) builds `mask = data == -200` (1 B) and sets -200 to NaN itself. It leaves -199 alone; `_cube_data` makes that NaN.
- `.fits.gz` files are fully decompressed. With `memmap=True`, irispy writes 0 into the fill (`sji.py:240`).
- AIA uses `missing=(-200,)` (`iris.py:247`). Its BSCALE=1 and BZERO=0, so astropy returns raw `>i2` (`image.py:805-809`). The component stays big-endian int16 unless -200 is present: kept 2 + 1 B per element. None of the 9 local AIA cutouts holds -200 or -199.

**Colour limits**
- `_image` sets `state.layers[0].percentile = 99.5` (`quicklook.py:742-744`) on each raster panel (map, spectrogram, λ panel) and on each SJI viewer.
- glue first computes min/max when the layer is created, then the 0.25 and 99.75 percentiles (`glue/core/state_objects.py:356-357, 403-422`), over the whole cube (`stretch_global` defaults to True, `glue/viewers/image/state.py:596-599`).
- The sample is `random_subset=10000`, drawn with replacement over all elements, NaN included; non-finite values are dropped afterwards, leaving about 10000 × (1 − fill fraction) values.
  - Code: `glue/core/data.py:1839-1852`, `glue/utils/array.py:466-471, 765-770`.
  - The sample is cached per Data shape, so the three raster panels share it.
- For a dask array glue instead takes 10 random chunks with up to 1000 contiguous values each (`glue/core/data.py:1840-1845`, `glue/utils/array.py:723-755`). That sample is not cached and is strongly correlated.

**`_GlueWCS`** (`iris.py:73-157`)
- Wraps `cube.wcs.low_level_wcs` (`iris.py:177`): FITS-TAB for rasters, gWCS for SJIs, `CompoundLowLevelWCS` for stacks.
- Its memo can grow to about 25 MB per dataset, only once the data is viewed (`iris.py:60-65`).
- It does not depend on how the data array is stored, and `link_hpc` checks for it (`iris.py:333`).

**Negative-step rasters (D10)**
- irispy flips data, WCS table, times, exposures and per-step metadata (`spectrograph.py:161-162, 62, 213-252`). glue-solar adds nothing.

## 2. Fill audit (`audit.py`)

Each window was compared with the raw int16, read through astropy `memmap=True, do_not_scale_image_data=True` and flipped for V34. The check is `eager == raw.astype(f32)*0.25+7992`, with NaN exactly where raw is -32768 or -32764, and `mask == isnan`.

- **Result:** true for all 8 windows of 3824262996, all 9 of 4000255147, all 56 window-files of 3400109360, SJI 1400, deconvolved SJI 2796 and AIA 171.
- **No Inf:** none of these files holds +Inf.
- **Fill fractions:**
  - 3824262996: 0.09 to 0.27.
  - 4000255147: 0.15 to 0.40.
  - 3400109360: 0.08 to 0.28.
  - Deconvolved SJI 2796: 0.56.
- **-199 is real data in these files:** raw -32764 occurs 346 times in 3824262996 C II and 1905 times in SJI 1400; irispy's mask misses all of these.
- **Near-sentinel values are data:** raw values from -32763 to -32701 (scaled -198.75 to -184.25) occur, for example 101 in SJI 1400 and 80 in 3824262996 Si IV 1403. Eager keeps them as data, so a lazy loader must match the two exact codes, not a threshold.
- **Negative values are common data:** for example 39.6 M in 3824262996 Si IV 1403.

## 3. Colour-limit reference (20 glue draws vs exact `np.percentile` of all finite values)

| Dataset | Exact [0.25, 99.75] | Glue upper over 20 draws | Worst upper error |
|---|---|---|---|
| 3824262996 Si IV 1394 | [-8.25, 151.0] | 123.4 to 215.5 | 42.7 % |
| 3824262996 Mg II k | [-0.5, 650.25] | 592.5 to 712.8 | 9.6 % |
| 3824262996 2814 | [0.25, 739.0] | 726 to 756 | 2.3 % |
| 4000255147 Si IV 1394 | [-8.25, 108.5] | 89.9 to 145.5 | 34.1 % |
| 4000255147 Mg II k | [-0.5, 195.75] | 183.5 to 204.9 | 6.3 % |
| 3400109360 r0 2814 | [-1.5, 56.46] | 9.9 to 80.9 | 82 % |
| SJI 1400 | [4.75, 590.5] | 459 to 692 | 22 % |

- Lower limits sit at a few DN, in 0.25 DN steps (for example -0.5 or 0.25), so a relative 1 % on them is meaningless. Measuring the error as a share of the exact range would work.
- Cost: glue takes about 0.6 ms per limit pair. The exact percentile takes 0.2 to 2.0 s per window.

## 4. Eager memory and time

**Method**
- One fresh process per case, with HOME from `mktemp -d`, offscreen Qt, `PYTHONPATH` pointing at glue-solar-accept, cwd in scratch.
- **ru_maxrss:** the peak resident size (bytes on macOS).
- **Peak footprint:** from `proc_pid_rusage` V4 `lifetime_max_phys_footprint`, which I checked against a known allocation.
- **Traced:** `tracemalloc`, which numpy reports its buffers to.
- **Load time:** `time.perf_counter` around the loader call.
- **Page cache:** warm; I can't purge it without sudo, so cold-read times will be longer.
- **Baseline:** about 0.38 to 0.40 GB RSS and 0.295 GB footprint after imports.

**GB (B per element where marked)**

| Case | Elements | Load s | ru_maxrss | Kept RSS | Peak footprint | Traced kept / peak (B/el) |
|---|---|---|---|---|---|---|
| 3824262996 File→Open (8 windows, one read) | 792.3 M | 2.29 | 5.35 | 4.82 | 4.68 | 5.00 / 6.30 |
| 3824262996 browser (8 × `load_entry`) | 792.3 M | 3.08 | 5.70 | 5.23 | 4.32 | 5.00 / 5.92 |
| 4000255147 File→Open (9 windows) | 1034.2 M | 4.43 | 6.55 | 5.85 | 6.58 | 5.00 / 6.34 |
| 4000255147 browser | 1034.2 M | 4.24 | 6.84 | 6.13 | 5.83 | 5.01 / 5.59 |
| 3400109360 browser, per scan (56 Data) | 502.2 M | 6.66 | 3.44 | 3.36 | 2.69 | 5.03 / 5.54 |
| 3400109360 browser, stacked (7 Data) | 502.2 M | 6.53 | 4.58 | 3.76 | 1.65 | 1.03 / 3.36, plus 2.0 GB memmap |
| SJI 1400 `.gz` (4000255147) | 64.7 M | 1.75 to 2.43 | 1.00 | 1.00 | 0.69 | 5.04 / 7.06 |
| SJI 2796 deconvolved `.gz` | 37.2 M | 0.78 to 1.01 | 0.81 | 0.81 | 0.52 | 5.02 / 7.04 |
| AIA 171 cutout | 57.3 M | 0.17 to 0.54 | 0.73 | 0.73 | 0.59 | 3.04 / 6.04 |

- **Time split, File→Open path:**
  - 3824262996: irispy read 0.89 s, `_cube_data` 0.84 s (`isin` 0.19 s on the 235 M-element Mg II k window).
  - 4000255147: 1.19 s and 1.18 s.
- **Where the extra peak comes from:**
  - astropy's int16 + float32 pair: +2 B per element per HDU, briefly.
  - irispy's bool mask: +1 B. On the File→Open path the masks of all windows are alive together, which is why it peaks higher (6.3 vs 5.6 to 5.9).
  - `isin` temporaries.
  - For `.gz` files, the gzip buffer.
- **RSS runs above footprint by about 1 GB after a browser load:** RSS on macOS still counts freed pages the system has not yet reclaimed. For a stack it also counts the memmap pages.
- **irispy `read_files(memmap=True)` costs almost nothing:**
  - 3824262996: 0.29 s, +4 MB.
  - 4000255147: 0.39 s, +8 MB.
  - 3400109360 (8 files): 1.53 s, +9 MB.
  - The data comes back as `>i2` memmap views, negative-stride for V34, with no mask. The unit is still the scaled `DN_IRIS_FUV`, so the scaling has to be applied separately.

## 5. Points that affect the acceptance check
1. **What "10 % of eager RSS" means:** taken as absolute, 3824262996 allows 0.535 GB while imports alone are 0.38 GB, leaving about 150 MB for the load. With a Qt app the baseline is about 0.43 GB, from the M0 acceptance probe. Measuring peak minus baseline would allow about 0.50 GB.
2. **"Within 1 % of eager 99.5 %":** this can only be met against the exact all-finite percentile (§3). Glue's own sampled value is too noisy to compare against.
3. **Tests that pin today's types** (they will need adapting for dask-backed components):
   - `tests/test_importer.py:142-183`: four main components; `.data` of the mask is uint8.
   - `tests/test_importer.py:210-270`: the stack and the fill count of 35,027.
   - `tests/test_importer.py:444-462`: the V34 flip and -199.

Files are in `/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/lazy/loaders/`:
- `measure.py`, `run.sh`, `results_*.jsonl` and `components_*.json`: the memory and time runs.
- `audit.py`, `run_audit.sh` and `audit_*.jsonl`: the fill and limit checks.
- `memmap_floor.py`: the irispy `memmap=True` cost.
- `split.py`: the time split.

=== MAP consumers ===
I mapped every consumer with code citations and probed each one against eager data. One layout works with every consumer that has to work: a `DaskComponent` subclass that slices the raw int16 file first and scales only that slice (layout C below). Two glue paths still need our own handling: colour and histogram limits, and the whole-cube spectrum computed when the quicklook opens.

**How I measured.** Timings use `time.perf_counter`. Peak RSS was sampled with `psutil` every 2 ms in a separate thread (`lazylib.meter`). GUI timings are the median of 5 actions, each timed from the action until every canvas, profile worker and coordinator timer was idle.

**Probe data.**
- **Synthetic:** a 350 MB big-endian int16 file shaped like 4000255147 Si IV 1403 (1600, 417, 262). It has fill -32768 and -32764, negative values and whole missing exposures.
- **Real:** windows of 3824262996, 4000255147 and 3400109360, memory-mapped read-only. The GUI probe used 4000255147 Si IV 1403 scan 0 plus eager SJI 1400, running main's `quicklook()` (cbf75e4, PYTHONPATH=glue-solar-accept).

**Layouts compared.**
- **eager:** main's loader.
- **A:** `DaskComponent(scale(da.from_array(raw)))`, a plain dask graph.
- **B:** raw int16 `DaskComponent` plus a glue `DerivedComponent` for the scaled values and the mask.
- **C:** a `DaskComponent` subclass whose `__getitem__` slices the raw memmap and then scales; `.data` stays a dask graph; the mask is a `DerivedComponent`.

## 1. How glue-core 1.27.0 handles dask
- `Component.autotyped` returns a `DaskComponent` for any `da.Array` (component.py:158-159).
- `DaskComponent.data` returns the dask array (component.py:546-547). `__getitem__` computes and returns numpy (557-558).
- `Data.get_data(cid)` with no view returns `comp.data`, so a dask array. With a view it returns numpy (data.py:1402-1419). `data[cid]` goes through this (576-597).
- `DerivedComponent.data` and `__getitem__` call `link.compute` (component.py:207-221). `ComponentLink.compute` calls `np.asarray(result)` (component_link.py:166-190), so a derived component read without a view computes the whole array.
- **`compute_statistic`:**
  - With an axis and more than 40M elements, it splits into chunk views, each read through `__getitem__` (data.py:1676-1724).
  - With a `SliceSubsetState` (including `PixelSubsetState`), it reads only that slice via `to_array` (1733-1735).
  - With `random_subset` on dask, it uses `random_views_for_dask_array` (data.py:1840-1847; array.py:723-755). That picks 10 random chunks and reads a block from each chunk's start corner: the "reads only chunk corners" problem.
  - Every path then copies to float64 and builds a keep mask (array.py:455-486).
- **`compute_histogram`:** reads with no view (dask), indexes with `x[da.asarray(mask)]` for subsets (1939-1941), and computes after the range cut (array.py:574-583).
- **Image slices (FRB):** a dask sub-region shortcut is used only when the target component is a `DaskComponent` (fixed_resolution_buffer.py:274-300). Otherwise glue uses n-dimensional fancy indexing, which dask 2026.8 does not support (`NotImplementedError`).
- glue's own comment says `compute_statistic`, `compute_histogram` and `compute_fixed_resolution_buffer` may be overridden by subclasses for performance (data.py:1627-1628).

## 2. Two dask 2026.8 problems that affect every consumer
- **`da.from_array(np.memmap)` reads the whole file.** dask copies anything array-like that has `.copy` (dask/array/core.py:3649-3650), and without a `name` it hashes the memmap (core.py:3673-3674; tokenize.py:466-468). On the 350 MB file this cost 154 ms and +667 MiB. A thin wrapper with no `.copy` plus an explicit `name` cost 6 ms and +0 MiB (`lazylib.RawView`).
- **Slicing does not pass through the scaling.** `scale(raw)[:, 208, :]` scales every chunk in full: 106 ms and +1.2 GB, against 108 ms and +40 MiB for the raw slice. So "scaled per requested slice" needs `__getitem__` to slice the raw data first (layout C). Layout A rescales whole chunks on every image step.
- **Memory-mapped pages count in RSS on macOS.** A map panel at fixed λ touches every page of the file: +309 MiB for 350 MB. The "<10 % of eager RSS" acceptance check needs to count this, or the loader needs to read with pread or astropy `section` instead of a memmap.

## 3. Consumer by consumer

**glue-solar's own readers**
- **Coordinator** (quicklook.py:129-135 `_times`, 508-513 exposure read) and **`FrameTimeTool` / exposure label** (tools.py:68-85, 222-247): read only `Time` and `Exposure time`. These are numpy broadcasts (iris.py:164-167, 190-196), so they are unaffected: 0.0 ms, and the label text is identical in eager, A and C. They must stay numpy. `DateTimeComponent` rejects anything else (component.py:511-512), and a dask `Time` would become a `DaskComponent`, so `_time_component` (tools.py:70) would find nothing.
- **`CursorReadoutTool`** (tools.py:328): one scalar read per mouse move. Real data: eager 0.19 ms, C 0.2 ms, A 17.7 ms. Synthetic: B 0.6 ms. Same value in all.
- **`link_hpc` and its links** (iris.py:310-341): use only coords and world component IDs, never values. SJI step is 35 ms in all layouts.
- **Quicklook geometry helpers** (`_wavelengths`, `_window`, `_footprint_limits`, `_lon_lat`): coords and world components only. The crosshair patch (glue_patches.py:177) reads only the subset's slices.

**Image viewer slices (FRB)**, synthetic, ms per slice:

| Panel | eager | C | A | B |
|---|---|---|---|---|
| map at fixed λ | 13.5 | 15.0 | 211 (+1.5 GB) | raises |
| spectrogram | 0.6 | 1.2 | 22.9 | raises |
| λ–t | 2.3 | 4.6 | 90 (+0.8 GB) | raises |

- All successful slices equal eager, NaN included.
- B always raises `NotImplementedError: Don't yet support nd fancy indexing`, because its target is a `DerivedComponent` and so misses glue's dask shortcut.
- The Point subset mask on the map takes 5 ms on dask against 14.5 ms (+149 MiB) eager.

**Image colour limits** (state_objects.py:331 uses 10000 random points; 403-421; NaN falls back to (0, 1) at 425)
- In the GUI, all three raster panels get limits [0, 1] in both A and C; eager gives [-8.5, 43.41].
- Real windows with 1-step chunks: 3824262996 Mg II and 3400109360 Mg II give NaN, so (0, 1). 4000255147 Mg II gives an upper limit near 20 against an exact 195.75. Si IV gives about 4.5 against 42.75.
- With dask's "auto" chunks: NaN or up to 2.4× off, at about 330 ms and +2 GB per lower/upper pair.
- **The acceptance criterion needs a definition.** Eager glue's own 99.5 % limit comes from 10000 random points and is fixed per Data object (data.py:1849-1850). Across 30 fresh Data objects its upper limit varies from the exact value by:
  - 3824262996 Mg II k: -12 % to +6 %
  - 4000255147 Si IV 1403: -17 % to +14 %
  - 4000255147 Mg II k: -4 % to +8 %
  - 3400109360 Mg II k: -20 % to +20 %

  "Within 1 % of eager 99.5 %" can only hold against the exact percentile of the eager values. That definition is for you to confirm.
- Setting `stretch_global=False` makes glue use the displayed slice (`to_array`), which gives sane values on C: 4.8 ms per spectrogram slice, 25.6 ms and +339 MiB per map slice. But it recomputes on every slice change, so it does not match "set once".

**Profile viewer** (profile/state.py:212-228, 426-490; glue-qt threaded artist)
- The Point spectrum uses the slice path: 0.1 ms in C, 22 ms in A. Its sum is identical in all layouts (1232.75).
- When the quicklook adds the raster (quicklook.py:777-789), the layer is still visible, so glue computes the whole-cube mean twice: once on the main thread, once on the worker.
  - Synthetic, per pass: eager 0.68 s, C 1.03 s.
  - Real, C, 4000255147 Mg II k: 2.2 s and +1.57 GB peak (+751 MiB with 1-step chunks). 3824262996 Mg II k: 1.2-1.75 s.
  - Quicklook open-to-idle: eager 1.39 s, C 2.13 s.
- A `layer_artist_maker` that creates the layer as `ProfileLayerState(layer=data, viewer_state=viewer.state, visible=False)` removed both passes on the synthetic C data (add_data 0.38 s to 0.00 s). It would need to apply to the quicklook's spectrum panel only.

**Histogram viewer**
- The x range comes from the same corner sample (state_objects.py:566-573), so it is [0, 1] in A and C against [-12.75, 214.5] eager.
- Whole-cube histogram: about 630 ms in all layouts, but +1.1-1.5 GB on dask against +791 MiB eager.
- With a Point subset, each point move costs 180-230 ms and about 1 GB on dask (the full mask, data.py:1939-1941), against 36 ms and 167 MiB eager.
- glue-qt asks "Add large data set?" above 2e7 elements (histogram/data_viewer.py:25), eager or lazy.

**Subset masks**
- `PixelSubsetState`, `SliceSubsetState` and ROIs on pixel or world axes never read values: 0.0-0.4 ms in all layouts.
- Value-based selections:
  - `RangeSubsetState.to_mask` with no view returns a dask mask (subset.py:807-810). Profiles, percentiles, histograms and slices still work with it.
  - `InequalitySubsetState` reads the whole cube and caches it (subset.py:1662-1683): 200-330 ms and +1.2-1.8 GB on dask, against 38 ms and 167 MiB eager.

**Table viewer**
- Refuses any data that is not 1-D (glue_qt table data_viewer.py:42), eager or lazy, so no change.

**Session saving**
- Eager, A and C all fail first on Quantity values in `meta`. glue reports "Failed to save session" in an error dialog (application_base.py:100 `catch_error`), writes no file and does not crash.
- Once the meta is fixed, dask components raise `GlueSerializeError`, because glue has no saver for dask arrays (state.py:1093-1101, 380-397). That needs file references (`wp3-file-references`).
- Without a LoadLog, eager embeds the data even when "include data" is off: the 350 MB synthetic file gave 4.9 GB of JSON in 18 s and +6 GB.

**Data export**
- Whole-data FITS and HDF5 export works on dask (gridded_fits.py:65-75, hdf5.py:41-47), but computes everything: +0.8-1.3 GB against +0.7 GB eager.
- Exporting a `PixelSubsetState` or ROI subset to FITS raises `IndexError: Incorrect shape ... of integer indices`. A numpy mask cannot be used to assign into a dask array. This happened in both A and C, in the GUI and in the synthetic probe. B works but computes the whole array. A `RangeSubsetState` subset (dask mask) exports fine.

**Arithmetic and derived components**
- An Arithmetic-editor component (`ParsedComponentLink`) returns a dask array when read without a view, and numpy with a view.
- Its image slices work on C (0.8 ms) but raise `NotImplementedError` on A and B, because it is a `DerivedComponent`.
- A `ComponentLink` with a `using` function computes everything when read without a view. C's mask read that way cost 206 ms and +1.4 GB; any colour-limit or histogram calculation on the mask attribute does this.

## 4. Quicklook GUI, 4000255147 Si IV 1403

| Measure | eager | C | A |
|---|---|---|---|
| `quicklook()` | 1.37 s | 2.11 s | 2.23 s |
| open to idle | 1.39 s | 2.13 s | 2.25 s |
| λ–t slit step | 200 ms | 199 ms | 253 ms |
| map λ step | 34 ms | 40 ms | 109 ms |
| synced step | 177 ms | 183 ms | 212 ms |
| SJI step | 35 ms | 35 ms | 36 ms |
| click to idle | 194 ms | 185 ms | 318 ms |

No errors beyond the session and export ones above. These timings are only for comparing layouts within this probe: the eager λ–t slit step here (200 ms) is slower than the M0 acceptance median (73-110 ms).

## Files
All in `/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/lazy/consumers/`:
- **Shared code and data:** `lazylib.py` (the four layouts and the meter), `make_synth.py`, `synth.i2` (350 MB, can be deleted).
- **Probes:** `probe_core.py`, `probe_limits_real.py`, `probe_limits_eager_spread.py`, `probe_gui.py`, `probe_range.py`, `probe_profile_hidden.py`.
- **Results:** `probe_core_{eager,A,B,C}.log`, `probe_limits_real.log`, `probe_limits_eager_spread.log`, `gui_{eager,C,A}.json` / `.err`.

=== MAP fits ===
# wp10-m1-lazy-loading (F034): how IRIS files sit on disk, and what lazy access costs

## Bottom line

- **Axis order needs no change.** A window's numpy order on disk is (step, slit-y, λ), and an SJI's is (frame, y, x). irispy uses the same order. The only reorientation is the negative-step flip, which works as a reversed dask slice (`lazy[::-1]`).
- **Two ways to read lazily, with a trade-off:**
  - Memory-mapping (`memmap`) is fastest once the file is in the page cache. But every page it touches counts in RSS. One map at a single wavelength touches every page of the window, so RSS grows by the whole raw window (+490 to +789 MB).
  - Reading whole contiguous step planes (`pread`) keeps RSS at or below about 100 MB. It is 2 to 6 times slower than memmap when the data is cached, and faster than memmap when it is not.
- **That decides the "below 10 % of eager RSS" criterion.** Eager peaks are +5.33 GB (3824262996) and +6.90 GB (4000255147), so the budgets are about 533 and 690 MB. A memmapped map of the 4000255147 Mg II k window alone is +789 MB, which already fails. Only the plane-read approach fits, unless the criterion counts footprint instead of RSS.
- **astropy's `section` cannot serve the map as it is.** Its non-contiguous path reads one element at a time (about 10 µs each), so one map takes 4.3–6.7 s. Its reads are also not thread-safe, and in this dask version `lock=True` does not protect them, so a source wrapped in dask needs its own lock.
- **`.fits.gz` SJIs have no lazy access.** Each `section` read on a `.fits.gz` file costs about one full decompression (382 ms per frame). They need an eager raw int16 read or a one-off gunzip to a cache file.
- **irispy `memmap=True` cannot be used for SJIs.** It writes 0 into the fill pixels, which scales to 7992 DN. On a `.fits` it also copies nearly every page into private memory.
- **Colour limits are cheap from raw ints.** An exact whole-window 0.25/99.75 percentile takes one streamed pass of 0.3–0.9 s with no extra memory.
- **Correctness held on every check.** On 3400109360, all 56 windows of the 8 files, read lazily and reversed, equal irispy's eager read after glue-solar's fill-to-NaN, including NaN positions. All 68 per-slice benchmark runs also equal the memmap-scaled reference.

## How I measured

Everything ran with the `iris-plan` Python, `HOME` set to a temporary directory, offscreen Qt and Agg, from the scratchpad. The machine is an Apple M4 Pro with 24 GB RAM and 16 KB pages.

- **Memory:** `proc_pid_rusage(RUSAGE_INFO_V4)` gives RSS (the same number psutil reports), `phys_footprint`, and the lifetime peak; I also read `ru_maxrss`.
  - On macOS, RSS includes clean file-backed pages that are mapped into the process, plus freed malloc pages kept for reuse. Footprint excludes clean file-backed pages.
- **Cold cache:**
  - `msync(MS_INVALIDATE)` on a read-only shared mapping evicts the file's pages. I confirmed residency was below 0.1 % with `mincore` before each cold slice. Nothing is written to the data.
  - "read MB" is the page-cache residency added by the slice (`mincore` before and after).
- **Timings:** `time.perf_counter`; median of 5 runs when warm, 1 when cold.
- **Slices, numpy order (step, y, λ):**

| Slice | Key |
|---|---|
| profile | `[s, y, :]` |
| λ–t at one slit | `[:, y, :]` |
| spectrogram | `[s, :, :]` |
| map at one λ | `[:, :, k]` |

Each slice was scaled exactly as astropy scales (float32 copy, multiply by BSCALE, add BZERO; `astropy/io/fits/hdu/image.py:845,858-861`), then fill was set to NaN.

## 1. How the files are laid out (astropy `HDUList` dump)

### Rasters

- The primary HDU has no data. Windows are image extensions 1..NWIN, and the last two HDUs are auxiliary data (irispy `spectrograph.py:171`).
- Every window is BITPIX 16, BSCALE 0.25, BZERO 7992, with no BLANK keyword.
- FITS axes are NAXIS1 = λ, NAXIS2 = slit y, NAXIS3 = step. Each window is one contiguous big-endian `>i2` block.
- irispy keeps that order: `data = hdulist[i].data[steps]` (`spectrograph.py:252`).

| Observation | Windows | Notable windows (numpy shape, raw size) | STEPS_AV |
|---|---|---|---|
| 3824262996 | 8, 1.585 GB file | Mg II k: (400, 1095, 537), 470 MB; Si IV 1403: (400, 1095, 304), 266 MB | +0.349 |
| 4000255147 (sit-and-stare) | 9, 2.07 GB file | Mg II k: (1600, 417, 555), 741 MB; Si IV 1403: (1600, 417, 262), 350 MB | 0.0 |
| 3400109360 | 7 per file, 8 files of 126 MB | Mg II k: (64, 548, 380) | −0.998 (flips) |

### SJIs and AIA

- **SJI:** data are in the primary HDU, (frame, y, x), int16, BSCALE 0.25, BZERO 7992. The files are `.fits.gz`.
  - 4000255147 SJI 1400 is (400, 417, 388): 67.6 MB compressed, 129.6 MB uncompressed.
  - Fill: raw −32768 on 13.9 M pixels (21 %), raw −32764 on 1,905 pixels. So −199 does occur.
- **AIA cutouts:** int16 with BSCALE 1 and BZERO 0.

### Fill codes

Raw codes are (scaled − BZERO) / BSCALE: −200 is raw −32768 and −199 is raw −32764. AIA's −200 is raw −200. A reader should take BSCALE and BZERO from each HDU, not hard-code them.

### The `.tar.gz` archives

- Each archive holds the raw `.fits` files, uncompressed inside one gzip stream.
- Decompressing the 3824262996 stream takes 2.1 s for 1.585 GB (`gzip -dc`), and it cannot be read at random positions.
- Both existing flows extract first: glue-solar `scan.py:29-52` and irispy `utils.py:40-78`, which reuses an earlier extraction. So lazy access always runs on extracted `.fits` files.

### astropy scaling options

- `do_not_scale_image_data=True` returns the raw `>i2` values.
- `uint` handling only applies when BSCALE = 1 and BZERO = 2^15 (`image.py:751-761`). IRIS data therefore scale to float32 (`image.py:764-765`).

## 2. What astropy offers for lazy reads

**memmap**
- It maps the whole file with `ACCESS_COPY` (`file.py:90-91, 373-390`), and `hdu.data` is a view into it.
- It is turned off for anything that is not a regular file, including `GzipFile` (`file.py:291-292`).

**`hdu.section`**
- A contiguous key is one `seek` plus `fromfile` (`image.py:1036-1042`). Any other key recurses down to single elements (`image.py:1052-1071`).
- Measured on the map at one λ:

| Window | Map time |
|---|---|
| 3400109360 Mg II k | 348 ms |
| 3824262996 | 4.3 s |
| 4000255147 | 6.6 s |

- The profile, spectrogram and λ–t slices are contiguous, or one row per step, so they are fine.
- Scaled `section` reads keep −200 as a value, because there is no BLANK keyword.
- `Section` has `shape` and `dtype` but no `ndim` (`image.py:969-984`), so `da.from_array` needs `meta=`.

**`.fits.gz` with `section`**
- Every frame costs 382 ms, in any order (0, 1, 2, 200, 399, back to 0 …). A full eager raw read is 336 ms.
- The cause: `readarray` seeks to the data offset and then back to the saved position (`file.py:369, 445-455`). Each backward `GzipFile` seek re-decompresses from the start.

**Threads (reproduced in `threads.py`)**
- Non-memmap reads share one handle: `tell`, `seek`, `fromfile`, `seek` back (`file.py:369, 445-455`).
- 8 threads reading `section[i]` returned 20 to 28 of 64 planes wrong, silently, with no exception.

## 3. dask and glue interplay

- `da.from_array(hdu.data)` copies the memmap view, because of `x.copy()` (`dask/array/core.py:3649`). On 4000255147 Mg II k that took 1.1 s, +742 MB footprint and +1.48 GB RSS. So a memmap ndarray cannot be passed directly.
  - A small source object without `copy` or `__array_function__`, defining `__dask_tokenize__`, avoids that.
  - dask then pushes each view down into that object's `__getitem__`. For example, a spectrogram key arrives as `(slice(60,61), slice(0,548), slice(0,334))`.
- dask 2026.8.0 drops `from_array(lock=True)` when it merges a view into the read task:
  - `graph_from_arraylike` passes the lock as a keyword argument (`core.py:311`).
  - `_is_getter_task` only reads positional arguments (`optimization.py:83-87`).
  - The merged task is rebuilt without the lock (`optimization.py:176-181`).
  - Measured: 12 concurrent reads with `lock=True`, and the map came out wrong.
  - A `section` source therefore needs its own lock, or `os.pread` on its own file descriptor. A memmap source is thread-safe.
- Scaling inside `map_blocks`, or as dask elementwise operations, stops the view reaching the read. Each slice then reads whole chunks: on 3400109360 the λ–t slice read 19–22 MB instead of 1 MB. So do the scaling inside the source's `__getitem__`.
- glue's `DaskComponent.__getitem__` is `np.asarray(self._data[key].compute())` (`glue/core/component.py:557-558`).
- The quicklook's Profile uses a `PixelSubsetState`, and glue reads it as `data[att, slices]` (`glue/core/subset.py:1423`, `data.py:1733-1735`). That is a one-row read.
- Chunk size matters: with 1 step per chunk, each dask task costs about 0.1–0.15 ms.
  - 4000255147 Mg II k, warm: λ–t 235 ms and map 159 ms with 1-step chunks, against 8.6 and 8.8 ms with 32-step chunks.
  - Use chunks of 32 steps or more.

## 4. irispy `read_files(memmap=True)`

**Rasters**
- Opening the whole file takes 0.07 s and about 4 MB.
- Data are raw `>i2` views with mask None.
- The unit is still `DN_IRIS_NUV`/FUV even though the values are unscaled (`spectrograph.py:216-223, 255-268`).
- The negative-step flip is a negative-stride view: 3400109360 shows strides (−416480, 760, 2), so it stays lazy (`spectrograph.py:162, 252`).
- −199 is never handled.

**SJIs: why the fill becomes 0**
- `data_nan_masked[data == BAD_PIXEL_VALUE_UNSCALED] = 0` (`irispy/io/sji.py:239-243`, with −32768 from `utils/constants.py`).
- It has been there since irispy's first commit, 02f5358 (2020-04-25, "New irispy package", then `read_iris_sji_level2_fits`). Nothing later revisits it (`git log -S` in `~/Git/irispy`).
- My reading of the reason: int16 cannot hold NaN, so the unscaled path writes 0 where the scaled path writes NaN.
- Consequences:
  - Raw 0 scales to BZERO = 7992 DN, a plausible bright value. 13.9 M pixels become 0, and the 1,905 raw −32764 pixels are left alone.
  - The comparison reads every page.
  - The writes go to the copy-on-write mapping, so every page holding fill becomes private.

| SJI read | Time | RSS | Footprint |
|---|---|---|---|
| gunzipped `.fits`, `memmap=True` | 0.09 s | +198 MB | +133 MB (about the whole 129.6 MB raw) |
| `.fits.gz`, `memmap=True` (memmap ignored) | 1.54 s | n/a | +133 MB (eager raw int16) |
| `.fits.gz`, `memmap=False` | 1.62 s | n/a | +264 MB (float32, plus a bool mask) |

## 5. Per-slice costs, Mg II k windows

Each cell is profile / λ–t / spectrogram / map in ms. "+RSS" is the growth after the map slice.

- **mm:** astropy memmap view.
- **planes:** `section` for contiguous keys; for the map, a loop that reads whole step planes and keeps one plane alive at a time.
- **dask-X/32:** the source object over X, 32 steps per chunk.

**3824262996, (400, 1095, 537), 470 MB raw**

| Method | Warm (ms) | Warm +RSS | Cold (ms) | Cold +RSS |
|---|---|---|---|---|
| mm | 0.0 / 0.3 / 0.6 / 5.7 | +490 MB (footprint +0.8) | 0.3 / 81.5 / 2.2 / 510 | +481 MB |
| planes | 0.0 / 4.5 / 0.7 / 28.8 | +35 MB | 0.3 / 48.5 / 1.4 / 103 | +17 MB |
| dask-mm/32 | 0.7 / 2.4 / 1.3 / 3.2 | +517 MB | 1.6 / 26.1 / 4.8 / 258 | +484 MB |
| dask-planes/32 | 0.8 / 7.8 / 1.6 / 33.7 | +85 MB | 1.0 / 52.0 / 2.3 / 372 | +25 MB |
| section (map only) | 4287 | — | 4394 | — |

**4000255147, (1600, 417, 555), 741 MB raw**

| Method | Warm (ms) | Warm +RSS | Cold (ms) | Cold +RSS |
|---|---|---|---|---|
| mm | 0.0 / 1.1 / 0.2 / 8.6 | +789 MB | 0.9 / 305 / 2.0 / 790 | +756 MB |
| planes | 0.1 / 18.1 / 0.3 / 50.5 | +95 MB | 0.9 / 208 / 1.6 / 161 | +22 MB |
| dask-mm/32 | 0.7 / 8.6 / 1.1 / 8.8 | +808 MB | 1.7 / 98 / 3.0 / 390 | +758 MB |
| dask-planes/32 | 0.7 / 29.9 / 0.9 / 67.8 | +98 MB | 1.2 / 237 / 2.6 / 401 | +25 MB |
| section (map only) | 6623 | — | 6689 | — |

**Data pulled from disk by the cold λ–t slice**

| Observation | memmap | pread (planes) |
|---|---|---|
| 3824262996 | 19 MB | 7 MB |
| 4000255147 | 78 MB | 28 MB |

memmap pulls more because page-fault read-ahead fetches larger clusters.

**Si IV 1403 windows, map at one λ**

| Window | mm warm / cold | planes warm / cold |
|---|---|---|
| 3824262996 h5 (266 MB) | 5.2 / 291 ms | 16.5 / 58 ms |
| 4000255147 h6 (350 MB) | 8.1 / 405 ms | 34 / 78 ms |

On 3400109360, every slice takes 36 ms or less, even cold. All 68 runs gave equal results; the first cold attempts of 3824262996 h8 dask-mm/32 and dask-planes/32 failed only the eviction check and passed when re-run.

## 6. SJI frame access (4000255147 SJI 1400)

| Access | Per-frame cost | Memory |
|---|---|---|
| `.fits.gz` via `section` | 382 ms | — |
| `.fits.gz` eager raw int16 read | 336 ms once | +129.8 MB footprint (2 bytes per element, against 4 for float32) |
| gunzipped copy, memmap frame read | 0.4–0.6 ms cold or warm | — |

The data from the `.fits.gz` and from the gunzipped copy were identical.

## 7. Applying the flip lazily (`flip.py`)

On 3400109360 (STEPS_AV < −0.01, so irispy flips), I wrapped the raw memmap in the source object and reversed it with `da.from_array(...)[::-1]`. That orientation matches irispy's.

- All 8 files and 56 windows were compared against `read_files(memmap=False)` after glue-solar's `np.isin(-200, -199)` to NaN (`iris.py:182-186`).
- The full arrays, map, spectrogram, λ–t and profile are all equal, with identical NaN positions.
- Step 3 arrives at the source as on-disk plane 60 (64 − 1 − 3): still one contiguous read.
- The fill totals over the observation: raw −32768 on 53.6 M pixels, raw −32764 on 8,975.

## 8. Colour limits from raw ints (`limits.py`)

glue's "99.5 %" means the 0.25 and 99.75 percentiles (`state_objects.py:403-422`). glue computes them from a random subset of 10,000 points (`state_objects.py:331`), so its eager value itself varies between runs.

The exact percentile can be computed from a `bincount` of raw codes over 65,536 bins, streamed one plane at a time. It matched `np.nanpercentile` on the scaled data.

| Window | Exact limits (scaled) | Time | Extra footprint |
|---|---|---|---|
| 3824262996 h8 | (−0.5, 650.25) | 0.56 s | none |
| 3824262996 h5 | (−8.0, 76.0) | 0.32 s | none |
| 4000255147 h8 | (−0.5, 195.75) | 0.88 s | none |
| 4000255147 h6 | (−8.5, 42.75) | 0.43 s | none |

Sampling evenly spaced step planes instead, upper-limit error as a percentage of the limit range:

| Planes sampled | Read time | Upper-limit error |
|---|---|---|
| 64 | 15–89 ms | 0.0 to 0.6 % |
| 32 | 7–45 ms | up to 1.0 % |
| 4 to 16 | 1–22 ms | up to 3.4 % |

The lower limit sits near 0, so its error as a percentage of the value is not meaningful.

## 9. Eager reference (`eager.py`)

This is glue-solar's `iris_data()` on the whole file, with no glue app.

| Observation | Load time | Peak RSS | Footprint | Peak bytes per element |
|---|---|---|---|---|
| 3824262996 | 2.0 s | +5.33 GB | +4.01 GB | 6.7 |
| 4000255147 | 2.7 s | +6.90 GB | +5.87 GB | 6.7 |

## Questions for whoever implements this

1. **Is the 10 % RSS budget meant to include clean file-backed pages?** If it is, memmap is out and plane reads are needed: about 2–6 times slower warm, and still well inside the M0 step budgets of 73–110 ms. If not, memmap with 32-step dask chunks is fastest.
2. **For `.fits.gz` SJIs, eager raw int16 or a one-off gunzip to a cache file?** Eager raw costs 129.6 MB for this SJI and 336 ms at load. A cache file needs disk space; this disk is 97 % full.
3. **Exact limits or sampled limits?** The exact pass costs 0.3–0.9 s per window. A 64-plane sample stayed within 0.6 % of the exact upper limit here, but glue's own eager reference is a random 10,000-point sample.

All scripts and the raw results are in `/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/lazy/fits/`. `results.jsonl` holds all 68 benchmark runs and `table.py` prints them as a table. `run_matrix.sh` reruns the matrix. The gunzipped SJI copy has been deleted.

- `bench.py`
- `run_matrix.sh`
- `results.jsonl`
- `table.py`
- `cache.py`
- `mem.py`
- `layout.py`
- `irispy_memmap.py`
- `sji.py`
- `flip.py`
- `limits.py`
- `eager.py`
- `pushdown.py`
- `threads.py`

=== MAP prior ===
# Prior art and constraints for `wp10-m1-lazy-loading` (F034)

No prior work implements lazy loading, so this item starts fresh. Measured on the current stack (dask 2026.8.0), several glue and dask defaults break a naive design:

- **dask copies the file into memory.** `da.from_array(memmap)` makes a full copy of the window.
- **glue's own dask colour limits are wrong.** It samples only chunk corners, so it returns limits of 0 to 1.
- **A glue derived component cannot be drawn.** An Image viewer cannot show a derived component (such as the mask) over a `DaskComponent`.
- **The quicklook Profile reads the whole window.** That takes 2.4–2.7 s on the main thread when the quicklook opens.
- **Two acceptance criteria are not testable as worded.** "Within 1 % of eager 99.5 %" fails on quantisation and on glue's own randomness, and "below 10 % of eager RSS" depends on how RSS is measured.

## 1. Prior art in the plan history

- **The pre-restructure item** (`git show a04eba4^:IRIS_GLUE_GAP_PLAN.md`, line 961) said:
  - Open rasters and SJIs with irispy `memmap=True` and publish `DaskComponent`s computing `raw*BSCALE+BZERO`, the fill rule and the uint8 mask per requested slice.
  - Build the 4D stack from lazy scans. Lazy opens run in the `wp10-nonblocking-load` Worker.
  - Eager loading stays the default until the lazy path passes the same tests.
  - Add `dask[array]` to `pyproject.toml` in the PR that first imports dask.
  - Done when peak RSS **"before any viewer opens"** stays below 10 % of eager (3.17 GB and 4.14 GB float32), slices, NaN positions and masks equal eager (including 3400109360), **GUI gaps stay ≤ 0.2 s and the M0 budgets hold**.
  - Depends on `wp10-m0-acceptance` and `wp10-nonblocking-load`.
- **What the restructure (a04eba4) changed.** It added the raw-int16 approach, the derived mask and limits from our own raw-int sample. It dropped the "before any viewer opens" qualifier, the GUI-gap and M0-budget clauses, and the dependency on nonblocking-load. It also added two notes:
  - "irispy `memmap=True` zeroes SJI fill, so SJIs need our own astropy read, and `.fits.gz` SJIs an eager int16 read".
  - The `wp0-report-candidates` entry "core dask percentile sampling reads only chunk corners".
- **03351c4** moved lazy loading to M1 and proposed `wp0-core-missing-value`: a per-component missing value glue would treat like NaN, so int16 could stay integer. Until then, each requested slice would become float32 with NaN.
- **2124cda** dropped that proposal. The user decided against a sentinel value, here or upstream ("lets leave it as NaN then"). This is now D17.
- **An earlier table row** read: "Core has `DaskComponent` and random-view statistics; IRIS reads eagerly (`memmap=False`), stacks use floating memmaps; a representative interactive workload still needs measurement."
- **Older notes still relevant:**
  - Stack storage is a `np.result_type(scan0, float32)` memmap.
  - D12: masks are uint8 because glue coerces bool to int64.
  - Negatives stay data (33–62 % of valid FUV samples).
  - The +Inf saturation guard covers a code path only: local int16 Level-2 files cannot store Inf.

## 2. GLUE_SPEED.md findings that bear on lazy data

- **profile-stats#6:** percentile limits sample 10,000 values (`glue/core/state_objects.py:331`) and are cheap. It records: "dask or memmap data was not tested (glue-solar loads with memmap=False)". Nothing in the survey measured dask.
- **R14:** `_reset_y_limits` computes whole-cube profiles on the main thread (`glue/viewers/profile/state.py:212`, called from 66–67 and 158–161). The quicklook adds the raster to its Profile and hides it, but the pass still runs: 0.37–0.40 s on Si IV eager. `add_data` also queues a forced worker recompute.
- **R21:** `compute_statistic` copies each chunk to float64 (`glue/utils/array.py:483`) after `np.asanyarray` (`:455`). Chunks are 4e7 elements (`data.py:1675-1730`).
- **R3:** glue-qt threads a Profile layer when `layer.size > 1e7` (`glue_qt/viewers/profile/layer_artist.py:50`). A subset's size is its parent's size.
- **R23:** the Histogram builds full-cube masks.
- **R26:** glue imports `dask.array` eagerly (0.10–0.14 s per launch, after the irispy/sunpy.map deferral in `wp10-m1-startup-io-speed`).
- **R13 / S5:** a `.fits.gz` is decompressed 4–5 times on open.
- **io-model "Memory":** BSCALE scaling makes an int16 transient (tracemalloc peak 1.17 GB, keeping 835 MB for a 667 MB float32 window). glue's FITS reader memory-maps, but BSCALE forces scaling into memory. glue keeps irispy's array without a copy.
- **io-model "Not investigated":** irispy/ndcube cubes sit in reference cycles, so their masks stay alive until the cyclic GC runs. Run `gc.collect()` before taking RSS.
- **The 'Add large data set?' prompt** fires at `data.size >= large_data_size` (`glue/viewers/common/viewer.py:200`): Profile 1e8, Histogram 2e7 (glue_qt `profile/data_viewer.py:25`, `histogram/data_viewer.py:25`). The quicklook sets `large_data_size=None` (`glue_solar/quicklook.py:781`). Cancelling it breaks later viewers (`wp0-qt-large-data-cancel`). Lazy data trips it exactly as eager data does.
- **M0 memory baselines** (Current state): 4000005156 scan 0 keeps 5.15 B/element and peaks at 9.53 by tracemalloc. The 3602506433 stack peaks at 9.17 GB RSS. The acceptance probe measures RSS with psutil and `ru_maxrss`, as a delta over the start.

## 3. Prototypes touching lazy data

None implements lazy loading. `perf_survey/links/03_tab_inverse.py:15` uses `read_files(memmap=True)` only for WCS timing; `io-model/load.py` and `gz.py` use `memmap=False`. `itn32_sot/research/sot_prototype.diff:27` has the same `memmap=memmap, do_not_scale_image_data=memmap` idiom as irispy. The acceptance probe (memory mode) is the RSS harness to reuse.

## 4. How glue and other plugins hold large FITS

- **glue-core FITS factory:** `fits.open(..., mode='denywrite')` (`glue/core/data_factories/fits.py:35,75`), then `Component.autotyped(hdu.data)` (`:140`). Scaled data are therefore materialised; glue has no lazy FITS factory.
- **glue-core HDF5:** memory-maps contiguous datasets (`hdf5.py:44-66`).
- **`DaskComponent`** is created only when a caller passes a `da.Array` (`component.py:158-159`).
- **spectral-cube** (installed but not importable: `ImportError` on astropy 8.0.1) uses the pattern that works here: a numpy-like handler class with `shape`, `dtype`, `ndim` and `__getitem__`, passed to `da.from_array(handler, name='... ' + uuid4(), chunks=...)` (`dask_spectral_cube.py:177-199, 311, 1466`; `casa_dask.py:207`). Its `to_glue` adds the cube eagerly (`spectral_cube.py:2293`).
- **glue-astronomy, glue-jupyter and jdaviz** are in no local env and have no local checkout, so I could not cite them.

## 5. DaskComponent history and limits

**History** (`~/Git/glue`):
- Added 2020-05-11 (commit 2c5e053f, PRs #2137 and #2149), released in v1.0.0 (2020-09-17, `CHANGES.md:797`).
- #2249: viewer and mixed-dask fixes (v1.2.4).
- #2399: `__getitem__` always returns numpy (v1.11.0).
- #2412: histograms of lazy arrays (v1.12.0).
- #2444: no fancy indexing for subsets over dask data (v1.14.0).
- `component.py`, `data.py`, `utils/array.py`, `fixed_resolution_buffer.py` and `state_objects.py` are identical between v1.27.0 and local glue main (`git diff --stat` empty). Only `viewers/image/state.py` changed: 1-D datasets cannot be reference data.

**Limits** (glue 1.27.0):
1. **No view gives the dask array itself.** `.data` returns it (`component.py:546`), and so does `Data.get_data(cid)` with no view (`data.py:1414-1417`). `compute_statistic` then materialises it with `np.asanyarray` (`utils/array.py:455`).
2. **No nd fancy indexing.** `__getitem__` is `np.asarray(self._data[key].compute())` (`component.py:557-558`), and dask refuses nd fancy indexing (`dask/array/slicing.py:249`). Only the fixed-resolution buffer's (FRB) dask branch avoids it. That branch slices a bounding box and converts it to float64 (`fixed_resolution_buffer.py:285-300`, `.astype(float)` at `:295`). It runs only when the target is a `DaskComponent` or a subset is drawn over dask data.
3. **Random statistics sample chunk corners.** `random_views_for_dask_array` (`utils/array.py:723-753`, unseeded `np.random.randint` at `:732`) picks 10 random chunks and reads the leading corner block of each. A NaN result becomes limits (0, 1) (`state_objects.py:424-425`).
4. **No session saver for dask arrays.** The Component saver does `context.do(component.data)` (`glue/core/state.py:1093-1101`), unless the component has a `_load_log` and `include_data` is False.
5. **Derived components break session save if their function is not importable.** The function saver falls back to Python 2's `.encode('base64')` (`state.py:1232`), which raises on Python 3.
6. **Histograms compute the whole lazy array** after the keep mask (`utils/array.py:574-582`).

## 6. New measurements

All runs: iris-plan env, scratch HOME, offscreen, warm page cache, one fresh process per variant. Times by `perf_counter`. Memory by psutil RSS, `ru_maxrss` (peak) and macOS `phys_footprint` (`proc_pid_rusage` v2), which leaves out clean file-backed pages that RSS counts.

**M1. Slicing a lazily scaled memmap** (3824262996 Mg II k, 400×1095×537 int16, 470 MB)

| Approach | Build cost | Spectrogram | Map | λ–step |
| --- | --- | --- | --- | --- |
| `da.from_array(astropy data)` + elementwise ops, step chunks | +471 MB footprint, +941 MB RSS | 0.10 s | 0.30 s | 0.33 s |
| Same with `map_blocks` | same | – | 0.13 s | 0.13 s |
| Getter class (scaling in `__getitem__`), one chunk, `name=False` | 0 | 0.11 s | 5–18 ms | 1.5 ms |
| Getter class, 400 step chunks, `name=False` | 0 | 0.10 s | 73–82 ms | 65–70 ms |

- The build copy happens with every `name`/`asarray`/`inline_array` setting, and also for a plain `np.memmap`: dask 2026.8.0 runs `x = x.copy()` on any array-like with `.copy` (`dask/array/core.py:3649-3650`). I did not check which dask release introduced it. irispy only requires `dask>=2024.7.0`.
- `chunks="auto"` peaked at 3.77 GB RSS.
- Every result was bit-equal to the eager slice.
- dask does not push slices through elementwise or `map_blocks`, so scaling belongs inside the `from_array` source.
- With `name=None`, hashing the getter makes RSS grow by the whole window (+471 MB) before any slice is read.
- A map slice (all steps at one λ) touches every page of a C-ordered `[step][slit][λ]` window. RSS rose by about +475 MB while footprint rose by only +18 MB.

**M3 / M8. glue's own limits on dask** (all 17 windows of both observations; glue 99.5 % = percentiles 0.25 and 99.75 with `random_subset=10000`)

- **One chunk:** NaN limits on every window.
- **Per-step chunks:** NaN on 3824262996; up to 4871 % off on 4000255147.
- **Stock glue-qt Image viewer** (default and after setting 99.5): `v_min=0`, `v_max=1`, with no error.
- **`stretch_global=False`** gives sensible per-slice limits (−0.57, 560.6), because a `SliceSubsetState` reads the whole slice.
- **glue's eager limits are themselves random.** Across 10 seeds the eager upper limit for 4000255147 Si IV 1394 spans 92.0–145.5 (exact 108.5), and for 3824262996 Mg II k 620.5–712.8 (exact 650.25). The worst eager deviation from exact is 1.4–34 % of the value.

**M9. Raw-int samples** (percentiles of raw ints scaled afterwards equal those of the scaled data; reference = exact `nanpercentile` of the whole window)

| Sample | Worst error, % of range | Time per window (warm) |
| --- | --- | --- |
| 10,000 random | 20.4 % | ~0 s |
| 100,000 random | 10.5 % | 0.004 s |
| 1,000,000 random | 2.0 % (up to 3.5 DN on bright lines) | 0.04 s |
| Every 8th step, whole planes | 2.0 % (over 1 % only on Fe XII on both observations and Cl I; 0.25–0.5 DN) | 0.03–0.28 s |
| Every 32nd step | 3.0 % | 0.006–0.068 s |

- **Quantisation sets a floor.** Raw values are 0.25 DN steps. Lower limits lie between −8.75 and +2 DN, so one step is 3–100 % of the lower limit. Faint windows have upper limits of 6.5–16.25 DN, so one step is 1.5–3.8 % of the upper limit. A 1 % tolerance on each limit's own value cannot be met.
- **Cold-disk cost.** Random samples touch about every 16 KB page, which is a full window read when the cache is cold. Sampling every k-th step reads 1/k of the window. Cold disk was not measured.

**M4. glue code paths, eager vs dask (one-chunk getter)**

| Path | 3824262996 Mg II k | 4000255147 Mg II k (1600×417×555) |
| --- | --- | --- |
| Whole-cube mean profile (the `_reset_y_limits` pass) | 0.89 → 2.39 s; RSS +790 MB, footprint +27 MB | 1.62 → 2.67 s; RSS +1.35 GB, peak RSS 2.09 GB |
| Map slice through `compute_fixed_resolution_buffer` | 9 ms | 14 ms |
| Spectrogram slice through `compute_fixed_resolution_buffer` | 3–7 ms | 1–3 ms |

- Profiles from dask equal the eager ones bit for bit.
- `data[cid]` returns a dask `Array`.
- Session save raises `GlueSerializeError` ("Don't know how to serialize dask.array") both with and without `include_data`.

**M5. Derived uint8 mask** (`ComponentLink` with a module-level function) over the `DaskComponent`

- A slice view takes 0.087 s and equals eager.
- **The FRB fails:** `NotImplementedError: Don't yet support nd fancy indexing`. The path is `fixed_resolution_buffer.py:309` → `component.py:217` → `component_link.py:166` → `component.py:558` → dask. So the derived mask, and any derived component over lazy data, cannot be shown in an Image viewer.
- `data[mask]` with no view takes 1.04 s and adds 258 MB footprint (a whole-cube uint8).
- `random_subset` limits on the mask scan the whole window (0.5 s).
- The mask is not in `main_components`.

**M6. irispy 0.9.1 `read_files(memmap=True)`**

- **Negative-step raster:** returns a lazy negative-stride view equal to `raw[::-1]` in 0.05 s. `mask=None`, and the unit stays `DN_IRIS_NUV` even though the data are unscaled ints. That label is wrong.
- **SJI 1400 `.fits.gz`:** an eager int16 read, 1.57 s, +137 MB footprint. All 13,926,465 raw −32768 values become 0 (physical 7992 DN). The 1,905 values of −32764 (= −199) stay. Unit `DN_IRIS_SJI_UNSCALED`.
- **99 raster files** (Si IV 1403): 1.33 s, +25 MB, **99 open files**.

**M7. Eager peak for "all windows" on main** (cbf75e4, no app; process baseline 0.39 GB RSS)

| | 3824262996 (8 windows) | 4000255147 (9 windows + SJI 1400) |
| --- | --- | --- |
| Eager peak RSS | 5.73 GB | 7.49 GB |
| Eager footprint | 4.31 GB | 5.43 GB |
| Eager open time | 2.08 s | 4.52 s |
| 10 % target, absolute | 0.573 GB | 0.749 GB |
| irispy memmap floor, peak RSS | 0.394 GB (0.06 s) | 0.666 GB (0.82 s); the SJI int16 read alone is +0.27 GB RSS |

## 7. Constraints a design must meet

1. **D17 / D12.** Missing data become NaN: raw −32768 and −32764 (−200 and −199) for rasters and SJIs, −200 only for AIA cutouts (`loaders/iris.py:246-247`; AIA files have BSCALE 1, BZERO 0). +Inf is saturation; negatives are data; stored masks are uint8. Nothing is a sentinel value.
2. **Eager equality.** The eager loader builds float32 with `values[isin(values, MISSING)] = NaN` and a mask `isnan(values).view(uint8)` (`loaders/iris.py:181-189`; `stack_spectrograms.py:14, 45-64`). Quarter-DN values below 2^22 are exact in float32, so lazy slices can be bit-equal.
3. **D10.** Negative-step rasters keep irispy's flip, with data, fill mask, WCS, times and per-step meta flipped together (`irispy/io/spectrograph.py:162, 258`). An own astropy read must reproduce the flip. Tests cover this in `test_importer.py:444-464`.
4. **SJIs cannot use irispy's memmap path**, because it zeroes the fill (`irispy/io/sji.py:239-241`). `.fits.gz` cannot be memory-mapped, so an SJI is an eager int16 read with lazy scaling.
5. **D18 / D2.** Configure glue first. Any change to glue's behaviour switches on a behaviour probe, never a version, and goes in the workaround register.
6. **Colour limits must not come from glue's dask sampling** (section 6, M3/M8). Set `v_min`/`v_max` once per image layer; glue switches the percentile to 'Custom' (`state_objects.py:341-344, 352-354`). The quicklook's `state.layers[0].percentile = 99.5` (`quicklook.py:744`) must change on lazy data. `stretch_global=False` still works through `SliceSubsetState`.
7. **The quicklook budgets still apply.** `quicklook()` ≤ 3 s (currently 1.15 s on 3824262996 and 1.36 s on 4000255147 Si IV). `_profile` adds the whole raster (`quicklook.py:775-790`), and on dask the `_reset_y_limits` pass alone costs 2.4–2.7 s on Mg II k, plus a forced worker recompute (R14). Image step ≤ 0.10 s, λ–t ≤ 0.15 s, click ≤ 0.35 s and SJI ≤ 0.15 s are met by the one-chunk getter on a warm cache.
8. **Lazy stacks** replace the eager tempfile float memmap and the eager `np.isnan` NDCube mask (`stack_spectrograms.py:45-64, 81`). Scan 0 still supplies the WCS. `Time` and `Exposure time` stay per-frame broadcasts (`loaders/iris.py:164-167, 190-196`).
9. **Items that build on this one:** `wp2-m2-moment-maps` (peak RSS ≤ 3× the float32 window), `wp4-m1-multi-window`, `wp10-m3-sit-stare-chunks`, and `wp1-dn-per-s` (M1: a `DerivedComponent` shown in viewers). `wp1-dn-per-s` breaks on lazy data (section 6, M5).
10. **dask is already a transitive dependency** (irispy-lmsal requires `dask[array]>=2024.7.0`). Import it lazily, so `wp10-m1-startup-io-speed`'s import deferrals keep their gain (R26).
11. **Tests** use LM-SAL/irispy-data remote data only. glue-solar tests the glue side. Existing tests expect the mask in `main_components` (`test_importer.py:147, 183`) and read whole `.data` (`:156-158, 228-229, 268-270`).

## 8. Pitfalls already recorded or found

1. `da.from_array` on any `.copy`-able array copies the whole window. Wrap the memmap in a class without `.copy`, as spectral-cube does.
2. `name=None` hashes the source and reads the whole window. Pass `name=False` or a uuid name.
3. Chunking: dask computes whole blocks. One chunk per window is fastest (5 ms map slice); per-step chunks cost 70–80 ms per map slice.
4. glue's dask percentiles read corner blocks: NaN becomes limits 0–1 silently, or values are badly off. Any later percentile change in the style editor or by a callback recomputes them that way.
5. A glue `DerivedComponent` over a `DaskComponent` fails in an Image viewer. This affects the mask in this item, `wp1-dn-per-s`, and `wp5-m3` 'Subtract mean spectrum'. Whole reads of a derived mask materialise the full cube.
6. Unviewed whole-component reads (`data[cid]`, `.data`, `compute_statistic` with no view, Histogram) give a dask array or compute everything.
7. Session save fails for dask arrays (`wp3-file-references` is the fix). Sessions with glue-solar data already fail today.
8. irispy marks memmap raster units as DN although the data are unscaled. SJI memmap zeroes fill and writes into copy-on-write pages (`astropy/io/fits/file.py:90-96`: readonly maps `ACCESS_COPY`).
9. Memory-mapped files stay open: 99 handles for 3602506433. GUI apps on macOS get a soft limit of 256 (`launchctl limit maxfiles`).
10. A map (λ) slice reads the whole window from disk, so cold-cache steps cost a full window read (not measured). RSS and `ru_maxrss` count those clean pages; footprint does not.
11. A `.fits.gz` SJI is decompressed 4–5 times per open (R13). irispy plus our own astropy read adds more passes.
12. If you measure footprint with `proc_pid_rusage`, the full `rusage_info_v2` struct is needed. A truncated ctypes struct corrupted memory and segfaulted in my runs.

## 9. Decisions needed before the done-when can be tested

- **What "below 10 % of eager RSS" measures.** Absolute `ru_maxrss` leaves 0.18 GB (3824262996) and 0.36 GB (4000255147) above the process baseline, and 4000255147's SJI int16 read takes most of that. The alternatives are a delta over the start (as the acceptance probe does) or footprint.
- **When the 10 % peak is taken.** If it includes the quicklook, the Profile's whole-window pass and the map's page-ins push RSS to 1.8–2.1 GB, while footprint stays near +30–40 MB. The pre-restructure text said "before any viewer opens".
- **What "within 1 % of eager 99.5 %" is measured against.** glue's eager limits are unseeded samples, and quantisation rules out 1 % of each limit's value. A testable reference is the exact `nanpercentile` of the eager array, with tolerance at 1 % of the range or one to two 0.25-DN steps.

Measurement scripts and logs are in `/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/lazy/prior/`: `m1_dask_slicing.py`, `m2_from_array_copy.py`, `m3_glue_limits.py`, `m4_glue_paths.py`, `m4b_4000255147.py`, `m5_derived_mask.py`, `m6_irispy_memmap.py`, `m7_eager_vs_memmap_open.py`, `m8_viewer_limits.py`, `m9_raw_sample.py`, with results in `m*.jsonl`. The old plan text is at `/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/old_plan.md`.