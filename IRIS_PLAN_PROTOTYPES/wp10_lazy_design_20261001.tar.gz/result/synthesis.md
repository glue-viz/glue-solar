# Recommended design: wp10-m1-lazy-loading (F034)

**Base:** risk-first (`lazy/incremental/`), because it is the smallest code that already meets memory and equality on all 73 window-files, uses glue's own override point for limits (`glue/core/data.py:1627-1628`) and keeps the mask a glue derived component as the item says. **Grafted:** minimal-memory's size-capped exact limit sample and generated int16 test files; glue-native's own SJI/AIA raw read, probe-gated PV-slice patch and `layer_artist_maker` for the hidden spectrum layer. **Every judge finding is addressed** in §12.

## 1. Data structures

One new module `glue_solar/sources/loaders/lazy.py` (~170 lines; the prototype at `lazy/incremental/tree/glue_solar/sources/loaders/lazy.py` is the starting point, with the changes marked below).

| Kind | Raw source | Value component | Mask | Time / Exposure |
|---|---|---|---|---|
| Raster window, per scan (`.fits`, `.fits.gz`) | irispy `read_files(memmap=True)` → `cube.data`, a `>i2` memmap view, already flipped for V34 (`irispy/io/spectrograph.py:160-162, 252`). For `.gz` astropy holds raw int16 in RAM (2 B/el) | `RawComponent(DaskComponent)` on `LazyData(Data)` | `data.add_component_link(ComponentLink([cid], ComponentID(f"{label} mask", parent=data), using=fill_mask))` (`glue/core/data.py:1112`); `fill_mask` is module-level so WP3 can save it by name (avoids `state.py:1232`) | unchanged 0-byte broadcasts (`loaders/iris.py:164-167, 190-196`) |
| Stack | `RawStack([scan.data …])` over the per-scan views | same | same | Time `(scan, step)` broadcast via `stack_times`; Exposure per scan as today (`iris.py:227`) |
| SJI `.fits` / AIA cutout | own `fits.open(path, memmap=True, do_not_scale_image_data=True)[0].data`; irispy `read_files(memmap=True)` supplies only gWCS, meta, extra coords (its memmap path zeroes fill, `irispy/io/sji.py:239-243`) | same, unit `DN_UNIT["SJI"]`, `meta["scaled"]=True` (irispy's memmap unit is `DN_IRIS_SJI_UNSCALED`, `sji.py:243, 256`) | same | unchanged |
| SJI `.fits.gz` | same call; astropy decompresses to raw int16 in RAM (WP10 note: eager int16 read, no cache file) | same | same | unchanged |
| Anything not int16 (irispy's bundled float32 CI files, BITPIX 32, a future float product) | main's eager branch of `_cube_data`, verbatim | `Component` | uint8 `Component` | unchanged |

Guard (fixes the missing integer guard both judges found):

```python
lazy = scaling is not None and values.dtype.kind == "i" and values.dtype.itemsize == 2
```

int16 only: the 65,536-bin `bincount` can then never raise and never truncates floats. Float files take the eager path, which glue treats with `finite=True` (D12's +Inf rule stays glue's).

`LAZY = True` module switch in `loaders/iris.py` restores main's path exactly (documented in `dev_guide/loader-customization.rst`).

## 2. Scaling, fill, flip, mask

- **Scaling** only in `_Scaled.__getitem__`: `raw[key]` → `astype(float32)`, `*= BSCALE`, `+= BZERO`, astropy's order (`astropy/io/fits/hdu/image.py:845, 858-861`). Only the requested view is scaled; fancy keys work because the memmap accepts them. BSCALE/BZERO per window from the headers (`_window_scaling`, one `fits.open(memmap=True)` of headers; SJI/AIA from `hdu.header`), never hard-coded.
- **Fill (D12, D17):** codes `(m − BZERO)/BSCALE` for `MISSING_VALUES` (`stack_spectrograms.py:14`) kept only when integral: −32768/−32764 for IRIS, −200 for AIA (`missing=(-200,)`, `iris.py:247`). Compared exactly with `np.isin(raw, fill)` on the raw ints, never a threshold (raw −32763…−32701 are data). Dropped: minimal-memory's `BLANK` code (no IRIS/AIA header has one).
- **Flip (D10):** irispy's negative-stride view; glue-solar adds no flip code. Verified equal on all 56 window-files by all three judges.
- **Mask:** derived uint8. Draws through glue's generic FRB path because `RawComponent.__getitem__` takes the n-d integer keys (`fixed_resolution_buffer.py:309` → `component.py:217` → our `__getitem__`); measured equal to eager for map/spectrogram/λ–t/resampled map. Same property makes `wp1-dn-per-s` drawable. Not in `main_components`: tests at `test_importer.py:147, 183, 206` change.

## 3. Chunking

`.data` = `da.from_array(_Scaled, chunks=(32 steps, full plane), name=f"iris-raw-{uuid4().hex}", asarray=False, meta=…)`. The explicit `name` stops dask hashing the file (`dask/array/core.py:3673-3677`); `_Scaled` has no `.copy` so dask does not read it at build (`core.py:3649-3650`). Dask runs only for whole-component reads: `compute_statistic` ≤ 4e7 elements with no view, `compute_histogram`, `RangeSubsetState`, export. Views (every panel, profile, cursor) bypass dask entirely via `__getitem__`, so no block-shape tuning (glue-native's 23 ms λ–t headroom problem does not arise). `RawStack.__getitem__` handles int, slice and all-array keys grouped by scan.

## 4. Colour limits (set once, exact on the acceptance data)

`LazyData.compute_statistic` answers `minimum`/`maximum`/`percentile` calls that have `random_subset`, no `subset_state`, no `axis`, no `view` and target a `RawComponent`; everything else → `super()`. That is exactly the call glue makes for every percentile preset (`state_objects.py:403-422`), the style editor and the Histogram x range (`:566-573`), so `quicklook.py:744` (`percentile = 99.5`) is untouched and re-picking 99.5 % in the style editor stays exact (fixes glue-native's one-off Custom problem).

Sample rule (graft from minimal-memory, replaces risk-first's 128 M-element rule): a `bincount` over the 65,536 raw codes from whole leading planes, fill codes zeroed, numpy-linear percentile. **Every plane while the window's raw size ≤ `SAMPLE_BYTES = 512 MiB`**; above that, evenly spaced planes to that budget. Results: exact (0 % error) on all 17 raster windows of 3824262996 and 4000255147, all 56 of 3400109360 and SJI 1400 (judge-done reproduced on minimal-memory's `limits2.jsonl`; 4000255147 Mg II k at 741 MB is sampled and still exact). First call ≤ 0.6 s warm per window on first Image layer; cached after. This removes the two per-value failures (3824262996 Si IV 1403 lower −8.25 vs −8.0; 4000255147 C II −7.25 vs −7.5) and the [−0.5, 196.0] vs 195.75 inconsistency.

Why not glue-native's "count every value": unbounded first-layer time on the GUI thread (≈18 s for a 20 GB window at 0.68 s/740 MB). Why not a 128 M cap: fails 1 % per value on two acceptance windows.

## 5. Consumers

| Consumer | Behaviour | Code change |
|---|---|---|
| Image panels, SJI, cursor readout, Point spectrum, Collapse | `__getitem__` view; image step 21–27 ms vs main 31–32 (`acc/probe/out_lazy*`) | none |
| Coordinator, Frame-time tool, `link_hpc`, crosshair/pixel-point patches | numpy Time/Exposure, coordinates | none |
| Image/Histogram limits, style editor | `LazyData.compute_statistic` | §4 |
| Quicklook spectrum panel | glue computes whole-cube mean twice on `add_data` while the layer is visible (`profile/state.py:430-436`; R14): 2.79 s lazy. Fix: `@layer_artist_maker("IRIS: hidden spectrum layer")` in `sources/iris.py` returns `ProfileLayerState(layer=data, viewer_state=viewer.state, visible=False)` when `data in getattr(viewer, "hidden_data", ())`; `QuicklookProfileViewer(ProfileViewer)` carries `hidden_data=()`, `_profile` sets it before `add_data` and drops the loop at `quicklook.py:783-786`. Registry is consulted first (`viewers/common/viewer.py:212`) and only the named dataset is hidden | glue-native's registry maker + 5-line viewer subclass; eager-safe (PR0) |
| PV slicer | `pv_slicer.py:205` passes `data[attribute]` (dask) to pvextractor → `AttributeError`. `glue_patches.py` gains `pv_slice_from_path` behind `needs_pv_dask_workaround()` (probe: run `_slice_from_path` on a 3-plane dask `Data` in try/except; 1 ms), same pattern as `needs_pv_slice_workaround` (`glue_patches.py:108-116`). Patch wraps `data` so `__getitem__` returns `np.asarray(data[att])`: whole read, as eager does | glue-native's patch, probe-gated (D2) |
| Subset export to FITS | `values[~mask] = nan` on dask raises `IndexError` (`data_exporters/gridded_fits.py:65-72`). Same probe-gating: `needs_fits_export_dask_workaround()` (export a 2×2 dask Data with a Pixel subset into `tmp_path` in try/except) → patch `export_fits` with `values = np.asarray(data[cid])`. Retire both when glue/glue-qt accept `DaskComponent` | new probe-gated patch (D2) |
| Plain Profile/Histogram of a whole cube, Inequality subsets, derived-mask statistics | dask whole read: ~0.6 s/370 M el, transient +0.9–1.5 GB, same order as eager | none (accepted) |
| Merging datasets | glue builds a plain `Data` (`data_collection.py:353`), limits fall back to glue's corner sample | none (rare; docs note) |

## 6. Sessions, large-data prompt

- Save fails inside `catch_error` (`application_base.py:18-29, 100`) on Quantity meta, exactly as main; dialog, no file, no crash. After WP3 fixes meta, File→Open data save by load log (`state.py:1096-1099`); browser data hit `GlueSerializeError` until `wp3-file-references` adds `RawComponent.__gluestate__` (path, ext, flip, scaling, fill codes). Docs note now.
- "Add large data set?" untouched (D18): `viewer.py:200`, Profile 1e8 / Histogram 2e7; quicklook keeps `large_data_size=None` (`quicklook.py:781`).

## 7. Load paths

- **File→Open / `--startup`:** `iris_data` → `read_files(path, memmap=LAZY)`; rasters → `_raster_collection_data(..., scaling=_window_scaling(path))`; SJI/AIA → `_image_cube_data` with the own raw read. `.fits.gz` rasters cost one extra decompression for `_window_scaling` (only the remote test asset; local flows extract first, `scan.py:29-52`).
- **Browser:** `raster_data` per ticked window as today; stacks via `RawStack`. `image_data` as above.
- **Open files:** `allow_open_files()` (soft limit → `min(hard, 10240)`) called **only inside the lazy loaders**, not `setup()` (fixes glue-native's process-wide raise). Needed: 3602506433 ×7 windows holds 693 fds against macOS's GUI 256.
- **Stacks:** `stack_wcs`/`stack_times` split out of `stack_spectrogram_sequence` (`:66-75, 53-62`), which stays for the eager fallback. Replace the `SimpleNamespace` stand-in: split `_cube_data` into `_cube_data(cube, …)` and `_dataset(wcs, meta, unit, values, label, …)`; the stack calls the latter (~10 lines, also drops the `missing=()` special case and the unused `NDCube(mask=isnan)` at `stack_spectrograms.py:81`).

## 8. PR sequence (stacked drafts on `main`)

**PR0 — hidden spectrum layer** (eager-safe, independent): `QuicklookProfileViewer`, the registry maker, `_profile` change, one test. Done when: `quicklook()` runs no `compute_statistic` with `axis` and `subset_state=None`; M0 `quicklook()` ≤ previous median (removes R14's 0.37–0.40 s).

**PR1 — wp10-m1-lazy-loading** (one PR = one item; commits in this order so each is reviewable):
1. `lazy.py` + unit tests on generated int16 files;
2. rasters per scan (`_cube_data` guard, `_window_scaling`, `iris_data`, `raster_data`, `allow_open_files`);
3. stacks (`RawStack`, `stack_wcs`, `stack_times`, `_dataset` split);
4. SJI `.fits`/`.fits.gz` and AIA (own raw read);
5. probe-gated PV-slice and FITS-export patches + register rows;
6. `dask[array]>=2024.7.0` in `pyproject.toml` (irispy's floor; tested in `iris-plan-dask-floor`), docs (`loading-iris-level-2-raster-and-sji-data.rst:43-44, 52, 63-65, 101-121`, `loader-customization.rst:16-33`), changelog.

Done when: lazy File→Open of all raster windows of 3824262996 and 4000255147 peaks < 10 % of eager RSS (both as Δ over post-import baseline and absolute `ru_maxrss`, no viewer: measured 0.1–0.3 % / 5.4–7.0 %); every value, NaN, mask, FRB and Time/Exposure equals eager on both files, all 56 window-files and 7 stacks of 3400109360, SJI 1400, deconvolved 2796 and AIA 171; 99.5 % limits of every Image layer equal `np.nanpercentile(eager_finite, [0.25, 99.75])` within 1 % of each value (exact on acceptance data); all M0 budgets hold, medians and maxima, 6 rounds; 154 tests + new ones pass.

## 9. Tests (glue side only; bundled files, generated copies in `tmp_path`, LM-SAL/irispy-data remote)

Bundled irispy rasters are float32, so they only exercise the eager branch; the int16 path needs generated copies (BSCALE 0.25, BZERO 7992, planted −32768/−32764, negatives, a copy with STEPS_AV < −0.01) and the remote cutouts.

New `tests/test_lazy.py`:
1. Views (step, slit, λ, scalar, fancy, bool, negative-step) equal astropy's scaled `getdata` with fill→NaN; derived mask is uint8 `isnan`; glue's FRB for data and mask equals the oracle.
2. Float32 copy → `Component`, not `RawComponent`; int16 copy → `RawComponent` (the guard).
3. Limits: `compute_statistic` percentile == `np.nanpercentile` exactly; Image layer at 99.5 shows them; with `SAMPLE_BYTES` patched to 2 planes the error ≤ 1 % of value on the generated file; Histogram x range finite; `positive=True` path.
4. `.fits.gz` int16 copy loads lazily with equal values (fixes the untested path in minimal-memory).
5. Stack equals per-scan loads (values, mask, FRBs with cross-scan fancy keys, Time, Exposure).
6. `allow_open_files` raises a 256 soft limit, never lowers.
7. Probes: `needs_pv_dask_workaround()`/`needs_fits_export_dask_workaround()` true on glue-qt 0.4.2 / glue 1.27.0, false against the patched functions; PV slice and Point export of lazy data succeed.
8. `save_session` on lazy data reports an error, writes no file, does not raise.
9. `LAZY=False` gives main's layout.
10. Remote: 3400109360 cutout lazy == eager (D10; existing `test_negative_step_raster_keeps_irispys_orientation` stays), 4000005156 Si IV `.fits.gz`, SJI 1400 f050 `.fits.gz`, AIA tarball (−200 only). Drop any assertion on raw strides (irispy's layout).

Adapted: `test_importer.py:147, 183, 206` (mask not in `main_components`), `:258` (stack keyword), `test_plugin.py:328` (`sji[att, 0]`), `:340` (AIA "no NaN"). `test_quicklook.py`: no whole-cube `compute_statistic` during `quicklook()`.

**Manual probe** `IRIS_PLAN_PROTOTYPES/wp10_lazy_probe/` (archive from `incremental/`: `open_rss.py`, `equal.py`, `stack_equal.py`, `limits_final.py`, `image_lazy.py`, `fd_limit.py`; from `judge-done/digest.py`): modes `open` (psutil 1 ms + `ru_maxrss` + footprint, lazy vs eager, no viewer), `equal`, `limits`, `fd`, then the M0 acceptance probe `time | memory | crash` with `TREE=<branch>`, 6 rounds, plus one cold-cache map step per observation (`msync` eviction from `fits/bench.py`). Results to Current state.

## 10. Risks and mitigations

- **SIGBUS on a truncated/unmounted file** (memmap): extraction never overwrites (`scan.py:45-52`); `LAZY=False` escape; docs. Upgrade path: swap `_Scaled.raw` for minimal-memory's `FileWindow` plane reader (no other code changes) if it bites.
- **RSS grows while viewing**: a map touches every page (+490–789 MB on Mg II k), footprint stays small; the done-when is measured at open. Cold first map 0.3–0.8 s on 470–741 MB windows. For > RAM files `wp10-m3-sit-stare-chunks`.
- **Sampled limits above 512 MiB raw** could miss 1 % per value on clumpy windows: the probe reports both metrics; per-value exactness is only claimed for windows ≤ 512 MiB.
- **First Image layer blocks ≤ 0.6 s warm** per window (cold: a 512 MiB read): within the 3 s `quicklook()` budget; move to `wp10-nonblocking-load` Worker later if needed.
- **`.fits.gz` SJI** decompressed twice (irispy + ours): +0.6 s, +0.41 GB peak; 10.8 % absolute if the SJI counts as a "window" of 4000255147.
- **Whole-array consumers** (value subsets, PV, export, derived-mask stats) transiently hold float32: never more than eager keeps.
- **Browser stacks re-open every file per window** (7×99): follow-up, one `read_files` per tick set.
- **Windows**: no `resource` module; `allow_open_files` is a no-op; untested.
- **dask floor 2024.7** untested: only `from_array(name=, meta=, asarray=False)` used; test in a floor env before merge.

## 11. Decisions that need the user

1. **"Below 10 % of eager RSS"**: (a) Δ peak over post-import baseline, no viewer; (b) absolute `ru_maxrss`. Both pass for rasters. **Recommend (a), report (b).** Confirm "all windows" means raster windows (SJI `.gz` in RAM gives 10.8 % absolute).
2. **"Within 1 % of eager 99.5 %"**: reference = exact `nanpercentile([0.25, 99.75])` of eager finite values (glue's own draw varies 2–82 %). Tolerance per value with `SAMPLE_BYTES=512 MiB` (exact on acceptance data; ≤ 0.6 s) vs 128 MiB (≤ 0.66 % of value, ≤ 0.18 s). **Recommend 512 MiB.**
3. **Memmap (irispy's view, fewer lines, SIGBUS/RSS-while-viewing) vs plane reads (own reader, bounded RSS, faster cold, 2–6× slower warm).** **Recommend memmap now**, `_Scaled.raw` as the swap point.
4. **`.fits.gz` SJIs: int16 in RAM (plan note) vs gunzip cache file** (disk 97 % full, temp files leaked in a prototype). **Recommend RAM.**
5. **Mask as glue derived component** (leaves `main_components`; tests/docs change). **Recommend yes**, per item text and D4.
6. **PR0 separate or folded into PR1.** **Recommend separate**: eager gains R14's fix regardless.
7. **One PR for the item vs three items** (rasters / SJI+AIA / stacks). **Recommend one PR, ordered commits**; all three parts are prototyped and measured.
8. **Raise the open-file soft limit** inside the lazy loaders to 10240. **Recommend yes.**

## 12. Judge findings → fixes

| Finding | Fix |
|---|---|
| risk-first: PV slicer breaks, export regression left upstream | probe-gated patches in `glue_patches.py` (§5) |
| risk-first: int guard described but absent; floats truncated in `bincount` | int16-only guard in `_cube_data` (§1); test 2 |
| risk-first: 0.6 % only as range share; two per-value failures; 196.0 vs 195.75 | 512 MiB cap, exact on acceptance data (§4) |
| risk-first: PR1 lacks SJI/stacks; text vs prototype on stacks | all in PR1, ordered commits (§8) |
| risk-first: cold/RSS-while-viewing unmeasured | probe adds cold map step; risk recorded (§9, §10) |
| risk-first: `get_data_layer_artist` override hides later datasets; not a registry | registry maker keyed on `viewer.hidden_data` (§5) |
| risk-first: raw-stride test tests irispy | dropped (§9) |
| risk-first: `SimpleNamespace`, stack Time layout | `_dataset` split; Time `(scan, step)` broadcast kept, equality tested (§7, §9) |
| glue-native: Custom one-off limits; `setup()` raises fd limit; mask not derived; per-block scaling; every-value count unbounded | `compute_statistic` override; fd raise in loaders; derived mask; view-first `__getitem__`; capped sample |
| minimal-memory: `.gz` rasters fall back eagerly; `assert` fallback; AIA contradiction; two SJI paths; own byte reader | `do_not_scale_image_data` via irispy's memmap; no assert; AIA lazy via own read; one SJI path; irispy's memmap instead of a reader |
| shared: `_window_scaling` decompresses `.gz` rasters | accepted (test asset only); noted in §7 |

Prototype files: `/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/lazy/incremental/tree/glue_solar/sources/loaders/lazy.py` and `prototype.diff` (base); grafts from `lazy/design-glue/lazy_design.diff` (SJI raw read, `pv_slice_from_path`, registry maker) and `lazy/design-robust/rawsource.py:18` (`SAMPLE_BYTES`); verification scripts in `lazy/judge-done/digest.py`.