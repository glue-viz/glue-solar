"""Exact raw-code histogram of the 4000255147 Mg II k window (1600x417x555 int16): serial vs threads; warm cache."""
import glob, time
from concurrent.futures import ThreadPoolExecutor
import numpy as np
from astropy.io import fits
f = sorted(glob.glob("/Users/nabil/DATA/IRIS/*4000255147_raster/*.fits"))[0]
h = fits.open(f, memmap=True, do_not_scale_image_data=True)
raw = h[8].data
print(h[0].header["TDESC8"], raw.shape, raw.dtype)
np.asarray(raw).sum()  # warm the page cache

def counts(planes):
    return np.bincount(planes.ravel().astype(np.int32) + 32768, minlength=65536)

def counts2(planes):
    return np.bincount(planes.astype("<i2").view("<u2").ravel() ^ np.uint16(0x8000), minlength=65536)

for name, fn in (("int32+offset", counts), ("u16 xor", counts2)):
    t = time.perf_counter(); c1 = sum(fn(raw[i:i + 32]) for i in range(0, raw.shape[0], 32)); serial = time.perf_counter() - t
    for workers in (4, 8):
        with ThreadPoolExecutor(workers) as pool:
            t = time.perf_counter(); c2 = sum(pool.map(fn, (raw[i:i + 32] for i in range(0, raw.shape[0], 32)))); par = time.perf_counter() - t
        assert np.array_equal(c1, c2)
        print(f"{name}: serial {serial:.3f} s, {workers} threads {par:.3f} s, {raw.size / 1e6:.0f} M elements")
