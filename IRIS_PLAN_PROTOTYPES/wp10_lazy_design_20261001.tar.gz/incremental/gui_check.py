"""glue's own viewers on one lazy window: Image viewer percentile limits (99.5 % and 95 %), the derived mask as an
image attribute, Histogram x range, and Save session. python gui_check.py OBSID WINDOW. Times by perf_counter."""
import glob, json, os, sys, tempfile, time
import numpy as np
from glue_qt.app import GlueApplication
from glue_qt.utils import process_events
from glue_qt.viewers.image import ImageViewer
from glue_qt.viewers.histogram import HistogramViewer
from glue_solar.sources.loaders import iris as L

obsid, window = sys.argv[1], sys.argv[2]
f = sorted(glob.glob(f"/Users/nabil/DATA/IRIS/*{obsid}_raster/*.fits"))[0]
[d] = [x for x in L.iris_data(f) if x.label.startswith(window.replace(" ", "_") + "-")]
L.LAZY = False
[e] = L.raster_data([f], [window])
ev = e[e.main_components[0]]
out = {"obsid": obsid, "window": window, "shape": d.shape}
app = GlueApplication()
errors = []
app.report_error = lambda message, detail: errors.append(message.splitlines()[0] + " | " + message.splitlines()[-1][:120])
app.data_collection.append(d)
t = time.perf_counter()
v = app.new_data_viewer(ImageViewer, data=d)
layer = v.state.layers[0]
layer.percentile = 99.5
process_events()
out["image_open_s"] = round(time.perf_counter() - t, 3)
out["v_99.5"] = [layer.v_min, layer.v_max]
out["exact_99.5"] = [float(x) for x in np.nanpercentile(ev, [0.25, 99.75])]
layer.percentile = 95
out["v_95"] = [layer.v_min, layer.v_max]
out["exact_95"] = [float(x) for x in np.nanpercentile(ev, [2.5, 97.5])]
layer.percentile = 100
out["v_minmax"] = [layer.v_min, layer.v_max]
out["exact_minmax"] = [float(np.nanmin(ev)), float(np.nanmax(ev))]
t = time.perf_counter()
layer.attribute = d.derived_components[0]  # the mask
process_events()
v.figure.canvas.draw()
out["mask_attribute_s"] = round(time.perf_counter() - t, 3)
out["mask_limits"] = [layer.v_min, layer.v_max]
out["mask_image_shape"] = list(np.shape(v.axes.images[0].get_array())) if v.axes.images else None
t = time.perf_counter()
h = app.new_data_viewer(HistogramViewer)
h.large_data_size = None
h.add_data(d)
process_events()
out["histogram_s"] = round(time.perf_counter() - t, 3)
out["histogram_x"] = [h.state.hist_x_min, h.state.hist_x_max]
path = os.path.join(tempfile.mkdtemp(), "s.glu")
app.save_session(path)
out["save_session_errors"] = errors[:]
out["session_file_exists"] = os.path.exists(path)
out["errors"] = errors
print(json.dumps(out, default=float), flush=True)
os._exit(0)
