"""Browser per-scan loads of 3602506433 (99 files) under the macOS GUI soft limit of 256 open files."""
import glob, os, resource, sys, time, gc
resource.setrlimit(resource.RLIMIT_NOFILE, (256, resource.getrlimit(resource.RLIMIT_NOFILE)[1]))
import psutil
if len(sys.argv) > 2:  # what a loader would do before lazy reads: soft limit up to the hard one
    soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
    for want in (hard, 1 << 20, 1 << 16, 10240):
        try:
            resource.setrlimit(resource.RLIMIT_NOFILE, (min(want, hard), hard)); break
        except (ValueError, OSError) as e:
            print("setrlimit", want, "refused:", e)
    print("soft limit now", resource.getrlimit(resource.RLIMIT_NOFILE)[0])
from glue_solar.sources.loaders import iris as L
from glue_solar.sources.loaders.scan import scan_directory
L.LAZY = sys.argv[1] == "lazy"
files = sorted(glob.glob("/Users/nabil/DATA/IRIS/*3602506433_raster/*.fits"))
[obs] = scan_directory(os.path.dirname(files[0]), recursive=False)
print("windows", obs.windows)
kept = []
for w in obs.windows:
    t = time.perf_counter()
    try:
        kept += L.load_entry(obs, "raster", w)
        print(w, "ok", round(time.perf_counter() - t, 2), "s; open files", len(psutil.Process().open_files()), flush=True)
    except Exception as e:
        print(w, "FAILS", type(e).__name__, str(e)[:150], flush=True); break
gc.collect(); print("after gc open files", len(psutil.Process().open_files()))
