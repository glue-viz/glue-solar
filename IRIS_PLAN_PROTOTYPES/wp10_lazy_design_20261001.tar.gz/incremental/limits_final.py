"""The prototype's limits (glue's '99.5 %' through LazyData.compute_statistic) on every window of 3824262996 and
4000255147, every window-file of 3400109360 and its 7 stacks, against exact percentiles of every finite eager
value (np.nanpercentile). Error in % of the exact range; time of the first call (the sample) by perf_counter."""
import glob, json, sys, time
import numpy as np
from glue_solar.sources.loaders import iris as L


def check(lazy, eager, tag):
    cid = lazy.main_components[0]
    t = time.perf_counter()
    lims = [float(lazy.compute_statistic("percentile", cid, percentile=p, random_subset=10000)) for p in (0.25, 99.75)]
    dt = time.perf_counter() - t
    exact = [float(x) for x in np.nanpercentile(eager[eager.main_components[0]], [0.25, 99.75])]
    err = max(abs(a - b) for a, b in zip(lims, exact)) / (exact[1] - exact[0]) * 100
    print(json.dumps({"tag": tag, "label": lazy.label[:40], "elements_M": round(lazy.size / 1e6), "limits": lims, "exact": exact,
                      "err_pct_range": round(err, 3), "first_call_s": round(dt, 3)}), flush=True)


for obs in ("3824262996", "4000255147", "3400109360"):
    files = sorted(glob.glob(f"/Users/nabil/DATA/IRIS/*{obs}_raster/*.fits"))
    for f in files:
        L.LAZY = True; lazy = L.iris_data(f)
        L.LAZY = False; eager = L.iris_data(f)
        for a, b in zip(lazy, eager):
            check(a, b, obs)
        del eager
    if obs == "3400109360":
        from glue_solar.sources.loaders.scan import scan_directory
        import os
        [o] = scan_directory(os.path.dirname(files[0]), recursive=False)
        for w in o.windows:
            L.LAZY = True; [a] = L.raster_data(files, [w], stack=True)
            L.LAZY = False; [b] = L.raster_data(files, [w], stack=True)
            check(a, b, obs + " stack")
