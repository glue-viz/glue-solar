"""Lazy vs eager stacks (browser, stack ticked) of every scan of OBSID: values and NaN per scan, the derived mask, glue
FRBs of the quicklook's stack panels (map, spectrogram, λ–scan) for values and mask, Time and Exposure time, limits.
python stack_equal.py OBSID WINDOW..."""
import gc, glob, json, sys, time
import numpy as np, psutil
from glue_solar.sources.loaders import iris as L

obsid, windows = sys.argv[1], sys.argv[2:]
files = sorted(glob.glob(f"/Users/nabil/DATA/IRIS/*{obsid}_raster/*.fits"))
for w in windows:
    L.LAZY = True
    rss0 = psutil.Process().memory_info().rss
    t = time.perf_counter(); [d] = L.raster_data(files, [w], stack=True); t_lazy = time.perf_counter() - t
    rss_lazy = psutil.Process().memory_info().rss - rss0
    L.LAZY = False
    t = time.perf_counter(); [e] = L.raster_data(files, [w], stack=True); t_eager = time.perf_counter() - t
    cid, mcid = d.main_components[0], d.derived_components[0]
    ecid, emcid = e.main_components[0], e.main_components[1]
    ns, n, ny, nl = d.shape
    ok_v = all(np.array_equal(d[cid, (i,)], e[ecid, (i,)], equal_nan=True) for i in range(ns))
    ok_m = all(np.array_equal(d[mcid, (i,)], e[emcid, (i,)]) for i in range(ns))
    s, y, k = n // 2, ny // 2, nl // 2
    panels = {"map": [ns // 2, (0, n - 1, n), (0, ny - 1, ny), k], "spectrogram": [ns // 2, s, (0, ny - 1, ny), (0, nl - 1, nl)],
              "lambda_scan": [(0, ns - 1, ns), s, y, (0, nl - 1, nl)], "map_resampled": [ns - 1, (0, n - 1, 41), (0, ny - 1, 77), k]}
    frb = {}
    for name, b in panels.items():
        t = time.perf_counter()
        v, m = d.compute_fixed_resolution_buffer(b, target_cid=cid), d.compute_fixed_resolution_buffer(b, target_cid=mcid)
        dt = (time.perf_counter() - t) * 1e3
        frb[name] = [bool(np.array_equal(v, e.compute_fixed_resolution_buffer(b, target_cid=ecid), equal_nan=True)
                          and np.array_equal(m, e.compute_fixed_resolution_buffer(b, target_cid=emcid))), round(dt, 1)]
    times_ok = bool(np.array_equal(d["Time"][:, :, 0, 0], e["Time"][:, :, 0, 0]) and np.array_equal(d["Exposure time"][:, :, 0, 0], e["Exposure time"][:, :, 0, 0]))
    ev = e[ecid]
    lims = [float(d.compute_statistic("percentile", cid, percentile=p, random_subset=10000)) for p in (0.25, 99.75)]
    exact = [float(x) for x in np.nanpercentile(ev, [0.25, 99.75])]
    print(json.dumps({"obsid": obsid, "window": w, "shape": d.shape, "lazy_s": round(t_lazy, 2), "eager_s": round(t_eager, 2),
                      "lazy_rss_MB": round(rss_lazy / 1e6), "values": ok_v, "mask": ok_m, "frb": frb, "time_exposure": times_ok,
                      "limits": lims, "exact": exact, "err_pct_range": [round(100 * abs(a - b) / (exact[1] - exact[0]), 2) for a, b in zip(lims, exact)]}), flush=True)
    del d, e, ev; gc.collect()
