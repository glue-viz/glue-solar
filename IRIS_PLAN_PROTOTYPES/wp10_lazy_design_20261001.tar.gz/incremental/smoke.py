import glob, time
import numpy as np
from glue_solar.sources.loaders import iris
f = sorted(glob.glob("/Users/nabil/DATA/IRIS/*3400109360_raster/*.fits"))[0]
t = time.perf_counter(); lazy = iris.iris_data(f); print("lazy", time.perf_counter() - t)
iris.LAZY = False
t = time.perf_counter(); eager = iris.iris_data(f); print("eager", time.perf_counter() - t)
for l, e in zip(lazy, eager):
    assert l.label == e.label
    cl, ce = l.main_components[0], e.main_components[0]
    print(l.label, type(l.get_component(cl)).__name__, l.shape, [c.label for c in l.main_components], [c.label for c in l.derived_components][:2])
    lv, ev = l[cl, (slice(None),) * 3], e[ce]
    np.testing.assert_array_equal(lv, ev)
    lm, em = l[l.derived_components[-1], (slice(None),) * 3], e[e.main_components[1]]
    assert lm.dtype == np.uint8; np.testing.assert_array_equal(lm, em)
    full = np.asarray(l[cl]); np.testing.assert_array_equal(full, ev)
    m = np.asarray(l[l.derived_components[-1]]); np.testing.assert_array_equal(m, em)
    print("  limits", [l.compute_statistic("percentile", cl, percentile=p, random_subset=10000) for p in (0.25, 99.75)],
          "exact", np.nanpercentile(ev, [0.25, 99.75]))
print("ok")
