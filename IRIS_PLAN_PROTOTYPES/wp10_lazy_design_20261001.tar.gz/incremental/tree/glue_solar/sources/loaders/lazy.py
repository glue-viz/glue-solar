"""
IRIS data held as the file's raw integers and scaled per read, with the missing-data codes as NaN.
"""

from itertools import islice
from uuid import uuid4

import dask.array as da
import numpy as np
from glue.core.component import DaskComponent
from glue.core.data import Data

__all__ = ["LazyData", "RawComponent", "RawStack", "allow_open_files", "fill_mask"]

# Colour limits come from whole planes along the leading (step or frame) axis, evenly spaced, at least
# this many samples: every plane of a smaller window
SAMPLE_SIZE = 128_000_000
# Steps per dask chunk, for the reads glue makes of a whole component
CHUNK_STEPS = 32


def allow_open_files(wanted=10240):
    """
    Raise this process's soft limit on open files to ``wanted`` (never above the hard limit, never lower).

    Every memory-mapped file stays open: one per raster file and read, so a 99-scan observation
    opened window by window passes the 256 that macOS gives GUI apps by the third window.
    """
    try:
        import resource
    except ImportError:  # Windows
        return
    soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
    if soft != resource.RLIM_INFINITY and soft < wanted:
        resource.setrlimit(resource.RLIMIT_NOFILE, (wanted if hard == resource.RLIM_INFINITY else min(wanted, hard), hard))


class _Scaled:
    """
    What dask reads from: ``raw[key]`` as float32 ``raw * bscale + bzero``, as astropy scales it,
    with the ``fill`` codes as NaN. No ``copy`` method, so dask 2026.8 does not copy the whole file.
    """

    def __init__(self, raw, bscale, bzero, fill):
        self.raw = raw
        self.shape, self.ndim, self.dtype = raw.shape, raw.ndim, np.dtype(np.float32)
        self.bscale, self.bzero, self.fill = np.float32(bscale), np.float32(bzero), np.asarray(fill, raw.dtype)

    def __getitem__(self, key):
        raw = np.asarray(self.raw[key])
        values = raw.astype(np.float32)
        values *= self.bscale
        values += self.bzero
        values[np.isin(raw, self.fill)] = np.nan
        return values


class RawComponent(DaskComponent):
    """
    A glue component over the raw integers of an IRIS file: a memory map, or an array in memory.

    A read with a view (every image slice, profile and cursor readout) slices the raw array and
    scales only that slice, fancy indices included; a read of the whole component goes through dask.
    """

    def __init__(self, raw, bscale, bzero, missing, units=None):
        fill = [(value - bzero) / bscale for value in missing]
        self._source = _Scaled(raw, bscale, bzero, [int(code) for code in fill if float(code).is_integer()])
        self._counts = None
        values = da.from_array(
            self._source,
            chunks=(CHUNK_STEPS,) + raw.shape[1:],
            name=f"iris-raw-{uuid4().hex}",  # a name, so dask does not hash the file
            meta=np.empty((0,) * raw.ndim, np.float32),
            asarray=False,
        )
        super().__init__(values, units=units)

    def __getitem__(self, key):
        return self._source[key]

    def _sample(self):
        """Counts of each raw code over evenly spaced planes, the fill codes left out."""
        if self._counts is None:
            raw, counts = self._source.raw, np.zeros(65536, np.int64)
            for index in islice(np.ndindex(raw.shape[:-2]), 0, None, -(-raw.size // SAMPLE_SIZE)):
                counts += np.bincount(np.asarray(raw[index]).ravel().astype(np.int32) + 32768, minlength=65536)
            counts[self._source.fill.astype(np.int32) + 32768] = 0
            self._counts = counts
        return self._counts

    def sampled_statistic(self, statistic, percentile=None, positive=False):
        """'minimum', 'maximum' or 'percentile' of the sample, as numpy's linear percentile computes it."""
        counts = self._sample()
        values = (np.arange(65536) - 32768) * float(self._source.bscale) + float(self._source.bzero)
        if positive:
            counts = np.where(values > 0, counts, 0)
        cumulative = np.cumsum(counts)
        total = cumulative[-1]
        if total == 0:
            return np.nan
        position = {"minimum": 0.0, "maximum": total - 1.0}.get(statistic)
        if position is None:
            position = percentile / 100 * (total - 1)
        low, high = (np.searchsorted(cumulative, index, side="right") for index in (np.floor(position), np.ceil(position)))
        return values[low] + (position - np.floor(position)) * (values[high] - values[low])


class RawStack:
    """
    Equal-shaped raw arrays, one per scan, as one array with a leading scan axis; a read touches only
    the scans it selects.
    """

    def __init__(self, scans):
        self.scans = scans
        self.shape = (len(scans), *scans[0].shape)
        self.ndim, self.dtype, self.size = len(self.shape), scans[0].dtype, int(np.prod(self.shape))

    def __getitem__(self, key):
        key = key if isinstance(key, tuple) else (key,)
        first, rest = key[0], key[1:]
        if isinstance(first, (int, np.integer)):
            return np.asarray(self.scans[first][rest])
        if isinstance(first, slice):
            picked = range(*first.indices(len(self.scans)))
            return np.stack([np.asarray(self.scans[i][rest]) for i in picked]) if picked else np.empty((0, *self.scans[0][rest].shape), self.dtype)
        # one index array per axis, as glue's fixed-resolution buffer asks
        arrays = np.broadcast_arrays(*key)
        values = np.empty(arrays[0].shape, self.dtype)
        for scan in np.unique(arrays[0]):
            where = arrays[0] == scan
            values[where] = self.scans[scan][tuple(array[where] for array in arrays[1:])]
        return values


class LazyData(Data):
    """
    A glue dataset whose `RawComponent`s answer glue's sampled statistics (colour and histogram
    limits) from their own sample of the raw integers.

    glue samples a dask array at the corners of 10 random chunks (`glue.utils.array.random_views_for_dask_array`),
    which on IRIS windows is mostly fill: limits of 0 to 1.
    """

    def compute_statistic(self, statistic, cid, subset_state=None, axis=None, finite=True, positive=False,
                          percentile=None, view=None, random_subset=None, **kwargs):
        if random_subset and subset_state is None and axis is None and view is None and statistic in ("minimum", "maximum", "percentile"):
            component = self.get_component(cid)
            if isinstance(component, RawComponent):
                return component.sampled_statistic(statistic, percentile, positive)
        return super().compute_statistic(statistic, cid, subset_state=subset_state, axis=axis, finite=finite,
                                          positive=positive, percentile=percentile, view=view,
                                          random_subset=random_subset, **kwargs)


def fill_mask(values):
    """1 where ``values`` is NaN (missing), else 0, one byte per sample."""
    return np.isnan(values).view(np.uint8)
