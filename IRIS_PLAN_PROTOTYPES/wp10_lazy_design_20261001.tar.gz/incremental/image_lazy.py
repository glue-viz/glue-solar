"""PR2 sketch: an SJI/AIA cube's metadata from irispy read_files(memmap=True), its raw integers from our own astropy
read (irispy's memory-mapped reader writes 0 over the fill), scaled per read by RawComponent.
python image_lazy.py <lazy|eager|check> PATH. Peak RSS: psutil sampled every 1 ms and ru_maxrss; one case per process."""
import gc, json, sys, threading, time
sys.path.insert(0, "/private/tmp/claude-501/-Users-nabil-Git-glue-solar/9355b8dc-4df0-4d22-a711-8c51c1b022d0/scratchpad/lazy/fits")
import numpy as np, psutil
from astropy.io import fits
from irispy.io import read_files
from irispy.utils.constants import DN_UNIT
from glue.core.component_id import ComponentID
from glue.core.component_link import ComponentLink
from glue_solar.sources.loaders import iris as L
from glue_solar.sources.loaders.lazy import LazyData, RawComponent, fill_mask
from mem import usage

mode, path = sys.argv[1], sys.argv[2]
missing = (-200,) if "aia" in path.lower() or "SDO" in path else (-200, -199)


def lazy_image(path):
    cube = read_files(path, memmap=True, uncertainty=False)  # metadata, WCS and extra coordinates
    with fits.open(path, memmap=True, do_not_scale_image_data=True) as hdulist:
        raw, header = hdulist[0].data, hdulist[0].header
        bscale, bzero = header.get("BSCALE", 1), header.get("BZERO", 0)
    d = LazyData(label="img")
    d.coords = L._GlueWCS(cube.wcs.low_level_wcs)
    d.meta = cube.meta
    cid = d.add_component(RawComponent(raw, bscale, bzero, missing, units=str(DN_UNIT["SJI"])), "img")
    d.add_component_link(ComponentLink([cid], ComponentID("img mask", parent=d), using=fill_mask))
    d.add_component(L._per_frame(L._frame_times(cube), cube.shape), "Time")
    return d


proc = psutil.Process(); gc.collect(); u0 = usage(); rss0 = proc.memory_info().rss
peak = [rss0]; stop = threading.Event()
def sample():
    while not stop.is_set():
        peak[0] = max(peak[0], proc.memory_info().rss); time.sleep(0.001)
th = threading.Thread(target=sample, daemon=True); th.start()
t = time.perf_counter()
d = L.image_data(path) if mode == "eager" else lazy_image(path)
dt = time.perf_counter() - t
stop.set(); th.join(); gc.collect(); u1 = usage()
res = {"mode": mode, "file": path.split("/")[-1][-40:], "shape": d.shape, "load_s": round(dt, 2),
       "peak_rss_delta_MB": round((max(peak[0], u1["maxrss"]) - rss0) / 1e6), "kept_rss_delta_MB": round((u1["rss"] - rss0) / 1e6),
       "kept_footprint_delta_MB": round((u1["footprint"] - u0["footprint"]) / 1e6)}
if mode == "check":
    L.LAZY = False
    e = L.image_data(path)
    ev = e[e.main_components[0]]
    lv = d[d.main_components[0], (slice(None),) * 3]
    res["equal_values"] = bool(np.array_equal(lv, ev, equal_nan=True))
    res["equal_mask"] = bool(np.array_equal(d[d.derived_components[0], (slice(None),) * 3], e[e.main_components[1]]))
    res["limits"] = [float(d.compute_statistic("percentile", d.main_components[0], percentile=p, random_subset=10000)) for p in (0.25, 99.75)]
    res["exact"] = [float(x) for x in np.nanpercentile(ev, [0.25, 99.75])]
    res["fill_minus199"] = int((np.asarray(d.get_component(d.main_components[0])._source.raw) == -32764).sum())
print(json.dumps(res), flush=True)
