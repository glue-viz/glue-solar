"""Exact 0.25/99.75 percentiles (glue's '99.5 %') of every raster window vs evenly spaced whole-plane samples.

Exact: bincount of every raw code in the window (fill codes dropped), numpy 'linear' percentile.
Sample: raw[::k] with k = ceil(elements / budget), i.e. at least `budget` elements, all planes when smaller.
Errors: in DN, in 0.25-DN steps and in % of the exact range. Times by perf_counter, warm cache.
"""
import glob, json, math, sys, time
import numpy as np
from astropy.io import fits

FILL = np.array([-32768, -32764])
OBS = {"3824262996": "*3824262996_raster/*.fits", "4000255147": "*4000255147_raster/*.fits", "3400109360": "*3400109360_raster/*.fits"}


def counts_of(planes):
    c = np.zeros(65536, np.int64)
    for p in planes:
        c += np.bincount(p.ravel().astype(np.int32) + 32768, minlength=65536)
    c[FILL + 32768] = 0
    return c


def pct(c, q, b, z):
    cum = np.cumsum(c); n = cum[-1]; pos = q / 100 * (n - 1)
    lo, hi = (np.searchsorted(cum, i, side="right") for i in (math.floor(pos), math.ceil(pos)))
    v = lambda code: (code - 32768) * b + z
    return v(lo) + (pos - math.floor(pos)) * (v(hi) - v(lo))


for obs in sys.argv[1:]:
    for f in sorted(glob.glob(f"/Users/nabil/DATA/IRIS/{OBS[obs]}")):
        with fits.open(f, memmap=True, do_not_scale_image_data=True) as h:
            for ext in range(1, len(h) - 2):
                hdu = h[ext]; raw = hdu.data; b, z = hdu.header["BSCALE"], hdu.header["BZERO"]
                t = time.perf_counter(); full = counts_of(raw); t_exact = time.perf_counter() - t
                exact = [pct(full, q, b, z) for q in (0.25, 99.75)]
                rng = exact[1] - exact[0]
                row = {"obs": obs, "file": f[-11:-5], "window": h[0].header[f"TDESC{ext}"], "shape": raw.shape,
                       "exact": exact, "exact_s": round(t_exact, 3)}
                for budget in (8e6, 16e6, 32e6, 64e6):
                    k = max(1, math.ceil(raw.size / budget))
                    t = time.perf_counter(); c = counts_of(raw[::k]); dt = time.perf_counter() - t
                    lims = [pct(c, q, b, z) for q in (0.25, 99.75)]
                    err = [abs(lims[i] - exact[i]) for i in (0, 1)]
                    row[f"b{int(budget / 1e6)}M"] = {"k": k, "planes": len(range(0, raw.shape[0], k)), "s": round(dt, 3),
                                                   "err_dn": [round(e, 3) for e in err], "err_steps": [round(e / b, 2) for e in err],
                                                   "err_pct_range": [round(100 * e / rng, 2) for e in err]}
                print(json.dumps(row), flush=True)
