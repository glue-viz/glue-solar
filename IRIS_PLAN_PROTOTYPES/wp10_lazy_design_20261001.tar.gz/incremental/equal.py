"""Lazy vs eager, window by window: every value and NaN (glue views of 32 steps), the derived mask, the glue
fixed-resolution buffers of the quicklook's three panels (values and mask) and a profile view, and the sampled
99.5 % limits against the exact percentiles of the eager values (np.nanpercentile of every finite value).

python equal.py OBSID [all]: all files of OBSID (else the first). One JSON line per window.
"""
import glob, json, sys, time
import numpy as np
from glue_solar.sources.loaders import iris as L

obsid = sys.argv[1]
files = sorted(glob.glob(f"/Users/nabil/DATA/IRIS/*{obsid}_raster/*.fits"))
files = files if "all" in sys.argv else files[:1]


def frb(data, cid, bounds):
    return data.compute_fixed_resolution_buffer(bounds, target_cid=cid)


for f in files:
    L.LAZY = True
    lazy = L.iris_data(f)
    for d in lazy:
        window = d.label.split("-")[0].replace("_", " ")
        L.LAZY = False
        [e] = L.raster_data([f], [window])
        cid, mcid = d.main_components[0], d.derived_components[0]
        ev, em = e[e.main_components[0]], e[e.main_components[1]]
        n, ny, nl = d.shape
        ok = {"values": True, "mask": True}
        t = time.perf_counter()
        for a in range(0, n, 32):
            view = (slice(a, a + 32),)
            ok["values"] &= np.array_equal(d[cid, view], ev[view], equal_nan=True)
            m = d[mcid, view]
            ok["mask"] &= m.dtype == np.uint8 and np.array_equal(m, em[view])
        t_all = time.perf_counter() - t
        s, y, k = n // 2, ny // 2, nl // 2
        panels = {  # glue's own fixed-resolution buffers, as the image viewers ask for them
            "map": ([(0, n - 1, n), (0, ny - 1, ny), k], (slice(None), slice(None), k)),
            "spectrogram": ([s, (0, ny - 1, ny), (0, nl - 1, nl)], (s, slice(None), slice(None))),
            "lambda_t": ([(0, n - 1, n), y, (0, nl - 1, nl)], (slice(None), y, slice(None))),
            "map_resampled": ([(0, n - 1, 97), (0, ny - 1, 113), k], None),
        }
        frb_ok, frb_ms = {}, {}
        for name, (bounds, key) in panels.items():
            t = time.perf_counter()
            v = frb(d, cid, bounds); m = frb(d, mcid, bounds)
            frb_ms[name] = round((time.perf_counter() - t) * 1e3, 1)
            ve, me = frb(e, e.main_components[0], bounds), frb(e, e.main_components[1], bounds)
            frb_ok[name] = bool(np.array_equal(v, ve, equal_nan=True) and np.array_equal(m, me) and (key is None or np.array_equal(ve, ev[key].astype(float), equal_nan=True)))
        profile_ok = bool(np.array_equal(d[cid, (s, y, slice(None))], ev[s, y, :], equal_nan=True))
        t = time.perf_counter()
        lims = [float(d.compute_statistic("percentile", cid, percentile=p, random_subset=10000)) for p in (0.25, 99.75)]
        t_lim = time.perf_counter() - t
        exact = [float(x) for x in np.nanpercentile(ev, [0.25, 99.75])]
        rng = exact[1] - exact[0]
        print(json.dumps({"obsid": obsid, "file": f[-11:-5], "window": window, "shape": d.shape, "flipped": d.get_component(cid)._source.raw.strides[0] < 0,
                          "equal_all_values": bool(ok["values"]), "equal_mask": bool(ok["mask"]), "views_s": round(t_all, 2),
                          "frb_equal": frb_ok, "frb_ms": frb_ms, "profile_equal": profile_ok,
                          "limits": lims, "exact": exact, "limits_s": round(t_lim, 3),
                          "err_pct_range": [round(100 * abs(lims[i] - exact[i]) / rng, 2) for i in (0, 1)],
                          "fill_fraction": round(float(em.mean()), 3)}), flush=True)
        del e, ev, em
