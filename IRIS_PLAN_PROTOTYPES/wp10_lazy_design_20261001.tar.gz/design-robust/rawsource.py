"""
Prototype (design-robust) for wp10-m1-lazy-loading: IRIS image HDUs held as raw int16 on disk (or in memory
for .fits.gz), scaled per requested slice, glue-visible as a DaskComponent whose __getitem__ never goes
through dask, and a Data subclass whose limits come from a histogram of the raw codes.
"""

import uuid

import dask.array as da
import numpy as np
from glue.core.component import DaskComponent, DerivedComponent
from glue.core.component_id import ComponentID
from glue.core.component_link import ComponentLink
from glue.core.data import Data

CHUNK_BYTES = 8 * 2**20  # raw bytes per dask chunk: whole-array dask consumers hold about threads x 3 x this
BATCH_BYTES = 2**20  # raw bytes per read of whole planes
SAMPLE_BYTES = 512 * 2**20  # raw bytes the limits histogram reads at most; evenly spaced planes beyond


def _expand(key, ndim):
    """``key`` as one index per axis: Ellipsis and missing trailing axes as slices, an n-d bool mask as its indices."""
    if not isinstance(key, tuple):
        key = (key,)
    if len(key) == 1 and isinstance(key[0], np.ndarray) and key[0].dtype == bool and key[0].ndim == ndim:
        key = np.nonzero(key[0])
    for i, k in enumerate(key):
        if k is Ellipsis:
            key = key[:i] + (slice(None),) * (ndim - len(key) + 1) + key[i + 1 :]
            break
    return tuple(key) + (slice(None),) * (ndim - len(key))


def _normalise(key, shape):
    """(lo, hi, rel): the bounding box of ``key`` per axis, inclusive, and ``key`` relative to it."""
    key = _expand(key, len(shape))
    if len(key) != len(shape):
        raise IndexError(f"too many indices for shape {shape}")
    lo, hi, rel = [], [], []
    for k, n in zip(key, shape):
        if isinstance(k, slice):
            start, stop, step = k.indices(n)
            r = range(start, stop, step)
            if len(r) == 0:
                return None
            low = min(r[0], r[-1])
            lo.append(low), hi.append(max(r[0], r[-1]))
            rel.append(slice(r[0] - low, r[-1] - low + 1, step) if step > 0 else slice(r[0] - low, None, step))
        else:
            a = np.asarray(k)
            if a.dtype == bool:
                a = np.nonzero(a)[0]
            if a.size == 0:
                return None
            if not np.issubdtype(a.dtype, np.integer):
                raise IndexError(f"unsupported index {k!r}")
            a = np.where(a < 0, a + n, a)
            if a.min() < 0 or a.max() >= n:
                raise IndexError(f"index out of range for axis of size {n}")
            low = int(a.min())
            lo.append(low), hi.append(int(a.max()))
            rel.append(int(a) - low if a.ndim == 0 else a - low)
    return lo, hi, tuple(rel)


class _Window:
    """Raw values of one image cube, any numpy key; subclasses read a bounding box."""

    def __getitem__(self, key):
        box = _normalise(key, self.shape)
        if box is None:
            return np.broadcast_to(np.zeros((), self.dtype), self.shape)[key].copy()
        lo, hi, rel = box
        return self.box(lo, hi)[rel]


class FileWindow(_Window):
    """One 3-D image HDU of an uncompressed FITS file, in irispy's orientation; reads from any thread."""

    def __init__(self, path, offset, shape, dtype, flip):
        self.path, self.offset, self.shape, self.dtype, self.flip = str(path), int(offset), tuple(shape), np.dtype(dtype), flip

    def box(self, lo, hi):
        """
        The box lo..hi (inclusive) in irispy's orientation, read with plain reads from its own file object (any
        thread): runs of whole planes when the box spans every row, else each plane's band of rows. Plain reads
        beat a memory map 5x on a cold cache and keep no file pages in the process (RSS).
        """
        n0, n1, n2 = self.shape
        out = np.empty([b - a + 1 for a, b in zip(lo, hi)], self.dtype)
        first, last = (n0 - 1 - hi[0], n0 - 1 - lo[0]) if self.flip else (lo[0], hi[0])  # planes on disk
        rows = hi[1] - lo[1] + 1
        band = rows * n2 * self.dtype.itemsize
        per = max(1, BATCH_BYTES // band) if rows == n1 else 1  # whole planes are contiguous: read runs
        buf = np.empty((per, rows, n2), self.dtype)
        with open(self.path, "rb", buffering=0) as f:
            for p in range(first, last + 1, per):
                q = min(last + 1, p + per)
                block = buf[: q - p]
                f.seek(self.offset + (p * n1 + lo[1]) * n2 * self.dtype.itemsize)
                if f.readinto(block) != block.nbytes:
                    raise OSError(f"{self.path} is shorter than its FITS header says")
                block = block[:, :, lo[2] : hi[2] + 1]
                if self.flip:  # disk planes p..q-1 are logical steps n0-1-p down to n0-q
                    out[n0 - q - lo[0] : n0 - p - lo[0]] = block[::-1]
                else:
                    out[p - lo[0] : q - lo[0]] = block
        return out


class MemoryWindow(_Window):
    """A raw cube already in memory (a decompressed .fits.gz), in irispy's orientation."""

    def __init__(self, raw, flip):
        self.raw = raw[::-1] if flip else raw
        self.shape, self.dtype = self.raw.shape, self.raw.dtype

    def __getitem__(self, key):
        return self.raw[key]

    def box(self, lo, hi):
        return self.raw[tuple(slice(a, b + 1) for a, b in zip(lo, hi))]


class StackWindow(_Window):
    """Scans of one window stacked along a new leading axis, each read from its own file."""

    def __init__(self, scans):
        self.scans = scans
        self.shape = (len(scans), *scans[0].shape)
        self.dtype = scans[0].dtype

    def box(self, lo, hi):
        return np.stack([self.scans[s].box(lo[1:], hi[1:]) for s in range(lo[0], hi[0] + 1)])


class Scaled:
    """Raw codes to float32 DN per requested slice, astropy's way (image.py:845, 858-861), fill codes to NaN."""

    def __init__(self, raw, bscale, bzero, fill):
        self.raw, self.bscale, self.bzero, self.fill = raw, float(bscale), float(bzero), tuple(int(c) for c in fill)
        self.shape, self.ndim, self.dtype = raw.shape, len(raw.shape), np.dtype(np.float32)
        self._counts = None

    def __getitem__(self, key):
        key = _expand(key, self.ndim)
        k0, rest = key[0], key[1:]
        if isinstance(k0, slice) and all(isinstance(k, (slice, int, np.integer)) for k in rest):
            # a large basic view (glue's InequalitySubsetState reads data[cid, ...]) is scaled a chunk of planes
            # at a time into its output, so it never holds the raw box and its temporaries whole
            steps = range(*k0.indices(self.shape[0]))
            inner = int(np.prod([len(range(*k.indices(n))) if isinstance(k, slice) else 1 for k, n in zip(rest, self.shape[1:])]))
            per = max(1, CHUNK_BYTES // (2 * max(1, inner)))  # by the size of the box asked for
            if len(steps) > per:
                parts = [steps[i : i + per] for i in range(0, len(steps), per)]
                out = None
                for i, part in enumerate(parts):
                    stop = part.stop if part.stop >= 0 else None
                    values = self.scale(self.raw[(slice(part.start, stop, part.step), *rest)])
                    if out is None:
                        out = np.empty((len(steps), *values.shape[1:]), np.float32)
                    out[i * per : i * per + len(part)] = values
                return out
        return self.scale(self.raw[key])

    def scale(self, raw):
        values = np.array(raw, dtype=np.float32)
        if self.bscale != 1:
            values *= self.bscale
        if self.bzero != 0:
            values += self.bzero
        fill = np.zeros(raw.shape, bool)
        for code in self.fill:
            fill |= raw == code
        values[fill] = np.nan
        return values

    def counts(self):
        """Counts of every raw int16 code, fill codes removed; whole planes, evenly spaced past SAMPLE_BYTES."""
        if self._counts is None:
            plane = int(np.prod(self.shape[-2:]))
            leading = self.shape[:-2]
            n = int(np.prod(leading))
            k = max(1, min(n, SAMPLE_BYTES // (2 * plane)))
            picks = np.unique(np.linspace(0, n - 1, k).round().astype(int))
            per = max(1, CHUNK_BYTES // (2 * plane))  # one read call (and file open) per chunk
            counts = np.zeros(65536, np.int64)
            batched = len(picks) == n and len(leading) == 1
            for start in range(0, len(picks), per if batched else 1):
                idx = np.unravel_index(picks[start], leading)
                if batched:
                    stop = min(n, start + per) - 1
                    raw = self.raw.box((start, 0, 0), (stop, self.shape[1] - 1, self.shape[2] - 1))
                else:
                    lo = (*idx, 0, 0)
                    hi = (*idx, self.shape[-2] - 1, self.shape[-1] - 1)
                    raw = self.raw.box(lo, hi)
                counts += np.bincount(np.asarray(raw, np.int16).view(np.uint16).ravel(), minlength=65536)
            counts = np.concatenate([counts[32768:], counts[:32768]])  # signed order, -32768 first
            for code in self.fill:
                counts[code + 32768] = 0
            self._counts = counts
        return self._counts

    def _picks(self):
        """Evenly spaced leading indices whose planes hold at most SAMPLE_BYTES of raw values (all if fewer)."""
        plane = int(np.prod(self.shape[-2:])) * self.raw.dtype.itemsize
        n = int(np.prod(self.shape[:-2]))
        return np.unique(np.linspace(0, n - 1, max(1, min(n, SAMPLE_BYTES // plane))).round().astype(int))

    def statistic(self, statistic, percentile=None, positive=False):
        if self.raw.dtype.kind != "i":  # float images (irispy's decimated test files): the sampled planes' values
            leading = self.shape[:-2]
            values = np.concatenate([self[np.unravel_index(i, leading)].ravel() for i in self._picks()])
            values = values[np.isfinite(values) & ((values > 0) if positive else True)]
            if values.size == 0:
                return np.nan
            return {"minimum": np.min, "maximum": np.max}.get(statistic, lambda v: np.percentile(v, percentile))(values)
        counts = self.counts()
        values = (np.arange(-32768, 32768, dtype=np.int64).astype(np.float32) * np.float32(self.bscale) + np.float32(self.bzero)).astype(np.float64)
        if positive:
            counts = np.where(values > 0, counts, 0)
        cum = np.cumsum(counts)
        total = int(cum[-1])
        if total == 0:
            return np.nan
        if statistic == "minimum":
            return values[np.searchsorted(cum, 1)]
        if statistic == "maximum":
            return values[np.searchsorted(cum, total)]
        q = percentile / 100 * (total - 1)
        i0 = int(np.floor(q))
        t = q - i0
        a = values[np.searchsorted(cum, i0 + 1)]
        b = values[np.searchsorted(cum, min(i0 + 2, total))]
        return a + (b - a) * t if t < 0.5 else b - (b - a) * (1 - t)  # numpy's _lerp


class LazyComponent(DaskComponent):
    """
    glue's DaskComponent for whole-array consumers (``.data`` is a dask array, chunked by whole planes), but
    every view, as glue's viewers, links and subsets ask, goes straight to the source without dask.
    """

    def __init__(self, source, units=None):
        plane = int(np.prod(source.shape[-2:])) * 2
        lead = [1] * (source.ndim - 2)
        lead[-1] = max(1, min(source.shape[-3], CHUNK_BYTES // plane))
        chunks = (*lead, *source.shape[-2:])
        meta = np.empty((0,) * source.ndim, np.float32)
        array = da.from_array(source, chunks=chunks, name=f"iris-{uuid.uuid4().hex}", meta=meta, asarray=False)
        super().__init__(array, units=units)
        self.source = source

    def __getitem__(self, key):
        return self.source[key]


def nan_mask(values):
    """One byte per sample, 1 where ``values`` is NaN: glue stores bool as int64 (glue/utils/array.py:159-160)."""
    return np.isnan(values).view(np.uint8)


class IRISData(Data):
    """
    glue Data whose whole-component statistics and histograms of a LazyComponent are computed by glue-solar
    (glue says subclasses may: glue/core/data.py:1627-1628): limits from the raw codes, histograms streamed
    a chunk at a time. Everything else is glue's.
    """

    def _lazy(self, cid):
        try:
            component = self.get_component(cid)
        except Exception:  # noqa: BLE001 - glue raises IncompatibleAttribute for other datasets' cids
            return None
        return component if isinstance(component, LazyComponent) else None

    def get_data(self, cid, view=None):
        # A whole read gives numpy, as eager data do (glue-qt's PV slicer and glue's exporters need it): read and
        # scaled a chunk of planes at a time, held only by the caller. Views stay lazy reads.
        if view is None and not isinstance(cid, ComponentLink) and self._lazy(cid) is not None:
            view = Ellipsis
        return super().get_data(cid, view=view)

    def compute_statistic(self, statistic, cid, subset_state=None, axis=None, finite=True, positive=False,
                          percentile=None, view=None, random_subset=None, n_chunk_max=40000000):
        component = None
        if subset_state is None and axis is None and view is None and finite and statistic in ("minimum", "maximum", "percentile"):
            component = self._lazy(cid)
        if component is None:
            return super().compute_statistic(statistic, cid, subset_state=subset_state, axis=axis, finite=finite,
                                             positive=positive, percentile=percentile, view=view,
                                             random_subset=random_subset, n_chunk_max=n_chunk_max)
        if statistic != "percentile" and random_subset:
            # glue's eager minimum and maximum come from random_subset values: their expected extremes
            percentile = 100 / (random_subset + 1)
            percentile = percentile if statistic == "minimum" else 100 - percentile
            statistic = "percentile"
        return component.source.statistic(statistic, percentile, positive)

    def compute_histogram(self, cids, weights=None, range=None, bins=None, log=None, subset_state=None,
                          random_subset=None):
        component = self._lazy(cids[0]) if len(cids) == 1 and weights is None else None
        if component is None:
            return super().compute_histogram(cids, weights=weights, range=range, bins=bins, log=log,
                                             subset_state=subset_state, random_subset=random_subset)
        from glue.utils.array import compute_histogram

        result = 0
        for view in da.core.slices_from_chunks(component.data.chunks):
            values = component[view]
            if subset_state is not None:
                values = values[subset_state.to_mask(self, view)]
            result = result + compute_histogram([values.ravel()], range=range, bins=bins, log=log)
        return result


def add_lazy(data, source, label, units):
    """The science component and its NaN mask as a glue derived component."""
    cid = data.add_component(LazyComponent(source, units=units), label)
    mask = ComponentID(f"{label} mask", parent=data)
    data.add_component(DerivedComponent(data, ComponentLink([cid], mask, using=nan_mask)), mask)
    return cid, mask
