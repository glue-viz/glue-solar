import sys
import numpy as np
from astropy.io import fits
for p in sys.argv[1:]:
    with fits.open(p) as h:
        d = h[1].data.astype(np.int64); hd = h[1].header
        n = hd['NSATPIX']
        vals = np.unique(d[d >= 14000])[::-1]
        cum = [(int(v), int((d >= v).sum())) for v in vals]
        near = [c for c in cum if abs(c[1] - n) <= 60]
        print(p.rsplit('/',1)[-1], 'LUTID', hd.get('LUTID'), 'NSATPIX', n, 'BLANK', hd.get('BLANK'), 'n<0', int((d < 0).sum()), 'min', int(d.min()), 'near', near[:6], 'cum_first8', cum[:8])
