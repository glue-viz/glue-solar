import sys
import numpy as np
from astropy.io import fits
for p in sys.argv[1:]:
    with fits.open(p) as h:
        hdu = h[1]
        d = hdu.data.astype(np.int64)
        hd = hdu.header
        vals, cnts = np.unique(d[d >= 15000], return_counts=True)
        top = list(zip(vals[-6:].tolist(), cnts[-6:].tolist()))
        print(p.rsplit('/',1)[-1], hd.get('IMG_PATH'), 'NSATPIX', hd.get('NSATPIX'), 'DATAMAX', hd.get('DATAMAX'),
              'n>=16000', int((d >= 16000).sum()), 'n==max', int((d == d.max()).sum()), 'max', int(d.max()), 'top', top)
