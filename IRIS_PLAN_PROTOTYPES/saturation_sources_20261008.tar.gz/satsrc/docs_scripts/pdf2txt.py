import sys
sys.path.insert(0, sys.argv[1])
from pypdf import PdfReader
for path in sys.argv[2:]:
    r = PdfReader(path)
    out = path.rsplit('.', 1)[0] + '.pdf.txt'
    with open(out, 'w') as f:
        for i, p in enumerate(r.pages, 1):
            f.write(f"\n=== PAGE {i} ===\n")
            f.write(p.extract_text() or '')
    print(out, len(r.pages))
