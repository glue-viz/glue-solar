import sys, openpyxl
wb = openpyxl.load_workbook(sys.argv[1], read_only=True, data_only=True)
for ws in wb.worksheets:
    for i, row in enumerate(ws.iter_rows(values_only=True), 1):
        vals = [str(v) for v in row if v is not None]
        if vals:
            print(f"{ws.title}:{i}: " + " | ".join(vals))
