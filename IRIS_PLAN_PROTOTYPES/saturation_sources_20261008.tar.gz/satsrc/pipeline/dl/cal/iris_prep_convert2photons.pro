function IRIS_PREP_CONVERT2PHOTONS, idata, $
	inhead = inhead, outhead = outhead
	
;+
;
;
;
;-

end
