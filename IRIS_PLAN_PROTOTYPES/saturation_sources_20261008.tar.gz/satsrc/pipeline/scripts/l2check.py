import sys, re, glob
import numpy as np
from astropy.io import fits

files = sorted(glob.glob('/Users/nabil/DATA/IRIS/*/*.fits') + glob.glob('/Users/nabil/DATA/IRIS/*.fits.gz'))
for f in files:
    try:
        with fits.open(f, do_not_scale_image_data=True, memmap=False) as h:
            p = h[0].header
            hist = [str(x) for x in p.get('HISTORY', [])]
            nsat = [int(m.group(1)) for x in hist for m in [re.search(r'Set (\d+) saturated', x)] if m]
            warp = [x.strip() for x in hist if 'INF_POLY_2D' in x or 'INFTERPOLATE' in x]
            c60 = c64 = c60s0 = 0; mx = -99999; nbig = 0
            for hdu in h:
                d = hdu.data
                if d is None or d.dtype.kind != 'i' or d.ndim < 2:
                    continue
                mx = max(mx, int(d.max()))
                c60 += int((d == 32760).sum()); c64 += int((d > 32760).sum())
                if d.ndim == 3:
                    c60s0 += int((d[0] == 32760).sum())
            tdmax = max([p[k] for k in p if k.startswith('TDMAX')] or [p.get('DATAMAX', np.nan)])
            print(f.split('/')[-1][:60], 'IPRPVER', p.get('IPRPVER'), 'VER_RF2', p.get('VER_RF2'), 'DATE_RF2', p.get('DATE_RF2'),
                  'NSATPIX', p.get('NSATPIX'), 'histN', nsat, 'warp', warp[:1], 'max', mx, 'n32760', c60, 'n>32760', c64, 'n32760_step0', c60s0, 'TDMAXmax', tdmax)
    except Exception as e:
        print(f, 'ERR', e)
