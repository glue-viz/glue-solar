"""Raw-int16 saturation survey of local IRIS Level 2 files.

Usage: python -I sat_scan.py OUT.json [files...]   (default: every non-AIA file under /Users/nabil/DATA/IRIS)
"""
import glob
import json
import re
import sys

import numpy as np
from astropy.io import fits
from scipy import ndimage

TOP = 32760                      # top raw code seen; 0.25*32760 + 7992 = 16182 DN
FILL = -32768                    # 0.25*-32768 + 7992 = -200 DN (missing)
HIST_RE = re.compile(r'saturat|\bInf\b', re.I)
KEY_RE = re.compile(r'SAT|^DATA|^TDM|^TDESC|^TDET|^TWMAX|^MISSVALS|^TOTVALS|^DATAVALS')
EIGHT = np.ones((3, 3), bool)


def phys(raw, h):
    return raw * h.get('BSCALE', 1.0) + h.get('BZERO', 0.0)


def plane_components(plane, h, wave_axis):
    """Components of TOP samples in one 2D plane (8-connected) with their border values."""
    mask = plane == TOP
    lab, n = ndimage.label(mask, EIGHT)
    border = ndimage.binary_dilation(mask, EIGHT) & ~mask & (plane != FILL)
    # assign each border pixel to an adjacent component
    owner = np.where(border, ndimage.maximum_filter(lab, size=3), 0)
    pv = phys(plane.astype(float), h)
    idx = np.arange(1, n + 1)
    sizes = ndimage.sum(mask, lab, idx)
    bmed = ndimage.median(pv, owner, idx) if border.any() else np.full(n, np.nan)
    bmax = ndimage.maximum(pv, owner, idx) if border.any() else np.full(n, np.nan)
    out = []
    for i, sl in enumerate(ndimage.find_objects(lab)):
        com = ndimage.center_of_mass(mask, lab, i + 1)
        c = {'size': int(sizes[i]), 'ext0': sl[0].stop - sl[0].start, 'ext1': sl[1].stop - sl[1].start,
             'bmed': float(bmed[i]), 'bmax': float(bmax[i]), 'c0': float(com[0]), 'c1': float(com[1])}
        if wave_axis is not None:     # numpy axis 1 of the plane = FITS axis 1 = WAVE
            c['wave'] = h['CRVAL1'] + (com[1] + 1 - h['CRPIX1']) * h['CDELT1']
        out.append(c)
    return out


def scan_image(d, h, label, is_raster):
    sat = phys(TOP, h)
    r = {'hdu': label, 'shape': list(d.shape), 'dtype': str(d.dtype)}
    if d.dtype.kind == 'f':
        r.update(n_posinf=int(np.isposinf(d).sum()), n_neginf=int(np.isneginf(d).sum()),
                 n_nan=int(np.isnan(d).sum()), max=float(np.nanmax(d[np.isfinite(d)])) if np.isfinite(d).any() else None)
        return r
    r['bscale'], r['bzero'] = h.get('BSCALE'), h.get('BZERO')
    r['raw_max'], r['raw_min'] = int(d.max()), int(d.min())
    r['phys_max'] = float(phys(r['raw_max'], h))
    r['n_top'] = int((d == TOP).sum())
    r['n_gt_top'] = int((d > TOP).sum())
    r['n_fill'] = int((d == FILL).sum())
    hi = d[d >= 32740].astype(np.int64)
    r['top_codes'] = {int(k + 32740): int(v) for k, v in enumerate(np.bincount(hi - 32740, minlength=28)) if v}
    lo = d[d <= -32750].astype(np.int64)
    r['bottom_codes'] = {int(k - 32768): int(v) for k, v in enumerate(np.bincount(lo + 32768, minlength=19)) if v}
    # fill samples touching a bright valid sample (would reveal Inf/NaN -> fill)
    nb = {2000: 0, 8091: 0}
    for t in range(d.shape[0]):
        mx = phys(ndimage.maximum_filter(np.where(d[t] == FILL, np.int16(-32767), d[t]), 3).astype(float), h)
        for thr in nb:
            nb[thr] += int(((d[t] == FILL) & (mx >= thr)).sum())
    r['fill_next_to_bright'] = nb
    # samples just below the top code, in DN bands
    p = phys(d.astype(np.float32), h)
    r['n_90_100pct'] = int(((p >= 0.9 * sat) & (p < sat)).sum())
    r['n_99_100pct'] = int(((p >= 0.99 * sat) & (p < sat)).sum())
    del p
    per_exp = (d == TOP).reshape(d.shape[0], -1).sum(1)
    r['top_per_exposure'] = {int(i): int(v) for i, v in enumerate(per_exp) if v}
    r['first_exposure_max_phys'] = float(phys(int(d[0].max()), h))
    comps = []
    neigh_sat, neigh_vals = 0, []
    for t in np.nonzero(per_exp)[0]:
        lab, _ = ndimage.label(d[t] == TOP, EIGHT)
        for k, c in enumerate(plane_components(d[t], h, 1 if is_raster else None)):
            c['t'] = int(t)
            sv = [d[tt][lab == k + 1] for tt in (t - 1, t + 1) if 0 <= tt < d.shape[0]]
            sv = np.concatenate(sv) if sv else np.array([], np.int16)
            sv = sv[sv != FILL]
            c['step_med'] = float(phys(float(np.median(sv)), h)) if sv.size else None
            comps.append(c)
        ys, xs = np.nonzero(d[t] == TOP)
        for tt in (t - 1, t + 1):           # neighbours along time / raster step
            if 0 <= tt < d.shape[0]:
                v = d[tt][ys, xs]
                neigh_sat += int((v == TOP).sum())
                neigh_vals.extend(phys(v[v != FILL].astype(float), h).tolist())
    r['components'] = comps
    r['step_neighbours'] = {'n_pairs_top': neigh_sat, 'n_vals': len(neigh_vals),
                            'median': float(np.median(neigh_vals)) if neigh_vals else None,
                            'frac_ge_half_sat': float(np.mean(np.array(neigh_vals) >= 0.5 * sat)) if neigh_vals else None}
    return r


def scan_file(path):
    rec = {'file': path, 'history': [], 'keys': {}, 'images': []}
    with fits.open(path, do_not_scale_image_data=True) as hl:
        is_raster = 'raster' in path
        for i, hdu in enumerate(hl):
            h = hdu.header
            for line in h.get('HISTORY', []):
                if HIST_RE.search(line):
                    rec['history'].append([i, str(line)])
            for k in h:
                if k and KEY_RE.search(k) and k not in ('DATASUM',):
                    rec['keys'][f'{i}:{k}'] = h[k]
            if hdu.is_image and hdu.data is not None and hdu.data.ndim == 3:
                lab = h.get('EXTNAME') or f'hdu{i}'
                if i and 'raster' in path and not h.get('EXTNAME'):
                    lab = f'win{i}:' + str(hl[0].header.get(f'TDESC{i}', ''))
                rec['images'].append(scan_image(hdu.data, h, lab, is_raster))
    return rec


def main():
    out = sys.argv[1]
    files = sys.argv[2:] or sorted(f for f in glob.glob('/Users/nabil/DATA/IRIS/**/*.fits*', recursive=True)
                                   if '/aia_' not in f)
    recs = []
    for f in files:
        print(f, flush=True)
        recs.append(scan_file(f))
    with open(out, 'w') as fh:
        json.dump(recs, fh, default=str)


def _selftest():
    # 3 steps x 5 y x 6 lambda; one isolated spike and one 2-pixel plateau with bright border
    h = {'BSCALE': 0.25, 'BZERO': 7992, 'CRVAL1': 1000.0, 'CRPIX1': 1.0, 'CDELT1': 1.0}
    d = np.zeros((3, 5, 6), np.int16)
    d[1, 1, 1] = TOP
    d[1, 3, 3:5] = TOP
    d[1, 2:5, 2:6][d[1, 2:5, 2:6] != TOP] = 30000
    r = scan_image(d, h, 'x', True)
    assert r['n_top'] == 3 and r['top_per_exposure'] == {1: 3}
    sizes = sorted(c['size'] for c in r['components'])
    assert sizes == [1, 2], sizes
    plateau = [c for c in r['components'] if c['size'] == 2][0]
    assert plateau['bmed'] == phys(30000, h) and abs(plateau['wave'] - 1003.5) < 1e-9


if __name__ == '__main__':
    _selftest()
    main()
