"""Interior fill (-32768) holes and exact-zero samples in raw int16 L2 images: would reveal Inf -> fill or bad->0."""
import glob, sys, collections
import numpy as np
from astropy.io import fits
from scipy import ndimage
EIGHT = np.ones((3, 3), bool)
tot = collections.Counter()
for f in sorted(glob.glob('/Users/nabil/DATA/IRIS/**/*.fits*', recursive=True)):
    if '/aia_' in f or 'fexxi' in f:
        continue
    with fits.open(f, do_not_scale_image_data=True) as hl:
        for i, hdu in enumerate(hl):
            if not (hdu.is_image and hdu.data is not None and hdu.data.ndim == 3 and hdu.data.dtype.kind == 'i'):
                continue
            d = hdu.data
            nh, nhs, nzero = 0, 0, int((d == -31968).sum())
            bright = []
            for t in range(d.shape[0]):
                fill = d[t] == -32768
                if not fill.any():
                    continue
                lab, n = ndimage.label(fill, EIGHT)
                edge = np.unique(np.r_[lab[0], lab[-1], lab[:, 0], lab[:, -1]])
                inner = np.setdiff1d(np.arange(1, n + 1), edge)
                if inner.size:
                    m = np.isin(lab, inner)
                    nh += inner.size
                    nhs += int(m.sum())
                    ring = ndimage.binary_dilation(m, EIGHT) & ~fill
                    if ring.any():
                        bright.append(float(d[t][ring].max()) * .25 + 7992)
            if nh or nzero:
                print(f.split('/')[-1][8:60], i, 'interior holes', nh, 'samples', nhs, 'max ring DN', max(bright) if bright else None, 'raw==0DN samples', nzero)
            tot['hdus'] += 1
            tot['holes'] += nh
            tot['hole_samples'] += nhs
print(dict(tot))
