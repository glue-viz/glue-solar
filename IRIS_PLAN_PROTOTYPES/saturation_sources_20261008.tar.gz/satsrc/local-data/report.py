import collections
import json
import re
import sys

import numpy as np

SAT = 16182.0
recs = json.load(open(sys.argv[1]))


def short(f):
    m = re.search(r'iris_l2_(\d{8}_\d{6})_(\d+)_(\w+?)(?:_t000)?(?:_r(\d+))?(_deconvolved)?\.fits', f)
    return f'{m[1]}_{m[2]} {m[3]}{" r" + m[4] if m[4] else ""}{" dec" if m[5] else ""}' if m else f.split('/')[-1]


print('== per file ==')
print('file | HIST N | n_top(file) | n_gt_top | per-window n_top | windows TDMAX>16182 (TDMAX, n_top) | max|TDMAX-stored max| where TDMAX<=16182 | DATAMAX | NSATPIX | TSATPX set')
for r in recs:
    hn = [int(m[1]) for _, l in r['history'] for m in [re.search(r'Set (\d+) saturated', l)] if m]
    imgs = [i for i in r['images'] if 'raw_max' in i]
    k = r['keys']
    win = []
    over, diffs = [], []
    for j, im in enumerate(imgs, 1):
        win.append(f"{im['hdu'].split(':')[-1]}={im['n_top']}")
        td = k.get(f'0:TDMAX{j}')
        if td is None:
            continue
        if td > SAT:
            over.append(f"w{j}({td},{im['n_top']})")
        else:
            diffs.append(abs(td - im['phys_max']))
    tsat = sorted({v for kk, v in k.items() if re.match(r'\d+:TSATPX', kk)})
    print(f"{short(r['file'])} | {hn} | {sum(i['n_top'] for i in imgs)} | {sum(i['n_gt_top'] for i in imgs)} | "
          f"{' '.join(win)} | {' '.join(over) or '-'} | {max(diffs) if diffs else '-'} | {k.get('0:DATAMAX')} | "
          f"{k.get('0:NSATPIX')} | {tsat}")

print('\n== float images ==')
for r in recs:
    for im in r['images']:
        if 'n_posinf' in im:
            print(short(r['file']), im)

print('\n== top codes (all int16 images) ==')
top, bot = collections.Counter(), collections.Counter()
for r in recs:
    for im in r['images']:
        top.update({int(a): b for a, b in im.get('top_codes', {}).items()})
        bot.update({int(a): b for a, b in im.get('bottom_codes', {}).items()})
print('top', sorted(top.items()))
print('bottom', sorted(bot.items()))
print('raw_max set', sorted({im['raw_max'] for r in recs for im in r['images'] if 'raw_max' in im}, reverse=True)[:8])
print('raw_min set', sorted({im['raw_min'] for r in recs for im in r['images'] if 'raw_min' in im})[:4])
print('bscale/bzero', {(im.get('bscale'), im.get('bzero')) for r in recs for im in r['images'] if 'raw_max' in im})
print('fill next to bright', collections.Counter(json.dumps(im['fill_next_to_bright']) for r in recs for im in r['images'] if 'fill_next_to_bright' in im))

print('\n== per observation/window: TOP-sample morphology ==')
groups = collections.defaultdict(list)
near = collections.Counter()
for r in recs:
    obs = short(r['file']).split(' r')[0]
    for im in r['images']:
        if 'raw_max' not in im:
            continue
        near[(obs, im['hdu'], '90-100%')] += im['n_90_100pct']
        near[(obs, im['hdu'], '99-100%')] += im['n_99_100pct']
        for c in im['components']:
            c['file'] = short(r['file'])
            groups[(obs, im['hdu'])].append(c)
print('obs | window | n comps | n samples | size hist | slit-extent max | border median q10/q50/q90 DN | step-neighbour median q50 | class spike/plateau/other (samples) | samples 0.9-1.0*SAT | 0.99-1.0*SAT')
for key, cs in sorted(groups.items()):
    size = [c['size'] for c in cs]
    bmed = np.array([c['bmed'] for c in cs])
    smed = np.array([c['step_med'] if c['step_med'] is not None else np.nan for c in cs])
    cls = collections.Counter()
    for c, b, s in zip(cs, bmed, smed):
        if b < 0.25 * SAT and not (s >= 0.25 * SAT):
            cls['spike'] += c['size']
        elif b >= 0.5 * SAT:
            cls['plateau'] += c['size']
        else:
            cls['other'] += c['size']
    sh = collections.Counter(min(s, 10) for s in size)
    print(f"{key[0]} | {key[1]} | {len(cs)} | {sum(size)} | {dict(sorted(sh.items()))} | {max(c['ext0'] for c in cs)} | "
          f"{np.nanpercentile(bmed, [10, 50, 90]).round(0).tolist()} | {np.nanmedian(smed) if np.isfinite(smed).any() else None} | "
          f"{cls['spike']}/{cls['plateau']}/{cls['other']} | {near[(key[0], key[1], '90-100%')]} | {near[(key[0], key[1], '99-100%')]}")

print('\n== largest / plateau components ==')
allc = [(k, c) for k, cs in groups.items() for c in cs]
for k, c in sorted(allc, key=lambda kc: -kc[1]['size'])[:25]:
    print(k[1], c['file'], {x: (round(v, 2) if isinstance(v, float) else v) for x, v in c.items() if x != 'file'})
print('\n== wavelength of TOP components (raster), rounded 0.5 A, top 30 ==')
wl = collections.Counter()
for k, c in allc:
    if 'wave' in c:
        wl[(k[1].split(':')[-1], round(c['wave'] * 2) / 2)] += c['size']
for (w, l), n in wl.most_common(30):
    print(w, l, n)
