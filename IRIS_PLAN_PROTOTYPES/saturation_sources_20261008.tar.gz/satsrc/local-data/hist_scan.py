import glob, re, sys, collections
from astropy.io import fits
pat = re.compile(r'saturat|\bInf\b', re.I)
files = sorted(f for f in glob.glob('/Users/nabil/DATA/IRIS/**/*.fits*', recursive=True) if '/aia_' not in f)
forms = collections.Counter()
for f in files:
    with fits.open(f, do_not_scale_image_data=True) as hl:
        for i, h in enumerate(hl):
            for line in h.header.get('HISTORY', []):
                if pat.search(line):
                    forms[(i, re.sub(r'\d+', 'N', line.strip()))] += 1
                    print(f.split('/')[-1], i, repr(line))
print(len(files), 'files')
for k, v in forms.items(): print(v, k)
