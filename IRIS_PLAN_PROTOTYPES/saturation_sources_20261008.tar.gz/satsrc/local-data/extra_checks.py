"""Reproduces the inline checks: (1) which exposure the HISTORY block comes from, (2) per-observation table,
(3) TDMAX>16182 <=> TOP samples, (4) irispy packaged test files: Inf / TOP counts."""
import collections, glob, json, re
import numpy as np
from astropy.io import fits
recs = json.load(open('all.json'))
print('== (1) HISTORY "Dark ... T=[" string vs per-exposure dark-temperature strings in the filename table ==')
for obs in ['f783', '38a3', '2dd2', 'c760', '5617', 'cf5f', 'eac3']:
    files = sorted(glob.glob(f'/Users/nabil/DATA/IRIS/{obs}*/*.fits'))
    tstr = [l for l in fits.getheader(files[0])['HISTORY'] if 'Dark' in l][0].split('T=[')[1]
    same = len({tuple(fits.getheader(f)['HISTORY']) for f in files})
    hits, n = [], 0
    for f in files:
        for k, row in enumerate(fits.getdata(f, ext=-1)):
            n += 1
            if tstr in ' '.join(map(str, row)):
                hits.append((f[-11:-5], k))
    print(obs, f'{len(files)} files, distinct HISTORY blocks={same}; matching exposure rows {len(hits)}/{n}: {hits[:3]}')
print('\n== (2) per observation: obs | files | exposures | HISTORY N | TOP in exposure 0 | TOP total | >TOP | windows TDMAX>16182 | max TDMAX ==')
o = collections.defaultdict(lambda: collections.defaultdict(int))
for r in recs:
    m = re.search(r'iris_l2_(\d{8}_\d{6}_\d+)_(raster|SJI_\d+)', r['file'])
    if not m: continue
    g = o[m[1] + ' ' + m[2] + (' deconvolved' if 'deconv' in r['file'] else '')]
    imgs = [i for i in r['images'] if 'raw_max' in i]
    g['files'] += 1; g['exp'] += imgs[0]['shape'][0]
    g['N'] = sorted({int(re.search(r'Set (\d+)', l)[1]) for _, l in r['history']}) or '-'
    g['top'] += sum(i['n_top'] for i in imgs); g['gt'] += sum(i['n_gt_top'] for i in imgs)
    if re.search(r'r00000|SJI', r['file']): g['first'] = sum(i['top_per_exposure'].get('0', 0) for i in imgs)
    for j, im in enumerate(imgs, 1):
        td = r['keys'].get(f'0:TDMAX{j}')
        g['win'] += 1; g['over'] += td > 16182; g['maxtd'] = max(g['maxtd'], td)
        if 'deconv' not in r['file'] and (td > 16182) != (im['n_top'] > 0): g['MISMATCH'] += 1
for k, g in sorted(o.items()):
    print(f"{k} | {g['files']} | {g['exp']} | {g['N']} | {g['first']} | {g['top']} | {g['gt']} | {g['over']}/{g['win']} | {g['maxtd']} | mismatch={g['MISMATCH']}")
print('\n== (4) irispy packaged test files ==')
for f in sorted(glob.glob('/Users/nabil/mamba/envs/iris-plan-main/lib/python3.13/site-packages/irispy/data/test/**/*.fits*', recursive=True)):
    with fits.open(f, do_not_scale_image_data=True) as hl:
        out = []
        for i, h in enumerate(hl):
            if h.is_image and h.data is not None and h.data.ndim >= 2:
                d = h.data
                out.append(f'{i}:{d.dtype} +inf={int(np.isposinf(d).sum())} nan={int(np.isnan(d).sum())}' if d.dtype.kind == 'f'
                           else f'{i}:{d.dtype} rawmax={d.max()} n32760={int((d == 32760).sum())}')
        print(f.split('/test/')[1], out, [l for h in hl for l in h.header.get('HISTORY', []) if 'aturat' in l])
