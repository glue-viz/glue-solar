"""Route 1 on 4000005156 Si IV 1394 (two-scan stack, and scan 0 alone): a Pixel click on a viewer of the complementary axes."""
from common import *  # noqa: F403

from glue_solar.quicklook import _line_core, coordinator, quicklook
from glue_solar.sources.loaders.iris import raster_data

t0 = time.perf_counter()
[stack] = raster_data(RASTER_FILES, ["Si IV 1394"], stack=True)
[scan0] = raster_data(RASTER_FILES[:1], ["Si IV 1394"])
print(f"loaded in {time.perf_counter() - t0:.1f} s: stack {stack.shape}, scan {scan0.shape}, size {stack.size:.3g}")
cube = np.asarray(stack[stack.main_components[0]])
cube0 = np.asarray(scan0[scan0.main_components[0]])
wl = _line_core(stack)
SCAN, STEP, SLIT = 1, 20, 300
print("line core pixel", wl)

app = new_app()
v = quicklook(app, [stack])
events(20)
coord = coordinator(app.data_collection)
[point] = app.session.edit_subset_mode.edit_subset
print("quicklook point slices", point.subset_state.slices)

# (b) spectrogram row = the spectrum at the point: the quicklook's spectrum panel
select_point(v["map"], STEP, SLIT)
print("after map click, point", point.subset_state.slices)
v["wavelength"].state.slices = (SCAN, *v["wavelength"].state.slices[1:])  # nothing: shows scan
v["map"].state.slices = (SCAN, *v["map"].state.slices[1:])
events(10)
print("after scan slider, point", point.subset_state.slices)
sub = next(s for s in point.subsets if s.data is stack)
compare("(b) spectrum panel vs cube[scan, step, slit, :]", profile_of(v["spectrum"], sub), cube[SCAN, STEP, SLIT, :])

# (a) map row by a click on the spectrogram (shows wavelength x slit): the step axis would be free in glue's own state
select_point(v["spectrogram"], wl, SLIT)
print("after spectrogram click at (wl, slit), point", point.subset_state.slices, type(point.subset_state).__name__)
row = app.new_data_viewer(ProfileViewer, data=stack)
row.state.x_att = stack.pixel_component_ids[1]
row.state.function = "mean"
events(10)
got = profile_of(row, sub)
compare("(a) map row via spectrogram click, Profile x=step", got, cube[SCAN, :, SLIT, wl])
print("  ", draw_ok(row))

# (a) map column by a click on the wavelength panel (wavelength x scan): slit would be free in glue's own state
select_point(v["wavelength"], wl, SCAN)
print("after wavelength-panel click at (wl, scan), point", point.subset_state.slices)
col = app.new_data_viewer(ProfileViewer, data=stack)
col.state.x_att = stack.pixel_component_ids[2]
events(10)
compare("(a) map column via λ-scan click, Profile x=slit", profile_of(col, sub), cube[SCAN, STEP, :, wl])
print("  ", draw_ok(col))

# a plain Image viewer of the stack (not a quicklook panel) showing wavelength x slit at the scan
plain = image(app, stack, 3, 2, (SCAN, STEP, 0, 0))
select_point(plain, wl, SLIT)
print("plain viewer (λ, slit) click: point", coord.point.slices if coord.point is not None else None,
      "group", coord.group.label)
g = coord.group
s2 = next(s for s in g.subsets if s.data is stack)
compare("(a) map row via plain-viewer click, Profile x=step", profile_of(row, s2), cube[SCAN, :, SLIT, wl])

# glue alone (no coordinator pinning): what the click would give, for reference
from glue.viewers.image.pixel_selection_subset_state import PixelSubsetState
raw = PixelSubsetState(stack, [slice(SCAN, SCAN + 1), slice(None), slice(SLIT, SLIT + 1), slice(wl, wl + 1)])
grp = app.data_collection.new_subset_group(label="raw pixel (bypass)", subset_state=raw)
events(10)
print("raw PixelSubsetState group after the coordinator saw it:", grp.subset_state.slices)

# scan 0 alone (3D scanning raster), quicklook + spectrogram click
app2 = new_app()
v2 = quicklook(app2, [scan0])
events(20)
[point2] = app2.session.edit_subset_mode.edit_subset
select_point(v2["spectrogram"], wl, SLIT)
print("3D scan: after spectrogram click, point", point2.subset_state.slices)
row2 = app2.new_data_viewer(ProfileViewer, data=scan0)
row2.state.x_att = scan0.pixel_component_ids[0]
events(10)
sub2 = next(s for s in point2.subsets if s.data is scan0)
compare("3D scan (a) map row via spectrogram click", profile_of(row2, sub2), cube0[:, SLIT, wl])
print("  ", draw_ok(row2))
