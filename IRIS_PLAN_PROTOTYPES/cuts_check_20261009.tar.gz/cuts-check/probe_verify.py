"""Skeptic's extra checks: glue alone without the coordinator, IndexedData as a cut, the spectrum panel drawing a 1-sample cut, a banded cut."""
from common import *  # noqa: F403

from glue.core.data_derived import IndexedData
from glue.core.subset import SliceSubsetState
from glue.viewers.image.pixel_selection_subset_state import PixelSubsetState

from glue_solar.quicklook import _line_core, coordinator, quicklook
from glue_solar.sources.loaders.iris import raster_data

[stack] = raster_data(RASTER_FILES, ["Si IV 1394"], stack=True)
[scan0] = raster_data(RASTER_FILES[:1], ["Si IV 1394"])
cid, cid0 = stack.main_components[0], scan0.main_components[0]
cube, cube0 = np.asarray(stack[cid]), np.asarray(scan0[cid0])
wl = _line_core(stack)
SCAN, STEP, SLIT = 1, 20, 300
row_expected = cube[SCAN, :, SLIT, wl]

print("=== glue alone, no coordinator: what a Pixel click on a (λ, slit) panel gives a Profile with x = step")
raw4 = PixelSubsetState(stack, [slice(None), slice(None), slice(SLIT, SLIT + 1), slice(wl, wl + 1)])
got = stack.compute_statistic("mean", cid, axis=(0, 2, 3), subset_state=raw4)
compare("stack: click fixes only the two shown axes, scan stays free", got, row_expected)
compare("  = mean of the two scans", got, np.nanmean(cube[:, :, SLIT, wl], axis=0))
raw3 = PixelSubsetState(scan0, [slice(None), slice(SLIT, SLIT + 1), slice(wl, wl + 1)])
compare("3D scan: the same click, Profile x = step", scan0.compute_statistic("mean", cid0, axis=(1, 2), subset_state=raw3),
        cube0[:, SLIT, wl])

print("=== Route 3 variant: a SliceSubsetState over a wavelength band (as the light curve's band)")
band = slice(wl - 10, wl + 11)
cut = SliceSubsetState(stack, [slice(SCAN, SCAN + 1), slice(None), slice(SLIT, SLIT + 1), band])
compare("row over a 21-px band, mean", stack.compute_statistic("mean", cid, axis=(0, 2, 3), subset_state=cut),
        np.nanmean(cube[SCAN, :, SLIT, band], axis=1))

print("=== IndexedData (glue.core.data_derived) as the cut: a 1-D derived dataset at the point")
app = new_app()
v = quicklook(app, [stack])
events(20)
coord = coordinator(app.data_collection)
select_point(v["map"], STEP, SLIT)
v["map"].state.slices = (SCAN, *v["map"].state.slices[1:])
events(10)
row = IndexedData(stack, (SCAN, None, SLIT, wl))
try:
    app.data_collection.append(row)
    events(10)
    print("  appended:", row.label, row.shape, "point still", coord.point.slices if coord.point else None)
    p = app.new_data_viewer(ProfileViewer, data=row)
    events(10)
    print("  profile x_att", p.state.x_att, "layers", [(l.layer.label, l.enabled, l.disabled_message) for l in p.layers])
    compare("IndexedData row in a Profile", profile_of(p, row), row_expected)
    row.indices = (SCAN, None, SLIT + 5, wl)
    events(10)
    compare("  after indices -> slit+5 (NumericalDataChangedMessage)", profile_of(p, row), cube[SCAN, :, SLIT + 5, wl])
    print("  label now", row.label)
    for name in ("map", "spectrogram", "wavelength", "spectrum"):
        print(f"  {name} panel layers:", [l.layer.label for l in v[name].layers])
    path = os.path.join(tempfile.mkdtemp(), "s.glu")
    try:
        app.save_session(path)
        print("  session with an IndexedData saved OK")
    except Exception as e:  # noqa: BLE001
        print(f"  session save with an IndexedData: {type(e).__name__}: {str(e)[:160]}")
    # a Collapse band cannot be an IndexedData index
    try:
        IndexedData(stack, (SCAN, None, SLIT, band))
        print("  IndexedData accepted a slice as an index (band)")
    except Exception as e:  # noqa: BLE001
        print(f"  IndexedData with a band index: {type(e).__name__}: {str(e)[:120]}")
except Exception as e:  # noqa: BLE001
    import traceback
    traceback.print_exc()
    print(f"  IndexedData route failed: {type(e).__name__}: {str(e)[:200]}")

print("=== Does the spectrum panel draw a SliceSubsetState row cut (1 sample against 313 x)?")
mode = app.session.edit_subset_mode
edit = mode.edit_subset
cut_row = app.data_collection.new_subset_group(
    label="Cut row", subset_state=SliceSubsetState(stack, [slice(SCAN, SCAN + 1), slice(None), slice(SLIT, SLIT + 1), slice(wl, wl + 1)]))
mode.edit_subset = edit
events(10)
spec = v["spectrum"]
sub = next(s for s in cut_row.subsets if s.data is stack)
[artist] = [a for a in spec.layers if a.state.layer is sub]
try:
    artist.state.reset_cache()
    artist._calculate_profile_thread(reset=True)
    artist._calculate_profile_postthread()
    x, y = artist.plot_artist.get_data()
    print("  plot_artist data lengths:", len(x), len(y), "enabled", artist.enabled, repr(artist.disabled_message)[:100])
    spec.figure.canvas.draw()
    print("  spectrum panel draw: ok")
except Exception as e:  # noqa: BLE001
    print(f"  spectrum panel draw: {type(e).__name__}: {str(e)[:200]}")
