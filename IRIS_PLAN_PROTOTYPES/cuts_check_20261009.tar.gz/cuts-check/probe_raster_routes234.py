"""Routes 2-4 on 4000005156 Si IV 1394 (two-scan stack; scan 0 alone for the 3D case)."""
from common import *  # noqa: F403

from glue.core.edit_subset_mode import AndMode, ReplaceMode
from glue.core.roi import RectangularROI, XRangeROI
from glue.core.subset import SliceSubsetState
from glue.plugins.tools.path_slicer.path_sliced_data import sample_points

from glue_solar.quicklook import _light_curve, _line_core, _show, coordinator, quicklook
from glue_solar.sources.loaders.iris import raster_data
from glue_solar.tools import PathData

[stack] = raster_data(RASTER_FILES, ["Si IV 1394"], stack=True)
cube = np.asarray(stack[stack.main_components[0]])
wl = _line_core(stack)
SCAN, STEP, SLIT = 1, 20, 300
row_expected, col_expected = cube[SCAN, :, SLIT, wl], cube[SCAN, STEP, :, wl]
print(f"NaN in the row: {np.isnan(row_expected).sum()}, in the column: {np.isnan(col_expected).sum()}")

app = new_app()
v = quicklook(app, [stack])
events(20)
coord = coordinator(app.data_collection)
point = coord.group
select_point(v["map"], STEP, SLIT)
v["map"].state.slices = (SCAN, *v["map"].state.slices[1:])
events(10)
print("point", point.subset_state.slices)
mode = app.session.edit_subset_mode


def new_groups(before):
    return [g for g in app.data_collection.subset_groups if g not in before]


def subset_of(group):
    return next(s for s in group.subsets if s.data is stack)


def profile(x_axis, function="mean"):
    p = app.new_data_viewer(ProfileViewer, data=stack)
    p.state.x_att = stack.pixel_component_ids[x_axis]
    p.state.function = function
    events(10)
    return p


print("=== Route 2: a one-row region on the map, Profile with Mean")
before = list(app.data_collection.subset_groups)
v["map"].apply_roi(RectangularROI(-0.5, 63.5, SLIT - 0.4, SLIT + 0.4))  # x = step, y = slit
events(10)
[row_group] = new_groups(before)
print("  new group", row_group.label, type(row_group.subset_state).__name__, "edit subset still the point:",
      mode.edit_subset == [point])
mask = row_group.subset_state.to_mask(stack)
print("  mask selects", int(mask.sum()), "of", mask.size, "values; per step", int(mask[:, 0].sum()))
p_row = profile(1)
t0 = time.perf_counter()
got = profile_of(p_row, subset_of(row_group))
print(f"  profile in {time.perf_counter() - t0:.2f} s")
compare("map row, region only, Mean", got, row_expected)
compare("  = nanmean over both scans and every wavelength", got, np.nanmean(cube[:, :, SLIT, :], axis=(0, 2)))
# AND a one-pixel region on the λ-scan panel (x = wavelength, y = scan): restricts both hidden axes at once
mode.edit_subset, mode.mode = [row_group], AndMode
v["wavelength"].apply_roi(RectangularROI(wl - 0.4, wl + 0.4, SCAN - 0.4, SCAN + 0.4))
events(10)
mode.mode = ReplaceMode
print("  after AND:", type(row_group.subset_state).__name__)
for function in ("mean", "maximum", "median", "sum"):
    p_row.state.function = function
    compare(f"map row, region AND λ-scan pixel, {function}", profile_of(p_row, subset_of(row_group)), row_expected)
p_row.state.function = "mean"

# map column, and the λ restriction from the spectrum panel's x range instead
mode.edit_subset = [point]
before = list(app.data_collection.subset_groups)
v["map"].apply_roi(RectangularROI(STEP - 0.4, STEP + 0.4, -0.5, cube.shape[2] - 0.5))
events(10)
[col_group] = new_groups(before)
p_col = profile(2)
compare("map column, region only, Mean", profile_of(p_col, subset_of(col_group)), col_expected)
wave = v["spectrum"].state.x_att
w = stack[wave, (0, 0, 0, slice(None))]
mode.edit_subset, mode.mode = [col_group], AndMode
v["spectrum"].apply_roi(XRangeROI(w[wl] - 0.4 * (w[wl + 1] - w[wl]), w[wl] + 0.4 * (w[wl + 1] - w[wl])))
events(10)
compare("map column, region AND spectrum x-range (both scans still in)", profile_of(p_col, subset_of(col_group)),
        col_expected)
compare("  = mean of the two scans", profile_of(p_col, subset_of(col_group)), np.nanmean(cube[:, STEP, :, wl], axis=0))
v["wavelength"].apply_roi(RectangularROI(wl - 0.4, wl + 0.4, SCAN - 0.4, SCAN + 0.4))
events(10)
mode.mode = ReplaceMode
compare("map column, region AND x-range AND λ-scan pixel", profile_of(p_col, subset_of(col_group)), col_expected)
mode.edit_subset = [point]
# does it follow the point? move the point and re-read
select_point(v["map"], STEP + 5, SLIT + 5)
compare("  after moving the point: still the old column (static)", profile_of(p_col, subset_of(col_group)),
        col_expected)

print("=== Route 3: a SliceSubsetState group (as the light curve's), Profile x = the cut axis")
cut_row = app.data_collection.new_subset_group(
    label="Cut row", subset_state=SliceSubsetState(stack, [slice(SCAN, SCAN + 1), slice(None), slice(SLIT, SLIT + 1),
                                                           slice(wl, wl + 1)]))
mode.edit_subset = [point]
events(10)
print("  coordinator left it alone:", cut_row.subset_state.slices, "point still followed:", coord.group is point)
p3 = profile(1)
compare("map row via SliceSubsetState, Mean", profile_of(p3, subset_of(cut_row)), row_expected)
for name in ("map", "spectrogram", "wavelength", "spectrum"):
    print(f"  {name} panel with the cut layer:", draw_ok(v[name])[0],
          profile_of(v[name], subset_of(cut_row)) if name == "spectrum" else "")
cut_col = app.data_collection.new_subset_group(
    label="Cut column", subset_state=SliceSubsetState(stack, [slice(SCAN, SCAN + 1), slice(STEP, STEP + 1),
                                                              slice(None), slice(wl, wl + 1)]))
mode.edit_subset = [point]
p4 = profile(2)
compare("map/spectrogram column via SliceSubsetState", profile_of(p4, subset_of(cut_col)), col_expected)
print("  cut row in the x=slit profile:", (lambda g: g if isinstance(g, str) else [np.shape(a) for a in g])(
    profile_of(p4, subset_of(cut_row))))
t0 = time.perf_counter()
for i in range(20):
    cut_row.subset_state = SliceSubsetState(stack, [slice(SCAN, SCAN + 1), slice(None), slice(SLIT + i, SLIT + i + 1),
                                                    slice(wl, wl + 1)])
    profile_of(p3, subset_of(cut_row))
print(f"  20 moves of the cut row, each re-profiled: {(time.perf_counter() - t0) / 20 * 1e3:.1f} ms per move")

print("=== Existing 'Light curve at the point' on the stack (cut along scan)")
select_point(v["map"], STEP, SLIT)
v["map"].state.slices = (SCAN, *v["map"].state.slices[1:])
events(10)
lc = _light_curve(v["map"])
events(10)
[lc_layer] = [layer.layer for layer in lc.state.layers]
compare("light curve vs cube[:, step, slit, wl]", profile_of(lc, lc_layer), cube[:, STEP, SLIT, wl])

print("=== Route 4: Path diagram along the map's row")
path_tool = v["map"].toolbar.tools["solar:path"]
for label, (x0, y0), (x1, y1) in [
    ("exact pixel centres", (0, SLIT), (63, SLIT)),
    ("drawn 0.3 px off (left, up)", (-0.3, SLIT + 0.3), (63.2, SLIT + 0.3)),
    ("drawn 0.3 px off (down)", (0.2, SLIT - 0.3), (63.4, SLIT - 0.3)),
    ("drawn 1 px slanted", (0.0, SLIT - 0.4), (63.0, SLIT + 0.4)),
]:
    x, y = sample_points(np.array([x0, x1]), np.array([y0, y1]))
    for sampling in ("truncate", "nearest", "linear"):
        before = [d for d in app.data_collection if isinstance(d, PathData)]
        path_tool._extract(x, y, sampling)
        events(5)
        [diagram] = [d for d in app.data_collection if isinstance(d, PathData) and d not in before and d.original_data is stack]
        values = diagram[diagram.main_components[0] if diagram.main_components else stack.main_components[0]]
        print(f"  {label}, {sampling}: diagram {diagram.shape}", end="")
        compare("", np.asarray(values)[SCAN, wl], row_expected if len(x) == 64 else row_expected[: len(x)])
# 1-D cut of the stack's diagram (scan, λ, path): a Pixel click on a viewer of it showing λ against scan
diagram = [d for d in app.data_collection if isinstance(d, PathData) and d.original_data is stack][0]
dv = image(app, diagram, 1, 0)
before = list(app.data_collection.subset_groups)
mode.edit_subset = []
select_point(dv, wl, SCAN)
groups = new_groups(before)
print("  Pixel click on the diagram (λ, scan) viewer: new groups", [(g.label, g.subset_state.slices) for g in groups])
pd = app.new_data_viewer(ProfileViewer, data=diagram)
pd.state.x_att = diagram.pixel_component_ids[2]
events(10)
compare("map row from the diagram + Pixel + Profile", profile_of(pd, next(s for s in groups[0].subsets if s.data is diagram)),
        row_expected)
print("  coordinator point after the diagram click:", coord.group.label, coord.point.slices if coord.point else None)
