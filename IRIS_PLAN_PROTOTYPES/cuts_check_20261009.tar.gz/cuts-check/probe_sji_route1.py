"""Route 1 on the 4000255147 SJI 1400 cube: a Pixel click on a viewer showing y against time (or time against x)."""
from common import *  # noqa: F403

from glue_solar.quicklook import coordinator, quicklook
from glue_solar.sources.loaders.iris import image_data

t0 = time.perf_counter()
sji = image_data(SJI_FILE)
print(f"loaded in {time.perf_counter() - t0:.1f} s: {sji.shape}, size {sji.size:.3g}")
t0 = time.perf_counter()
cube = np.asarray(sji[sji.main_components[0]])
print(f"full read {time.perf_counter() - t0:.1f} s")
FRAME, Y, X = 123, 200, 150

for in_quicklook in (False, True):
    print(f"--- {'inside a slit-jaw-only quicklook tab' if in_quicklook else 'plain Image viewers'}")
    app = new_app()
    sji = image_data(SJI_FILE)
    if in_quicklook:
        q = quicklook(app, [sji])
        events(20)
    else:
        app.data_collection.append(sji)
    coord = coordinator(app.data_collection)
    # row of frame FRAME at y=Y: a viewer showing time (x) against y (y), click (FRAME, Y)
    ty = image(app, sji, 0, 1)
    select_point(ty, FRAME, Y)
    state = coord.point
    print("click on (time, y) viewer -> point", state.slices if state is not None else None)
    group = coord.group
    sub = next(s for s in group.subsets if s.data is sji)
    prof = app.new_data_viewer(ProfileViewer, data=sji)
    prof.state.x_att = sji.pixel_component_ids[2]
    events(10)
    compare("(c) frame row cube[frame, y, :] via Pixel on (time, y)", profile_of(prof, sub), cube[FRAME, Y, :])
    print("  ", draw_ok(prof))
    # does it follow a frame slider? an (x, y) viewer of the same cube
    xy = image(app, sji, 2, 1, (0, 0, 0))
    events(10)
    print("  (x, y) viewer frame slider after the click:", xy.state.slices)
    xy.state.slices = (FRAME + 7, 0, 0)
    events(10)
    state = coord.point
    print("  after moving that viewer's frame slider to", FRAME + 7, "-> point", state.slices if state is not None else None)
    compare("  row follows the slider", profile_of(prof, sub), cube[FRAME + 7, Y, :])
    # drag: Pixel drag on the (time, y) viewer
    ty.toolbar.active_tool = "image:point_selection"
    mouse(ty, "button_press_event", FRAME, Y)
    mouse(ty, "motion_notify_event", FRAME + 3, Y + 5)
    mouse(ty, "button_release_event", FRAME + 3, Y + 5)
    events(10)
    compare("  row follows a Pixel drag to (frame+3, y+5)", profile_of(prof, sub), cube[FRAME + 3, Y + 5, :])

    # column of frame FRAME at x=X: a viewer showing x (x) against time (y), click (X, FRAME)
    xt = image(app, sji, 2, 0)
    select_point(xt, X, FRAME)
    state = coord.point
    print("click on (x, time) viewer -> point", state.slices if state is not None else None)
    group = coord.group
    sub = next(s for s in group.subsets if s.data is sji)
    prof2 = app.new_data_viewer(ProfileViewer, data=sji)
    prof2.state.x_att = sji.pixel_component_ids[1]
    events(10)
    compare("(c) frame column cube[frame, :, x] via Pixel on (x, time)", profile_of(prof2, sub), cube[FRAME, :, X])
    print("  ", draw_ok(prof2))
    # the first profile (x on x) now shows a 1-value profile: what does it draw?
    print("  first profile after the column click:", draw_ok(prof))
