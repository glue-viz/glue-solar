"""Routes 2-4 on the 4000255147 SJI 1400 cube, and route 1's effect on a raster quicklook's point."""
from common import *  # noqa: F403

from glue.core.edit_subset_mode import AndMode, ReplaceMode
from glue.core.roi import RectangularROI, XRangeROI
from glue.core.subset import SliceSubsetState
from glue.plugins.tools.path_slicer.path_sliced_data import sample_points

from glue_solar.quicklook import QuicklookImageViewer, coordinator, quicklook
from glue_solar.sources.loaders.iris import image_data, raster_data
from glue_solar.tools import PathData

sji = image_data(SJI_FILE)
cube = np.asarray(sji[sji.main_components[0]])
FRAME, Y, X = 123, 200, 150
row_expected, col_expected = cube[FRAME, Y, :], cube[FRAME, :, X]
app = new_app()
app.data_collection.append(sji)
mode = app.session.edit_subset_mode


def new_groups(before):
    return [g for g in app.data_collection.subset_groups if g not in before]


def sub(group):
    return next(s for s in group.subsets if s.data is sji)


print("=== Route 2: a one-row region on a frame (Quicklook viewer and plain glue viewer)")
for cls in (QuicklookImageViewer, ImageViewer):
    xy = app.new_data_viewer(cls, data=sji)
    xy.state.x_att, xy.state.y_att = sji.pixel_component_ids[2], sji.pixel_component_ids[1]
    xy.state.slices = (FRAME, 0, 0)
    events(5)
    mode.edit_subset, before = [], list(app.data_collection.subset_groups)
    xy.apply_roi(RectangularROI(-0.5, cube.shape[2] - 0.5, Y - 0.4, Y + 0.4))
    events(5)
    [g] = new_groups(before)
    p = app.new_data_viewer(ProfileViewer, data=sji)
    p.state.x_att, p.state.function = sji.pixel_component_ids[2], "mean"
    events(5)
    compare(f"{cls.__name__}: frame row, region only", profile_of(p, sub(g)), row_expected)
    compare("  = nanmean over every frame", profile_of(p, sub(g)), np.nanmean(cube[:, Y, :], axis=0))
    # AND a frame range from a Profile with x = frame (pixel axis 0)
    pf = app.new_data_viewer(ProfileViewer, data=sji)
    pf.state.x_att = sji.pixel_component_ids[0]
    events(5)
    mode.edit_subset, mode.mode = [g], AndMode
    pf.apply_roi(XRangeROI(FRAME - 0.4, FRAME + 0.4))
    events(5)
    mode.mode = ReplaceMode
    compare(f"{cls.__name__}: frame row, region AND frame range", profile_of(p, sub(g)), row_expected)

print("=== Route 3: a SliceSubsetState group")
mode.edit_subset = []
g = app.data_collection.new_subset_group(label="cut", subset_state=SliceSubsetState(
    sji, [slice(FRAME, FRAME + 1), slice(Y, Y + 1), slice(None)]))
p = app.new_data_viewer(ProfileViewer, data=sji)
p.state.x_att = sji.pixel_component_ids[2]
events(5)
compare("frame row via SliceSubsetState", profile_of(p, sub(g)), row_expected)

print("=== Route 4: Path diagram along a frame's row, then a 1-D cut of the (frame, path) diagram")
xy = app.new_data_viewer(ImageViewer, data=sji)
xy.state.x_att, xy.state.y_att = sji.pixel_component_ids[2], sji.pixel_component_ids[1]
xy.state.slices = (FRAME, 0, 0)
events(5)
tool = xy.toolbar.tools["solar:path"]
x, y = sample_points(np.array([-0.3, cube.shape[2] - 0.7]), np.array([Y + 0.3, Y - 0.2]))
for sampling in ("truncate", "nearest"):
    before = [d for d in app.data_collection if isinstance(d, PathData)]
    tool._extract(x, y, sampling)
    events(5)
    [d] = [d for d in app.data_collection if isinstance(d, PathData) and d not in before]
    compare(f"diagram {d.shape} row at the frame, {sampling}", np.asarray(d[sji.main_components[0]])[FRAME], row_expected)
mode.edit_subset, before = [], list(app.data_collection.subset_groups)
dv = app.new_data_viewer(ImageViewer, data=d)
events(5)
print("  diagram viewer shows axes", dv.state.x_att, dv.state.y_att)
dv.apply_roi(RectangularROI(-0.5, d.shape[1] - 0.5, FRAME - 0.4, FRAME + 0.4))
events(5)
[g] = new_groups(before)
pd = app.new_data_viewer(ProfileViewer, data=d)
pd.state.x_att = d.pixel_component_ids[1]
events(5)
compare("frame row from the nearest diagram + one-row region + Profile", profile_of(pd, next(s for s in g.subsets if s.data is d)),
        row_expected)

print("=== Route 1 inside a raster quicklook: an SJI click while the quicklook's Point is the edit subset")
app2 = new_app()
[stack] = raster_data(RASTER_FILES, ["Si IV 1394"], stack=True)
sji2 = image_data(SJI_FILE)
v = quicklook(app2, [stack])
events(20)
app2.data_collection.append(sji2)
[point] = app2.session.edit_subset_mode.edit_subset
ty = app2.new_data_viewer(ImageViewer, data=sji2)
ty.state.x_att, ty.state.y_att = sji2.pixel_component_ids[0], sji2.pixel_component_ids[1]
events(5)
select_point(ty, FRAME, Y)
print("  quicklook Point group now on", point.subset_state.reference_data.label, point.subset_state.slices)
s = next(s for s in point.subsets if s.data is stack)
print("  quicklook spectrum panel's point profile:", (lambda g: g if isinstance(g, str) else [np.shape(a) for a in g])(
    profile_of(v["spectrum"], s)))
