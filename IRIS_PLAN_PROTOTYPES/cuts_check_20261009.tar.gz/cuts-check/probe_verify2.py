"""IndexedData in a saved session, and whether matplotlib really draws a 1-sample profile against 313 x."""
from common import *  # noqa: F403

from glue.core.data_derived import IndexedData
from glue.core.state import GlueSerializer
from glue.core.subset import SliceSubsetState

from glue_solar.quicklook import _line_core, quicklook
from glue_solar.sources.loaders.iris import raster_data

[stack] = raster_data(RASTER_FILES, ["Si IV 1394"], stack=True)
wl = _line_core(stack)
SCAN, STEP, SLIT = 1, 20, 300
app = new_app()
v = quicklook(app, [stack])
events(20)
row = IndexedData(stack, (SCAN, None, SLIT, wl))
app.data_collection.append(row)
events(5)
try:
    GlueSerializer(app.session).dumps()
    print("GlueSerializer: session with an IndexedData serialises OK")
except Exception as e:  # noqa: BLE001
    print(f"GlueSerializer with an IndexedData: {type(e).__name__}: {str(e)[:200]}")

mode = app.session.edit_subset_mode
edit = mode.edit_subset
cut = app.data_collection.new_subset_group(
    label="Cut row", subset_state=SliceSubsetState(stack, [slice(SCAN, SCAN + 1), slice(None), slice(SLIT, SLIT + 1), slice(wl, wl + 1)]))
mode.edit_subset = edit
events(5)
spec = v["spectrum"]
sub = next(s for s in cut.subsets if s.data is stack)
[artist] = [a for a in spec.layers if a.state.layer is sub]
artist.state.reset_cache()
artist._calculate_profile_thread(reset=True)
artist._calculate_profile_postthread()
line = artist.plot_artist
print("line visible:", line.get_visible(), "state.visible:", artist.state.visible, "lengths:", len(line.get_xdata()), len(line.get_ydata()))
try:
    line.recache()
    print("Line2D.recache: ok ->", line.get_path().vertices.shape)
except Exception as e:  # noqa: BLE001
    print(f"Line2D.recache: {type(e).__name__}: {e}")
import matplotlib
print("matplotlib", matplotlib.__version__)
try:
    spec.figure.canvas.draw()
    print("canvas.draw: ok")
except Exception as e:  # noqa: BLE001
    print(f"canvas.draw: {type(e).__name__}: {e}")
