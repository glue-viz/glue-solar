"""Save and restore of an application holding an IndexedData, done as glue does (GlueSerializer(app))."""
from common import *  # noqa: F403

from glue.core.data_derived import IndexedData
from glue.core.state import GlueSerializer, GlueUnSerializer

from glue_solar.quicklook import _line_core, quicklook
from glue_solar.sources.loaders.iris import raster_data

[stack] = raster_data(RASTER_FILES, ["Si IV 1394"], stack=True)
wl = _line_core(stack)
app = new_app()
v = quicklook(app, [stack])
events(20)
row = IndexedData(stack, (1, None, 300, wl))
app.data_collection.append(row)
p = app.new_data_viewer(ProfileViewer, data=row)
events(10)
try:
    dumped = GlueSerializer(app, include_data=False, absolute_paths=True).dumps()
    print("save: ok; IndexedData keys:", [k for k in __import__("json").loads(dumped) if "stack[" in k][:2])
    try:
        ga = GlueUnSerializer.loads(dumped)
        ga.object("__main__")
        print("restore: ok")
    except Exception as e:  # noqa: BLE001
        print(f"restore: {type(e).__name__}: {str(e)[:200]}")
except Exception as e:  # noqa: BLE001
    print(f"save: {type(e).__name__}: {str(e)[:200]}")
