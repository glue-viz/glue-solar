from common import *
from glue_solar.sources.loaders.iris import image_data
from glue.viewers.image.pixel_selection_subset_state import PixelSubsetState
sji = image_data(SJI_FILE)
print(type(sji), type(sji).__mro__[:3])
cid = sji.main_components[0]
st = PixelSubsetState(sji, [slice(123,124), slice(200,201), slice(None)])
a = st.to_array(sji, cid); print("to_array", np.shape(a))
r = sji.compute_statistic('maximum', cid, axis=(0,1), subset_state=st); print("stat", np.shape(r), r[:3] if np.ndim(r) else r)
app = new_app(); app.data_collection.append(sji)
g = app.data_collection.new_subset_group(label='p', subset_state=st)
prof = app.new_data_viewer(ProfileViewer, data=sji)
print("x_att choices", [str(c) for c in type(prof.state).x_att.get_choices(prof.state)])
prof.state.x_att = sji.pixel_component_ids[2]
print("x_att", prof.state.x_att, prof.state.x_att_pixel)
events(10)
for a in prof.layers:
    a.state.reset_cache(); p = a.state.profile
    print(a.state.layer.label, None if p is None else [np.shape(v) for v in p])
