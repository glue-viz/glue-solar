"""Can a session holding an IndexedData be restored? And how does a Profile of the stack draw a 1-sample y (matplotlib shape)."""
from common import *  # noqa: F403

from glue.core.data_derived import IndexedData
from glue.core.state import GlueSerializer, GlueUnSerializer

from glue_solar.quicklook import _line_core, quicklook
from glue_solar.sources.loaders.iris import raster_data

[stack] = raster_data(RASTER_FILES, ["Si IV 1394"], stack=True)
wl = _line_core(stack)
app = new_app()
v = quicklook(app, [stack])
events(20)
row = IndexedData(stack, (1, None, 300, wl))
app.data_collection.append(row)
p = app.new_data_viewer(ProfileViewer, data=row)
events(10)
dumped = GlueSerializer(app.session).dumps()
print("serialised; IndexedData entry:", [k for k in __import__("json").loads(dumped) if "stack[" in k][:2])
try:
    ga = GlueUnSerializer.loads(dumped)
    ga.object("__main__")
    print("restore: ok")
except Exception as e:  # noqa: BLE001
    print(f"restore: {type(e).__name__}: {str(e)[:200]}")
import matplotlib.lines as ml
l = ml.Line2D(np.arange(313.0), np.array([5.0]))
l.recache()
print("Line2D(313 x, 1 y) path vertices", l.get_path().vertices.shape, "y unique", np.unique(l.get_path().vertices[:, 1]))
