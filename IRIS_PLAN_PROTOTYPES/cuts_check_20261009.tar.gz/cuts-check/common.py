"""Shared setup for the cut probes: a headless glue-solar app, modal dialogs fail, helpers to click and read profiles."""
import os
import sys
import tempfile
import time

os.environ["GLUE_TESTING"] = "True"
from glue import config as glue_config

glue_config.CFG_DIR = tempfile.mkdtemp()

import numpy as np
from qtpy import QtWidgets
from matplotlib.backend_bases import MouseEvent

import glue_solar
from glue_qt.app.application import GlueApplication
from glue_qt.viewers.image import ImageViewer
from glue_qt.viewers.profile import ProfileViewer

RASTER_DIR = "/Users/nabil/DATA/IRIS/0598beef2a051b4f371a4b09e439c4e4-iris_l2_20130902_182935_4000005156_raster"
RASTER_FILES = sorted(os.path.join(RASTER_DIR, f) for f in os.listdir(RASTER_DIR))
SJI_FILE = "/Users/nabil/DATA/IRIS/534d789bb0a2821fb2b78eb36d1d6753-iris_l2_20130902_163935_4000255147_SJI_1400_t000.fits.gz"


def modal(*args, **kwargs):
    raise AssertionError("a modal dialog opened")


for cls in (QtWidgets.QMessageBox, QtWidgets.QDialog):
    cls.exec_ = modal
    cls.exec = modal

glue_solar.setup()
qapp = QtWidgets.QApplication.instance() or QtWidgets.QApplication(sys.argv)


def new_app():
    app = GlueApplication()
    app.show = lambda: None
    return app


def events(n=5):
    for _ in range(n):
        QtWidgets.QApplication.processEvents()


def mouse(viewer, name, x, y, button=1):
    viewer.figure.canvas.draw()
    px, py = viewer.axes.transData.transform((x, y))
    viewer.figure.canvas.callbacks.process(name, MouseEvent(name, viewer.figure.canvas, px, py, button=button))


def select_point(viewer, x, y):
    viewer.toolbar.active_tool = "image:point_selection"
    mouse(viewer, "button_press_event", x, y)
    mouse(viewer, "button_release_event", x, y)
    events()


def image(app, data, x, y, slices=None):
    viewer = app.new_data_viewer(ImageViewer, data=data)
    viewer.state.x_att, viewer.state.y_att = data.pixel_component_ids[x], data.pixel_component_ids[y]
    if slices is not None:
        viewer.state.slices = tuple(slices)
    events()
    return viewer


def profile_of(viewer, layer):
    """(x, y) of the viewer's layer whose state.layer is ``layer``, or the error as text."""
    for artist in viewer.layers:
        if artist.state.layer is layer:
            try:
                artist.state.reset_cache()
                if not artist.state.visible:
                    return f"layer hidden (visible=False)"
                artist.state.update_profile(update_limits=False)  # glue's limits update resets the cache once
                got = artist.state._profile_cache
                if got is None:
                    return "profile None"
                return got
            except Exception as e:  # noqa: BLE001
                return f"{type(e).__name__}: {e}"
    return "no such layer"


def draw_ok(viewer):
    """Whether a full draw of the viewer raises, and each layer artist's enabled/disabled message."""
    try:
        for artist in viewer.layers:
            artist.update()
        viewer.figure.canvas.draw()
        drawn = "draw ok"
    except Exception as e:  # noqa: BLE001
        drawn = f"draw raised {type(e).__name__}: {e}"
    return drawn, [(getattr(a.state.layer, "label", "?"), a.enabled, a.disabled_message) for a in viewer.layers]


def compare(label, got, expected):
    """Print whether a profile (x, y) or an array equals ``expected`` exactly (NaN = NaN)."""
    if isinstance(got, str):
        print(f"  {label}: FAIL ({got})")
        return False
    y = np.asarray(got[1] if isinstance(got, tuple) else got, dtype=float)
    expected = np.asarray(expected, dtype=float)
    if y.shape != expected.shape:
        print(f"  {label}: FAIL shape {y.shape} vs expected {expected.shape}; got[:5]={y.ravel()[:5]}")
        return False
    exact = np.array_equal(y, expected, equal_nan=True)
    diff = np.nanmax(np.abs(y - expected)) if np.isfinite(y - expected).any() else 0.0
    nan_mismatch = int((np.isnan(y) != np.isnan(expected)).sum())
    print(f"  {label}: {'EXACT' if exact else 'DIFFERS'} (n={y.size}, max|diff|={diff:.4g}, NaN mismatches={nan_mismatch})")
    return exact
